# UPCL source code

This folder contains a source-only copy of the UPCL / LASE research project.
The original source files retain their existing directory structure and contents.
Previously generated experimental data and results are not included in this release.

## Contents

| Path | Contents |
| --- | --- |
| `src/` | UPCL, DE variants, benchmark definitions, experiment drivers, analysis, plotting, and manuscript-generation code |
| `legacy/uav_20261011/` | Frozen UAV simulator source retained for interpreting the earlier experiments |
| `scripts/` | Existing launch and utility scripts |
| `tests/` | Existing test source |
| `gui_launcher.py` | Desktop interface source |
| `app/webapp/` | Web API, interface source, local JavaScript libraries, and supporting scripts |
| `requirements.txt` | Dependencies supplied with the original project |

## Installation

Use Python 3.10 or later. From this folder:

```shell
python -m venv .venv
```

Activate the virtual environment, then install the supplied dependencies:

```shell
python -m pip install -r requirements.txt
```

For the optional web interface, also install:

```shell
python -m pip install -r app/webapp/requirements.txt
```

## Entry points

Inspect the experiment options before starting a computation:

```shell
python src/run_upcl_cec.py --help
python src/run_uav.py --help
```

To start the web interface manually:

```shell
cd app/webapp
python -m uvicorn web.server:app --host 127.0.0.1 --port 8000
```

The Windows web launcher is `app/webapp/start_web.bat`.
The interface does not have access to the original experiment archive in this source-only folder.
Analysis and manuscript-generation scripts that read result tables, figures, or paper assets require those inputs to be supplied separately or generated first.
Some existing batch scripts refer to the original workspace; adjust those paths before using them in a different location.

## Benchmark and simulator inputs

Official CEC shift, rotation, and shuffle input files are not bundled.
As documented in `src/cec_suites.py`, missing official inputs cause a deterministic fallback to be used.
Provide the official inputs in the expected `data/cec20xx/` locations when official benchmark comparability is required.

The AFSIM engine installation is an optional external dependency and is not included.
Its integration source is retained in the package.

## Excluded material

- Experimental archives, raw results, processed CSV tables, plots, and logs.
- Runtime account databases and locally saved application state.
- The AFSIM software installation, maps, executables, and build products.
- Git history, Python caches, virtual environments, and compiled outputs.
- Manuscript DOCX/PDF files, downloaded reference papers, recorded videos, and experiment screenshots.

## 中文说明

这是从原项目单独复制的源码目录。保留算法、实验与分析脚本、桌面界面、Web 前后端源码、必要的界面资源及依赖说明。
本次不附实验数据、实验结果、账号数据库、AFSIM 安装包、历史 Git 仓库或缓存。
原项目文件没有被移动或修改；已有源码按原样复制。该目录可作为 GitHub 源码上传目录。

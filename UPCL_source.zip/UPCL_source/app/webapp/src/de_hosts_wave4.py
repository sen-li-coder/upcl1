# -*- coding: utf-8 -*-
"""Wave-4 pure-DE mechanism variants (mechanism-probe study).

Ten additional DE variants, each contributing a mechanism axis that the
existing 21 hosts do not cover: parameter encoding + p-best, discrete F pool,
distance/rank-driven parameter adaptation, sinusoidal parameter generation,
multi-operator adaptation, individual CR adaptation, hyperspherical search,
and iterated local search.

All classes subclass the ``DifferentialEvolution`` hook interface (via the
classes in ``de_hosts`` / ``de_hosts_cec``) and therefore expose the three
UPCL hooks identically to every existing host.
"""
import numpy as np

from de_hosts import (
    DifferentialEvolution, LSHADE, SHADE, STRATEGY_BEST1,
    STRATEGY_CURRENT_TO_PBEST, STRATEGY_CURRENT_TO_RAND, STRATEGY_RAND1,
)


# ===========================================================================
# Parameter encoding + p-best / discrete F pool
# ===========================================================================
class _jDEBase(DifferentialEvolution):
    """Shared jDE parameter encoding (F/CR in the genome, tau1/tau2 update).

    Mirrors ``de_hosts_cec.jDE`` so this module stays import-order independent.
    """
    name = "_jDEBase"

    def __init__(self, dim, lb, ub, pop_size=None, F=0.5, CR=0.9,
                 tau1=0.1, tau2=0.1, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.F_arr = np.full(self.N, F)
        self.CR_arr = np.full(self.N, CR)
        self.tau1, self.tau2 = tau1, tau2

    def _sample_params(self, i):
        if self.rng.random() < self.tau1:
            self.F_arr[i] = 0.1 + 0.9 * self.rng.random()
        if self.rng.random() < self.tau2:
            self.CR_arr[i] = self.rng.random()
        return self.F_arr[i], self.CR_arr[i]

    def _get_strategy(self, i, override):
        return STRATEGY_RAND1


class jDE100(_jDEBase):
    """jDE100 (Brest, Maučec & Bošković 2020).

    jDE self-adaptation (F/CR encoded in the genome, ``tau1``/``tau2``)
    combined with current-to-pbest/1 mutation over a top-``p`` pool.
    Axis: parameter encoding + p-best directional bias.
    """
    name = "jDE100"

    def __init__(self, dim, lb, ub, pop_size=None, F=0.5, CR=0.9,
                 tau1=0.1, tau2=0.1, p=0.1, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, F=F, CR=CR,
                         tau1=tau1, tau2=tau2, seed=seed, **kwargs)
        self.p = p

    def _sample_pbest_indices(self):
        top_k = max(2, int(self.p * self.N))
        order = np.argsort(self.fitness)
        return self.rng.choice(order[:top_k], size=self.N, replace=True)

    def _get_strategy(self, i, override):
        return STRATEGY_CURRENT_TO_PBEST


class j2020(_jDEBase):
    """j2020 (Brest, Maučec & Bošković 2020).

    jDE encoding with a *discrete* F pool {0.5, 0.6, 0.7}; each slot carries
    its own success/trial counters so the sampling distribution adapts.
    Axis: discrete F-pool self-adaptation.
    """
    name = "j2020"

    def __init__(self, dim, lb, ub, pop_size=None, F=0.5, CR=0.9,
                 tau1=0.1, tau2=0.1, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, F=F, CR=CR,
                         tau1=tau1, tau2=tau2, seed=seed, **kwargs)
        self.F_pool = np.array([0.5, 0.6, 0.7])
        self.nfp = len(self.F_pool)
        self._fsucc = np.ones(self.nfp)
        self._ftrial = np.ones(self.nfp)
        self._fcur = np.full(self.N, -1, dtype=int)

    def _sample_params(self, i):
        if self.rng.random() < self.tau1:
            p = self._fsucc / self._ftrial
            k = int(self.rng.choice(self.nfp, p=p / p.sum()))
            self._fcur[i] = k
            self.F_arr[i] = self.F_pool[k]
        else:
            self._fcur[i] = -1
        if self.rng.random() < self.tau2:
            self.CR_arr[i] = self.rng.random()
        return self.F_arr[i], self.CR_arr[i]

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        k = self._fcur[i]
        if k >= 0:
            self._ftrial[k] += 1
            if accepted and fu < f_old:
                self._fsucc[k] += 1


# ===========================================================================
# Distance / rank driven parameter adaptation
# ===========================================================================
class DISH(SHADE):
    """DISH (Viktorin et al. 2019): distance-based parameter adaptation.

    SHADE success-history, but the M_F/M_CR update is additionally weighted by
    the Euclidean distance of each successful parent to the current best:
    closer parents get higher weight, steering the memory toward small
    exploitative steps.  Axis: distance-driven F/CR adaptation.
    """
    name = "DISH"

    def __init__(self, dim, lb, ub, pop_size=None, H=6, p=0.1,
                 archive_rate=2.0, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, H=H, p=p,
                         archive_rate=archive_rate, seed=seed, **kwargs)
        self._sdist = []

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            if not hasattr(self, '_sF'):
                self._sF, self._sCR, self._sdelta = [], [], []
            self._sF.append(F)
            self._sCR.append(CR)
            self._sdelta.append(max(0.0, f_old - fu))
            d = float(np.linalg.norm(self.pop[i] - self.pop[self.best_idx]))
            self._sdist.append(d)

    def _generation_end_update(self):
        if hasattr(self, '_sF') and self._sF:
            sF = np.asarray(self._sF, dtype=float)
            sCR = np.asarray(self._sCR, dtype=float)
            sd = np.asarray(self._sdelta, dtype=float)
            dist = np.asarray(self._sdist, dtype=float)
            dmax = dist.max() if dist.size else 1.0
            # distance weight: closer to best -> higher weight
            w = sd * (dmax - dist + 0.1 * dmax + 1e-12)
            wsum = w.sum()
            if wsum > 0.0:
                w = w / wsum
                mf = float(np.sum(w * sF))
                self.M_F[self.k] = float(np.sum(w * sF ** 2) / (mf + 1e-12))
                self.M_CR[self.k] = float(np.sum(w * sCR))
            else:
                self.M_F[self.k] = float(np.mean(sF))
                self.M_CR[self.k] = float(np.mean(sCR))
            self.k = (self.k + 1) % self.H
            self._sF, self._sCR, self._sdelta, self._sdist = [], [], [], []


class DISK(DISH):
    """DISK (Viktorin et al. 2019): distance via rank-based parameter adaptation.

    Same success-history machinery as DISH but the weight uses the rank of the
    successful parent in the current population (better rank -> higher weight)
    instead of the raw Euclidean distance.  Axis: rank-driven F/CR adaptation.
    """
    name = "DISK"

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            if not hasattr(self, '_sF'):
                self._sF, self._sCR, self._sdelta = [], [], []
            self._sF.append(F)
            self._sCR.append(CR)
            self._sdelta.append(max(0.0, f_old - fu))
            order = np.argsort(self.fitness)      # ascending
            rank = float(np.where(order == i)[0][0])
            self._sdist.append(rank)

    def _generation_end_update(self):
        if hasattr(self, '_sF') and self._sF:
            sF = np.asarray(self._sF, dtype=float)
            sCR = np.asarray(self._sCR, dtype=float)
            sd = np.asarray(self._sdelta, dtype=float)
            rank = np.asarray(self._sdist, dtype=float)
            # better rank (small) -> higher weight
            w = sd * (self.N - rank + 1.0)
            wsum = w.sum()
            if wsum > 0.0:
                w = w / wsum
                mf = float(np.sum(w * sF))
                self.M_F[self.k] = float(np.sum(w * sF ** 2) / (mf + 1e-12))
                self.M_CR[self.k] = float(np.sum(w * sCR))
            else:
                self.M_F[self.k] = float(np.mean(sF))
                self.M_CR[self.k] = float(np.mean(sCR))
            self.k = (self.k + 1) % self.H
            self._sF, self._sCR, self._sdelta, self._sdist = [], [], [], []


# ===========================================================================
# Sinusoidal parameter generation
# ===========================================================================
class LSHADE_cnEpSin(LSHADE):
    """LSHADE-cnEpSin (Awad et al. 2017).

    L-SHADE whose F is generated by an ensemble of sinusoidal components
    (sin/cos) during the first half of the budget, then falls back to the
    Cauchy scheme of L-SHADE in the second half.  Axis: sinusoidal F generation
    vs. the standard Cauchy/Normal schemes.
    """
    name = "LSHADE-cnEpSin"

    def __init__(self, dim, lb, ub, pop_size=None, N_min=4, H=6, p=0.11,
                 archive_rate=2.6, freq=0.25, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, N_min=N_min, H=H,
                         p=p, archive_rate=archive_rate, seed=seed, **kwargs)
        self.freq = freq
        self._sin_prob = 0.5
        self._sin_succ = 0.0
        self._sin_fail = 0.0

    def _sample_params(self, i):
        r = self.rng.integers(0, self.H)
        ratio = min(self.nevals / max(self._max_evals, 1), 1.0)
        if ratio < 0.5:
            use_sin = self.rng.random() < self._sin_prob
            self._cur_sin = 1 if use_sin else 0
            t = 2.0 * np.pi * self.freq * ratio * 40.0
            if use_sin:
                F = 0.5 * (np.sin(t) + 1.0)
            else:
                F = 0.5 * (np.cos(t) + 1.0)
            F = 0.1 + 0.9 * F
        else:
            self._cur_sin = -1
            F = -1.0
            for _ in range(20):
                F = self.M_F[r] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
                if F > 1:
                    F = 1.0
                if F > 0:
                    break
            if F <= 0:
                F = 0.5
        CR = np.clip(self.rng.normal(self.M_CR[r], 0.1), 0.0, 1.0)
        return F, CR

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            if not hasattr(self, '_sF'):
                self._sF, self._sCR, self._sdelta = [], [], []
            self._sF.append(F)
            self._sCR.append(CR)
            self._sdelta.append(max(0.0, f_old - fu))
        if getattr(self, '_cur_sin', -1) >= 0:
            if accepted and fu < f_old:
                self._sin_succ += 1
            else:
                self._sin_fail += 1
            tot = self._sin_succ + self._sin_fail
            if tot > 0:
                self._sin_prob = np.clip(self._sin_succ / tot, 0.05, 0.95)


class SinDE(DifferentialEvolution):
    """SinDE (Draa et al. 2019): purely sinusoidal F and CR.

    F and CR are both driven by sinusoids of the generation counter (with
    different frequencies/phases), producing a periodic exploration/exploitation
    schedule without any memory.  Axis: sinusoidal F/CR generation.
    """
    name = "SinDE"

    def __init__(self, dim, lb, ub, pop_size=None, freq_F=0.5, freq_CR=0.3,
                 seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.freq_F = freq_F
        self.freq_CR = freq_CR

    def _sample_params(self, i):
        t = 2.0 * np.pi * self.g / 50.0
        F = 0.1 + 0.9 * (0.5 * (np.sin(self.freq_F * t) + 1.0))
        CR = 0.5 * (np.sin(self.freq_CR * t + np.pi / 2.0) + 1.0)
        return F, CR

    def _get_strategy(self, i, override):
        return STRATEGY_RAND1


# ===========================================================================
# Multi-operator adaptation (CEC2020 winner)
# ===========================================================================
class IMODE(LSHADE):
    """IMODE (Sallam, Elsayed, Chakrabortty & Ryan 2020, CEC2020 winner).

    L-SHADE (success-history F/CR + archive + LPSR) with a four-operator pool
    {rand/1, current-to-pbest, current-to-rand, best/1} whose sampling
    probabilities adapt from per-operator success counts.  Axis: multi-operator
    adaptive selection.
    """
    name = "IMODE"

    def __init__(self, dim, lb, ub, pop_size=None, N_min=4, H=6, p=0.11,
                 archive_rate=2.6, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, N_min=N_min, H=H,
                         p=p, archive_rate=archive_rate, seed=seed, **kwargs)
        self.strategies = [STRATEGY_RAND1, STRATEGY_CURRENT_TO_PBEST,
                           STRATEGY_CURRENT_TO_RAND, STRATEGY_BEST1]
        self.ns = len(self.strategies)
        self.prob = np.ones(self.ns) / self.ns
        self._succ = np.zeros(self.ns)
        self._fail = np.zeros(self.ns)
        self._cur = np.zeros(self.N, dtype=int)

    def _get_strategy(self, i, override):
        k = int(self.rng.choice(self.ns, p=self.prob))
        self._cur[i] = k
        return self.strategies[k]

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        k = self._cur[i]
        if accepted and fu < f_old:
            self._succ[k] += 1
            if not hasattr(self, '_sF'):
                self._sF, self._sCR, self._sdelta = [], [], []
            self._sF.append(F)
            self._sCR.append(CR)
            self._sdelta.append(max(0.0, f_old - fu))
        else:
            self._fail[k] += 1

    def _generation_end_update(self):
        super()._generation_end_update()          # SHADE memory + LPSR
        tot = self._succ + self._fail
        if tot.sum() > 0:
            s = self._succ / np.maximum(tot, 1) + 0.05
            self.prob = s / s.sum()
            self._succ[:] = 0.0
            self._fail[:] = 0.0


# ===========================================================================
# Individual-level CR adaptation
# ===========================================================================
class PaDE(SHADE):
    """PaDE (Meng, Pan & Tseng 2019).

    SHADE success-history for F, but CR is adapted at the *individual* level:
    each genome carries its own CR that persists on success and is re-sampled
    on failure.  Axis: individual-level CR adaptation (vs. the shared memory).
    """
    name = "PaDE"

    def __init__(self, dim, lb, ub, pop_size=None, H=6, p=0.1,
                 archive_rate=2.0, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, H=H, p=p,
                         archive_rate=archive_rate, seed=seed, **kwargs)
        self.CR_arr = np.full(self.N, 0.5)

    def _sample_params(self, i):
        r = self.rng.integers(0, self.H)
        F = -1.0
        for _ in range(20):
            F = self.M_F[r] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1:
                F = 1.0
            if F > 0:
                break
        if F <= 0:
            F = 0.5
        if self.rng.random() < 0.1:
            self.CR_arr[i] = self.rng.normal(0.5, 0.1)
        CR = float(np.clip(self.CR_arr[i], 0.0, 1.0))
        return F, CR

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            if not hasattr(self, '_sF'):
                self._sF, self._sCR, self._sdelta = [], [], []
            self._sF.append(F)
            self._sCR.append(CR)
            self._sdelta.append(max(0.0, f_old - fu))


# ===========================================================================
# Iterated local search
# ===========================================================================
class SHADE_ILS(LSHADE):
    """SHADE-ILS (Molina, LaTorre & Herrera 2018): L-SHADE + iterated local search.

    L-SHADE with an iterated local search: after ``ils_interval`` consecutive
    generations without improvement, the best solution is perturbed with a
    shrinking Gaussian step and the improved point (if any) replaces it.
    Axis: stagnation-triggered local search (replaces, not overlays).
    """
    name = "SHADE-ILS"

    def __init__(self, dim, lb, ub, pop_size=None, N_min=4, H=6, p=0.11,
                 archive_rate=2.6, ils_interval=5, ils_n=3, seed=None,
                 **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, N_min=N_min, H=H,
                         p=p, archive_rate=archive_rate, seed=seed, **kwargs)
        self.ils_interval = ils_interval
        self.ils_n = ils_n

    def _generation_step(self, fobj):
        super()._generation_step(fobj)
        if self.stagnation >= self.ils_interval:
            self._ils(fobj)

    def _ils(self, fobj):
        ratio = min(self.nevals / max(self._max_evals, 1), 1.0)
        sigma = 0.1 * (self.ub - self.lb) * (1.0 - ratio) + 1e-30
        xbest = self.pop[self.best_idx].copy()
        fbest = self.fitness[self.best_idx]
        for _ in range(self.ils_n):
            if self.nevals >= self._max_evals:
                break
            x = np.clip(xbest + sigma * self.rng.standard_normal(self.dim),
                        self.lb, self.ub)
            fu = fobj(x)
            self.nevals += 1
            if self.post_eval_fn is not None:
                self.post_eval_fn(fu)
            if fu < fbest:
                self.pop[self.best_idx] = x
                self.fitness[self.best_idx] = fu
                self.best_so_far = fu
                fbest = fu
                xbest = x.copy()
                self.stagnation = 0


# ===========================================================================
# Wave-4 registry (merged into de_hosts_cec.EXTRA_HOSTS at import time)
# ===========================================================================
WAVE4_HOSTS = {
    'jDE100': jDE100,
    'j2020': j2020,
    'DISH': DISH,
    'DISK': DISK,
    'LSHADE-cnEpSin': LSHADE_cnEpSin,
    'SinDE': SinDE,
    'IMODE': IMODE,
    'PaDE': PaDE,
    'SHADE-ILS': SHADE_ILS,
}

# Adaptivity score (0 fixed / 1 self-adaptive params / 2 adaptive params+strategy
# / 3 adaptive + population-size control), consistent with de_hosts_cec.ADAPTIVITY.
WAVE4_ADAPTIVITY = {
    'jDE100': 1, 'j2020': 1, 'SinDE': 1,
    'DISH': 2, 'DISK': 2, 'PaDE': 2,
    'LSHADE-cnEpSin': 3, 'IMODE': 3, 'SHADE-ILS': 3,
}

WAVE4_POP_SIZE = {
    'jDE100': 100, 'j2020': 100, 'DISH': 100, 'DISK': 100,
    'SinDE': 100, 'PaDE': 100,
    'LSHADE-cnEpSin': '18D', 'IMODE': '18D',
    'SHADE-ILS': '18D',
}

WAVE4_ORDER = [
    'jDE100', 'j2020', 'DISH', 'DISK', 'LSHADE-cnEpSin', 'SinDE',
    'IMODE', 'PaDE', 'SHADE-ILS',
]

# -*- coding: utf-8 -*-
"""CEC 2017 / CEC 2022 paired experiments for the UPCL paper (Exp1 - Exp6).

Protocol
--------
* Suites: CEC 2017 (29 functions, D = 30 and 50) and CEC 2022 (12 functions,
  D = 10 and 20).  Budget 10000 * D evaluations.
* Every cell (host, function, dimension) is run as a **paired** experiment:
  the bare host H and H+UPCL use the same seed, the same population, the same
  budget and the same evaluation accounting.  The only difference is whether
  the proposal-correction layer is attached.
* UPCL hyper-parameters are the fixed values of the manuscript.  Nothing is
  tuned per problem, per function or per host.
* 30 independent runs per cell (configurable, for the smoke tests).

Experiments
-----------
Exp1  overall comparison: error mean +/- std, paired Wilcoxon with Holm
      correction, Win-Tie-Loss per cell, Friedman over the configurations.
Exp2  cross-host generality: improved / tie / degraded counts, mean relative
      improvement and mean policy intervention rate per host, and the test of
      "the better adapted the host, the lower the intervention rate".
Exp3  convergence behaviour on one unimodal (F1), one multimodal (F5), one
      hybrid (F15) and one composite (F25) function.
Exp4  ablation: full UPCL / random correction / no minimal-intervention term /
      no response memory (M = 1) / bare host.
Exp5  mechanism diagnostics: intervention-rate curves, relative correction
      size, gain per function category, high-dimensional effects.
Exp6  computational overhead: wall-clock and UPCL decision time, and the
      check that the evaluation count is unchanged.

Usage
-----
    python run_upcl_cec.py --estimate                 # cost estimate
    python run_upcl_cec.py --stage smoke              # logic check (minutes)
    python run_upcl_cec.py --stage pilot              # small scale
    python run_upcl_cec.py --stage main  --workers 20 # full protocol
    python run_upcl_cec.py --stage ablation           # Exp4 only
    python run_upcl_cec.py --analyze-only             # rebuild tables/figures

Results land in ``results/cec/``; the analysis stage reads whatever is on
disk, so a long run can be interrupted and resumed with ``--resume``.
"""
import argparse
import importlib
import json
import os
import sys
import threading
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                    # noqa: E402
import de_hosts                                            # noqa: E402
import de_hosts_cec as DHC                                 # noqa: E402
from upcl_experiment import (UPCL_CONFIGS, UPCLController,  # noqa: E402
                             get_config)

DHC.register()

# PyInstaller 打包后 __file__ 指向临时解压目录，改用 exe 所在目录作为项目根，
# 保证 results/ 落盘到 exe 旁边（换机器也能独立跑数据）。
if getattr(sys, 'frozen', False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'cec'
STOP_FILE = OUT / '.stop'   # presence requests a graceful stop between cells
PAUSE_FILE = OUT / '.pause'  # presence makes the process exit before running
STATUS_DIR = OUT / 'logs' / '.workers'  # worker 实时状态（GUI 轮询读取）
FES_MULT = 10_000          # budget = FES_MULT * D
N_GRID = 100               # convergence sampling grid
SEED_BASE = 20240_000
FLOOR = 1e-8               # error floor before taking logs

# ===========================================================================
# Result-file schema versioning
# ===========================================================================
# 落盘 JSON 带 ``schema`` 版本号；加载时按版本逐级迁移，避免未来字段/命名演进
# 导致旧数据被当作「新宿主/新结构」而静默整 cell 重跑。
SCHEMA_VERSION = 1

# 宿主标签历史改名（旧名 -> 新名）。新增改名/字段演进时在此登记，并 bump 版本。
_HOST_RENAMES = {}


def migrate_payload(data):
    """Bring an on-disk result payload up to ``SCHEMA_VERSION``.

    Mutates and returns ``data``.  Unknown fields are preserved so a forward
    (older reader) never destroys newer data; we only add/normalise known keys.
    """
    if not isinstance(data, dict):
        return data
    ver = data.get('schema', 0)
    if ver < 1:
        # v0 -> v1: tag the file; migrate any renamed host labels.
        data = dict(data)
        if data.get('host') in _HOST_RENAMES:
            data['host'] = _HOST_RENAMES[data['host']]
        runs = data.get('runs')
        if isinstance(runs, list):
            for run in runs:
                if not isinstance(run, dict):
                    continue
                for arm, rec in run.items():
                    if isinstance(rec, dict) and rec.get('host') in _HOST_RENAMES:
                        rec['host'] = _HOST_RENAMES[rec['host']]
        data['schema'] = SCHEMA_VERSION
        ver = SCHEMA_VERSION
    # future versions go here: ``if ver < 2: ...``
    return data

# Exp4 arms: label -> (UPCL config or None for the bare host)
ABLATION_ARMS = [
    ('bare', None),
    ('random', 'random'),
    ('no_minimal', 'no_minimal'),
    ('mem1', 'no_memory'),
    ('full', 'default'),
]

STAGES = {
    # suite, dims, hosts, functions, runs
    'smoke': dict(suites=['cec2022'], dims=[10], hosts=4, funcs=3, runs=2),
    'pilot': dict(suites=['cec2017'], dims=[30], hosts=6, funcs=6, runs=5),
    'ablation': dict(suites=['cec2017'], dims=[30], hosts=6, funcs=12, runs=5),
    'main': dict(suites=['cec2017', 'cec2022'], dims=None, hosts=None,
                 funcs=None, runs=30),
}

# representative hosts for the figures (Exp3) and for the pilot stages
FIG_HOSTS = ['DE/rand/1', 'JADE', 'SHADE', 'L-SHADE']
PILOT_HOSTS = ['DE/rand/1', 'DE/best/1', 'jDE', 'JADE', 'SHADE', 'L-SHADE']


# ===========================================================================
# Single run
# ===========================================================================
def _grid_interp(evals, conv, grid):
    """Best-so-far error sampled at ``grid`` (step function, as recorded)."""
    idx = np.searchsorted(evals, grid, side='right') - 1
    idx = np.clip(idx, 0, len(conv) - 1)
    return np.asarray(conv, dtype=float)[idx]


def run_arm(host_name, func, dim, seed, max_evals, upcl_cfg_name,
            pop_size=None, measure_upcl=True, record_pop=False, n_pop_frames=20,
            progress_cb=None):
    """Run one arm.  Returns a record dict (no UPCL if cfg name is None).

    ``record_pop`` 时按代采样种群在 x1-x2 子空间的投影轨迹，写入 rec['pop_trace']
    （供二维地形收敛过程可视化）；默认 False 以保持落盘体积不变。

    ``progress_cb(nevals, g)`` 每代调用一次，供 GUI 进度条；默认 None 零开销。
    """
    from upcl_framework import UPCLController as _C

    host = de_hosts.get_host(host_name, dim, func.lb, func.ub, seed=seed,
                             pop_size=pop_size or DHC.pop_size_for(host_name, dim))
    controller, upcl_time = None, 0.0

    if upcl_cfg_name is not None:
        controller = _C(dim, func.lb, func.ub, seed=seed + 977,
                        config=get_config(upcl_cfg_name))
        host.gen_begin_fn = controller.begin_generation
        host.post_eval_fn = controller.observe
        if measure_upcl:
            _raw = controller.propose

            def _timed(x, u, f_x, _raw=_raw):
                nonlocal upcl_time
                t0 = time.perf_counter()
                r = _raw(x, u, f_x)
                upcl_time += time.perf_counter() - t0
                return r
            host.proposal_fn = _timed
        else:
            host.proposal_fn = controller.propose

    # 二维地形采样：按代记录种群 x1-x2 投影，帧数约 n_pop_frames 帧
    record_every = 0
    if record_pop:
        n_pop = pop_size or DHC.pop_size_for(host_name, dim)
        gens_est = max(1, int(max_evals) // max(1, n_pop))
        record_every = max(1, gens_est // max(1, n_pop_frames))

    def _progress(host):
        if progress_cb is not None:
            progress_cb(int(host.nevals), int(host.g))

    t0 = time.perf_counter()
    best_f, best_x, conv, evals = host.run(
        func, max_evals, callback=_progress if progress_cb else None,
        record_pop_every=record_every)
    wall = time.perf_counter() - t0

    grid = np.linspace(0.0, max_evals, N_GRID + 1)[1:]
    f_opt = getattr(func, 'f_opt', None)
    f_opt = 0.0 if f_opt is None else f_opt
    err_curve = _grid_interp(evals, conv, grid) - f_opt
    rec = {
        'host': host_name,
        'func': func.label,
        'fid': func.fid,
        'category': func.category,
        'suite': func.suite,
        'dim': dim,
        'seed': int(seed),
        'arm': upcl_cfg_name or 'bare',
        'max_evals': int(max_evals),
        'nevals': int(host.nevals),
        'err_final': float(best_f - f_opt),
        'err_curve': [float(v) for v in err_curve],
        'wall_time_s': float(wall),
        'upcl_decision_time_s': float(upcl_time),
        'grid': [float(v) for v in grid],
    }
    if record_pop and getattr(host, 'pop_history', None):
        rec['pop_trace'] = {
            'gens': [h['g'] for h in host.pop_history],
            'nevals': [h['nevals'] for h in host.pop_history],
            'pop': [[[float(v) for v in x] for x in h['pop']]
                    for h in host.pop_history],
            'best_x': [float(v) for v in np.asarray(best_x)[:2]],
            'x_opt': ([float(v) for v in np.asarray(func.x_opt)[:2]]
                      if getattr(func, 'x_opt', None) is not None else None),
        }
    if controller is not None:
        st = controller.stats()
        # down-sample the intervention-rate curves to keep the files small
        st['rho_policy_curve'] = _downsample(st.get('rho_policy_curve', []), 50)
        st['rho_curve'] = _downsample(st.get('rho_curve', []), 50)
        rec['upcl'] = st
    return rec


def _downsample(seq, n):
    if not seq:
        return []
    a = np.asarray(seq, dtype=float)
    if len(a) <= n:
        return [float(v) for v in a]
    idx = np.linspace(0, len(a) - 1, n).astype(int)
    return [float(v) for v in a[idx]]


# ===========================================================================
# One task = (suite, dim, host, function) x all runs x all arms
# ===========================================================================
def _write_worker_status(status):
    """原子写入当前 worker 的实时状态；GUI 轮询此文件刷新 worker 视图。"""
    try:
        STATUS_DIR.mkdir(parents=True, exist_ok=True)
        _tmp = STATUS_DIR / f'w{os.getpid()}.tmp'
        with open(_tmp, 'w', encoding='utf-8') as fh:
            json.dump(status, fh)
        _tmp.replace(STATUS_DIR / f'w{os.getpid()}.json')
    except Exception:
        pass


def _append_done_log(status):
    """追加一条 cell 完成记录，GUI 读取以展示实验进度明细。"""
    try:
        STATUS_DIR.mkdir(parents=True, exist_ok=True)
        with open(STATUS_DIR / 'done.log', 'a', encoding='utf-8') as fh:
            fh.write(json.dumps(status, ensure_ascii=False) + '\n')
    except Exception:
        pass


def run_task(task):
    """Run one cell (host × function) for all requested runs/arms.

    Run-level resume: any already-complete run (same seed, every arm present)
    is reused, so an interrupted cell only re-runs the missing runs instead of
    the whole cell.  Each newly finished run is flushed atomically, so a crash
    or kill keeps every completed run.  Returns ``('skip'|'done'|'error',
    path)`` and never raises, so one bad cell cannot kill the worker pool.
    """
    suite, dim, host_name, fid = task['suite'], task['dim'], task['host'], task['fid']
    runs, arms, fes_mult = task['runs'], task['arms'], task['fes_mult']
    max_evals = fes_mult * dim
    seed_base = task.get('seed_base', SEED_BASE)

    # host names contain '/' (DE/rand/1): sanitise so the JSON files stay flat
    out_file = (OUT / 'raw' / suite / f'D{dim}'
                / f'{host_name.replace("/", "-")}__F{fid}.json')
    arm_names = [a for a, _ in arms]

    def _seed(r):
        return seed_base + dim * 1_000_003 + r * 7919 + fid * 31

    def _flush(per_run):
        ordered = sorted(per_run, key=lambda e: e.get('run', 0))
        payload = {
            'schema': SCHEMA_VERSION,
            'suite': suite, 'dim': dim, 'host': host_name, 'fid': fid,
            'func': func.name, 'category': func.category,
            'max_evals': int(max_evals), 'runs_complete': len(ordered),
            'arms': arm_names,
            'runs': ordered,
        }
        tmp = out_file.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh)
        tmp.replace(out_file)

    try:
        func = CS.get_function(suite, dim, fid)
        pop_size = DHC.pop_size_for(host_name, dim)
        out_file.parent.mkdir(parents=True, exist_ok=True)

        # ---- run-level resume: reuse complete, seed-matching runs ----------
        existing_runs = {}
        if out_file.exists() and not task.get('force'):
            try:
                with open(out_file, 'r', encoding='utf-8') as fh:
                    existing = migrate_payload(json.load(fh))
                if (existing.get('arms') == arm_names
                        and existing.get('host') == host_name):
                    for entry in existing.get('runs', []):
                        if not isinstance(entry, dict):
                            continue
                        rid = entry.get('run')
                        if (rid is not None
                                and entry.get('seed') == _seed(rid)
                                and all(a in entry for a in arm_names)):
                            existing_runs[rid] = entry
            except Exception:
                existing_runs = {}

        if len(existing_runs) >= runs:
            return ('skip', str(out_file))

        per_run = list(existing_runs.values())
        for r in range(runs):
            if r in existing_runs:
                continue
            seed = _seed(r)
            entry = {'run': r, 'seed': seed}
            for arm_label, cfg in arms:
                _write_worker_status({
                    'pid': os.getpid(), 'suite': suite, 'dim': dim,
                    'host': host_name, 'fid': fid, 'func': func.name,
                    'arm': arm_label, 'run': r + 1, 'runs': runs,
                    'status': 'running', 'updated': time.time(),
                })
                rec = run_arm(host_name, func, dim, seed, max_evals, cfg,
                              pop_size=pop_size)
                entry[arm_label] = rec
            per_run.append(entry)
            _flush(per_run)          # atomic flush after each completed run

        _done = {'pid': os.getpid(), 'suite': suite, 'dim': dim,
                 'host': host_name, 'fid': fid, 'func': func.name,
                 'status': 'done', 'updated': time.time()}
        _write_worker_status(_done)
        _append_done_log(_done)
        return ('done', str(out_file))
    except Exception as exc:
        return ('error', f'{out_file}: {exc!r}')


# ===========================================================================
# Task assembly
# ===========================================================================
def select(suite, dims, hosts, funcs, runs, ablation=False, upcl=True):
    dims = dims or list(CS.SUITE_DIMS[suite])
    host_list = DHC.CEC_HOST_ORDER if hosts is None else list(hosts)
    all_f = CS.get_suite(suite, dims[0])
    if funcs is None:
        fids = [f.fid for f in all_f]
    elif isinstance(funcs, str):
        fids = [f.fid for f in all_f if f.category == funcs]
    else:
        fids = [int(x) for x in funcs]
    if ablation:
        arms = list(ABLATION_ARMS)
    elif upcl:
        arms = [('bare', None), ('full', 'default')]
    else:
        arms = [('bare', None)]
    tasks = []
    for dim in dims:
        for h in host_list:
            # 黑盒插件不暴露内部种群，UPCL 无法介入，只跑 bare 臂做纯算法对比。
            h_arms = arms
            if getattr(de_hosts.HOST_REGISTRY.get(h), 'is_blackbox', False):
                h_arms = [('bare', None)]
            for fid in fids:
                tasks.append(dict(suite=suite, dim=dim, host=h, fid=fid,
                                  runs=runs, arms=h_arms, fes_mult=FES_MULT))
    return tasks


def build_tasks(args):
    stage = STAGES[args.stage]
    suites = args.suites or stage['suites']
    runs = args.runs or stage['runs']
    hosts = args.hosts
    if hosts is None:
        n = stage['hosts']
        hosts = (DHC.CEC_HOST_ORDER[:n] if n and n < len(DHC.CEC_HOST_ORDER)
                 else DHC.CEC_HOST_ORDER)
    funcs = args.funcs
    if funcs is None and stage['funcs']:
        all_f = CS.get_suite(suites[0], (args.dims or CS.SUITE_DIMS[suites[0]])[0])
        # spread the pilot over the four categories
        by_cat = {}
        for f in all_f:
            by_cat.setdefault(f.category, []).append(f.fid)
        pick = []
        i = 0
        while len(pick) < stage['funcs']:
            for c in ['unimodal', 'multimodal', 'hybrid', 'composite']:
                lst = by_cat.get(c, [])
                if i < len(lst):
                    pick.append(lst[i])
                if len(pick) >= stage['funcs']:
                    break
            i += 1
        funcs = sorted(pick)

    dims = args.dims
    tasks = []
    for suite in suites:
        d = dims or (CS.SUITE_DIMS[suite] if stage['dims'] is None
                     else stage['dims'])
        tasks.extend(select(suite, d, hosts, funcs, runs,
                            ablation=(args.exp == '4'),
                            upcl=not args.no_upcl))
    return tasks


def measured_run_cost():
    """Mean wall-clock of one run per (suite, dim, fid, arm), from the results.

    Extrapolating a plan from *measured* cells is far more reliable than
    calibrating on a single arbitrarily chosen cell: the per-run cost varies by
    more than an order of magnitude across the suite (a D=50 composite step
    costs tens of times a D=30 unimodal one).
    """
    out = {}
    for p in sorted((OUT / 'raw').glob('*/*/*.json')):
        try:
            with open(p, 'r', encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:                                     # pragma: no cover
            continue
        for run in d.get('runs', []):
            for arm, rec in run.items():
                if not isinstance(rec, dict) or 'wall_time_s' not in rec:
                    continue
                key = (d['suite'], d['dim'], d['fid'], arm)
                out.setdefault(key, []).append(float(rec['wall_time_s']))
    return {k: (float(np.mean(v)), len(v)) for k, v in out.items()}


def _calibrate(suite, dim, host, fids, fes_mult):
    """Time one run per arm on a few representative functions of a block.

    Cheap and expensive functions differ by an order of magnitude, so a
    representative sample (unimodal / hybrid / composite) is timed instead of
    a single cell.
    """
    costs = {}
    for fid in fids:
        func = CS.get_function(suite, dim, fid)
        for arm, cfg, key in (('bare', None, (suite, dim, fid, None)),
                              ('full', 'default', (suite, dim, fid, 'full'))):
            t0 = time.perf_counter()
            run_arm(host, func, dim, 1, fes_mult * dim, cfg)
            dt = time.perf_counter() - t0
            costs.setdefault(key, []).append(dt)
            print(f'    {func.label[:28]:<28s} {arm:>5s} {dt:7.1f} s/run')
    return {k: (float(np.mean(v)), len(v)) for k, v in costs.items()}


def estimate(args, tasks):
    """Project the CPU cost of ``tasks``; prints hours, returns nothing."""
    if not tasks:
        print('nothing to do')
        return
    meas = measured_run_cost()
    if meas:
        print(f'using the wall-clock of {len(meas)} already measured '
              f'(suite, dim, fid, arm) combinations')
    by_pair = {}
    for t in tasks:
        by_pair.setdefault((t['suite'], t['dim']), []).append(t)

    # per block: everything already measured, plus two anchors (the cheapest
    # unimodal function and the most expensive composite one) so that the
    # projection is never based on a single function-cost regime
    sample = {}
    for (suite, dim), ts in sorted(by_pair.items()):
        allf = CS.get_suite(suite, dim)
        by_cat = {}
        for f in allf:
            by_cat.setdefault(f.category, []).append(f.fid)
        need = [allf[0].fid]
        for c in ('composite', 'hybrid'):
            if by_cat.get(c):
                need.append(by_cat[c][-1])
                break
        fids_done = sorted({k[2] for k in meas if (k[0], k[1]) == (suite, dim)
                            and k[3] == 'full'})
        missing = [f for f in need if f not in fids_done]
        print(f'  {suite} D={dim}: {len(fids_done)} functions already measured'
              + (f', calibrating on {missing}' if missing else ''))
        if missing:
            for (s, d, fid, arm), (m, n) in _calibrate(
                    suite, dim, ts[0]['host'], missing,
                    ts[0]['fes_mult']).items():
                meas[(s, d, fid, 'full' if arm else 'bare')] = (m, n)
        sample[(suite, dim)] = sorted(set(fids_done) | set(need))

    total = 0.0
    print(f'\n{"cell block":<24s}{"funcs":>7s}{"cells":>7s}{"runs":>7s}'
          f'{"s/run":>9s}{"CPU-hours":>12s}')
    for (suite, dim), ts in sorted(by_pair.items()):
        arms = ts[0]['arms']
        allf = CS.get_suite(suite, dim)
        # per-category cost measured from the sample
        cat_cost = {}
        for fid in sample[(suite, dim)]:
            cat = CS.get_function(suite, dim, fid).category
            c = 0.0
            for arm, cfg in arms:
                key = (suite, dim, fid, 'full' if cfg else 'bare')
                c += meas.get(key, meas.get((suite, dim, fid, 'full'),
                                            (60.0, 0)))[0]
            cat_cost.setdefault(cat, []).append(c)
        cat_mean = {k: float(np.mean(v)) for k, v in cat_cost.items()}
        glob = float(np.mean(list(cat_mean.values()))) if cat_mean else 60.0
        # weight by the real function mix of the block
        per_run = float(np.mean([cat_mean.get(f.category, glob) for f in allf]))
        nruns = sum(t['runs'] for t in ts)
        hrs = per_run * nruns / 3600.0
        total += hrs
        print(f'{suite + " D=" + str(dim):<24s}{len(allf):>7d}{len(ts):>7d}'
              f'{nruns:>7d}{per_run:>9.1f}{hrs:>12,.1f}')
    print(f'{"total":<24s}{"":>7s}{len(tasks):>7d}'
          f'{sum(t["runs"] for t in tasks):>7d}{"":>9s}{total:>12,.1f}')
    print(f'~{total / max(args.workers, 1):,.1f} h wall on {args.workers} '
          f'workers ({total / max(args.workers, 1) / 24:,.1f} days)')


# ===========================================================================
# Entry point
# ===========================================================================
def main(argv=None):
    global SEED_BASE
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--stage', default='smoke', choices=list(STAGES))
    ap.add_argument('--exp', default=None, help='1..6 or 4 for the ablation')
    ap.add_argument('--suites', nargs='*', default=None)
    ap.add_argument('--dims', nargs='*', type=int, default=None)
    ap.add_argument('--hosts', nargs='*', default=None)
    ap.add_argument('--funcs', nargs='*', default=None,
                    help='function ids, or a category name')
    ap.add_argument('--runs', type=int, default=None)
    ap.add_argument('--evals-mult', type=int, default=FES_MULT)
    ap.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 4) - 2))
    ap.add_argument('--force', action='store_true')
    ap.add_argument('--resume', action='store_true', default=True)
    ap.add_argument('--estimate', action='store_true')
    ap.add_argument('--analyze-only', action='store_true')
    ap.add_argument('--seed', type=int, default=SEED_BASE)
    ap.add_argument('--no-upcl', action='store_true',
                    help='run the bare hosts only (skip the UPCL arm)')
    args = ap.parse_args(argv)
    SEED_BASE = args.seed

    if args.analyze_only:
        importlib.import_module('analyze_upcl_cec').run_all(
            args.suites or ['cec2017', 'cec2022'])
        return

    tasks = build_tasks(args)
    for t in tasks:
        t['fes_mult'] = args.evals_mult
        t['force'] = args.force
        t['seed_base'] = args.seed
    rng = np.random.default_rng(0)
    rng.shuffle(tasks)          # long LPSR cells do not cluster on one worker

    print(f'{len(tasks)} cells  ({len(set((t["host"], t["dim"], t["suite"]) for t in tasks))}'
          f' host x dim x suite combinations, '
          f'{tasks[0]["runs"] if tasks else 0} runs, '
          f'{len(tasks[0]["arms"]) if tasks else 0} arms)')

    if args.estimate:
        estimate(args, tasks)
        return

    OUT.mkdir(parents=True, exist_ok=True)
    # 清空上一次运行的 worker 实时状态与完成记录，避免 GUI 误读残留
    STATUS_DIR.mkdir(parents=True, exist_ok=True)
    for _f in STATUS_DIR.glob('w*.json'):
        try:
            _f.unlink()
        except OSError:
            pass
    try:
        (STATUS_DIR / 'done.log').unlink()
    except OSError:
        pass
    if PAUSE_FILE.exists():
        print('[pause] pause marker present — exiting without running any cell. '
              'Delete results/cec/.pause to resume.', flush=True)
        return
    try:
        STOP_FILE.unlink()          # clear any stale stop marker
    except FileNotFoundError:
        pass
    t_start = time.time()
    total = len(tasks)
    results = []

    # 每 5 秒打印一次百分比进度（daemon 线程），取代逐 cell 刷屏。
    state = {'done': 0, 'skip': 0, 'error': 0}
    state_lock = threading.Lock()
    stop_progress = threading.Event()

    def progress_pct():
        with state_lock:
            done, skip = state['done'], state['skip']
            err = state['error']
        finished = done + skip + err
        pct = finished / total * 100.0 if total else 0.0
        el = time.time() - t_start
        eta = el / max(finished, 1) * (total - finished)
        return (f'  {finished}/{total}  ({pct:.1f}%)  '
                f'elapsed {el/60:.1f} min  eta {eta/60:.1f} min')

    def progress_loop():
        print(progress_pct(), flush=True)          # 启动即打印 0% 基线
        while not stop_progress.wait(5.0):
            print(progress_pct(), flush=True)

    threading.Thread(target=progress_loop, daemon=True).start()

    def record(res):
        results.append(res)
        with state_lock:
            state[res[0]] = state.get(res[0], 0) + 1
        if res[0] == 'error':
            print(f'[error] cell failed: {res[1]}', flush=True)

    if args.workers <= 1:
        for t in tasks:
            if STOP_FILE.exists():
                print('[stop] stop marker present — halting (remaining cells '
                      'will resume on the next launch)', flush=True)
                break
            record(run_task(t))
    else:
        import multiprocessing as mp

        # Windows 用 spawn，worker 拉起可能偶发 PermissionError(WinError 5)；
        # 建池失败时退避重试，避免整个任务因一次 spawn 抖动而中断。
        def _make_pool():
            last = None
            for attempt in range(3):
                try:
                    return mp.Pool(processes=args.workers)
                except Exception as exc:
                    last = exc
                    print(f'[warn] worker pool spawn failed '
                          f'(attempt {attempt + 1}/3): {exc}', flush=True)
                    time.sleep(2 * (attempt + 1))
            raise last

        pool = _make_pool()
        try:
            pending = []
            it = iter(tasks)
            for _ in range(args.workers):
                t = next(it, None)
                if t is None:
                    break
                try:
                    pending.append(pool.apply_async(run_task, (t,)))
                except Exception as exc:
                    record(('error', f'submit: {exc!r}'))
            stopped = False
            while pending:
                while not any(p.ready() for p in pending):
                    if not stopped and STOP_FILE.exists():
                        stopped = True
                        print('[stop] stop requested — no new cells will start; '
                              'waiting for in-flight cells...', flush=True)
                    time.sleep(0.1)
                for p in pending:
                    if p.ready():
                        try:
                            record(p.get())
                        except Exception as exc:
                            # worker 异常退出等：记为该 cell 失败，不中断全局
                            record(('error', f'worker result: {exc!r}'))
                pending = [p for p in pending if not p.ready()]
                if not (stopped or STOP_FILE.exists()):
                    while len(pending) < args.workers:
                        t = next(it, None)
                        if t is None:
                            break
                        try:
                            pending.append(pool.apply_async(run_task, (t,)))
                        except Exception as exc:
                            record(('error', f'submit: {exc!r}'))
        finally:
            pool.close()
            pool.join()
    stop_progress.set()
    print(f'finished in {(time.time() - t_start) / 60:.1f} min: '
          f'{sum(1 for r in results if r[0] == "done")} written, '
          f'{sum(1 for r in results if r[0] == "skip")} already present, '
          f'{sum(1 for r in results if r[0] == "error")} failed')

    if not args.no_upcl and not getattr(sys, 'frozen', False):
        try:
            importlib.import_module('analyze_upcl_cec').run_all(
                args.suites or [t['suite'] for t in [tasks[0]]] or
                ['cec2017', 'cec2022'])
        except Exception as exc:                   # analysis must not lose data
            print(f'[warn] analysis failed: {exc}')


if __name__ == '__main__':
    main()

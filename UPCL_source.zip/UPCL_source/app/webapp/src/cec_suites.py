# -*- coding: utf-8 -*-
"""IEEE CEC 2017 and CEC 2022 single-objective bound-constrained suites.

Provenance
----------
The composition tables below (which base functions enter each hybrid and
composite function, the dimension proportions ``p``, the ``sigma`` and
``lambda`` lists and the bias values) are transcribed from the published
suite definitions as exposed by the opfunu reference implementation.

Shift vectors, rotation matrices and shuffle permutations are the one part of
the suites that ships as *data* files (``shift_data_*.txt``, ``M_*_D*.txt``,
``shuffle_data_*_D*.txt``) rather than as formulas.  Those files are not in
this repository.  Two consequences, both of which must be stated in the
paper:

1.  When ``data/cec2017`` (resp. ``data/cec2022``) holds the official files,
    they are loaded and the functions are the official ones.  Otherwise the
    script falls back to deterministically generated data, seeded by
    ``(suite, function id, dimension)``: uniform shifts in ``[-80, 80]^D``,
    orthogonal matrices from a QR decomposition, random permutations.
2.  Absolute error values produced in fallback mode are therefore NOT
    comparable with published CEC leaderboards.  Every experiment in this
    project is a *paired* comparison of a bare host H against H+UPCL on the
    same function, same dimension, same seed and same budget, and that
    comparison is invariant to the particular rotation and shift used.

Self-consistent optimum
-----------------------
Every function is normalised so that ``f(o) = bias`` exactly, where ``o`` is
the shift vector and ``bias`` the published optimum value.  Several base
operators (Lunacek bi-Rastrigin, HGBat, HappyCat, Katsuura) do not vanish at
the origin in the form used by the suites; the constructor evaluates the raw
operator at the origin once and subtracts it.  Without this the reported
error ``f(x) - f*`` could be negative, which would silently corrupt every
convergence plot and every log-scale statistic.
"""
import hashlib
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA_DIRS = {'cec2017': ROOT / 'data' / 'cec2017',
             'cec2022': ROOT / 'data' / 'cec2022',
             'cec2015': ROOT / 'data' / 'cec2015',
             'cec2014': ROOT / 'data' / 'cec2014',
             'cec2013': ROOT / 'data' / 'cec2013'}

_WARNED = set()


# ===========================================================================
# Deterministic surrogate data
# ===========================================================================
def _rng(tag):
    """Stable across processes: hash() is salted, md5 is not."""
    return np.random.default_rng(
        int.from_bytes(hashlib.md5(tag.encode('utf-8')).digest()[:8], 'big'))


def _orthogonal(dim, tag):
    """Orthogonal matrix (condition number 1), det = +1."""
    a = _rng(tag).standard_normal((dim, dim))
    q, r = np.linalg.qr(a)
    return q @ np.diag(np.sign(np.diag(r)))


def _shift(n_rows, dim, tag):
    """CEC convention: the shifted optimum lies inside [-80, 80]^D."""
    return _rng(tag).uniform(-80.0, 80.0, size=(n_rows, dim))


def _shuffle(dim, tag):
    return _rng(tag).permutation(dim)


def _official(suite, name, dim):
    """Best-effort loader for the official data files (opfunu naming)."""
    d = DATA_DIRS.get(suite)
    if d is None or not d.is_dir():
        return None
    p = d / name
    if p.suffix != '.txt':
        p = p.with_suffix('.txt')
    if not p.exists():
        # opfunu keeps dimension-specific matrix files, e.g. M_1_D30.txt
        alt = d / f"{name}_D{dim}.txt"
        if alt.exists():
            p = alt
        else:
            return None
    try:
        return np.loadtxt(p)
    except Exception:
        return None


def _warn_once(key, msg):
    if key not in _WARNED:
        _WARNED.add(key)
        print(f'[CEC] {msg}')


# ===========================================================================
# Base operators
# ===========================================================================
def sphere(z):
    return np.sum(z ** 2)


def different_powers(z):
    n = len(z)
    i = np.arange(1.0, n + 1.0)
    return np.sqrt(np.sum(np.abs(z) ** (2.0 + 4.0 * (i - 1.0) / (n - 1.0))))


def bent_cigar(z):
    return z[0] ** 2 + 1e6 * np.sum(z[1:] ** 2)


def zakharov(z):
    i = np.arange(1, len(z) + 1)
    s = np.sum(0.5 * i * z)
    return np.sum(z ** 2) + s ** 2 + s ** 4


def rosenbrock(z):
    return np.sum(100.0 * (z[:-1] ** 2 - z[1:]) ** 2 + (z[:-1] - 1.0) ** 2)


def rastrigin(z):
    return np.sum(z ** 2 - 10.0 * np.cos(2.0 * np.pi * z) + 10.0)


def schaffer_f7(z):
    s = np.sqrt(z[:-1] ** 2 + z[1:] ** 2)
    t = np.sqrt(s) * (np.sin(50.0 * s ** 0.2) ** 2 + 1.0)
    return (np.sum(t) / (len(z) - 1.0)) ** 2


def lunacek_bi_rastrigin(z, miu0=2.5, d=1.0):
    n = len(z)
    s = 1.0 - 1.0 / (2.0 * np.sqrt(n + 20.0) - 8.2)
    miu1 = -np.sqrt((miu0 ** 2 - d) / s)
    xhat = 2.0 * np.sign(miu0) * z
    t1 = np.sum((xhat - miu0) ** 2)
    t2 = d * n + s * np.sum((xhat - miu1) ** 2)
    t3 = 10.0 * (n - np.sum(np.cos(2.0 * np.pi * (xhat - miu0))))
    return min(t1, t2) + t3


def non_continuous_rastrigin(z):
    y = np.where(np.abs(z) > 0.5, np.round(2.0 * z) / 2.0, z)
    return np.sum(y ** 2 - 10.0 * np.cos(2.0 * np.pi * y) + 10.0)


def levy(z):
    w = 1.0 + (z - 1.0) / 4.0
    t = np.sin(np.pi * w[0]) ** 2
    t += np.sum((w[:-1] - 1.0) ** 2
                * (1.0 + 10.0 * np.sin(np.pi * w[:-1] + 1.0) ** 2))
    t += (w[-1] - 1.0) ** 2 * (1.0 + np.sin(2.0 * np.pi * w[-1]) ** 2)
    return t


def modified_schwefel(z):
    n = len(z)
    z = z + 4.209687462275036e+002
    hi = z > 500.0
    lo = z < -500.0
    mid = ~(hi | lo)
    out = np.zeros_like(z)
    zh = 500.0 - np.mod(z[hi], 500.0)
    out[hi] = zh * np.sin(np.sqrt(np.abs(zh))) - (z[hi] - 500.0) ** 2 / (1e4 * n)
    zl = np.mod(np.abs(z[lo]), 500.0) - 500.0
    out[lo] = zl * np.sin(np.sqrt(np.abs(zl))) - (z[lo] + 500.0) ** 2 / (1e4 * n)
    out[mid] = z[mid] * np.sin(np.sqrt(np.abs(z[mid])))
    return 418.9828872724338 * n - np.sum(out)


def elliptic(z):
    n = len(z)
    return np.sum((1e6 ** (np.arange(n) / max(n - 1, 1))) * z ** 2)


def ackley(z):
    n = len(z)
    return (-20.0 * np.exp(-0.2 * np.sqrt(np.sum(z ** 2) / n))
            - np.exp(np.sum(np.cos(2.0 * np.pi * z)) / n) + 20.0 + np.e)


def griewank(z):
    i = np.arange(1, len(z) + 1)
    return np.sum(z ** 2) / 4000.0 - np.prod(np.cos(z / np.sqrt(i))) + 1.0


def discus(z):
    return 1e6 * z[0] ** 2 + np.sum(z[1:] ** 2)


def happy_cat(z):
    """z is already offset by -1 by the caller (suite uses shift = -1)."""
    n = len(z)
    s = np.sum(z ** 2)
    return np.abs(s - n) ** 0.5 + (0.5 * s + np.sum(z)) / n + 0.5


def hgbat(z):
    n = len(z)
    s = np.sum(z ** 2)
    return (np.abs(s ** 2 - np.sum(z) ** 2) ** 0.5
            + (0.5 * s + np.sum(z)) / n + 0.5)


def katsuura(z):
    n = len(z)
    k = np.arange(1, 33)
    # (n, 32) table of |2^k z_i - round(2^k z_i)| / 2^k
    t = np.abs(2.0 ** k * z[:, None] - np.round(2.0 ** k * z[:, None])) / (2.0 ** k)
    inner = 1.0 + (np.arange(1, n + 1)[:, None] * t).sum(axis=1)
    return (10.0 / n ** 2) * np.prod(inner ** (10.0 / n ** 1.2)) - 10.0 / n ** 2


def weierstrass_norm(z, a=0.5, b=3.0, kmax=20):
    k = np.arange(kmax + 1)
    ak, bk = a ** k, b ** k
    s1 = np.sum(ak[:, None] * np.cos(2.0 * np.pi * bk[:, None]
                                     * (z[None, :] + 0.5)), axis=0)
    s2 = np.sum(ak * np.cos(2.0 * np.pi * bk * 0.5))
    return np.sum(s1) - len(z) * s2


def expanded_scaffer_f6(z):
    x, y = z, np.roll(z, -1)
    s = x ** 2 + y ** 2
    return np.sum(0.5 + (np.sin(np.sqrt(s)) ** 2 - 0.5) / (1.0 + 0.001 * s) ** 2)


rotated_expanded_schaffer = expanded_scaffer_f6


def _grie_rosen(z):
    """Expanded Griewank + Rosenbrock (grie_rosen in the CEC sources)."""
    x, y = z, np.roll(z, -1)
    tmp = 100.0 * (x ** 2 - y) ** 2 + (x - 1.0) ** 2
    i = np.arange(1, len(tmp) + 1)
    return np.sum(tmp ** 2) / 4000.0 - np.prod(np.cos(tmp / np.sqrt(i))) + 1.0


def expanded_griewank_rosenbrock(z):
    return _grie_rosen(z + 1.0)


grie_rosen_cec = expanded_griewank_rosenbrock


def calculate_weight(z, sigma):
    """Composition weight of the CEC suites.

    The published definition contains the reciprocal-distance factor

        w_i = 1 / ||x - o_i|| * exp(-||x - o_i||^2 / (2 D sigma_i^2)),

    which makes the composition locally dominated by the nearest component.
    Dropping it (a common transcription error) flattens the composition and
    moves its minimum away from the shift vectors, which shows up as a
    *negative* error f(x) - f* and corrupts every log-scale statistic.  The
    singular case ||x - o_i|| = 0 is given a large finite weight (the C
    sources use infinity) so that the normalisation stays finite.
    """
    d2 = float(np.sum(z ** 2))
    if d2 <= 1e-300:
        return 1e30
    return float(np.exp(-d2 / (2.0 * len(z) * sigma ** 2)) / np.sqrt(d2))


# ===========================================================================
# CEC 2013 support transforms (transcribed from opfunu operator.py)
# ===========================================================================
def _tosz(z):
    """CEC2013 ``tosz`` transform, applied to the first and last components."""
    def _trans(xi):
        if xi > 0:
            c1, c2, x_sign = 10.0, 7.9, 1.0
            x_star = np.log(np.abs(xi))
        elif xi == 0:
            c1, c2, x_sign, x_star = 5.5, 3.1, 0.0, 0.0
        else:
            c1, c2, x_sign = 5.5, 3.1, -1.0
            x_star = np.log(np.abs(xi))
        return x_sign * np.exp(x_star + 0.049
                               * (np.sin(c1 * x_star) + np.sin(c2 * x_star)))
    z = np.asarray(z, dtype=float).copy()
    z[0] = _trans(z[0])
    z[-1] = _trans(z[-1])
    return z


def _tasy(z, beta=0.5):
    """CEC2013 ``tasy`` asymmetric transform."""
    z = np.asarray(z, dtype=float)
    ndim = len(z)
    idx = np.arange(0, ndim)
    with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
        up = 1.0 + beta * ((idx - 1.0) / (ndim - 1.0)) * np.sqrt(np.abs(z))
        x_temp = np.abs(z) ** up
    return np.where(z > 0, x_temp, z)


def _rounder(x, condition):
    """CEC2013 ``rounder`` non-continuous transform."""
    x = np.asarray(x, dtype=float)
    temp_2x = 2.0 * x
    dec, inter = np.modf(temp_2x)
    temp_2x = np.where(temp_2x <= 0.0, inter - (dec >= 0.5), temp_2x)
    temp_2x = np.where(dec < 0.5, inter, temp_2x)
    temp_2x = np.where(dec >= 0.5, inter + 1.0, temp_2x)
    return np.where(condition < 0.5, x, temp_2x / 2.0)


def _diag_alpha(size, alpha=10.0):
    """Diagonal matrix diag(alpha^(i/(2(size-1))))."""
    idx = np.arange(0, size)
    return np.diag(alpha ** (idx / (2.0 * (size - 1.0))))


def _lunacek_shift(z, miu0=2.5, d=1.0, shift=0.0):
    """Lunacek bi-Rastrigin with an additive ``shift`` (opfunu F17/F18)."""
    x = np.asarray(z, dtype=float) + shift
    ndim = len(x)
    s = 1.0 - 1.0 / (2.0 * np.sqrt(ndim + 20.0) - 8.2)
    miu1 = -np.sqrt((miu0 ** 2 - d) / s)
    delta = x - miu0
    term1 = np.sum(delta ** 2)
    term2 = np.sum((x - miu1) ** 2) * s + d * ndim
    return min(term1, term2) + 10.0 * (ndim - np.sum(np.cos(2.0 * np.pi * delta)))


def _grie_rosen_cec2013(z):
    """Expanded Griewank+Rosenbrock exactly as in opfunu (CEC2013 F19)."""
    z = np.asarray(z, dtype=float) + 1.0
    tmp1 = (z[:-1] ** 2 - z[1:]) ** 2
    tmp2 = (z[:-1] - 1.0) ** 2
    temp = 100.0 * tmp1 + tmp2
    f = np.sum(temp ** 2 / 4000.0 - np.cos(temp) + 1.0)
    t1 = (z[-1] ** 2 - z[0]) ** 2
    t2 = (z[-1] - 1.0) ** 2
    temp = 100.0 * t1 + t2
    f += temp ** 2 / 4000.0 - np.cos(temp) + 1.0
    return f


def _schaffer_f7_c13(z):
    """Schaffer F7 as CEC2013 defines it (no (n-1) normalisation)."""
    s = np.sqrt(z[:-1] ** 2 + z[1:] ** 2)
    result = np.sum(np.sqrt(s) * (1.0 + np.sin(50.0 * s ** 0.2) ** 2))
    return result ** 2


# ===========================================================================
# Function object
# ===========================================================================
class CECFunction:
    """One suite function: x -> f(x), with f(o) = bias."""

    def __init__(self, suite, fid, name, category, dim,
                 evaluate_raw, bias=0.0, x_opt=None, lb=-100.0, ub=100.0):
        self.suite = suite
        self.fid = fid                    # official id (CEC2017: 1,3..30)
        self.name = name
        self.category = category          # unimodal / multimodal / hybrid / composite
        self.dim = dim
        self.bias = float(bias)
        self.lb = float(lb)
        self.ub = float(ub)
        self._raw = evaluate_raw
        # x_opt may be a single point or a stack of candidate optima; for
        # composite functions the composition is minimised near one of the
        # component shift vectors, and which one is cheapest has to be checked
        # rather than assumed.
        cand = (np.zeros((1, dim)) if x_opt is None
                else np.atleast_2d(np.asarray(x_opt, dtype=float)))
        vals = [float(evaluate_raw(c)) for c in cand]
        self.x_opt = cand[int(np.argmin(vals))]
        # normalise so that f(x_opt) = bias exactly (see module docstring)
        self.offset = float(min(vals))
        self.f_opt = self.bias

    def __call__(self, x):
        return float(self._raw(np.asarray(x, dtype=float)) - self.offset
                     + self.bias)

    def error(self, x):
        return self(x) - self.f_opt

    @property
    def label(self):
        return f'F{self.fid}'

    def __repr__(self):
        return f'<CEC {self.suite} {self.label} {self.name} D={self.dim}>'


# ===========================================================================
# Suite construction helpers
# ===========================================================================
def _split_dims(dim, p, shuffle):
    """Partition shuffled dimension indices according to proportions p."""
    idx, out, start = [], [], 0
    for k, frac in enumerate(p):
        n_k = int(np.ceil(frac * dim))
        out.append(np.sort(shuffle[start:start + n_k]))
        start += n_k
    out[-1] = np.sort(shuffle[start:]) if start < dim else out[-1]
    return out


def _make_simple(suite, fid, name, category, dim, op, scale=None, bias=0.0,
                 add=0.0, rotate=True):
    """Shifted (and, unless rotate=False, rotated) single-operator function."""
    tag = f'{suite}_{fid}_{dim}'
    o = _official(suite, f'shift_data_{fid}', dim)
    if o is None:
        o = _shift(1, dim, tag + '_shift')[0]
    else:
        o = np.asarray(o)[:dim]
    m = _official(suite, f'M_{fid}', dim)
    if m is None:
        m = _orthogonal(dim, tag + '_M')
        _warn_once(suite, f'{suite}: official data files absent in '
                          f'{DATA_DIRS[suite]}; using deterministic '
                          f'shifts/rotations (paired comparisons unaffected).')
    else:
        m = np.asarray(m).reshape(dim, dim)

    def raw(x):
        z = x - o
        if scale is not None:
            z = scale * z
        if rotate:
            z = m @ z
        return op(z + add)

    return CECFunction(suite, fid, name, category, dim, raw, bias=bias,
                       x_opt=o)


def _make_hybrid(suite, fid, name, dim, parts, p, bias, shuffle_then_rotate,
                 shift=None):
    """parts: list of callables applied to the sub-vectors of the rotated z."""
    tag = f'{suite}_{fid}_{dim}'
    if shift is not None:
        o = np.asarray(shift, dtype=float)
    else:
        o = _official(suite, f'shift_data_{fid}', dim)
        o = _shift(1, dim, tag + '_shift')[0] if o is None else np.asarray(o)[:dim]
    m = _official(suite, f'M_{fid}', dim)
    m = _orthogonal(dim, tag + '_M') if m is None else np.asarray(m).reshape(dim, dim)
    sh = _official(suite, f'shuffle_data_{fid}', dim)
    if sh is None:
        sh = _shuffle(dim, tag + '_shuffle')
    else:
        sh = (np.asarray(sh, dtype=int) - 1)[:dim]
    groups = _split_dims(dim, p, sh)

    def raw(x):
        z = x - o
        if shuffle_then_rotate:
            z = m @ np.concatenate([z[g] for g in groups])
        else:
            z = m @ z
        return float(sum(op(z[g]) for op, g in zip(parts, groups)))

    return CECFunction(suite, fid, name, 'hybrid', dim, raw, bias=bias,
                       x_opt=o)


def _make_composite(suite, fid, name, dim, comps, sigmas, lams, cbias,
                    bias, use_first_shift=False):
    """comps: list of dicts with keys op / scale / add / raw / rotate / m_fid.

    ``raw=True`` evaluates the component on ``x`` directly (no shift, no
    rotation, no scale).  ``rotate=False`` skips rotation.  ``m_fid=k`` uses
    the rotation matrix of base function k instead of this composition's own
    k-th block (CEC2014 F24-F27 reuse the base functions' matrices).
    """
    n = len(comps)
    tag = f'{suite}_{fid}_{dim}'
    o = _official(suite, f'shift_data_{fid}', dim)
    if o is None:
        o = _shift(n, dim, tag + '_shift')
    else:
        o = np.asarray(o).reshape(-1, dim)[:n]
    m = _official(suite, f'M_{fid}', dim)
    m = np.asarray(m).reshape(-1, dim)[:n * dim] if m is not None else None
    mats = []
    for k, c in enumerate(comps):
        mf = c.get('m_fid')
        if mf is not None:
            mm = _official(suite, f'M_{mf}', dim)
            mats.append(_orthogonal(dim, tag + f'_M{mf}') if mm is None
                        else np.asarray(mm).reshape(dim, dim))
        elif m is not None:
            mats.append(m[k * dim:(k + 1) * dim])
        else:
            mats.append(_orthogonal(dim, tag + f'_M{k}'))

    def raw(x):
        gs, ws = [], []
        for k, c in enumerate(comps):
            if c.get('raw'):
                gs.append(lams[k] * c['op'](x) + cbias[k])
            else:
                z = x - (o[0] if use_first_shift else o[k])
                if c.get('scale') is not None:
                    z = c['scale'] * z
                if c.get('rotate', True):
                    z = mats[k] @ z
                gs.append(lams[k] * c['op'](z + c.get('add', 0.0)) + cbias[k])
            ws.append(calculate_weight(x - o[k], sigmas[k]))
        ws = np.asarray(ws)
        ws = ws / np.sum(ws)
        return float(np.dot(ws, np.asarray(gs)))

    # the composition is minimised near one of the component shift vectors;
    # which one is decided by CECFunction
    return CECFunction(suite, fid, name, 'composite', dim, raw, bias=bias,
                       x_opt=o)


def _make_hybrid_composite(suite, fid, name, dim, kids, sigmas, lams,
                           cbias, bias):
    """Composition whose components are themselves hybrid functions.

    ``kids`` are opfunu indices of the hybrid components.  Each component is
    rebuilt with the composition's own shift row as its shift vector.
    """
    n = len(kids)
    tag = f'{suite}_{fid}_{dim}'
    o = _shift(n, dim, tag + '_shift')
    # the component hybrids share the shift rows of the composition, so that
    # component k is minimised at o[k] -- this is how the suite is constructed
    # and without it the reported optimum of the composition is meaningless
    hybrids = [get_cec2017_hybrid(dim, k, shift=o[i])
               for i, k in enumerate(kids)]

    def raw(x):
        gs, ws = [], []
        for k, h in enumerate(hybrids):
            gs.append(lams[k] * h(x) + cbias[k])
            ws.append(calculate_weight(x - o[k], sigmas[k]))
        ws = np.asarray(ws)
        return float(np.dot(ws / np.sum(ws), np.asarray(gs)))

    return CECFunction(suite, fid, name, 'composite', dim, raw, bias=bias,
                       x_opt=o)


# ===========================================================================
# CEC 2017  (29 functions: F1, F3 ... F30 -- the original F2 was withdrawn)
# ===========================================================================
# opfunu index k  ->  official id  k+1  for k >= 2
_CEC2017_HYBRIDS = {
    10: ('Hybrid 1', [zakharov, lambda z: rosenbrock(z + 1.0), rastrigin],
         [0.2, 0.4, 0.4]),
    11: ('Hybrid 2', [elliptic, modified_schwefel, bent_cigar],
         [0.3, 0.3, 0.4]),
    12: ('Hybrid 3', [bent_cigar, lambda z: rosenbrock(z + 1.0),
                      lunacek_bi_rastrigin], [0.3, 0.3, 0.4]),
    13: ('Hybrid 4', [elliptic, ackley, schaffer_f7, rastrigin],
         [0.2, 0.2, 0.2, 0.4]),
    14: ('Hybrid 5', [bent_cigar, hgbat, rastrigin,
                      lambda z: rosenbrock(z + 1.0)], [0.2, 0.2, 0.3, 0.3]),
    15: ('Hybrid 6', [expanded_scaffer_f6, hgbat,
                      lambda z: rosenbrock(z + 1.0), modified_schwefel],
         [0.2, 0.2, 0.3, 0.3]),
    16: ('Hybrid 7', [katsuura, ackley, expanded_griewank_rosenbrock,
                      modified_schwefel, rastrigin], [0.1, 0.2, 0.2, 0.2, 0.3]),
    17: ('Hybrid 8', [elliptic, ackley, rastrigin, hgbat, discus],
         [0.2, 0.2, 0.2, 0.2, 0.2]),
    18: ('Hybrid 9', [bent_cigar, rastrigin, expanded_griewank_rosenbrock,
                      weierstrass_norm, expanded_scaffer_f6],
         [0.2, 0.2, 0.2, 0.2, 0.2]),
    19: ('Hybrid 10', [happy_cat, katsuura, ackley, rastrigin,
                       modified_schwefel, schaffer_f7],
         [0.1, 0.1, 0.2, 0.2, 0.2, 0.2]),
}

_CEC2017_COMPOSITES = {
    20: ('Composition 1',
         [dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
          dict(op=elliptic), dict(op=rastrigin)],
         [10, 20, 30], [1.0, 1e-6, 1.0]),
    21: ('Composition 2',
         [dict(op=rastrigin), dict(op=griewank),
          dict(op=modified_schwefel, scale=1000.0 / 100)],
         [10, 20, 30], [1.0, 10.0, 1.0]),
    22: ('Composition 3',
         [dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
          dict(op=ackley), dict(op=modified_schwefel), dict(op=rastrigin)],
         [10, 20, 30, 40], [1.0, 10.0, 1.0, 1.0]),
    23: ('Composition 4',
         [dict(op=ackley), dict(op=elliptic), dict(op=griewank),
          dict(op=rastrigin)],
         [10, 20, 30, 40], [10.0, 1e-6, 10.0, 1.0]),
    24: ('Composition 5',
         [dict(op=rastrigin), dict(op=happy_cat, add=-1.0), dict(op=ackley),
          dict(op=discus), dict(op=lambda z: rosenbrock(z + 1.0),
                                scale=2.048 / 100)],
         [10, 20, 30, 40, 50], [10.0, 1.0, 10.0, 1e-6, 1.0]),
    25: ('Composition 6',
         [dict(op=expanded_scaffer_f6, add=1.0),
          dict(op=modified_schwefel, scale=1000.0 / 100),
          dict(op=griewank, scale=600.0 / 100),
          dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
          dict(op=rastrigin)],
         [10, 20, 20, 30, 40], [1e-26, 10.0, 1e-6, 10.0, 5e-4]),
    26: ('Composition 7',
         [dict(op=hgbat, scale=5.0 / 100, add=-1.0),
          dict(op=rastrigin, scale=5.12 / 100),
          dict(op=modified_schwefel, scale=1000.0 / 100),
          dict(op=bent_cigar), dict(op=elliptic),
          dict(op=expanded_scaffer_f6, add=1.0)],
         [10, 20, 30, 40, 50, 60], [10.0, 10.0, 2.5, 1e-26, 1e-6, 5e-4]),
    27: ('Composition 8',
         [dict(op=ackley), dict(op=griewank, scale=600.0 / 100),
          dict(op=discus),
          dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
          dict(op=happy_cat, scale=5.0 / 100, add=-1.0),
          dict(op=expanded_scaffer_f6, add=1.0)],
         [10, 20, 30, 40, 50, 60], [10.0, 10.0, 1e-6, 1.0, 1.0, 5e-4]),
}

_CEC2017_SIMPLE = [
    (1, 'Shifted and Rotated Bent Cigar', 'unimodal', bent_cigar, None, 0.0),
    (2, 'Shifted and Rotated Zakharov', 'unimodal', zakharov, None, 0.0),
    (3, "Shifted and Rotated Rosenbrock", 'multimodal', rosenbrock,
     2.048 / 100, 1.0),
    (4, "Shifted and Rotated Rastrigin", 'multimodal', rastrigin, None, 0.0),
    (5, "Expanded Schaffer's F7", 'multimodal', schaffer_f7, 0.5 / 100, 0.0),
    (6, 'Lunacek Bi-Rastrigin', 'multimodal', lunacek_bi_rastrigin,
     600.0 / 100, 0.0),
    (7, 'Non-Continuous Rastrigin', 'multimodal', non_continuous_rastrigin,
     5.12 / 100, 0.0),
    (8, 'Levy', 'multimodal', levy, 5.12 / 100, 0.0),
    (9, 'Modified Schwefel', 'multimodal', modified_schwefel,
     1000.0 / 100, 0.0),
]


def get_cec2017(dim=30):
    suite, out = 'cec2017', []
    for k, name, cat, op, scale, add in _CEC2017_SIMPLE:
        fid = k if k == 1 else k + 1          # official id skips F2
        out.append(_make_simple(suite, fid, name, cat, dim, op,
                                scale=scale, bias=100.0 * fid, add=add))
    for k, (name, ops, p) in _CEC2017_HYBRIDS.items():
        fid = k + 1
        out.append(_make_hybrid(suite, fid, name, dim, ops, p,
                                100.0 * fid, shuffle_then_rotate=False))
    for k, (name, comps, sig, lam) in _CEC2017_COMPOSITES.items():
        fid = k + 1
        out.append(_make_composite(suite, fid, name, dim, comps, sig, lam,
                                   [100.0 * i for i in range(len(comps))],
                                   100.0 * fid))
    # F29 / F30: compositions of hybrid functions
    for fid, name, kids, sigmas in [
        (29, 'Composition 9', [14, 15, 16], [10, 30, 50]),
        (30, 'Composition 10', [14, 17, 18], [10, 30, 50]),
    ]:
        out.append(_make_hybrid_composite(
            suite, fid, name, dim, kids, sigmas, [1.0, 1.0, 1.0],
            [0.0, 100.0, 200.0], 100.0 * fid))
    return sorted(out, key=lambda f: f.fid)


def get_cec2017_hybrid(dim, opfunu_index, shift=None):
    """Build a single hybrid by opfunu index (used by the composite-of-hybrids)."""
    name, ops, p = _CEC2017_HYBRIDS[opfunu_index]
    return _make_hybrid('cec2017', opfunu_index + 1, name, dim, ops, p,
                        0.0, shuffle_then_rotate=False, shift=shift)


# ===========================================================================
# CEC 2022  (12 functions, D = 10 / 20)
# ===========================================================================
_CEC2022_HYBRIDS = {
    6: ('Hybrid 1', [bent_cigar, hgbat, rastrigin], [0.4, 0.4, 0.2],
        [0.0, -1.0, 0.0]),
    7: ('Hybrid 2', [hgbat, katsuura, ackley, rastrigin, modified_schwefel,
                     schaffer_f7], [0.1, 0.2, 0.2, 0.2, 0.1, 0.2],
        [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
    8: ('Hybrid 3', [katsuura, happy_cat, grie_rosen_cec, modified_schwefel,
                     ackley], [0.3, 0.2, 0.2, 0.1, 0.2],
        [0.0, -1.0, 0.0, 0.0, 0.0]),
}

_CEC2022_COMPOSITES = {
    9: ('Composition 1',
        [dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
         dict(op=elliptic), dict(op=bent_cigar), dict(op=discus),
         dict(op=elliptic)],
        [10, 20, 30, 40, 50], [1, 1e-6, 1e-6, 1e-6, 1e-6],
        [0, 200, 300, 100, 400]),
    10: ('Composition 2',
         [dict(op=modified_schwefel, scale=1000.0 / 100),
          dict(op=rastrigin, scale=5.12 / 100),
          dict(op=hgbat, scale=5.0 / 100, add=-1.0)],
         [20, 10, 10], [1, 1, 1], [0, 200, 100]),
    11: ('Composition 3',
         [dict(op=rotated_expanded_schaffer, scale=0.5 / 100),
          dict(op=modified_schwefel, scale=1000.0 / 100),
          dict(op=griewank, scale=600.0 / 100),
          dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
          dict(op=rastrigin)],
         [20, 20, 30, 30, 20], [1e-26, 10, 1e-6, 10, 5e-4],
         [0, 200, 300, 400, 200]),
    12: ('Composition 4',
         [dict(op=hgbat, scale=5.0 / 100, add=-1.0),
          dict(op=rastrigin, scale=5.12 / 100),
          dict(op=modified_schwefel, scale=1000.0 / 100),
          dict(op=bent_cigar), dict(op=elliptic),
          dict(op=rotated_expanded_schaffer)],
         [10, 20, 30, 40, 50, 60], [10, 10, 2.5, 1e-26, 1e-6, 5e-4],
         [0, 300, 500, 100, 400, 200]),
}

_CEC2022_SIMPLE = [
    (1, 'Shifted and Rotated Zakharov', 'unimodal', zakharov, None, 0.0, 300.0),
    (2, "Shifted and Rotated Rosenbrock", 'multimodal', rosenbrock,
     2.048 / 100, 1.0, 400.0),
    (3, "Expanded Schaffer's F6", 'multimodal', rotated_expanded_schaffer,
     0.5 / 100, 0.0, 600.0),
    (4, 'Non-Continuous Rastrigin', 'multimodal', non_continuous_rastrigin,
     5.12 / 100, 0.0, 800.0),
    (5, 'Levy', 'multimodal', levy, 5.12 / 100, 0.0, 900.0),
]


def get_cec2022(dim=10):
    suite, out = 'cec2022', []
    for fid, name, cat, op, scale, add, bias in _CEC2022_SIMPLE:
        out.append(_make_simple(suite, fid, name, cat, dim, op, scale=scale,
                                bias=bias, add=add))
    for fid, (name, ops, p, adds) in _CEC2022_HYBRIDS.items():
        parts = [(lambda z, o=op, a=a: o(z + a)) for op, a in zip(ops, adds)]
        out.append(_make_hybrid(suite, fid, name, dim, parts, p,
                                HYBRID_BIAS_2022[fid],
                                shuffle_then_rotate=True))
    for fid, (name, comps, sig, lam, cb) in _CEC2022_COMPOSITES.items():
        out.append(_make_composite(suite, fid, name, dim, comps, sig, lam,
                                   [float(v) for v in cb],
                                   float(COMPOSITE_BIAS_2022[fid])))
    return sorted(out, key=lambda f: f.fid)


HYBRID_BIAS_2022 = {6: 1800.0, 7: 2000.0, 8: 2200.0}
COMPOSITE_BIAS_2022 = {9: 2300.0, 10: 2400.0, 11: 2600.0, 12: 2700.0}

# ===========================================================================
# CEC 2015  (15 functions, D = 10 / 30)
# ===========================================================================
_CEC2015_SIMPLE = [
    (1, 'Rotated Bent Cigar', 'unimodal', bent_cigar, None, 0.0),
    (2, 'Rotated Discus', 'unimodal', discus, None, 0.0),
    (3, 'Shifted and Rotated Weierstrass', 'multimodal', weierstrass_norm,
     0.5 / 100, 0.0),
    (4, "Shifted and Rotated Schwefel's", 'multimodal', modified_schwefel,
     1000.0 / 100, 0.0),
    (5, 'Shifted and Rotated Katsuura', 'multimodal', katsuura,
     5.0 / 100, 0.0),
    (6, 'Shifted and Rotated HappyCat', 'multimodal', happy_cat,
     5.0 / 100, -1.0),
    (7, 'Shifted and Rotated HGBat', 'multimodal', hgbat,
     5.0 / 100, -1.0),
    (8, 'Shifted and Rotated Expanded Griewank+Rosenbrock', 'multimodal',
     expanded_griewank_rosenbrock, 5.0 / 100, 0.0),
    (9, "Shifted and Rotated Expanded Scaffer's F6", 'multimodal',
     expanded_scaffer_f6, None, 0.0),
]

_CEC2015_HYBRIDS = {
    10: ('Hybrid 1', [modified_schwefel, rastrigin, elliptic],
         [0.3, 0.3, 0.4]),
    11: ('Hybrid 2', [griewank, weierstrass_norm,
                      lambda z: rosenbrock(z + 1.0), expanded_scaffer_f6],
         [0.2, 0.2, 0.3, 0.3]),
    12: ('Hybrid 3', [katsuura, lambda z: happy_cat(z - 1.0),
                      expanded_griewank_rosenbrock, modified_schwefel,
                      ackley], [0.1, 0.2, 0.2, 0.2, 0.3]),
}

_CEC2015_COMPOSITES = {
    13: ('Composition 1',
         [dict(op=lambda z: rosenbrock(z + 1.0)),
          dict(op=elliptic, raw=True),
          dict(op=bent_cigar),
          dict(op=discus),
          dict(op=elliptic, raw=True)],
         [10, 20, 30, 40, 50], [1.0, 1e-6, 1e-26, 1e-6, 1e-6]),
    14: ('Composition 2',
         [dict(op=modified_schwefel), dict(op=rastrigin), dict(op=elliptic)],
         [10, 30, 50], [0.25, 1.0, 1e-7]),
    15: ('Composition 3',
         [dict(op=hgbat, add=-1.0), dict(op=rastrigin),
          dict(op=modified_schwefel), dict(op=weierstrass_norm),
          dict(op=elliptic)],
         [10, 10, 10, 20, 20], [10.0, 10.0, 2.5, 25.0, 1e-6]),
}


def get_cec2015(dim=10):
    suite, out = 'cec2015', []
    for fid, name, cat, op, scale, add in _CEC2015_SIMPLE:
        out.append(_make_simple(suite, fid, name, cat, dim, op,
                                scale=scale, bias=100.0 * fid, add=add))
    for fid, (name, ops, p) in _CEC2015_HYBRIDS.items():
        out.append(_make_hybrid(suite, fid, name, dim, ops, p,
                                100.0 * fid, shuffle_then_rotate=False))
    for fid, (name, comps, sig, lam) in _CEC2015_COMPOSITES.items():
        out.append(_make_composite(suite, fid, name, dim, comps, sig, lam,
                                   [100.0 * i for i in range(len(comps))],
                                   100.0 * fid))
    return sorted(out, key=lambda f: f.fid)


# ===========================================================================
# CEC 2014  (30 functions, D = 10 / 20 / 30 / 50 / 100)
# ===========================================================================
_CEC2014_SIMPLE = [
    (1, 'Rotated High Conditioned Elliptic', 'unimodal', elliptic, None, 0.0, True),
    (2, 'Rotated Bent Cigar', 'unimodal', bent_cigar, None, 0.0, True),
    (3, 'Rotated Discus', 'unimodal', discus, None, 0.0, True),
    (4, "Shifted and Rotated Rosenbrock's", 'multimodal', rosenbrock,
     2.048 / 100, 1.0, True),
    (5, "Shifted and Rotated Ackley's", 'multimodal', ackley, None, 0.0, True),
    (6, 'Shifted and Rotated Weierstrass', 'multimodal', weierstrass_norm,
     0.5 / 100, 0.0, True),
    (7, "Shifted and Rotated Griewank's", 'multimodal', griewank,
     600.0 / 100, 0.0, True),
    (8, "Shifted Rastrigin's", 'multimodal', rastrigin, 5.12 / 100, 0.0, False),
    (9, "Shifted and Rotated Rastrigin's", 'multimodal', rastrigin,
     5.12 / 100, 0.0, True),
    (10, "Shifted Schwefel's", 'multimodal', modified_schwefel,
     1000.0 / 100, 0.0, False),
    (11, "Shifted and Rotated Schwefel's", 'multimodal', modified_schwefel,
     1000.0 / 100, 0.0, True),
    (12, 'Shifted and Rotated Katsuura', 'multimodal', katsuura,
     5.0 / 100, 0.0, True),
    (13, 'Shifted and Rotated HappyCat', 'multimodal', happy_cat,
     5.0 / 100, -1.0, True),
    (14, 'Shifted and Rotated HGBat', 'multimodal', hgbat,
     5.0 / 100, -1.0, True),
    (15, 'Shifted and Rotated Expanded Griewank+Rosenbrock', 'multimodal',
     expanded_griewank_rosenbrock, 5.0 / 100, 0.0, True),
    (16, "Shifted and Rotated Expanded Scaffer's F6", 'multimodal',
     expanded_scaffer_f6, None, 0.0, True),
]

_CEC2014_HYBRIDS = {
    17: ('Hybrid 1', [modified_schwefel, rastrigin, elliptic],
         [0.3, 0.3, 0.4]),
    18: ('Hybrid 2', [bent_cigar, lambda z: hgbat(z - 1.0), rastrigin],
         [0.3, 0.3, 0.4]),
    19: ('Hybrid 3', [griewank, weierstrass_norm,
                      lambda z: rosenbrock(z + 1.0), expanded_scaffer_f6],
         [0.2, 0.2, 0.3, 0.3]),
    20: ('Hybrid 4', [lambda z: hgbat(z - 1.0), discus,
                      expanded_griewank_rosenbrock, rastrigin],
         [0.2, 0.2, 0.3, 0.3]),
    21: ('Hybrid 5', [expanded_scaffer_f6, lambda z: hgbat(z - 1.0),
                      lambda z: rosenbrock(z + 1.0), modified_schwefel,
                      elliptic], [0.1, 0.2, 0.2, 0.2, 0.3]),
    22: ('Hybrid 6', [katsuura, lambda z: happy_cat(z - 1.0),
                      expanded_griewank_rosenbrock, modified_schwefel,
                      ackley], [0.1, 0.2, 0.2, 0.2, 0.3]),
}

_CEC2014_COMPOSITES = {
    23: ('Composition 1',
         [dict(op=lambda z: rosenbrock(z + 1.0), scale=2.048 / 100),
          dict(op=elliptic, raw=True),
          dict(op=bent_cigar),
          dict(op=discus),
          dict(op=elliptic, raw=True)],
         [10, 20, 30, 40, 50], [1.0, 1e-6, 1e-26, 1e-6, 1e-6]),
    24: ('Composition 2',
         [dict(op=modified_schwefel, scale=1000.0 / 100, rotate=False),
          dict(op=rastrigin, scale=5.12 / 100, m_fid=9),
          dict(op=hgbat, scale=5.0 / 100, add=-1.0, m_fid=14)],
         [20, 20, 20], [1.0, 1.0, 1.0]),
    25: ('Composition 3',
         [dict(op=modified_schwefel, scale=1000.0 / 100, m_fid=11),
          dict(op=rastrigin, scale=5.12 / 100, m_fid=9),
          dict(op=elliptic, m_fid=1)],
         [10, 30, 50], [0.25, 1.0, 1e-7]),
    26: ('Composition 4',
         [dict(op=modified_schwefel, scale=1000.0 / 100, m_fid=11),
          dict(op=happy_cat, scale=5.0 / 100, add=-1.0, m_fid=13),
          dict(op=elliptic, m_fid=1),
          dict(op=weierstrass_norm, scale=0.5 / 100, m_fid=6),
          dict(op=griewank, scale=600.0 / 100, m_fid=7)],
         [10, 10, 10, 10, 10], [0.25, 1.0, 1e-7, 2.5, 10.0]),
    27: ('Composition 5',
         [dict(op=hgbat, scale=5.0 / 100, add=-1.0, m_fid=14),
          dict(op=rastrigin, scale=5.12 / 100, m_fid=9),
          dict(op=modified_schwefel, scale=1000.0 / 100, m_fid=11),
          dict(op=weierstrass_norm, scale=0.5 / 100, m_fid=6),
          dict(op=elliptic, m_fid=1)],
         [10, 10, 10, 20, 20], [10.0, 10.0, 2.5, 25.0, 1e-6]),
    28: ('Composition 6',
         [dict(op=expanded_griewank_rosenbrock, scale=5.0 / 100),
          dict(op=happy_cat, scale=5.0 / 100, add=-1.0),
          dict(op=modified_schwefel, scale=1000.0 / 100),
          dict(op=expanded_scaffer_f6),
          dict(op=elliptic)],
         [10, 20, 30, 40, 50], [2.5, 10.0, 2.5, 5e-4, 1e-6]),
}

_CEC2014_HYBRID_COMPOSITES = {
    29: [([modified_schwefel, rastrigin, elliptic], [0.3, 0.3, 0.4]),
         ([bent_cigar, lambda z: hgbat(z - 1.0), rastrigin], [0.3, 0.3, 0.4]),
         ([griewank, weierstrass_norm, lambda z: rosenbrock(z + 1.0),
           expanded_scaffer_f6], [0.2, 0.2, 0.3, 0.3])],
    30: [([lambda z: hgbat(z - 1.0), discus, expanded_griewank_rosenbrock,
           rastrigin], [0.2, 0.2, 0.3, 0.3]),
         ([expanded_scaffer_f6, lambda z: hgbat(z - 1.0),
           lambda z: rosenbrock(z + 1.0), modified_schwefel, elliptic],
          [0.1, 0.2, 0.2, 0.2, 0.3]),
         ([katsuura, lambda z: happy_cat(z - 1.0),
           expanded_griewank_rosenbrock, modified_schwefel, ackley],
          [0.1, 0.2, 0.2, 0.2, 0.3])],
}


def _make_cec2014_hybrid_composite(fid, dim, kids, matrix_fids, bias):
    """Composition whose components are CEC2014 hybrids (F29/F30)."""
    suite, name = 'cec2014', f'Composition {fid - 22}'
    tag = f'{suite}_{fid}_{dim}'
    n = len(kids)
    o = _official(suite, f'shift_data_{fid}', dim)
    if o is None:
        o = _shift(n, dim, tag + '_shift')
    else:
        o = np.asarray(o).reshape(-1, dim)[:n]
    sh = _official(suite, f'shuffle_data_{fid}', dim)
    sh = _shuffle(dim, tag + '_shuffle') if sh is None else \
        (np.asarray(sh, dtype=int) - 1)[:dim]
    m = _official(suite, f'M_{fid}', dim)
    m = np.asarray(m).reshape(-1, dim)[:n * dim] if m is not None else None
    mats = []
    for k, mf in enumerate(matrix_fids):
        if mf is not None:
            mm = _official(suite, f'M_{mf}', dim)
            mats.append(_orthogonal(dim, tag + f'_M{mf}') if mm is None
                        else np.asarray(mm).reshape(dim, dim))
        elif m is not None:
            mats.append(m[k * dim:(k + 1) * dim])
        else:
            mats.append(_orthogonal(dim, tag + f'_M{k}'))

    def raw(x):
        gs, ws = [], []
        for k, (ops, p) in enumerate(kids):
            groups = _split_dims(dim, p, sh)
            z = mats[k] @ np.concatenate([(x - o[k])[g] for g in groups])
            gs.append(1.0 * float(sum(op(z[g]) for op, g in zip(ops, groups)))
                      + 100.0 * k)
            ws.append(calculate_weight(x - o[k], [10, 30, 50][k]))
        ws = np.asarray(ws)
        return float(np.dot(ws / np.sum(ws), np.asarray(gs)))

    return CECFunction(suite, fid, name, 'composite', dim, raw, bias=bias,
                       x_opt=o)


def get_cec2014(dim=10):
    suite, out = 'cec2014', []
    for fid, name, cat, op, scale, add, rotate in _CEC2014_SIMPLE:
        out.append(_make_simple(suite, fid, name, cat, dim, op, scale=scale,
                                bias=100.0 * fid, add=add, rotate=rotate))
    for fid, (name, ops, p) in _CEC2014_HYBRIDS.items():
        out.append(_make_hybrid(suite, fid, name, dim, ops, p, 100.0 * fid,
                                shuffle_then_rotate=True))
    for fid, (name, comps, sig, lam) in _CEC2014_COMPOSITES.items():
        out.append(_make_composite(suite, fid, name, dim, comps, sig, lam,
                                   [100.0 * i for i in range(len(comps))],
                                   100.0 * fid))
    out.append(_make_cec2014_hybrid_composite(
        29, dim, _CEC2014_HYBRID_COMPOSITES[29], [17, 18, 19], 2900.0))
    out.append(_make_cec2014_hybrid_composite(
        30, dim, _CEC2014_HYBRID_COMPOSITES[30], [None, None, None], 3000.0))
    return sorted(out, key=lambda f: f.fid)


# ===========================================================================
# CEC 2013 (28 functions, transcribed from opfunu cec_based/cec2013.py)
# ===========================================================================
_CEC2013_BIAS = {1: -1400.0, 2: -1300.0, 3: -1200.0, 4: -1100.0, 5: -1000.0,
                 6: -900.0, 7: -800.0, 8: -700.0, 9: -600.0, 10: -500.0,
                 11: -400.0, 12: -300.0, 13: -200.0, 14: -100.0, 15: 100.0,
                 16: 200.0, 17: 300.0, 18: 400.0, 19: 500.0, 20: 600.0,
                 21: 700.0, 22: 800.0, 23: 900.0, 24: 1000.0, 25: 1100.0,
                 26: 1200.0, 27: 1300.0, 28: 1400.0}

_CEC2013_NAMES = {
    1: 'Sphere Function',
    2: 'Rotated High Conditioned Elliptic Function',
    3: 'Rotated Bent Cigar Function',
    4: 'Rotated Discus Function',
    5: 'Different Powers Function',
    6: 'Rotated Rosenbrock Function',
    7: 'Rotated Schaffers F7 Function',
    8: 'Rotated Ackley Function',
    9: 'Rotated Weierstrass Function',
    10: 'Rotated Griewank Function',
    11: 'Rastrigin Function',
    12: 'Rotated Rastrigin Function',
    13: 'Non-Continuous Rotated Rastrigin Function',
    14: 'Schwefel Function',
    15: 'Rotated Schwefel Function',
    16: 'Rotated Katsuura Function',
    17: 'Lunacek bi-Rastrigin Function',
    18: 'Rotated Lunacek bi-Rastrigin Function',
    19: 'Rotated Expanded Griewank plus Rosenbrock Function',
    20: 'Rotated Expanded Scaffer F6 Function',
    21: 'Composition Function 1',
    22: 'Composition Function 2',
    23: 'Composition Function 3',
    24: 'Composition Function 4',
    25: 'Composition Function 5',
    26: 'Composition Function 6',
    27: 'Composition Function 7',
    28: 'Composition Function 8',
}


def _cec2013_data(dim, tag):
    """CEC2013 shares one shift file and one stacked rotation file per dim.

    ``shift`` is (10, dim) -- 10 shift vectors; ``matrix`` is (10 * dim, dim)
    -- 10 stacked orthogonal blocks.  Falls back to deterministic generation
    when the official files are absent.
    """
    d = DATA_DIRS.get('cec2013')
    shift = matrix = None
    if d is not None and d.is_dir():
        sp = d / 'shift_data.txt'
        if sp.exists():
            try:
                shift = np.loadtxt(sp)
            except Exception:
                shift = None
        mp = d / f'M_D{dim}.txt'
        if mp.exists():
            try:
                matrix = np.loadtxt(mp)
            except Exception:
                matrix = None
    if shift is None or np.asarray(shift).shape[0] < 10:
        shift = _shift(10, dim, tag + '_shift')
    else:
        shift = np.asarray(shift, dtype=float)
    if matrix is None or np.asarray(matrix).shape[0] < 10 * dim:
        matrix = np.concatenate(
            [_orthogonal(dim, f'{tag}_M{k}') for k in range(10)], axis=0)
    else:
        matrix = np.asarray(matrix, dtype=float)
    return shift[:, :dim], matrix[:, :dim]


# --- CEC 2013 basic raw evaluators (all return f(x) WITHOUT bias) ---
def _c13_sphere(x, o):
    return sphere(x - o)


def _c13_elliptic(x, o, m):
    return elliptic(_tosz(m @ (x - o)))


def _c13_bent_cigar(x, o, m1, m2):
    return bent_cigar(m2 @ _tasy(m1 @ (x - o), 0.5))


def _c13_discus(x, o, m):
    return discus(_tosz(m @ (x - o)))


def _c13_diff_powers(x, o):
    return different_powers(x - o)


def _c13_rosenbrock(x, o, m):
    return rosenbrock(m @ (2.048 * (x - o) / 100.0) + 1.0)


def _c13_schaffer_f7(x, o, m1, m2):
    alpha = _diag_alpha(len(x), 10.0)
    return _schaffer_f7_c13((alpha @ m2) @ _tasy(m1 @ (x - o), 0.5))


def _c13_ackley(x, o, m1, m2):
    alpha = _diag_alpha(len(x), 10.0)
    return ackley((alpha @ m2) @ _tasy(m1 @ (x - o), 0.5))


def _c13_weierstrass(x, o, m1, m2):
    alpha = _diag_alpha(len(x), 10.0)
    return weierstrass_norm((alpha @ m2) @ _tasy(m1 @ (0.5 * (x - o) / 100.0),
                                                 0.5))


def _c13_griewank(x, o, m):
    alpha = _diag_alpha(len(x), 100.0)
    return griewank((alpha @ m) @ (600.0 * (x - o) / 100.0))


def _c13_rastrigin(x, o):
    alpha = _diag_alpha(len(x), 10.0)
    return rastrigin(alpha @ _tasy(_tosz(5.12 * (x - o) / 100.0), 0.2))


def _c13_rastrigin_rot(x, o, m1, m2):
    alpha = _diag_alpha(len(x), 10.0)
    t1 = (m1 @ alpha) @ m2
    t2 = _tosz(m1 @ (5.12 * (x - o) / 100.0))
    return rastrigin(t1 @ _tasy(t2, 0.2))


def _c13_rastrigin_noncont(x, o, m1, m2):
    alpha = _diag_alpha(len(x), 10.0)
    x_star = m1 @ (5.12 * (x - o) / 100.0)
    y = _rounder(x_star, np.abs(x_star))
    t1 = _tasy(_tosz(y), 0.2)
    t2 = (m1 @ alpha) @ m2
    return rastrigin(t2 @ t1)


def _c13_schwefel(x, o):
    alpha = _diag_alpha(len(x), 10.0)
    return modified_schwefel(alpha @ (1000.0 * (x - o) / 100.0))


def _c13_schwefel_rot(x, o, m):
    alpha = _diag_alpha(len(x), 10.0)
    return modified_schwefel((alpha @ m) @ (1000.0 * (x - o) / 100.0))


def _c13_katsuura(x, o, m1, m2):
    alpha = _diag_alpha(len(x), 100.0)
    return katsuura((m2 @ alpha) @ (m1 @ (5.0 * (x - o) / 100.0)))


def _c13_lunacek(x, o, use_shift_sign):
    y = 10.0 * (x - o) / 100.0
    x_hat = 2.0 * (np.sign(o) if use_shift_sign else np.sign(y)) * y
    return _lunacek_shift(x_hat, 2.5, 1.0, 2.5)


def _c13_grie_rosen(x, o, m):
    return _grie_rosen_cec2013(m @ (5.0 * (x - o) / 100.0))


def _c13_scaffer_f6(x, o, m1, m2):
    return expanded_scaffer_f6(m2 @ _tasy(m1 @ (x - o), 0.5))


def get_cec2013(dim=30):
    suite, tag = 'cec2013', f'cec2013_{dim}'
    shift, matrix = _cec2013_data(dim, tag)

    def blk(k):
        return matrix[k * dim:(k + 1) * dim, :dim]

    o0 = shift[0]
    b0, b1 = blk(0), blk(1)

    out = []

    def add(fid, cat, raw_fn, x_opt):
        out.append(CECFunction(suite, fid, _CEC2013_NAMES[fid], cat, dim,
                               raw_fn, bias=_CEC2013_BIAS[fid], x_opt=x_opt))

    # --- unimodal F1-F5 ---
    add(1, 'unimodal', lambda x: _c13_sphere(x, o0), o0)
    add(2, 'unimodal', lambda x: _c13_elliptic(x, o0, b0), o0)
    add(3, 'unimodal', lambda x: _c13_bent_cigar(x, o0, b0, b1), o0)
    add(4, 'unimodal', lambda x: _c13_discus(x, o0, b0), o0)
    add(5, 'unimodal', lambda x: _c13_diff_powers(x, o0), o0)
    # --- basic multimodal F6-F20 ---
    add(6, 'multimodal', lambda x: _c13_rosenbrock(x, o0, b0), o0)
    add(7, 'multimodal', lambda x: _c13_schaffer_f7(x, o0, b0, b1), o0)
    add(8, 'multimodal', lambda x: _c13_ackley(x, o0, b0, b1), o0)
    add(9, 'multimodal', lambda x: _c13_weierstrass(x, o0, b0, b1), o0)
    add(10, 'multimodal', lambda x: _c13_griewank(x, o0, b0), o0)
    add(11, 'multimodal', lambda x: _c13_rastrigin(x, o0), o0)
    add(12, 'multimodal', lambda x: _c13_rastrigin_rot(x, o0, b0, b1), o0)
    add(13, 'multimodal', lambda x: _c13_rastrigin_noncont(x, o0, b0, b1), o0)
    add(14, 'multimodal', lambda x: _c13_schwefel(x, o0), o0)
    add(15, 'multimodal', lambda x: _c13_schwefel_rot(x, o0, b0), o0)
    add(16, 'multimodal', lambda x: _c13_katsuura(x, o0, b0, b1), o0)
    add(17, 'multimodal', lambda x: _c13_lunacek(x, o0, True), o0)
    add(18, 'multimodal', lambda x: _c13_lunacek(x, o0, False), o0)
    add(19, 'multimodal', lambda x: _c13_grie_rosen(x, o0, b0), o0)
    add(20, 'multimodal', lambda x: _c13_scaffer_f6(x, o0, b0, b1), o0)

    # --- composition F21-F28 ---
    def add_comp(fid, comps, sigmas, lams, cbias):
        n = len(comps)

        def raw(x):
            ws = np.array([calculate_weight(x - shift[i], sigmas[i])
                           for i in range(n)])
            gs = np.array([lams[i] * comps[i](x) + cbias[i]
                           for i in range(n)])
            return float(np.dot(ws / np.sum(ws), gs))

        out.append(CECFunction(suite, fid, _CEC2013_NAMES[fid], 'composite',
                               dim, raw, bias=_CEC2013_BIAS[fid],
                               x_opt=shift[:n]))

    add_comp(21,
             [lambda x: _c13_rosenbrock(x, shift[0], b0),
              lambda x: _c13_diff_powers(x, shift[1]),
              lambda x: _c13_bent_cigar(x, shift[2], b0, b1),
              lambda x: _c13_discus(x, shift[3], b0),
              lambda x: _c13_sphere(x, shift[4])],
             [10, 20, 30, 40, 50],
             [1.0, 1e-6, 1e-26, 1e-6, 0.1],
             [0, 100, 200, 300, 400])
    add_comp(22,
             [lambda x: _c13_schwefel(x, shift[0]),
              lambda x: _c13_schwefel(x, shift[1]),
              lambda x: _c13_schwefel(x, shift[2])],
             [20, 20, 20], [1.0, 1.0, 1.0], [0, 100, 200])
    add_comp(23,
             [lambda x: _c13_schwefel_rot(x, shift[0], b0),
              lambda x: _c13_schwefel_rot(x, shift[1], b0),
              lambda x: _c13_schwefel_rot(x, shift[2], b0)],
             [20, 20, 20], [1.0, 1.0, 1.0], [0, 100, 200])
    add_comp(24,
             [lambda x: _c13_schwefel_rot(x, shift[0], b0),
              lambda x: _c13_rastrigin_rot(x, shift[1], b0, b1),
              lambda x: _c13_weierstrass(x, shift[2], b0, b1)],
             [20, 20, 20], [0.25, 1.0, 2.5], [0, 100, 200])
    add_comp(25,
             [lambda x: _c13_schwefel_rot(x, shift[0], b0),
              lambda x: _c13_rastrigin_rot(x, shift[1], b0, b1),
              lambda x: _c13_weierstrass(x, shift[2], b0, b1)],
             [10, 30, 50], [0.25, 1.0, 2.5], [0, 100, 200])
    add_comp(26,
             [lambda x: _c13_schwefel_rot(x, shift[0], b0),
              lambda x: _c13_rastrigin_rot(x, shift[1], b0, b1),
              lambda x: _c13_elliptic(x, shift[2], b0),
              lambda x: _c13_weierstrass(x, shift[3], b0, b1),
              lambda x: _c13_griewank(x, shift[4], b0)],
             [10, 10, 10, 10, 10],
             [0.25, 1.0, 1e-7, 2.5, 10.0],
             [0, 100, 200, 300, 400])
    add_comp(27,
             [lambda x: _c13_griewank(x, shift[0], b0),
              lambda x: _c13_rastrigin_rot(x, shift[1], b0, b1),
              lambda x: _c13_schwefel_rot(x, shift[2], b0),
              lambda x: _c13_weierstrass(x, shift[3], b0, b1),
              lambda x: _c13_sphere(x, shift[4])],
             [10, 10, 10, 20, 20],
             [100.0, 10.0, 2.5, 25.0, 0.1],
             [0, 100, 200, 300, 400])
    add_comp(28,
             [lambda x: _c13_grie_rosen(x, shift[0], b0),
              lambda x: _c13_schaffer_f7(x, shift[1], blk(2), blk(3)),
              lambda x: _c13_schwefel_rot(x, shift[2], b0),
              lambda x: _c13_scaffer_f6(x, shift[3], b0, b1),
              lambda x: _c13_sphere(x, shift[4])],
             [10, 20, 30, 40, 50],
             [2.5, 2.5e-6, 2.5, 5e-4, 0.1],
             [0, 100, 200, 300, 400])

    return sorted(out, key=lambda f: f.fid)


SUITE_LOADERS = {'cec2017': get_cec2017, 'cec2022': get_cec2022,
                 'cec2015': get_cec2015, 'cec2014': get_cec2014,
                 'cec2013': get_cec2013}
SUITE_DIMS = {'cec2017': (30, 50), 'cec2022': (10, 20), 'cec2015': (10, 30),
              'cec2014': (10, 20, 30, 50, 100), 'cec2013': (10, 30, 50, 100)}
SUITE_NFUNCS = {'cec2017': 29, 'cec2022': 12, 'cec2015': 15, 'cec2014': 30,
                'cec2013': 28}

_CACHE = {}


def get_suite(suite, dim):
    key = (suite, dim)
    if key not in _CACHE:
        _CACHE[key] = SUITE_LOADERS[suite](dim)
    return _CACHE[key]


def get_function(suite, dim, fid):
    for f in get_suite(suite, dim):
        if f.fid == fid:
            return f
    raise KeyError(f'no {suite} function F{fid} at D={dim}')


def categories(suite):
    return {'cec2017': ['unimodal', 'multimodal', 'hybrid', 'composite'],
            'cec2022': ['unimodal', 'multimodal', 'hybrid', 'composite'],
            'cec2015': ['unimodal', 'multimodal', 'hybrid', 'composite'],
            'cec2014': ['unimodal', 'multimodal', 'hybrid', 'composite'],
            'cec2013': ['unimodal', 'multimodal', 'composite']}[suite]


if __name__ == '__main__':
    # Self-consistency: the seeded optimum must give a zero error, and random
    # samples must never beat it (a negative error means the normalisation
    # constant is wrong, e.g. a missing composition weight factor).
    rng = np.random.default_rng(0)
    worst_neg = 0.0
    for suite, dims in SUITE_DIMS.items():
        for dim in dims:
            fs = get_suite(suite, dim)
            errs = [f.error(f.x_opt) for f in fs]
            print(f'{suite} D={dim}: {len(fs)} functions, '
                  f'max |f(o)-f*| = {max(abs(e) for e in errs):.3e}')
            cand = rng.uniform(-100.0, 100.0, (2000, dim))
            neg = []
            for f in fs:
                best = min(float(f(x)) - f.f_opt for x in cand)
                if best < -1e-6:
                    neg.append((f.label, best))
            worst_neg = min(worst_neg, min([v for _, v in neg], default=0.0))
            if neg:
                print('   negative errors at random points:',
                      ', '.join(f'{k} {v:.3e}' for k, v in neg[:6]))
            for f in fs[:2]:
                x = rng.uniform(-100, 100, dim)
                print(f'   {f.label:>4s} {f.category:<11s} '
                      f'f*={f.f_opt:9.2f}  f(o)-f*={f.error(f.x_opt):.2e}  '
                      f'f(rand)={f(x):12.4e}')
    print(f'worst negative error over 2000 random points: {worst_neg:.3e}')

# -*- coding: utf-8 -*-
"""
Universal Proposal Correction Layer (UPCL)
==========================================

UPCL is a host-agnostic layer that wraps an arbitrary differential evolution
variant.  It treats the host H as an *opaque proposal generator*

        u_i = H(x_i, S_t)                       (host produces a proposal)

and returns a corrected proposal

        u~_i = x_i + T_a(u_i - x_i),            a in A = {I, C, E, R, P}

before the single fitness evaluation that the host would perform anyway.

The proposal level of adaptation is defined by four constraints
----------------------------------------------------------------
(1) Opacity.  UPCL never reads or writes F, CR, the external archive, the
    mutation-strategy id, or any host-side success memory.  The only
    host-level inputs are the population X and its fitness vector f(X) --
    observables that every population-based optimiser exposes -- plus the
    scalar response Delta f of the evaluated proposal.
(2) Zero extra evaluations.  Exactly one proposal is evaluated per target
    vector, so the evaluation budget of H+UPCL is bit-for-bit identical to
    that of H.  Exploration changes *where* the budget is spent, not how much
    of it is spent.
(3) Minimal intervention.  An action is taken only when its predicted
    response exceeds that of the identity by a margin, after paying an
    intervention cost proportional to the geometric distortion.
(4) Identity-safe.  C(H) = H is always admissible: with no response evidence
    the layer degenerates to the identity map, so the layer cannot damage a
    host that is already well tuned.

Relation to neighbouring mechanisms (see paper Sec. 2 for the full audit)
-------------------------------------------------------------------------
The individual operators are deliberately classical: reflection,
contraction and expansion are the moves of the Nelder-Mead simplex, and
step-size increase/decrease is the mesh update of a direct-search method.
The contribution is not the operator set but its placement -- the operators
act on a proposal *supplied by an opaque host*, are selected from an
online (proposal-descriptor, action) response model, and are gated by a
minimum-distortion objective.  Unlike opposition-based DE or multi-trial
DE, no additional candidate is generated and no extra evaluation is spent.
"""

import math
import os

import numpy as np

try:
    from numba import njit
    _HAS_NUMBA = True
except Exception:                                        # pragma: no cover
    _HAS_NUMBA = False

    def njit(*args, **kwargs):
        def _decorator(fn):
            return fn
        return _decorator

# JIT fast path on by default; UPCL_DISABLE_NUMBA=1 forces the pure-numpy
# reference path (used by the numerical-equivalence tests).
_USE_NUMBA = _HAS_NUMBA and os.environ.get('UPCL_DISABLE_NUMBA') != '1'


def _clamp(v, lo=-4.0, hi=4.0):
    """np.clip for a Python float (avoids the numpy call in the hot path)."""
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v


# ---------------------------------------------------------------------------
# Action space
# ---------------------------------------------------------------------------
ACTION_NAMES = ('I', 'C', 'E', 'R', 'P')
A_IDENTITY, A_CONTRACT, A_EXPAND, A_REFLECT, A_PROJECT = range(5)
N_ACTIONS = len(ACTION_NAMES)


DEFAULTS = dict(
    contract=0.7,          # alpha : d' = alpha * d   (2nd-round "mild geometry")
    expand=1.4,            # beta  : d' = beta  * d    (2nd-round "mild geometry")
    project_mix=0.5,       # q' = normalize((1-m) q + m * s_hat)
    lam=0.90,              # intervention-cost weight
    margin=0.20,           # baseline identity-safe margin
    margin_adapt=0.60,     # extra margin scaled by the host's own quality
    margin_ema=0.02,       # EMA rate of the host-quality estimate
    ucb_kappa=0.35,        # uncertainty penalty  kappa / sqrt(1 + n_eff)
    eps0=0.15,             # initial exploration rate
    eps_min=0.00,          # exploration stops once the model is populated
    eps_gens=60,           # generations over which exploration decays
    explore_weights=(0.30, 0.25, 0.20, 0.10, 0.15),  # I, C, E, R, P
    mem_capacity=256,      # response-memory capacity
    bandwidth=1.2,         # kernel bandwidth in descriptor space
    prior_strength=2.0,    # shrinkage towards the per-action global mean
    n_min=3.0,             # minimum effective sample size for a prediction
    ema_gamma=0.05,        # learning rate of the success-direction EMA
    n_ref=32,              # reference points used for scale / crowding
    n_proto=8,             # direction prototypes used for novelty
    min_shrink=0.5,        # feasibility shrink below this reverts to identity
    degenerate_eps=1e-24,
    # Which descriptor components feed the response model, as a 5-tuple of
    # 0/1 over (rho_step, theta_align, eta_elite, kappa_crowd, nu_novel).
    # Zeroed components are pinned to a constant (0) so they carry no kernel
    # distance, which is equivalent to reducing the descriptor dimensionality.
    descriptor_mask=(1, 1, 1, 1, 1),

    # --- ARD automatic descriptor relevance (Scheme 1) --------------
    # With ``ard_enable=True`` the hard 0/1 ``descriptor_mask`` is replaced
    # by a per-component, per-action *learned* length-scale (automatic
    # relevance determination).  Each action maintains online first/second
    # moments of its descriptor components and their covariance with the
    # response; the diagonal kernel bandwidth is then
    #     bw_j = bandwidth * sigma_j / (|rho_j| + ard_prior)
    # where sigma_j is the component's sample std and rho_j its sample
    # correlation with the response.  A component that never co-varies with
    # the response (|rho_j| -> 0) gets a huge bandwidth and is thereby muted,
    # which is exactly what a hand-picked zero in ``descriptor_mask`` does --
    # but learned *per (host, function)* from data instead of fixed globally.
    # ``ard_prior`` is the shrinkage prior on relevance (a weak prior, not a
    # hand-tuned cut); ``ard_warmup`` keeps the scalar bandwidth until each
    # action has that many samples, so the early moments are not degenerate.
    ard_enable=False,
    ard_prior=0.1,
    ard_warmup=8,

    # --- ablation: disable specific actions (P/C ablation) -----------
    # Tuple of action names (subset of 'I','C','E','R','P') to switch off.
    # Disabled actions are never drawn in exploration nor selected by the
    # policy, which isolates the contribution of each operator.  Empty for
    # the default operating point (behaviour unchanged).
    disable_actions=(),

    # --- stagnation-aware reflection (mechanism study) ---------------
    # With ``stagnation_enable=False`` (the default) the behaviour is bit-for-
    # bit identical to the paper's default operating point.  When enabled, the
    # reflect / expand costs -- normally pinned at 2.0 / (expand-1) so those
    # two "escape" moves are never selected -- drop to the ``stagnation_*``
    # values once the population-best has failed to improve for
    # ``stagnation_window`` consecutive generations, letting the response model
    # actually try a jump out of a local optimum when the search has stalled.
    stagnation_enable=False,
    stagnation_window=30,
    stagnation_tol=1e-12,
    stagnation_reflect_cost=0.5,
    stagnation_expand_cost=0.4,
    stagnation_reflect_bonus=0.8,
    stagnation_expand_bonus=0.5,
    # Expand multiplier used *only* while the population is stalled.  A DE
    # stall is fundamentally a collapse of the difference vector F*(x_r2-x_r3),
    # so the escape move that actually helps is not reflect (which flips an
    # already-collapsed d) but a *large* expansion that temporarily restores a
    # meaningful step.  Default = ``expand`` (1.4) so the behaviour is
    # bit-for-bit unchanged unless a preset overrides it.
    stagnation_expand_factor=1.4,
    # Project step multiplier / optimistic bonus used *only* while stalled.
    # A stalled project keeps the (collapsed) host step nd by default, so it
    # cannot escape either; scaling it by stagnation_project_factor turns it
    # into a *directed* restart along the running success direction s_hat.
    stagnation_project_factor=1.0,
    stagnation_project_bonus=0.0,
)


# ===========================================================================
# JIT-compiled kernel (response-memory prediction)
# ===========================================================================
if _HAS_NUMBA:
    @njit(cache=True)
    def _predict_all_nb(Z, R, size, z, bw2, k0, n_min, out_pred, out_neff):
        """Kernel-weighted response prediction for all actions at ``z``.

        ``Z`` is (N_ACTIONS, cap, dim_z), ``R`` is (N_ACTIONS, cap), ``size``
        the per-action fill count and ``z`` the (dim_z,) descriptor.  Results
        are written into ``out_pred`` / ``out_neff`` (both (N_ACTIONS,)).
        """
        n_act = Z.shape[0]
        dim_z = Z.shape[2]
        for a in range(n_act):
            n = size[a]
            if n <= 0:
                out_pred[a] = 0.0
                out_neff[a] = 0.0
                continue
            sw = 0.0
            gsum = 0.0
            s2 = 0.0
            wr = 0.0
            for i in range(n):
                acc = 0.0
                for j in range(dim_z):
                    diff = Z[a, i, j] - z[j]
                    acc += diff * diff
                wi = math.exp(-0.5 * acc / bw2)
                sw += wi
                gsum += R[a, i]
                s2 += wi * wi
                wr += wi * R[a, i]
            g = gsum / n
            if sw <= 1e-12:
                out_pred[a] = g
                out_neff[a] = 0.0
                continue
            ne = sw * sw / s2 if s2 > 0.0 else 0.0
            k = k0 * (1.0 - ne / n_min)
            if k < 0.0:
                k = 0.0
            elif k > k0:
                k = k0
            local = wr / sw
            out_pred[a] = (sw * local + k * g) / (sw + k + 1e-30)
            out_neff[a] = ne


# ===========================================================================
# M2 -- Response memory:  (z, a) -> E[Delta f]
# ===========================================================================
class ResponseMemory:
    """Non-parametric, online model of the proposal-response map.

    Stores triples (z, a, r) where z is the descriptor of the *uncorrected*
    host proposal, a is the action actually applied, and r is the normalised
    fitness response.  Predictions are kernel-weighted means over the most
    recent samples of the queried action, shrunk towards that action's global
    mean when the effective sample size is small.

    Samples are kept in *per-action* ring buffers of equal capacity.  The
    identity action dominates the proposal stream (> 99% in steady state), so
    a single shared FIFO would flush every C/E/R/P sample within a few
    generations and leave those arms with no usable evidence once exploration
    stops.  A private buffer per action keeps each arm's most recent evidence
    alive independently of the traffic of the others.
    """

    def __init__(self, capacity=256, dim_z=5, bandwidth=1.2,
                 prior_strength=2.0, n_min=3.0, ard=False,
                 ard_prior=0.1, ard_warmup=8):
        self.dim_z = int(dim_z)
        self.bw = float(bandwidth)
        self.k0 = float(prior_strength)
        self.n_min = float(n_min)
        self.ard = bool(ard)
        self.ard_prior = float(ard_prior)
        self.ard_warmup = int(ard_warmup)
        # Per-action ring buffers.  The nominal ``capacity`` is split evenly
        # so that each action holds ``capacity // N_ACTIONS`` samples.
        self.cap = max(1, int(capacity) // N_ACTIONS)
        self.Z = np.zeros((N_ACTIONS, self.cap, self.dim_z), dtype=float)
        self.R = np.zeros((N_ACTIONS, self.cap), dtype=float)
        self.ptr = np.zeros(N_ACTIONS, dtype=np.intp)
        self.size = np.zeros(N_ACTIONS, dtype=np.intp)
        self._pred = np.zeros(N_ACTIONS, dtype=float)
        self._neff = np.zeros(N_ACTIONS, dtype=float)
        # ARD online statistics (per action): Welford mean/M2 of the descriptor
        # components and of the response, plus the accumulated component x
        # response centred cross-product (=> sample covariance / correlation).
        self._mu = np.zeros((N_ACTIONS, self.dim_z), dtype=float)
        self._m2 = np.zeros((N_ACTIONS, self.dim_z), dtype=float)
        self._rbar = np.zeros(N_ACTIONS, dtype=float)
        self._rm2 = np.zeros(N_ACTIONS, dtype=float)
        self._xr = np.zeros((N_ACTIONS, self.dim_z), dtype=float)
        self._ard_n = np.zeros(N_ACTIONS, dtype=float)

    # ------------------------------------------------------------------
    def add(self, z, a, r):
        p = int(self.ptr[a])
        self.Z[a, p] = z
        self.R[a, p] = r
        self.ptr[a] = (p + 1) % self.cap
        if self.size[a] < self.cap:
            self.size[a] += 1
        if self.ard:
            # Welford update of descriptor mean / M2, response mean / M2, and
            # the centred cross-product for the component-response covariance.
            n = self._ard_n[a]
            mu, m2 = self._mu[a], self._m2[a]
            d = z - mu
            mu += d / (n + 1.0)
            d2 = z - mu
            m2 += d * d2
            dr = r - self._rbar[a]
            self._rbar[a] += dr / (n + 1.0)
            self._rm2[a] += dr * (r - self._rbar[a])
            # Welford cross-term: (z - mu_old) * (r - rbar_new), where ``d``
            # still holds z - mu_old (mu was updated in place above).
            self._xr[a] += d * (r - self._rbar[a])
            self._ard_n[a] = n + 1.0

    # ------------------------------------------------------------------
    def global_mean(self, a):
        n = int(self.size[a])
        if n == 0:
            return 0.0
        return float(self.R[a, :n].mean())

    # ------------------------------------------------------------------
    def _action_pred(self, a, z):
        """Kernel estimate ``(r_hat, n_eff)`` for a single action at ``z``."""
        n = int(self.size[a])
        if n == 0:
            return 0.0, 0.0
        Zm = self.Z[a, :n]
        Rm = self.R[a, :n]
        diff = Zm - z
        if self.ard and self._ard_n[a] >= self.ard_warmup:
            # Automatic relevance: each component gets its own length-scale
            # from its sample std and its sample correlation with the response.
            na = self._ard_n[a]
            sig = np.sqrt(self._m2[a] / na)
            sig = np.maximum(sig, 1e-6)
            sr = math.sqrt(max(self._rm2[a] / na, 1e-12))
            rho = (self._xr[a] / na) / (sig * sr + 1e-12)
            rho = np.clip(rho, -1.0, 1.0)
            bwv = self.bw * sig / (np.abs(rho) + self.ard_prior)
            bwv = np.maximum(bwv, 1e-6)
            d2 = np.einsum('ij,ij->i', diff / bwv, diff / bwv)
            w = np.exp(-0.5 * d2)
        else:
            d2 = np.einsum('ij,ij->i', diff, diff)
            w = np.exp(-0.5 * d2 / (self.bw * self.bw))
        sw = float(w.sum())
        g = float(Rm.mean())
        if sw <= 1e-12:
            # No kernel weight reaches this action: fall back to its global
            # mean and report zero effective sample size.
            return g, 0.0
        s2 = float(np.dot(w, w))
        ne = sw * sw / s2 if s2 > 0.0 else 0.0
        # Shrink towards the action's global mean when evidence is thin.
        k = self.k0 * (1.0 - ne / self.n_min)
        if k < 0.0:
            k = 0.0
        elif k > self.k0:
            k = self.k0
        local = float(np.dot(w, Rm) / sw)
        pred = (sw * local + k * g) / (sw + k + 1e-30)
        return pred, ne

    # ------------------------------------------------------------------
    def predict_all(self, z, w=None):
        """Kernel prediction for *all* actions at the descriptor ``z``.

        Returns ``(r_hat, n_eff)``, two arrays of shape ``(N_ACTIONS,)``.
        The ``w`` argument is accepted for backward compatibility but ignored:
        per-action buffers are queried directly.
        """
        if _USE_NUMBA and not self.ard:
            _predict_all_nb(self.Z, self.R, self.size, z,
                            self.bw * self.bw, self.k0, self.n_min,
                            self._pred, self._neff)
            return self._pred, self._neff
        pred, neff = self._pred, self._neff
        for a in range(N_ACTIONS):
            pred[a], neff[a] = self._action_pred(a, z)
        return pred, neff

    def predict(self, z, a, w=None):
        """Return ``(r_hat, n_eff)`` for a single action ``a`` at ``z``."""
        return self._action_pred(a, z)

    # ------------------------------------------------------------------
    def counts(self):
        return [int(self.size[a]) for a in range(N_ACTIONS)]


# ===========================================================================
# UPCL controller
# ===========================================================================
class UPCLController:
    """Proposal-level correction layer attached to one DE host instance."""

    def __init__(self, dim, lb, ub, seed=None, config=None):
        cfg = dict(DEFAULTS)
        if config:
            cfg.update(config)
        self.cfg = cfg
        self.dim = int(dim)
        # Bounds may be given as scalars, which every numpy consumer below
        # would silently broadcast into a 0-d array and then fail to index.
        self.lb = np.full(int(dim), float(np.ravel(lb)[0])) if np.ndim(lb) == 0 \
            else np.asarray(lb, dtype=float).ravel()
        self.ub = np.full(int(dim), float(np.ravel(ub)[0])) if np.ndim(ub) == 0 \
            else np.asarray(ub, dtype=float).ravel()
        self.rng = np.random.default_rng(seed)

        # --- M2: response memory -------------------------------------
        self.memory = ResponseMemory(
            capacity=cfg['mem_capacity'],
            bandwidth=cfg['bandwidth'],
            prior_strength=cfg['prior_strength'],
            n_min=cfg['n_min'],
            ard=cfg['ard_enable'],
            ard_prior=cfg['ard_prior'],
            ard_warmup=cfg['ard_warmup'],
        )

        # --- ablation: action ids to disable -------------------------
        self._disabled = set()
        for _n in cfg['disable_actions']:
            if _n in ACTION_NAMES:
                self._disabled.add(ACTION_NAMES.index(_n))

        # --- per-generation population context -----------------------
        self.s_ref = 1.0
        self.sigma_f = 1.0
        self.best_x = None
        self.ref_pts = None
        self._ref2 = None          # |ref_pts|^2, cached once per generation
        self._tmp_ref = None       # scratch of length n_ref
        self._z = np.zeros(5)      # descriptor buffer (valid for one proposal)
        # Under ARD the component relevance is learned per (host, function),
        # so the hard 0/1 mask is disabled (all components flow to the kernel,
        # where the per-component bandwidths decide their weight).
        self._desc_mask = (np.ones(5) if cfg['ard_enable']
                           else np.asarray(cfg['descriptor_mask'], dtype=float))
        # Exp5 diagnostic accumulators, indexed by [response sign, component]
        self._desc_sum = np.zeros((2, 5))
        self._desc_sq = np.zeros((2, 5))
        self._desc_n = np.zeros(2)
        self.population = None
        self.fitness = None
        self.generation = 0

        # --- learned success direction (used by the projection action) --
        self.s_hat = None
        # EMA of the response obtained by the host's *own* proposals, i.e. by
        # the identity action.  It is the layer's estimate of how good the
        # host currently is, and it raises the bar for intervening.
        self.r_identity_ema = 0.0
        self.protos = np.zeros((int(cfg['n_proto']), self.dim))
        self.n_proto = 0
        self._proto_ptr = 0

        # --- pending proposal awaiting its response -------------------
        self._pending = None

        # --- diagnostics ---------------------------------------------
        self.n_proposals = 0
        self.n_interventions = 0
        self.n_explore_act = 0
        self.n_policy_act = 0
        self.gen_proposals = 0
        self.gen_interventions = 0
        self.gen_policy_act = 0
        self.action_counts = np.zeros(N_ACTIONS, dtype=np.int64)
        self.rho_curve = []          # total intervention rate per generation
        self.rho_policy_curve = []   # policy-driven rate (exploration removed)
        self.mean_abs_shift = 0.0    # mean ||u~ - u|| / ||u - x|| when acting

        # --- stagnation-aware reflection state -----------------------
        self._stag_enable = bool(cfg['stagnation_enable'])
        self._stag_window = int(cfg['stagnation_window'])
        self._stag_tol = float(cfg['stagnation_tol'])
        self._stag_reflect_cost = float(cfg['stagnation_reflect_cost'])
        self._stag_expand_cost = float(cfg['stagnation_expand_cost'])
        self._stag_reflect_bonus = float(cfg['stagnation_reflect_bonus'])
        self._stag_expand_bonus = float(cfg['stagnation_expand_bonus'])
        self._stag_expand_factor = float(cfg['stagnation_expand_factor'])
        self._stag_project_factor = float(cfg['stagnation_project_factor'])
        self._stag_project_bonus = float(cfg['stagnation_project_bonus'])
        self._last_best_f = None
        self._stagnation_count = 0
        self._stag_active = False
        self._stagnation_gen_count = 0
        self.stag_action_counts = np.zeros(N_ACTIONS, dtype=np.int64)

    # ------------------------------------------------------------------
    # Generation-level context (population observables only)
    # ------------------------------------------------------------------
    def begin_generation(self, pop, fitness):
        self.population = pop
        self.fitness = fitness
        N = pop.shape[0]
        self.sigma_f = float(np.std(fitness)) + 1e-30
        self.best_x = pop[int(np.argmin(fitness))].copy()

        # Characteristic population scale from a sampled subset.
        n_ref = int(min(N, self.cfg['n_ref']))
        if n_ref >= 2:
            idx = self.rng.choice(N, size=n_ref, replace=False)
            P = pop[idx]
            diff = P[:, None, :] - P[None, :, :]
            dist = np.sqrt(np.einsum('ijk,ijk->ij', diff, diff))
            iu = np.triu_indices(n_ref, k=1)
            s = float(np.median(dist[iu])) if len(iu[0]) else 1.0
            self.s_ref = max(s, 1e-30)
            self.ref_pts = P
        else:
            self.s_ref = 1.0
            self.ref_pts = np.asarray(pop)
        # P is a copy, so its row norms are valid for the whole generation and
        # let _describe replace a (n_ref, dim) subtraction plus a norm by one
        # matrix-vector product.
        self._ref2 = np.einsum('ij,ij->i', self.ref_pts, self.ref_pts)
        m = self.ref_pts.shape[0]
        if self._tmp_ref is None or self._tmp_ref.shape[0] < m:
            self._tmp_ref = np.zeros(m)

        if self.gen_proposals > 0:
            self.rho_curve.append(self.gen_interventions / float(self.gen_proposals))
            self.rho_policy_curve.append(self.gen_policy_act / float(self.gen_proposals))
        self.gen_proposals = 0
        self.gen_interventions = 0
        self.gen_policy_act = 0

        # Stagnation detection (host-agnostic: population observables only).
        if self._stag_enable:
            best_f = float(np.min(fitness))
            if self._last_best_f is not None:
                if best_f < self._last_best_f - self._stag_tol:
                    self._stagnation_count = 0
                else:
                    self._stagnation_count += 1
            self._last_best_f = best_f
            self._stag_active = self._stagnation_count >= self._stag_window
            if self._stag_active:
                self._stagnation_gen_count += 1
        else:
            self._stag_active = False

        self.generation += 1

    # ------------------------------------------------------------------
    # M1 -- Proposal characterisation
    # ------------------------------------------------------------------
    def _describe(self, x, d, nd):
        q = d / nd
        z = self._z
        # rho : relative step length (log scale, population-relative)
        z[0] = _clamp(0.5 * math.log2(nd / self.s_ref + 1e-30))
        # theta : alignment with the learned success direction
        z[1] = (0.0 if self.s_hat is None
                else _clamp(float(np.dot(q, self.s_hat))))
        # eta : alignment with the current elite direction
        ze = self.best_x - x
        ne = math.sqrt(float(np.dot(ze, ze)))
        z[2] = 0.0 if ne < 1e-30 else _clamp(float(np.dot(q, ze / ne)))
        # kappa : crowding at the landing point.  |r - u|^2 = |r|^2 - 2 r.u +
        # |u|^2, so the (n_ref, dim) temporary is avoided entirely.
        u = x + d
        uu = float(np.dot(u, u))
        if self._ref2 is not None:
            m = self.ref_pts.shape[0]
            tmp = self._tmp_ref[:m]
            np.dot(self.ref_pts, u, out=tmp)
            tmp *= -2.0
            tmp += self._ref2
            tmp += uu
            dmin = math.sqrt(max(float(tmp.min()), 0.0))
        else:                                            # pragma: no cover
            dmin = float(np.linalg.norm(self.ref_pts - u, axis=1).min())
        z[3] = _clamp(0.5 * math.log2(dmin / self.s_ref + 1e-30))
        # nu : directional novelty against the prototype set
        if self.n_proto > 0:
            cos = self.protos[:self.n_proto] @ q
            np.abs(cos, out=cos)
            z[4] = _clamp(1.0 - float(np.max(cos)))
        else:
            z[4] = 1.0
        z *= self._desc_mask
        return z, q

    # ------------------------------------------------------------------
    # M3 -- action application, cost, and selection
    # ------------------------------------------------------------------
    def _apply(self, a, d, nd, q):
        if a == A_IDENTITY:
            return d, q
        if a == A_CONTRACT:
            return self.cfg['contract'] * d, q
        if a == A_EXPAND:
            factor = (self._stag_expand_factor if self._stag_active
                      else self.cfg['expand'])
            return factor * d, q
        if a == A_REFLECT:
            return -d, -q
        if a == A_PROJECT:
            if self.s_hat is None:
                return d, q
            m = self.cfg['project_mix']
            q2 = (1.0 - m) * q + m * self.s_hat
            n2 = math.sqrt(float(np.dot(q2, q2)))
            if n2 < 1e-12:
                return d, q
            q2 = q2 / n2
            step = nd * self._stag_project_factor if self._stag_active else nd
            return step * q2, q2
        raise ValueError(f'unknown action {a}')

    def _cost(self, a, q, q2):
        if a == A_IDENTITY:
            return 0.0
        if a == A_CONTRACT:
            return 1.0 - self.cfg['contract']
        if a == A_EXPAND:
            return self.cfg['expand'] - 1.0
        if a == A_REFLECT:
            return 2.0
        if a == A_PROJECT:
            dq = q2 - q
            return math.sqrt(float(np.dot(dq, dq)))
        return 0.0

    def _cost_vector(self, q):
        """Distortion cost of all five actions, as a Python tuple.

        I, C and R are constant; P needs the projected direction, which is
        also what ``_apply`` would compute for the projection, so it is
        evaluated here instead of calling ``_apply`` five times.
        """
        g = self.cfg
        c_proj = 0.0
        if self.s_hat is not None:
            m = g['project_mix']
            q2 = (1.0 - m) * q + m * self.s_hat
            n2 = math.sqrt(float(np.dot(q2, q2)))
            if n2 >= 1e-12:
                q2 = q2 / n2
                dq = q2 - q
                c_proj = math.sqrt(float(np.dot(dq, dq)))
        if self._stag_active:
            c_reflect = self._stag_reflect_cost
            c_expand = self._stag_expand_cost
        else:
            c_reflect = 2.0
            c_expand = g['expand'] - 1.0
        return (0.0, 1.0 - g['contract'], c_expand, c_reflect, c_proj)

    def _explore_rate(self):
        g = self.cfg
        t = min(1.0, self.generation / float(max(1, g['eps_gens'])))
        return float(g['eps0'] + (g['eps_min'] - g['eps0']) * t)

    def _select(self, z, d, nd, q):
        """Return (action, was_exploration).

        Exploration draws over the *whole* action set, including the identity,
        with the fixed weights ``explore_weights`` (not uniformly).  Sampling
        the identity is what keeps the response model of
        "do nothing" alive: if only non-identity arms were explored, the
        identity estimate would freeze at its early-run value and any arm that
        happened to look good once would be re-selected forever (a positive
        feedback loop that drives the intervention rate to 1).
        """
        g = self.cfg
        if self.rng.random() < self._explore_rate():
            w = np.asarray(g['explore_weights'], dtype=float)
            for a in self._disabled:
                w[a] = 0.0
            w = w / w.sum()
            return int(self.rng.choice(N_ACTIONS, p=w)), True
        # Adaptive identity margin: the better the host's own proposals are
        # doing, the more a correction must promise before it is applied.
        margin = g['margin'] + g['margin_adapt'] * max(0.0, self.r_identity_ema)
        r_hat, n_eff = self.memory.predict_all(z)
        cost = self._cost_vector(q)
        lam, kappa = g['lam'], g['ucb_kappa']
        r0, e0 = r_hat[0], n_eff[0]
        best_score = (r0 - lam * cost[0]
                      - kappa / math.sqrt(1.0 + e0) + margin)
        best_a = A_IDENTITY
        projectable = self.s_hat is not None
        stag = self._stag_active
        for a in range(1, N_ACTIONS):
            if a in self._disabled:
                continue
            if a == A_PROJECT and not projectable:
                continue
            # Penalise thin evidence: an arm supported by few kernel-weighted
            # samples must beat the identity by more, not less.
            score = (r_hat[a] - lam * cost[a]
                     - kappa / math.sqrt(1.0 + n_eff[a]))
            # Stagnation-aware escape bonus: when the search has stalled the
            # reflect/expand moves still have no response samples (r_hat == 0),
            # so without an optimistic bonus they can never out-score identity
            # and the layer never learns whether jumping out of the local
            # optimum actually helps.
            if stag:
                if a == A_REFLECT:
                    score += self._stag_reflect_bonus
                elif a == A_EXPAND:
                    score += self._stag_expand_bonus
                elif a == A_PROJECT:
                    score += self._stag_project_bonus
            if score > best_score:
                best_score = score
                best_a = a
        return int(best_a), False

    # ------------------------------------------------------------------
    # Feasibility: shrink the corrected step back into the box
    # ------------------------------------------------------------------
    def _box_shrink(self, x, d):
        u = x + d
        t = 1.0
        over = u > self.ub
        if np.any(over):
            dd = d[over]
            dd = np.where(np.abs(dd) < 1e-30, 1e-30, dd)
            t = min(t, float(np.min((self.ub[over] - x[over]) / dd)))
        under = u < self.lb
        if np.any(under):
            dd = d[under]
            dd = np.where(np.abs(dd) < 1e-30, 1e-30, dd)
            t = min(t, float(np.min((self.lb[under] - x[under]) / dd)))
        t = float(max(0.0, min(1.0, t)))
        return x + t * d, t

    # ------------------------------------------------------------------
    # Host-facing API
    # ------------------------------------------------------------------
    def propose(self, x, u, f_x):
        """Return the (possibly corrected) proposal for target vector x."""
        self.n_proposals += 1
        self.gen_proposals += 1
        d = u - x
        nd = float(np.sqrt(float(np.dot(d, d))))
        if nd < self.cfg['degenerate_eps']:
            self._pending = (None, A_IDENTITY, f_x, None)
            return u

        z, q = self._describe(x, d, nd)
        a, explored = self._select(z, d, nd, q)
        d_a, q_a = self._apply(a, d, nd, q)
        if a == A_IDENTITY:
            # The layer must be a pure pass-through when it decides not to
            # intervene: returning x + t*d would perturb the host's proposal
            # by one ulp and make the paired comparison impure.  Feasibility
            # of the host's own proposal is the host's responsibility, exactly
            # as in the bare run.
            u_new, t = u, 1.0
        else:
            u_new, t = self._box_shrink(x, d_a)
            # Feasibility shrink has deformed the geometry too far -> identity.
            if t < self.cfg['min_shrink']:
                a, explored = A_IDENTITY, False
                u_new = u
                q_a = q

        if a != A_IDENTITY:
            self.n_interventions += 1
            self.gen_interventions += 1
            if explored:
                self.n_explore_act += 1
            else:
                self.n_policy_act += 1
            du = u_new - u
            self.mean_abs_shift += math.sqrt(float(np.dot(du, du))) / nd
        self.action_counts[a] += 1
        if self._stag_active:
            self.stag_action_counts[a] += 1

        # Novelty prototype refresh
        if self.n_proto < self.protos.shape[0]:
            self.protos[self.n_proto] = q
            self.n_proto += 1
        elif self.rng.random() < 0.05:
            self.protos[self._proto_ptr] = q
            self._proto_ptr = (self._proto_ptr + 1) % self.protos.shape[0]

        # The direction stored with the pending record is the one that was
        # actually executed, q_a, not the one the host proposed: when a
        # correction is applied and succeeds, the credit belongs to the
        # corrected move.  s_hat is updated with q_a for that reason.
        self._pending = (z, a, f_x, q_a)
        return u_new

    def observe(self, f_new):
        """Record the response of the proposal returned by the last propose()."""
        if self._pending is None:
            return
        z, a, f_old, q_exec = self._pending
        self._pending = None
        if z is None:
            return
        # Scale-free, bounded response.  Dividing by the population fitness
        # dispersion removes the objective's units; tanh() bounds the target
        # so that a single outlier improvement cannot dominate the kernel
        # regression and, hence, the action comparison.
        raw = (f_old - f_new) / (self.sigma_f + 1e-30)
        r = float(np.tanh(raw))
        self.memory.add(z, a, r)
        # Exp5 descriptor diagnostic: split the descriptors by the sign of the
        # observed response.  The standardised difference of the two groups
        # says which descriptor components separate working proposals from
        # failing ones, and whether that survives at D = 50.
        bucket = 0 if r > 0.0 else 1
        self._desc_sum[bucket] += z
        self._desc_sq[bucket] += z * z
        self._desc_n[bucket] += 1.0
        if a == A_IDENTITY:
            g = self.cfg['margin_ema']
            self.r_identity_ema = (1.0 - g) * self.r_identity_ema + g * r
        if r > 0.0 and q_exec is not None:
            gam = self.cfg['ema_gamma']
            if self.s_hat is None:
                self.s_hat = q_exec.copy()
            else:
                s = (1.0 - gam) * self.s_hat + gam * q_exec
                ns = math.sqrt(float(np.dot(s, s)))
                if ns > 1e-12:
                    self.s_hat = s / ns

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------
    def intervention_rate(self):
        if self.n_proposals == 0:
            return 0.0
        return self.n_interventions / float(self.n_proposals)

    def policy_rate(self):
        """Intervention rate with exploration draws removed.

        This is the quantity that measures how often the layer *believes* it
        should correct the host, and is the one reported as rho in the paper.
        """
        if self.n_proposals == 0:
            return 0.0
        return self.n_policy_act / float(self.n_proposals)

    def mean_shift(self):
        if self.n_interventions == 0:
            return 0.0
        return self.mean_abs_shift / float(self.n_interventions)

    def stats(self):
        return {
            'n_proposals': int(self.n_proposals),
            'n_interventions': int(self.n_interventions),
            'intervention_rate': float(self.intervention_rate()),
            'policy_rate': float(self.policy_rate()),
            'mean_relative_shift': float(self.mean_shift()),
            'action_counts': {ACTION_NAMES[i]: int(self.action_counts[i])
                              for i in range(N_ACTIONS)},
            'memory_counts': {ACTION_NAMES[i]: int(self.memory.counts()[i])
                              for i in range(N_ACTIONS)},
            'rho_curve': [float(v) for v in self.rho_curve],
            'rho_policy_curve': [float(v) for v in self.rho_policy_curve],
            'descriptor_influence': self.descriptor_influence(),
            'stagnation_enable': bool(self._stag_enable),
            'stagnation_gens': int(self._stagnation_gen_count),
            'stagnation_active': bool(self._stag_active),
            'stag_action_counts': {ACTION_NAMES[i]: int(self.stag_action_counts[i])
                                   for i in range(N_ACTIONS)},
        }

    def descriptor_influence(self):
        """Standardised descriptor contrast between working and failing moves.

        For every one of the five descriptor components the mean value over
        the proposals whose response was positive is compared with the mean
        over the proposals whose response was not, and the difference is
        divided by the component's overall standard deviation.  Large values
        identify the components that actually carry the signal the response
        model exploits.
        """
        n_pos, n_neg = float(self._desc_n[0]), float(self._desc_n[1])
        out = {'n_pos': n_pos, 'n_neg': n_neg}
        total_n = n_pos + n_neg
        for k in range(5):
            key = f'z{k}'
            if total_n <= 0 or n_pos <= 0 or n_neg <= 0:
                out[f'{key}_pos'] = 0.0
                out[f'{key}_neg'] = 0.0
                out[f'{key}_effect'] = 0.0
                continue
            m_pos = self._desc_sum[0, k] / n_pos
            m_neg = self._desc_sum[1, k] / n_neg
            m_all = (self._desc_sum[0, k] + self._desc_sum[1, k]) / total_n
            v_all = ((self._desc_sq[0, k] + self._desc_sq[1, k]) / total_n
                     - m_all * m_all)
            sd = math.sqrt(max(v_all, 1e-12))
            out[f'{key}_pos'] = float(m_pos)
            out[f'{key}_neg'] = float(m_neg)
            out[f'{key}_effect'] = float((m_pos - m_neg) / sd)
        return out

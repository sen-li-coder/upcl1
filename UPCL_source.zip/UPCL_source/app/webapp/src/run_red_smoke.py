"""红方 F1~F4 课题 smoke：验证「红方编码 → 仿真 → 目标 → 约束」全链路。

流程
----
1. 用现有 DE 在**当前代码**上求一个蓝方最优突防方案，作为固定对手 ``blue_x``。
   红方优化本质是 min–max，本 smoke 先固定内层；蓝方域随机化留待后续
   （设计文档 §10 风险 1）。
2. 评估出厂红方配置（真基线 :func:`uav_red.evaluate_base`）。
3. 用 DE 优化指定课题（deploy / ew / intercept / coordinate），与真基线逐指标对比。
4. 逐课题钩子敏感性：固定其余变量、单项扫描该课题的决策槽位，确认它们真的在
   改变仿真结局（而非只有静态代理项在动）—— 否则钩子可能是死代码。
5. ``--fingerprint``：默认路径零副作用自检，见 :func:`check_default_path`。

用法
----
    python -u run_red_smoke.py --fid 1 --blue-evals 3000 --red-evals 3000
    python -u run_red_smoke.py --fid 3 --modes intercept coordinate --red-evals 8000
    python -u run_red_smoke.py --fingerprint
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from dataclasses import replace

import numpy as np

import uav_red as R
from de_hosts import get_host
from uav_adversarial import _intercept_cfg, get_uav_problem

ENV_SEED = 20_240_000          # 与既有 UAV 蓝方实验一致的地形 seed（地形与 seed 无关，仅巡逻兵分布相关）

# 默认路径指纹基准（--fingerprint 自检用；F3/F4 新增钩子全部 None 时必须逐位不变）
FP_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       'results', 'apps', 'red_default_fingerprint.json')


def _fingerprint(fid: int, seed: int, xs) -> list:
    """默认路径（无红方干预）的逐位指纹：cost/state/metrics/frames 全量摘要。"""
    prob = get_uav_problem('intercept', fid=fid, seed=seed)
    out = []
    for x in xs:
        cost, state, metrics, frames = prob.env._rollout(x, record=True)
        blob = json.dumps({
            'cost': repr(float(cost)),
            'state': list(map(int, state)),
            'metrics': {k: (repr(v) if isinstance(v, float) else v)
                        for k, v in sorted(metrics.items())},
            'frames': json.dumps(frames, sort_keys=True, default=lambda o: float(o)),
        }, sort_keys=True, default=str)
        out.append({'cost': float(cost), 'state': list(map(int, state)),
                    'digest': hashlib.sha256(blob.encode()).hexdigest()[:16]})
    return out


def check_default_path(path: str = FP_PATH) -> int:
    """「默认路径零副作用」自检。

    F3/F4 给 ``EnvConfig`` 加了 ``assign_target / sector_bounds / launch_threshold``
    三个钩子。它们全部为 None（``_rollout`` 的 red_x 也为 None）时必须与改造前
    逐位等价 —— 否则会污染既有的蓝方第五章实验与 F1/F2 结果。
    比对 cost / state / 全量 metrics / 全部渲染帧的 sha256 指纹。
    """
    rng = np.random.default_rng(20261014)
    xs = [rng.uniform(-1.0, 1.0, 30) for _ in range(3)]
    cur = {f'fid{fid}_seed{seed}': _fingerprint(fid, seed, xs)
           for fid in (1, 2, 3, 4) for seed in (0, 7)}
    if os.path.exists(path):
        with open(path, encoding='utf-8') as fh:
            ref = json.load(fh)
        bad = [k for k in ref if ref[k] != cur.get(k)]
        print(f'[默认路径自检] 参照 {path}')
        print('  结果：' + ('IDENTICAL —— F3/F4 钩子默认关闭时逐位不变'
                          if not bad else f'DIFF！不一致项 {bad}'))
        return 1 if bad else 0
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(cur, fh, indent=1, sort_keys=True)
    print(f'[默认路径自检] 无参照文件，已写入基准 {path}')
    return 0


def _line(m: dict) -> str:
    return ('arr=%d lost=%d patrolKill=%d infSurv=%.2f baseHP=%.0f fc=%.0f risk=%.0f'
            % (m['n_arrived'], m['n_lost'], m['n_patrol_killed'],
               m['infantry_survival'], m['base_hp'],
               m['first_capture'], m['risk_time']))


def solve_blue(fid: int, evals: int, host_name: str, seed: int, runs: int = 3):
    """在当前代码上求蓝方最优突防方案，作为红方的固定对手。

    best-of-``runs``：单次 DE 的蓝方方案往往突不进去（红方任务退化为全平），
    取多次独立运行中蓝方代价最低（= 突防最成功）的一个，才能让红方有优化空间。
    """
    prob = get_uav_problem('intercept', fid=fid, seed=ENV_SEED)
    best_f, best_x, wall = float('inf'), None, 0.0
    for r in range(runs):
        host = get_host(host_name, prob.dim, R.LB, R.UB, seed=seed * 1000 + r)
        t0 = time.perf_counter()
        f, x, _conv, _ev = host.run(prob, evals)
        wall += time.perf_counter() - t0
        if float(f) < best_f:
            best_f, best_x = float(f), np.asarray(x, dtype=float)
    _c, _st, metrics = prob.evaluate(best_x)
    return best_x, best_f, metrics, wall


def random_control(mode: str, fid: int, blue_x, evals: int, seed: int):
    """同预算均匀随机搜索对照：确认 DE 的增益不是「随便采都行」。"""
    prob = R.RedProblem(mode, fid=fid, seed=ENV_SEED, blue_x=blue_x)
    rng = np.random.default_rng(seed + 20261014)
    best_f, best_x, best_res = float('inf'), None, None
    for _ in range(evals):
        x = rng.uniform(R.LB, R.UB, prob.dim)
        r = prob.evaluate(x)
        if r['cost'] < best_f:
            best_f, best_x, best_res = r['cost'], x, r
    return np.asarray(best_x, dtype=float), float(best_f), best_res, prob.nevals


def optimize_red(mode: str, fid: int, blue_x, evals: int, host_name: str,
                 seed: int):
    """DE 优化一个红方课题，返回 (best_x, best_f, 评估结果, 墙钟, 评估次数)。"""
    prob = R.RedProblem(mode, fid=fid, seed=ENV_SEED, blue_x=blue_x)
    host = get_host(host_name, prob.dim, R.LB, R.UB, seed=seed)
    t0 = time.perf_counter()
    best_f, best_x, _conv, _ev = host.run(prob, evals)
    wall = time.perf_counter() - t0
    res = prob.evaluate(best_x)
    return np.asarray(best_x, dtype=float), float(best_f), res, wall, prob.nevals


def f2_sensitivity(base_cfg, blue_x, opt_res):
    """逐项扫描 F2 的雷达/预警钩子，确认其边际效应非零。

    含停机坪项：停机坪是 F2 的「拦截机出动基地」变量。把最优停机坪换回出厂东南角
    （(950,50) 距走廊最近点 636 m，拦截机 63 步才能到位而无人机 60 步打完）应显著
    变差 —— 这正是 F2 获得真实仿真杠杆的来源（只优化雷达时三钩子全是零效应）。
    """
    plan0 = opt_res['plan']
    rr0 = float(plan0.radar_range or base_cfg.radar_range)
    grid = [
        ('alert_threshold', [1, 2, 3], None),
        ('scan_period', [1, 6, 12, 24], None),
        ('radar_half_angle', [math.pi, math.pi / 2.0, math.pi / 6.0],
         ['180deg(全向)', '90deg', '30deg']),
        ('radar_range', [rr0 * 0.6, rr0, rr0 * 1.4],
         ['%.0fm(缩)' % (rr0 * 0.6), '%.0fm(最优)' % rr0, '%.0fm(放)' % (rr0 * 1.4)]),
        ('helipads', [list(base_cfg.interceptor_pos), list(plan0.helipads or [])],
         ['出厂(950,50)', '最优']),
    ]
    rows = []
    for name, vals, labels in grid:
        for j, v in enumerate(vals):
            p2 = replace(plan0, **{name: v})
            r = R.red_evaluate(mode='ew', base_cfg=base_cfg, plan=p2,
                               blue_x=blue_x, seed=ENV_SEED)
            rows.append({
                'knob': name, 'value': v, 'cost': r['cost'],
                'label': (labels[j] if labels else _v(v)),
                'objective': r['objective'], 'n_arrived': r['n_arrived'],
                'n_lost': r['n_lost'], 'range_eff': r['radar_range_eff'],
                'fc': r['first_capture'], 'feasible': bool(r['feasible']),
            })
    return rows


def _sens(mode, base_cfg, blue_x, plan0, grid):
    """通用钩子敏感性扫描：逐个槽位替换最优解中的该项，返回指标行。

    表项可为 ``(name, vals, labels)`` 或 ``(name, vals, labels, extra)``；后者
    的 ``extra`` 会与该项**一起**覆盖（例如「把责任区关掉再看主责分配的边际
    效应」，否则分区约束会把主责分配完全淹没，看起来像死代码）。
    """
    rows = []
    for item in grid:
        name, vals, labels = item[0], item[1], item[2]
        extra = item[3] if len(item) > 3 else {}
        for j, v in enumerate(vals):
            p2 = replace(plan0, **{name: v}, **extra)
            r = R.red_evaluate(mode=mode, base_cfg=base_cfg, plan=p2,
                               blue_x=blue_x, seed=ENV_SEED)
            rows.append({
                'knob': name, 'label': (labels[j] if labels else _v(v)),
                'cost': r['cost'], 'objective': r['objective'],
                'n_arrived': r['n_arrived'], 'n_lost': r['n_lost'],
                'fc': r['first_capture'], 'risk': r['risk_time'],
                'gap': r['coverage_gap'], 'deploy': r['deploy_cost'],
                'feasible': bool(r['feasible']), 'n_violations': r['n_violations'],
            })
    return rows


def f3_sensitivity(base_cfg, blue_x, opt_res):
    """F3 钩子扫描：出动基地（helipads）+ 拦截航路（int_routes）。

    只变一个槽位、其余固定在最优解，看 cost / fc（首次交战时刻）/ risk 是否
    真的随之变化 —— 若航路单独扫描时全行相同，说明该槽位对仿真零杠杆
    （增益只来自 deploy 等静态代理项），必须暴露出来。
    """
    p0 = opt_res['plan']
    return [
        ('helipads', [list(base_cfg.interceptor_pos), list(p0.helipads or [])],
         ['出厂(东南角)', '最优']),
        ('int_routes', [list(R.default_int_routes(base_cfg)),
                        [tuple(p) for p in (p0.int_routes or [])]],
         ['出厂(走廊中段等分)', '最优']),
    ]


def f4_sensitivity(base_cfg, blue_x, opt_res):
    """F4 钩子扫描：协同层三件套（主责分配 / 责任区 / 逐机出动阈值）+ 拦截层。"""
    p0 = opt_res['plan']
    n_int = max(1, int(base_cfg.n_interceptors))
    n_units = R._n_units(base_cfg)
    return [
        # 关掉责任区后再看主责分配的边际效应：分区开启时它会把分配完全淹没
        # （扇区已把目标分给固定单元，主责再约束也不改变结果），看起来像死代码。
        ('assign', [[-1] * n_units, list(p0.assign or [-1] * n_units), [0] * n_units],
         ['出厂(自由贪心)', '最优', '对照(全体打0号)'], {'sector_bounds': None}),
        ('sector_bounds', [None, list(p0.sector_bounds or [])],
         ['出厂(不分区)', '最优']),
        ('launch_threshold', [[1] * n_int, list(p0.launch_threshold or [1] * n_int)],
         ['出厂(即捕即出动)', '最优']),
        ('helipads', [list(base_cfg.interceptor_pos), list(p0.helipads or [])],
         ['出厂(东南角)', '最优']),
    ]


def main() -> int:
    ap = argparse.ArgumentParser(description='红方 F1~F4 课题 smoke')
    ap.add_argument('--fid', type=int, default=1)
    ap.add_argument('--blue-evals', type=int, default=3000)
    ap.add_argument('--blue-runs', type=int, default=3)
    ap.add_argument('--red-evals', type=int, default=3000)
    ap.add_argument('--control-evals', type=int, default=0,
                    help='随机搜索对照的评估次数，0 表示与 red-evals 相同')
    ap.add_argument('--host', default='DE/rand/1')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--modes', nargs='+', default=['deploy', 'ew'],
                    help='课题：deploy / ew / intercept / coordinate')
    ap.add_argument('--fingerprint', action='store_true',
                    help='只跑「默认路径零副作用」自检（不求解蓝方/红方）')
    ap.add_argument('--out', default='')
    args = ap.parse_args()

    if args.fingerprint:
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass
        return check_default_path()
    n_control = args.control_evals or args.red_evals

    try:                              # Windows 控制台默认 GBK，中文报告会乱码
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    base_cfg = _intercept_cfg(args.fid)
    print('=' * 78)
    print(f'红方课题 smoke  fid={args.fid}  env_seed={ENV_SEED}  '
          f'host={args.host}  blue_evals={args.blue_evals}  red_evals={args.red_evals}')
    print(f'编成：拦截机 {base_cfg.n_interceptors} / 防空车 {base_cfg.n_aa} / '
          f'巡逻兵 {base_cfg.n_patrol} / 无人机 {base_cfg.n_drones} / '
          f'步兵 {base_cfg.n_infantry}')
    print('=' * 78)

    # ---- 1. 蓝方最优对手 ----
    t0 = time.perf_counter()
    blue_x, blue_f, blue_m, blue_wall = solve_blue(
        args.fid, args.blue_evals, args.host, args.seed, args.blue_runs)
    n_blue = args.blue_evals * args.blue_runs
    print(f'[蓝方对手] DE {args.blue_runs}×{args.blue_evals} evals（取最优），'
          f'{blue_wall:.1f}s ({blue_wall / n_blue * 1000:.1f} ms/eval)  '
          f'cost={blue_f:.4f}')
    print(f'           {_line(blue_m)}')

    # ---- 2. 真基线（出厂红方配置） ----
    base = R.evaluate_base(base_cfg, blue_x=blue_x, seed=ENV_SEED)
    print(f'[真基线  ] cost={base["cost"]:.4f}  objective={base["objective"]:.4f}'
          f'  gap={base["coverage_gap"]:.3f}  deploy={base["deploy_cost"]:.3f}')
    print(f'           {_line(base)}')

    report = {'fid': args.fid, 'env_seed': ENV_SEED, 'host': args.host,
              'blue': {'cost': blue_f, 'metrics': _clean(blue_m)},
              'baseline': _clean(base), 'modes': {}}

    # ---- 3. 逐课题优化 ----
    for mode in args.modes:
        print('-' * 78)
        x, f, res, wall, nev = optimize_red(
            mode, args.fid, blue_x, args.red_evals, args.host, args.seed)
        desc = res['plan_desc']
        dcost = res['cost'] - base['cost']
        print(f'[{R.MODE_NAMES[mode]}] D={len(x)}  {nev} evals  {wall:.1f}s '
              f'({wall / max(nev, 1) * 1000:.1f} ms/eval)')
        print(f'  cost {base["cost"]:.4f} -> {res["cost"]:.4f}  '
              f'(Δ={dcost:+.4f}, {"改善" if dcost < 0 else "变差"})')
        print(f'  objective={res["objective"]:.4f} penalty={res["penalty"]:.4f} '
              f'feasible={res["feasible"]} viol={res["n_violations"]}')
        for v in res['violations']:
            print(f'    ! {v[0]} sev={v[1]:.3f} {v[2]}')
        print(f'  覆盖缺口 {base["coverage_gap"]:.3f} -> {res["coverage_gap"]:.3f}'
              f'  后勤散布 {base["deploy_cost"]:.3f} -> {res["deploy_cost"]:.3f}')
        print(f'  {_line(res)}')
        # 同预算随机搜索对照：确认增益不是「随便采都行」
        _cx, cf, _cr, nev_c = random_control(
            mode, args.fid, blue_x, n_control, args.seed)
        print(f'  [对照] 随机搜索 {nev_c} evals: cost={cf:.4f} '
              f'（DE 比随机 {cf - res["cost"]:+.4f}）')
        for k, v in desc.items():
            print(f'    {k}: {v}')
        report['modes'][mode] = {
            'dim': int(len(x)), 'nevals': int(nev), 'wall_s': round(wall, 2),
            'cost': res['cost'], 'objective': res['objective'],
            'delta_vs_base': dcost, 'feasible': bool(res['feasible']),
            'violations': [list(v) for v in res['violations']],
            'coverage_gap': res['coverage_gap'],
            'deploy_cost': res['deploy_cost'],
            'plan_desc': desc, 'x_best': [float(v) for v in x],
            'metrics': _clean(res),
        }
        if mode == 'ew':
            rows = f2_sensitivity(base_cfg, blue_x, res)
            report['ew_sensitivity'] = rows
            print('  F2 钩子敏感性（其余变量固定在最优解）：')
            cur = None
            for r in rows:
                if r['knob'] != cur:
                    cur = r['knob']
                    print(f'    -- {cur} --')
                print('       v=%-13s cost=%-11.4f obj=%-11.4f arr=%d lost=%d '
                      'range_eff=%.1f fc=%.0f feas=%s'
                      % (r['label'], r['cost'], r['objective'],
                         r['n_arrived'], r['n_lost'], r['range_eff'], r['fc'],
                         r['feasible']))
        elif mode in ('intercept', 'coordinate'):
            grid = (f3_sensitivity if mode == 'intercept'
                    else f4_sensitivity)(base_cfg, blue_x, res)
            rows = _sens(mode, base_cfg, blue_x, res['plan'], grid)
            report[mode + '_sensitivity'] = rows
            print(f'  {R.MODE_NAMES[mode]} 钩子敏感性（其余变量固定在最优解）：')
            cur = None
            for r in rows:
                if r['knob'] != cur:
                    cur = r['knob']
                    print(f'    -- {cur} --')
                print('       v=%-20s cost=%-11.4f obj=%-11.4f arr=%d lost=%d '
                      'fc=%-5.0f risk=%-6.1f feas=%s viol=%d'
                      % (r['label'], r['cost'], r['objective'],
                         r['n_arrived'], r['n_lost'], r['fc'], r['risk'],
                         r['feasible'], r['n_violations']))

    print('=' * 78)
    if args.out:
        with open(args.out, 'w', encoding='utf-8') as fh:
            json.dump(report, fh, ensure_ascii=False, indent=1)
        print(f'报告已写入 {args.out}')
    return 0


def _v(x) -> str:
    """敏感性取值的默认标签；角度/距离类槽位在 grid 里另给显式可读标签。"""
    return str(x)


def _clean(m: dict) -> dict:
    out = {}
    for k, v in m.items():
        if k in ('plan', 'cfg', 'layout', 'full_plan', 'frames'):
            continue
        if isinstance(v, (bool, np.bool_)):
            out[k] = bool(v)
        elif isinstance(v, (int, np.integer)):
            out[k] = int(v)
        elif isinstance(v, (float, np.floating)):
            out[k] = float(v)
        elif isinstance(v, list) and v and isinstance(v[0], tuple):
            out[k] = [list(p) for p in v]
        else:
            out[k] = v
    return out


if __name__ == '__main__':
    raise SystemExit(main())

"""LASE <-> AFSIM 2.9 高保真复核桥。

把 LASE 内置降阶对抗仿真（:mod:`uav_adversarial`）的一局解翻译成一份真实可跑的
AFSIM 想定（WSF 输入文件），用官方 ``mission.exe`` headless 重放，再回读事件
日志与逐帧遥测，与内置引擎的指标并排对比。

职责划分（设计原则）
--------------------
* **运动学 / 时序 / 事件管线归 AFSIM**：蓝方无人机按决策航点由 ``WSF_AIR_MOVER``
  真实飞行（限速 / 限转弯 / 限爬升 / 沿航路捕获），红方直升机由
  ``WsfPlatform.GoToLocation`` 追击，探测产生真实的 ``SENSOR_TRACK_INITIATED``。
* **交战判决沿用 LASE 规则**：LASE 的探测/攻击半径是二维水平距离，AFSIM 原生
  传感器是三维斜距锥体，两者不等价；为做到「同一套战术规则、只换仿真内核」，
  距离与锥角判定写在 AFSIM 脚本处理器里（照抄 LASE 公式），武器用
  ``WSF_IMPLICIT_WEAPON`` + 球形杀伤模型（命中半径 = ``missile_radius``）。
  注意 AFSIM 隐式武器是**理想拦截**（发射即按预测拦截点命中），比 LASE 的
  「导弹限速/限转弯/燃料有限、可被机动甩脱」更强，这是两套引擎已知的建模差。
* **差异归因，而不是抹平**：AFSIM 侧没有三维山地与山体视线遮挡（见
  :data:`NOT_MODELED`），而 LASE 默认开 LOS 遮挡。为了让「桥接是否忠实」可判读，
  对比表给三列：LASE 原始（含山地/遮挡）、**LASE 同假设臂**（关闭 LOS 遮挡，
  与 AFSIM 的平坦地面等价）、AFSIM 真实运行。若后两列接近，说明桥接本身没走样，
  剩余差异来自已声明的建模差（隐式理想拦截）。
* **未建模者如实标注**：见 :data:`NOT_MODELED`（三维合成山地、楼房掩体、
  巡逻兵交火与基地轰炸不在 v1 内），因此对比表只覆盖空情指标。

坐标：LASE 地图是 1000×1000 米的平面坐标，AFSIM 用经纬高。取 ``LAT0/LON0``
为原点，北向 y、东向 x 线性映射（局部等距近似，1000 米范围误差 < 1 厘米）。
"""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

ROOT = Path(__file__).resolve().parents[1]


def _find_afsim_root() -> Path:
    """定位 AFSIM 安装树：环境变量优先，其次项目根 / 上一级 / 再上一级。

    Web 端跑的是 ``app/webapp/src`` 下的镜像副本，安装树却在仓库根，
    因此不能只用 ``Path(__file__).parents[1]``。
    """
    env = os.environ.get('LASE_AFSIM_ROOT')
    cands: List[Path] = [Path(env)] if env else []
    bases = [ROOT] + list(ROOT.parents)[:2]
    cands.extend(base / 'afsim-2.9.0-win64' for base in bases)
    for cand in cands:
        if (cand / 'bin' / 'mission.exe').is_file():
            return cand
    return cands[-1]


DEFAULT_AFSIM_ROOT = _find_afsim_root()

# 局部等距坐标系原点（AFSIM 想定使用的战场位置）
LAT0 = 34.0
LON0 = -117.0
M_PER_DEG_LAT = 111320.0
M_PER_DEG_LON = M_PER_DEG_LAT * math.cos(math.radians(LAT0))

BLUE_PREFIX = 'uav'
INF_PREFIX = 'inf'
AA_PREFIX = 'aa'
HELI_PREFIX = 'heli'
RADAR_NAME = 'radar1'
RECORDER_NAME = 'clock0'

NOT_MODELED = [
    '三维合成山地地形（AFSIM 侧按平坦地面处理）',
    '山体对雷达视线的遮挡（对比时以「LASE 关闭 LOS 遮挡」为同假设基准）',
    '楼房掩体对雷达视线的遮挡',
    '20 名巡逻兵的地面交火与基地轰炸',
]


# --------------------------------------------------------------------------
# 坐标系换算
# --------------------------------------------------------------------------
def xy_to_latlon(x: float, y: float) -> Tuple[float, float]:
    """LASE 平面坐标（米）-> (纬度, 经度)。"""
    return LAT0 + float(y) / M_PER_DEG_LAT, LON0 + float(x) / M_PER_DEG_LON


def latlon_to_xy(lat: float, lon: float) -> Tuple[float, float]:
    """(纬度, 经度) -> LASE 平面坐标（米）。"""
    return (float(lon) - LON0) * M_PER_DEG_LON, (float(lat) - LAT0) * M_PER_DEG_LAT


def _pos(x: float, y: float, z: float) -> str:
    """生成 AFSIM ``position`` 片段（北纬 / 西经 + 海拔米）。"""
    lat, lon = xy_to_latlon(x, y)
    return 'position %.8fn %.8fw altitude %.2f m msl' % (lat, abs(lon), float(z))


def _num(v: float) -> str:
    """脚本 / 命令里的数值字面量（固定小数，不用科学计数法）。"""
    return ('%.6f' % float(v)).rstrip('0').rstrip('.') or '0.0'


# --------------------------------------------------------------------------
# 引擎探测
# --------------------------------------------------------------------------
def _parse_list_block(lines: Sequence[str], idx: int) -> List[str]:
    """解析自检输出里「Plugins Loaded: / Extensions Included:」后的列表。

    实测 2.9.0 把整张列表压在冒号同一行（逗号分隔），旧版本则是后续若干
    缩进行，两种排布都要能读，否则插件数会误报成 0。
    """
    head = lines[idx].split(':', 1)[1].strip()
    parts = [head] if head else []
    if not head:
        j = idx + 1
        while j < len(lines) and lines[j].strip() and lines[j][:1] in (' ', '\t'):
            parts.append(lines[j].strip())
            j += 1
    joined = ' '.join(parts)
    return [p.strip() for p in joined.split(',') if p.strip()]


class AfsimEngine:
    """一只 AFSIM 2.9 安装（``bin/mission.exe`` 为唯一必需入口）。"""

    def __init__(self, root: Optional[str] = None):
        raw = root or os.environ.get('LASE_AFSIM_ROOT') or DEFAULT_AFSIM_ROOT
        self.root = Path(raw).resolve()
        self.bin_dir = self.root / 'bin'
        self.exe = self.bin_dir / 'mission.exe'
        self.warlock = self.bin_dir / 'warlock.exe'
        self._info: Optional[dict] = None

    def available(self) -> bool:
        return self.exe.is_file()

    def info(self, refresh: bool = False) -> dict:
        """引擎元信息（版本 / 构建时间 / 插件列表），结果缓存。"""
        if self._info is not None and not refresh:
            return dict(self._info)
        meta = {
            'available': self.available(),
            'root': str(self.root),
            'exe': str(self.exe),
            'warlock': self.warlock.is_file(),
            'version': None,
            'built': None,
            'plugins': [],
            'extensions': [],
            'reason': '',
        }
        if not meta['available']:
            meta['reason'] = '未找到 %s' % self.exe
            self._info = meta
            return dict(meta)
        try:
            out = subprocess.run([str(self.exe), '--help'], cwd=str(self.bin_dir),
                                 capture_output=True, text=True, timeout=60,
                                 errors='replace')
            text = (out.stdout or '') + (out.stderr or '')
            lines = text.splitlines()
            for i, line in enumerate(lines):
                s = line.strip()
                if s.startswith('WSF Version:'):
                    meta['version'] = s.split(':', 1)[1].strip()
                elif s.startswith('Built:'):
                    meta['built'] = s.split(':', 1)[1].strip()
                elif s.startswith('Plugins Loaded:'):
                    meta['plugins'] = _parse_list_block(lines, i)
                elif s.startswith('Extensions Included:'):
                    meta['extensions'] = _parse_list_block(lines, i)
        except Exception as exc:                       # pragma: no cover - 环境相关
            meta['reason'] = '引擎自检失败：%s' % exc
        self._info = meta
        return dict(meta)


# --------------------------------------------------------------------------
# 想定生成
# --------------------------------------------------------------------------
def _scan_block(names: Sequence[str], *, ring_range: float, vert_tan: float,
                forward_deg: Optional[float] = None,
                var: str = 'bestRange', name_var: str = 'bestName') -> List[str]:
    """生成「逐个候选目标找最近可交战者」的 AFSIM 脚本片段。

    ``forward_deg`` 为 None 时是全向判定（防空车）；给定时额外要求目标落在
    机头 ±forward_deg 内（直升机前向锥）。
    """
    out: List[str] = []
    for i, nm in enumerate(names):
        v = 'c%d' % i
        out.append('         WsfPlatform %s = WsfSimulation.FindPlatform("%s");' % (v, nm))
        out.append('         if (%s.IsValid() && %s.DamageFactor() < 1.0)' % (v, v))
        out.append('         {')
        # WSF 脚本没有 sqrt()；水平距离直接用引擎自带的 GroundRangeTo（米）
        out.append('            double dz%d = %s.Altitude() - PLATFORM.Altitude();' % (i, v))
        out.append('            if (dz%d < 0.0) { dz%d = -dz%d; }' % (i, i, i))
        out.append('            double gr%d = PLATFORM.GroundRangeTo(%s);' % (i, v))
        cond = 'gr%d < %s && dz%d <= (gr%d + 1.0) * %s' % (i, _num(ring_range), i, i, _num(vert_tan))
        if forward_deg is not None:
            cond += (' && PLATFORM.RelativeBearingTo(%s) <= %s'
                     ' && PLATFORM.RelativeBearingTo(%s) >= -%s'
                     % (v, _num(forward_deg), v, _num(forward_deg)))
        out.append('            if (%s)' % cond)
        out.append('            {')
        out.append('               if (gr%d < %s) { %s = gr%d; %s = "%s"; }'
                   % (i, var, var, i, name_var, nm))
        out.append('            }')
        out.append('         }')
    return out


def _alert_block(names: Sequence[str], radar_name: str, radius: float) -> List[str]:
    """雷达预警判定：任一存活蓝方目标进入雷达半径即返回 alerted。"""
    out: List[str] = []
    out.append('         WsfPlatform rd = WsfSimulation.FindPlatform("%s");' % radar_name)
    out.append('         bool alerted = false;')
    for i, nm in enumerate(names):
        v = 'a%d' % i
        out.append('         WsfPlatform %s = WsfSimulation.FindPlatform("%s");' % (v, nm))
        out.append('         if (%s.IsValid() && %s.DamageFactor() < 1.0)' % (v, v))
        out.append('         {')
        out.append('            if (rd.GroundRangeTo(%s) < %s) { alerted = true; }'
                   % (v, _num(radius)))
        out.append('         }')
    return out


def _route_block(points: Sequence[Tuple[float, float, float]], speed: float) -> List[str]:
    """航路：``points`` = [(x, y, z), ...]；首点带速度，末点之后保持直飞。"""
    out: List[str] = ['   route']
    for i, (x, y, z) in enumerate(points):
        item = '      ' + _pos(x, y, z)
        if i == 0:
            item += ' speed %.2f m/s' % speed
        out.append(item)
    out.append('   end_route')
    return out


def build_scenario(cfg, waypoints, inf_waypoints=None, *, fid: int = 1,
                   case_label: str = '', seed: int = 20261018,
                   extra_note: str = '') -> str:
    """按 LASE 配置 + 决策航点生成完整 AFSIM 想定文本。

    ``waypoints``：形状 (n_drones, K, 3) 的地图坐标航点 (x, y, z)。
    ``inf_waypoints``：形状 (n_infantry, K, 2) 的地图坐标航点。
    """
    dt = float(getattr(cfg, 'dt', 0.25))
    n_steps = int(getattr(cfg, 'n_steps', 220))
    end_time = dt * n_steps
    tx, ty = tuple(getattr(cfg, 'target_pos', (820.0, 820.0)))
    sx, sy = tuple(getattr(cfg, 'start_pos', (60.0, 60.0)))
    max_alt = float(getattr(cfg, 'max_alt', 460.0))
    v_drone = float(cfg.drone_speed) / dt
    v_inf = float(cfg.infantry_speed) / dt
    v_heli = float(cfg.interceptor_speed) / dt
    v_aa = float(cfg.aa_speed) / dt
    aa_half_v = math.tan(float(getattr(cfg, 'aa_vert_half_angle', 1.0472)))
    heli_half_v = math.tan(float(getattr(cfg, 'intercept_vert_half_angle', 0.5236)))
    heli_fwd = math.degrees(float(getattr(cfg, 'intercept_half_angle', 0.5236)))
    climb = float(getattr(cfg, 'max_climb_rate', 25.0)) / dt

    blue = ['%s%d' % (BLUE_PREFIX, i + 1) for i in range(int(cfg.n_drones))]
    infs = ['%s%d' % (INF_PREFIX, i + 1) for i in range(int(cfg.n_infantry))]
    aaes = ['%s%d' % (AA_PREFIX, i + 1) for i in range(int(getattr(cfg, 'n_aa', 0)))]
    helis = ['%s%d' % (HELI_PREFIX, i + 1) for i in range(int(cfg.n_interceptors))]

    L: List[str] = []
    add = L.append
    add('# ' + '=' * 74)
    add('# LASE -> AFSIM 2.9 高保真复核想定（src/afsim_bridge.py 自动生成，勿手改）')
    add('# case   : %s' % (case_label or ('uav_intercept F%d' % fid)))
    add('# battle : %.0f x %.0f m, dt = %.3f s, steps = %d, end_time = %.2f s'
        % (cfg.map_w, cfg.map_h, dt, n_steps, end_time))
    add('# speeds : drone %.2f / infantry %.2f / aa %.2f / heli %.2f m/s'
        % (v_drone, v_inf, v_aa, v_heli))
    add('# engage : 2D 水平距离 + 垂直锥（沿用 LASE 判决规则，非 AFSIM 原生传感器判决）')
    if extra_note:
        add('# note   : %s' % extra_note)
    add('# ' + '=' * 74)
    add('')
    add('end_time %.2f sec' % end_time)
    add('random_seed %d' % int(seed))
    add('')
    for ln in ('event_output',
               '   file out/events.evt',
               '   enable PLATFORM_ADDED',
               '   enable PLATFORM_DELETED',
               '   enable PLATFORM_BROKEN',
               '   enable WEAPON_FIRED',
               '   enable WEAPON_HIT',
               '   enable WEAPON_MISSED',
               '   enable SENSOR_TRACK_INITIATED',
               'end_event_output',
               '',
               'weapon_effects LASE_BLAST WSF_SPHERICAL_LETHALITY',
               '   minimum_radius 0.10 m',
               '   maximum_radius %.2f m' % float(cfg.missile_radius),
               '   maximum_damage 1.00',
               '   minimum_damage 0.90',
               '   threshold_damage 0.00',
               '   exponent 1.00',
               'end_weapon_effects',
               ''):
        add(ln)

    # ---- 平台类型 -------------------------------------------------------
    add('platform_type LASE_DRONE WSF_PLATFORM')
    add('   icon uav')
    add('   side blue')
    add('   mover WSF_AIR_MOVER')
    add('      maximum_speed %.2f m/s' % max(v_drone * 1.4, v_drone + 10.0))
    add('      maximum_turn_rate %.2f deg/s' % math.degrees(cfg.drone_turn_rate / dt))
    add('      maximum_climb_rate %.2f m/s' % climb)
    add('   end_mover')
    add('end_platform_type')
    add('')
    add('platform_type LASE_INFANTRY WSF_PLATFORM')
    add('   side blue')
    add('   mover WSF_GROUND_MOVER')
    add('      maximum_speed %.2f m/s' % v_inf)
    add('   end_mover')
    add('end_platform_type')
    add('')

    add('platform_type LASE_AA WSF_PLATFORM')
    add('   side red')
    add('   sensor alert WSF_GEOMETRIC_SENSOR')
    add('      mode search')
    add('         frame_time %.2f sec' % dt)
    add('         platform_type default detection_range %.2f m' % math.hypot(float(cfg.aa_range), max_alt))
    add('         maximum_range %.2f m' % math.hypot(float(cfg.aa_range), max_alt))
    add('         azimuth_field_of_view -180 deg 180 deg')
    add('         elevation_field_of_view -89 deg 89 deg')
    add('      end_mode')
    add('   end_sensor')
    add('   weapon lase_sam WSF_IMPLICIT_WEAPON')
    add('      quantity 48')
    add('      weapon_effects LASE_BLAST')
    add('      update_interval %.2f sec' % dt)
    add('      firing_interval %.2f sec' % (float(cfg.aa_reload) * dt))
    add('   end_weapon')
    add('   processor engage WSF_SCRIPT_PROCESSOR')
    add('      update_interval %.2f sec' % dt)
    add('      on_update')
    add('         double bestRange = 1000000000.0;')
    add('         string bestName = "";')
    L.extend(_scan_block(blue, ring_range=float(cfg.aa_range), vert_tan=aa_half_v))
    add('         if (bestName != "")')
    add('         {')
    add('            WsfTrack tk = WsfTrack();')
    add('            tk.SetTarget(bestName);')
    add('            PLATFORM.Weapon("lase_sam").Fire(tk);')
    add('         }')
    add('      end_on_update')
    add('   end_processor')
    add('end_platform_type')
    add('')

    add('platform_type LASE_HELI WSF_PLATFORM')
    add('   icon helicopter')
    add('   side red')
    add('   mover WSF_AIR_MOVER')
    add('      maximum_speed %.2f m/s' % max(v_heli * 1.4, v_heli + 10.0))
    add('      maximum_turn_rate %.2f deg/s' % math.degrees(cfg.interceptor_turn_rate / dt))
    add('      maximum_climb_rate %.2f m/s' % climb)
    add('   end_mover')
    add('   weapon lase_sam WSF_IMPLICIT_WEAPON')
    add('      quantity 48')
    add('      weapon_effects LASE_BLAST')
    add('      update_interval %.2f sec' % dt)
    add('      firing_interval %.2f sec' % (float(cfg.aa_reload) * dt))
    add('   end_weapon')
    add('   processor pilot WSF_SCRIPT_PROCESSOR')
    add('      update_interval %.2f sec' % dt)
    add('      on_update')
    add('         # 雷达捕获后才起飞，随后逐帧追击最近的存活目标')
    L.extend(_alert_block(blue, RADAR_NAME, float(cfg.radar_range)))
    add('         double bestRange = 1000000000.0;')
    add('         string bestName = "";')
    L.extend(_scan_block(blue, ring_range=float(cfg.intercept_radius), vert_tan=heli_half_v,
                         forward_deg=heli_fwd))
    add('         if (alerted && bestName != "")')
    add('         {')
    add('            WsfPlatform bt = WsfSimulation.FindPlatform(bestName);')
    add('            if (bt.IsValid())')
    add('            {')
    add('               PLATFORM.GoToLocation(bt.Latitude(), bt.Longitude(), bt.Altitude());')
    add('            }')
    add('            WsfTrack tk = WsfTrack();')
    add('            tk.SetTarget(bestName);')
    add('            PLATFORM.Weapon("lase_sam").Fire(tk);')
    add('         }')
    add('      end_on_update')
    add('   end_processor')
    add('end_platform_type')
    add('')

    # 预警雷达：注意 WSF_GEOMETRIC_SENSOR 只能在 platform_type 内定义，
    # 直接写在平台实例上会报 “Unknown sensor: <name>”。
    add('platform_type LASE_RADAR WSF_PLATFORM')
    add('   icon radar')
    add('   side red')
    add('   sensor watch WSF_GEOMETRIC_SENSOR')
    add('      mode search')
    add('         frame_time %.2f sec' % dt)
    add('         platform_type default detection_range %.2f m'
        % math.hypot(float(cfg.radar_range), max_alt))
    add('         maximum_range %.2f m' % math.hypot(float(cfg.radar_range), max_alt))
    add('         azimuth_field_of_view -180 deg 180 deg')
    add('         elevation_field_of_view -89 deg 89 deg')
    add('      end_mode')
    add('   end_sensor')
    add('end_platform_type')
    add('')

    # ---- 遥测记录器 -----------------------------------------------------
    # 同上：WSF_SCRIPT_PROCESSOR 也必须在 platform_type 内定义。
    add('platform_type LASE_CLOCK WSF_PLATFORM')
    add('   processor rec WSF_SCRIPT_PROCESSOR')
    add('      update_interval %.2f sec' % dt)
    add('      on_update')
    add('         double tt = TIME_NOW;')
    for _nm in blue + infs + aaes + helis:
        add('         WsfPlatform p = WsfSimulation.FindPlatform("%s");' % _nm)
        add('         if (p.IsValid())')
        add('         {')
        add('            writeln("TL,", tt, ",%s,", (p.Longitude() + %s) * %s, ",",'
            ' (p.Latitude() - %s) * %s, ",", p.Altitude(), ",", p.DamageFactor(),'
            ' ",", p.Speed());'
            % (_nm, _num(abs(LON0)), _num(M_PER_DEG_LON), _num(LAT0), _num(M_PER_DEG_LAT)))
        add('         }')
    add('      end_on_update')
    add('   end_processor')
    add('end_platform_type')
    add('')

    # ---- 实例：蓝方无人机 -----------------------------------------------
    wps = [[[float(v) for v in p] for p in w] for w in waypoints]
    z0 = float(wps[0][0][2]) if wps and wps[0] else max_alt * 0.6
    for name, route in zip(blue, wps):
        pts = [(sx, sy, z0)] + [(p[0], p[1], p[2]) for p in route] + [(tx, ty, float(route[-1][2]) if route else z0)]
        add('platform %s LASE_DRONE' % name)
        add('   side blue')
        L.extend(_route_block(pts, v_drone))
        add('end_platform')
        add('')

    # ---- 实例：蓝方步兵 -----------------------------------------------
    if inf_waypoints is not None:
        for name, route in zip(infs, inf_waypoints):
            pts = [(sx, sy, 0.0)] + [(float(p[0]), float(p[1]), 0.0) for p in route] + [(tx, ty, 0.0)]
            add('platform %s LASE_INFANTRY' % name)
            add('   side blue')
            L.extend(_route_block(pts, v_inf))
            add('end_platform')
            add('')

    # ---- 实例：红方防空车 / 直升机 / 雷达 -------------------------------
    for name, pos in zip(aaes, list(getattr(cfg, 'aa_pos', []))[:len(aaes)]):
        add('platform %s LASE_AA' % name)
        add('   side red')
        add('   ' + _pos(float(pos[0]), float(pos[1]), max(0.0, 2.0)))
        add('end_platform')
        add('')
    for name, pos in zip(helis, list(getattr(cfg, 'interceptor_pos', []))[:len(helis)]):
        add('platform %s LASE_HELI' % name)
        add('   side red')
        add('   ' + _pos(float(pos[0]), float(pos[1]), 20.0))
        add('end_platform')
        add('')
    rx, ry = tuple(getattr(cfg, 'radar_pos', (500.0, 500.0)))
    add('platform %s LASE_RADAR' % RADAR_NAME)
    add('   side red')
    add('   ' + _pos(float(rx), float(ry), 30.0))
    add('end_platform')
    add('')

    # ---- 遥测记录器实例 -------------------------------------------------
    # 记录器必须落在战场内：AFSIM 平台默认位置是 (0,0)（几内亚湾），
    # 若不给坐标，Warlock/Mystic 的 “Center on Scenario” 会把视角中心算到
    # (0,0) 与战场的连线中点，导致地图缩放到全球后看不出交战。
    add('platform %s LASE_CLOCK' % RECORDER_NAME)
    add('   side neutral')
    add('   ' + _pos(float(getattr(cfg, 'map_w', 1000.0)) * 0.5,
                       float(getattr(cfg, 'map_h', 1000.0)) * 0.5, 0.0))
    add('end_platform')
    add('')
    return '\n'.join(L) + '\n'


# --------------------------------------------------------------------------
# 运行与解析
# --------------------------------------------------------------------------
EVENT_KINDS = ('PLATFORM_ADDED', 'PLATFORM_DELETED', 'PLATFORM_BROKEN', 'WEAPON_FIRED',
               'WEAPON_HIT', 'WEAPON_MISSED', 'SENSOR_TRACK_INITIATED')


def run_scenario(text: str, work_dir, engine: Optional[AfsimEngine] = None,
                 timeout: float = 300.0) -> dict:
    """把想定写入 ``work_dir/input.txt`` 并 headless 跑一遍。"""
    engine = engine or AfsimEngine()
    if not engine.available():
        return {'ok': False, 'error': 'AFSIM 不可用：%s' % engine.info().get('reason', '')}
    wd = Path(work_dir)
    (wd / 'out').mkdir(parents=True, exist_ok=True)
    (wd / 'input.txt').write_text(text, encoding='utf-8', newline='\n')
    t0 = time.time()
    try:
        proc = subprocess.run([str(engine.exe), 'input.txt'], cwd=str(wd),
                              capture_output=True, text=True, timeout=timeout,
                              errors='replace')
        log = (proc.stdout or '') + (proc.stderr or '')
        rc = proc.returncode
    except subprocess.TimeoutExpired as exc:            # pragma: no cover
        log = 'AFSIM 运行超时（%.0f s）' % timeout
        rc = -1
    wall = time.time() - t0
    (wd / 'mission.log').write_text(log, encoding='utf-8', newline='\n')
    ok = ('Loading simulation input complete.' in log) and ('FATAL' not in log) and rc == 0
    return {'ok': ok, 'returncode': rc, 'wall_time_s': wall, 'log': log, 'work_dir': str(wd)}


def parse_telemetry(log_text: str) -> Dict[str, List[Tuple[float, float, float, float, float, float]]]:
    """解析 ``TL,<t>,<name>,<x>,<y>,<z>,<damage>,<speed>`` 遥测行。"""
    out: Dict[str, List[Tuple[float, float, float, float, float, float]]] = {}
    for line in log_text.splitlines():
        if not line.startswith('TL,'):
            continue
        parts = line.strip().split(',')
        if len(parts) < 8:
            continue
        try:
            rec = (float(parts[1]), float(parts[3]), float(parts[4]),
                   float(parts[5]), float(parts[6]), float(parts[7]))
        except ValueError:
            continue
        out.setdefault(parts[2], []).append(rec)
    return out


def parse_events(evt_path) -> List[dict]:
    """解析 AFSIM 事件输出（``<time> EVENT subject ...``）。"""
    events: List[dict] = []
    p = Path(evt_path)
    if not p.is_file():
        return events
    for line in p.read_text(encoding='utf-8', errors='replace').splitlines():
        toks = line.split()
        if len(toks) < 3:
            continue
        try:
            t = float(toks[0])
        except ValueError:
            continue
        if toks[1] not in EVENT_KINDS:
            continue
        events.append({'t': t, 'event': toks[1], 'subject': toks[2],
                       'target': toks[3] if len(toks) > 3 else ''})
    return events


def compute_metrics(frames, events, cfg, end_time: float, fid: int = 1) -> dict:
    """按 LASE 的口径从 AFSIM 真实轨迹/事件复算空情指标。"""
    blue = ['%s%d' % (BLUE_PREFIX, i + 1) for i in range(int(cfg.n_drones))]
    tx, ty = tuple(cfg.target_pos)
    radius = float(cfg.target_radius)
    killed = {e['subject']: e['t'] for e in events
              if e['event'] == 'PLATFORM_BROKEN' and e['subject'] in blue}
    n_fired = sum(1 for e in events if e['event'] == 'WEAPON_FIRED')
    n_hit = sum(1 for e in events if e['event'] == 'WEAPON_HIT')
    n_tracks = sum(1 for e in events if e['event'] == 'SENSOR_TRACK_INITIATED')

    n_arrived = 0
    path_length = 0.0
    min_dist = float('inf')
    nofly_steps = 0
    bounds_steps = 0
    terminal: Dict[str, float] = {}
    for name in blue:
        seq = frames.get(name, [])
        prev = None
        arrive_t = None
        for (t, x, y, z, dmg, _sp) in seq:
            alive = dmg < 1.0
            dist = math.hypot(x - tx, y - ty)
            if alive:
                min_dist = min(min_dist, dist)
                if dist <= radius and arrive_t is None:
                    arrive_t = t
                if prev is not None and prev[4] < 1.0:
                    path_length += math.hypot(x - prev[1], y - prev[2])
                if not (0.0 <= x <= cfg.map_w and 0.0 <= y <= cfg.map_h):
                    bounds_steps += 1
                for zone in getattr(cfg, 'no_fly_zones', []) or []:
                    cx, cy, cz, rr = (float(v) for v in zone[:4])
                    if math.hypot(x - cx, y - cy) <= rr and abs(z - cz) <= rr:
                        nofly_steps += 1
                        break
            prev = (t, x, y, z, dmg, _sp)
        if arrive_t is not None and name not in killed:
            n_arrived += 1
            terminal[name] = arrive_t
        elif name in killed:
            terminal[name] = killed[name]
        elif seq:
            terminal[name] = seq[-1][0]

    flight_time = max(terminal.values()) if terminal else 0.0
    n_lost = len(killed)
    return {
        'n_arrived': int(n_arrived),
        'n_lost': int(n_lost),
        'n_fired': int(n_fired),
        'n_hit': int(n_hit),
        'n_sensor_tracks': int(n_tracks),
        'nofly_steps': int(nofly_steps),
        'bounds_steps': int(bounds_steps),
        'path_length': round(float(path_length), 1),
        'min_dist': round(float(min_dist), 1) if min_dist != float('inf') else None,
        'flight_time_s': round(float(flight_time), 3),
        'frames': int(sum(len(v) for v in frames.values())),
    }


# --------------------------------------------------------------------------
# 高层入口：加载一局 LASE 解 -> AFSIM 复核 -> 并排对比
# --------------------------------------------------------------------------
DEFAULT_CASE_ROOT = ROOT / 'results' / 'apps' / 'raw' / 'uav_intercept' / 'D30'
DEFAULT_OUT_ROOT = ROOT / 'results' / 'apps' / 'afsim_check'


def list_cases(results_root=None, fid: Optional[int] = None,
               limit: Optional[int] = None) -> List[dict]:
    """列出可复核的 LASE 存档局（按任务 / 宿主 / run 排序）。"""
    root = Path(results_root or DEFAULT_CASE_ROOT)
    items: List[dict] = []
    if not root.is_dir():
        return items
    for path in sorted(root.glob('*__F*.json')):
        host, _, tail = path.stem.rpartition('__F')
        try:
            ffid = int(tail)
        except ValueError:
            continue
        if fid is not None and ffid != int(fid):
            continue
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        runs = data.get('runs') or []
        arms = [a for a in (data.get('arms') or ['bare', 'full'])
                if any(r.get(a) for r in runs)]
        items.append({
            'host': data.get('host', host),
            'fid': ffid,
            'runs': len(runs),
            'arms': arms,
            'max_evals': data.get('max_evals'),
            'file': str(path),
        })
    items.sort(key=lambda d: (d['fid'], d['host']))
    return items[:int(limit)] if limit else items


def load_case(host: str, fid: int = 1, run: int = 0, arm: str = 'full',
              results_root=None) -> dict:
    """从 ``results/apps/raw/uav_intercept/D30`` 取一局的决策向量与内置指标。"""
    root = Path(results_root or DEFAULT_CASE_ROOT)
    path = root / ('%s__F%d.json' % (host, int(fid)))
    if not path.is_file():
        raise FileNotFoundError('找不到结果文件：%s' % path)
    data = json.loads(path.read_text(encoding='utf-8'))
    runs = data.get('runs') or []
    if not (0 <= int(run) < len(runs)):
        raise IndexError('%s 只有 %d 个 run，请求 run=%s' % (path.name, len(runs), run))
    rec = runs[int(run)].get(arm) or {}
    best_x = rec.get('best_x')
    if not best_x:
        raise ValueError('%s run=%s arm=%s 没有 best_x' % (path.name, run, arm))
    metrics = rec.get('metrics') or {}
    return {
        'host': data.get('host', host),
        'fid': int(fid),
        'run': int(run),
        'arm': arm,
        'seed': int(rec.get('seed') or runs[int(run)].get('seed') or 0),
        'max_evals': rec.get('max_evals'),
        'nevals': rec.get('nevals'),
        'err_final': rec.get('err_final'),
        'best_x': [float(v) for v in best_x],
        'lase_metrics': metrics,
        'file': str(path),
    }


def _lase_problem(fid: int, seed: int):
    """构造 LASE 内置问题（intercept 固定战场布局，seed 决定山地与散布）。"""
    sys.path.insert(0, str(ROOT / 'src'))
    from uav_adversarial import get_uav_problem          # noqa: WPS433 (延迟导入)
    return get_uav_problem('intercept', fid=int(fid), seed=int(seed))


def run_case(best_x, fid: int = 1, seed: int = 0, *, problem=None,
             work_dir=None, engine: Optional[AfsimEngine] = None,
             case_label: str = '', timeout: float = 600.0,
             compare: bool = True, keep: bool = True) -> dict:
    """把一局 LASE 解送进 AFSIM 跑一遍，返回遥测 / 事件 / 指标 / 对比。"""
    import numpy as np                                    # 局部导入，保持 CLI 轻量

    problem = problem or _lase_problem(fid, seed)
    cfg = problem.env.cfg
    x = np.asarray(best_x, dtype=float).ravel()
    waypoints = problem.decode(x)
    inf_waypoints = problem.decode_infantry(x) if int(cfg.n_infantry) > 0 else None
    text = build_scenario(cfg, waypoints, inf_waypoints, fid=int(fid),
                          case_label=case_label, seed=int(seed))
    wd = Path(work_dir or (DEFAULT_OUT_ROOT / (case_label or ('F%d' % int(fid)))))
    res = run_scenario(text, wd, engine=engine, timeout=timeout)
    out = {
        'ok': False,
        'case': case_label,
        'fid': int(fid),
        'seed': int(seed),
        'work_dir': str(wd),
        'scenario': str(wd / 'input.txt'),
        'engine': engine.info() if engine else AfsimEngine().info(),
        'geometry': _geometry(cfg),
        'not_modeled': list(NOT_MODELED),
    }
    if not res['ok']:
        out['error'] = (res['log'] or 'AFSIM 运行失败').strip().splitlines()[-1:]
        out['log_tail'] = (res['log'] or '').strip().splitlines()[-20:]
        return out

    frames = parse_telemetry(res['log'])
    events = parse_events(wd / 'out' / 'events.evt')
    end_time = float(getattr(cfg, 'dt', 0.25)) * int(getattr(cfg, 'n_steps', 220))
    metrics = compute_metrics(frames, events, cfg, end_time, fid=int(fid))

    lase = lase_flat = None
    if compare:
        lase = _evaluate(problem, x)
        # 同假设臂：AFSIM 侧没有三维地形/山体遮挡，这里关掉 LASE 的 LOS 遮挡
        # 再重放同一解，作为「桥接是否忠实」的基准。
        saved = bool(getattr(problem.env.cfg, 'los_block', False))
        try:
            problem.env.cfg.los_block = False
            lase_flat = _evaluate(problem, x)
        finally:
            problem.env.cfg.los_block = saved

    out.update({
        'ok': True,
        'returncode': res['returncode'],
        'wall_time_s': round(res['wall_time_s'], 3),
        'metrics': metrics,
        'lase': lase,
        'lase_flat': lase_flat,
        'comparison': compare_table(lase, lase_flat, metrics, cfg) if lase else [],
        'events': events,
        'telemetry': {k: v for k, v in frames.items()},
        'log_tail': (res['log'] or '').strip().splitlines()[-8:],
    })
    if not keep:
        out['telemetry'] = {}
    blob = wd / 'afsim_check.json'
    try:
        blob.write_text(json.dumps(_jsonable(out), ensure_ascii=False, indent=1),
                        encoding='utf-8', newline='\n')
    except OSError as exc:                                # pragma: no cover
        out['write_error'] = str(exc)
    return out


def _geometry(cfg) -> dict:
    """给前端画战场用的几何（与 LASE 同一坐标系：米，左下原点）。"""
    zones = []
    for z in (getattr(cfg, 'no_fly_zones', None) or []):
        try:
            if isinstance(z, dict):
                zones.append({'kind': z.get('kind', 'rect'),
                              'x': float(z.get('x', 0.0)), 'y': float(z.get('y', 0.0)),
                              'w': float(z.get('w', 0.0)), 'h': float(z.get('h', 0.0))})
            else:
                zones.append({'kind': 'rect', 'x': float(z[0]), 'y': float(z[1]),
                              'w': float(z[2]) - float(z[0]),
                              'h': float(z[3]) - float(z[1])})
        except (TypeError, ValueError, IndexError):
            continue
    sx, sy = tuple(getattr(cfg, 'start_pos', (60.0, 60.0)))
    tx, ty = tuple(getattr(cfg, 'target_pos', (820.0, 820.0)))
    rx, ry = tuple(getattr(cfg, 'radar_pos', (500.0, 500.0)))
    return {
        'map': [float(cfg.map_w), float(cfg.map_h)],
        'start': [float(sx), float(sy)],
        'target': [float(tx), float(ty)],
        'target_radius': float(getattr(cfg, 'target_radius', 55.0)),
        'base_radius': float(getattr(cfg, 'base_radius', 55.0)),
        'aa': [[float(p[0]), float(p[1])] for p in (getattr(cfg, 'aa_pos', None) or [])],
        'aa_range': float(getattr(cfg, 'aa_range', 0.0)),
        'heli': [[float(p[0]), float(p[1])] for p in (getattr(cfg, 'interceptor_pos', None) or [])],
        'radar': [float(rx), float(ry)],
        'radar_range': float(getattr(cfg, 'radar_range', 0.0)),
        'no_fly_zones': zones,
        'alt_max': float(getattr(cfg, 'max_alt', 460.0)),
    }


def _evaluate(problem, x) -> dict:
    """跑一次 LASE 内置引擎并整理成可比指标。"""
    cost, _state, m = problem.evaluate(x)
    dt = float(getattr(problem.env.cfg, 'dt', 0.25))
    return {
        'cost': round(float(cost), 3),
        'n_arrived': int(m.get('n_arrived', 0)),
        'n_lost': int(m.get('n_lost', 0)),
        'path_length': round(float(m.get('path_length', 0.0)), 1),
        'flight_time_s': round(float(m.get('flight_time', 0.0)) * dt, 3),
        'min_dist': round(float(m.get('min_dist', 0.0)), 1),
        'nofly_steps': int(m.get('nofly_steps', 0)),
        'raw': m,
    }


def compare_table(lase: dict, lase_flat: Optional[dict], afsim: dict, cfg) -> List[dict]:
    """三列对比：LASE 原始 / LASE 同假设（无遮挡） / AFSIM 真实运行。"""
    rows = []

    def add(name, unit, a, b, c, better, note=''):
        rows.append({
            'metric': name, 'unit': unit,
            'lase': a, 'lase_flat': b, 'afsim': c,
            'delta': None if c is None or b is None else round(float(c) - float(b), 2),
            'better': better, 'note': note,
        })

    def pick(key):
        return (lase.get(key) if lase else None,
                lase_flat.get(key) if lase_flat else None,
                afsim.get(key))

    add('n_arrived', '架', *pick('n_arrived'), 'high', '到达目标区的无人机数')
    add('n_lost', '架', *pick('n_lost'), 'low', '被拦截击落的无人机数')
    add('path_length', 'm', *pick('path_length'), 'low', '存活段累计航程')
    add('flight_time', 's', *pick('flight_time_s'), 'low', '编队终态时刻')
    add('min_dist', 'm', *pick('min_dist'), 'high', '最近接近目标区距离')
    add('nofly_steps', '帧', *pick('nofly_steps'), 'low', '禁飞区侵入帧数')
    add('n_fired', '发', None, None, afsim.get('n_fired'), 'none', '仅 AFSIM 侧有真实武器事件')
    add('n_hit', '发', None, None, afsim.get('n_hit'), 'none', '仅 AFSIM 侧有真实命中事件')
    add('n_sensor_tracks', '条', None, None, afsim.get('n_sensor_tracks'), 'none',
        'AFSIM 原生传感器航迹（几何传感器，仅机型标识用）')
    return rows


def _jsonable(obj):
    """把 numpy 标量 / 长列表压成可 JSON 化的结构。"""
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, float):
        return None if obj != obj else round(obj, 6)          # NaN -> null
    if hasattr(obj, 'item'):
        return obj.item()
    return obj


# --------------------------------------------------------------------------
# CLI：python src/afsim_bridge.py --host CoBiDE --fid 1 --run 0
# --------------------------------------------------------------------------
def _fmt_table(rows: List[dict]) -> str:
    head = ('| %-14s | %-4s | %12s | %12s | %12s | %10s |'
            % ('指标', '单位', 'LASE 原始', 'LASE 无遮挡', 'AFSIM 2.9', 'Δ(AFSIM-无遮挡)'))
    sep = '|' + '-' * 16 + '|' + '-' * 6 + '|' + '-' * 14 + '|' + '-' * 14 + '|' + '-' * 14 + '|' + '-' * 22 + '|'
    lines = [head, sep]

    def cell(v):
        return '—' if v is None else ('%.3f' % v if isinstance(v, float) else str(v))

    for r in rows:
        lines.append('| %-14s | %-4s | %12s | %12s | %12s | %10s |'
                     % (r['metric'], r['unit'], cell(r['lase']), cell(r['lase_flat']),
                        cell(r['afsim']), cell(r['delta'])))
    return '\n'.join(lines)


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description='LASE 解 -> AFSIM 2.9 高保真复核')
    ap.add_argument('--host', default='CoBiDE', help='DE 宿主算法名（结果文件名前缀）')
    ap.add_argument('--fid', type=int, default=1, help='任务号（intercept 1..4）')
    ap.add_argument('--run', type=int, default=0, help='第几个 run（0 起）')
    ap.add_argument('--arm', default='full', choices=('bare', 'full'), help='实验臂')
    ap.add_argument('--results-root', default=None, help='UAV 结果 JSON 目录')
    ap.add_argument('--out', default=None, help='输出目录（默认 results/apps/afsim_check）')
    ap.add_argument('--timeout', type=float, default=600.0, help='单次 AFSIM 运行超时（秒）')
    ap.add_argument('--list', action='store_true', help='只列出可复核的局')
    args = ap.parse_args(list(argv) if argv is not None else None)

    engine = AfsimEngine()
    info = engine.info()
    print('AFSIM: %s' % ('可用 · %s' % info.get('version', '') if info.get('available')
                         else '不可用 · %s' % info.get('reason', '')))
    if args.list:
        for c in list_cases(args.results_root, fid=args.fid):
            print('%-22s F%d  runs=%d  arms=%s' % (c['host'], c['fid'], c['runs'],
                                                   ','.join(c['arms'])))
        return 0
    case = load_case(args.host, args.fid, args.run, args.arm, args.results_root)
    label = '%s_F%d_run%d_%s' % (case['host'], case['fid'], case['run'], case['arm'])
    out_dir = Path(args.out or DEFAULT_OUT_ROOT) / label
    res = run_case(case['best_x'], fid=case['fid'], seed=case['seed'],
                   work_dir=out_dir, engine=engine, case_label=label,
                   timeout=args.timeout)
    if not res['ok']:
        print('复核失败：%s' % res.get('error'))
        return 2
    print('想定：%s' % res['scenario'])
    print('引擎耗时 %.2f s，遥测 %d 帧，事件 %d 条'
          % (res['wall_time_s'], res['metrics']['frames'], len(res['events'])))
    print()
    print(_fmt_table(res['comparison']))
    print()
    print('未建模（不参与对比）：%s' % '；'.join(res['not_modeled']))
    print('对比结果：%s' % (out_dir / 'afsim_check.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())


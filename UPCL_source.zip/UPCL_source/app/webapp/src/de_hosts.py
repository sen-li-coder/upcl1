# -*- coding: utf-8 -*-
"""
DE Host Algorithm Implementations:
- Classical DE/rand/1
- JADE (Adaptive DE with optional external archive)
- SHADE (Success-History based parameter Adaptation for DE)
- L-SHADE (SHADE with Linear population size Reduction)
- CoBiDE (Crossover-Binary Differential Evolution)
- jSO (improved SHADE variant with additional mechanisms)

Each host algorithm exposes a uniform lifecycle with hook points:
    1. init(P0, f(P0))
    2. for each generation g:
       a. gen_begin_hook(pop, fitness)               -- external layer refreshes context
       b. sample_params(i) -> (F, CR)                -- host produces raw parameters
       c. mutate(i, strategy_id, F, archive) -> v_i
       d. crossover(x_i, v_i, CR) -> u_i
       e. proposal_hook(x_i, u_i, f_i) -> u_i'       -- external proposal correction
       f. evaluate(u_i')                             -- ONE evaluation, as in the host
       g. post_eval_hook(f_new)                      -- response feedback to the layer
       h. selection -> accept/reject
       i. host memory update (F, CR, archive)        -- never touched by the layer

The three external hooks are the complete interface of the Universal Proposal
Correction Layer (UPCL).  They expose only the target vector, the candidate
proposal, and the resulting scalar response -- never F, CR, the archive, the
strategy id, or any host-side success memory.
"""

import numpy as np
from abc import ABC, abstractmethod


# ===========================================================================
# Mutation strategy registry
# ===========================================================================
STRATEGY_RAND1 = "rand/1"
STRATEGY_CURRENT_TO_PBEST = "current-to-pbest"
STRATEGY_BEST2 = "best/2"
STRATEGY_CURRENT_TO_RAND = "current-to-rand"
STRATEGY_BEST1 = "best/1"
STRATEGY_RAND2 = "rand/2"
STRATEGY_CURRENT_TO_BEST1 = "current-to-best/1"
STRATEGY_EITHER_OR = "either-or"

STRATEGY_POOL = [STRATEGY_RAND1, STRATEGY_CURRENT_TO_PBEST, STRATEGY_BEST2, STRATEGY_CURRENT_TO_RAND]

# Optional observer for operator-behaviour analysis (default None => zero overhead).
# Signature: STEP_HOOK(strategy_id, idx, step_vector) called BEFORE bounce-back,
# where step_vector is the F-scaled differential contribution (v - base).
STEP_HOOK = None


_ARANGE_CACHE = {}


def _arange(n):
    """Cached ``np.arange(n)``: the mutation helper asks for it every call."""
    a = _ARANGE_CACHE.get(n)
    if a is None:
        a = np.arange(n)
        _ARANGE_CACHE[n] = a
    return a


def _clip_scalar(v, lo, hi):
    """np.clip for a Python/numpy scalar (np.clip costs ~1.5 us per call)."""
    if isinstance(v, (int, float, np.floating, np.integer)):
        return lo if v < lo else (hi if v > hi else v)
    return np.clip(v, lo, hi)


def strategy_mutate(strategy_id, idx, pop, fitness, F, lb, ub,
                    archive=None, pbest_idx=None, rng=None, best_idx=None):
    """Dispatch mutation strategies.

    Returns mutant vector v_i for individual idx.
    """
    rng = rng if rng is not None else np.random.default_rng()
    N = len(pop)
    D = pop.shape[1]

    # Helper: pick random indices; prefer distinct, fallback to with-replacement
    # if not enough.  The candidate set is built with numpy instead of a
    # Python comprehension (identical contents -> identical draws, this is the
    # hottest call of the whole loop).
    def _rand(n, exclude):
        if exclude:
            mask = np.ones(N, dtype=bool)
            mask[list(exclude)] = False
            candidates = np.flatnonzero(mask)
        else:
            candidates = _arange(N)
        if len(candidates) >= n:
            return list(rng.choice(candidates, size=n, replace=False))
        elif len(candidates) > 0:
            # Allow replacement to get exactly n draws
            return list(rng.choice(candidates, size=n, replace=True))
        else:
            # No candidates (degenerate), allow idx/best repeats
            return list(rng.integers(0, max(1, N), size=n))

    if strategy_id == STRATEGY_RAND1:
        a, b, c = _rand(3, {idx})
        v = pop[a] + F * (pop[b] - pop[c])
        step = v - pop[a]
    elif strategy_id == STRATEGY_CURRENT_TO_PBEST:
        p_idx = pbest_idx if pbest_idx is not None else np.argmin(fitness)
        # choose r1 != idx, r2 != idx from population U archive
        r1 = _rand(1, {idx, p_idx})[0]
        if archive is not None and len(archive) > 0:
            pool_ext = np.vstack([pop, np.array(archive)])
            idxs_ex = {idx, p_idx, r1}
            cand_ex = [j for j in range(len(pool_ext)) if j not in idxs_ex]
            if len(cand_ex) == 0:
                cand_ex = list(range(len(pool_ext)))
            r2_ex = rng.choice(cand_ex)
            xr2 = pool_ext[r2_ex]
        else:
            r2 = _rand(1, {idx, p_idx, r1})[0]
            xr2 = pop[r2]
        v = pop[idx] + F * (pop[p_idx] - pop[idx]) + F * (pop[r1] - xr2)
        step = v - pop[idx]
    elif strategy_id == STRATEGY_BEST2:
        b_idx = best_idx if best_idx is not None else np.argmin(fitness)
        picks = _rand(4, {idx, b_idx})
        r1, r2, r3, r4 = picks[0], picks[1], picks[2], picks[3]
        v = pop[b_idx] + F * (pop[r1] - pop[r2]) + F * (pop[r3] - pop[r4])
        step = v - pop[b_idx]
    elif strategy_id == STRATEGY_CURRENT_TO_RAND:
        picks = _rand(3, {idx})
        r1, r2, r3 = picks[0], picks[1], picks[2]
        k = rng.random()
        v = pop[idx] + k * (pop[r1] - pop[idx]) + F * (pop[r2] - pop[r3])
        step = v - pop[idx]
    elif strategy_id == STRATEGY_BEST1:
        b_idx = best_idx if best_idx is not None else np.argmin(fitness)
        r1, r2 = _rand(2, {idx, b_idx})
        v = pop[b_idx] + F * (pop[r1] - pop[r2])
        step = v - pop[b_idx]
    elif strategy_id == STRATEGY_RAND2:
        a, b, c, d, e = _rand(5, {idx})
        v = pop[a] + F * (pop[b] - pop[c]) + F * (pop[d] - pop[e])
        step = v - pop[a]
    elif strategy_id == STRATEGY_EITHER_OR:
        # Price/Storn/Lampinen either-or: DE/rand/1 with F, or the variant
        # scaled by K = 0.5(F+1).  The branch is drawn from rng, so the two
        # arms of a paired run draw the same sequence.
        a, b, c = _rand(3, {idx})
        if rng.random() < 0.4:
            v = pop[a] + F * (pop[b] - pop[c])
        else:
            K = 0.5 * (F + 1.0)
            v = pop[a] + K * (pop[b] + pop[c] - 2.0 * pop[a])
        step = v - pop[a]
    elif strategy_id == STRATEGY_CURRENT_TO_BEST1:
        b_idx = best_idx if best_idx is not None else np.argmin(fitness)
        r1, r2 = _rand(2, {idx, b_idx})
        v = pop[idx] + F * (pop[b_idx] - pop[idx]) + F * (pop[r1] - pop[r2])
        step = v - pop[idx]
    else:
        raise ValueError(f"Unknown strategy: {strategy_id}")

    # Operator-behaviour observer (F-scaled differential contribution, pre bounce-back)
    if STEP_HOOK is not None:
        STEP_HOOK(strategy_id, idx, step)

    # Box constraint handling: bounce back
    v = np.where(v < lb, 0.5 * (lb + pop[idx]), v)
    v = np.where(v > ub, 0.5 * (ub + pop[idx]), v)
    return v


# ===========================================================================
# Base DE class
# ===========================================================================
class DifferentialEvolution(ABC):
    """Abstract base class for all DE host algorithms."""

    name = "DE-base"

    def __init__(self, dim, lb, ub, pop_size=None, seed=None, **kwargs):
        self.dim = dim
        self.lb = np.asarray(lb, dtype=float)
        self.ub = np.asarray(ub, dtype=float)
        self.N = pop_size if pop_size is not None else 10 * dim
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self._ar = np.arange(dim)      # crossover mask, allocated once
        # Pop
        self.pop = None
        self.fitness = None
        self.best_idx = None
        # Host-owned archive (if supported)
        self.archive = []
        # Counters
        self.g = 0
        self.nevals = 0
        # Stagnation info (best-so-far plateau length)
        self.best_so_far = np.inf
        self.stagnation = 0
        # External proposal-correction interface (set by UPCL). All default no-op.
        self.gen_begin_fn = None   # (pop, fitness) -> None
        self.proposal_fn = None    # (x_i, u_i, f_i) -> u_i'   (before evaluation)
        self.post_eval_fn = None   # (f_new) -> None           (response feedback)
        # Per-individual strategy override (optional)
        self._strategies = None

        # --- Stagnation-triggered restart (an optional DE-level mechanism,
        # not a proposal correction).  Off by default so every host behaves
        # bit-for-bit as before unless a runner opts in via kwargs. ---------
        self.restart_enable = bool(kwargs.get('restart_enable', False))
        self.restart_window = int(kwargs.get('restart_window', 30))
        self.restart_frac = float(kwargs.get('restart_frac', 0.2))
        self.restart_keep_best = bool(kwargs.get('restart_keep_best', True))
        self.restart_count = 0
        self.restart_gens = []            # generation indices where it fired
        self.restart_evals = 0            # evaluations spent re-initialising
        self.restart_n_reset_total = 0

        # --- Eigen-guided mutation (EGM): mix a covariance-shaped search
        # direction (second-order statistic) into the DE mutation.  This is the
        # statistical-layer counterpart of the CMA-ES sampling term, orthogonal
        # to the F/CR adaptation / archive / LPSR that SHADE-family hosts
        # already implement.  Off by default so hosts stay bit-for-bit. -------
        self.eigen_enable = bool(kwargs.get('eigen_enable', False))
        self.eigen_alpha = float(kwargs.get('eigen_alpha', 0.5))
        self.eigen_prob = float(kwargs.get('eigen_prob', 0.5))
        self.eigen_every = int(kwargs.get('eigen_every', 5))
        self._eig_evec = None        # D x D eigenvectors (columns)
        self._eig_scale = None       # D  sqrt(eigenvalues), descending
        self._eig_ready = False
        self.eigen_applied = 0       # how many mutants got the guide term

    # ------------------------------------------------------------------
    # Core lifecycle
    # ------------------------------------------------------------------
    def initialize_population(self, fobj):
        self.pop = self.rng.uniform(self.lb, self.ub, size=(self.N, self.dim))
        self.fitness = np.array([fobj(x) for x in self.pop])
        self.nevals = self.N
        self.best_idx = int(np.argmin(self.fitness))
        self.best_so_far = self.fitness[self.best_idx]
        self.stagnation = 0
        self.g = 0

    def run(self, fobj, max_evals, callback=None, record_pop_every=0):
        self.initialize_population(fobj)
        conv_curve = [self.best_so_far]
        eval_points = [self.nevals]
        # 二维地形可视化：按代采样种群在 x1-x2 子空间上的投影（仅前两维），
        # 供 GUI 回放“种群收敛过程”。record_pop_every=0 时完全不记录（零开销）。
        self.pop_history = []
        if record_pop_every > 0:
            self.pop_history.append(
                {'g': int(self.g), 'nevals': int(self.nevals),
                 'pop': self.pop[:, :2].copy()})

        while self.nevals < max_evals:
            self._generation_step(fobj)
            self.g += 1
            # Stagnation-triggered restart: after a full generation with no
            # best improvement for ``restart_window`` consecutive generations,
            # re-spread the worst individuals to restore diversity.
            if self.restart_enable and self.stagnation >= self.restart_window:
                self._restart(fobj, max_evals)
            # Track convergence at coarse grain
            conv_curve.append(self.best_so_far)
            eval_points.append(self.nevals)
            if callback is not None:
                callback(self)
            if record_pop_every > 0 and self.g % record_pop_every == 0:
                self.pop_history.append(
                    {'g': int(self.g), 'nevals': int(self.nevals),
                     'pop': self.pop[:, :2].copy()})

        return self.best_so_far, self.pop[self.best_idx], np.array(conv_curve), np.array(eval_points)

    def _generation_step(self, fobj):
        """Execute one generation with the external proposal-correction hooks."""
        # (a) refresh the population-level context of the external layer
        if self.gen_begin_fn is not None:
            self.gen_begin_fn(self.pop, self.fitness)

        # Pre-compute pbest for current-to-pbest (JADE/SHADE style)
        pbest_idx = self._sample_pbest_indices()
        pbest_i = pbest_idx if not isinstance(pbest_idx, np.ndarray) else pbest_idx
        best_before = self.best_so_far

        for i in range(self.N):
            # Early exit if budget exhausted
            if self.nevals >= self._get_budget_ceiling():
                break

            # (b) host samples its own F, CR -- never observed by the layer
            F, CR = self._sample_params(i)
            F = _clip_scalar(F, 1e-4, 2.0)
            CR = _clip_scalar(CR, 0.0, 1.0)

            # (c) choose strategy id -- host-internal, never observed by the layer
            strategy_id = self._get_strategy(i, None)

            # (d) mutate with the host's own archive, if any
            effective_archive = self.archive if (self.archive is not None
                                                 and len(self.archive) > 0) else None
            v = strategy_mutate(
                strategy_id, i, self.pop, self.fitness, F,
                self.lb, self.ub,
                archive=effective_archive,
                pbest_idx=pbest_i[i] if isinstance(pbest_idx, np.ndarray) else pbest_idx,
                rng=self.rng,
                best_idx=self.best_idx,
            )

            # (d2) EIGEN-GUIDED MUTATION (optional, statistical layer): mix a
            # covariance-shaped direction into the mutant.  This happens inside
            # mutation, before the external proposal hook, and only when
            # enabled -- it is NOT a proposal correction.
            if self.eigen_enable:
                v = self._eigen_guide(v, i)

            # (e) crossover
            u = self._crossover(i, self.pop[i], v, CR)

            # (f) EXTERNAL PROPOSAL CORRECTION.
            # The layer sees only (x_i, u_i, f(x_i)) and returns u_i'. It never
            # sees F, CR, the archive or the strategy id, and it never writes
            # them back.
            if self.proposal_fn is not None:
                u = self.proposal_fn(self.pop[i], u, self.fitness[i])

            # (g) ONE evaluation -- identical accounting to the unmodified host
            fu = fobj(u)
            self.nevals += 1

            # (h) response feedback to the external layer
            if self.post_eval_fn is not None:
                self.post_eval_fn(fu)

            # (i) selection and host-owned bookkeeping.  The parent only has
            # to be copied when it is actually discarded into an archive.
            f_old = self.fitness[i]
            accepted = False
            if fu <= f_old:
                x_old = self.pop[i].copy()
                self.pop[i] = u
                self.fitness[i] = fu
                accepted = True
                # add discarded parent to host archive (optional)
                self._maybe_archive(x_old)

            self._update_memories(i, accepted, F, CR, fu, f_old)

            # Update best
            if self.fitness[i] < self.best_so_far:
                self.best_so_far = self.fitness[i]
                self.best_idx = i
                self.stagnation = 0
        # end for
        if self.best_so_far >= best_before:
            self.stagnation += 1
        self._generation_end_update()

    def _get_budget_ceiling(self):
        """Override for budget-early-exit support."""
        return 10 ** 18

    # ------------------------------------------------------------------
    # Default implementation hooks (override per algorithm)
    # ------------------------------------------------------------------
    @abstractmethod
    def _sample_params(self, i):
        """Return (F, CR) for individual i."""
        ...

    def _sample_pbest_indices(self):
        """Return single best index or per-ind array for current-to-pbest variants.
        Default: global best index."""
        return self.best_idx

    def _get_strategy(self, i, override):
        """Choose strategy id for individual i."""
        if self._strategies is not None and i < len(self._strategies):
            return self._strategies[i]
        if override and 'global_strategy' in override:
            return override['global_strategy']
        return STRATEGY_RAND1

    def _crossover(self, i, x, v, CR):
        """Default binomial crossover."""
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        """Update host success memories (JADE/SHADE)."""
        pass

    def _maybe_archive(self, x):
        """Add to archive with capacity limit."""
        pass

    def _generation_end_update(self):
        """Per-generation end bookkeeping (e.g., SHADE histogram, L-SHADE pop reduction)."""
        pass

    def _restart(self, fobj, max_evals):
        """Stagnation-triggered partial re-initialisation.

        Resets the ``restart_frac`` worst individuals (best kept) to uniform
        random points and re-evaluates them, spending the evaluation budget
        exactly like the normal loop does.  This restores the population
        spread -- and therefore the difference-vector amplitude -- that
        collapses when DE stalls inside a basin.
        """
        n_reset = max(1, int(round(self.restart_frac * self.N)))
        order = np.argsort(self.fitness)          # ascending; worst are last
        worst = order[-n_reset:]
        n_done = 0
        for j in worst:
            if self.restart_keep_best and j == self.best_idx:
                continue
            if self.nevals >= max_evals:
                break
            self.pop[j] = self.rng.uniform(self.lb, self.ub, size=self.dim)
            self.fitness[j] = fobj(self.pop[j])
            self.nevals += 1
            n_done += 1
        self.best_idx = int(np.argmin(self.fitness))
        self.best_so_far = self.fitness[self.best_idx]
        self.stagnation = 0
        self.restart_count += 1
        self.restart_gens.append(int(self.g))
        self.restart_evals += n_done
        self.restart_n_reset_total += n_done

    def _update_eigen(self):
        """Recompute the population covariance eigendecomposition.

        The eigenvector columns (sorted by descending eigenvalue) are the
        principal directions of the current population; ``_eig_scale`` holds the
        square roots of the eigenvalues, i.e. the natural length scale along
        each direction.  Together they sample the covariance-shaped Gaussian
        N(0, C), mirroring the CMA-ES sampling term inside a DE mutation.
        """
        if self.N < 2:
            self._eig_ready = False
            return
        X = self.pop - self.pop.mean(axis=0)
        C = (X.T @ X) / max(1, self.N - 1)
        w, V = np.linalg.eigh(C)          # ascending eigenvalues
        w = np.maximum(w, 0.0)
        order = np.argsort(w)[::-1]
        self._eig_evec = V[:, order]
        self._eig_scale = np.sqrt(w[order])
        self._eig_ready = True

    def _eigen_guide(self, v, i):
        """Add a covariance-shaped direction to mutant ``v`` (with bounce-back)."""
        if self.g % self.eigen_every == 0:
            self._update_eigen()
        if not self._eig_ready or self.rng.random() > self.eigen_prob:
            return v
        z = self.rng.standard_normal(self.dim)
        d_rot = self._eig_evec @ (self._eig_scale * z)
        v = v + self.eigen_alpha * d_rot
        self.eigen_applied += 1
        # Box handling identical to strategy_mutate's bounce-back.
        v = np.where(v < self.lb, 0.5 * (self.lb + self.pop[i]), v)
        v = np.where(v > self.ub, 0.5 * (self.ub + self.pop[i]), v)
        return v


# ===========================================================================
# 1. Classical DE/rand/1
# ===========================================================================
class ClassicDE(DifferentialEvolution):
    name = "DE/rand/1"

    def __init__(self, dim, lb, ub, pop_size=None, F=0.5, CR=0.9, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.F_fixed = F
        self.CR_fixed = CR

    def _sample_params(self, i):
        return self.F_fixed, self.CR_fixed

    def _get_strategy(self, i, override):
        if self._strategies is not None and i < len(self._strategies):
            return self._strategies[i]
        if override and 'global_strategy' in override:
            return override['global_strategy']
        return STRATEGY_RAND1


# ===========================================================================
# 2. JADE (Adaptive DE with optional archive)
# ===========================================================================
class JADE(DifferentialEvolution):
    name = "JADE"

    def __init__(self, dim, lb, ub, pop_size=None, c=0.1, p=0.05,
                 archive_rate=2.0, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.c = c
        self.p = p
        self.archive_max = int(self.N * archive_rate)
        # Means
        self.mu_F = 0.5
        self.mu_CR = 0.5
        # Archive
        self.archive = []

    def _sample_pbest_indices(self):
        # Per-individual: pick from top p*N randomly
        top_k = max(1, int(self.p * self.N))
        order = np.argsort(self.fitness)
        top_idx = order[:top_k]
        return self.rng.choice(top_idx, size=self.N, replace=True)

    def _sample_params(self, i):
        # Cauchy for F
        F = -1.0
        while F <= 0:
            F = self.mu_F + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1.0:
                F = 1.0
                break
        # Normal for CR
        CR = np.clip(self.rng.normal(self.mu_CR, 0.1), 0.0, 1.0)
        return F, CR

    def _crossover(self, i, x, v, CR):
        # Binomial
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            # Update means with Lehmer-style (JADE paper uses arithmetic mean of succ)
            # We cache in lists then update end of gen
            if not hasattr(self, '_sF'):
                self._sF, self._sCR = [], []
            self._sF.append(F)
            self._sCR.append(CR)
            # Add discarded to archive
            # NOTE: archive addition done in step via _maybe_archive (called before this)

    def _maybe_archive(self, x):
        self.archive.append(x.copy())
        if len(self.archive) > self.archive_max:
            self.archive.pop(self.rng.integers(0, len(self.archive)))

    def _get_strategy(self, i, override):
        # JADE core is current-to-pbest/1 with archive; allow override
        if self._strategies is not None and i < len(self._strategies):
            return self._strategies[i]
        if override and 'global_strategy' in override:
            return override['global_strategy']
        return STRATEGY_CURRENT_TO_PBEST

    def _generation_end_update(self):
        # Update mu_F, mu_CR using JADE rule (Lehmer mean for F, arithmetic for CR)
        if hasattr(self, '_sF') and len(self._sF) > 0:
            sF = np.array(self._sF)
            sCR = np.array(self._sCR)
            # Lehmer mean = mean(s^2)/mean(s)
            lehmer_F = np.mean(sF ** 2) / (np.mean(sF) + 1e-12)
            self.mu_F = (1 - self.c) * self.mu_F + self.c * lehmer_F
            self.mu_CR = (1 - self.c) * self.mu_CR + self.c * np.mean(sCR)
            self._sF, self._sCR = [], []


# ===========================================================================
# 3. SHADE (Success-History based parameter adaptation)
# ===========================================================================
class SHADE(DifferentialEvolution):
    name = "SHADE"

    def __init__(self, dim, lb, ub, pop_size=None, H=6, p=0.1,
                 archive_rate=2.0, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.H = H
        self.p = p
        self.M_F = np.full(H, 0.5)
        self.M_CR = np.full(H, 0.5)
        self.k = 0  # history pointer
        self.archive_max = int(self.N * archive_rate)
        self.archive = []

    def _sample_pbest_indices(self):
        top_k = max(2, int(self.p * self.N))
        order = np.argsort(self.fitness)
        top_idx = order[:top_k]
        return self.rng.choice(top_idx, size=self.N, replace=True)

    def _sample_params(self, i):
        r_idx = self.rng.integers(0, self.H)
        mu_F = self.M_F[r_idx]
        mu_CR = self.M_CR[r_idx]
        # Cauchy for F
        F = -1.0
        count = 0
        while F <= 0 and count < 20:
            F = mu_F + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1:
                F = 1
            count += 1
        if F <= 0:
            F = 0.5
        # Normal for CR
        CR = np.clip(self.rng.normal(mu_CR, 0.1), 0.0, 1.0)
        return F, CR

    def _get_strategy(self, i, override):
        if self._strategies is not None and i < len(self._strategies):
            return self._strategies[i]
        if override and 'global_strategy' in override:
            return override['global_strategy']
        return STRATEGY_CURRENT_TO_PBEST

    def _maybe_archive(self, x):
        self.archive.append(x.copy())
        if len(self.archive) > self.archive_max:
            self.archive.pop(self.rng.integers(0, len(self.archive)))

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            if not hasattr(self, '_sF'):
                self._sF, self._sCR, self._sdelta = [], [], []
            self._sF.append(F)
            self._sCR.append(CR)
            self._sdelta.append(max(0.0, f_old - fu))

    def _generation_end_update(self):
        # SHADE: weighted Lehmer mean using |delta_f| as weights, write M[k]
        if hasattr(self, '_sF') and len(self._sF) > 0:
            sF = np.array(self._sF)
            sCR = np.array(self._sCR)
            sW = np.array(self._sdelta, dtype=float)
            sW_sum = sW.sum()
            if sW_sum > 0:
                w = sW / sW_sum
                mean_wF = np.sum(w * sF)
                lehmer_F = np.sum(w * sF ** 2) / (mean_wF + 1e-12)
                mean_wCR = np.sum(w * sCR)
                self.M_F[self.k] = lehmer_F
                self.M_CR[self.k] = mean_wCR
            else:
                self.M_F[self.k] = np.mean(sF)
                self.M_CR[self.k] = np.mean(sCR)
            self.k = (self.k + 1) % self.H
            self._sF, self._sCR, self._sdelta = [], [], []


# ===========================================================================
# 4. L-SHADE (SHADE with Linear population size Reduction)
# ===========================================================================
class LSHADE(SHADE):
    name = "L-SHADE"

    def __init__(self, dim, lb, ub, pop_size=None, N_min=4, H=6,
                 p=0.11, archive_rate=2.6, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, H=H, p=p,
                         archive_rate=archive_rate, seed=seed, **kwargs)
        self.N_init = self.N
        self.N_min = max(4, N_min)

    def _generation_end_update(self):
        super()._generation_end_update()
        # Linear population size reduction rule
        # N_new = round((N_min - N_init)/MaxEval * nevals + N_init)
        # We need MaxEval; pass via state if known; otherwise defer
        if not hasattr(self, '_max_evals'):
            return
        ratio = self.nevals / self._max_evals
        N_new = int(round((self.N_min - self.N_init) * ratio + self.N_init))
        N_new = max(self.N_min, N_new)
        if N_new < self.N:
            # Keep best N_new individuals
            order = np.argsort(self.fitness)
            keep = order[:N_new]
            self.pop = self.pop[keep]
            self.fitness = self.fitness[keep]
            self.N = N_new
            self.best_idx = int(np.argmin(self.fitness))
            # Resize archive
            self.archive_max = int(self.N * 2.6)
            while len(self.archive) > self.archive_max:
                self.archive.pop(self.rng.integers(0, len(self.archive)))

    def run(self, fobj, max_evals, callback=None, record_pop_every=0):
        self._max_evals = max_evals
        return super().run(fobj, max_evals, callback, record_pop_every)


# ===========================================================================
# 5. CoBiDE (Crossover-Binary Differential Evolution)
# Uses a mixture of strategies (curr/1, rand/2, rand-to-best/2, best/2)
# with adaptive parameter control via memory similar to SHADE but 
# includes specific crossover bias (toward lower/upper bounds) and 
# bimodal F distribution.
# ===========================================================================
class CoBiDE(SHADE):
    name = "CoBiDE"

    def __init__(self, dim, lb, ub, pop_size=None, H=10, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, H=H, p=0.1,
                         archive_rate=2.0, seed=seed, **kwargs)
        # CoBiDE specific: strategy weights
        self.strategies = [
            STRATEGY_RAND1, STRATEGY_BEST2,
            STRATEGY_CURRENT_TO_PBEST, STRATEGY_CURRENT_TO_RAND,
        ]
        self.n_strat = len(self.strategies)
        self.prob_strat = np.ones(self.n_strat) / self.n_strat
        self._reward_S = [[0.0] for _ in range(self.n_strat)]
        # CR memory has two modes; F two modes (CoBiDE paper)
        self.mu_CR1 = 0.8
        self.mu_CR2 = 0.2
        self.mu_F1 = 0.65
        self.mu_F2 = 0.1
        self.ps = 0.5  # probability of choosing mode 1
        self.alpha = 0.1  # learning rate
        # Extra memory for strategy selection
        self._cur_strategy = []

    def _sample_params(self, i):
        # Bi-modal F, CR
        if self.rng.random() < self.ps:
            muF, muCR = self.mu_F1, self.mu_CR1
        else:
            muF, muCR = self.mu_F2, self.mu_CR2
        F = -1
        count = 0
        while F <= 0 and count < 20:
            F = muF + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1: F = 1
            count += 1
        if F <= 0: F = 0.5
        CR = np.clip(self.rng.normal(muCR, 0.1), 0, 1)
        return F, CR

    def _sample_strategy_idx(self):
        return self.rng.choice(self.n_strat, p=self.prob_strat)

    def _get_strategy(self, i, override):
        if self._strategies is not None and i < len(self._strategies):
            return self._strategies[i]
        if override and 'global_strategy' in override:
            return override['global_strategy']
        s = self._sample_strategy_idx()
        self._cur_strategy.append((i, s))
        return self.strategies[s]

    def _crossover(self, i, x, v, CR):
        # CoBiDE: biased crossover toward search space bounds with probability q
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        child = np.where(mask, v, x)
        # Add small bound bias (CoBiDE variant)
        q = 0.1 / D
        bb_mask = self.rng.random(D) < q
        child = np.where(bb_mask, np.where(self.rng.random(D) < 0.5, self.lb, self.ub), child)
        return child

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            # update bimodal means towards the good params
            delta = abs(f_old - fu)
            w = delta / (np.sum(np.abs(f_old - fu + 1e-12)) + 1e-12)
            if CR > 0.5:
                self.mu_CR1 = (1 - self.alpha) * self.mu_CR1 + self.alpha * CR
            else:
                self.mu_CR2 = (1 - self.alpha) * self.mu_CR2 + self.alpha * CR
            if F > 0.4:
                self.mu_F1 = (1 - self.alpha) * self.mu_F1 + self.alpha * F
            else:
                self.mu_F2 = (1 - self.alpha) * self.mu_F2 + self.alpha * F
            # update strategy rewards
            if self._cur_strategy:
                # find last matching idx for i (approx)
                for (idx_i, s) in reversed(self._cur_strategy):
                    if idx_i == i:
                        self._reward_S[s].append(delta + 1e-8)
                        break

    def _generation_end_update(self):
        # SHADE-like for M_F/M_CR (inherited but unused); focus on strategy probs
        # Strategy weight update from CoBiDE paper (proportional to cumulative reward with decay)
        totals = []
        for rewards in self._reward_S:
            if len(rewards) > 1:
                mean_r = np.mean(rewards[1:])
            else:
                mean_r = 1e-8
            totals.append(mean_r + 1e-8)
        # Reset rewards with memory decay
        self._reward_S = [[0.9 * r[0] if r else 0.0] for r in self._reward_S]
        t_sum = sum(totals)
        if t_sum > 0:
            # Smoothed update
            new_probs = np.array(totals) / t_sum
            self.prob_strat = 0.8 * self.prob_strat + 0.2 * new_probs
            # Ensure minimum probability
            self.prob_strat = np.clip(self.prob_strat, 0.05, None)
            self.prob_strat /= self.prob_strat.sum()
        self._cur_strategy = []


# ===========================================================================
# 6. jSO (improved SHADE variant with additional features from LSHADE)
# jSO was the winner of CEC2017 competition in its category.
# Key features: population size reduction, memory adaptation, current-to-pbest-w/archive,
# F/CR memory with initial values, pbest range scaling, archive size.
# ===========================================================================
class jSO(LSHADE):
    name = "jSO"

    def __init__(self, dim, lb, ub, pop_size=None, H=5,
                 archive_rate=2.0, seed=None, **kwargs):
        N_init = pop_size if pop_size is not None else int(25 * np.log(dim) * np.sqrt(dim))
        super().__init__(dim, lb, ub, pop_size=N_init, N_min=max(4, dim//2),
                         H=H, p=0.25, archive_rate=archive_rate, seed=seed, **kwargs)
        # jSO specific initial memory values (per CEC2017 paper)
        self.M_F = np.array([0.9, 0.9, 0.9, 0.9, 0.9], dtype=float)[:H]
        self.M_CR = np.array([0.9, 0.9, 0.9, 0.9, 0.9], dtype=float)[:H]
        if H != 5:
            self.M_F = np.full(H, 0.9)
            self.M_CR = np.full(H, 0.9)

    def _sample_params(self, i):
        r_idx = self.rng.integers(0, self.H)
        muF = self.M_F[r_idx]
        muCR = self.M_CR[r_idx]
        # jSO: F sampling with early-bias toward 0.7
        F = -1.0
        count = 0
        while F <= 0 and count < 30:
            F = muF + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1.2:
                F = 1.2
                break
            count += 1
        if F <= 0:
            F = 0.7
        # jSO: scale CR slightly down for later stage (handled via memory)
        CR = np.clip(self.rng.normal(muCR, 0.1), 0.0, 1.0)
        return F, CR


# ===========================================================================
# Helpers
# ===========================================================================
def _local_roughness(pop, fitness, k=None):
    """Compute per-individual local roughness via k-NN fitness variance.
    Returns normalized roughness per individual.
    """
    N, D = pop.shape
    if k is None:
        k = max(3, int(0.2 * N))
    k = min(k, N - 1)
    # Distance matrix
    X = pop
    # (N,D) -> (N,N) Euclidean
    diff = X[:, None, :] - X[None, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=2))
    np.fill_diagonal(dist, np.inf)
    # For each row, find k smallest distances indices
    order = np.argpartition(dist, k, axis=1)[:, :k]
    # Compute roughness for each i
    roughness = np.zeros(N)
    for i in range(N):
        nbrs = order[i]
        f_nbrs = fitness[nbrs]
        mean_f = np.mean(f_nbrs)
        roughness[i] = np.sqrt(np.mean((f_nbrs - mean_f) ** 2))
    # Normalize
    rmax = roughness.max()
    if rmax < 1e-30:
        return np.zeros(N)
    return roughness / (rmax + 1e-12)


# ===========================================================================
# Factory
# ===========================================================================
HOST_REGISTRY = {
    'DE/rand/1': ClassicDE,
    'JADE': JADE,
    'SHADE': SHADE,
    'L-SHADE': LSHADE,
    'CoBiDE': CoBiDE,
    'jSO': jSO,
}


def get_host(name, dim, lb, ub, seed=None, pop_size=None, **kwargs):
    cls = HOST_REGISTRY[name]
    return cls(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)


def get_all_host_names():
    return list(HOST_REGISTRY.keys())


if __name__ == '__main__':
    # Quick smoke test
    from benchmarks import get_benchmark
    func = get_benchmark('Sphere', 10)
    lb, ub = func.get_bounds()
    for name in get_all_host_names():
        rng = np.random.default_rng(0)
        alg = get_host(name, 10, lb, ub, seed=0)
        best_f, best_x, curve, evals = alg.run(func, max_evals=5000)
        print(f"{name:10s}: best_f={best_f:.4e}, #evals={evals[-1]}")

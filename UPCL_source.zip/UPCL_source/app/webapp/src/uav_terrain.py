# -*- coding: utf-8 -*-
"""三维地形基础设施（``Terrain`` / ``terrain_blocked``）。

这两个工具被 ``uav_swarm``（集群突防）与 ``uav_adversarial``（突防拦截）共用，
独立成模块以避免地形基础设施依附于任何具体场景。

约定：地形以三组数据描述 —— ``xs``（递增的 x 坐标）、``ys``（递增的 y
坐标）、``Z[j, i]``（高程，对应 ``ys[j]`` 与 ``xs[i]``），高程用双线性插值
取值；``terrain_blocked`` 沿三维视线等距采样，任一点低于地面高程即判定
遮挡（用于雷达 / 通信链路 LOS 判定）。

仅依赖 numpy。
"""

from __future__ import annotations

import numpy as np


class Terrain:
    """规则网格高程场：双线性插值查询任意 (x, y) 的地面高程。"""

    def __init__(self, xs, ys, Z):
        self.xs = np.asarray(xs, dtype=np.float64)
        self.ys = np.asarray(ys, dtype=np.float64)
        self.Z = np.asarray(Z, dtype=np.float64)
        self.x0, self.x1 = float(self.xs[0]), float(self.xs[-1])
        self.y0, self.y1 = float(self.ys[0]), float(self.ys[-1])
        self.dx = float(self.xs[1] - self.xs[0])
        self.dy = float(self.ys[1] - self.ys[0])
        z = self.Z[~np.isnan(self.Z)]
        self.z_min = float(z.min())
        self.z_max = float(z.max())

    def height(self, x, y):
        """返回 (x, y) 处的地面高程；越界返回 z_min，空洞按 z_min 兜底。"""
        x = float(x); y = float(y)
        if x < self.x0 or x > self.x1 or y < self.y0 or y > self.y1:
            return self.z_min
        i = int((x - self.x0) / self.dx)
        j = int((y - self.y0) / self.dy)
        i = max(0, min(i, len(self.xs) - 2))
        j = max(0, min(j, len(self.ys) - 2))
        fx = (x - self.xs[i]) / self.dx
        fy = (y - self.ys[j]) / self.dy
        z = (self.Z[j, i] * (1 - fx) * (1 - fy) + self.Z[j, i + 1] * fx * (1 - fy)
             + self.Z[j + 1, i] * (1 - fx) * fy + self.Z[j + 1, i + 1] * fx * fy)
        if np.isnan(z):
            z = self.z_min
        return float(z)

    def grid(self):
        """返回 (xs, ys, Z) 原始网格（供前端抽稀后绘制地形网格）。"""
        return self.xs, self.ys, self.Z

    def bounds(self):
        """返回 (x0, x1, y0, y1) 覆盖范围。"""
        return self.x0, self.x1, self.y0, self.y1


def terrain_blocked(terrain, p0, p1, n=64):
    """地形遮挡判断：三维视线任一点被地面高程截断则遮挡。

    ``p0`` / ``p1`` 为 ``(x, y, z)``，``n`` 为采样段数。用于雷达捕获与通信
    链路的视线（LOS）判定。
    """
    x0, y0, z0 = p0
    x1, y1, z1 = p1
    for k in range(1, n):
        t = k / n
        xi = x0 + (x1 - x0) * t
        yi = y0 + (y1 - y0) * t
        zi = z0 + (z1 - z0) * t
        if terrain.height(xi, yi) > zi:
            return True
    return False

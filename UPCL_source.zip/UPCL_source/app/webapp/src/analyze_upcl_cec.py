# -*- coding: utf-8 -*-
"""Analysis of the CEC experiments: Exp1 - Exp6.

Reads whatever is in ``results/cec/raw`` and writes CSV tables to
``results/cec/tables`` and figures to ``results/cec/figures``.  It is
idempotent and safe to re-run after a partial experiment.

Statistical conventions
-----------------------
* primary effect size: ``dec = log10(err_bare) - log10(err_upcl)`` of the
  run medians, floored at 1e-8 -- a percentage is not interpretable when the
  optimum is zero;
* per-cell significance: paired Wilcoxon signed-rank over the 30 runs;
* multiplicity: Holm across all cells of one (suite, dimension) block;
* overall: Friedman / Iman-Davenport with mean ranks;
* Win / Tie / Loss: a win is a cell where UPCL is better *and* the Holm-adjusted
  test rejects; a loss is the same in the other direction; everything else is
  a tie.
"""
import csv
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                    # noqa: E402
import de_hosts_cec as DHC                                 # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
# 多用户隔离：跟随 run_upcl_cec.py 的 UPCL_OUT_DIR 环境变量，读写同一用户目录
_OUT_ENV = os.environ.get('UPCL_OUT_DIR')
_BASE = Path(_OUT_ENV) if _OUT_ENV else (ROOT / 'results' / 'cec')
RAW = _BASE / 'raw'
TAB = _BASE / 'tables'
FIG = _BASE / 'figures'
FLOOR = 1e-8
ALPHA = 0.05
# reference value per (suite, dim, fid), subtracted from every error; see
# ``reference``.  ``None`` means "raw errors", which is only safe when every
# function's declared optimum is a true lower bound of its landscape.
REF = None
# Order of the five descriptor components of the proposal-level descriptor.
DESC_NAMES = ['rho_step', 'theta_align', 'eta_elite', 'kappa_crowd', 'nu_novel']

# D=50 于 2026-10-22 补入 wave-4 九个变体（源目录 E:\cec2017\D50，30 runs，
# 清单 results/cec/archive/d50_wave4_import_manifest.csv），四个区块因此都是
# 29 个变体 × 29 个问题的完整设计；原先按变体白名单过滤的逻辑已删除。

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False


# ===========================================================================
# Statistics helpers
# ===========================================================================
def wilcoxon_paired(a, b):
    """Two-sided Wilcoxon signed-rank p-value; 1.0 when nothing differs."""
    from scipy.stats import wilcoxon
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    d = d[~np.isnan(d)]
    if len(d) == 0 or np.allclose(d, 0.0):
        return 1.0
    try:
        return float(wilcoxon(d, alternative='two-sided',
                              zero_method='wilcox').pvalue)
    except Exception:
        return 1.0


def holm(pvals, alpha=ALPHA):
    """Holm step-down.  Returns a boolean list of rejections."""
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    rej = np.zeros(m, dtype=bool)
    running = True
    for k, idx in enumerate(order):
        thresh = alpha / (m - k)
        if running and p[idx] <= thresh:
            rej[idx] = True
        else:
            running = False
    return rej


def friedman(mat):
    """Friedman test over a (blocks x treatments) matrix of values."""
    from scipy.stats import chi2, rankdata
    x = np.asarray(mat, float)
    n, k = x.shape
    ranks = np.apply_along_axis(rankdata, 1, x)
    rj = ranks.mean(axis=0)
    chi = (12.0 * n / (k * (k + 1))) * (np.sum(rj ** 2) - k * (k + 1) ** 2 / 4.0)
    # Iman-Davenport correction
    f_id = ((n - 1) * chi) / max(n * (k - 1) - chi, 1e-12)
    from scipy.stats import f as fdist
    p = float(fdist.sf(f_id, k - 1, (k - 1) * (n - 1)))
    return dict(chi2=float(chi), iman_davenport=float(f_id), p=p,
                mean_ranks=[float(v) for v in rj], n_blocks=int(n),
                n_treatments=int(k))


def dec(bare, wrapped):
    """Orders of magnitude gained (median based), the primary effect size."""
    return float(np.log10(max(float(np.median(bare)), FLOOR))
                 - np.log10(max(float(np.median(wrapped)), FLOOR)))


def ri(bare, wrapped):
    """Relative improvement, reported for reference next to ``dec``.

    Normalising by the *larger* of the two means keeps the statistic in
    ``[-1, 1]`` (positive = the layer helped) and behaves sanely on cells that
    reach machine precision: normalising by the bare mean alone produces
    numbers of order 1e15 whenever the host solves a cell and the wrapped
    variant lands at 1e-3, which is noise dressed up as an effect.
    """
    b = float(np.mean(np.asarray(bare, float)))
    u = float(np.mean(np.asarray(wrapped, float)))
    # magnitudes: a negative mean error (a reference value that was exceeded,
    # see ``reference``) must not shrink the scale towards zero.
    scale = max(abs(b), abs(u), FLOOR)
    return float((b - u) / scale)


# ===========================================================================
# Loading
# ===========================================================================
def _norm_runs(runs):
    """Normalise the wrapped arm to ``'upcl'``.

    The established hosts store the wrapped arm under ``'upcl'`` while the
    ten wave-4 variants store it under ``'full'`` (the legacy name).  Both
    mean "host + UPCL layer".  Renaming on read makes every downstream
    consumer see a single, consistent arm name.
    """
    out = []
    for r in runs:
        rr = dict(r)
        if 'full' in rr and 'upcl' not in rr:
            rr['upcl'] = rr.pop('full')
        out.append(rr)
    return out


def load_cells(suite=None, dim=None):
    """Return { (suite, dim, host, fid): {'bare': [...], 'upcl': [...]} }."""
    cells = {}
    if not RAW.exists():
        return cells
    for f in RAW.rglob('*.json'):
        try:
            with open(f, 'r', encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        if suite and d.get('suite') != suite:
            continue
        if dim and d.get('dim') != dim:
            continue
        # 2026-10-22：D=50 补入 wave-4 九个变体（E:\cec2017\D50，30 runs），
        # 四个区块现均为 29 个变体 × 29 个问题的完整设计，不再需要按变体过滤。
        if int(d.get('runs_complete') or 0) < 30:
            continue
        key = (d['suite'], d['dim'], d['host'], d['fid'])
        runs = _norm_runs(d['runs'])
        # A cell normally lives in exactly one file; the extend() branch only
        # merges a cell that was split over several files (e.g. an interrupted
        # run).  Note that the entry must *not* be extended when it is created,
        # otherwise every run would be counted twice.
        if key in cells:
            cells[key]['runs'].extend(runs)
        else:
            cells[key] = {'meta': {k: d[k] for k in
                                   ('suite', 'dim', 'host', 'fid', 'func',
                                    'category', 'max_evals', 'arms')},
                          'runs': runs}
    # 未完成（合并后 runs 不足 30）的 cell 视为“未获取”：从分析中排除，
    # 论文表格里留空，而不是用部分数据冒充完整结果。
    cells = {k: c for k, c in cells.items() if len(c['runs']) >= 30}
    return cells


def arms_of(cell):
    """Names of the arms present in a cell."""
    return sorted({k for r in cell['runs'] for k in r
                   if k not in ('run', 'seed')})


def reference(cells):
    """Best value observed per function, used as the error reference.

    Every function is normalised so that ``f(x_opt) = bias`` (see
    ``cec_suites.CECFunction``), and the reported error is ``f(x) - bias``.  For
    the composite functions that normalisation only pins the value at *one*
    candidate point: the true minimum of the blend can lie well below ``bias``,
    and with the deterministic fallback data it regularly does (CEC 2017 F7
    reaches about 610 below the declared optimum in the pilot).  Optimisers
    then produce *negative* "errors", which makes ``log10`` undefined and turns
    every effect size of those cells into noise.

    Subtracting the best value observed anywhere in the experiment restores a
    non-negative error scale.  It is a constant per function, so it is applied
    identically to both arms of every cell and leaves every paired difference
    in the raw scale untouched -- only the log transform becomes well defined.
    """
    ref = {}
    counts = {}
    for (suite, dim, host, fid), c in cells.items():
        vals = [r[a]['err_final'] for r in c['runs'] for a in arms_of(c)
                if a in r]
        if not vals:
            continue
        key = (suite, dim, fid)
        m = min(float(v) for v in vals)
        ref[key] = min(ref.get(key, float('inf')), m)
        counts[key] = counts.get(key, 0) + len(vals)
    rows = [dict(suite=s, dim=d, fid=f, reference_value=v,
                 n_runs=counts[(s, d, f)])
            for (s, d, f), v in sorted(ref.items())]
    _write('reference_values.csv', rows,
           ['suite', 'dim', 'fid', 'reference_value', 'n_runs'])
    return ref


def series(cell, arm, field='err_final'):
    """Values of one arm, shifted by the per-function reference when numeric."""
    vals = [r[arm][field] for r in cell['runs'] if arm in r]
    if field not in ('err_final', 'err_curve') or REF is None:
        return vals
    key = (cell['meta']['suite'], cell['meta']['dim'], cell['meta']['fid'])
    shift = REF.get(key)
    if shift is None:
        return vals
    if field == 'err_final':
        return [max(float(v) - shift, 0.0) for v in vals]
    return [[max(float(x) - shift, 0.0) for x in seq] for seq in vals]


# ===========================================================================
# Exp1: overall comparison
# ===========================================================================
def exp1(cells):
    rows = []
    for key, c in sorted(cells.items()):
        suite, dim, host, fid = key
        if 'upcl' not in arms_of(c):
            continue
        e0 = np.asarray(series(c, 'bare'), float)
        e1 = np.asarray(series(c, 'upcl'), float)
        n = min(len(e0), len(e1))
        if n == 0:
            continue
        e0, e1 = e0[:n], e1[:n]
        rows.append(dict(
            suite=suite, dim=dim, host=host, fid=fid,
            func=c['meta'].get('func', ''), category=c['meta'].get('category', ''),
            n=n,
            bare_mean=float(e0.mean()), bare_std=float(e0.std(ddof=1)) if n > 1 else 0.0,
            upcl_mean=float(e1.mean()), upcl_std=float(e1.std(ddof=1)) if n > 1 else 0.0,
            bare_median=float(np.median(e0)), upcl_median=float(np.median(e1)),
            dec=dec(e0, e1), ri=ri(e0, e1),
            p=wilcoxon_paired(e0, e1),
        ))
    add_rho(rows, cells)
    # Holm within each (suite, dim) block
    for block in {(r['suite'], r['dim']) for r in rows}:
        idx = [i for i, r in enumerate(rows)
               if (r['suite'], r['dim']) == block]
        rej = holm([rows[i]['p'] for i in idx])
        for i, rg in zip(idx, rej):
            rows[i]['p_holm_reject'] = bool(rg)
            if rg:
                rows[i]['verdict'] = 'win' if rows[i]['dec'] > 0 else 'loss'
            else:
                rows[i]['verdict'] = 'tie'
    _write('exp1_cells.csv', rows,
           ['suite', 'dim', 'host', 'fid', 'func', 'category', 'n',
            'bare_mean', 'bare_std', 'upcl_mean', 'upcl_std',
            'bare_median', 'upcl_median', 'dec', 'ri', 'rho', 'p',
            'p_holm_reject', 'verdict'])
    return rows


def exp1_summary(rows):
    out = []
    for (suite, dim, host) in sorted({(r['suite'], r['dim'], r['host'])
                                      for r in rows}):
        rs = [r for r in rows if (r['suite'], r['dim'], r['host'])
              == (suite, dim, host)]
        out.append(dict(
            suite=suite, dim=dim, host=host, cells=len(rs),
            wins=sum(1 for r in rs if r['verdict'] == 'win'),
            ties=sum(1 for r in rs if r['verdict'] == 'tie'),
            losses=sum(1 for r in rs if r['verdict'] == 'loss'),
            dec_mean=float(np.mean([r['dec'] for r in rs])),
            dec_median=float(np.median([r['dec'] for r in rs])),
            ri_mean=float(np.mean([r['ri'] for r in rs])),
            rho=float(np.mean([r.get('rho', 0.0) for r in rs])),
        ))
    _write('exp1_host_summary.csv', out,
           ['suite', 'dim', 'host', 'cells', 'wins', 'ties', 'losses',
            'dec_mean', 'dec_median', 'ri_mean', 'rho'])
    return out


def add_rho(rows, cells):
    """Attach the mean policy intervention rate to every cell row."""
    for r in rows:
        key = (r['suite'], r['dim'], r['host'], r['fid'])
        c = cells.get(key)
        if not c:
            continue
        vals = [x['upcl']['policy_rate'] for x in
                [rr.get('upcl') for rr in c['runs']]
                if x and x.get('upcl')]
        r['rho'] = float(np.mean(vals)) if vals else 0.0
    return rows


# ===========================================================================
# Exp2: cross-host generality
# ===========================================================================
def exp2(rows):
    from scipy.stats import spearmanr
    out = []
    for (suite, dim) in sorted({(r['suite'], r['dim']) for r in rows}):
        rs = [r for r in rows if (r['suite'], r['dim']) == (suite, dim)]
        hosts = sorted({r['host'] for r in rs})
        rho, decs, ads = [], [], []
        per_host = []
        for h in hosts:
            hr = [r for r in rs if r['host'] == h]
            per_host.append(dict(
                suite=suite, dim=dim, host=h, cells=len(hr),
                improved=sum(1 for r in hr if r['dec'] > 0.05),
                tie=sum(1 for r in hr if abs(r['dec']) <= 0.05),
                degraded=sum(1 for r in hr if r['dec'] < -0.05),
                dec_mean=float(np.mean([r['dec'] for r in hr])),
                ri_mean=float(np.mean([r['ri'] for r in hr])),
                rho=float(np.mean([r.get('rho', 0.0) for r in hr])),
                adaptivity=DHC.ADAPTIVITY.get(h, -1),
            ))
            rho.append(per_host[-1]['rho'])
            decs.append(per_host[-1]['dec_mean'])
            ads.append(float(DHC.ADAPTIVITY.get(h, -1)))
        if len(set(ads)) > 1 and len(rho) > 3:
            corr, pval = spearmanr(ads, rho)
        else:
            corr, pval = float('nan'), float('nan')
        for row in per_host:
            row['spearman_adaptivity_rho'] = float(corr)
            row['spearman_p'] = float(pval)
        out.extend(per_host)
    _write('exp2_cross_host.csv', out,
           ['suite', 'dim', 'host', 'cells', 'improved', 'tie', 'degraded',
            'dec_mean', 'ri_mean', 'rho', 'adaptivity',
            'spearman_adaptivity_rho', 'spearman_p'])
    return out


# ===========================================================================
# Exp3: convergence curves
# ===========================================================================
def exp3(cells, host_subset=None, fids=(1, 5, 15, 25)):
    if not HAVE_MPL:
        return
    host_subset = host_subset or FIG_HOSTS
    for (suite, dim) in sorted({(k[0], k[1]) for k in cells}):
        avail = sorted({k[3] for k in cells if (k[0], k[1]) == (suite, dim)})
        picked = [f for f in fids if f in avail][:4]
        if not picked:
            continue
        fig, axes = plt.subplots(2, 2, figsize=(11, 7.5), sharex=False)
        flat = axes.ravel()
        for extra in flat[len(picked):]:
            extra.set_visible(False)
        cmap = plt.get_cmap('tab10')
        for ax, fid in zip(flat, picked):
            for hi, h in enumerate(host_subset):
                key = [k for k in cells
                       if (k[0], k[1], k[2], k[3]) == (suite, dim, h, fid)]
                if not key:
                    continue
                c = cells[key[0]]
                c0 = series(c, 'bare', 'err_curve')
                c1 = series(c, 'upcl', 'err_curve')
                if not c0 or not c1:
                    continue
                grid = c['runs'][0]['bare']['grid']
                m0 = np.median(np.asarray(c0, float), axis=0)
                m1 = np.median(np.asarray(c1, float), axis=0)
                col = cmap(hi % 10)
                ax.plot(grid, np.log10(np.maximum(m0, FLOOR)), '--', color=col,
                        alpha=0.9, label=f'{h} bare')
                ax.plot(grid, np.log10(np.maximum(m1, FLOOR)), '-', color=col,
                        alpha=0.9, label=f'{h} +UPCL')
            ax.set_title(f'{suite} F{fid} D={dim}')
            ax.set_xlabel('FES')
            ax.set_ylabel(r'$\log_{10}$ error')
            ax.grid(alpha=0.3)
        handles, labels = axes.ravel()[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='lower center', ncol=4, fontsize=7)
        fig.tight_layout(rect=[0, 0.07, 1, 1])
        FIG.mkdir(parents=True, exist_ok=True)
        fig.savefig(FIG / f'exp3_convergence_{suite}_D{dim}.png', dpi=150)
        plt.close(fig)


# ===========================================================================
# Exp4: ablation
# ===========================================================================
def _mean_rate(cell, arm, field='policy_rate'):
    vals = [r[arm]['upcl'][field] for r in cell['runs']
            if arm in r and r[arm].get('upcl')]
    return float(np.mean(vals)) if vals else 0.0


def _mean_rho(cell, arm):
    return _mean_rate(cell, arm, 'policy_rate')


def exp4(cells):
    rows, blocks = [], defaultdict(lambda: defaultdict(list))
    for key, c in sorted(cells.items()):
        suite, dim, host, fid = key
        present = arms_of(c)
        if len(present) < 3:
            continue
        for arm in present:
            vals = np.asarray(series(c, arm), float)
            blocks[(suite, dim, host, fid)][arm] = vals
    if not blocks:
        return rows
    arm_names = sorted({a for b in blocks.values() for a in b})
    for (suite, dim, host, fid), d in sorted(blocks.items()):
        for arm in arm_names:
            v = d.get(arm)
            if v is None or len(v) == 0:
                continue
            cc = cells[(suite, dim, host, fid)]
            rows.append(dict(suite=suite, dim=dim, host=host, fid=fid, arm=arm,
                             median=float(np.median(v)),
                             mean=float(np.mean(v)),
                             std=float(np.std(v, ddof=1)) if len(v) > 1 else 0.0,
                             dec_vs_bare=(dec(d['bare'], v) if 'bare' in d else 0.0),
                             rho=_mean_rho(cc, arm),
                             intervention_rate=_mean_rate(
                                 cc, arm, 'intervention_rate'),
                             ))
    _write('exp4_ablation_cells.csv', rows,
           ['suite', 'dim', 'host', 'fid', 'arm', 'median', 'mean', 'std',
            'dec_vs_bare', 'rho', 'intervention_rate'])

    # Friedman over the arms, with the functions as blocks
    summary = []
    for (suite, dim, host) in sorted({(r['suite'], r['dim'], r['host'])
                                      for r in rows}):
        rr = [r for r in rows
              if (r['suite'], r['dim'], r['host']) == (suite, dim, host)]
        fids = sorted({r['fid'] for r in rr})
        mat = []
        for fid in fids:
            row = []
            ok = True
            for arm in arm_names:
                v = [r['median'] for r in rr
                     if r['fid'] == fid and r['arm'] == arm]
                if not v:
                    ok = False
                    break
                row.append(v[0])
            if ok:
                mat.append(row)
        if len(mat) < 2 or len(mat[0]) < 3:
            continue
        fr = friedman(np.asarray(mat, float))
        summary.append(dict(suite=suite, dim=dim, host=host,
                            n_blocks=fr['n_blocks'],
                            chi2=fr['chi2'], p=fr['p'],
                            **{f'rank_{a}': r for a, r in
                               zip(arm_names, fr['mean_ranks'])}))
    _write('exp4_friedman.csv', summary,
           ['suite', 'dim', 'host', 'n_blocks', 'chi2', 'p']
           + [f'rank_{a}' for a in arm_names])

    # the headline contrast: full UPCL vs the random-correction control
    contrasts = []
    for (suite, dim, host) in sorted({(r['suite'], r['dim'], r['host'])
                                      for r in rows}):
        rr = [r for r in rows
              if (r['suite'], r['dim'], r['host']) == (suite, dim, host)]
        for arm in ('random', 'no_minimal', 'mem1'):
            a = [r['median'] for r in rr if r['arm'] == 'full']
            b = [r['median'] for r in rr if r['arm'] == arm]
            if not a or not b or len(a) != len(b):
                continue
            contrasts.append(dict(suite=suite, dim=dim, host=host,
                                  contrast=f'full vs {arm}',
                                  dec=float(np.log10(max(np.median(b), FLOOR))
                                            - np.log10(max(np.median(a), FLOOR))),
                                  p=wilcoxon_paired(b, a)))
    _write('exp4_contrasts.csv', contrasts,
           ['suite', 'dim', 'host', 'contrast', 'dec', 'p'])
    return rows


# ===========================================================================
# Exp5: mechanism diagnostics
# ===========================================================================
def exp5(cells, rows):
    stats = []
    for key, c in sorted(cells.items()):
        suite, dim, host, fid = key
        ups = [r['upcl'].get('upcl') for r in c['runs'] if 'upcl' in r]
        ups = [u for u in ups if u]
        if not ups:
            continue
        curves = [u.get('rho_policy_curve', []) for u in ups]
        npts = min((len(x) for x in curves if x), default=0)
        mean_curve = (np.mean([np.asarray(x[:npts], float) for x in curves
                               if len(x) >= npts], axis=0).tolist()
                      if npts else [])
        stats.append(dict(
            suite=suite, dim=dim, host=host, fid=fid,
            category=c['meta'].get('category', ''),
            rho=float(np.mean([u['policy_rate'] for u in ups])),
            intervention_rate=float(np.mean([u['intervention_rate'] for u in ups])),
            mean_relative_shift=float(np.mean([u['mean_relative_shift'] for u in ups])),
            # action_counts is keyed by the single-letter action codes
            identity_share=float(np.mean([
                u['action_counts'].get('I', 0)
                / max(sum(u['action_counts'].values()), 1) for u in ups])),
            rho_curve=mean_curve,
        ))
    _write('exp5_mechanism.csv',
           [{k: v for k, v in s.items() if k != 'rho_curve'} for s in stats],
           ['suite', 'dim', 'host', 'fid', 'category', 'rho',
            'intervention_rate', 'mean_relative_shift', 'identity_share'])

    # gain per function category, and per dimension (high-dimensional effect)
    cat = defaultdict(list)
    for r in rows:
        cat[(r['suite'], r['dim'], r['category'])].append(r['dec'])
    cat_rows = [dict(suite=s, dim=d, category=c, cells=len(v),
                     dec_mean=float(np.mean(v)), dec_median=float(np.median(v)),
                     wins=sum(1 for x in v if x > 0.05),
                     losses=sum(1 for x in v if x < -0.05))
                for (s, d, c), v in sorted(cat.items())]
    _write('exp5_by_category.csv', cat_rows,
           ['suite', 'dim', 'category', 'cells', 'dec_mean', 'dec_median',
            'wins', 'losses'])

    # rho vs dimension: does the layer intervene more when D grows?
    dim_rows = []
    for (suite, dim) in sorted({(s['suite'], s['dim']) for s in stats}):
        ss = [s for s in stats if (s['suite'], s['dim']) == (suite, dim)]
        dim_rows.append(dict(suite=suite, dim=dim,
                             rho=float(np.mean([s['rho'] for s in ss])),
                             shift=float(np.mean([s['mean_relative_shift']
                                                  for s in ss])),
                             identity_share=float(np.mean([s['identity_share']
                                                           for s in ss]))))
    _write('exp5_by_dimension.csv', dim_rows,
           ['suite', 'dim', 'rho', 'shift', 'identity_share'])

    # --- which of the five descriptor components carry the response signal ---
    # effect_k is the standardised difference (in units of the component's own
    # standard deviation) between the descriptors of proposals that worked and
    # those that did not.  Cells without the diagnostic are skipped, so the
    # table stays empty when the runs predate the instrumentation.
    desc_cells = []
    for key, c in sorted(cells.items()):
        suite, dim, host, fid = key
        uks = [r['upcl']['upcl'].get('descriptor_influence')
               for r in c['runs'] if r.get('upcl', {}).get('upcl')]
        uks = [u for u in uks if u]
        if not uks:
            continue
        row = dict(suite=suite, dim=dim, host=host, fid=fid,
                   category=c['meta'].get('category', ''))
        for k in range(5):
            row[f'{DESC_NAMES[k]}_effect'] = float(
                np.mean([u.get(f'z{k}_effect', 0.0) for u in uks]))
        desc_cells.append(row)
    if desc_cells:
        _write('exp5_descriptor_influence.csv', desc_cells,
               ['suite', 'dim', 'host', 'fid', 'category']
               + [f'{n}_effect' for n in DESC_NAMES])
        desc_rows = []
        for (suite, dim) in sorted({(r['suite'], r['dim']) for r in desc_cells}):
            rr = [r for r in desc_cells if (r['suite'], r['dim']) == (suite, dim)]
            row = dict(suite=suite, dim=dim, cells=len(rr))
            for n in DESC_NAMES:
                v = [r[f'{n}_effect'] for r in rr]
                row[f'{n}_effect'] = float(np.mean(v))
                row[f'{n}_effect_sd'] = float(np.std(v))
                row[f'{n}_effect_abs'] = float(np.mean(np.abs(v)))
            desc_rows.append(row)
        _write('exp5_descriptor_by_dim.csv', desc_rows,
               ['suite', 'dim', 'cells']
               + [c for n in DESC_NAMES
                  for c in (f'{n}_effect', f'{n}_effect_sd', f'{n}_effect_abs')])

    if HAVE_MPL and stats:
        _fig_rho_curves(stats)
    return stats


def exp5_dim_transfer(rows):
    """Carry-over of the paired effect from CEC 2017 D=30 to D=50.

    Only the hosts present in both blocks are used, so the comparison is
    paired in the strict sense: same implementations, same seeds, same
    budget, different dimension.  Two tables are written: the per-host
    values (drawn as a figure) and the summary statistics quoted in the
    dimension paragraph of the paper.
    """
    a = {}
    b = {}
    for r in rows:
        if r['suite'] != 'cec2017':
            continue
        if r['dim'] == 30:
            a.setdefault(r['host'], []).append(r)
        elif r['dim'] == 50:
            b.setdefault(r['host'], []).append(r)
    common = sorted(set(a) & set(b))
    if len(common) < 3:
        return []

    def _m(rr, k):
        return float(np.mean([x[k] for x in rr]))

    hosts = []
    for h in common:
        hosts.append(dict(host=h,
                          dec30=_m(a[h], 'dec'), dec50=_m(b[h], 'dec'),
                          ri30=_m(a[h], 'ri'), ri50=_m(b[h], 'ri'),
                          rho30=_m(a[h], 'rho'), rho50=_m(b[h], 'rho'),
                          n30=len(a[h]), n50=len(b[h])))
    _write('exp5_dim_hosts.csv', hosts,
           ['host', 'dec30', 'dec50', 'ri30', 'ri50', 'rho30', 'rho50',
            'n30', 'n50'])

    from scipy.stats import spearmanr
    x = [h['dec30'] for h in hosts]
    y = [h['dec50'] for h in hosts]
    sp = spearmanr(x, y)
    sp_rho = spearmanr([h['rho30'] for h in hosts], [h['rho50'] for h in hosts])
    # cell level, paired on (host, fid)
    ca = {(r['host'], r['fid']): r['dec'] for h in common for r in a[h]}
    cb = {(r['host'], r['fid']): r['dec'] for h in common for r in b[h]}
    keys = sorted(set(ca) & set(cb))
    va = [ca[k] for k in keys]
    vb = [cb[k] for k in keys]

    stats = [
        dict(metric='hosts_in_both_blocks', value=float(len(common)), p='',
             n=len(common)),
        dict(metric='host_dec_spearman', value=float(sp.statistic),
             p=float(sp.pvalue), n=len(common)),
        dict(metric='host_dec_wilcoxon_p', value=float(len(common)),
             p=wilcoxon_paired(x, y), n=len(common)),
        dict(metric='host_sign_agree', value=float(sum(1 for u, v in zip(x, y)
                                                      if u * v > 0)),
             p='', n=len(common)),
        dict(metric='host_both_positive', value=float(sum(1 for u, v
                                                          in zip(x, y)
                                                          if u > 0 and v > 0)),
             p='', n=len(common)),
        dict(metric='host_rho_spearman', value=float(sp_rho.statistic),
             p=float(sp_rho.pvalue), n=len(common)),
        dict(metric='cells_in_both_blocks', value=float(len(keys)), p='',
             n=len(keys)),
        dict(metric='cell_dec_mean30', value=float(np.mean(va)), p='',
             n=len(va)),
        dict(metric='cell_dec_mean50', value=float(np.mean(vb)), p='',
             n=len(vb)),
        dict(metric='cell_dec_median30', value=float(np.median(va)), p='',
             n=len(va)),
        dict(metric='cell_dec_median50', value=float(np.median(vb)), p='',
             n=len(vb)),
        dict(metric='cell_dec_wilcoxon_p', value=float(len(keys)),
             p=wilcoxon_paired(vb, va), n=len(keys)),
        dict(metric='cell_frac_positive30',
             value=float(np.mean([v > 0 for v in va])), p='', n=len(va)),
        dict(metric='cell_frac_positive50',
             value=float(np.mean([v > 0 for v in vb])), p='', n=len(vb)),
    ]
    _write('exp5_dim_transfer.csv', stats, ['metric', 'value', 'p', 'n'])
    return stats


def _fig_rho_curves(stats):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for (suite, dim) in sorted({(s['suite'], s['dim']) for s in stats}):
        ss = [s for s in stats if (s['suite'], s['dim']) == (suite, dim)
              and s['rho_curve']]
        if not ss:
            continue
        n = min(len(s['rho_curve']) for s in ss)
        y = np.mean([np.asarray(s['rho_curve'][:n]) for s in ss], axis=0)
        ax.plot(np.linspace(0, 1, n), y, label=f'{suite} D={dim}')
    ax.set_xlabel('search progress (fraction of the budget)')
    ax.set_ylabel(r'policy intervention rate $\rho_{policy}$')
    ax.legend()
    ax.grid(alpha=0.3)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(FIG / 'exp5_rho_curve.png', dpi=150)
    plt.close(fig)


# ===========================================================================
# Exp6: computational overhead
# ===========================================================================
def exp6(cells):
    out = []
    for key, c in sorted(cells.items()):
        suite, dim, host, fid = key
        if 'upcl' not in arms_of(c):
            continue
        t0 = np.asarray([r['bare']['wall_time_s'] for r in c['runs']
                         if 'bare' in r], float)
        t1 = np.asarray([r['upcl']['wall_time_s'] for r in c['runs']
                         if 'upcl' in r], float)
        n = min(len(t0), len(t1))
        if n == 0:
            continue
        t0, t1 = t0[:n], t1[:n]
        dec_t = np.asarray([r['upcl']['upcl_decision_time_s']
                            for r in c['runs'] if 'upcl' in r], float)[:n]
        ev0 = [r['bare']['nevals'] for r in c['runs'] if 'bare' in r][:n]
        ev1 = [r['upcl']['nevals'] for r in c['runs'] if 'upcl' in r][:n]
        ev = float(np.mean(ev1)) if ev1 else 0.0
        out.append(dict(
            suite=suite, dim=dim, host=host, fid=fid, n=n,
            bare_s=float(t0.mean()), upcl_s=float(t1.mean()),
            overhead_pct=float((t1.mean() - t0.mean()) / max(t0.mean(), 1e-9) * 100),
            upcl_decision_s=float(dec_t.mean()),
            decision_share_pct=float(dec_t.mean() / max(t1.mean(), 1e-9) * 100),
            # per-proposal figures: the absolute cost of one decision and the
            # extra wall-clock per proposal (machine-load robust, unlike %)
            decision_us=float(dec_t.mean() / ev * 1e6) if ev else 0.0,
            overhead_us=float((t1.mean() - t0.mean()) / ev * 1e6) if ev else 0.0,
            fe_equal=bool(np.all(np.asarray(ev0) == np.asarray(ev1))),
            fe_bare=int(np.mean(ev0)), fe_upcl=int(np.mean(ev1)),
        ))
    _write('exp6_overhead.csv', out,
           ['suite', 'dim', 'host', 'fid', 'n', 'bare_s', 'upcl_s',
            'overhead_pct', 'upcl_decision_s', 'decision_share_pct',
            'decision_us', 'overhead_us', 'fe_equal', 'fe_bare', 'fe_upcl'])
    agg = []
    for host in sorted({r['host'] for r in out}):
        rr = [r for r in out if r['host'] == host]
        agg.append(dict(host=host,
                        overhead_pct=float(np.mean([r['overhead_pct'] for r in rr])),
                        decision_share_pct=float(np.mean([r['decision_share_pct']
                                                          for r in rr])),
                        decision_us=float(np.mean([r['decision_us'] for r in rr])),
                        overhead_us=float(np.mean([r['overhead_us'] for r in rr])),
                        fe_equal=bool(all(r['fe_equal'] for r in rr))))
    _write('exp6_overhead_by_host.csv', agg,
           ['host', 'overhead_pct', 'decision_share_pct', 'decision_us',
            'overhead_us', 'fe_equal'])
    # by (suite, dim): the per-proposal cost is the machine-independent
    # quantity that the paper should quote, the percentage is not.
    agg_d = []
    for (suite, dim) in sorted({(r['suite'], r['dim']) for r in out}):
        rr = [r for r in out if (r['suite'], r['dim']) == (suite, dim)]
        agg_d.append(dict(
            suite=suite, dim=dim, cells=len(rr),
            bare_s=float(np.mean([r['bare_s'] for r in rr])),
            upcl_s=float(np.mean([r['upcl_s'] for r in rr])),
            overhead_pct=float(np.mean([r['overhead_pct'] for r in rr])),
            decision_us=float(np.mean([r['decision_us'] for r in rr])),
            overhead_us=float(np.mean([r['overhead_us'] for r in rr])),
            decision_share_pct=float(np.mean([r['decision_share_pct']
                                              for r in rr])),
            fe_equal=bool(all(r['fe_equal'] for r in rr)),
            fe_bare=int(np.mean([r['fe_bare'] for r in rr])),
        ))
    _write('exp6_overhead_by_dim.csv', agg_d,
           ['suite', 'dim', 'cells', 'bare_s', 'upcl_s', 'overhead_pct',
            'decision_us', 'overhead_us', 'decision_share_pct', 'fe_equal',
            'fe_bare'])
    if HAVE_MPL and agg:
        fig, (ax, ax2) = plt.subplots(1, 2, figsize=(11, 4))
        ax.bar([a['host'] for a in agg], [a['overhead_pct'] for a in agg])
        ax.set_ylabel('extra wall-clock (%)')
        ax.set_title('overhead by host')
        plt.setp(ax.get_xticklabels(), rotation=60, ha='right', fontsize=7)
        if agg_d:
            lbl = [f'{d["suite"]} D={d["dim"]}' for d in agg_d]
            ax2.bar(lbl, [d['decision_us'] for d in agg_d])
            ax2.set_ylabel(r'decision cost ($\mu$s per proposal)')
            ax2.set_title('absolute cost (load-independent)')
        fig.suptitle('Exp6: cost of attaching UPCL (evaluations unchanged)')
        fig.tight_layout()
        FIG.mkdir(parents=True, exist_ok=True)
        fig.savefig(FIG / 'exp6_overhead.png', dpi=150)
        plt.close(fig)
    return out


# ===========================================================================
# I/O helpers
# ===========================================================================
def _write(name, rows, fields):
    if not rows:
        return
    TAB.mkdir(parents=True, exist_ok=True)
    with open(TAB / name, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow(r)


FIG_HOSTS = ['DE/rand/1', 'JADE', 'SHADE', 'L-SHADE']


def run_all(suites=None):
    global REF
    TAB.mkdir(parents=True, exist_ok=True)
    FIG.mkdir(parents=True, exist_ok=True)
    cells = load_cells()
    if not cells:
        print('[analyze] no results found under', RAW)
        return
    REF = reference(cells)      # non-negative error scale, see reference()
    rows = exp1(cells)          # exp1 attaches rho itself
    exp1_summary(rows)
    exp2(rows)
    exp3(cells)
    exp4(cells)
    exp5(cells, rows)
    exp5_dim_transfer(rows)
    exp6(cells)
    _console(rows)


def _console(rows):
    print('\n=== Exp1: overall (per suite / dimension) ===')
    for (suite, dim) in sorted({(r['suite'], r['dim']) for r in rows}):
        rs = [r for r in rows if (r['suite'], r['dim']) == (suite, dim)]
        w = sum(1 for r in rs if r['verdict'] == 'win')
        t = sum(1 for r in rs if r['verdict'] == 'tie')
        l = sum(1 for r in rs if r['verdict'] == 'loss')
        print(f'  {suite} D={dim}: cells {len(rs):3d}  W/T/L {w}/{t}/{l}  '
              f'mean dec {np.mean([r["dec"] for r in rs]):+.3f}  '
              f'mean rho {np.mean([r.get("rho", 0) for r in rs]):.3f}')
    print('\n=== Exp1: per host (by suite and dimension) ===')
    for r in _read('exp1_host_summary.csv'):
        print(f'  {r["suite"]:>8s} D={int(float(r["dim"])):<3d}'
              f'  {r["host"]:>20s}  W/T/L '
              f'{r["wins"]}/{r["ties"]}/{r["losses"]}'
              f'   dec {float(r["dec_mean"]):+.3f}'
              f'   ri  {float(r["ri_mean"]):+.3f}'
              f'   rho {float(r["rho"]):.3f}')

    print('\n=== Exp6: cost of attaching UPCL ===')
    for r in _read('exp6_overhead_by_dim.csv'):
        print(f'  {r["suite"]} D={r["dim"]:<3s} cells {r["cells"]:>3s}  '
              f'bare {float(r["bare_s"]):8.1f}s  +UPCL {float(r["upcl_s"]):8.1f}s  '
              f'overhead {float(r["overhead_pct"]):+7.1f}%  '
              f'decision {float(r["decision_us"]):6.1f} us/proposal  '
              f'FEs identical: {r["fe_equal"]}')
    acc = _read('exp4_ablation_cells.csv')
    if acc:
        print('\n=== Exp4: ablation (per arm, averaged over cells) ===')
        for arm in sorted({r['arm'] for r in acc}):
            rr = [r for r in acc if r['arm'] == arm]
            print(f'  {arm:>11s}  dec vs bare '
                  f'{np.mean([float(r["dec_vs_bare"]) for r in rr]):+7.3f}  '
                  f'rho {np.mean([float(r["rho"]) for r in rr]):.3f}  '
                  f'interv. {np.mean([float(r["intervention_rate"]) for r in rr]):.3f}')


def _read(name):
    p = TAB / name
    if not p.exists():
        return []
    with open(p, 'r', encoding='utf-8') as fh:
        return list(csv.DictReader(fh))


if __name__ == '__main__':
    run_all(sys.argv[1:] or None)

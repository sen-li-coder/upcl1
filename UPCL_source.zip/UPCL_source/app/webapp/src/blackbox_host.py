# -*- coding: utf-8 -*-
"""黑盒算法宿主：通过 stdin/stdout 的 JSON 行协议，接入客户自研算法。

背景
----
本系统（差分进化 + UPCL 机制研究平台）以「卖系统、不给源码」的方式交付，
客户希望在平台上对比自己的算法。黑盒协议让客户用任意语言写一个可执行程序，
平台作为「评估服务」向它提供 ``f(x)`` 的取值，客户程序自己负责搜索。

协议（每一行是一个 UTF-8 JSON 对象）
------------------------------------
1. 平台启动客户程序后，先发送一行初始化消息：:

       {"cmd": "init", "dim": 10, "lb": [-100, ...], "ub": [100, ...],
        "max_evals": 100000, "seed": 20240000}

2. 客户程序进入搜索循环，每次需要评估一个解时，向 stdout 打印一行：:

       {"cmd": "eval", "x": [1.2, -3.4, ...]}

   平台计算 ``f(x)`` 后向客户程序的 stdin 打印一行：:

       {"cmd": "f", "f": 123.456}

3. 当评估次数达到 ``max_evals`` 后，平台回复：:

       {"cmd": "stop"}

   并关闭 stdin。客户程序收到 ``stop``（或读不到输入）后应立即退出。
   客户程序也可以主动结束搜索：打印 ``{"cmd": "done"}`` 后退出。

平台会记录每一次评估的 ``(x, f)``，并自动维护「已评估点的最小 f」作为
best-so-far 收敛曲线，因此客户程序无需自己上报历史最优。
"""

import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

if getattr(sys, 'frozen', False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = Path(__file__).resolve().parents[1]

PLUGINS_DIR = ROOT / 'plugins'


def _plugin_dirs(extra=None):
    """插件搜索目录：用户私有（extra/env）在前，公共预置在后。"""
    dirs = []
    for d in (extra, os.environ.get('UPCL_PLUGINS_DIR')):
        if d:
            dirs.append(Path(d))
    dirs.append(PLUGINS_DIR)
    seen, out = set(), []
    for d in dirs:
        if d in seen:
            continue
        seen.add(d)
        out.append(d)
    return out


def load_plugins(extra_dirs=None):
    """扫描插件目录（私有优先 + 公共兜底），返回 {算法名: 插件描述 dict}。

    每个插件描述里额外带 ``_dir`` 字段（插件文件所在目录），执行时以其为
    工作目录解析 exec 里的相对路径。
    """
    plugins = {}
    for d in _plugin_dirs(extra_dirs):
        if not d.is_dir():
            continue
        for p in sorted(d.glob('*.json')):
            try:
                data = json.loads(p.read_text(encoding='utf-8'))
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            name = str(data.get('name') or p.stem).strip()
            if not name or name in plugins:
                continue  # 私有目录优先
            data['name'] = name
            data['_dir'] = str(d)
            plugins[name] = data
    return plugins


def make_blackbox_cls(name, plugin):
    """为某个插件生成一个 BlackBoxHost 子类，把插件描述挂在类属性上。"""
    return type(name, (BlackBoxHost,), {'name': name, 'plugin': plugin})


def register_plugins(host_registry):
    """把所有插件注册进 HOST_REGISTRY，返回新增的算法名列表。"""
    added = []
    for name, plugin in load_plugins().items():
        if name in host_registry and not getattr(host_registry[name], 'is_blackbox', False):
            # 与内置算法重名：跳过，避免覆盖内置实现
            continue
        host_registry[name] = make_blackbox_cls(name, plugin)
        added.append(name)
    return added


class BlackBoxHost:
    """黑盒算法宿主：实现与内置 DE 宿主完全一致的 run 接口。

    被 ``de_hosts.get_host`` 按同样的 ``(dim, lb, ub, pop_size, seed)`` 签名
    实例化，``run(fobj, max_evals, callback, record_pop_every)`` 返回
    ``(best_f, best_x, conv_curve, eval_points)``，因此可直接进入 CEC 对比流程。
    """

    is_blackbox = True
    name = 'blackbox'
    plugin = None  # 由 make_blackbox_cls 生成的子类覆盖

    def __init__(self, dim, lb, ub, pop_size=None, seed=None, **kwargs):
        self.dim = int(dim)
        # 边界可能是标量（所有维同界）或长度=dim 的向量，统一广播为 (dim,) 向量
        self.lb = np.broadcast_to(np.asarray(lb, dtype=float), (self.dim,)).astype(float)
        self.ub = np.broadcast_to(np.asarray(ub, dtype=float), (self.dim,)).astype(float)
        self.pop_size = pop_size
        self.seed = seed
        # 客户自定义参数：通过 init 消息的 params 字段透传给程序（可含任意 key-value）
        plugin = self.plugin if isinstance(self.plugin, dict) else {}
        self.params = dict(plugin.get('params') or {})
        self.N = pop_size if pop_size else max(4, self.dim)
        self.pop = None
        self.fitness = None
        self.best_idx = 0
        self.g = 0
        self.nevals = 0
        self.best_so_far = np.inf
        self.best_x = None
        self.stagnation = 0
        self.archive = []
        self.pop_history = []
        # UPCL 介入钩子：黑盒不暴露内部种群，一律保持 None（不介入）
        self.gen_begin_fn = None
        self.proposal_fn = None
        self.post_eval_fn = None
        self.last_error = None

    # ------------------------------------------------------------------
    def _command(self):
        plugin = self.plugin or {}
        spec = plugin.get('exec', '')
        if isinstance(spec, (list, tuple)):
            cmd = [str(x) for x in spec]
        else:
            cmd = shlex.split(str(spec), posix=(os.name != 'nt'))
        extra = plugin.get('extra_args') or []
        cmd = cmd + [str(x) for x in extra]
        if not cmd:
            raise RuntimeError('插件未配置可执行程序（exec 为空）')
        return cmd

    def _send(self, proc, msg):
        try:
            proc.stdin.write(json.dumps(msg, ensure_ascii=False) + '\n')
            proc.stdin.flush()
        except Exception:
            pass

    def _terminate(self, proc):
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
        except Exception:
            pass
        try:
            proc.stdout.close()
            proc.stderr.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def run(self, fobj, max_evals, callback=None, record_pop_every=0):
        """执行黑盒算法一轮搜索，返回 (best_f, best_x, conv, evals)。"""
        plugin = self.plugin or {}
        timeout = float(plugin.get('timeout_s', 600) or 600)
        cmd = self._command()

        cwd = plugin.get('_dir') or str(PLUGINS_DIR)
        proc = subprocess.Popen(
            cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding='utf-8',
            errors='replace', bufsize=1, cwd=cwd)

        self._send(proc, {
            'cmd': 'init', 'dim': self.dim,
            'lb': [float(v) for v in self.lb],
            'ub': [float(v) for v in self.ub],
            'max_evals': int(max_evals),
            'seed': int(self.seed) if self.seed is not None else 0,
            'params': self.params,
        })

        conv = []
        evals = []
        self.best_so_far = np.inf
        self.best_x = None
        self.nevals = 0
        self.g = 0
        start = time.perf_counter()
        cb_every = max(1, int(max_evals) // 200)

        try:
            while True:
                if time.perf_counter() - start > timeout:
                    raise TimeoutError(f'插件执行超时（>{timeout}s）')
                if proc.poll() is not None:
                    break
                line = proc.stdout.readline()
                if not line:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except Exception:
                    continue
                if not isinstance(msg, dict):
                    continue
                c = msg.get('cmd')
                if c == 'eval':
                    x = msg.get('x')
                    if self.nevals >= max_evals:
                        self._send(proc, {'cmd': 'stop'})
                        break
                    try:
                        xa = np.asarray(x, dtype=float).reshape(-1)
                    except Exception:
                        self._send(proc, {'cmd': 'f', 'f': float('inf')})
                        continue
                    if xa.shape[0] != self.dim:
                        self._send(proc, {'cmd': 'f', 'f': float('inf')})
                        continue
                    f = float(fobj(xa))
                    self.nevals += 1
                    if f < self.best_so_far:
                        self.best_so_far = f
                        self.best_x = xa.copy()
                    conv.append(self.best_so_far)
                    evals.append(self.nevals)
                    self._send(proc, {'cmd': 'f', 'f': f})
                    self.g = self.nevals
                    if callback is not None and self.nevals % cb_every == 0:
                        callback(self)
                elif c == 'done':
                    self._send(proc, {'cmd': 'stop'})
                    break
                else:
                    self._send(proc, {'cmd': 'ok'})
        except Exception as exc:  # noqa: BLE001
            self.last_error = str(exc)
        finally:
            self._terminate(proc)

        if self.nevals == 0:
            detail = self.last_error or '客户程序未发起任何评估'
            raise RuntimeError(f'黑盒算法「{self.name}」运行失败：{detail}')

        return (self.best_so_far,
                self.best_x,
                np.asarray(conv, dtype=float),
                np.asarray(evals, dtype=float))


# ---------------------------------------------------------------------------
# 冒烟自检：用一个真实 CEC 函数跑一轮，验证协议链路与收敛性。
# ---------------------------------------------------------------------------
def smoke_test(name, dim=10, max_evals=1000, seed=1, plugins_dir=None):
    """对某个已安装插件做一次快速自检，返回结果字典（供向导展示）。"""
    import cec_suites as CS
    plugins = load_plugins([plugins_dir] if plugins_dir else None)
    if name not in plugins:
        return {'ok': False, 'msg': f'插件「{name}」不存在'}
    plugin = plugins[name]
    func = CS.get_function('cec2022', dim, 1)
    cls = make_blackbox_cls(name, plugin)
    host = cls(dim, func.lb, func.ub, seed=seed)
    t0 = time.perf_counter()
    best_f, best_x, conv, evals = host.run(func, max_evals)
    wall = time.perf_counter() - t0
    f_opt = float(getattr(func, 'f_opt', 0.0) or 0.0)
    err_first = float(conv[0] - f_opt) if len(conv) else None
    err_final = float(best_f - f_opt)
    return {
        'ok': True,
        'name': name,
        'nevals': int(host.nevals),
        'wall_s': round(wall, 2),
        'err_first': err_first,
        'err_final': err_final,
        'improved': err_first is None or err_final < err_first,
    }

# -*- coding: utf-8 -*-
"""二维适应度地形 + 种群收敛轨迹采样（供 GUI「二维地形图」窗口调用）。

不落盘、不跑完整实验：按需跑单 run，把种群在 x1-x2 子空间上的投影轨迹
与二维地形一并返回，用于即时可视化「算法种群如何在地形上收敛」。

被 gui_launcher.py 在后台线程中懒加载调用；依赖 numpy + cec_suites +
de_hosts + de_hosts_cec + run_upcl_cec（均已随 exe 打包）。
"""
import numpy as np


def _contour_segments(Z, level, lb, ub):
    """marching squares 提取 Z==level 的等值线段（返回实际坐标）。

    Z 形状 (ny, nx)，Z[i, j] 位于坐标 (x=j, y=i)，x/y 均 linspace(lb, ub)。
    返回 [(x1, y1, x2, y2), ...]，坐标为实际搜索空间值，用于画等高线“圈圈”。
    """
    ny, nx = Z.shape
    segs = []

    def xof(j):
        return lb + j / (nx - 1) * (ub - lb)

    def yof(i):
        return lb + i / (ny - 1) * (ub - lb)

    for i in range(ny - 1):
        for j in range(nx - 1):
            v00 = Z[i, j]
            v10 = Z[i, j + 1]
            v11 = Z[i + 1, j + 1]
            v01 = Z[i + 1, j]
            case = ((1 if v00 >= level else 0)
                    | (2 if v10 >= level else 0)
                    | (4 if v11 >= level else 0)
                    | (8 if v01 >= level else 0))
            if case == 0 or case == 15:
                continue

            def ip(va, vb, a, b):
                if abs(vb - va) < 1e-12:
                    return a
                return a + (level - va) / (vb - va) * (b - a)

            edges = {
                0: (xof(ip(v00, v10, j, j + 1)), yof(i)),          # 底
                1: (xof(j + 1), yof(ip(v10, v11, i, i + 1))),       # 右
                2: (xof(ip(v01, v11, j, j + 1)), yof(i + 1)),       # 顶
                3: (xof(j), yof(ip(v00, v01, i, i + 1))),           # 左
            }
            pairs = {
                1: [0, 3], 2: [0, 1], 3: [1, 3], 4: [1, 2],
                5: [0, 3, 1, 2], 6: [0, 2], 7: [2, 3], 8: [2, 3],
                9: [0, 2], 10: [0, 1, 2, 3], 11: [1, 2], 12: [1, 3],
                13: [0, 1], 14: [0, 3],
            }[case]
            for k in range(0, len(pairs), 2):
                a = edges[pairs[k]]
                b = edges[pairs[k + 1]]
                segs.append((a[0], a[1], b[0], b[1]))
    return segs


def _chain_segments_to_loops(segs):
    """把 marching squares 输出的线段按端点串成连续多段线。

    返回 [ [[x,y], [x,y], ...], ... ]，每条多段线按顺序排列；
    完全在域内的等值线为闭合圈（首尾同点），触边界的为开放弧。
    """
    def k(x, y):
        return (round(x, 12), round(y, 12))

    edges = []
    node_pos = {}
    for (x1, y1, x2, y2) in segs:
        a = k(x1, y1)
        b = k(x2, y2)
        node_pos[a] = (x1, y1)
        node_pos[b] = (x2, y2)
        edges.append((a, b))

    from collections import defaultdict
    adj = defaultdict(list)
    for ei, (a, b) in enumerate(edges):
        adj[a].append((ei, b))
        adj[b].append((ei, a))

    used = [False] * len(edges)
    loops = []
    for ei in range(len(edges)):
        if used[ei]:
            continue
        used[ei] = True
        a, b = edges[ei]
        path = [a, b]

        # 向前延伸
        cur, prev = b, a
        while True:
            nxt = None
            for (ej, nb) in adj[cur]:
                if used[ej] or nb == prev:
                    continue
                used[ej] = True
                nxt = nb
                break
            if nxt is None:
                break
            path.append(nxt)
            prev, cur = cur, nxt

        # 向后延伸
        cur, prev = a, b
        while True:
            nxt = None
            for (ej, nb) in adj[cur]:
                if used[ej] or nb == prev:
                    continue
                used[ej] = True
                nxt = nb
                break
            if nxt is None:
                break
            path.insert(0, nxt)
            prev, cur = cur, nxt

        loops.append([[float(node_pos[kk][0]), float(node_pos[kk][1])]
                      for kk in path])
    return loops


def _landscape(func, n=80, progress_cb=None):
    """在 x1-x2 平面上采样二维地形，其余维固定在最优解 x_opt[2:]。

    返回 (X, Y, Z)，其中 Z[i, j] = f(x1_j, x2_i, x_opt[2:])。
    ``progress_cb(fraction, message)`` 在分块采样间回调（fraction ∈ [0, 0.08]）。
    """
    gx = np.linspace(func.lb, func.ub, n)
    gy = np.linspace(func.lb, func.ub, n)
    X, Y = np.meshgrid(gx, gy)
    fixed = np.asarray(func.x_opt[2:], dtype=float)
    pts = np.c_[X.ravel(), Y.ravel(),
                np.broadcast_to(fixed, (X.size, fixed.size))]
    Z = np.empty(X.size, dtype=float)
    chunk = max(1, X.size // 20)
    for i in range(0, X.size, chunk):
        Z[i:i + chunk] = [func(p) for p in pts[i:i + chunk]]
        if progress_cb is not None:
            frac = 0.08 * min(1.0, (i + chunk) / X.size)
            progress_cb(frac, f'采样二维地形 {min(i + chunk, X.size)}/{X.size}')
    return X, Y, Z.reshape(X.shape)


def sample(suite, dim, fid, host_name, arm='bare', fes_mult=10000,
           n_frames=20, seed=None, runs=1, progress_cb=None):
    """按需采样一个 cell 的种群收敛轨迹 + 二维地形。

    返回 dict：
      landscape : (X, Y, Z) 二维地形
      traces    : [ {'gens':[...], 'nevals':[...], 'pop':[Nx2 ndarray, ...]}, ... ]
      err_curves: [ (grid ndarray, err ndarray), ... ]
      best_x / x_opt / f_opt / lb / ub / func / dim ...

    ``progress_cb(fraction, message)`` 全程回调（0~1），供 GUI 进度条。
    """
    import cec_suites as CS
    import de_hosts as DH
    import de_hosts_cec as DHC
    from run_upcl_cec import run_arm

    func = CS.get_function(suite, dim, fid)
    max_evals = int(fes_mult * dim)
    pop_size = DHC.pop_size_for(host_name, dim)
    X, Y, Z = _landscape(func, progress_cb=progress_cb)

    # log 归一化地形（真实 log10 高度，用于 tooltip 展示真实函数值）
    Zf = np.asarray(Z, dtype=float)
    Zn = np.log10(Zf - float(Zf.min()) + 1.0)

    # 分位（rank）归一化到 0~1：让地形结构（山峰/山谷）在任意函数上都均匀可见。
    # 否则旋转 + 高次项函数（如 Zakharov）在 log 空间仍是“深井”，
    # 绝大部分网格挤在高值端，颜色与等高线都堆在一处，看起来“没有地形”。
    flat = Zn.ravel()
    order = np.argsort(np.argsort(flat))
    Zr = (order / float(max(len(flat) - 1, 1))).reshape(Zn.shape)

    # 等高线：基于分位高度 Zr 的层级，串成连续多段线（闭合圈/开放弧）
    contours = []
    for level in (0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80):
        segs = _contour_segments(Zr, level, func.lb, func.ub)
        loops = _chain_segments_to_loops(segs)
        contours.append({'level': level, 'loops': loops})

    upcl_cfg = None if arm == 'bare' else 'default'
    traces, err_curves, best_x = [], [], None

    def _run_progress(nevals, g):
        if progress_cb is not None:
            frac = 0.08 + 0.92 * min(1.0, nevals / max_evals)
            progress_cb(frac, f'运行中：第 {g} 代，已评估 {nevals}/{max_evals}')

    for r in range(runs):
        s = seed if seed is not None else \
            (20240_000 + dim * 1_000_003 + r * 7919 + fid * 31)
        rec = run_arm(host_name, func, dim, int(s), max_evals, upcl_cfg,
                      pop_size=pop_size, record_pop=True, n_pop_frames=n_frames,
                      progress_cb=_run_progress)
        pt = rec.get('pop_trace')
        if pt:
            traces.append({
                'gens': list(pt['gens']),
                'nevals': list(pt['nevals']),
                'pop': [np.asarray(p, dtype=float) for p in pt['pop']],
            })
            best_x = np.asarray(pt['best_x'], dtype=float)
        err_curves.append((np.asarray(rec.get('grid', []), dtype=float),
                           np.asarray(rec['err_curve'], dtype=float)))

    return {
        'suite': suite, 'dim': dim, 'fid': fid, 'host': host_name, 'arm': arm,
        'func': func.label, 'func_name': func.name,
        'lb': float(func.lb), 'ub': float(func.ub),
        'f_opt': float(func.f_opt),
        'landscape': (X, Y, Z),
        'z_log': Zn.tolist(),
        'z_rank': Zr.tolist(),
        'contours': contours,
        'traces': traces,
        'err_curves': err_curves,
        'best_x': best_x.tolist() if best_x is not None else None,
        'x_opt': [float(v) for v in np.asarray(func.x_opt)[:2]],
    }

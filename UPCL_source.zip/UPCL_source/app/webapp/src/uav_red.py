"""红方四课题（F1 兵力部署 / F2 预警 / F3 拦截 / F4 协同）的统一决策空间与评估器。

设计要点（详见 docs/uav_red_design.md）
-------------------------------------
* **统一 ``RedPlan``**：4 个课题不是 4 个场景，而是同一个红方配置对象
  ``RedPlan`` 的 4 个子空间。DE / DRL / LLM 三种决策器都往同一个 ``RedPlan``
  上写，下层 ``UAVEnv._rollout`` 完全无感，因此可以横向对比而不需要三套环境代码。
* **复用而非重写**：物理 / 判定 / 帧生成 / 21 项 metrics 全部复用
  ``UAVEnv._rollout``；本模块只做「红方决策变量 → EnvConfig」的映射、
  红方目标函数与约束消化。
* **维度随编成自适应**：F1 只决定「布点」不决定「定编」，所以停机坪维度 =
  ``2 × n_interceptors``（fid=1 时为 2 维，fid=3/4 时为 4 维），编成仍由
  ``fid`` 通过 ``_intercept_cfg`` 决定。
* **按课题豁免约束**：C5「停机坪须在雷达探测范围外」对 F3/F4 不生效，且这两个
  课题的停机坪 ROI 放开到全图 —— 理由见 :data:`C5_EXEMPT_MODES`。F1/F2 的约束
  集合与 ROI 保持不变。

编码约定
-------
所有连续槽位归一化到 ``[-1, 1]``（与项目内全部 DE 宿主一致），在
``decode_plan`` 内部映射到各自的 ROI / 取值区间。离散量（扫描周期、告警阈值）
在解码处取整，DE 侧无感 —— 沿用 ``uav_adversarial`` 的「离散决策在
decode/penalty 内部消化」约定。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

# _intercept_cfg / _intercept_layout 是模块私有函数，但红方课题需要拿到「未加
# 干预的原始红方配置」作为基底（fid 决定编成与禁飞区），故直接复用。
from uav_adversarial import (EnvConfig, UAVEnv, _intercept_cfg,
                             _intercept_layout)

# ===========================================================================
# 编码域与部署区域（ROI）
# ===========================================================================

LB, UB = -1.0, 1.0

# 巡逻兵分区中心个数：n_patrol 名巡逻兵均分到这些中心附近确定性散布
PATROL_ANCHORS = 2

# 各单元允许的部署区域 (x_lo, x_hi) × (y_lo, y_hi)。
# radar 允许中央大范围；helipad 覆盖「东南半区 + 贴近突防走廊」的空地 —— 一方面
# 保留出厂的东南角停机坪，另一方面允许 F2 把出动基地前推到走廊附近（这是 F2 的
# 核心权衡：C5 要求停机坪落在雷达探测范围外，故雷达越小/扇区越窄，越能把拦截机
# 前推到位；出厂 (950,50) 距走廊最近点 636 m，拦截机 63 步才能到位而无人机 60 步
# 打完，结构上够不着，F2 只优化雷达时对结局零杠杆）；aa 限定基地周边；patrol
# 限定中央巷战区域（与原生随机范围一致）。
# int_route 覆盖「突防走廊中后段 + 基地周边」：拦截航路只需覆盖蓝方必经之地，
# 起点一侧（西南角）留给蓝方突防，不必浪费航点。
ROI = {
    'radar':     ((220.0, 920.0), (220.0, 920.0)),
    'helipad':   ((560.0, 985.0), (25.0, 760.0)),
    'aa':        ((560.0, 1000.0), (560.0, 1000.0)),
    'patrol':    ((380.0, 860.0), (380.0, 860.0)),
    'int_route': ((250.0, 950.0), (250.0, 950.0)),
}

# F3 拦截 / F4 协同 的停机坪 ROI（C5 豁免后）：放开到全图，仅留 25 m 边界余量
# 避免贴边触发越界罚分。
HELIPAD_ROI_UNRESTRICTED = ((25.0, 985.0), (25.0, 985.0))

# C5（停机坪须在雷达探测范围外）的豁免课题。
#
# F3/F4 不把雷达探测距离当决策变量（固定 520），若仍要求停机坪落在雷达范围外，
# 停机坪的合法区域只剩 ``ROI['helipad']`` 的东南角窄条：DE 在 fid=3 上给 2000 次
# 评估时只能给出 infeasible 解（cost −142.63，含 penalty 159），要 8000 次才找到
# 可行解。而「从哪儿起飞」恰恰是 F3/F4 唯一的主导杠杆 —— 出厂停机坪 (950,50) 距
# 突防走廊最近点 636 m，拦截机需 63 步才到位而无人机 60 步打完，结构上够不着；
# 只调航路（不动机场）对结局零杠杆。故这两个课题豁免 C5，并把停机坪 ROI 放开到
# 全图，让 DE 真正能搜「起飞基地前推」这条路径。F1/F2 不含此豁免，行为逐位不变。
C5_EXEMPT_MODES: Tuple[str, ...] = ('intercept', 'coordinate')

# 标量槽位取值区间（连续量直接线性映射，离散量取整）
SCALAR_RANGE = {
    'radar_range':      (180.0, 620.0),
    'radar_azimuth':    (0.0, 2.0 * math.pi),
    'radar_half_angle': (math.pi / 12.0, math.pi),   # 15° ~ 180°
    'scan_period':      (1.0, 24.0),
}

# 课题 -> 自由变量槽位
MODE_SLOTS: Dict[str, Tuple[str, ...]] = {
    # F1 兵力部署：雷达站 + 停机坪 + 防空车 + 巡逻兵分区中心
    'deploy': ('radar_xy', 'helipads', 'aa_pos', 'patrol_anchors'),
    # F2 预警：雷达选址 + 拦截机出动基地 + 探测距离 + 主瓣方位/张角 + 扫描周期
    #        + 告警阈值。含停机坪的原因：预警的军事意义 = 「提前发现」+「让拦截
    #        力量在正确位置及时到位」，二者是一体的；只优化雷达会让「发现」与
    #        「出动」脱节，使预警参数对仿真结局零杠杆（增益全部来自静态代理项）。
    'ew': ('radar_xy', 'helipads', 'radar_range', 'radar_azimuth',
           'radar_half_angle', 'scan_period', 'alert_threshold'),
    # F3 拦截：出动基地 + 拦截航路。含停机坪同样是被逼出来的 —— 出厂停机坪距
    #        走廊最近点 636 m，拦截机 63 步才到位而无人机 60 步打完，光调航路
    #        够不着，必须与「从哪儿起飞」一起决策（与 F2 共用 helipads 槽位）。
    'intercept': ('helipads', 'int_routes'),
    # F4 协同：拦截层（出动基地 + 航路）+ 调度层（主责分配 + 责任区 + 逐机出动
    #        阈值），对应设计文档 §4.4 的「下层航路 + 上层分工」分层。
    'coordinate': ('helipads', 'int_routes', 'assign', 'sector_bounds',
                   'launch_threshold'),
}

MODE_NAMES = {'deploy': 'F1 兵力部署', 'ew': 'F2 预警',
              'intercept': 'F3 拦截', 'coordinate': 'F4 协同'}

# 课题「实体描述」：这个课题在战场语境下要解决什么（**不含**维度、取值等代码参数）。
# 界面上的节点信息 = 实体描述 + 参数两段：描述取这里，参数另由 describe_topic /
# topic_table 给出，避免把代码参数当成实体描述讲给读者。
MODE_DOC: Dict[str, str] = {
    'deploy': '只决定「布点」不决定「定编」：在既定编成下选择雷达站、停机坪、防空车与'
              '巡逻分区的部署位置，回答「防御力量摆在哪」。',
    'ew': '围绕「提前发现 + 让拦截力量在正确位置及时到位」：雷达选址与探测参数、出动'
          '基地必须一起决定，否则「发现」与「出动」脱节，预警参数对结局零杠杆。',
    'intercept': '围绕「从哪儿起飞、沿哪条航路拦」：出动基地与拦截机航路共同决策 —— '
                 '出厂停机坪离突防走廊太远，只调航路结构上够不着。',
    'coordinate': '在拦截航路之上再加一层调度：把主责目标分配、责任区边界与逐机出动'
                  '阈值交给优化器，即「下层航路 + 上层分工」的分层协同。',
}

# 红方（防御方）模型**已登记**的场景。目前课题 / 部署区域 / 约束 / 目标函数全部建立在
# intercept（实景突防）的 ``_intercept_cfg`` 之上：swarm（集群突防）的红方只有
# ``uav_swarm.SwarmEnv.red_cost`` 里的「拦截者巡逻航点 + 突破/击落/暴露时长三项目标」，
# 课题与约束尚未登记。故本体 / 知识图谱在 swarm 下显式给出「未注册」缺口视图，
# 绝不静默套用 intercept 的口径（见 ``web/ontology_api.py``）。
RED_SCENARIOS: Tuple[str, ...] = ('intercept',)

# 坐标类槽位 -> ROI 键（槽位名面向课题，ROI 键面向单元类型）
SLOT_ROI = {
    'radar_xy': 'radar',
    'helipads': 'helipad',
    'aa_pos': 'aa',
    'patrol_anchors': 'patrol',
    'int_routes': 'int_route',
}

# 离散（取整）标量槽位
INT_SLOTS = ('scan_period', 'alert_threshold', 'launch_threshold')


def _roi(slot: str, mode: str) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    """取坐标槽位在某课题下的部署区域。

    F3/F4 豁免 C5，停机坪改用全图 ROI（见 :data:`C5_EXEMPT_MODES`）；其余槽位与
    其余课题一律走 :data:`ROI`，保证 F1/F2 与已有结果逐位不变。
    """
    key = SLOT_ROI[slot]
    if key == 'helipad' and mode in C5_EXEMPT_MODES:
        return HELIPAD_ROI_UNRESTRICTED
    return ROI[key]


def _n_units(cfg: EnvConfig) -> int:
    """防御单元数 = 防空车 + 拦截机（F4 协同的作用对象）。"""
    return max(1, int(cfg.n_aa)) + max(1, int(cfg.n_interceptors))


def _slot_dim(slot: str, cfg: EnvConfig) -> int:
    if slot == 'radar_xy':
        return 2
    if slot == 'helipads':
        return 2 * max(1, int(cfg.n_interceptors))
    if slot == 'aa_pos':
        return 2 * max(1, int(cfg.n_aa))
    if slot == 'patrol_anchors':
        return 2 * PATROL_ANCHORS
    if slot == 'int_routes':
        return (2 * max(1, int(cfg.n_interceptors))
                * max(1, int(cfg.n_int_waypoints)))
    if slot == 'assign':
        return _n_units(cfg) * max(1, int(cfg.n_drones))
    if slot == 'sector_bounds':
        return _n_units(cfg)          # n_units 个 logits -> n_units-1 个边界
    if slot == 'launch_threshold':
        return max(1, int(cfg.n_interceptors))
    return 1


def plan_dim(mode: str, cfg: EnvConfig) -> int:
    """红方该课题的连续决策维度 D。"""
    return sum(_slot_dim(s, cfg) for s in MODE_SLOTS[mode])


def _unit(v: float) -> float:
    """[-1,1] -> [0,1]。"""
    return 0.5 * (float(v) + 1.0)


def _lin(v: float, lo: float, hi: float) -> float:
    return lo + _unit(v) * (hi - lo)


# ===========================================================================
# 红方配置对象
# ===========================================================================


@dataclass
class RedPlan:
    """一次红方部署/预警方案的完整描述（4 课题的统一载体）。"""

    mode: str = 'deploy'
    radar_xy: Optional[Tuple[float, float]] = None
    helipads: Optional[List[Tuple[float, float]]] = None
    aa_pos: Optional[List[Tuple[float, float]]] = None
    patrol_anchors: Optional[List[Tuple[float, float]]] = None
    radar_range: Optional[float] = None
    radar_azimuth: Optional[float] = None
    radar_half_angle: Optional[float] = None
    scan_period: Optional[int] = None
    alert_threshold: Optional[int] = None
    # —— F3 拦截 ——
    # 各拦截机的巡逻/拦截航点（拍平为 [k*K + j] 的实际地图坐标，K = n_int_waypoints）：
    # 拦截机起飞后沿本机航点闭环巡逻，仅在侦察圆锥内发现目标时转追击。
    int_routes: Optional[List[Tuple[float, float]]] = None
    # —— F4 协同 ——
    # 主责目标索引（行序：防空车在前 n_aa 行、拦截机在后 n_int 行；-1 = 自由交战）
    assign: Optional[List[int]] = None
    # 责任区方位角边界（rad，相对基地、升序，长度 = 单元数 − 1）
    sector_bounds: Optional[List[float]] = None
    # 拦截机逐机出动阈值（各机需同时看到 N 个目标才起飞）
    launch_threshold: Optional[List[int]] = None

    def units(self) -> List[Tuple[str, float, float]]:
        """展开为全部可部署单元 [(类型, x, y), ...]，供约束检查与覆盖计算。"""
        out: List[Tuple[str, float, float]] = []
        if self.radar_xy is not None:
            out.append(('radar', float(self.radar_xy[0]), float(self.radar_xy[1])))
        for p in self.helipads or []:
            out.append(('helipad', float(p[0]), float(p[1])))
        for p in self.aa_pos or []:
            out.append(('aa', float(p[0]), float(p[1])))
        for p in self.patrol_anchors or []:
            out.append(('patrol', float(p[0]), float(p[1])))
        return out

    def describe(self, cfg: EnvConfig) -> Dict[str, object]:
        d: Dict[str, object] = {'课题': MODE_NAMES.get(self.mode, self.mode)}
        if self.radar_xy is not None:
            d['雷达站'] = f'({self.radar_xy[0]:.0f}, {self.radar_xy[1]:.0f})'
        if self.helipads:
            d['停机坪'] = ', '.join(f'({p[0]:.0f},{p[1]:.0f})' for p in self.helipads)
        if self.aa_pos:
            d['防空车'] = ', '.join(f'({p[0]:.0f},{p[1]:.0f})' for p in self.aa_pos)
        if self.patrol_anchors:
            d['巡逻分区'] = ', '.join(f'({p[0]:.0f},{p[1]:.0f})'
                                      for p in self.patrol_anchors)
        if self.radar_range is not None:
            d['探测距离'] = f'{self.radar_range:.0f}'
        if self.radar_half_angle is not None:
            d['主瓣半张角'] = f'{math.degrees(self.radar_half_angle):.1f}°'
        if self.radar_azimuth is not None:
            d['主瓣方位角'] = f'{math.degrees(self.radar_azimuth):.1f}°'
        if self.scan_period is not None:
            d['扫描周期'] = f'{self.scan_period} 步'
        if self.alert_threshold is not None:
            d['告警阈值'] = f'{self.alert_threshold} 目标'
        if self.int_routes:
            kk = max(1, int(getattr(cfg, 'n_int_waypoints', 1)))
            groups = [self.int_routes[j:j + kk]
                      for j in range(0, len(self.int_routes), kk)]
            d['拦截航路'] = ' | '.join(
                '机%d:%s' % (k, '->'.join(f'({p[0]:.0f},{p[1]:.0f})' for p in g))
                for k, g in enumerate(groups))
        if self.assign:
            d['主责分配'] = ', '.join('自由' if v < 0 else f'打目标{v}'
                                      for v in self.assign)
        if self.sector_bounds:
            d['责任区边界'] = ', '.join(f'{math.degrees(v):.0f}°'
                                        for v in self.sector_bounds)
        if self.launch_threshold:
            d['逐机出动阈值'] = ', '.join(str(int(v))
                                          for v in self.launch_threshold)
        return d


def _decode_assign(seg: np.ndarray, cfg: EnvConfig) -> List[int]:
    """软分配 logits -> 一对一硬分配（贪心去冲突；-1 = 未分到、自由交战）。

    ``seg`` 形状 = ``n_units × n_drones``。按每行最大 logit 从高到低「抢」目标：
    置信度最高的单元先选，已被占用的目标不再分给别人；剩下的单元记 -1（退回
    自由贪心）。n_units > n_drones 时必然有单元分不到 —— 这正是协同的价值：
    让抢不到目标的单元别去重复打击同一架。
    """
    n_units = _n_units(cfg)
    n_d = max(1, int(cfg.n_drones))
    m = np.asarray(seg, dtype=float).ravel()[:n_units * n_d].reshape(n_units, n_d)
    order = sorted(range(n_units), key=lambda r: -float(np.max(m[r])))
    out = [-1] * n_units
    taken: set = set()
    for r in order:
        if float(np.max(m[r])) <= 0.0:
            continue                      # 该单元没给出偏好 -> 不分配（自由贪心，
            #                               与出厂行为一致；见 _encode_assign）
        c = int(np.argmax(m[r]))
        if c not in taken:
            out[r] = c
            taken.add(c)
    return out


def _decode_sector(seg: np.ndarray) -> List[float]:
    """n_units 个 logits -> n_units−1 个责任区边界角（rad，升序且落在 [-pi, pi)）。

    用 softmax 得到各扇区「份额」再取累积和作为边界：天然升序、连续可微，且
    logits 全相等时退化为均匀划分（360°/n_units 一段）。相比「直接编码角度再
    排序」，它没有组合跳变，DE 好优化。
    """
    lg = np.asarray(seg, dtype=float).ravel()
    if lg.size <= 1:
        return []
    if float(np.ptp(lg)) < 1e-9:
        return []                         # 全等 -> 不分区（出厂默认；见 _encode_sector）
    e = np.exp(lg - float(lg.max()))
    p = e / float(e.sum())
    return [float(v * 2.0 * math.pi - math.pi) for v in np.cumsum(p)[:-1]]


def routes_to_red_x(plan: RedPlan, cfg: EnvConfig) -> Optional[np.ndarray]:
    """``plan.int_routes``（实际地图坐标）-> ``_rollout`` 的 ``red_x`` 归一化编码。

    与 ``_decode_red_waypoints`` 的约定一致：``[-1,1]`` 线性映射到
    ``[0,map_w] × [0,map_h]``。未给航路时返回 None（拦截机退回规则追击）。
    """
    if not plan.int_routes:
        return None
    n_int = max(1, int(cfg.n_interceptors))
    kk = max(1, int(cfg.n_int_waypoints))
    arr = np.zeros(n_int * kk * 2, dtype=float)
    for idx in range(n_int * kk):
        if idx >= len(plan.int_routes):
            break
        px, py = plan.int_routes[idx]
        arr[2 * idx] = 2.0 * float(px) / float(cfg.map_w) - 1.0
        arr[2 * idx + 1] = 2.0 * float(py) / float(cfg.map_h) - 1.0
    return np.clip(arr, LB, UB)


def default_int_routes(cfg: EnvConfig, t_lo: float = 0.30,
                       t_hi: float = 0.75) -> List[Tuple[float, float]]:
    """出厂配置里没有「巡逻航路」可读，故给一个中性起点：沿突防走廊中后段等分。

    拦截机真正能巡到哪儿取决于停机坪，所以这只是 ``baseline_x`` 的参考起点
    （真基线请用 :func:`evaluate_base`），DE 会从它出发自行搜索航路。
    """
    sx, sy = float(cfg.start_pos[0]), float(cfg.start_pos[1])
    bx, by = float(cfg.base_pos[0]), float(cfg.base_pos[1])
    n_int = max(1, int(cfg.n_interceptors))
    kk = max(1, int(cfg.n_int_waypoints))
    out: List[Tuple[float, float]] = []
    for k in range(n_int):
        off = 40.0 * (k - (n_int - 1) / 2.0)      # 多机时横向错开，避免完全重合
        for j in range(kk):
            t = t_lo + (t_hi - t_lo) * ((j + 0.5) / kk)
            out.append((sx + (bx - sx) * t + off, sy + (by - sy) * t + off))
    return out


def _encode_assign(plan: RedPlan, cfg: EnvConfig) -> List[float]:
    """硬分配 -> logits 矩阵（被分配列 +1、其余 -1），与 :func:`_decode_assign` 互逆。"""
    n_units = _n_units(cfg)
    n_d = max(1, int(cfg.n_drones))
    rows = list(plan.assign or [-1] * n_units)
    out = [-1.0] * (n_units * n_d)
    for r in range(n_units):
        c = rows[r] if r < len(rows) else -1
        if 0 <= c < n_d:
            out[r * n_d + c] = 1.0
    return out


def _encode_sector(plan: RedPlan, cfg: EnvConfig) -> List[float]:
    """责任区边界 -> logits（各扇区宽度的对数再去均值），与 :func:`_decode_sector` 互逆。

    注意 logits 维度是 ``n_units``，而方案里存的是 ``n_units−1`` 个边界（少一个），
    所以「无边界」必须补成 ``n_units`` 个 0（= 均匀划分），否则编码维度会缺。
    """
    n_units = _n_units(cfg)
    edges = [-math.pi] + [float(v) for v in (plan.sector_bounds or [])]
    edges.append(math.pi)
    if len(edges) - 1 != n_units:            # 无边界（或长度不符）-> 均匀划分
        return [0.0] * n_units
    w = [max(1e-6, edges[i + 1] - edges[i]) for i in range(n_units)]
    lg = [math.log(v) for v in w]
    mu = sum(lg) / len(lg)
    return [v - mu for v in lg]


def decode_plan(x: Sequence[float], mode: str, cfg: EnvConfig) -> RedPlan:
    """连续编码 ``[-1,1]^D`` -> :class:`RedPlan`。

    按 ``MODE_SLOTS[mode]`` 的顺序依次切分；坐标类槽位在各自 ROI 内线性映射，
    标量槽位按 ``SCALAR_RANGE`` 映射（离散量取整）。
    """
    x = np.asarray(x, dtype=float).ravel()
    need = plan_dim(mode, cfg)
    if x.size < need:
        raise ValueError(f'红方编码维度不足：需要 {need}，实际 {x.size}')
    plan = RedPlan(mode=mode)
    i = 0
    for slot in MODE_SLOTS[mode]:
        d = _slot_dim(slot, cfg)
        seg = x[i:i + d]
        i += d
        if slot in SLOT_ROI:
            (xlo, xhi), (ylo, yhi) = _roi(slot, mode)
            n = d // 2
            plan_pts = [(_lin(seg[2 * k], xlo, xhi),
                         _lin(seg[2 * k + 1], ylo, yhi)) for k in range(n)]
            if slot == 'radar_xy':
                plan.radar_xy = plan_pts[0]
            elif slot == 'helipads':
                plan.helipads = plan_pts
            elif slot == 'aa_pos':
                plan.aa_pos = plan_pts
            elif slot == 'patrol_anchors':
                plan.patrol_anchors = plan_pts
            elif slot == 'int_routes':
                plan.int_routes = plan_pts
            continue
        if slot == 'alert_threshold':
            hi = float(max(1, int(cfg.n_drones)))
            plan.alert_threshold = int(round(_lin(seg[0], 1.0, hi)))
        elif slot == 'scan_period':
            lo, hi = SCALAR_RANGE[slot]
            plan.scan_period = max(1, int(round(_lin(seg[0], lo, hi))))
        elif slot == 'launch_threshold':
            hi = float(max(1, int(cfg.n_drones)))
            plan.launch_threshold = [max(1, int(round(_lin(v, 1.0, hi))))
                                     for v in seg]
        elif slot == 'assign':
            plan.assign = _decode_assign(seg, cfg)
        elif slot == 'sector_bounds':
            plan.sector_bounds = _decode_sector(seg)
        else:
            lo, hi = SCALAR_RANGE[slot]
            setattr(plan, slot, _lin(seg[0], lo, hi))
    return plan


# ===========================================================================
# RedPlan -> EnvConfig 映射（下层 _rollout 完全无感）
# ===========================================================================


def effective_radar_range(range_nominal: float, half_angle: float,
                          sector_gain: bool = True) -> float:
    """定向天线的等效探测距离。

    窄主瓣把同样的发射能量集中到更小的立体角内，按双程 R^4 雷达方程，
    距离增益 ∝ (pi / half_angle) ** 0.25。``half_angle = pi``（全向）时
    增益恰为 1.0，即退化为原行为 —— 这是 F2「窄扇区换远距」权衡的物理模型。
    """
    if not sector_gain:
        return float(range_nominal)
    half = max(float(half_angle), 1e-6)
    return float(range_nominal) * (math.pi / half) ** 0.25


def apply_plan(plan: RedPlan, base_cfg: EnvConfig,
               sector_gain: bool = True) -> Tuple[EnvConfig, dict]:
    """把 :class:`RedPlan` 应用到 ``EnvConfig`` 上，返回 (cfg, layout)。

    不修改 ``base_cfg``（``dataclasses.replace`` 浅拷贝 + 显式复制可变字段）。
    ``layout`` 沿用 ``_intercept_layout``，若方案给出巡逻分区中心则附加
    ``layout['patrol']``（``UAVEnv`` 已支持该键）。
    """
    cfg = replace(base_cfg)
    cfg.no_fly_zones = list(base_cfg.no_fly_zones)
    cfg.interceptor_pos = list(base_cfg.interceptor_pos)
    cfg.aa_pos = list(base_cfg.aa_pos)

    if plan.radar_xy is not None:
        cfg.radar_pos = (float(plan.radar_xy[0]), float(plan.radar_xy[1]))
    if plan.helipads:
        cfg.interceptor_pos = [(float(p[0]), float(p[1])) for p in plan.helipads]
    if plan.aa_pos:
        cfg.aa_pos = [(float(p[0]), float(p[1])) for p in plan.aa_pos]
    if plan.radar_range is not None:
        cfg.radar_range = float(plan.radar_range)
    if plan.radar_azimuth is not None:
        cfg.radar_azimuth = float(plan.radar_azimuth)
    if plan.radar_half_angle is not None:
        cfg.radar_half_angle = float(plan.radar_half_angle)
    if plan.scan_period is not None:
        cfg.scan_period = max(1, int(plan.scan_period))
    if plan.alert_threshold is not None:
        cfg.alert_threshold = max(1, int(plan.alert_threshold))
    # F4 协同：主责分配 / 责任区边界 / 逐机出动阈值（None 时保持原「独立贪心 +
    # 全局告警」行为）。航路 int_routes 不进 cfg —— 它是 _rollout 的调用参数。
    if plan.assign is not None:
        cfg.assign_target = [int(v) for v in plan.assign]
    if plan.sector_bounds is not None:
        cfg.sector_bounds = [float(v) for v in plan.sector_bounds]
    if plan.launch_threshold is not None:
        cfg.launch_threshold = [max(1, int(v)) for v in plan.launch_threshold]

    # 窄主瓣 -> 等效探测距离变远（全向时增益为 1，与原行为完全一致）
    cfg.radar_range = effective_radar_range(cfg.radar_range,
                                           cfg.radar_half_angle, sector_gain)
    # 编成随布点同步（维度依赖项，与 _build_env 的做法一致）
    cfg.n_interceptors = len(cfg.interceptor_pos)
    cfg.n_aa = len(cfg.aa_pos)

    layout = _intercept_layout(cfg)
    if plan.patrol_anchors:
        layout['patrol'] = [(float(p[0]), float(p[1]))
                            for p in plan.patrol_anchors]
    return cfg, layout


# ===========================================================================
# 约束消化（6 条约束：违约以罚分形式被优化器无感吸收）
# ===========================================================================


@dataclass
class RedConstraints:
    """红方部署的硬约束（以分级罚分实现，DE 无感）。"""

    radar_base_max: float = 620.0     # C2 雷达站到基地距离上限
    min_sep: float = 70.0             # C3 单元间最小间距
    aa_cover_base: bool = True        # C4 防空车必须覆盖基地
    # C5 停机坪须在雷达探测范围外。F3/F4 豁免（见 C5_EXEMPT_MODES）：
    # :func:`red_evaluate` 会按课题自动把它置 False，无需调用方手工传参。
    helipad_out_of_radar: bool = True
    penalty_scale: float = 800.0      # 违约罚分系数（基础目标量级 ~10^2）

    def check(self, plan: RedPlan, cfg: EnvConfig
              ) -> Tuple[List[Tuple[str, float, str]], float]:
        """返回 (violations, penalty)。violations = [(名称, 严重度∈[0,1], 说明)]。"""
        viol: List[Tuple[str, float, str]] = []
        base = (float(cfg.base_pos[0]), float(cfg.base_pos[1]))
        units = plan.units()

        # C1 任一单元不得落在禁飞区
        for (kind, ux, uy) in units:
            for (nx, ny, _nz, nr) in cfg.no_fly_zones:
                nx, ny, nr = float(nx), float(ny), float(nr)
                d = math.hypot(ux - nx, uy - ny)
                if d < nr:
                    viol.append(('no_fly', (nr - d) / max(nr, 1.0),
                                 f'{kind}({ux:.0f},{uy:.0f}) 落入禁飞区(r={nr:.0f})'))

        # C2 雷达站不得远离基地（不允许把预警设施藏到地图角落）
        if plan.radar_xy is not None:
            d = math.hypot(plan.radar_xy[0] - base[0], plan.radar_xy[1] - base[1])
            if d > self.radar_base_max:
                viol.append(('radar_base',
                             (d - self.radar_base_max) / self.radar_base_max,
                             f'雷达距基地 {d:.0f} > {self.radar_base_max:.0f}'))

        # C3 单元间最小间距（排除「全部堆在一格」的退化解，兼顾相互暴露）
        for i in range(len(units)):
            for j in range(i + 1, len(units)):
                d = math.hypot(units[i][1] - units[j][1],
                               units[i][2] - units[j][2])
                if d < self.min_sep:
                    viol.append(('min_sep',
                                 (self.min_sep - d) / self.min_sep,
                                 f'{units[i][0]}×{units[j][0]} 间距 {d:.0f}'
                                 f' < {self.min_sep:.0f}'))

        # C4 防空车必须能覆盖基地（否则失去「拱卫基地」的部署意义）
        if self.aa_cover_base:
            for p in plan.aa_pos or []:
                d = math.hypot(float(p[0]) - base[0], float(p[1]) - base[1])
                if d > cfg.aa_range:
                    viol.append(('aa_cover', (d - cfg.aa_range) / cfg.aa_range,
                                 f'防空车距基地 {d:.0f} > 射程 {cfg.aa_range:.0f}'))

        # C5 停机坪须在雷达探测范围外（保持「停靠待命、雷达捕获才出动」语义）。
        # F3/F4 不带本项（self.helipad_out_of_radar=False，由 red_evaluate 按课题置位）。
        if self.helipad_out_of_radar and plan.helipads:
            rx, ry = float(cfg.radar_pos[0]), float(cfg.radar_pos[1])
            rr = float(cfg.radar_range)
            if rr > 0.0:
                for p in plan.helipads:
                    d = math.hypot(float(p[0]) - rx, float(p[1]) - ry)
                    if d <= rr:
                        viol.append(('helipad_in_radar', (rr - d) / rr,
                                     f'停机坪距雷达 {d:.0f} ≤ 探测距离 {rr:.0f}'))

        # C6 拦截航路不得穿过禁飞区（否则等于让拦截机穿山/穿禁区飞，失去意义）
        for (rx, ry) in (plan.int_routes or []):
            for (nx, ny, _nz, nr) in cfg.no_fly_zones:
                nx, ny, nr = float(nx), float(ny), float(nr)
                d = math.hypot(float(rx) - nx, float(ry) - ny)
                if d < nr:
                    viol.append(('route_nofly', (nr - d) / max(nr, 1.0),
                                 f'航点({rx:.0f},{ry:.0f}) 落入禁飞区(r={nr:.0f})'))

        return viol, self.penalty_scale * sum(s for _, s, _ in viol)


# ===========================================================================
# 静态覆盖评估（纯几何、零仿真）与红方目标函数
# ===========================================================================


def static_coverage(plan: RedPlan, cfg: EnvConfig, n_samples: int = 64,
                    patrol_xy: Optional[Sequence[Tuple[float, float]]] = None
                    ) -> Tuple[float, float]:
    """静态覆盖缺口 + 后勤散布代价（毫秒级，供目标塑形与可解释诊断）。

    采样点 = 蓝方突防通道（起点→基地直线）+ 基地周边环。覆盖源 = 防空车对空
    范围 + 巡逻兵可视范围。**雷达是传感器不是火力单元、拦截机是机动单元，两者
    都不进入静态覆盖项**（其价值只由仿真结局体现）；否则优化器会靠「把雷达半径
    顶满 / 把主瓣压到 15°」直接把 gap 刷到 0 而不改善任何实际拦截效果 ——
    实测该刷分路径可凭空产出 ~46 分「增益」（radar_range=5000 时 cost
    -305.96 → -352.21，而全部仿真指标逐位不变）。

    ``patrol_xy`` 给出时以其为巡逻兵实际位置（真实基线用）；否则用方案的分区
    中心并加上 ±28 m 的散布余量。
    """
    sx, sy = float(cfg.start_pos[0]), float(cfg.start_pos[1])
    bx, by = float(cfg.base_pos[0]), float(cfg.base_pos[1])
    pts: List[Tuple[float, float]] = []
    for i in range(n_samples):
        t = (i + 0.5) / n_samples
        pts.append((sx + (bx - sx) * t, sy + (by - sy) * t))
    for i in range(n_samples // 2):
        th = 2.0 * math.pi * i / max(1, n_samples // 2)
        pts.append((bx + cfg.base_radius * math.cos(th),
                    by + cfg.base_radius * math.sin(th)))

    covers: List[Tuple[float, float, float]] = []
    for p in cfg.aa_pos:
        covers.append((float(p[0]), float(p[1]), float(cfg.aa_range)))
    if patrol_xy is None:
        for p in plan.patrol_anchors or []:
            covers.append((float(p[0]), float(p[1]),
                           float(cfg.patrol_vision_range) + 28.0))
    else:
        for p in patrol_xy:
            covers.append((float(p[0]), float(p[1]),
                           float(cfg.patrol_vision_range)))

    n_cov = 0
    for (px, py) in pts:
        for (cx, cy, cr) in covers:
            if math.hypot(px - cx, py - cy) <= cr:
                n_cov += 1
                break
    gap = 1.0 - n_cov / max(len(pts), 1)

    diag = math.hypot(cfg.map_w, cfg.map_h)
    units = plan.units()
    deploy = (sum(math.hypot(u[1] - bx, u[2] - by) for u in units)
              / max(len(units), 1) / diag)
    return gap, deploy


@dataclass
class RedWeights:
    """红方目标的连续塑形项权重（离散结局由 cfg.w_arrive/w_lost 主导）。"""

    early: float = 150.0    # 及早交战：first_capture 越早该项越大（从未交战记 0）
    risk: float = 90.0      # 暴露压制：risk_time / n_steps
    gap: float = 120.0      # 通道覆盖缺口罚分
    deploy: float = 30.0    # 后勤散布代价（防止单元全部堆向基地）


def red_objective(metrics: Dict, cfg: EnvConfig, gap: float, deploy: float,
                  w: RedWeights) -> float:
    """红方目标（越小越好）。

    = 突破罚 − 击落奖（离散结局，主导）
      − 及早交战奖 − 暴露压制奖（连续，提供搜索梯度）
      + 覆盖缺口罚 + 后勤散布罚

    注意：原来的 ``red_cost`` 用了未归一化的 ``0.5 * risk_time``；此处改为
    ``w.risk * risk_time / n_steps``，使各连续项同量纲、权重可直接比较。
    """
    base = (cfg.w_arrive * metrics['n_arrived']
            - cfg.w_lost * metrics['n_lost'])
    eng = float(metrics['first_capture'])
    if eng < 0.0:                      # -1 = 全程未被拦截，视作「无预警」
        eng = float(cfg.n_steps)
    early = (float(cfg.n_steps) - eng) / max(float(cfg.n_steps), 1.0)
    risk = float(metrics['risk_time']) / max(float(cfg.n_steps), 1.0)
    return (base - w.early * early - w.risk * risk
            + w.gap * gap + w.deploy * deploy)


# ===========================================================================
# 统一红方评估器（4 课题共用）
# ===========================================================================


def red_evaluate(x: Optional[Sequence[float]] = None, mode: str = 'deploy',
                 base_cfg: Optional[EnvConfig] = None, *, plan: Optional[RedPlan] = None,
                 blue_x: Optional[Sequence[float]] = None, seed: int = 0,
                 weights: Optional[RedWeights] = None,
                 cons: Optional[RedConstraints] = None,
                 sector_gain: bool = True,
                 want_frames: bool = False) -> Dict:
    """评估一个红方方案，返回含 cost / objective / penalty / 全部仿真 metrics 的 dict。

    ``x`` 为 ``[-1,1]^D`` 连续编码；也可直接传 ``plan=``。``blue_x`` 为固定的
    蓝方航点编码（None 时用 :func:`straight_blue_x` 的「直扑基地」基准对手）。
    """
    if base_cfg is None:
        raise ValueError('必须给出 base_cfg（用 _intercept_cfg(fid) 取得基底）')
    w = weights or RedWeights()
    cons = cons or RedConstraints()
    if mode in C5_EXEMPT_MODES and cons.helipad_out_of_radar:
        # F3/F4 豁免 C5（见 C5_EXEMPT_MODES）：这两个课题的雷达探测距离不是决策
        # 变量（固定 520），若仍要求停机坪落在雷达范围外，起飞基地只剩东南角窄条，
        # DE 在 fid=3 上 2000 evals 内给不出可行解。此处按课题自动豁免，调用方
        # （含 RedProblem）无需手工传参；F1/F2 不受影响。
        cons = replace(cons, helipad_out_of_radar=False)
    if plan is None:
        if x is None:
            raise ValueError('必须给出 x 或 plan')
        if isinstance(x, RedPlan):
            plan = x
        else:
            plan = decode_plan(x, mode, base_cfg)

    cfg, layout = apply_plan(plan, base_cfg, sector_gain=sector_gain)
    # 红方决策的三条注入通道（下层 _rollout 无感）：
    #   ① 布点/预警  -> cfg（apply_plan 已写）
    #   ② F3 拦截航路 -> red_x（_rollout 参数，拦截机沿航点闭环巡逻）
    #   ③ F4 协同调度 -> cfg.assign_target / sector_bounds / launch_threshold
    # opponent=None：拦截机走 _rollout 内置规则（感知锥内追击 + 航点巡逻）。
    # 策略型红方（DRL 对手）走 OpponentPolicy 接口，属设计文档 P2，不在本轮。
    env = UAVEnv(cfg, seed=seed, layout=layout)
    if blue_x is None:
        blue_x = straight_blue_x(base_cfg)
    red_x = routes_to_red_x(plan, cfg)
    _cost, state, metrics, frames = env._rollout(blue_x, record=want_frames,
                                                 red_x=red_x)

    # 覆盖/后勤按「生效的完整部署」计（含该课题未优化的单元），否则 F2（不优化
    # 巡逻兵/防空车）会漏算它们的贡献，导致跨课题口径不一致。
    eff = plan_from_cfg(cfg, 'deploy')
    if plan.patrol_anchors:
        eff.patrol_anchors = list(plan.patrol_anchors)
    gap, deploy = static_coverage(
        eff, cfg, patrol_xy=None if eff.patrol_anchors else env.patrol0)
    # 约束只检查「决策变量本身」（解是否可行），未优化单元的出厂状态不参与判罚
    viol, penalty = cons.check(plan, cfg)
    obj = red_objective(metrics, cfg, gap, deploy, w)

    out: Dict = dict(metrics)
    out.update({
        'cost': obj + penalty,
        'objective': obj,
        'penalty': penalty,
        'feasible': len(viol) == 0,
        'n_violations': len(viol),
        'violations': viol,
        'coverage_gap': gap,
        'deploy_cost': deploy,
        'radar_range_eff': float(cfg.radar_range),
        'plan': plan,
        'plan_desc': plan.describe(cfg),
        'full_plan': eff,
        'cfg': cfg,
        'layout': layout,
        'units': eff.units(),
    })
    if want_frames:
        out['frames'] = frames
        out['state'] = [int(s) for s in state]
    return out


# ===========================================================================
# 固定对手、真基线 与 编码逆变换
# ===========================================================================


def straight_blue_x(cfg: EnvConfig, z_off_frac: float = 0.5) -> np.ndarray:
    """构造「直扑基地」的蓝方航点编码，作为红方评估的固定基准对手。

    每架无人机 / 步兵沿 起点→基地 直线等分取 K 个中途航点，高度取
    贴地 + 半程爬升偏移。这是无优化的朴素突防方案，用于让所有红方方案面对
    同一个对手，保证横向可比（红方优化本质是 min–max，固定对手是最简内层）。
    """
    lay = _intercept_layout(cfg)
    starts = list(lay['starts'])
    inf = list(lay['infantry'])
    bx, by = float(cfg.base_pos[0]), float(cfg.base_pos[1])
    x = np.zeros(cfg.dim, dtype=float)
    k = 0
    for i in range(cfg.n_drones):
        sx, sy = starts[i % len(starts)]
        for j in range(cfg.n_waypoints):
            t = (j + 1) / (cfg.n_waypoints + 1)
            x[k] = 2.0 * (sx + (bx - sx) * t) / cfg.map_w - 1.0
            x[k + 1] = 2.0 * (sy + (by - sy) * t) / cfg.map_h - 1.0
            x[k + 2] = 2.0 * z_off_frac - 1.0
            k += 3
    for i in range(cfg.n_infantry):
        sx, sy = inf[i % len(inf)]
        for j in range(cfg.n_waypoints):
            t = (j + 1) / (cfg.n_waypoints + 1)
            x[k] = 2.0 * (sx + (bx - sx) * t) / cfg.map_w - 1.0
            x[k + 1] = 2.0 * (sy + (by - sy) * t) / cfg.map_h - 1.0
            k += 2
    return np.clip(x, LB, UB)


def plan_from_cfg(cfg: EnvConfig, mode: str = 'deploy') -> RedPlan:
    """把 ``cfg`` 里现行的红方配置读成一个 :class:`RedPlan`（仅该课题的自由槽位）。"""
    plan = RedPlan(mode=mode)
    plan.radar_xy = (float(cfg.radar_pos[0]), float(cfg.radar_pos[1]))
    slots = MODE_SLOTS[mode]
    if 'helipads' in slots:
        plan.helipads = [(float(p[0]), float(p[1])) for p in cfg.interceptor_pos]
    if 'aa_pos' in slots:
        plan.aa_pos = [(float(p[0]), float(p[1])) for p in cfg.aa_pos]
    if 'radar_range' in slots:
        plan.radar_range = float(cfg.radar_range)
    if 'radar_azimuth' in slots:
        plan.radar_azimuth = float(cfg.radar_azimuth)
    if 'radar_half_angle' in slots:
        plan.radar_half_angle = float(cfg.radar_half_angle)
    if 'scan_period' in slots:
        plan.scan_period = int(cfg.scan_period)
    if 'alert_threshold' in slots:
        plan.alert_threshold = int(cfg.alert_threshold)
    if 'int_routes' in slots:
        plan.int_routes = default_int_routes(cfg)
    if 'assign' in slots:
        plan.assign = [-1] * _n_units(cfg)        # 出厂 = 各单元自由贪心
    if 'sector_bounds' in slots:
        plan.sector_bounds = None                 # 出厂 = 不分区（全向）
    if 'launch_threshold' in slots:
        plan.launch_threshold = [max(1, int(cfg.alert_threshold))] * max(
            1, int(cfg.n_interceptors))
    return plan


def encode_plan(plan: RedPlan, mode: str, cfg: EnvConfig) -> np.ndarray:
    """:class:`RedPlan` -> ``[-1,1]^D``（:func:`decode_plan` 的逆），用于基线与回放。"""

    def inv(v: float, lo: float, hi: float) -> float:
        return 2.0 * (float(v) - lo) / (hi - lo) - 1.0

    out: List[float] = []
    for slot in MODE_SLOTS[mode]:
        if slot in SLOT_ROI:
            (xlo, xhi), (ylo, yhi) = _roi(slot, mode)
            pts = {'radar_xy': [plan.radar_xy], 'helipads': plan.helipads,
                   'aa_pos': plan.aa_pos,
                   'patrol_anchors': plan.patrol_anchors,
                   'int_routes': (plan.int_routes
                                  or default_int_routes(cfg))}[slot]
            for p in pts:
                out.append(inv(p[0], xlo, xhi))
                out.append(inv(p[1], ylo, yhi))
            continue
        if slot == 'alert_threshold':
            out.append(inv(plan.alert_threshold, 1.0, float(max(1, cfg.n_drones))))
        elif slot == 'launch_threshold':
            hi = float(max(1, cfg.n_drones))
            for v in (plan.launch_threshold
                      or [1] * max(1, cfg.n_interceptors)):
                out.append(inv(v, 1.0, hi))
        elif slot == 'assign':
            out.extend(_encode_assign(plan, cfg))
        elif slot == 'sector_bounds':
            out.extend(_encode_sector(plan, cfg))
        else:
            lo, hi = SCALAR_RANGE[slot]
            out.append(inv(getattr(plan, slot), lo, hi))
    return np.clip(np.asarray(out, dtype=float), LB, UB)


def evaluate_base(base_cfg: EnvConfig, *, blue_x: Optional[Sequence[float]] = None,
                  seed: int = 0, weights: Optional[RedWeights] = None) -> Dict:
    """评估「未经优化」的出厂红方配置 —— 真基线。

    与 :func:`red_evaluate` 的唯一区别是巡逻兵用 ``UAVEnv`` 原生的
    ``[380,860]²`` 均匀随机散布（而非 2 个分区中心的锚定散布），因此静态覆盖
    也用实际巡逻兵位置计算。
    """
    w = weights or RedWeights()
    env = UAVEnv(base_cfg, seed=seed, layout=_intercept_layout(base_cfg))
    if blue_x is None:
        blue_x = straight_blue_x(base_cfg)
    _c, _state, metrics, _f = env._rollout(blue_x, record=False)
    plan = plan_from_cfg(base_cfg, 'deploy')
    gap, deploy = static_coverage(plan, base_cfg, patrol_xy=env.patrol0)
    obj = red_objective(metrics, base_cfg, gap, deploy, w)
    out: Dict = dict(metrics)
    out.update({'cost': obj, 'objective': obj, 'penalty': 0.0, 'feasible': True,
                'n_violations': 0, 'violations': [], 'coverage_gap': gap,
                'deploy_cost': deploy,
                'radar_range_eff': float(base_cfg.radar_range),
                'patrol_xy': list(env.patrol0)})
    return out


def baseline_x(mode: str, cfg: EnvConfig) -> np.ndarray:
    """把出厂配置编码回 ``[-1,1]^D``，作为优化起点参考与「DE 是否进步」的自检。

    ⚠ F1 的巡逻兵在出厂配置里是 ``[380,860]²`` 上的**均匀随机散布**，无法用 2 个
    分区中心精确表示，此处以两个 ``(620,620)`` 中心近似 —— **它不是真基线**，
    真基线请用 :func:`evaluate_base`。
    """
    plan = plan_from_cfg(cfg, mode)
    if 'patrol_anchors' in MODE_SLOTS[mode]:
        # 两个中心沿 x 方向错开，使锚定散布的标准差与出厂均匀分布
        # [380,860]² 的标准差（480/√12 ≈ 139）相当，且满足 C3 最小间距
        plan.patrol_anchors = [(481.0, 620.0), (759.0, 620.0)]
    return encode_plan(plan, mode, cfg)


# ===========================================================================
# DE 适配（与 CECFunction 鸭子类型一致：lb/ub/dim/f_opt/label/fid/category）
# ===========================================================================


class RedProblem:
    """把红方课题包装成 DE 可直接消费的问题对象。

    ``blue_x`` 为固定的蓝方对手（None 时用「直扑基地」基准）；红方优化本质是
    min–max，固定对手是最简内层；要抗不同蓝方部署需在外层对 ``blue_x`` 做
    域随机化（见设计文档 §10 风险 1）。
    """

    def __init__(self, mode: str = 'deploy', fid: int = 1, seed: int = 0, *,
                 blue_x: Optional[Sequence[float]] = None,
                 weights: Optional[RedWeights] = None,
                 cons: Optional[RedConstraints] = None,
                 sector_gain: bool = True, name: str = ''):
        self.mode = mode
        self.fid = int(fid)
        self.seed = int(seed)
        self.base_cfg = _intercept_cfg(self.fid)
        self.weights = weights or RedWeights()
        self.cons = cons or RedConstraints()
        if mode in C5_EXEMPT_MODES and self.cons.helipad_out_of_radar:
            # 与 red_evaluate 保持一致：F3/F4 豁免 C5（见 C5_EXEMPT_MODES），
            # 使 self.cons 直接反映本课题真正生效的约束集合（供报告 / 界面展示）。
            self.cons = replace(self.cons, helipad_out_of_radar=False)
        self.sector_gain = bool(sector_gain)
        self.blue_x = (np.asarray(blue_x, dtype=float) if blue_x is not None
                       else straight_blue_x(self.base_cfg))
        self.dim = plan_dim(mode, self.base_cfg)
        self.lb = LB
        self.ub = UB
        self.f_opt = None
        self.x_opt = None
        self.category = 'application'
        self.suite = f'uav_red_{mode}'
        self.name = name or f'{MODE_NAMES.get(mode, mode)} @ U{self.fid}'
        self.nevals = 0
        self.last: Optional[Dict] = None

    @property
    def label(self) -> str:
        return f'R{self.fid}-{self.mode}'

    def decode(self, x: Sequence[float]) -> RedPlan:
        return decode_plan(x, self.mode, self.base_cfg)

    def evaluate(self, x: Sequence[float]) -> Dict:
        self.nevals += 1
        self.last = red_evaluate(x, self.mode, self.base_cfg,
                                 blue_x=self.blue_x, seed=self.seed,
                                 weights=self.weights, cons=self.cons,
                                 sector_gain=self.sector_gain)
        return self.last

    def __call__(self, x: Sequence[float]) -> float:
        return float(self.evaluate(x)['cost'])

    def __repr__(self) -> str:
        return (f'<Red {self.name} mode={self.mode} D={self.dim} '
                f'U{self.fid} seed={self.seed}>')


# ===========================================================================
# 元数据：约束清单与课题说明
# ===========================================================================
# 这里是「约束与课题」文案的**单一事实来源**：Web 的课题说明弹窗、脚本报告与设计
# 文档都从这里取，避免出现「界面写的」与「代码做的」两套说法。
#
# 每条约束 = (编号, 名称, 代码内判罚名, 一句话文案, 生效课题)。
# 「生效课题」= 该课题下 :meth:`RedConstraints.check` 会真正判罚它的课题集合。
# C5 刻意不含 intercept/coordinate（原因见 :data:`C5_EXEMPT_MODES`）—— 界面上那句
# 「本课题已豁免」就是由这条数据生成的，不再另写一份文案。
CONSTRAINT_DOC: Tuple[Tuple[str, str, str, str, Tuple[str, ...]], ...] = (
    ('C1', '禁飞区', 'no_fly',
     '任一单元坐标与拦截航路航点均不得落入圆形禁飞区。',
     ('deploy', 'ew', 'intercept', 'coordinate')),
    ('C2', '雷达不远离基地', 'radar_base',
     '雷达站到基地距离 ≤ 620 m，不允许把预警设施藏到地图角落。',
     ('deploy', 'ew')),
    ('C3', '单元最小间距', 'min_sep',
     '任意两个单元间距 ≥ 70 m，排除「全部堆在一格」的退化解。',
     ('deploy', 'ew', 'intercept', 'coordinate')),
    ('C4', '防空车拱卫基地', 'aa_cover',
     '每辆防空车到基地的距离 ≤ 其射程，否则失去拱卫基地的意义。',
     ('deploy',)),
    ('C5', '停机坪在雷达外', 'helipad_in_radar',
     '停机坪须落在雷达探测范围之外，保持「停靠待命、被雷达捕获才出动」的语义。',
     ('deploy', 'ew')),
    ('C6', '拦截航路避禁飞区', 'route_nofly',
     '拦截航路航点不得落入禁飞区，否则等于让拦截机穿禁区飞行。',
     ('intercept', 'coordinate')),
)

# 槽位中文名（界面与报告共用）
SLOT_NAMES: Dict[str, str] = {
    'radar_xy': '雷达站坐标',
    'helipads': '停机坪坐标',
    'aa_pos': '防空车坐标',
    'patrol_anchors': '巡逻分区中心',
    'radar_range': '雷达探测距离',
    'radar_azimuth': '主瓣方位角',
    'radar_half_angle': '主瓣半张角',
    'scan_period': '扫描周期',
    'alert_threshold': '告警阈值',
    'int_routes': '拦截航路航点',
    'assign': '主责目标分配',
    'sector_bounds': '责任区边界',
    'launch_threshold': '逐机出动阈值',
}

# 槽位「实体描述」：这个决策变量在战场上代表什么（界面节点信息里的「描述」取这里）。
# 维度 D / 取值区间 / 部署区域属于「参数」，由 describe_topic 另行给出，二者分开展示。
SLOT_DOC: Dict[str, str] = {
    'radar_xy': '预警雷达站的部署位置：全图唯一的远程传感器，决定哪片空域能被提前'
                '发现；它不参与静态火力覆盖，避免「顶满半径刷缺口罚分」。',
    'helipads': '拦截机的出动基地位置：决定拦截机能否在蓝方打完之前到位，是拦截效果的'
                '主导杠杆；F3/F4 里它与航路一起决策。',
    'aa_pos': '防空车的部署位置：近距火力单元，须能在射程内拱卫基地，并贡献静态覆盖。',
    'patrol_anchors': '巡逻分队的区域中心：巡逻兵在各中心附近确定性散开，提供区域静态'
                      '覆盖。',
    'radar_range': '雷达的最大有效探测半径：越大覆盖越广，但受主瓣张角与地形遮挡牵制。',
    'radar_azimuth': '雷达主瓣的朝向：决定预警扇区指向哪片空域。',
    'radar_half_angle': '主瓣半张角：扇区收窄则能量集中、看得更远，但覆盖方向更受限。',
    'scan_period': '雷达扫完一圈的周期：周期越短，越早发现目标。',
    'alert_threshold': '触发告警所需的目标数：阈值越低越早进入戒备，也越容易被虚警牵动。',
    'int_routes': '拦截机的巡逻航路点：规定它在哪儿待机、沿什么路径搜敌。',
    'assign': '各火力单元主责拦击的蓝方目标编号：决定谁打谁，避免重复打同一目标。',
    'sector_bounds': '各火力单元的责任区边界：把战场切成互不重叠的拦截扇区。',
    'launch_threshold': '每架拦截机各自的出动阈值：控制它何时从停靠待命转入拦截。',
}

# 判罚名 -> 约束编号，供结果里的 violations 回填编号后展示
VIOLATION_CODES: Dict[str, str] = {c[2]: c[0] for c in CONSTRAINT_DOC}


def constraints_for(mode: str) -> List[Dict[str, object]]:
    """某课题的约束清单（含「本课题是否生效」与豁免说明）。"""
    out: List[Dict[str, object]] = []
    for cid, name, code, text, modes in CONSTRAINT_DOC:
        active = mode in modes
        note = ''
        if code == 'helipad_in_radar' and not active:
            note = ('F3/F4 已豁免：这两个课题不把雷达探测距离当决策变量（固定 520 m），'
                    '若仍要求停机坪落在雷达外，起飞基地只剩东南角窄条，优化器在有限'
                    '预算内找不到可行解；而「从哪儿起飞」正是拦截效果的主导杠杆。'
                    '豁免后停机坪的部署区域放开到全图。')
        out.append({'id': cid, 'name': name, 'code': code, 'text': text,
                    'active': bool(active), 'note': note})
    return out


def fid_summary(cfg: EnvConfig) -> Dict[str, int]:
    """编成摘要（界面与报告共用）：各单元数量、航点数与仿真步数。"""
    return {
        'n_drones': int(cfg.n_drones),
        'n_infantry': int(cfg.n_infantry),
        'n_interceptors': int(cfg.n_interceptors),
        'n_aa': int(cfg.n_aa),
        'n_patrol': int(cfg.n_patrol),
        'n_waypoints': int(cfg.n_waypoints),
        'n_int_waypoints': int(cfg.n_int_waypoints),
        'n_steps': int(cfg.n_steps),
        'n_units': int(_n_units(cfg)),
    }


# 蓝方对手口径（界面下拉与说明共用；runner 按 key 分派）
OPPONENT_DOC: Tuple[Tuple[str, str, str], ...] = (
    ('straight', '直扑基地',
     '无优化的朴素突防：每架无人机 / 步兵沿「起点→基地」直线等分取航点。秒级返回，'
     '适合快速试跑；但仿真中蓝方常被全歼，红方增益主要来自部署代理项，不宜作为最终结论。'),
    ('best', '强突防（best-of-N）',
     '先用 DE 独立求 N 次蓝方突防最优、取最好解当对手。这才是真实杠杆所在（出厂配置下'
     '蓝方 1 架突防成功、红方 2 架直升机被击落），代价是每次点击要等数分钟。'),
)


def describe_topic(mode: str, fid: int = 1) -> Dict[str, object]:
    """红方课题的结构化说明（Web「课题说明」弹窗与脚本报告共用这一份数据）。"""
    if mode not in MODE_SLOTS:
        raise ValueError(f'未知红方课题：{mode}（可选 {tuple(MODE_SLOTS)}）')
    cfg = _intercept_cfg(int(fid))
    slots: List[Dict[str, object]] = []
    for s in MODE_SLOTS[mode]:
        item: Dict[str, object] = {'key': s, 'label': SLOT_NAMES.get(s, s),
                                   'dim': int(_slot_dim(s, cfg))}
        if s in SLOT_ROI:
            (xlo, xhi), (ylo, yhi) = _roi(s, mode)
            item['roi'] = [[float(xlo), float(xhi)], [float(ylo), float(yhi)]]
        elif s in ('alert_threshold', 'launch_threshold'):
            item['range'] = [1.0, float(max(1, int(cfg.n_drones)))]
            item['unit'] = '个目标'
        elif s in SCALAR_RANGE:
            item['range'] = [float(SCALAR_RANGE[s][0]), float(SCALAR_RANGE[s][1])]
        slots.append(item)

    w = RedWeights()
    objective = [
        {'term': '突破罚', 'sign': '+',
         'text': f'蓝方突防成功架次 × w_arrive（{cfg.w_arrive:.0f}/架，主导项）'},
        {'term': '击落奖', 'sign': '−',
         'text': f'被击落蓝方单位 × w_lost（{cfg.w_lost:.0f}/架，主导项）'},
        {'term': '及早交战奖', 'sign': '−',
         'text': f'首次交战越早越好，权重 {w.early:.0f}；全程未交战记 0'},
        {'term': '暴露压制奖', 'sign': '−',
         'text': f'蓝方暴露在火力下的时长占比，权重 {w.risk:.0f}'},
        {'term': '覆盖缺口罚', 'sign': '+',
         'text': f'突防通道与基地环未被防空车 / 巡逻兵覆盖的比例，权重 {w.gap:.0f}'
                 '（雷达与拦截机不计入静态覆盖）'},
        {'term': '后勤散布罚', 'sign': '+',
         'text': f'各单元到基地的平均距离（归一化），权重 {w.deploy:.0f}'},
    ]
    notes = [
        '约束以分级罚分实现（罚分系数 800），因此优化器可能先给出违约束的低 cost 解；'
        '界面上的「可行性」按违约条目数判定。',
        '决策维度随 fid 的编成变化，同一课题在不同 fid 下的 D 不同（详见维度表）。',
        '红方优化本质是 min–max：本页面固定一个蓝方对手再优化红方；要抗不同蓝方部署，'
        '需在外层对蓝方解做域随机化。',
    ]
    if mode in C5_EXEMPT_MODES:
        notes.insert(0, '本课题豁免 C5（停机坪可在雷达探测范围内），且停机坪 ROI 为全图 —— '
                        '因为「从哪儿起飞」是拦截效果的主导杠杆。')
    return {
        'mode': mode,
        'name': MODE_NAMES.get(mode, mode),
        'fid': int(fid),
        'dim': int(plan_dim(mode, cfg)),
        'slots': slots,
        'constraints': constraints_for(mode),
        'c5_exempt': bool(mode in C5_EXEMPT_MODES),
        'objective': objective,
        'opponents': [{'key': k, 'label': lb, 'text': tx}
                      for k, lb, tx in OPPONENT_DOC],
        'formation': fid_summary(cfg),
        'notes': notes,
    }


def topic_table() -> List[Dict[str, object]]:
    """四个课题的总览表（界面下拉与文档表格共用）：名称 / 各 fid 的 D / 豁免项。"""
    out: List[Dict[str, object]] = []
    for mode in MODE_SLOTS:
        dims = {str(f): int(plan_dim(mode, _intercept_cfg(int(f)))) for f in (1, 3, 4)}
        out.append({
            'mode': mode,
            'name': MODE_NAMES.get(mode, mode),
            'dims': dims,
            'c5_exempt': bool(mode in C5_EXEMPT_MODES),
            'n_slots': len(MODE_SLOTS[mode]),
        })
    return out




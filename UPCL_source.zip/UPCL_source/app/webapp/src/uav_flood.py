# -*- coding: utf-8 -*-
"""
山区洪涝灾害下无人机运输与通信协同优化 —— 真实场景仿真引擎
============================================================

真实场景 : 2026 研赛 D 题 —— 广西横州市镇龙乡，台风"美莎克"洪涝
真实地形 : Copernicus GLO-30 数字高程模型（30 m，EPSG:4326，41.7~1132.9 m）
真实节点 : O01 凤丹村无人机调度中心 + 15 个服务区 S001–S015
官方规则 : 附录2（航段三阶段 / 等效航程 / 能耗 / 返航余量 / 两阶段充电）
          附录3（自由空间损耗 / 链路预算 / 地形遮挡 / 双向判定 / 中继两跳）

两种决策编码（供 DE 连续优化器消费）：
  1. 'waypoints'   —— 连续航点：单架次地形·能耗·通信演示（问题 1/3 局部）
  2. 'permutation' —— 随机键排列：多机·多服务区·货箱组批调度（问题 2/3）

物理推导（依据附录2 + 参考文献[5] 无人机能耗模型）：
  * 等效航程 L(q)=L0-(L0-LF)(q/Q)^1.5  =>  单位水平距离能耗 e(q)=Eg_use/L(q)
  * 水平巡航能耗 E_hor = Eg_use·d / L(q)
  * 爬升附加能耗 E_up  = (m_empty+q)·g·h⁺ / η_up   （η_up=0.72，下降效率取 0）
  * 返航安全余量 E_p ≤ (1-ρ)·Eg_use                （ρ=20%）
  * 两阶段充电  t=T·[0.65(0.9-s)/0.9+0.35] (s<0.9)；t=T·[0.35(1-s)/0.1] (s≥0.9)
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

# ======================================================================
# 常量与官方规则参数
# ======================================================================

G_ACC = 9.80665
R_EARTH = 6378137.0
DEG = math.pi / 180.0

H_CRUISE_CLEARANCE = 50.0   # 巡航海拔 = 沿线 DEM 最高像元 + 50 m
H_SERVICE_CLEARANCE = 30.0  # 服务区作业高度 = 地面海拔 + 30 m
RHO_RETURN = 0.20           # 返航电量下限 20%
ETA_CLIMB = 0.72            # 爬升能耗效率
H_RELAY_MAX_AGL = 300.0     # 中继最大悬停离地高度

# 附录3 通信参数
COMM = dict(
    f_mhz=2400.0, lsys=3.0, lobs=10.0, psens=-98.0, margin=8.0,
    transport=dict(pt=20.0, g=3.0),
    relay_access=dict(pt=20.0, g=6.0),
    relay_backhaul=dict(pt=19.0, g=8.0),
    gateway=dict(pt=27.0, g=12.0, h_agl=20.0),
)

# D 题官方数据目录：优先环境变量 UAV_FLOOD_DATA，其次按脚本位置相对查找，
# 不再硬编码盘符，换机器 / 换目录（含中文、空格路径）后都能自动定位。
_APP_ROOT = Path(__file__).resolve().parents[1]    # app/webapp（src/ 直接位于仓库根时为仓库根）
try:
    _REPO_ROOT = Path(__file__).resolve().parents[3]   # 仓库根（内含 D题/）
except IndexError:                                  # 树更浅时退化为 _APP_ROOT，避免 import 崩溃
    _REPO_ROOT = _APP_ROOT
_DATA_CANDIDATES = [
    _APP_ROOT / 'D题' / '数据',                     # 数据随 webapp 一起分发时
    _APP_ROOT.parent / 'D题' / '数据',              # 数据放在 app/ 下时
    _REPO_ROOT / 'D题' / '数据',                    # 常规：<仓库根>/D题/数据
]


# ======================================================================
# 硬编码官方数据（固定数据，避免运行时依赖 openpyxl）
# ======================================================================

BASE_NODE = ('O01', '凤丹村无人机调度中心', 109.2308517, 23.0085095, 127.7)

# (编号, 名称, 经度, 纬度, 海拔 m, 保障人口)
SERVICES = [
    ('S001', '平旺·那龙·镇龙乡', 109.2432319, 23.0335927, 154.0, 2100),
    ('S002', '上良', 109.2585519, 23.0703271, 189.5, 330),
    ('S003', '六造·那旭·都长', 109.1688578, 23.0402714, 308.5, 275),
    ('S004', '大站', 109.2381714, 23.0778414, 198.3, 188),
    ('S005', '上良·古律·那麓', 109.2283003, 23.0561338, 165.0, 126),
    ('S006', '六昌·木路', 109.1997836, 23.007714, 284.8, 121),
    ('S007', '佛子·那桑·银坑', 109.1928191, 23.0294186, 318.5, 76),
    ('S008', '古麻·大站', 109.2127472, 23.0795113, 240.9, 55),
    ('S009', '那龙', 109.2541424, 23.0552989, 200.0, 45),
    ('S010', '镇龙乡', 109.2760168, 23.0194009, 321.6, 31),
    ('S011', '那从', 109.2203356, 23.0319231, 182.1, 30),
    ('S012', '镇龙乡', 109.2831357, 23.0544640, 249.8, 16),
    ('S013', '镇龙乡', 109.2713839, 23.0310882, 321.7, 14),
    ('S014', '镇龙乡', 109.2835966, 23.0052097, 321.0, 12),
    ('S015', '六造·那托·那旭', 109.1923786, 23.0494548, 444.5, 3),
]

# 物资类型: (质量 kg, 体积 m³)
CARGO_TYPES = {'MED': (3.0, 0.012), 'WAT': (14.0, 0.027),
               'FOD': (8.0, 0.028), 'HYG': (6.0, 0.035)}

# 每服务区需求: {svc: {'med':n, 'wat':n, 'fod':n, 'hyg':n,
#                      'prio':(med,wat,fod,hyg), 'deadline':(med,wat,fod,hyg)}}
# 首批 = MED 第 1 箱 + WAT 第 1 箱；deadline 为首批箱截止/非首批箱期望送达（s）
DEMAND = {
    'S001': dict(med=2, wat=8, fod=3, hyg=2, prio=(24, 12, 10, 8), dl=(3600, 3600, 7200, 10800)),
    'S002': dict(med=1, wat=4, fod=2, hyg=1, prio=(24, 12, 10, 8), dl=(3600, 3600, 7200, 10800)),
    'S003': dict(med=1, wat=4, fod=2, hyg=1, prio=(20, 10, 8, 6), dl=(7200, 7200, 10800, 14400)),
    'S004': dict(med=1, wat=3, fod=1, hyg=1, prio=(20, 10, 8, 6), dl=(7200, 7200, 10800, 14400)),
    'S005': dict(med=1, wat=3, fod=1, hyg=1, prio=(16, 8, 6, 4), dl=(10800, 10800, 14400, 18000)),
    'S006': dict(med=1, wat=3, fod=1, hyg=1, prio=(24, 12, 10, 8), dl=(3600, 3600, 7200, 10800)),
    'S007': dict(med=1, wat=2, fod=1, hyg=1, prio=(24, 12, 10, 8), dl=(3600, 3600, 7200, 10800)),
    'S008': dict(med=1, wat=2, fod=1, hyg=1, prio=(20, 10, 8, 6), dl=(7200, 7200, 10800, 14400)),
    'S009': dict(med=1, wat=1, fod=1, hyg=0, prio=(16, 8, 6, 0), dl=(10800, 10800, 14400, 0)),
    'S010': dict(med=1, wat=1, fod=1, hyg=0, prio=(24, 12, 10, 0), dl=(3600, 3600, 7200, 0)),
    'S011': dict(med=1, wat=1, fod=1, hyg=0, prio=(16, 8, 6, 0), dl=(10800, 10800, 14400, 0)),
    'S012': dict(med=1, wat=1, fod=1, hyg=0, prio=(22, 12, 10, 0), dl=(3600, 3600, 7200, 0)),
    'S013': dict(med=1, wat=1, fod=1, hyg=0, prio=(24, 12, 10, 0), dl=(3600, 3600, 7200, 0)),
    'S014': dict(med=1, wat=1, fod=1, hyg=0, prio=(22, 12, 10, 0), dl=(3600, 3600, 7200, 0)),
    'S015': dict(med=1, wat=1, fod=1, hyg=0, prio=(18, 8, 6, 0), dl=(7200, 10800, 14400, 0)),
}

# 三类机型: {机型: dict}
DRONE_MODELS = {
    'A': dict(name='中轻载', m_empty=70.0, Q=25.0, V=0.06, v_cruise=12.0,
              L0=25000.0, LF=20000.0, E_use=4.5, v_up=3.0, v_down=2.5,
              t_prep=300.0, t_load=30.0, t_hand=150.0, t_hand_box=30.0),
    'B': dict(name='中载', m_empty=65.0, Q=30.0, V=0.073, v_cruise=15.0,
              L0=28000.0, LF=16000.0, E_use=4.0, v_up=3.0, v_down=2.5,
              t_prep=300.0, t_load=30.0, t_hand=150.0, t_hand_box=30.0),
    'C': dict(name='重载', m_empty=69.9, Q=80.0, V=0.25, v_cruise=15.0,
              L0=26000.0, LF=12000.0, E_use=8.0, v_up=2.5, v_down=2.0,
              t_prep=300.0, t_load=30.0, t_hand=180.0, t_hand_box=36.0),
}

# 8 架实体机
DRONE_UNITS = [('U01', 'A'), ('U02', 'A'), ('U03', 'A'), ('U04', 'A'),
               ('U05', 'B'), ('U06', 'B'), ('U07', 'C'), ('U08', 'C')]

# 共享电池: {机型: (组数, 等效完全充电时间 s)}
BATTERIES = {'A': (6, 1800.0), 'B': (4, 2400.0), 'C': (4, 3000.0)}

# 中继无人机 R
RELAY_MODEL = dict(m_empty=21.0, m_comm=2.5, m_takeoff=23.5, v_cruise=15.0,
                   p_cruise=1.15, E_use=3.2, v_up=4.0, v_down=3.0,
                   t_prep=180.0, t_link=30.0, t_turn=300.0,
                   p_hover=1.05, p_comm=0.05, h_agl_max=300.0)
RELAY_UNITS = ['R01', 'R02']
RELAY_BATTERIES = (6, 1800.0)


# ======================================================================
# 坐标投影与 DEM 加载
# ======================================================================

def _find_data_root():
    env = os.environ.get('UAV_FLOOD_DATA')
    if env and os.path.isdir(env):
        return env
    for c in _DATA_CANDIDATES:
        if os.path.isdir(c):
            return c
    return None


def lonlat_to_xy(lon, lat, lon0, lat0):
    """等距圆柱投影：经纬度 -> 局部平面米坐标（40 km 范围形变 < 0.1%）。"""
    kx = R_EARTH * math.cos(lat0 * DEG)
    x = (lon - lon0) * DEG * kx
    y = (lat - lat0) * DEG * R_EARTH
    return float(x), float(y)


_LON0 = BASE_NODE[2]
_LAT0 = BASE_NODE[3]
_dem_cache = None


def _load_real_dem():
    """加载镇龙乡 30m DEM，返回 (xs 递增 m, ys 递增 m, Z)。"""
    global _dem_cache
    if _dem_cache is not None:
        return _dem_cache
    root = _find_data_root()
    if root is None:
        raise FileNotFoundError('D题数据目录未找到')
    import scipy.io as sio
    import glob
    pat = os.path.join(root, '镇龙乡地理空间数据', '镇龙乡及周边地理数据',
                       '数字高程模型数据（DEM）', '*.mat')
    mat_path = glob.glob(pat)[0]
    m = sio.loadmat(mat_path)
    lat = np.asarray(m['latitude']).ravel()   # 北 -> 南
    lon = np.asarray(m['longitude']).ravel()  # 西 -> 东
    dem = np.asarray(m['dem'], dtype=np.float64)
    nodata = float(np.asarray(m['nodata']).ravel()[0])
    dem[dem == nodata] = np.nan
    xs = (lon - _LON0) * DEG * R_EARTH * math.cos(_LAT0 * DEG)
    ys_lat = (lat - _LAT0) * DEG * R_EARTH  # 北 -> 南（递减）
    ys = ys_lat[::-1]                        # 南 -> 北（递增）
    Z = dem[::-1, :]                         # Z[j, i] 对应 ys[j], xs[i]
    _dem_cache = (xs, ys, Z)
    return _dem_cache


def _make_boxes_for(services, demand):
    """按需求汇总生成货箱（箱号·服务区·类型·质量·体积·首批·期限·优先）。"""
    boxes = []
    for sid, *_rest in services:
        d = demand[sid]
        for typ, idx in (('MED', 'med'), ('WAT', 'wat'), ('FOD', 'fod'), ('HYG', 'hyg')):
            n = d[idx]
            if n <= 0:
                continue
            mass, vol = CARGO_TYPES[typ]
            prio = d['prio'][{'med': 0, 'wat': 1, 'fod': 2, 'hyg': 3}[idx]]
            dl = d['dl'][{'med': 0, 'wat': 1, 'fod': 2, 'hyg': 3}[idx]]
            for k in range(n):
                first = (typ in ('MED', 'WAT')) and (k == 0)
                boxes.append(dict(
                    sid=sid, typ=typ, mass=mass, vol=vol,
                    first=first, deadline=(dl if first else dl),
                    expect=dl, prio=prio, name=f'{sid}-{typ}-{k + 1:02d}'))
    return boxes


def _make_boxes():
    return _make_boxes_for(SERVICES, DEMAND)


# ======================================================================
# flood_v2 —— 扩展复杂灾区（长条形山地 + 更分散救援点）
# ======================================================================

# 24 个分散救援点的地名（虚构山区地名，仅用于扩展演示）
_V2_NAMES = ['青石垭', '双河口', '大石坡', '老鹰岩', '麻柳沟', '半坡寨', '杉木坪',
             '回龙湾', '牛头山', '白岩脚', '核桃坝', '李子坳', '枇杷村', '柏杨坪',
             '苦竹溪', '磨盘山', '响水洞', '燕子岩', '月亮坝', '黄土坎', '枫香湾',
             '马鞍山', '雷打石', '观音桥']


def _make_services_v2():
    """长条形灾区：沿 x 主轴约 68 km、y 轴约 32 km 分散 24 个救援点。

    坐标直接为投影后的局部平面米坐标（非经纬度），基地在长轴西端 (-36000, 0)。
    """
    rng = np.random.default_rng(20261007)
    svcs = []
    for i in range(24):
        x = -32000.0 + i * (68000.0 / 23) + rng.uniform(-900, 900)
        y = rng.uniform(-16000, 16000)
        elev = (120.0 + 180.0 * (0.5 + 0.5 * math.sin(0.35 * i + 0.6))
                + rng.uniform(0, 160))
        pop = int(rng.choice([3, 12, 16, 30, 45, 55, 76, 121, 126, 188, 275, 330]))
        svcs.append((f'V{i + 1:03d}', _V2_NAMES[i], float(x), float(y), float(elev), pop))
    return svcs


def _make_demand_v2():
    """v2 各救援点需求（小规模，与 v1 单点规模相近，货箱可组批）。"""
    return {f'V{i + 1:03d}': dict(med=1, wat=3, fod=2, hyg=1,
                                   prio=(20, 10, 8, 6),
                                   dl=(7200, 7200, 10800, 14400))
            for i in range(24)}


SERVICES_V2 = _make_services_v2()
DEMAND_V2 = _make_demand_v2()


# ======================================================================
# Terrain（真实 DEM 双线性插值）
# ======================================================================

class Terrain:
    def __init__(self, xs, ys, Z):
        self.xs = np.asarray(xs, dtype=np.float64)
        self.ys = np.asarray(ys, dtype=np.float64)
        self.Z = np.asarray(Z, dtype=np.float64)
        self.x0, self.x1 = float(self.xs[0]), float(self.xs[-1])
        self.y0, self.y1 = float(self.ys[0]), float(self.ys[-1])
        self.dx = float(self.xs[1] - self.xs[0])
        self.dy = float(self.ys[1] - self.ys[0])
        z = self.Z[~np.isnan(self.Z)]
        self.z_min = float(z.min())
        self.z_max = float(z.max())

    def height(self, x, y):
        x = float(x); y = float(y)
        if x < self.x0 or x > self.x1 or y < self.y0 or y > self.y1:
            return self.z_min
        i = int((x - self.x0) / self.dx)
        j = int((y - self.y0) / self.dy)
        i = max(0, min(i, len(self.xs) - 2))
        j = max(0, min(j, len(self.ys) - 2))
        fx = (x - self.xs[i]) / self.dx
        fy = (y - self.ys[j]) / self.dy
        z = (self.Z[j, i] * (1 - fx) * (1 - fy) + self.Z[j, i + 1] * fx * (1 - fy)
             + self.Z[j + 1, i] * (1 - fx) * fy + self.Z[j + 1, i + 1] * fx * fy)
        if np.isnan(z):
            z = self.z_min
        return float(z)

    def grid(self):
        return self.xs, self.ys, self.Z

    def bounds(self):
        return self.x0, self.x1, self.y0, self.y1


# ======================================================================
# 附录2 官方物理引擎
# ======================================================================

def equivalent_range(L0, LF, Q, q):
    """等效航程 L(q) = L0 - (L0-LF)·(q/Q)^1.5（附录2）。"""
    q = max(0.0, min(float(q), Q))
    return L0 - (L0 - LF) * (q / Q) ** 1.5


def _segment_max_elev(terrain, x0, y0, x1, y1, step=30.0):
    d = math.hypot(x1 - x0, y1 - y0)
    n = max(2, int(d / step))
    zmax = -1e18
    for k in range(n + 1):
        t = k / n
        zmax = max(zmax, terrain.height(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    return zmax


def transport_segment(terrain, model, q, p0, p1):
    """航段三阶段（爬升→巡航→下降）能耗与时间（附录2）。

    p0/p1 = (x, y, z)，z 为作业高度（绝对海拔）。巡航海拔 = 沿线 DEM 最高 + 50 m。
    """
    x0, y0, z0 = p0
    x1, y1, z1 = p1
    d = math.hypot(x1 - x0, y1 - y0)
    if d < 1e-6:
        return dict(d=0.0, cruise_z=z0, h_plus=0.0, h_minus=0.0, t=0.0,
                    e_hor=0.0, e_up=0.0, e=0.0)
    zmax = _segment_max_elev(terrain, x0, y0, x1, y1)
    cruise_z = zmax + H_CRUISE_CLEARANCE
    h_plus = max(0.0, cruise_z - z0)
    h_minus = max(0.0, cruise_z - z1)
    t = h_plus / model['v_up'] + d / model['v_cruise'] + h_minus / model['v_down']
    Lq = equivalent_range(model['L0'], model['LF'], model['Q'], q)
    e_hor = model['E_use'] * d / Lq                       # kWh
    e_up = (model['m_empty'] + q) * G_ACC * h_plus / ETA_CLIMB / 3.6e6  # kWh
    return dict(d=d, cruise_z=cruise_z, h_plus=h_plus, h_minus=h_minus,
                t=t, e_hor=e_hor, e_up=e_up, e=e_hor + e_up)


def transport_path_energy(terrain, model, q_out, nodes_out, q_back, nodes_back):
    """往返路径总能耗/时间：去程载货 q_out，返程空载（沿 nodes_back）。"""
    E = t = 0.0
    for seg in [(nodes_out, q_out), (nodes_back, q_back)]:
        ns, qq = seg
        for a, b in zip(ns[:-1], ns[1:]):
            r = transport_segment(terrain, model, qq, a, b)
            E += r['e']; t += r['t']
    return E, t


def charge_time_seconds(soc_start, T_full):
    """两阶段充电时间（附录2）。"""
    s = max(0.0, min(float(soc_start), 1.0))
    if s < 0.9:
        return T_full * (0.65 * (0.9 - s) / 0.9 + 0.35)
    return T_full * (0.35 * (1.0 - s) / 0.1)


def relay_energy(terrain, base_xy, base_z, hover_pt, t_hover):
    """中继架次能耗：爬升 + 水平巡航(往返) + 悬停服务（下降效率取 0）。"""
    hx, hy, hz = hover_pt
    d = math.hypot(hx - base_xy[0], hy - base_xy[1])
    m = RELAY_MODEL
    h_plus = max(0.0, hz - base_z)
    e_climb = m['m_takeoff'] * G_ACC * h_plus / ETA_CLIMB / 3.6e6
    e_cruise = m['p_cruise'] * (2.0 * d / m['v_cruise']) / 3600.0
    e_hover = (m['p_hover'] + m['p_comm']) * t_hover / 3600.0
    return e_climb + e_cruise + e_hover


# ======================================================================
# 附录3 官方通信引擎
# ======================================================================

def fspl_db(f_mhz, d_km):
    """自由空间损耗（附录3）：32.45 + 20lg f + 20lg D。"""
    return 32.45 + 20.0 * math.log10(f_mhz) + 20.0 * math.log10(max(d_km, 1e-6))


def _pth():
    return COMM['psens'] + COMM['margin']  # -90 dBm


def _link_max(tx_pt, tx_g, rx_g):
    """单向最大允许损耗：Pt+Gt+Gr-Lsys-Pth。"""
    return tx_pt + tx_g + rx_g - COMM['lsys'] - _pth()


def _link_max_bidi(tx_key, rx_key):
    """双向链路预算（附录3 双向判定，取较小者）。"""
    t = COMM[tx_key]; r = COMM[rx_key]
    return min(_link_max(t['pt'], t['g'], r['g']), _link_max(r['pt'], r['g'], t['g']))


def terrain_blocked(terrain, p0, p1, n=64):
    """地形遮挡判断：三维视线任一点被地面高程截断则遮挡（附录3 b_ij）。"""
    x0, y0, z0 = p0
    x1, y1, z1 = p1
    for k in range(1, n):
        t = k / n
        xi = x0 + (x1 - x0) * t
        yi = y0 + (y1 - y0) * t
        zi = z0 + (z1 - z0) * t
        if terrain.height(xi, yi) > zi:
            return True
    return False


def link_available(terrain, tx_key, rx_key, p0, p1):
    """链路可用：FSPL + Lobs·b_ij ≤ Lmax(a↔b)。"""
    blocked = terrain_blocked(terrain, p0, p1)
    d_km = math.dist(p0, p1) / 1000.0
    loss = fspl_db(COMM['f_mhz'], d_km) + COMM['lobs'] * (1 if blocked else 0)
    return loss <= _link_max_bidi(tx_key, rx_key)


# ======================================================================
# FloodConfig
# ======================================================================

@dataclass
class FloodConfig:
    # —— 编码模式 ——
    encoding: str = 'permutation'    # 'permutation' | 'waypoints'
    n_service: int = 15             # permutation 编码参与调度的服务区数
    target_service: str = 'S006'    # waypoints 编码的目标服务区

    # —— 场景与几何（保持旧字段兼容 GUI/web）——
    map_size: float = 42000.0
    grid_n: int = 128
    base_pos: tuple = (0.0, 0.0, 0.0)
    disaster_pos: list = field(default_factory=list)

    n_cargo: int = 1
    n_relay: int = 0
    n_waypoints: int = 3

    # —— 官方规则参数（冗余字段，兼容旧 describe）——
    m_body: float = 70.0
    m_payload: float = 25.0
    rotor_area: float = 0.6
    cd_area: float = 0.2
    speed: float = 12.0
    gamma_max: float = 25.0
    h_safe: float = 50.0
    h_comm: float = 300.0
    e_battery: float = 4.5
    arrive_radius: float = 60.0

    # —— 目标权重 ——
    w_energy: float = 1.0
    w_time: float = 0.05
    w_comm: float = 0.3
    w_tardy: float = 0.05
    w_safety: float = 100.0

    # —— 旧场景评分权重（冗余字段，仅兼容 uav_adversarial.describe_scenario）——
    w_arrive: float = 100.0
    w_terrain: float = 50.0
    w_slope: float = 10.0
    w_bounds: float = 50.0
    w_battery: float = 200.0

    seed: int = 0

    # 场景变体：'v1' = 镇龙乡真实 DEM 场景（默认），'v2' = 扩展复杂灾区
    variant: str = 'v1'

    @property
    def dim(self):
        if self.encoding == 'waypoints':
            # 航点编码为「单架次演示」：只含 n_waypoints 个二维航点 + 中继坐标，
            # 与 n_cargo 无关（n_cargo 仅用于排列编码的架次数），避免产生幽灵维度。
            return self.n_waypoints * 2 + self.n_relay * 3
        return self.n_service * 2 + self.n_relay * 3

    @property
    def n_drones(self):
        return self.n_cargo

    @property
    def gamma_max_rad(self):
        return self.gamma_max * DEG

    def describe(self):
        if self.encoding == 'waypoints':
            mode = '连续航点编码（单架次地形·能耗·通信演示）'
        else:
            mode = '随机键排列编码（多机·多服务区·货箱组批调度）'
        if self.encoding == 'waypoints':
            transport = f'{self.n_cargo} 架次槽位 · 机型 A/B/C（载 25/30/80 kg）'
        else:
            transport = '8 架实体机（A×4 / B×2 / C×2，共享电池组）'
        if getattr(self, 'variant', 'v1') == 'v2':
            return {
                '场景': '扩展复杂灾区（flood_v2）· 长条形山地',
                '地形': '合成长条形山脉 DEM（约 80×40 km，中央河谷 + 两侧山脊 + 多处峰）',
                '节点': f'O01 救灾基地（长轴西端） + {self.n_service} 个分散救援点 V001–V024',
                '编码': mode,
                '决策维数': self.dim,
                '运输机': transport,
                '中继': f'{self.n_relay} 架中继 R（悬停功率 1.05 kW，能源 3.2 kWh）',
                '规则': '附录2 三阶段航段 / 等效航程 / 返航余量 20%；附录3 链路预算 / 遮挡 / 双向判定',
            }
        return {
            '场景': '2026 研赛 D 题 · 广西横州市镇龙乡台风"美莎克"洪涝',
            '地形': 'Copernicus GLO-30 DEM（30 m 分辨率，约 42×40 km）',
            '节点': f'O01 凤丹村调度中心 + {len(SERVICES)} 个服务区 S001–S015',
            '编码': mode,
            '决策维数': self.dim,
            '运输机': transport,
            '中继': f'{self.n_relay} 架中继 R（悬停功率 1.05 kW，能源 3.2 kWh）',
            '规则': '附录2 三阶段航段 / 等效航程 / 返航余量 20%；附录3 链路预算 / 遮挡 / 双向判定',
        }


# ======================================================================
# FloodEnv（两种编码的统一求值）
# ======================================================================

def _type_to_model(t):
    u = (float(t) + 1.0) / 2.0
    return 'A' if u < 0.333 else ('B' if u < 0.667 else 'C')


def _min_model(mass, vol):
    for k in ('A', 'B', 'C'):
        if mass <= DRONE_MODELS[k]['Q'] + 1e-9 and vol <= DRONE_MODELS[k]['V'] + 1e-9:
            return k
    return 'C'


class FloodEnv:
    def __init__(self, cfg: FloodConfig, seed: int = 0):
        self.cfg = cfg
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        variant = getattr(cfg, 'variant', 'v1')

        if variant == 'v2':
            # 扩展复杂灾区：长条形合成地形 + 更分散救援点（平面坐标）
            self.terrain = self._synth_terrain_v2()
            self.real = False
            self.base_x, self.base_y = -36000.0, 0.0
            self.base_z = float(self.terrain.height(self.base_x, self.base_y))
            services_raw = SERVICES_V2
            demand = DEMAND_V2
        else:
            try:
                xs, ys, Z = _load_real_dem()
                self.terrain = Terrain(xs, ys, Z)
                self.real = True
            except Exception:
                self.terrain = self._synth_terrain()
                self.real = False
            self.base_x, self.base_y = lonlat_to_xy(BASE_NODE[2], BASE_NODE[3], _LON0, _LAT0)
            self.base_z = BASE_NODE[4]
            services_raw = SERVICES
            demand = DEMAND

        self.base = np.array([self.base_x, self.base_y, self.base_z])
        self.gateway = np.array([self.base_x, self.base_y, self.base_z + COMM['gateway']['h_agl']])

        self.services = []
        for sid, name, px, py, elev, pop in services_raw:
            if variant == 'v2':
                x, y = float(px), float(py)
            else:
                x, y = lonlat_to_xy(px, py, _LON0, _LAT0)
            self.services.append(dict(id=sid, name=name, x=x, y=y, elev=elev, pop=pop,
                                      z=elev + H_SERVICE_CLEARANCE))
        self.service_by_id = {s['id']: s for s in self.services}
        self.disasters = [np.array([s['x'], s['y'], s['z']]) for s in self.services]

        self.boxes = _make_boxes_for(services_raw, demand)
        for b in self.boxes:
            self.service_by_id[b['sid']].setdefault('boxes', []).append(b)
        for s in self.services:
            bxs = s.get('boxes', [])
            s['total_mass'] = sum(b['mass'] for b in bxs)
            s['first_mass'] = sum(b['mass'] for b in bxs if b['first'])

        self.models = DRONE_MODELS
        self.units = DRONE_UNITS
        self.relay_model = RELAY_MODEL

        cfg.terrain = self.terrain
        cfg.base_pos = (self.base_x, self.base_y, self.base_z)
        cfg.disaster_pos = [(s['x'], s['y'], s['z']) for s in self.services]

        self._xmin, self._xmax, self._ymin, self._ymax = self.terrain.bounds()

    def _synth_terrain(self):
        xs = np.linspace(-21000, 21000, 140)
        ys = np.linspace(-16000, 24000, 134)
        X, Y = np.meshgrid(xs, ys)
        Z = 300 + 250 * np.sin(X / 8000) * np.cos(Y / 6000) + 150 * np.exp(-((X / 9000) ** 2 + (Y / 9000) ** 2))
        return Terrain(xs, ys, Z)

    def _synth_terrain_v2(self):
        """长条形山脉：80 km（x）× 40 km（y），中央河谷 + 两侧山脊 + 多处峰。

        基地在西端 (-36000, 0)，救援点沿长轴散布到 +36000，航线更长、起伏更大。
        """
        xs = np.linspace(-40000, 40000, 200)
        ys = np.linspace(-20000, 20000, 120)
        X, Y = np.meshgrid(xs, ys)
        ridge = np.abs(Y) / 12000.0                                   # 两侧越靠边越高
        ridges = (0.5 + 0.5 * np.sin(X / 7000)) * (0.5 + 0.5 * np.sin(X / 13000 + 1.0))
        valley = np.exp(-(Y / 5000.0) ** 2)                            # 中央河谷
        Z = (140.0 + 420.0 * ridge + 260.0 * ridges * (1.0 - 0.6 * valley)
             + 120.0 * np.exp(-((X + 20000) / 9000) ** 2 - ((Y + 9000) / 7000) ** 2)
             + 150.0 * np.exp(-((X + 8000) / 7000) ** 2 - ((Y - 8000) / 6000) ** 2)
             + 180.0 * np.exp(-((X + 25000) / 8000) ** 2 - ((Y + 6000) / 6000) ** 2)
             + 200.0 * np.exp(-((X + 33000) / 7000) ** 2 - ((Y - 5000) / 5000) ** 2))
        return Terrain(xs, ys, Z)

    # ---------------- 解码 ----------------

    def _decode_relays(self, x, off):
        relays = []
        for r in range(self.cfg.n_relay):
            u = (x[off + 3 * r] + 1) / 2
            v = (x[off + 3 * r + 1] + 1) / 2
            w = (x[off + 3 * r + 2] + 1) / 2
            rx = self._xmin + u * (self._xmax - self._xmin)
            ry = self._ymin + v * (self._ymax - self._ymin)
            hgt = self.terrain.height(rx, ry)
            rz = hgt + 50.0 + w * (H_RELAY_MAX_AGL - 50.0)
            relays.append(np.array([rx, ry, rz]))
        return relays

    def decode(self, x):
        x = np.asarray(x, dtype=np.float64).ravel()
        if self.cfg.encoding == 'waypoints':
            routes, relays = self._waypoint_nodes(x)
        else:
            routes, relays = self._permutation_routes(x)
        return routes, relays

    def _waypoint_nodes(self, x):
        n = self.cfg.n_waypoints
        svc = self.service_by_id[self.cfg.target_service]
        m = 1500.0
        xmin = min(0.0, svc['x']) - m; xmax = max(0.0, svc['x']) + m
        ymin = min(0.0, svc['y']) - m; ymax = max(0.0, svc['y']) + m
        wps = []
        for k in range(n):
            u = (x[2 * k] + 1) / 2; v = (x[2 * k + 1] + 1) / 2
            wx = xmin + u * (xmax - xmin)
            wy = ymin + v * (ymax - ymin)
            wz = self.terrain.height(wx, wy) + H_CRUISE_CLEARANCE
            wps.append((wx, wy, wz))
        base_node = (self.base_x, self.base_y, self.base_z)
        svc_node = (svc['x'], svc['y'], svc['z'])
        out_nodes = [base_node] + wps + [svc_node]
        back_nodes = [svc_node] + wps[::-1] + [base_node]
        relays = self._decode_relays(x, 2 * n)
        route = out_nodes + back_nodes[1:]
        return [route], relays

    # ---------------- 排列编码：装箱 ----------------

    def _trip_fits(self, trip, b):
        m = self.models[trip['model']]
        return trip['mass'] + b['mass'] <= m['Q'] + 1e-9 and trip['vol'] + b['vol'] <= m['V'] + 1e-9

    def _new_trip(self, tkey, b, sid):
        model = _type_to_model(tkey)
        if b['mass'] > self.models[model]['Q'] or b['vol'] > self.models[model]['V']:
            model = _min_model(b['mass'], b['vol'])
        return dict(model=model, boxes=[b], mass=b['mass'], vol=b['vol'],
                    svc_seq=[sid], svc_mass={sid: b['mass']})

    def _build_trips(self, order, type_key):
        trips = []
        cur = None
        for si in order:
            svc = self.services[si]
            for b in sorted(svc['boxes'], key=lambda bb: not bb['first']):
                if cur is not None and self._trip_fits(cur, b):
                    cur['boxes'].append(b)
                    cur['mass'] += b['mass']; cur['vol'] += b['vol']
                    cur['svc_mass'][svc['id']] = cur['svc_mass'].get(svc['id'], 0.0) + b['mass']
                    if svc['id'] not in cur['svc_seq']:
                        cur['svc_seq'].append(svc['id'])
                else:
                    if cur is not None:
                        trips.append(cur)
                    cur = self._new_trip(type_key[si], b, svc['id'])
        if cur is not None:
            trips.append(cur)
        return trips

    def _permutation_routes(self, x):
        N = self.cfg.n_service
        order_key = x[0:N]
        type_key = x[N:2 * N]
        order = [int(i) for i in np.argsort(order_key)]
        trips = self._build_trips(order, type_key)
        base_node = (self.base_x, self.base_y, self.base_z)
        routes = []
        for t in trips:
            pts = [base_node]
            for sid in t['svc_seq']:
                s = self.service_by_id[sid]
                pts.append((s['x'], s['y'], s['z']))
            pts.append(base_node)
            routes.append(pts)
        relays = self._decode_relays(x, 2 * N)
        return routes, relays

    # ---------------- 通信评估 ----------------

    def _comm_violation(self, route, relays):
        """返回路径上通信中断采样点比例（直连或经中继均不可用）。"""
        pts = []
        for a, b in zip(route[:-1], route[1:]):
            d = math.hypot(b[0] - a[0], b[1] - a[1])
            ns = max(1, int(d / 500.0))
            for k in range(1, ns + 1):
                t = k / ns
                pts.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t,
                            a[2] + (b[2] - a[2]) * t))
        if not pts:
            return 0.0
        bad = 0
        for p in pts:
            ok = link_available(self.terrain, 'transport', 'gateway', p, self.gateway)
            if not ok:
                for r in relays:
                    if (link_available(self.terrain, 'transport', 'relay_access', p, r)
                            and link_available(self.terrain, 'relay_backhaul', 'gateway', r, self.gateway)):
                        ok = True
                        break
            if not ok:
                bad += 1
        return bad / len(pts)

    # ---------------- 连续航点 rollout ----------------

    def _rollout_waypoints(self, x):
        n = self.cfg.n_waypoints
        svc = self.service_by_id[self.cfg.target_service]
        routes, relays = self._waypoint_nodes(x)
        route = routes[0]
        out_nodes = route[:n + 2]
        back_nodes = route[n + 1:]
        first_boxes = [b for b in svc['boxes'] if b['first']]
        q = sum(b['mass'] for b in first_boxes)
        vol = sum(b['vol'] for b in first_boxes)
        model_key = _min_model(q, vol)
        model = self.models[model_key]
        E_out, t_out = transport_path_energy(self.terrain, model, q, out_nodes, 0.0, [])
        E_back, t_back = transport_path_energy(self.terrain, model, 0.0, back_nodes, 0.0, [])
        E = E_out + E_back
        nbox = len(first_boxes)
        t_service = model['t_prep'] + nbox * model['t_load'] + model['t_hand'] + nbox * model['t_hand_box']
        t_total = t_out + t_back + t_service
        comm_viol = self._comm_violation(route, relays)
        e_budget = (1.0 - RHO_RETURN) * model['E_use']
        pen_safety = max(0.0, E - e_budget) / model['E_use']
        cfg = self.cfg
        cost = (cfg.w_energy * E / e_budget
                + cfg.w_time * t_total / 3600.0
                + cfg.w_comm * comm_viol
                + cfg.w_safety * pen_safety)
        metrics = dict(E=E, E_out=E_out, E_back=E_back, t=t_total, t_out=t_out, t_back=t_back,
                       q=q, model=model_key, n_box=nbox, comm_viol=comm_viol,
                       safety_ok=E <= e_budget + 1e-9,
                       comm_ok=bool(comm_viol <= 1e-9),
                       energy=float(E), flight_time=float(t_total))
        return cost, metrics, ([route], relays)

    # ---------------- 排列编码：路径 / 时间轴 ----------------

    def _trip_metrics(self, trip):
        model = self.models[trip['model']]
        base_node = (self.base_x, self.base_y, self.base_z)
        seq = [base_node] + [tuple(self.service_by_id[s][k] for k in ('x', 'y', 'z'))
                             for s in trip['svc_seq']] + [base_node]
        E = 0.0
        t_flight = 0.0
        arrival = {}
        remaining = trip['mass']
        for idx in range(len(seq) - 1):
            a, b = seq[idx], seq[idx + 1]
            is_last = (idx == len(seq) - 2)
            q_seg = 0.0 if is_last else remaining
            r = transport_segment(self.terrain, model, q_seg, a, b)
            E += r['e']; t_flight += r['t']
            if not is_last:
                sid = trip['svc_seq'][idx]
                nbox = len([bb for bb in trip['boxes'] if bb['sid'] == sid])
                hand = model['t_hand'] + nbox * model['t_hand_box']
                arrival[sid] = t_flight + hand
                t_flight += hand
                remaining -= trip['svc_mass'][sid]
        trip['E'] = E
        trip['t_flight'] = t_flight
        trip['t_ground'] = model['t_prep'] + len(trip['boxes']) * model['t_load']
        trip['arrival'] = arrival
        return trip

    def _schedule(self, trips):
        free = {u[0]: 0.0 for u in self.units}
        unit_model = {u[0]: u[1] for u in self.units}
        makespan = 0.0
        deliveries = []
        info = []
        for trip in trips:
            mk = trip['model']
            cands = [u for u, m in unit_model.items() if m == mk]
            unit = min(cands, key=lambda u: free[u]) if cands else min(free, key=lambda u: free[u])
            start = free[unit]
            end = start + trip['t_ground'] + trip['t_flight']
            free[unit] = end
            makespan = max(makespan, end)
            for b in trip['boxes']:
                deliveries.append((b, start + trip['t_ground'] + trip['arrival'][b['sid']]))
            info.append((trip, start, end, unit))
        return makespan, deliveries, info

    def _rollout_permutation(self, x):
        N = self.cfg.n_service
        order = [int(i) for i in np.argsort(x[0:N])]
        type_key = x[N:2 * N]
        trips = self._build_trips(order, type_key)
        for t in trips:
            self._trip_metrics(t)
        relays = self._decode_relays(x, 2 * N)
        base_node = (self.base_x, self.base_y, self.base_z)
        routes = []
        for t in trips:
            pts = [base_node] + [tuple(self.service_by_id[s][k] for k in ('x', 'y', 'z'))
                                 for s in t['svc_seq']] + [base_node]
            routes.append(pts)

        makespan, deliveries, info = self._schedule(trips)

        total_E = sum(t['E'] for t in trips)
        e_budget = sum((1 - RHO_RETURN) * self.models[t['model']]['E_use'] for t in trips)
        pen_safety = sum(max(0.0, t['E'] - (1 - RHO_RETURN) * self.models[t['model']]['E_use'])
                         / self.models[t['model']]['E_use'] for t in trips)

        n_tardy = first_tardy = n_first = 0
        for b, t_del in deliveries:
            dl = b['deadline'] if b['first'] else b['expect']
            if t_del > dl:
                n_tardy += 1
                if b['first']:
                    first_tardy += 1
            if b['first']:
                n_first += 1
        n_total = max(1, len(deliveries))
        tardy = (n_tardy / n_total) + (first_tardy / max(1, n_first))

        comm_viol = 0.0
        if self.cfg.n_relay > 0 and routes:
            comm_viol = float(np.mean([self._comm_violation(rt, relays) for rt in routes]))

        cfg = self.cfg
        cost = (cfg.w_energy * total_E / max(1e-6, e_budget)
                + cfg.w_time * makespan / 10800.0
                + cfg.w_tardy * tardy
                + cfg.w_comm * comm_viol
                + cfg.w_safety * pen_safety)
        trip_states = []
        for t in trips:
            ok = t['E'] <= (1 - RHO_RETURN) * self.models[t['model']]['E_use'] + 1e-9
            trip_states.append(1 if ok else 2)
        metrics = dict(trips=len(trips), total_E=total_E, makespan=makespan,
                       n_tardy=n_tardy, n_first_tardy=first_tardy, n_total=len(deliveries),
                       comm_viol=comm_viol, pen_safety=pen_safety,
                       safety_ok=all(s == 1 for s in trip_states),
                       trip_states=trip_states,
                       comm_ok=bool(comm_viol <= 1e-9),
                       energy=float(total_E), flight_time=float(makespan))
        return cost, metrics, (routes, relays)

    # ---------------- 统一求值入口 ----------------

    def _rollout(self, x, record=False):
        x = np.asarray(x, dtype=np.float64).ravel()
        if self.cfg.encoding == 'waypoints':
            cost, metrics, (routes, relays) = self._rollout_waypoints(x)
            states = [1 if metrics.get('safety_ok', True) else 2]
        else:
            cost, metrics, (routes, relays) = self._rollout_permutation(x)
            states = list(metrics.get('trip_states', [1] * len(routes)))
        frames = self._make_frames(routes, relays, metrics, states) if record else None
        return cost, states, metrics, frames

    def _make_frames(self, routes, relays, metrics, states=None, n_steps=60):
        """把每条路线按弧长等距采样成动画帧（cargos=[x,y,z,state]）。"""
        relay_pts = [tuple(float(v) for v in np.asarray(r, dtype=np.float64).ravel())
                     for r in relays]
        samples = []
        for route in routes:
            pts = np.asarray(route, dtype=np.float64)
            if len(pts) < 2:
                p = pts[0] if len(pts) == 1 else np.array([0.0, 0.0, 0.0])
                samples.append(np.tile(p, (n_steps + 1, 1)))
                continue
            d = np.linalg.norm(np.diff(pts, axis=0), axis=1)
            cum = np.concatenate([[0.0], np.cumsum(d)])
            total = cum[-1]
            if total <= 1e-9:
                samples.append(np.tile(pts[0], (n_steps + 1, 1)))
                continue
            s_tgt = np.linspace(0.0, total, n_steps + 1)
            sp = np.empty((n_steps + 1, 3))
            for k, s in enumerate(s_tgt):
                j = int(np.searchsorted(cum, s, side='right') - 1)
                j = max(0, min(j, len(pts) - 2))
                seg = cum[j + 1] - cum[j]
                f = 0.0 if seg <= 1e-12 else (s - cum[j]) / seg
                f = max(0.0, min(1.0, f))
                sp[k] = pts[j] * (1.0 - f) + pts[j + 1] * f
            samples.append(sp)

        if states is None:
            states = [1 if metrics.get('safety_ok', True) else 2] * len(routes)
        frames = []
        for k in range(n_steps + 1):
            cargos = []
            for i, sp in enumerate(samples):
                st = states[i] if k == n_steps else 0
                cargos.append([float(sp[k][0]), float(sp[k][1]), float(sp[k][2]), st])
            frames.append({'step': k, 'cargos': cargos, 'relays': relay_pts})
        return frames

    def cost(self, x):
        cost, _, _, _ = self._rollout(x, record=False)
        return float(cost)

    def evaluate(self, x):
        """返回 (cost, state, metrics)，供 GUI 多维收敛曲线展示。"""
        cost, state, metrics, _ = self._rollout(x, record=False)
        return cost, state, metrics

    def trajectory(self, x):
        """返回 (cost, state, frames)，供 GUI 三维动画演示。"""
        cost, state, _, frames = self._rollout(x, record=True)
        return cost, state, frames


# ======================================================================
# 问题协议适配（与 CECFunction / SwarmProblem 鸭子类型一致）
# ======================================================================

class FloodProblem:
    """把一次洪涝救援场景包装成 DE 可直接消费的问题对象。

    协议字段对齐 ``cec_suites.CECFunction`` 与 ``uav_adversarial.UAVAdversarialProblem``：
    ``lb/ub/dim/f_opt/label/fid/category/suite/name`` + ``__call__(x) -> float``。
    """

    def __init__(self, scenario: str, fid: int, env: FloodEnv, name: str = ''):
        self.suite = f'uav_{scenario}'
        self.scenario = scenario
        self.fid = fid
        self.env = env
        self.cfg = env.cfg
        self.dim = env.cfg.dim
        self.lb = -1.0
        self.ub = 1.0
        self.f_opt = None
        self.x_opt = None
        self.name = name or f'{scenario} task {fid}'
        self.category = 'application'

    def decode(self, x):
        """返回 (routes, relays)：routes 为航线节点列表，relays 为中继悬停点。"""
        return self.env.decode(np.asarray(x, dtype=np.float64).ravel())

    def __call__(self, x) -> float:
        return self.env.cost(x)

    def trajectory(self, x):
        return self.env.trajectory(x)

    def evaluate(self, x):
        """返回 (cost, state, metrics)，供 GUI 多维收敛曲线展示。"""
        return self.env.evaluate(x)

    @property
    def label(self):
        return f'U{self.fid}'

    def __repr__(self):
        return f'<UAV {self.scenario} U{self.fid} {self.name} D={self.dim}>'


# ======================================================================
# 场景工厂
# ======================================================================

def build_flood_env(fid: int, seed: int = 0, n_waypoints=None,
                    n_cargo=None, n_relay=None) -> FloodEnv:
    """按任务 id 生成确定性的洪涝救援环境。

    ``n_waypoints`` 非 None 时切换到连续航点编码（单架次演示），``n_cargo`` /
    ``n_relay`` 覆盖运输机数 / 中继机数。4 个任务覆盖两种编码与有无中继协同。
    """
    cfg = FloodConfig()
    if n_waypoints is not None:
        cfg.encoding = 'waypoints'
        cfg.n_waypoints = int(n_waypoints)
    if n_cargo is not None:
        cfg.n_cargo = int(n_cargo)
    if n_relay is not None:
        cfg.n_relay = int(n_relay)

    if fid == 1:                            # 全服务区多机调度（排列编码，无中继）
        cfg.encoding = 'permutation'
        cfg.n_service = 15
        cfg.n_relay = 0 if n_relay is None else cfg.n_relay
    elif fid == 2:                          # 全服务区调度 + 2 架中继协同
        cfg.encoding = 'permutation'
        cfg.n_service = 15
        cfg.n_relay = 2 if n_relay is None else cfg.n_relay
    elif fid == 3:                          # 单架次航点：目标 S006（地形复杂服务区）
        cfg.encoding = 'waypoints'
        cfg.target_service = 'S006'
        cfg.n_waypoints = 3 if n_waypoints is None else cfg.n_waypoints
        cfg.n_relay = 0 if n_relay is None else cfg.n_relay
    else:                                   # 单架次航点 + 1 架中继：目标 S015
        cfg.encoding = 'waypoints'
        cfg.target_service = 'S015'
        cfg.n_waypoints = 4 if n_waypoints is None else cfg.n_waypoints
        cfg.n_relay = 1 if n_relay is None else cfg.n_relay

    return FloodEnv(cfg, seed=seed + fid * 101)


def build_flood_v2_env(fid: int = 1, seed: int = 0, n_waypoints=None,
                       n_cargo=None, n_relay=None) -> FloodEnv:
    """构建扩展复杂灾区（flood_v2）：长条形山地 + 24 个分散救援点。

    任务 fid 1/2 为全救援点多机调度（排列编码，有无中继），fid 3/4 为单架次
    连续航点演示（目标取分散点 V006 / V018）。
    """
    cfg = FloodConfig()
    cfg.variant = 'v2'
    cfg.n_service = 24
    if n_waypoints is not None:
        cfg.encoding = 'waypoints'
        cfg.n_waypoints = int(n_waypoints)
    if n_cargo is not None:
        cfg.n_cargo = int(n_cargo)

    if fid == 1:                            # 全救援点多机调度（无中继）
        cfg.encoding = 'permutation'
        cfg.n_relay = 0 if n_relay is None else int(n_relay)
    elif fid == 2:                          # 全救援点调度 + 3 架中继协同
        cfg.encoding = 'permutation'
        cfg.n_relay = 3 if n_relay is None else int(n_relay)
    elif fid == 3:                          # 单架次航点：目标 V006
        cfg.encoding = 'waypoints'
        cfg.target_service = 'V006'
        cfg.n_waypoints = 3 if n_waypoints is None else int(n_waypoints)
        cfg.n_relay = 0 if n_relay is None else int(n_relay)
    else:                                   # 单架次航点 + 1 架中继：目标 V018
        cfg.encoding = 'waypoints'
        cfg.target_service = 'V018'
        cfg.n_waypoints = 4 if n_waypoints is None else int(n_waypoints)
        cfg.n_relay = 1 if n_relay is None else int(n_relay)

    return FloodEnv(cfg, seed=seed + fid * 101)


# 注册：场景名 -> (默认维度, 默认任务数)
FLOOD_DIM = FloodConfig().dim      # permutation 默认 15*2 + 0 = 30
FLOOD_NFUNCS = 4

FLOOD_V2_DIM = FloodConfig(variant='v2', n_service=24).dim   # 24*2 + 0 = 48
FLOOD_V2_NFUNCS = 4


if __name__ == '__main__':
    for fid in range(1, FLOOD_NFUNCS + 1):
        env = build_flood_env(fid)
        p = FloodProblem('flood', fid, env)
        x = np.zeros(p.dim)
        c = p(x)
        print(f'{p!r}  encoding={p.cfg.encoding}  cost(x=0)={c:.3f}  '
              f'env.dim={p.cfg.dim}  real_dem={env.real}')
        rng = np.random.default_rng(1)
        costs = [p(rng.uniform(-1, 1, p.dim)) for _ in range(60)]
        print(f'  随机解 cost: min={min(costs):.3f} med={np.median(costs):.3f} '
              f'max={max(costs):.3f}')
        cost, state, frames = p.trajectory(x)
        print(f'  轨迹帧 {len(frames)}，末帧 cargos={len(frames[-1]["cargos"])}，'
              f'投送={sum(1 for c in frames[-1]["cargos"] if c[3] == 1)}')
    # v2 自检
    for fid in range(1, FLOOD_V2_NFUNCS + 1):
        env = build_flood_v2_env(fid)
        p = FloodProblem('flood_v2', fid, env)
        x = np.zeros(p.dim)
        c = p(x)
        print(f'{p!r}  encoding={p.cfg.encoding}  cost(x=0)={c:.3f}  '
              f'env.dim={p.cfg.dim}  real_dem={env.real}')
        cost, state, frames = p.trajectory(x)
        print(f'  轨迹帧 {len(frames)}，末帧 cargos={len(frames[-1]["cargos"])}，'
              f'投送={sum(1 for c in frames[-1]["cargos"] if c[3] == 1)}')


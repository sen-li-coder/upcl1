"""UAV 多智能体对抗仿真 —— LASE 的「应用问题套件」。

本模块让无人机对抗场景以与 ``cec_suites.CECFunction`` 相同的鸭子类型协议
接入主软件，从而复用 ``run_upcl_cec.run_arm``（30 个纯连续 DE + bare/UPCL
配对 + 落盘 schema），而无需改动任何 DE 核：

    * 决策变量 x ∈ [-1, 1]^D，全连续。离散/分类决策与约束在
      ``decode``/``penalty`` 内部消化，DE 完全无感 —— 这是「适配当下全部
      DE」的硬约束落点。
    * 毫秒级确定性 rollout，预算语义 = 评估次数，与 CEC 同构。

场景 ``intercept``（突防 vs 拦截）
----------------------------------
``n_drones`` 架我方无人机从起点突防至目标区；``n_interceptors`` 架规则
拦截者按「追击最近存活目标」运动。决策变量 = 每架无人机的 ``K`` 个中途
航点（连续坐标）。收益 = 到达奖励 - 损失 - 超时 - 禁飞区/越界/碰撞违反。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

# 场景 2：2020 华为杯研究生数学建模 D 题无人机集群协同对抗（独立模块，鸭子类型一致）
try:                                                     # pragma: no cover
    from .uav_swarm import (SwarmProblem, build_swarm_env, swarm_cfg,  # noqa: E402
                            SWARM_DIM, SWARM_NFUNCS)
except ImportError:                                      # pragma: no cover
    from uav_swarm import (SwarmProblem, build_swarm_env, swarm_cfg,  # noqa: E402
                           SWARM_DIM, SWARM_NFUNCS)

# 三维地形基础设施（Terrain / terrain_blocked）：突防拦截 / 集群突防共用
try:                                                     # pragma: no cover
    from .uav_terrain import Terrain, terrain_blocked     # noqa: E402
except ImportError:                                      # pragma: no cover
    from uav_terrain import Terrain, terrain_blocked      # noqa: E402

# ===========================================================================
# 环境参数
# ===========================================================================


@dataclass
class EnvConfig:
    """一次对抗仿真所需的全部环境参数（供 GUI 展示与编辑、供仿真使用）。"""

    map_w: float = 1000.0            # 地图宽（米/单位）
    map_h: float = 1000.0            # 地图高
    n_drones: int = 3                # 我方无人机数量
    drone_speed: float = 18.0        # 我方速度（单位/步）
    drone_turn_rate: float = 0.25    # 我方最大角速度（rad/步，限转向 → 无直角转弯）
    start_pos: Tuple[float, float] = (60.0, 60.0)   # 我方起点
    target_pos: Tuple[float, float] = (820.0, 820.0)  # 目标区中心（与军事基地 base_pos 一致）
    target_radius: float = 60.0      # 到达判定半径
    n_interceptors: int = 1          # 拦截者数量
    interceptor_speed: float = 12.0  # 拦截者速度
    interceptor_turn_rate: float = 0.35  # 拦截者最大角速度（rad/步）
    intercept_radius: float = 55.0   # 被击落判定半径（= 前方圆锥侦察范围半径）
    intercept_half_angle: float = 0.5236  # 拦截者前方圆锥水平半角（rad，约 30°）
    intercept_vert_half_angle: float = 0.5236  # 拦截者前方圆锥垂直半角（rad，约 30°）
    interceptor_pos: List[Tuple[float, float]] = field(
        default_factory=lambda: [(700.0, 700.0)])
    radar_pos: Tuple[float, float] = (500.0, 500.0)  # 雷达站位置（地图中央预警，与直升机停靠点错开）
    radar_range: float = 520.0        # 雷达探测半径（大范围预警，捕获后才起飞拦截）
    # —— 预警参数（红方 F2 预警课题）：默认值 = 原「全向雷达 + 即捕即出动」行为 ——
    radar_azimuth: float = 0.0        # 主瓣方位角（rad），仅当 radar_half_angle < pi 时生效
    radar_half_angle: float = math.pi  # 主瓣水平半张角（rad），pi = 全向无扇区门限
    alert_threshold: int = 1          # 雷达范围内需同时出现 N 个目标才出动（1 = 即捕即出动）
    scan_period: int = 1             # 雷达扫描周期（步），1 = 每步更新；>1 = 周期内锁存上次结果
    # —— 协同调度（红方 F3 拦截 / F4 协同课题）；三项全部 None 时逐位等价于原
    #    「各单元独立贪心打最近目标 + 全局告警阈值」行为 ——
    assign_target: Optional[List[int]] = None
    #   各防御单元的「主责目标」索引（-1 = 无主责、自由交战）。行序 = 防空车
    #   (n_aa 辆) 在前、拦截机 (n_interceptors 架) 在后。主责目标存活时该单元只
    #   打它；主责目标已终态则退回自由贪心（避免「分到死目标就永久沉默」）。
    sector_bounds: Optional[List[float]] = None
    #   责任区方位角边界（rad，相对基地、升序，长度 = 单元数 − 1）：把战场按基地
    #   方位角切成 (n_aa + n_interceptors) 个扇区，第 k 个单元只交战落在自己扇区
    #   内的目标。None = 不分区（各单元全向自由交战）。
    launch_threshold: Optional[List[int]] = None
    #   拦截机逐机出动阈值（第 k 架需雷达同时看到 N 个目标才起飞）；None = 用全局
    #   alert_threshold。用于「按需出动」，避免全部升空后集体扑向同一目标。
    interceptor_accel: float = 1.2    # 直升机起飞/降落加减速度（速度单位/步，模拟加减速过程）
    no_fly_zones: List[Tuple[float, float, float, float]] = field(
        default_factory=list)        # (cx, cy, cz, r) 禁飞球形空域
    n_waypoints: int = 2             # 每架无人机中途航点数 K（蓝方）
    n_int_waypoints: int = 2         # 每架拦截者中途航点数 K_red（协同演化）

    # —— 地面无人车（防空车，拦截方式之一）——
    n_aa: int = 2                    # 地面无人车数量
    aa_pos: List[Tuple[float, float]] = field(
        default_factory=lambda: [(820.0, 820.0), (780.0, 720.0)])  # 无人车初始位置
    aa_speed: float = 12.0           # 无人车地面机动速度（单位/步）
    aa_turn: float = 0.5             # 无人车最大角速度（rad/步）
    aa_range: float = 260.0          # 无人车对空探测/攻击范围（米）
    aa_vert_half_angle: float = 1.0472  # 无人车对空垂直半角（rad，约 60°）
    aa_reload: float = 2.5           # 发射冷却（步）
    aa_max_missiles: int = 3         # 同时在场导弹数上限（每车）
    missile_speed: float = 25.0      # 防空导弹速度（单位/步，≈1.4× 无人机 18）
    missile_turn: float = 0.5        # 导弹最大角速度（rad/步，有限转弯，非直角）
    missile_climb: float = 45.0      # 导弹每步最大爬升/俯冲（米/步）
    missile_radius: float = 18.0     # 导弹命中半径（米）
    missile_fuel: int = 40           # 导弹最大飞行步数（燃料耗尽自毁）

    # —— 三维地形对抗（intercept：合成山地 + 贴地飞行 + 视线遮挡 + 爬山能耗）——
    terrain_enabled: bool = True      # 启用三维合成山地地形
    h_clearance: float = 30.0        # 贴地飞行离地安全高度（米）
    terrain_amplitude: float = 220.0 # 山地起伏幅度（米）
    los_block: bool = True            # 拦截捕获需视线（LOS）通畅，山体可遮挡雷达
    wp_reach_radius: float = 30.0    # 中间航点到达判定半径
    n_steps: int = 220               # 最大仿真步数
    collision_radius: float = 25.0   # 我方机间碰撞判定半径

    # —— 蓝方三维飞行：高度自由度 + 能源 + 坠毁 ——
    max_alt: float = 460.0           # 蓝方飞行高度上限（绝对高度，米，≥ 地形最高贴地+偏移）
    max_climb_rate: float = 25.0     # 每步最大爬升/下降速率（米/步）
    max_alt_offset: float = 100.0    # 航点高度相对贴地高度的最大爬升偏移（米）
    lookahead_steps: int = 12        # 垂直前瞻步数（提前爬升翻越山峰，避免穿山兜底弹跳）
    energy_capacity: float = 100.0   # 每架初始能源
    energy_per_step: float = 0.35    # 每步水平飞行基础能耗
    climb_energy: float = 0.008      # 每爬升 1 米额外能耗

    # 收益权重（cost = -reward，DE 求最小化）
    w_arrive: float = 100.0
    w_lost: float = 80.0
    w_time: float = 30.0
    w_nofly: float = 20.0
    w_bounds: float = 30.0
    w_collision: float = 40.0
    # 连续梯度项（让 cost 具有梯度，收敛曲线不再是一条直线）
    w_path: float = 20.0             # 绕行惩罚权重（路径长度 / 直线距离 - 1）
    w_safety: float = 15.0           # 安全裕度奖励权重（与拦截者最小距离 / 4R）
    w_climb: float = 30.0            # 爬山能耗惩罚：翻越一座典型山地(≈terrain_amplitude米爬升)的罚分
    w_crash: float = 90.0            # 能源耗尽坠毁惩罚权重（每架）

    # —— 空地协同巷战（军事基地 + 步兵 + 巡逻兵 + 楼房掩体）——
    n_infantry: int = 3              # 蓝方步兵团队人数（协同作战，独立航点编码）
    infantry_speed: float = 5.0      # 步兵前进速度（单位/步，慢于无人机/拦截机）
    infantry_hp: float = 100.0       # 每名步兵血量（与巡逻兵对称交火）
    infantry_damage: float = 20.0    # 步兵每发伤害
    infantry_range: float = 30.0     # 步兵球形攻击范围（米）
    infantry_fire_cd: float = 0.25   # 步兵射击冷却（秒，每 0.25 秒攻击一次）
    n_patrol: int = 20               # 红方巡逻兵数量（随机分布，用户指定 20）
    patrol_hp: float = 100.0         # 巡逻兵血量（用户指定）
    patrol_damage: float = 20.0      # 巡逻兵每发伤害（用户指定）
    patrol_range: float = 30.0       # 巡逻兵球形攻击范围（米）
    patrol_vision_range: float = 80.0  # 巡逻兵可视范围（米，发现敌方→通知同伴→靠近，需 > 攻击范围）
    patrol_fire_cd: float = 0.25     # 巡逻兵射击冷却（秒，每 0.25 秒攻击一次）
    patrol_speed: float = 3.0        # 巡逻兵移动速度（单位/步）
    dt: float = 0.25                 # 仿真时间步长（秒/步），把射击冷却换算为步数
    base_pos: Tuple[float, float] = (820.0, 820.0)  # 军事基地（无人机攻击点 + 步兵夺取点）
    base_hp: float = 1000.0          # 军事基地血量（无人机轰炸削减，用户指定 1000）
    base_radius: float = 55.0        # 基地夺取/轰炸判定半径（米）
    bomb_damage: float = 50.0        # 每架到达无人机一次投弹伤害（投弹后自毁，不持续攻击）
    n_buildings: int = 14            # 楼房数量（巷战掩体）
    building_min: float = 22.0       # 楼房最小边长（米）
    building_max: float = 42.0       # 楼房最大边长（米）

    # 空地协同收益权重
    w_base: float = 200.0            # 基地轰炸进度奖励（0..1 连续梯度）
    w_inf_arrive: float = 120.0      # 每名步兵抵达基地奖励
    w_inf_lost: float = 100.0        # 每名步兵阵亡惩罚
    w_patrol_kill: float = 60.0      # 每击杀一名巡逻兵奖励
    w_success: float = 150.0         # 整体成功奖励（基地摧毁 + 步兵夺取）

    @property
    def dim(self) -> int:
        """蓝方决策变量维度 = 无人机三维航点 + 步兵二维航点。"""
        return (self.n_drones * self.n_waypoints * 3
                + self.n_infantry * self.n_waypoints * 2)

    @property
    def red_dim(self) -> int:
        """红方（拦截者）决策变量维度 = n_interceptors * n_int_waypoints * 2。"""
        return self.n_interceptors * self.n_int_waypoints * 2

    def describe(self) -> Dict[str, object]:
        """展平为可读 dict，供 GUI 参数面板显示。"""
        return {
            '地图尺寸': f'{self.map_w:.0f} × {self.map_h:.0f}',
            '我方无人机数量': self.n_drones,
            '我方速度': f'{self.drone_speed:.1f} /步',
            '我方转弯速率': f'{self.drone_turn_rate:.2f} rad/步',
            '我方最小转弯半径': f'{self.drone_speed / self.drone_turn_rate:.0f}',
            '起点': f'{self.start_pos}',
            '目标区（军事基地）': f'{self.base_pos} (r={self.base_radius:.0f})',
            '拦截者数量': self.n_interceptors,
            '拦截者速度': f'{self.interceptor_speed:.1f} /步',
            '拦截者转弯速率': f'{self.interceptor_turn_rate:.2f} rad/步',
            '拦截者最小转弯半径': f'{self.interceptor_speed / self.interceptor_turn_rate:.0f}',
            '拦截半径': f'{self.intercept_radius:.0f}',
            '捕获圆锥': (f'前方水平 ±{math.degrees(self.intercept_half_angle):.0f}° / '
                         f'垂直 ±{math.degrees(self.intercept_vert_half_angle):.0f}°'),
            '禁飞区': (f'{len(self.no_fly_zones)} 个: ' +
                       ', '.join(f'(x={c:.0f},y={d:.0f},z={z:.0f},r={r:.0f})'
                                 for c, d, z, r in self.no_fly_zones)
                       if self.no_fly_zones else '无'),
            '三维地形': ('启用 · 合成山地（起伏 '
                         + f'{self.terrain_amplitude:.0f} m）'
                         if self.terrain_enabled else '关闭（平地）'),
            '贴地飞行离地高度': f'{self.h_clearance:.0f} m',
            '飞行高度上限': f'{self.max_alt:.0f} m',
            '航点爬升偏移': (f'贴地高度 + [0, {self.max_alt_offset:.0f}] m 偏移，'
                             f'前瞻 {self.lookahead_steps} 步平滑爬升'),
            '能源': (f'初始 {self.energy_capacity:.0f}，每步 {self.energy_per_step:.2f}，'
                     f'爬升 {self.climb_energy:.3f}/m，耗尽坠毁'),
            '视线遮挡 LOS': ('开启 · 山体可遮挡拦截雷达'
                            if self.los_block else '关闭'),
            '爬山能耗': (f'翻越一座典型山地（爬升约 {self.terrain_amplitude:.0f} m）'
                         f'罚 {self.w_climb:.0f} 分'),
            '每机航点数 K': self.n_waypoints,
            '航点到达半径': f'{self.wp_reach_radius:.0f}',
            '决策变量维度 D': self.dim,
            '编码域': '[-1, 1]^D',
            '最大步数': self.n_steps,
            '碰撞半径': f'{self.collision_radius:.0f}',
            '绕行惩罚权重': f'{self.w_path:.0f}（路径长度 / 直线距离 - 1）',
            '安全裕度权重': f'{self.w_safety:.0f}（与拦截者最小距离 / 4R）',
            '军事基地（攻击点）': (f'{self.base_pos} (r={self.base_radius:.0f}, '
                             f'血量 {self.base_hp:.0f}，无人机每架投弹一次 '
                             f'{self.bomb_damage:.0f} 后自毁，步兵抵达后持续攻击)'),
            '步兵团队': (f'{self.n_infantry} 人（血量 {self.infantry_hp:.0f}，'
                         f'速度 {self.infantry_speed:.1f}/步，伤害 {self.infantry_damage:.0f}，'
                         f'射程 {self.infantry_range:.0f} m，冷却 {self.infantry_fire_cd:.2f} s，'
                         f'抵达目标点后攻击基地）'),
            '巡逻兵（红方）': (f'{self.n_patrol} 人（血量 {self.patrol_hp:.0f}，'
                             f'速度 {self.patrol_speed:.1f}/步，伤害 {self.patrol_damage:.0f}，'
                             f'射程 {self.patrol_range:.0f} m、可视 {self.patrol_vision_range:.0f} m，'
                             f'冷却 {self.patrol_fire_cd:.2f} s，'
                             f'平时慢速布朗巡逻，发现步兵后加速逼近（速度同步兵）、靠近再射击）'),
            '巷战楼房': f'{self.n_buildings} 栋（边长 {self.building_min:.0f}~{self.building_max:.0f} m，可作掩体遮挡 LOS）',
        }


# ===========================================================================
# 仿真引擎（纯 Python，确定性，毫秒级）
# ===========================================================================


def _intercept_terrain(map_w: float, map_h: float, amplitude: float,
                       seed: int = 0) -> "Terrain":
    """为 intercept 场景合成一片三维山地（确定性，随 seed 变化）。

    战场 [0, map_w] × [0, map_h] 内放置若干座高斯山峰 + 低频正弦起伏，
    使「翻山 vs 绕山」「山体遮挡雷达视线（LOS）」成为可优化的战略维度。
    山峰高度由 ``amplitude`` 缩放，谷底相对平坦（约 0 ~ 30 m）。
    """
    rng = np.random.default_rng(seed + 20261007)
    n = 96
    xs = np.linspace(0.0, map_w, n)
    ys = np.linspace(0.0, map_h, n)
    X, Y = np.meshgrid(xs, ys)
    # 若干山峰中心与半径（相对地图比例，保证山峰坐落在战场内部）
    cx = np.array([0.30, 0.50, 0.72, 0.15, 0.85])
    cy = np.array([0.65, 0.34, 0.60, 0.22, 0.80])
    sx = np.array([0.16, 0.18, 0.15, 0.13, 0.15])
    sy = np.array([0.15, 0.16, 0.17, 0.12, 0.13])
    amp = np.array([1.00, 0.85, 0.95, 0.70, 0.75]) * amplitude
    Z = np.zeros_like(X)
    for i in range(len(cx)):
        Z += amp[i] * np.exp(-((X - cx[i] * map_w) ** 2) / (2 * (sx[i] * map_w) ** 2)
                             - ((Y - cy[i] * map_h) ** 2) / (2 * (sy[i] * map_h) ** 2))
    # 低频起伏让谷地并非完全平坦，爬升/下降更真实
    Z += 35.0 * np.sin(X / 220.0) * np.cos(Y / 180.0) + 25.0
    return Terrain(xs, ys, Z)


def _decode_waypoints(x: np.ndarray, cfg: EnvConfig,
                      terrain=None) -> np.ndarray:
    """连续编码 [-1,1]^D -> (n_drones, K, 3) 地图航点坐标 (x, y, z)。

    x/y 解码到地图平面 [0, map_w]×[0, map_h]；z 编码为**相对贴地飞行高度的
    爬升偏移** [0, max_alt_offset]，解码后航点高度 = 贴地高度（地面 + 离地
    安全）+ 偏移，再夹到 max_alt 上限。传入 ``terrain``（三维地形启用）时按
    贴地偏移解码；否则回退为绝对高度 [0, max_alt]（兼容无地形调用）。
    """
    x = np.asarray(x, dtype=float).ravel()
    # 决策变量前半段 = 无人机三维航点；后半段 = 步兵二维航点（见 _decode_infantry_waypoints）
    n_drone_dims = cfg.n_drones * cfg.n_waypoints * 3
    x = x[:n_drone_dims].reshape(cfg.n_drones, cfg.n_waypoints, 3)
    xs = 0.5 * (x[:, :, 0] + 1.0) * cfg.map_w
    ys = 0.5 * (x[:, :, 1] + 1.0) * cfg.map_h
    if terrain is not None:
        z_off = 0.5 * (x[:, :, 2] + 1.0) * cfg.max_alt_offset
        ground = np.asarray(
            [terrain.height(float(px), float(py))
             for px, py in zip(xs.ravel(), ys.ravel())], dtype=float
        ).reshape(xs.shape)
        zs = np.minimum(ground + cfg.h_clearance + z_off, cfg.max_alt)
    else:
        zs = 0.5 * (x[:, :, 2] + 1.0) * cfg.max_alt
    return np.stack([xs, ys, zs], axis=-1)


def _decode_infantry_waypoints(x: np.ndarray, cfg: EnvConfig) -> np.ndarray:
    """连续编码 [-1,1]^D 后半段 -> (n_infantry, K, 2) 步兵地面航点 (x, y)。"""
    x = np.asarray(x, dtype=float).ravel()
    n_drone_dims = cfg.n_drones * cfg.n_waypoints * 3
    xi = x[n_drone_dims:].reshape(cfg.n_infantry, cfg.n_waypoints, 2)
    return np.stack([0.5 * (xi[:, :, 0] + 1.0) * cfg.map_w,
                     0.5 * (xi[:, :, 1] + 1.0) * cfg.map_h], axis=-1)


def _decode_red_waypoints(red_x: np.ndarray, cfg: EnvConfig) -> np.ndarray:
    """连续编码 [-1,1]^D_red -> (n_interceptors, K_red, 2) 拦截者巡逻航点。"""
    red_x = np.asarray(red_x, dtype=float).reshape(cfg.n_interceptors,
                                                  cfg.n_int_waypoints, 2)
    return np.stack([0.5 * (red_x[:, :, 0] + 1.0) * cfg.map_w,
                     0.5 * (red_x[:, :, 1] + 1.0) * cfg.map_h], axis=-1)


class UAVEnv:
    """一次确定性对抗 rollout 的求值器。

    每个 ``UAVEnv`` 绑定一套 ``EnvConfig``（含对手/禁飞区布局，由 seed 生成，
    布局本身确定可复现）。``cost(x)`` 返回越小越好的成本；``trajectory(x)``
    额外返回逐步快照供 GUI 动画。
    """

    def __init__(self, cfg: EnvConfig, seed: int = 0, opponent=None,
                 layout: Optional[dict] = None):
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)
        self.seed = int(seed)          # 供布朗运动等确定性随机游走复现
        self.start = np.asarray(cfg.start_pos, dtype=float)
        self.interceptors0 = np.asarray(cfg.interceptor_pos, dtype=float).reshape(-1, 2)
        self.nofly = np.asarray(cfg.no_fly_zones, dtype=float).reshape(-1, 4)
        self.opponent = opponent
        self.red_x = None            # 协同演化时固定红方航点（None=追击规则/DRL）
        # 三维合成山地：贴地飞行、爬山能耗与 LOS 视线遮挡的物理基础
        self.terrain = None
        if cfg.terrain_enabled:
            self.terrain = _intercept_terrain(cfg.map_w, cfg.map_h,
                                              cfg.terrain_amplitude, seed)
        # 空地协同巷战：军事基地 = 无人机攻击点 + 步兵夺取点（统一目标）
        self.base = np.asarray(cfg.base_pos, dtype=float)
        self.base_hp_max = float(cfg.base_hp)

        # 起点与步兵出发位置：默认每架蓝方在左下方区域独立随机散开（合成问题
        # 用）；实景场景由 `layout` 给出战前确定的固定编队 —— 同一张地图上的
        # 多个任务只有任务目标不同，起飞点与出发位置不变。
        _lay = layout or {}
        _lay_starts = list(_lay.get('starts') or [])
        rng = np.random.default_rng(seed + 4242)
        self.starts: List[Tuple[float, float]] = []
        self.targets: List[Tuple[float, float]] = []
        for _i in range(cfg.n_drones):
            if _i < len(_lay_starts):
                self.starts.append((float(_lay_starts[_i][0]),
                                    float(_lay_starts[_i][1])))
            else:
                self.starts.append((float(rng.uniform(40.0, 300.0)),
                                    float(rng.uniform(40.0, 300.0))))
            self.targets.append((float(cfg.base_pos[0]), float(cfg.base_pos[1])))

        # 蓝方步兵团队起点：地图左下，围绕锚点 (200, 150) 的小偏移队形
        _lay_inf = list(_lay.get('infantry') or [])
        rng_i = np.random.default_rng(seed + 777001)
        self.infantry0: List[Tuple[float, float]] = []
        ax, ay = 200.0, 150.0
        for _i in range(cfg.n_infantry):
            if _i < len(_lay_inf):
                self.infantry0.append((float(_lay_inf[_i][0]),
                                       float(_lay_inf[_i][1])))
            else:
                self.infantry0.append((ax + float(rng_i.uniform(-22.0, 22.0)),
                                       ay + float(rng_i.uniform(-22.0, 22.0))))

        # 红方巡逻兵：默认随机分布在地图中央巷战区域（基地周边 + 步兵路径沿途）；
        # 实景场景可由 layout['patrol'] 给出若干「分区中心」，巡逻兵在各中心附近
        # 确定性散布（红方 F1 兵力部署课题的决策变量之一）。
        rng_p = np.random.default_rng(seed + 777002)
        _lay_patrol = list(_lay.get('patrol') or [])
        self.patrol0: List[Tuple[float, float]] = []
        for _i in range(cfg.n_patrol):
            if _lay_patrol:
                _ax, _ay = _lay_patrol[_i % len(_lay_patrol)]
                self.patrol0.append((float(_ax) + float(rng_p.uniform(-28.0, 28.0)),
                                     float(_ay) + float(rng_p.uniform(-28.0, 28.0))))
            else:
                self.patrol0.append((float(rng_p.uniform(380.0, 860.0)),
                                     float(rng_p.uniform(380.0, 860.0))))

        # 楼房（巷战掩体）：随机分布，避开基地/步兵/巡逻兵/无人机起点
        rng_b = np.random.default_rng(seed + 777003)
        self.buildings: List[Tuple[float, float, float, float]] = []
        bmin, bmax = cfg.building_min, cfg.building_max
        attempts = 0
        while len(self.buildings) < cfg.n_buildings and attempts < 2000:
            attempts += 1
            bx = float(rng_b.uniform(240.0, 840.0))
            by = float(rng_b.uniform(240.0, 840.0))
            bw = float(rng_b.uniform(bmin, bmax))
            bd = float(rng_b.uniform(bmin, bmax))
            if self._building_overlaps(bx, by, bw, bd):
                continue
            self.buildings.append((bx, by, bw, bd))

        # 地面无人车（防空车）初始位置：确定性部署，贴地（z = 地面 + 车体高度 0）
        self.aa0: List[Tuple[float, float, float]] = []
        for (ax, ay) in list(cfg.aa_pos)[:cfg.n_aa]:
            self.aa0.append((float(ax), float(ay), self._ground_h(ax, ay)))

    # ---- 三维高度 / 视线遮挡辅助 -----------------------------------------
    def _ground_h(self, x: float, y: float) -> float:
        if self.terrain is None:
            return 0.0
        return self.terrain.height(x, y)

    def _alt(self, x: float, y: float) -> float:
        """贴地飞行高度 = 地面高程 + 离地安全高度。"""
        return self._ground_h(x, y) + self.cfg.h_clearance

    def _los_blocked(self, ax, ay, az, bx, by, bz) -> bool:
        """拦截者与无人机之间是否被山体遮挡（LOS 不通视）。"""
        if not self.cfg.los_block or self.terrain is None:
            return False
        return terrain_blocked(self.terrain, (ax, ay, az), (bx, by, bz))

    # ---- 巷战：楼房掩体 / LOS 遮挡辅助 ---------------------------------
    def _building_overlaps(self, bx, by, bw, bd) -> bool:
        """检查楼房 (bx,by,bw,bd) 是否与基地/步兵/巡逻兵/无人机起点/已有楼房重叠。"""
        pad = 6.0
        half_w, half_d = bw / 2 + pad, bd / 2 + pad
        if (abs(bx - self.base[0]) < half_w + self.cfg.base_radius
                and abs(by - self.base[1]) < half_d + self.cfg.base_radius):
            return True
        for (ix, iy) in self.infantry0:
            if abs(bx - ix) < half_w + 18 and abs(by - iy) < half_d + 18:
                return True
        for (px, py) in self.patrol0:
            if abs(bx - px) < half_w + 16 and abs(by - py) < half_d + 16:
                return True
        for (sx, sy) in self.starts:
            if abs(bx - sx) < half_w + 24 and abs(by - sy) < half_d + 24:
                return True
        # 直升机停机坪：拦截机初始停靠点（interceptor_pos），楼房不得覆盖，否则直升机卡楼
        for (hx, hy) in self.interceptors0:
            if abs(bx - hx) < half_w + 32 and abs(by - hy) < half_d + 32:
                return True
        # 预警雷达站：固定设施，楼房不得覆盖
        rx, ry = float(self.cfg.radar_pos[0]), float(self.cfg.radar_pos[1])
        if abs(bx - rx) < half_w + 24 and abs(by - ry) < half_d + 24:
            return True
        for (ox, oy, ow, od) in self.buildings:
            if (abs(bx - ox) < (bw + ow) / 2 + 6
                    and abs(by - oy) < (bd + od) / 2 + 6):
                return True
        return False

    @staticmethod
    def _seg_rect_hit(ax, ay, bx, by, cx, cy, w, d) -> bool:
        """二维线段 (a,b) 是否与轴对齐矩形 [cx±w/2]×[cy±d/2] 相交（LOS 遮挡）。"""
        xmin, xmax = cx - w / 2, cx + w / 2
        ymin, ymax = cy - d / 2, cy + d / 2
        if max(ax, bx) < xmin or min(ax, bx) > xmax \
                or max(ay, by) < ymin or min(ay, by) > ymax:
            return False
        dx, dy = bx - ax, by - ay
        t0, t1 = 0.0, 1.0
        for p, q in ((-dx, ax - xmin), (dx, xmax - ax),
                     (-dy, ay - ymin), (dy, ymax - ay)):
            if p == 0.0:
                if q < 0.0:
                    return False
            else:
                t = q / p
                if p < 0.0:
                    t0 = max(t0, t)
                else:
                    t1 = min(t1, t)
                if t0 > t1:
                    return False
        return True

    def _ground_los_blocked(self, ax, ay, bx, by) -> bool:
        """地面单位之间是否被楼房遮挡（步兵↔巡逻兵视线）。"""
        for (cx, cy, w, d) in self.buildings:
            if self._seg_rect_hit(ax, ay, bx, by, cx, cy, w, d):
                return True
        return False

    def _in_building(self, x, y) -> bool:
        """点 (x,y) 是否落入某栋楼房矩形内（地面移动碰撞）。"""
        for (cx, cy, w, d) in self.buildings:
            if abs(x - cx) < w / 2 and abs(y - cy) < d / 2:
                return True
        return False

    def _infantry_cover_target(self, ix, iy, tx, ty):
        """返回步兵 (ix,iy) 躲避巡逻兵 (tx,ty) 的最近楼房掩体点；无楼房返回 None。"""
        best, bd = None, 1e18
        for (cx, cy, w, d) in self.buildings:
            dist = math.hypot(cx - ix, cy - iy)
            if dist < bd:
                bd = dist
                # 掩体点 = 楼房中心沿「远离巡逻兵」方向偏移到楼房外缘
                dx, dy = ix - tx, iy - ty
                ln = math.hypot(dx, dy) or 1.0
                ox = cx + (dx / ln) * (max(w, d) / 2 + 3.0)
                oy = cy + (dy / ln) * (max(w, d) / 2 + 3.0)
                best = (ox, oy)
        return best

    # ---- 核心：一次 rollout（record=False 只算成本，毫秒级） --------------
    @staticmethod
    def _turn_toward(heading, target, max_turn):
        """把航向 ``heading`` 以不超过 ``max_turn`` 的角速度转向 ``target``。

        返回转向后的航向（rad）。这是仿真的物理约束：飞行器不能瞬间改变
        航向（即不能直角转弯），只能以有限角速度平滑转向。
        """
        d = (target - heading + math.pi) % (2.0 * math.pi) - math.pi
        d = max(-max_turn, min(max_turn, d))
        return heading + d

    @staticmethod
    def _in_capture_cone(dx, dy, dz, heading, radius, half_angle, vert_half_angle):
        """目标相对偏移 (dx, dy, dz) 是否落在拦截者前方圆锥侦察范围内。

        拦截者机头朝向 ``heading``（rad，0=东，水平），侦察范围为三维圆锥：
        水平角 ≤ ``half_angle``、垂直角（仰角）≤ ``vert_half_angle``、三维距离
        ≤ ``radius`` 三者同时满足才可捕获（而非任意方向的球形碰撞或水平扇形）。
        """
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist > radius:
            return False
        ang = math.atan2(dy, dx)
        diff = abs((ang - heading + math.pi) % (2.0 * math.pi) - math.pi)
        if diff > half_angle:
            return False
        # 垂直角：目标相对拦截者机头（水平）的仰角，蓝方靠高度差可逃出圆锥
        hdist = math.hypot(dx, dy)
        if hdist > 1e-9 and abs(math.atan2(dz, hdist)) > vert_half_angle:
            return False
        return True

    @staticmethod
    def _seg3d_hit(ax, ay, az, bx, by, bz, px, py, pz, r):
        """三维线段 (a,b) 到点 p 的最短距离是否 ≤ r（导弹路径穿越命中判定）。"""
        vx, vy, vz = bx - ax, by - ay, bz - az
        l2 = vx * vx + vy * vy + vz * vz
        t = 0.0 if l2 < 1e-12 else max(
            0.0, min(1.0, ((px - ax) * vx + (py - ay) * vy + (pz - az) * vz) / l2))
        qx, qy, qz = ax + t * vx, ay + t * vy, az + t * vz
        return (px - qx) ** 2 + (py - qy) ** 2 + (pz - qz) ** 2 <= r * r

    def _rollout(self, x, record: bool = False, red_x=None):
        cfg = self.cfg
        x = np.asarray(x, dtype=float).ravel()
        n, K = cfg.n_drones, cfg.n_waypoints
        map_w, map_h = cfg.map_w, cfg.map_h
        # 巡逻兵布朗运动确定性随机源：每次 rollout 从同一 seed 出发，保证成本可复现
        rng_walk = np.random.default_rng(self.seed + 20261009)
        tr = cfg.target_radius
        dspeed = cfg.drone_speed
        dturn = cfg.drone_turn_rate
        wp_reach = cfg.wp_reach_radius
        ispeed = cfg.interceptor_speed
        iturn = cfg.interceptor_turn_rate
        irad = cfg.intercept_radius
        ihalf = cfg.intercept_half_angle   # 前方圆锥水平半角
        vhalf = cfg.intercept_vert_half_angle  # 前方圆锥垂直半角
        crad = cfg.collision_radius
        nsteps = cfg.n_steps
        max_alt = cfg.max_alt
        max_alt_offset = cfg.max_alt_offset
        la_steps = cfg.lookahead_steps
        la_dist = dspeed * la_steps        # 前瞻距离（沿航向前方地形高度）
        climb_rate = cfg.max_climb_rate
        h_clear = cfg.h_clearance
        e_cap = cfg.energy_capacity
        e_step = cfg.energy_per_step
        e_climb = cfg.climb_energy

        # 地面无人车（防空车）仿真参数
        aa_speed = cfg.aa_speed
        aa_turn = cfg.aa_turn
        aa_range = cfg.aa_range
        aa_vhalf = cfg.aa_vert_half_angle
        aa_reload = cfg.aa_reload
        aa_max_msl = cfg.aa_max_missiles
        mspd = cfg.missile_speed
        mturn = cfg.missile_turn
        mclimb = cfg.missile_climb
        mrad = cfg.missile_radius
        mfuel = cfg.missile_fuel

        # 空地协同巷战：步兵 / 巡逻兵 / 军事基地
        n_inf = cfg.n_infantry
        ispeed_inf = cfg.infantry_speed
        idmg_inf = cfg.infantry_damage
        irng_inf = cfg.infantry_range
        inf_cd = max(1, int(round(cfg.infantry_fire_cd / max(cfg.dt, 1e-6))))
        n_pat = cfg.n_patrol
        pspeed = cfg.patrol_speed
        pdmg = cfg.patrol_damage
        prng = cfg.patrol_range
        vrange = cfg.patrol_vision_range
        pat_cd = max(1, int(round(cfg.patrol_fire_cd / max(cfg.dt, 1e-6))))
        base_r = cfg.base_radius
        bomb_dmg = cfg.bomb_damage
        base_hp_max = self.base_hp_max
        n_drone_dims = n * K * 3

        # 每架蓝方独立起/终点（全图散开），3D 航点：起点 -> K 个 (x,y,z) -> 目标
        routes = []
        for i in range(n):
            sx, sy = self.starts[i]
            tx, ty = self.targets[i]
            base = i * K * 3
            pts = [(sx, sy, self._alt(sx, sy), 0.0)]
            for k in range(K):
                px = 0.5 * (x[base + 3 * k] + 1.0) * map_w
                py = 0.5 * (x[base + 3 * k + 1] + 1.0) * map_h
                # z 编码为相对贴地高度的爬升偏移 [0, max_alt_offset]，
                # 航点高度 = 贴地 + 偏移（≤ max_alt）；偏移在相邻航点间线性插值，
                # 使飞机高度连续平滑过渡（不直线拉升、不卡位）。
                z_off = 0.5 * (x[base + 3 * k + 2] + 1.0) * max_alt_offset
                pz = min(self._alt(px, py) + z_off, max_alt)
                pts.append((px, py, pz, z_off))
            # 终点即目标区：贴地高度（地面 + 离地安全），偏移回 0，与起点一致；
            # 到达判定仅查水平距离，终点不应诱导蓝方爬到 max_alt 高空空耗能源。
            pts.append((tx, ty, self._alt(tx, ty), 0.0))
            routes.append(pts)

        # 蓝方步兵航点：起点 -> K 个二维航点 (x,y) -> 军事基地（夺取点）
        inf_routes = []
        for i in range(n_inf):
            sx, sy = self.infantry0[i]
            base = n_drone_dims + i * K * 2
            pts = [(sx, sy)]
            for k in range(K):
                px = 0.5 * (x[base + 2 * k] + 1.0) * map_w
                py = 0.5 * (x[base + 2 * k + 1] + 1.0) * map_h
                pts.append((px, py))
            pts.append((float(self.base[0]), float(self.base[1])))
            inf_routes.append(pts)

        # 直升机（拦截机）初始停靠在停机坪地面（贴地），雷达捕获后才会起飞
        ipos = [(float(p[0]), float(p[1]),
                 self._ground_h(float(p[0]), float(p[1]))) for p in self.interceptors0]
        n_int = len(ipos)
        # 球形禁飞区 (cx, cy, cz, r)
        nofly = ([(float(nf[0]), float(nf[1]), float(nf[2]), float(nf[3]))
                  for nf in self.nofly] if self.nofly.size else [])

        # 红方航点（协同演化）：拦截者沿自身航点闭环巡逻，而非追击
        red_routes = None
        rnext = None
        if red_x is not None:
            red_x = np.asarray(red_x, dtype=float).ravel()
            red_routes = []
            for k in range(n_int):
                base = k * cfg.n_int_waypoints * 2
                pts = [(ipos[k][0], ipos[k][1])]
                for j in range(cfg.n_int_waypoints):
                    rx = 0.5 * (red_x[base + 2 * j] + 1.0) * map_w
                    ry = 0.5 * (red_x[base + 2 * j + 1] + 1.0) * map_h
                    pts.append((rx, ry))
                pts.append((ipos[k][0], ipos[k][1]))  # 闭环回到起点
                red_routes.append(pts)
            rnext = [1] * n_int

        dpos = [(self.starts[i][0], self.starts[i][1],
                 self._alt(self.starts[i][0], self.starts[i][1])) for i in range(n)]
        dhead = [math.atan2(routes[i][1][1] - dpos[i][1],
                            routes[i][1][0] - dpos[i][0]) for i in range(n)]
        dnext = [1] * n                # 下一路点索引（0=起点，末尾=目标区）
        state = [0] * n                # 0 飞行 1 到达 2 被击落 3 坠毁
        energy = [float(e_cap)] * n    # 每架剩余能源

        # 拦截者初始朝向：指向首个目标方向（拦截范围朝前，覆盖无人机前进路线）
        ihead = [math.atan2(self.targets[0][1] - p[1],
                            self.targets[0][0] - p[0]) for p in ipos]

        # 直升机（拦截机）状态机：0 停靠待命 1 起飞加速 2 巡航拦截 3 返航 4 降落减速
        int_phase = [0] * n_int
        int_speed = [0.0] * n_int
        home_pos = [(ipos[k][0], ipos[k][1]) for k in range(n_int)]   # 停机坪 H（水平）
        home_gz = [ipos[k][2] for k in range(n_int)]                  # 停机坪地面高程
        radar_xy = (float(cfg.radar_pos[0]), float(cfg.radar_pos[1]))
        radar_r = float(cfg.radar_range)
        int_accel = float(cfg.interceptor_accel)
        # 预警参数（红方 F2 课题）：默认 radar_half = pi（全向）、scan = 1（逐帧）、
        # alert = 1（单目标即出动），与改动前的「全向雷达 + 即捕即出动」逐位等价。
        radar_az = float(getattr(cfg, 'radar_azimuth', 0.0))
        radar_half = float(getattr(cfg, 'radar_half_angle', math.pi))
        radar_alert = max(1, int(getattr(cfg, 'alert_threshold', 1)))
        radar_scan = max(1, int(getattr(cfg, 'scan_period', 1)))
        radar_locked = False             # 告警锁存：扫描周期内沿用上次扫描结果
        _hits = 0                        # 雷达捕获计数（锁存；首扫到来前的初值）

        # 地面无人车（防空车）状态：贴地机动，遇存活蓝方进入对空攻击范围后发射导弹
        aapos = [(self.aa0[a][0], self.aa0[a][1], self.aa0[a][2])
                 for a in range(len(self.aa0))]
        aah = [math.atan2(self.targets[0][1] - p[1],
                          self.targets[0][0] - p[0]) for p in aapos]
        aa_reload_t = [0.0] * len(aapos)     # 距离下次可发射的剩余步数
        aa_missiles = [[] for _ in aapos]    # 每车在场导弹：[[x,y,z,target_i,head,fuel,id], ...]
        msl_seq = 0                          # 导弹稳定 ID（前端按 ID 匹配，避免列表压缩错位）

        # —— 协同调度（红方 F3 拦截 / F4 协同）：责任区划分 + 主责目标分配 ——
        # 单元编号约定：地面防空车 0..n_aa-1，直升机 n_aa..n_aa+n_int-1。
        # sector_bounds / assign_target 均为 None 时 _unit_may_engage 恒为 True，
        # 完全退化为原来的「各单元独立贪心选最近目标」。
        aa_assign = list(getattr(cfg, 'assign_target', None) or [])
        sector_b = sorted(float(b) for b in
                          (getattr(cfg, 'sector_bounds', None) or []))
        launch_thr = list(getattr(cfg, 'launch_threshold', None) or [])
        n_aa_units = len(aapos)
        _base_x = float(cfg.base_pos[0])
        _base_y = float(cfg.base_pos[1])

        def _sector_of(px, py):
            """目标相对基地的方位角落入第几段责任区；未分区时返回 -1。"""
            if not sector_b:
                return -1
            ang = math.atan2(py - _base_y, px - _base_x)
            lo, hi = 0, len(sector_b)          # bisect_right：边界升序 -> 段索引
            while lo < hi:
                mid = (lo + hi) // 2
                if ang >= sector_b[mid]:
                    lo = mid + 1
                else:
                    hi = mid
            return lo

        def _unit_may_engage(unit, i):
            """单元 unit 是否被允许交战目标 i（责任区 + 主责分配双重门限）。"""
            if sector_b and _sector_of(dpos[i][0], dpos[i][1]) != unit:
                return False
            if unit < len(aa_assign):
                want = aa_assign[unit]
                if 0 <= want != i and want < n and state[want] == 0:
                    return False               # 主责目标仍存活 -> 专注它，不抢别人的
            return True

        # 蓝方步兵状态：0 行进 1 抵达基地 2 阵亡
        ipos_inf = [(float(self.infantry0[i][0]), float(self.infantry0[i][1]))
                    for i in range(n_inf)]
        ihead_inf = [math.atan2(inf_routes[i][1][1] - ipos_inf[i][1],
                                inf_routes[i][1][0] - ipos_inf[i][0])
                     for i in range(n_inf)]
        inext = [1] * n_inf
        istate = [0] * n_inf
        ihp = [float(cfg.infantry_hp)] * n_inf
        inf_cd_t = [0] * n_inf

        # 红方巡逻兵状态：0 存活 1 阵亡（布朗运动随机游走，phead 为当前航向）
        ppos = [(float(self.patrol0[j][0]), float(self.patrol0[j][1]))
                for j in range(n_pat)]
        pstate = [0] * n_pat
        php_v = [float(cfg.patrol_hp)] * n_pat
        pat_cd_t = [0] * n_pat
        phead = [float(rng_walk.uniform(0.0, 2.0 * math.pi)) for j in range(n_pat)]

        # 军事基地血量（无人机投弹 + 步兵攻击共同削减，0 = 目标被摧毁）
        base_hp = base_hp_max

        nofly_steps = 0.0
        bounds_steps = 0.0
        collisions = 0.0
        path_len = [0.0] * n          # 每架实际飞行距离（米）
        flight_t = [0] * n            # 每架飞行步数（到终态）
        climb_total = [0.0] * n       # 每架累计爬升米数（三维爬山能耗）
        turn_total = [0.0] * n        # 每架累计航向变化（轨迹曲率，rad）
        min_dist = 1e18               # 与拦截者最小距离（安全裕度）
        first_capture = -1.0          # 首次被拦截发生的时刻（步），-1 表示未被拦截
        risk_time = 0.0               # 处于拦截者捕获半径内的累计暴露时间（步）

        frames: List[Dict] = []
        if record:
            frames.append(self._snapshot(
                0, dpos, state, ipos, dhead, ihead,
                aa_states=[[aapos[a][0], aapos[a][1], aapos[a][2], aah[a]]
                           for a in range(len(aapos))],
                aa_msl=aa_missiles,
                infantry_pos=ipos_inf, infantry_state=istate, infantry_hp=ihp,
                patrol_pos=ppos, patrol_state=pstate, patrol_hp=php_v,
                patrol_alert=[0] * n_pat,
                inter_phase=int_phase, inter_speed=int_speed,
                base_hp=base_hp, base_hp_max=base_hp_max))

        for _step in range(1, nsteps + 1):
            events: List[Dict] = []      # 本步被拦截事件
            # 1) 蓝方：有限角速度转向当前路点，水平前进 + 垂直爬升/下降（有限速率）
            for i in range(n):
                if state[i] != 0:
                    continue
                tgt = routes[i][dnext[i]]
                prev_pt = routes[i][dnext[i] - 1]
                is_final = dnext[i] == len(routes[i]) - 1
                reach = base_r if is_final else wp_reach   # 终点即军事基地（攻击点）
                th = math.atan2(tgt[1] - dpos[i][1], tgt[0] - dpos[i][0])
                old_head = dhead[i]
                dhead[i] = self._turn_toward(dhead[i], th, dturn)
                turn_total[i] += abs((dhead[i] - old_head + math.pi) % (2.0 * math.pi) - math.pi)
                nx = dpos[i][0] + dspeed * math.cos(dhead[i])
                ny = dpos[i][1] + dspeed * math.sin(dhead[i])
                # 垂直：贴地平滑爬升——航段内爬升偏移线性插值（高度连续过渡，不直线
                # 拉升）+ 前瞻前方地形提前爬升 + 地面下限硬约束（绝不穿山）
                seg_len = math.hypot(tgt[0] - prev_pt[0], tgt[1] - prev_pt[1])
                d_to_end = math.hypot(nx - tgt[0], ny - tgt[1])
                t_seg = (max(0.0, min(1.0, 1.0 - d_to_end / seg_len))
                         if seg_len > 1e-6 else 0.0)
                off_t = prev_pt[3] + (tgt[3] - prev_pt[3]) * t_seg
                ground = self._ground_h(nx, ny)
                la_x = nx + la_dist * math.cos(dhead[i])
                la_y = ny + la_dist * math.sin(dhead[i])
                la_ground = self._ground_h(la_x, la_y)
                floor = max(ground, la_ground) + h_clear   # 前瞻贴地下限
                # 目标高度 = 贴地 + 插值偏移，且不低于贴地下限、不超上限
                desired = min(max(ground + h_clear + off_t, floor), max_alt)
                dz = max(-climb_rate, min(climb_rate, desired - dpos[i][2]))
                nz = dpos[i][2] + dz
                # 硬约束：绝不低于当前落点地形安全高度（不穿山），也不超过上限
                nz = max(nz, ground + h_clear)
                nz = min(nz, max_alt)
                climb = max(0.0, nz - dpos[i][2])
                climb_total[i] += climb
                # 能源：水平飞行 + 爬升额外，耗尽即坠毁
                energy[i] -= e_step + e_climb * climb
                if energy[i] <= 0.0:
                    energy[i] = 0.0
                    state[i] = 3
                    events.append({'t': 'crash', 'd': i, 'x': nx, 'y': ny,
                                   'z': nz, 's': -1})
                dpos[i] = (nx, ny, nz)
                path_len[i] += dspeed
                flight_t[i] = _step
                if state[i] == 0 and math.hypot(dpos[i][0] - tgt[0],
                                                dpos[i][1] - tgt[1]) <= reach:
                    if is_final:
                        state[i] = 1
                    else:
                        dnext[i] += 1

            # 2) 红方（直升机拦截机）状态机：停靠待命 → 雷达捕获起飞 → 巡航拦截 → 返航 → 降落。
            #    起飞/降落均带加减速仿真（速度 0→巡航线性加速，巡航→0 线性减速，随速度线性升降）。
            all_done = all(s != 0 for s in state)
            # 雷达捕获：任一存活无人机进入雷达站探测范围，触发停靠直升机出动。
            # F2 预警课题在此基础上叠加三项（默认关闭）：扫描周期锁存、定向扇区、
            # 「需同时出现 N 个目标才出动」的告警阈值。
            if _step % radar_scan == 0:
                _hits = 0
                for i in range(n):
                    if state[i] != 0:
                        continue
                    _dx = dpos[i][0] - radar_xy[0]
                    _dy = dpos[i][1] - radar_xy[1]
                    if math.hypot(_dx, _dy) > radar_r:
                        continue
                    if radar_half < math.pi:          # 定向扇区：主瓣方位角门限
                        _da = abs(math.atan2(_dy, _dx) - radar_az)
                        if min(_da, 2.0 * math.pi - _da) > radar_half:
                            continue
                    _hits += 1
                radar_locked = radar_r > 0.0 and _hits >= radar_alert
            # DRL 策略（L4/L5/L6）一次性输出各直升机目标方位角
            drl_targets = None
            if self.opponent is not None and red_routes is None:
                try:
                    drl_targets = self.opponent.act(ipos, ihead, dpos, state, cfg)
                except Exception:
                    drl_targets = None

            for k in range(n_int):
                ph = int_phase[k]
                hx, hy = home_pos[k]
                gz = home_gz[k]
                cz = self._alt(hx, hy)            # 巡航高度（停机坪上方贴地高度）

                if ph == 0:                       # 停靠待命：静止在停机坪，雷达捕获则起飞
                    int_speed[k] = 0.0
                    ipos[k] = (hx, hy, gz)
                    # 逐机出动阈值（F3/F4）：该机可自定义门限，缺省沿用全局锁存结果
                    if k < len(launch_thr):
                        _go = radar_r > 0.0 and _hits >= max(1, int(launch_thr[k]))
                    else:
                        _go = radar_locked
                    # L0「无对手」红方全程不动：不起飞、不拦截（与击落判定保持一致）
                    if _go and getattr(self.opponent, 'active', True):
                        int_phase[k] = 1
                    continue
                if ph == 1:                       # 起飞：垂直加速升空（速度 0→巡航）
                    int_speed[k] = min(ispeed, int_speed[k] + int_accel)
                    ipos[k] = (hx, hy, gz + (cz - gz) * (int_speed[k] / ispeed))
                    if int_speed[k] >= ispeed:
                        int_speed[k] = ispeed
                        int_phase[k] = 2
                    continue
                if ph == 4:                       # 降落：垂直减速下降（速度 巡航→0）
                    int_speed[k] = max(0.0, int_speed[k] - int_accel)
                    ipos[k] = (hx, hy, gz + (cz - gz) * (int_speed[k] / ispeed))
                    if int_speed[k] <= 0.0:
                        int_speed[k] = 0.0
                        int_phase[k] = 0
                    continue

                # ph == 2（巡航拦截）或 ph == 3（返航）：转向 + 水平移动
                bi = -1
                if ph == 3:
                    th = math.atan2(hy - ipos[k][1], hx - ipos[k][0])
                elif drl_targets is not None:
                    th = drl_targets[k] if (k < len(drl_targets) and drl_targets[k] is not None) else ihead[k]
                else:
                    bi, bd = -1, 1e18
                    for i in range(n):            # 圆锥侦察范围内最近的存活蓝方
                        if state[i] != 0:
                            continue
                        if not _unit_may_engage(n_aa_units + k, i):
                            continue              # 责任区/主责分配之外的目标不交战
                        dx = dpos[i][0] - ipos[k][0]
                        dy = dpos[i][1] - ipos[k][1]
                        dz = dpos[i][2] - ipos[k][2]
                        if self._in_capture_cone(dx, dy, dz, ihead[k], irad, ihalf, vhalf):
                            d = math.sqrt(dx * dx + dy * dy + dz * dz)
                            if d < bd:
                                bi, bd = i, d
                    if bi >= 0:
                        th = math.atan2(dpos[bi][1] - ipos[k][1],
                                        dpos[bi][0] - ipos[k][0])
                    elif red_routes is not None:
                        tgt = red_routes[k][rnext[k]]
                        th = math.atan2(tgt[1] - ipos[k][1], tgt[0] - ipos[k][0])
                    else:
                        bj, bd = -1, 1e18
                        for i in range(n):
                            if state[i] != 0:
                                continue
                            if not _unit_may_engage(n_aa_units + k, i):
                                continue          # 责任区/主责分配之外的目标不追击
                            d = math.hypot(dpos[i][0] - ipos[k][0],
                                           dpos[i][1] - ipos[k][1])
                            if d < bd:
                                bd, bj = d, i
                        if bj < 0:
                            th = ihead[k]
                        else:
                            th = math.atan2(dpos[bj][1] - ipos[k][1],
                                            dpos[bj][0] - ipos[k][0])

                ihead[k] = self._turn_toward(ihead[k], th, iturn)
                spd = int_speed[k] if int_speed[k] > 0.0 else ispeed
                nix = ipos[k][0] + spd * math.cos(ihead[k])
                niy = ipos[k][1] + spd * math.sin(ihead[k])
                ipos[k] = (nix, niy, self._alt(nix, niy))

                # 仅在巡航巡逻时推进航点索引
                if ph == 2 and bi < 0 and red_routes is not None:
                    if math.hypot(ipos[k][0] - red_routes[k][rnext[k]][0],
                                  ipos[k][1] - red_routes[k][rnext[k]][1]) <= wp_reach:
                        rnext[k] += 1
                        if rnext[k] >= len(red_routes[k]):
                            rnext[k] = 1

                # 状态迁移：巡航任务完成（无存活目标）→ 返航；返航到达停机坪上方 → 降落
                if ph == 2 and all_done:
                    int_phase[k] = 3
                    int_speed[k] = ispeed
                elif ph == 3 and math.hypot(ipos[k][0] - hx, ipos[k][1] - hy) <= wp_reach:
                    int_phase[k] = 4
                    int_speed[k] = ispeed

            # 3) 击落：前方圆锥侦察范围（水平角 ±ihalf、垂直角 ±vhalf、三维距离 <= irad，LOS 通畅）
            #    蓝方爬升增大垂直角 / 三维距离即可逃出圆锥追捕。
            if getattr(self.opponent, 'active', True) or red_routes is not None:
                for i in range(n):
                    if state[i] != 0:
                        continue
                    for k in range(n_int):
                        if int_phase[k] != 2:   # 仅巡航拦截时击落（停靠/起降/返航不击落）
                            continue
                        dx = dpos[i][0] - ipos[k][0]
                        dy = dpos[i][1] - ipos[k][1]
                        dz = dpos[i][2] - ipos[k][2]
                        if self._in_capture_cone(dx, dy, dz, ihead[k], irad, ihalf, vhalf):
                            if not self._los_blocked(dpos[i][0], dpos[i][1], dpos[i][2],
                                                     ipos[k][0], ipos[k][1], ipos[k][2]):
                                state[i] = 2
                                events.append({'t': 'intercept', 'd': i,
                                               'x': dpos[i][0], 'y': dpos[i][1],
                                               'z': dpos[i][2], 's': k})
                                if first_capture < 0:
                                    first_capture = float(_step)
                                break

            # 3.5) 地面无人车（防空车）：贴地机动 + 发射防空导弹 + 导弹追踪命中
            for a in range(len(aapos)):
                if aa_reload_t[a] > 0.0:
                    aa_reload_t[a] -= 1.0
                # 选目标：攻击范围内的存活蓝方（水平距离 + 对空垂直角均满足）
                bi, bd = -1, 1e18
                for i in range(n):
                    if state[i] != 0:
                        continue
                    if not _unit_may_engage(a, i):
                        continue              # 责任区/主责分配之外的目标不交战
                    dx = dpos[i][0] - aapos[a][0]
                    dy = dpos[i][1] - aapos[a][1]
                    dz = dpos[i][2] - aapos[a][2]
                    hd = math.hypot(dx, dy)
                    if hd > aa_range:
                        continue
                    if hd > 1e-6 and abs(math.atan2(dz, hd)) > aa_vhalf:
                        continue
                    if hd < bd:
                        bi, bd = i, hd
                if bi >= 0:
                    # 贴地机动追踪目标（z = 地面，无离地高度）
                    th = math.atan2(dpos[bi][1] - aapos[a][1],
                                    dpos[bi][0] - aapos[a][0])
                    aah[a] = self._turn_toward(aah[a], th, aa_turn)
                    nax = aapos[a][0] + aa_speed * math.cos(aah[a])
                    nay = aapos[a][1] + aa_speed * math.sin(aah[a])
                    aapos[a] = (nax, nay, self._ground_h(nax, nay))
                    # 发射新导弹：冷却就绪 + 未超上限 + 一对一（同目标只追一枚）+ LOS 通视
                    if (aa_reload_t[a] <= 0.0
                            and len(aa_missiles[a]) < aa_max_msl
                            and not any(m[3] == bi for m in aa_missiles[a])):
                        if not self._los_blocked(dpos[bi][0], dpos[bi][1],
                                                 dpos[bi][2],
                                                 aapos[a][0], aapos[a][1],
                                                 aapos[a][2]):
                            aa_missiles[a].append(
                                [aapos[a][0], aapos[a][1], aapos[a][2] + 2.0,
                                 bi, th, mfuel, msl_seq])
                            msl_seq += 1
                            aa_reload_t[a] = aa_reload
                # 导弹飞行与命中
                still = []
                for m in aa_missiles[a]:
                    ti = m[3]
                    if state[ti] != 0:
                        continue            # 目标已终态，导弹失的
                    m[5] -= 1
                    if m[5] <= 0:
                        continue            # 燃料耗尽 → 导弹失的（自毁）
                    mh = math.atan2(dpos[ti][1] - m[1], dpos[ti][0] - m[0])
                    m[4] = self._turn_toward(m[4], mh, mturn)
                    nx = m[0] + mspd * math.cos(m[4])
                    ny = m[1] + mspd * math.sin(m[4])
                    nz = m[2] + max(-mclimb, min(mclimb, dpos[ti][2] - m[2]))
                    nz = max(nz, self._ground_h(nx, ny))
                    if self._seg3d_hit(m[0], m[1], m[2], nx, ny, nz,
                                       dpos[ti][0], dpos[ti][1], dpos[ti][2],
                                       mrad):
                        state[ti] = 2
                        events.append({'t': 'missile', 'd': ti,
                                       'x': dpos[ti][0], 'y': dpos[ti][1],
                                       'z': dpos[ti][2], 's': a})
                        if first_capture < 0:
                            first_capture = float(_step)
                        continue            # 命中即消失
                    still.append([nx, ny, nz, ti, m[4], m[5], m[6]])
                aa_missiles[a] = still

            # 3.6) 空地协同巷战：步兵推进 + 抵达目标点后攻击基地 + 步兵↔巡逻兵交火 + 掩体躲避
            for i in range(n_inf):
                if istate[i] == 2:      # 阵亡，跳过
                    continue
                if inf_cd_t[i] > 0:
                    inf_cd_t[i] -= 1
                ix, iy = ipos_inf[i]
                # 已抵达目标点（state=1）：持续攻击基地，直到目标血量归零
                if istate[i] == 1:
                    if base_hp > 0.0 and inf_cd_t[i] <= 0:
                        base_hp = max(0.0, base_hp - idmg_inf)
                        inf_cd_t[i] = inf_cd
                    continue
                # 抵达基地判定：进入目标点即开始攻击基地
                if math.hypot(ix - self.base[0], iy - self.base[1]) <= base_r:
                    istate[i] = 1
                    if base_hp > 0.0 and inf_cd_t[i] <= 0:
                        base_hp = max(0.0, base_hp - idmg_inf)
                        inf_cd_t[i] = inf_cd
                    continue
                # 威胁：攻击范围内且 LOS 通畅的最近存活巡逻兵（可互射）
                tj, td = -1, 1e18
                for j in range(n_pat):
                    if pstate[j] != 0:
                        continue
                    d = math.hypot(ppos[j][0] - ix, ppos[j][1] - iy)
                    if d <= irng_inf and not self._ground_los_blocked(
                            ix, iy, ppos[j][0], ppos[j][1]):
                        if d < td:
                            tj, td = j, d
                if tj >= 0:
                    if inf_cd_t[i] <= 0:
                        # 反击射击（站定开火，削减巡逻兵血量）
                        php_v[tj] -= idmg_inf
                        inf_cd_t[i] = inf_cd
                        if php_v[tj] <= 0.0:
                            pstate[tj] = 1
                    else:
                        # 冷却间隙：朝最近楼房掩体躲避
                        cover = self._infantry_cover_target(
                            ix, iy, ppos[tj][0], ppos[tj][1])
                        if cover is not None:
                            cth = math.atan2(cover[1] - iy, cover[0] - ix)
                            ihead_inf[i] = self._turn_toward(ihead_inf[i], cth, 0.5)
                            nx = ix + ispeed_inf * math.cos(ihead_inf[i])
                            ny = iy + ispeed_inf * math.sin(ihead_inf[i])
                            if not self._in_building(nx, ny):
                                ipos_inf[i] = (nx, ny)
                else:
                    # 安全：朝下一航点前进
                    tgt = inf_routes[i][inext[i]]
                    th = math.atan2(tgt[1] - iy, tgt[0] - ix)
                    ihead_inf[i] = self._turn_toward(ihead_inf[i], th, 0.5)
                    nx = ix + ispeed_inf * math.cos(ihead_inf[i])
                    ny = iy + ispeed_inf * math.sin(ihead_inf[i])
                    if not self._in_building(nx, ny):
                        ipos_inf[i] = (nx, ny)
                    if math.hypot(ipos_inf[i][0] - tgt[0],
                                  ipos_inf[i][1] - tgt[1]) <= wp_reach:
                        inext[i] = min(inext[i] + 1, len(inf_routes[i]) - 1)

            # 3.7) 巡逻兵：布朗运动 + 可视范围发现敌方 + 攻击范围开火（攻击时不能移动）+ 协同追捕
            # 每步固定为全部巡逻兵预生成随机转向，使随机数消费只依赖步数、与状态无关（保证确定性）
            walk_dth = [float(rng_walk.normal(0.0, 0.8)) for _ in range(n_pat)]
            # 协同警报：任一存活巡逻兵在「可视范围」内看到步兵（LOS 通畅）即全局通报，
            # 其余未交战的巡逻兵会朝该步兵当前位置赶来追捕（取最近可见步兵为目标）。
            # 可视范围 > 攻击范围：先发现并通报，再靠近到攻击范围开火。
            alert_inf, alert_d = -1, 1e18
            pat_alert = [0] * n_pat    # 每个巡逻兵是否在可视范围内发现步兵（供前端头顶警示标志）
            for i in range(n_inf):
                if istate[i] != 0:
                    continue
                for j in range(n_pat):
                    if pstate[j] != 0:
                        continue
                    d = math.hypot(ipos_inf[i][0] - ppos[j][0],
                                   ipos_inf[i][1] - ppos[j][1])
                    if d <= vrange and not self._ground_los_blocked(
                            ppos[j][0], ppos[j][1], ipos_inf[i][0], ipos_inf[i][1]):
                        pat_alert[j] = 1
                        if d < alert_d:
                            alert_inf, alert_d = i, d
            for j in range(n_pat):
                if pstate[j] != 0:
                    continue
                if pat_cd_t[j] > 0:
                    pat_cd_t[j] -= 1
                px, py = ppos[j]
                ti, td = -1, 1e18
                for i in range(n_inf):
                    if istate[i] != 0:
                        continue
                    d = math.hypot(ipos_inf[i][0] - px, ipos_inf[i][1] - py)
                    if d <= prng and not self._ground_los_blocked(
                            px, py, ipos_inf[i][0], ipos_inf[i][1]):
                        if d < td:
                            ti, td = i, d
                if ti >= 0:
                    if pat_cd_t[j] <= 0:
                        # 射击（攻击时不能移动，原地开火）
                        ihp[ti] -= pdmg
                        pat_cd_t[j] = pat_cd
                        if ihp[ti] <= 0.0:
                            istate[ti] = 2
                    # 攻击/冷却期间不移动
                elif alert_inf >= 0:
                    # 协同追捕：朝被发现的步兵当前位置机动（实时跟踪，随步兵移动而更新）
                    # 发现后加速逼近，速度提升到与蓝方步兵正常速度一致
                    tx, ty = ipos_inf[alert_inf]
                    phead[j] = self._turn_toward(
                        phead[j], math.atan2(ty - py, tx - px), 0.6)
                    nx = px + ispeed_inf * math.cos(phead[j])
                    ny = py + ispeed_inf * math.sin(phead[j])
                    if nx < 80.0 or nx > map_w - 80.0:
                        nx = px
                    if ny < 80.0 or ny > map_h - 80.0:
                        ny = py
                    if self._in_building(nx, ny):
                        phead[j] += math.pi * 0.5      # 撞楼侧向避让
                    else:
                        ppos[j] = (nx, ny)
                else:
                    # 布朗运动（无规则随机游走）：航向高斯扰动 + 地图边界/楼房反弹
                    phead[j] += walk_dth[j]
                    nx = px + pspeed * math.cos(phead[j])
                    ny = py + pspeed * math.sin(phead[j])
                    if nx < 80.0 or nx > map_w - 80.0:
                        phead[j] = math.pi - phead[j]   # 水平边界反弹
                        nx = px
                    if ny < 80.0 or ny > map_h - 80.0:
                        phead[j] = -phead[j]            # 垂直边界反弹
                        ny = py
                    if self._in_building(nx, ny):
                        phead[j] += math.pi              # 撞楼掉头
                    else:
                        ppos[j] = (nx, ny)

            # 3.8) 无人机轰炸基地：抵达基地（state=1）的无人机投弹一次后自毁（不持续攻击）
            for i in range(n):
                if state[i] == 1:
                    if base_hp > 0.0:
                        base_hp = max(0.0, base_hp - bomb_dmg)
                    state[i] = 4            # 投弹完成，自毁（终态，前端不再渲染）
                    events.append({'t': 'bomb', 'd': i,
                                   'x': dpos[i][0], 'y': dpos[i][1],
                                   'z': dpos[i][2], 's': -1})

            # 4) 球形禁飞区 / 越界
            for i in range(n):
                if state[i] != 0:
                    continue
                px, py, pz = dpos[i][0], dpos[i][1], dpos[i][2]
                for (cx, cy, cz, r) in nofly:
                    if math.sqrt((px - cx) ** 2 + (py - cy) ** 2
                                 + (pz - cz) ** 2) <= r:
                        nofly_steps += 1.0
                        break
                if px < 0.0 or px > map_w or py < 0.0 or py > map_h:
                    bounds_steps += 1.0

            # 5) 机间碰撞
            for a in range(n):
                for b in range(a + 1, n):
                    if state[a] == 0 and state[b] == 0:
                        if math.hypot(dpos[a][0] - dpos[b][0],
                                      dpos[a][1] - dpos[b][1]) <= crad:
                            collisions += 1.0

            # 6) 安全裕度：存活无人机与拦截者的最小距离
            for i in range(n):
                if state[i] != 0:
                    continue
                for k in range(n_int):
                    dx = dpos[i][0] - ipos[k][0]
                    dy = dpos[i][1] - ipos[k][1]
                    dz = dpos[i][2] - ipos[k][2]
                    d = math.sqrt(dx * dx + dy * dy + dz * dz)
                    if d < min_dist:
                        min_dist = d
                    if d < irad:
                        risk_time += 1.0
                        break

            if record:
                frames.append(self._snapshot(
                    _step, dpos, state, ipos, dhead, ihead, events=events,
                    aa_states=[[aapos[a][0], aapos[a][1], aapos[a][2], aah[a]]
                               for a in range(len(aapos))],
                    aa_msl=aa_missiles,
                    infantry_pos=ipos_inf, infantry_state=istate, infantry_hp=ihp,
                    patrol_pos=ppos, patrol_state=pstate, patrol_hp=php_v,
                    patrol_alert=pat_alert,
                    inter_phase=int_phase, inter_speed=int_speed,
                    base_hp=base_hp, base_hp_max=base_hp_max))

            # 提前终止：无人机全部终态 且 步兵全部终态 且（基地已摧毁 或 无无人机
            # 可轰炸）且 直升机全部返航停靠 时，后续步不会再产生任何变化，提前 break。
            if record:
                drones_done = all(s != 0 for s in state)
                inf_done = all(s2 != 0 for s2 in istate)
                base_done = base_hp <= 0.0 or not any(s2 == 1 for s2 in istate)
                int_done = all(ph == 0 for ph in int_phase)
                if drones_done and inf_done and base_done and int_done:
                    break

        if min_dist >= 1e17:
            min_dist = math.hypot(map_w, map_h)
        total_path = sum(path_len)
        total_climb = sum(climb_total)
        total_turn = sum(turn_total)
        direct = sum(math.hypot(self.targets[i][0] - self.starts[i][0],
                                self.targets[i][1] - self.starts[i][1]) for i in range(n))
        path_eff = direct / max(total_path, 1.0) if total_path > 0 else 0.0
        n_inf_arrived = int(sum(1 for s2 in istate if s2 == 1))
        n_inf_lost = int(sum(1 for s2 in istate if s2 == 2))
        n_patrol_killed = int(sum(1 for s2 in pstate if s2 == 1))
        base_destroyed = base_hp <= 0.0
        mission_success = base_destroyed    # 目标血量归零 = 最终胜利
        # 士兵存活率与生命情况（蓝方步兵 / 红方巡逻兵）
        inf_alive = n_inf - n_inf_lost
        inf_alive_hp = [hp for s, hp in zip(istate, ihp) if s != 2]
        inf_survival = inf_alive / max(n_inf, 1)
        inf_avg_hp = sum(inf_alive_hp) / inf_alive if inf_alive > 0 else 0.0
        pat_alive = n_pat - n_patrol_killed
        pat_alive_hp = [hp for s, hp in zip(pstate, php_v) if s != 1]
        pat_survival = pat_alive / max(n_pat, 1)
        pat_avg_hp = sum(pat_alive_hp) / pat_alive if pat_alive > 0 else 0.0
        metrics = {
            'path_length': float(total_path),
            'flight_time': float(max(flight_t) if flight_t else 0.0),
            'min_dist': float(min_dist),
            'bounds_steps': int(bounds_steps),
            'nofly_steps': int(nofly_steps),
            'n_arrived': int(sum(1 for s in state if s in (1, 4))),
            'n_lost': int(sum(1 for s in state if s == 2)),
            'n_crashed': int(sum(1 for s in state if s == 3)),
            'climb': float(total_climb),
            'first_capture': float(first_capture),
            'risk_time': float(risk_time),
            'path_efficiency': float(path_eff),
            'curvature': float(total_turn),
            # 空地协同巷战
            'base_hp': float(base_hp),
            'base_destroyed': bool(base_destroyed),
            'n_inf_arrived': n_inf_arrived,
            'n_inf_lost': n_inf_lost,
            'n_patrol_killed': n_patrol_killed,
            'mission_success': bool(mission_success),
            # 士兵存活率与生命情况
            'infantry_alive': int(inf_alive),
            'infantry_survival': float(inf_survival),
            'infantry_avg_hp': float(inf_avg_hp),
            'infantry_hp_total': float(sum(inf_alive_hp)),
            'patrol_alive': int(pat_alive),
            'patrol_survival': float(pat_survival),
            'patrol_avg_hp': float(pat_avg_hp),
            'patrol_hp_total': float(sum(pat_alive_hp)),
        }
        reward = self._reward(state, istate, pstate, base_hp, nofly_steps,
                              bounds_steps, collisions, total_path, min_dist,
                              total_climb)
        cost = -reward
        if record:
            return cost, state, metrics, frames
        return cost, state, metrics, None

    def _reward(self, drone_state, infantry_state, patrol_state, base_hp,
                nofly_steps, bounds_steps, collisions, path_length, min_dist,
                total_climb):
        cfg = self.cfg
        n_arrived = sum(1 for s in drone_state if s in (1, 4))
        n_lost = sum(1 for s in drone_state if s == 2)
        n_crashed = sum(1 for s in drone_state if s == 3)
        n_unfinished = cfg.n_drones - n_arrived - n_lost - n_crashed
        direct = sum(math.hypot(self.targets[i][0] - self.starts[i][0],
                                self.targets[i][1] - self.starts[i][1])
                     for i in range(cfg.n_drones))
        # 绕行惩罚只看水平航程；爬升能耗由下方 w_climb 项单独承担，避免重复计罚
        path_norm = path_length / max(direct, 1.0)
        safety_norm = min(1.0, min_dist / (cfg.intercept_radius * 4.0))
        # 空地协同巷战
        n_inf_arrived = sum(1 for s in infantry_state if s == 1)
        n_inf_lost = sum(1 for s in infantry_state if s == 2)
        n_patrol_killed = sum(1 for s in patrol_state if s == 1)
        base_progress = 1.0 - base_hp / max(self.base_hp_max, 1.0)
        base_destroyed = base_hp <= 0.0
        mission_success = base_destroyed    # 目标血量归零 = 最终胜利
        r = (cfg.w_arrive * n_arrived
             - cfg.w_lost * n_lost
             - cfg.w_crash * n_crashed
             - cfg.w_time * n_unfinished
             - cfg.w_nofly * nofly_steps
             - cfg.w_bounds * bounds_steps
             - cfg.w_collision * collisions
             - cfg.w_path * (path_norm - 1.0)
             - cfg.w_climb * total_climb / max(cfg.terrain_amplitude, 1.0)
             + cfg.w_safety * safety_norm
             # 空地协同巷战收益
             + cfg.w_base * base_progress          # 基地轰炸进度（连续梯度）
             + cfg.w_inf_arrive * n_inf_arrived    # 步兵抵达基地
             - cfg.w_inf_lost * n_inf_lost         # 步兵阵亡
             + cfg.w_patrol_kill * n_patrol_killed # 击杀巡逻兵
             + (cfg.w_success if mission_success else 0.0))  # 整体成功
        return r

    @staticmethod
    def _snapshot(step, drone_pos, drone_state, inter_pos,
                  drone_head, inter_head, events=None, aa_states=None, aa_msl=None,
                  infantry_pos=None, infantry_state=None, infantry_hp=None,
                  patrol_pos=None, patrol_state=None, patrol_hp=None,
                  patrol_alert=None, inter_phase=None, inter_speed=None,
                  base_hp=None, base_hp_max=None):
        return {
            'step': int(step),
            'drones': [[float(p[0]), float(p[1]), float(p[2]), int(s), float(h)]
                       for p, s, h in zip(drone_pos, drone_state, drone_head)],
            # 直升机拦截机：[x, y, z, head, phase, speed]（phase：0 停靠 1 起飞
            # 2 巡航拦截 3 返航 4 降落；speed 供前端表现旋翼转速与起降加减速）
            'interceptors': [[float(p[0]), float(p[1]), float(p[2]), float(h),
                              int(inter_phase[k]) if inter_phase and k < len(inter_phase) else 2,
                              float(inter_speed[k]) if inter_speed and k < len(inter_speed) else 0.0]
                             for k, (p, h) in enumerate(zip(inter_pos, inter_head))],
            # 地面无人车（防空车）：[x, y, z, head]，贴地位置 + 航向
            'aa': [[float(q[0]), float(q[1]), float(q[2]), float(q[3])]
                   for q in (aa_states or [])],
            # 在场防空导弹：稳定 ID + 位置（前端按 ID 匹配，渲染导弹 + 发射焰）
            'missiles': [[int(m[6]), float(m[0]), float(m[1]), float(m[2])]
                         for a in (aa_msl or []) for m in a],
            # 本步被拦截事件，供前端播放「被拦截」反馈动画
            'events': list(events or []),
            # 蓝方步兵：[x, y, state, hp]（state：0 行进 1 抵达目标点并攻击 2 阵亡）
            'infantry': [[float(p[0]), float(p[1]), int(s), float(hp)]
                         for p, s, hp in zip(infantry_pos or [], infantry_state or [],
                                             infantry_hp or [])],
            # 红方巡逻兵：[x, y, state, hp, alert]（state：0 存活 1 阵亡；
            # alert：1=可视范围内发现步兵，供前端头顶闪烁警示标志）
            'patrol': [[float(p[0]), float(p[1]), int(s), float(hp),
                        int(patrol_alert[j]) if patrol_alert and j < len(patrol_alert) else 0]
                       for j, (p, s, hp) in enumerate(zip(patrol_pos or [], patrol_state or [],
                                                          patrol_hp or []))],
            # 军事基地：当前血量 / 上限血量（前端据此渲染基地血量条）
            'base': [float(base_hp if base_hp is not None else 0.0),
                     float(base_hp_max if base_hp_max is not None else 0.0)],
        }

    def cost(self, x: np.ndarray) -> float:
        cost, _, _, _ = self._rollout(x, record=False, red_x=self.red_x)
        return float(cost)

    def evaluate(self, x: np.ndarray):
        """返回 (cost, state, metrics)，供 GUI 多维收敛曲线展示。"""
        cost, state, metrics, _ = self._rollout(x, record=False, red_x=self.red_x)
        return cost, state, metrics

    def trajectory(self, x: np.ndarray):
        """返回 (cost, frames, final_state)，供 GUI 动画演示。"""
        cost, state, _, frames = self._rollout(x, record=True, red_x=self.red_x)
        return cost, state, frames

    def red_cost(self, red_x: np.ndarray, blue_x: np.ndarray) -> float:
        """协同演化：红方评估函数（固定蓝方航点 blue_x，红方按 red_x 巡逻）。

        红方目标 = 最小化蓝方突破、最大化击落、并让蓝方更多暴露于拦截半径内，
        后一项（risk_time）为红方提供连续的搜索梯度。
        """
        cfg = self.cfg
        _, _, metrics, _ = self._rollout(blue_x, record=False, red_x=red_x)
        return (cfg.w_arrive * metrics['n_arrived']
                - cfg.w_lost * metrics['n_lost']
                - 0.5 * metrics['risk_time'])


# ===========================================================================
# 问题协议适配（与 CECFunction 鸭子类型一致）
# ===========================================================================


class UAVAdversarialProblem:
    """把一次对抗场景包装成 DE 可直接消费的问题对象。

    协议字段对齐 ``cec_suites.CECFunction``：``lb/ub/dim/f_opt/label/fid/
    category/suite/name`` + ``__call__(x) -> float``。
    """

    def __init__(self, scenario: str, fid: int, env: UAVEnv,
                 name: str = ''):
        self.suite = f'uav_{scenario}'
        self.scenario = scenario
        self.fid = fid
        self.env = env
        self.cfg = env.cfg
        self.dim = env.cfg.dim
        self.red_dim = env.cfg.red_dim
        self.lb = -1.0
        self.ub = 1.0
        self.f_opt = None               # 无已知全局最优
        self.x_opt = None
        self.name = name or f'{scenario} task {fid}'
        self.category = 'application'

    def decode(self, x: np.ndarray) -> np.ndarray:
        terrain = self.env.terrain if self.cfg.terrain_enabled else None
        return _decode_waypoints(x, self.cfg, terrain=terrain)

    def decode_infantry(self, x: np.ndarray) -> np.ndarray:
        """解码步兵二维地面航点 (n_infantry, K, 2)，供前端画步兵路径。"""
        return _decode_infantry_waypoints(x, self.cfg)

    def __call__(self, x) -> float:
        return self.env.cost(x)

    def trajectory(self, x):
        return self.env.trajectory(x)

    def evaluate(self, x):
        """返回 (cost, state, metrics)，供 GUI 多维收敛曲线展示。"""
        return self.env.evaluate(x)

    def red_cost(self, red_x, blue_x):
        """协同演化：红方评估（固定蓝方 blue_x，评估红方航点 red_x）。"""
        return self.env.red_cost(red_x, blue_x)

    @property
    def label(self):
        return f'U{self.fid}'

    def __repr__(self):
        return (f'<UAV {self.scenario} U{self.fid} {self.name} '
                f'D={self.dim}>')


# ===========================================================================
# 场景注册与工厂
# ===========================================================================


def _intercept_cfg(fid: int, n_waypoints: Optional[int] = None,
                   n_infantry: Optional[int] = None) -> EnvConfig:
    """intercept（实景突防）任务的红方防御配置。

    固定战场：地形 / 建筑物 / 蓝方起飞编队与敌我初始位置由 ``seed`` 唯一确定，
    与任务号无关（见 ``UAVEnv`` 的 ``layout`` 参数）；``fid`` 只决定红方防御强度。
    共 4 个任务：U1 基线（1 拦截者）、U2 基线 + 禁飞区、U3 双拦截者、
    U4 双拦截者 + 禁飞区 + 拦截者加速。``fid>4`` 时确定性地随机散布拦截者与
    禁飞区，便于扩展更多任务。
    """
    cfg = EnvConfig()
    if n_waypoints is not None:
        cfg.n_waypoints = int(n_waypoints)
    if n_infantry is not None and int(n_infantry) > 0:
        cfg.n_infantry = int(n_infantry)
    # 巡逻兵数量统一为 cfg.n_patrol（默认 20，用户指定），不再随 fid 递减覆盖；
    # 任务难度差异由拦截者数量 / 禁飞区 / 拦截者速度体现。
    # 直升机停机坪设在东南角空地（远离军事基地，落在雷达探测范围外）：
    # 平时停靠待命，雷达捕获入侵无人机后才起飞拦截，避免「开局即悬空巡航」。
    if fid == 1:                                   # 基线：1 拦截者
        cfg.interceptor_pos = [(950.0, 50.0)]
    elif fid == 2:                                 # + 1 禁飞区
        cfg.interceptor_pos = [(950.0, 50.0)]
        cfg.no_fly_zones = [(480.0, 500.0, 310.0, 120.0)]
    elif fid == 3:                                 # 2 拦截者
        cfg.interceptor_pos = [(950.0, 50.0), (860.0, 45.0)]
    elif fid == 4:                                 # 2 拦截者 + 禁飞区 + 更快
        cfg.interceptor_pos = [(950.0, 50.0), (860.0, 45.0)]
        cfg.interceptor_speed = 14.0
        cfg.no_fly_zones = [(460.0, 520.0, 310.0, 130.0)]
    else:
        # 更多任务：随机但确定地散布拦截者与禁飞区（拦截者约束在东南角空地，
        # 且落在雷达范围外，保持「停靠待命、雷达捕获才出动」的语义）
        rng = np.random.default_rng(fid * 101)
        n = 1 + (fid % 4)
        cfg.interceptor_pos = []
        _fallback = [(950.0, 50.0), (860.0, 45.0), (920.0, 120.0), (900.0, 160.0)]
        attempts = 0
        while len(cfg.interceptor_pos) < n:
            attempts += 1
            if attempts > 400:   # 拒绝采样兜底：用确定性安全位补齐，保证必然终止
                for p in _fallback:
                    if len(cfg.interceptor_pos) >= n:
                        break
                    if p not in cfg.interceptor_pos:
                        cfg.interceptor_pos.append(p)
                break
            px = float(rng.uniform(820, 960))
            py = float(rng.uniform(40, 180))
            if math.hypot(px - 500.0, py - 500.0) > 520.0:
                cfg.interceptor_pos.append((px, py))
        cfg.interceptor_speed = 11.0 + (fid % 4) * 1.5
        if fid % 2 == 0:
            cfg.no_fly_zones = [
                (float(rng.uniform(300, 700)),
                 float(rng.uniform(300, 700)),
                 110.0,
                 float(rng.uniform(90, 150)))]
    cfg.n_interceptors = len(cfg.interceptor_pos)  # 同步拦截者数量（维度依赖）
    return cfg


def _build_env(scenario: str, fid: int, seed: int = 0,
               n_waypoints: Optional[int] = None,
               n_attack: Optional[int] = None,
               n_infantry: Optional[int] = None,
               opponent=None) -> UAVEnv:
    """按场景 + 任务 id 生成确定性的环境（对手/禁飞区布局由 seed 固定）。

    ``n_waypoints`` 可覆盖每架无人机的航点数 K；为 None 时使用场景默认值。
    ``opponent`` 为红方对手策略（intercept/swarm），None 表示使用 env 内置规则。
    """
    if scenario == 'intercept':
        cfg = _intercept_cfg(fid, n_waypoints=n_waypoints,
                             n_infantry=n_infantry)
    elif scenario == 'swarm':
        return build_swarm_env(fid, seed=seed, n_waypoints=n_waypoints,
                               n_attack=n_attack, opponent=opponent)
    else:
        raise KeyError(f'未知场景: {scenario}')

    cfg.n_interceptors = len(cfg.interceptor_pos)  # 同步拦截者数量（维度依赖）
    # 固定战场：实景场景是战前勘定的一张地图，地形、建筑物、蓝方起飞编队、
    # 步兵出发队形与红方巡逻兵位置都由 seed 唯一确定，与任务编号 fid 无关；
    # fid 只决定红方防御配置（拦截者数量 / 禁飞区 / 拦截者速度）。于是 F1-F4
    # 是同一张实景地图上的四个任务，只有任务目标不同。
    if scenario == 'intercept':
        return UAVEnv(cfg, seed=seed, opponent=opponent,
                      layout=_intercept_layout(cfg))
    return UAVEnv(cfg, seed=seed + fid * 101, opponent=opponent)


# 实景拦截场景的固定蓝方部署（战前确定）：无人机起飞编队与步兵出发队形。
# 无人机以 cfg.start_pos = (60, 60) 为基准点编队起飞，间距 > 25 m 的机间
# 碰撞判定距离；步兵围绕锚点 (200, 150) 成三角队形。
def _intercept_layout(cfg: EnvConfig) -> dict:
    """返回 intercept 场景的固定蓝方部署（不随任务编号变化）。"""
    sx, sy = float(cfg.start_pos[0]), float(cfg.start_pos[1])
    starts = [(sx, sy), (sx + 45.0, sy + 12.0), (sx + 12.0, sy + 55.0)]
    infantry = [(178.0, 128.0), (200.0, 150.0), (222.0, 172.0)]
    return {'starts': starts, 'infantry': infantry}


# 注册：场景名 -> (默认维度, 默认任务数)
SCENARIO_DIMS = {'intercept': 30, 'swarm': SWARM_DIM}
SCENARIO_NFUNCS = {'intercept': 4, 'swarm': SWARM_NFUNCS}


def list_scenarios() -> List[str]:
    return sorted(SCENARIO_DIMS)


# 各场景最小航点数（K 低于此值会被自动抬升，避免航点过少导致路径表达能力退化）
MIN_WAYPOINTS = {'intercept': 2, 'swarm': 3}


def min_waypoints_for(scenario: str) -> int:
    """返回场景允许的最小航点数（低于该值的 K 将被抬升到该下限）。"""
    return MIN_WAYPOINTS.get(scenario, 1)


def get_uav_problem(scenario: str, dim: Optional[int] = None,
                    fid: int = 1, seed: int = 0,
                    n_waypoints: Optional[int] = None,
                    n_attack: Optional[int] = None,
                    n_infantry: Optional[int] = None,
                    opponent=None) -> UAVAdversarialProblem:
    """工厂：构造一个 UAV 对抗问题对象。

    ``dim`` 为 None 时使用场景默认维度；``n_waypoints`` 可覆盖每架无人机的
    航点数 K（低于场景下限时按下限抬升）；``opponent`` 为红方对手策略
    （intercept/swarm）。
    """
    if scenario not in SCENARIO_DIMS:
        raise KeyError(f'未知场景: {scenario}（可用: {list_scenarios()}）')
    if n_waypoints is not None and int(n_waypoints) < min_waypoints_for(scenario):
        n_waypoints = min_waypoints_for(scenario)
    env = _build_env(scenario, fid, seed=seed, n_waypoints=n_waypoints,
                     n_attack=n_attack, n_infantry=n_infantry, opponent=opponent)
    if dim is not None and dim != env.cfg.dim:
        raise ValueError(
            f'场景 {scenario} 决策维度为 {env.cfg.dim}，与请求的 {dim} 不一致')
    if scenario == 'swarm':
        return SwarmProblem(scenario, fid, env)
    return UAVAdversarialProblem(scenario, fid, env)


# ===========================================================================
# 场景结构化说明（供 GUI 弹窗与 Web 展示：问题 / 模型 / 参数 / 约束）
# ===========================================================================

# 各场景的任务名称（fid -> 短名），供前端「任务」下拉展示。
# intercept 的 4 个任务共享同一张实景地图，只有红方防御强度不同；
# swarm 的 4 个任务对应赛题四问，红方集群编成与对抗区域带宽逐问升级。
TASK_NAMES = {
    'intercept': {
        1: '基线突防',
        2: '禁飞区绕行',
        3: '双机拦截',
        4: '强拦截对抗',
    },
    'swarm': {
        1: '双集群纵深拦截',
        2: '窄通道集群拦截',
        3: '双波次增援拦截',
        4: '五集群协同拦截',
    },
}

# 场景名（界面下拉、本体 / 知识图谱的场景筛选共用这一份，避免各处另写一套）
# ``SCENARIO_LABELS`` = 完整名（下拉选项 / 提示文案用）；
# ``SCENARIO_SHORT`` = 短名（图标题、状态行、节点标签这类空间有限处用，避免长串重复）。
SCENARIO_LABELS = {
    'intercept': '实景突防（无人机突防与拦截）',
    'swarm': '集群突防（2020 华为杯 D 题）',
}

SCENARIO_SHORT = {
    'intercept': '实景突防',
    'swarm': '集群突防',
}


def scenario_label(scenario: str, short: bool = False) -> str:
    """场景的中文名（``short=True`` 取短名；未登记时回退场景名本身）。"""
    key = str(scenario)
    return (SCENARIO_SHORT if short else SCENARIO_LABELS).get(key) \
        or SCENARIO_LABELS.get(key, key)


def list_tasks(scenario: str) -> List[int]:
    """场景下的任务编号列表（1..任务数）。"""
    return list(range(1, int(SCENARIO_NFUNCS.get(scenario, 1)) + 1))


def task_info(scenario: str, fid: int) -> Dict[str, object]:
    """单个任务的标签与红方配置摘要（不构建环境，供前端任务下拉展示）。

    intercept 是固定战场：地形与蓝方部署与 fid 无关，``fid`` 只改变红方防御
    强度；swarm 的对抗区域带宽与红方集群编成随 ``fid`` 变化。两者都只列
    防御相关参数，因此只需轻量构造 cfg，无需建环境。
    """
    fid = int(fid)
    name = TASK_NAMES.get(scenario, {}).get(fid, '')
    info: Dict[str, object] = {
        'scenario': scenario, 'fid': fid, 'name': name,
        'dim': SCENARIO_DIMS.get(scenario), 'brief': '',
        'n_interceptors': None, 'interceptor_speed': None,
        'n_no_fly_zones': 0,
        'n_clusters': None, 'cluster_size': None, 'defend_speed': None,
    }
    if scenario == 'intercept':
        cfg = _intercept_cfg(fid)
        n_int = len(cfg.interceptor_pos)
        n_nfz = len(cfg.no_fly_zones)
        info.update({
            'dim': cfg.dim,
            'n_interceptors': n_int,
            'interceptor_speed': float(cfg.interceptor_speed),
            'n_no_fly_zones': n_nfz,
        })
        info['brief'] = ' · '.join([
            f'{n_int} 架拦截者（速度 {cfg.interceptor_speed:.0f}/步）',
            f'{n_nfz} 个禁飞区' if n_nfz else '无禁飞区',
        ])
    elif scenario == 'swarm':
        cfg = swarm_cfg(fid)
        n_nfz = len(cfg.no_fly_zones)
        info.update({
            'dim': cfg.dim,
            'n_clusters': cfg.n_clusters,
            'cluster_size': cfg.cluster_size,
            'defend_speed': float(cfg.defend_speed),
            'n_no_fly_zones': n_nfz,
        })
        info['brief'] = ' · '.join([
            f'{cfg.n_clusters} 个集群 × {cfg.cluster_size} 架'
            f'（速度 {cfg.defend_speed:.0f} m/s）',
            f'{n_nfz} 个禁飞区' if n_nfz else '无禁飞区',
        ])
    return info


SCENARIO_NAMES = {
    'intercept': '无人机突防与拦截（三维山地）',
    'swarm': '无人机集群突防对抗（三维山地）',
}


def describe_scenario(scenario: str, fid: int = 1,
                      n_waypoints: Optional[int] = None,
                      n_attack: Optional[int] = None,
                      n_infantry: Optional[int] = None) -> Dict[str, object]:
    """返回场景的完整结构化说明，供 GUI 弹窗与 Web 前端渲染。

    返回字段：
      scenario / fid / name / dim / n_waypoints
      problem     —— 要解决的问题
      model       —— 模型在做什么（运动学 / 物理 / 判定模型）
      scoring     —— 目标函数与评分
      constraints —— 约束条件列表（每条一句）
      params      —— cfg.describe() 展平后的参数具体值 dict
      fid_note    —— 本任务（fid）的差异化说明
    """
    problem = get_uav_problem(scenario, fid=fid, n_waypoints=n_waypoints,
                              n_attack=n_attack, n_infantry=n_infantry)
    cfg = problem.cfg
    info = {
        'scenario': scenario,
        'fid': fid,
        'name': SCENARIO_NAMES.get(scenario, scenario),
        'dim': cfg.dim,
        'n_waypoints': cfg.n_waypoints,
        'min_waypoints': min_waypoints_for(scenario),
        'params': cfg.describe(),
    }

    if scenario == 'intercept':
        half = math.degrees(cfg.intercept_half_angle)
        vhalf = math.degrees(cfg.intercept_vert_half_angle)
        info.update({
            'problem': (
                '三维山地红蓝空地协同对抗：我方（蓝方）{n_drones} 架突防无人机从起点起飞，'
                '需穿越一片起伏山地与红方拦截区，轰炸位于目标区的军事基地（攻击点）；'
                '同时一支由 {n_inf} 名步兵组成的地面小队沿巷战区域协同推进，抵达军事基地'
                '后持续攻击之。红方除部署 {n_int} 架拦截者（圆锥侦察范围巡逻、锁定追击、山体'
                '可遮挡 LOS）外，还在地面随机部署 {n_pat} 名巡逻兵（球形攻击范围、攻击时'
                '不能移动），楼房可作掩体遮挡步兵与巡逻兵之间的视线。决策变量既包含每架'
                '无人机的 K={k} 个三维航点，也包含每名步兵的 K={k} 个二维地面航点'
                '（共 D={dim} 维），DE / UPCL 通过优化空地航点布局，使「无人机轰炸 + '
                '步兵攻击」共同将基地血量削减至 0 完成任务，同时最小化损失与各类代价。'
            ).format(n_drones=cfg.n_drones, n_int=cfg.n_interceptors,
                     n_inf=cfg.n_infantry, n_pat=cfg.n_patrol,
                     k=cfg.n_waypoints, dim=cfg.dim),
            'model': (
                '运动学模型：双方均以恒定速度运动（我方 {ds:.1f}/步、拦截者 {is_:.1f}/步），'
                '每步航向最多改变各自的最大角速度（我方 {dt:.2f}、拦截者 {it:.2f} rad/步，'
                '对应最小转弯半径），无法直角急转。无人机依次飞向 K 个中间航点'
                '（进入半径 {wp:.0f} 即切换下一航点），最后飞向目标区；若超过 {ns} 步'
                '仍未到达则判超时。拦截者未发现目标时按航点巡逻，一旦我方进入其前方'
                '圆锥侦察范围（水平 ±{half:.0f}°、垂直 ±{vhalf:.0f}°、距离小于 {ir:.0f} m）'
                '即锁定并持续追击，直至目标被击落或逃逸。三维物理：双方贴地飞行'
                '（高度 = 地面高程 + {hc:.0f} m），爬升累计爬山能耗；蓝方航点高度编码为'
                '贴地高度 + 爬升偏移 [0, {mo:.0f}] m，并以 {la} 步前瞻地形平滑爬升、'
                '地面下限硬约束保证不穿山；拦截捕获还需视线（LOS）通畅——若无人机与'
                '拦截者之间被山体遮挡，则无法被雷达捕获。'
            ).format(ds=cfg.drone_speed, is_=cfg.interceptor_speed,
                     dt=cfg.drone_turn_rate, it=cfg.interceptor_turn_rate,
                     wp=cfg.wp_reach_radius, ns=cfg.n_steps,
                     half=half, vhalf=vhalf, ir=cfg.intercept_radius,
                     hc=cfg.h_clearance, mo=cfg.max_alt_offset,
                     la=cfg.lookahead_steps)
            + (
                ' 空地协同模型：蓝方步兵（{n_inf} 人，速度 {isp:.1f}/步、血量 {ihp:.0f}）'
                '沿各自 K 个二维地面航点向军事基地推进（进入半径 {br:.0f} 后持续攻击基地），'
                '步兵可反击巡逻兵（伤害 {idmg:.0f}、射程 {irng:.0f} m、冷却 {icd:.2f} 秒）。'
                '红方巡逻兵（{n_pat} 人，血量 {php:.0f}、伤害 {pdmg:.0f}、射程 {prng:.0f} m、'
                '可视范围 {pv:.0f} m、冷却 {pcd:.2f} 秒）随机分布，攻击时不能移动；任一巡逻兵'
                '在可视范围内发现步兵后会通报同伴，其余巡逻兵赶来协同追捕，靠近到射程内再射击。'
                '楼房可遮挡双方视线（LOS），步兵被射击时主动向最近楼房掩体躲避。'
                '每架抵达基地的无人机投弹一次（伤害 {bdmg:.0f}）后自毁；基地血量 {bhp:.0f}'
                '由无人机投弹与步兵攻击共同削减，削减至 0 即为任务完成。'
            ).format(n_inf=cfg.n_infantry, isp=cfg.infantry_speed, ihp=cfg.infantry_hp,
                     br=cfg.base_radius, idmg=cfg.infantry_damage, irng=cfg.infantry_range,
                     icd=cfg.infantry_fire_cd, n_pat=cfg.n_patrol, php=cfg.patrol_hp,
                     pdmg=cfg.patrol_damage, prng=cfg.patrol_range, pv=cfg.patrol_vision_range,
                     pcd=cfg.patrol_fire_cd, bdmg=cfg.bomb_damage, bhp=cfg.base_hp),
            'scoring': (
                '目标函数 cost = -reward（DE 求最小化），reward = '
                '{wa:.0f}·到达数 - {wl:.0f}·被击落数 - {wcr:.0f}·坠毁数 - {wt:.0f}·未完成数'
                ' - {wnf:.0f}·禁飞步数 - {wb:.0f}·越界步数 - {wc:.0f}·碰撞数'
                ' - {wp:.0f}·(水平航程/直线距离-1) - {wcl:.0f}·(累计爬升/地形起伏)'
                ' + {ws:.0f}·(与拦截者最小距离/4R)'
                ' + {wbase:.0f}·基地轰炸进度 + {wila:.0f}·步兵抵达数'
                ' - {will:.0f}·步兵阵亡数 + {wpk:.0f}·击杀巡逻兵数'
                ' + {wsc:.0f}·整体成功（目标血量归零）。'
                '绕行与爬升能耗两项共同构成「翻山」与「绕山」的连续可微权衡，'
                '空地协同项则引导无人机轰炸与步兵推进的联合决策。'
            ).format(wa=cfg.w_arrive, wl=cfg.w_lost, wcr=cfg.w_crash, wt=cfg.w_time,
                     wnf=cfg.w_nofly, wb=cfg.w_bounds, wc=cfg.w_collision,
                     wp=cfg.w_path, wcl=cfg.w_climb, ws=cfg.w_safety,
                     wbase=cfg.w_base, wila=cfg.w_inf_arrive, will=cfg.w_inf_lost,
                     wpk=cfg.w_patrol_kill, wsc=cfg.w_success),
            'constraints': [
                f'地图边界：越出 [0, {cfg.map_w:.0f}]×[0, {cfg.map_h:.0f}] 判罚'
                f'（权重 {cfg.w_bounds:.0f}/步）。',
                f'禁飞区：进入圆形禁飞区判罚（权重 {cfg.w_nofly:.0f}/步）。'
                if cfg.no_fly_zones else '禁飞区：本任务未设置禁飞区，此项不生效。',
                f'机间碰撞：两机距离 < {cfg.collision_radius:.0f} 判罚'
                f'（权重 {cfg.w_collision:.0f}）。',
                f'拦截判定：进入拦截者前方圆锥侦察范围（水平 ±{half:.0f}°、垂直 ±{vhalf:.0f}°'
                f'、距离 < {cfg.intercept_radius:.0f} m）即被击落。',
                f'地面无人车（防空车）：{cfg.n_aa} 辆贴地机动对空拦截（水平距离 ≤ '
                f'{cfg.aa_range:.0f} m、仰角 ≤ {cfg.aa_vert_half_angle * 180 / math.pi:.0f}°），'
                f'进入攻击范围且视线通畅即发射拦截导弹（速度 {cfg.missile_speed:.0f} m/s，'
                f'略快于无人机；限转弯率 {cfg.missile_turn:.1f} rad/步、不能直角转弯，'
                f'燃料 {cfg.missile_fuel} 步耗尽自毁），每车对同一目标只追一枚导弹，'
                f'命中即击落（无人机可通过机动甩掉导弹）。',
                f'视线遮挡（LOS）：无人机与拦截者之间被山体遮挡时，雷达无法捕获'
                f'（贴山规避）。' if cfg.los_block else '视线遮挡：本任务关闭 LOS，山体不遮挡雷达。',
                f'贴地飞行：航点高度 = 地面高程 + {cfg.h_clearance:.0f} m + 爬升偏移'
                f'[0, {cfg.max_alt_offset:.0f}] m，前瞻 {cfg.lookahead_steps} 步平滑'
                f'爬升，地面下限硬约束保证不穿山。',
                f'爬升能耗按累计爬升 / 地形起伏（{cfg.terrain_amplitude:.0f} m）'
                f'计入代价（权重 {cfg.w_climb:.0f}）。',
                f'运动学约束：每步航向改变量 ≤ 最大角速度（最小转弯半径 '
                f'{cfg.drone_speed / cfg.drone_turn_rate:.0f} m）。',
                f'时限：超过 {cfg.n_steps} 步未到达判超时。',
                f'到达判定：进入目标区（军事基地）半径 {cfg.base_radius:.0f} 即记为到达。',
                f'军事基地：血量 {cfg.base_hp:.0f}，每架抵达基地的无人机投弹一次伤害 '
                f'{cfg.bomb_damage:.0f} 后自毁（不持续攻击）；步兵抵达后持续攻击基地，'
                f'目标血量削减至 0 即最终胜利。',
                f'步兵：{cfg.n_infantry} 人，血量 {cfg.infantry_hp:.0f}、速度 '
                f'{cfg.infantry_speed:.1f}/步，抵达目标点（基地半径 {cfg.base_radius:.0f}）后'
                f'持续攻击基地（伤害 {cfg.infantry_damage:.0f}、冷却 {cfg.infantry_fire_cd:.2f} 秒）；'
                f'途中可反击巡逻兵（射程 {cfg.infantry_range:.0f} m）。',
                f'巡逻兵：{cfg.n_patrol} 人，血量 {cfg.patrol_hp:.0f}、伤害 {cfg.patrol_damage:.0f}、'
                f'射程 {cfg.patrol_range:.0f} m、可视范围 {cfg.patrol_vision_range:.0f} m、'
                f'冷却 {cfg.patrol_fire_cd:.2f} 秒，攻击时不能移动；无威胁时慢速布朗巡逻，'
                f'可视范围内发现步兵后加速逼近（速度与步兵一致）并呼叫同伴协同追捕，靠近到射程内再射击。',
                f'楼房掩体：{cfg.n_buildings} 栋（边长 {cfg.building_min:.0f}~{cfg.building_max:.0f} m），'
                f'遮挡步兵与巡逻兵之间的视线（LOS），步兵被射击时主动向最近楼房躲避。',
                f'侦察机/防空车不对步兵攻击；巡逻兵不对空中无人机攻击（空地分层交战）。',
            ],
            'fid_note': (
                f'本想定 U{fid}：{cfg.n_interceptors} 架拦截者'
                f'（速度 {cfg.interceptor_speed:.0f}/步）、'
                f'{cfg.n_aa} 辆地面无人车（防空车，对空攻击范围 '
                f'{cfg.aa_range:.0f} m、仰角 ≤ {cfg.aa_vert_half_angle * 180 / math.pi:.0f}°，'
                f'发射速度 {cfg.missile_speed:.0f} m/s 略快于无人机的拦截导弹）、'
                + (f'{len(cfg.no_fly_zones)} 个禁飞区、'
                   if cfg.no_fly_zones else '无禁飞区、')
                + (f'{cfg.n_patrol} 名巡逻兵、{cfg.n_buildings} 栋楼房、'
                   f'军事基地血量 {cfg.base_hp:.0f}。')
            ),
            'optimization': (
                f'演化优化：决策变量 x∈[-1,1]^{cfg.dim} 前半段为 {cfg.n_drones} 架无人机的 '
                f'K={cfg.n_waypoints} 个三维航点坐标（x,y,z，最小航点数 '
                f'{MIN_WAYPOINTS["intercept"]}），后半段为 {cfg.n_infantry} 名步兵的 '
                f'K={cfg.n_waypoints} 个二维地面航点坐标（x,y），解码后依次连接为飞行'
                f'/行进轨迹。差分进化（DE）在连续空间内以 cost=-reward 为适应度执行'
                f'「变异-交叉-选择」搜索最优空地航点布局；种群规模按维度自适应，'
                f'评估预算（max_evals）驱动 L-SHADE 的线性种群缩减与自适应参数。'
                f'协同模式下红方拦截者的 K_red={cfg.n_int_waypoints} 个巡逻航点作为'
                f'独立种群，与蓝方交替演化一代，形成对抗博弈。'
            ),
        })

    elif scenario == 'swarm':
        half = cfg.intercept_half_angle
        vhalf = cfg.intercept_vert_half_angle
        info.update({
            'problem': (
                '三维山地集群突防对抗（2020 华为杯研究生数学建模 D 题简化版）：蓝方 {n_attack} 架'
                '突防无人机从对抗区域 AB 边同一处起点出发（起点一致、各自航点轨迹随机），'
                '需穿越一片含高低地势、峡谷与瀑布的复杂山地，再突破红方集群与地面防空车'
                '拦截区抵达 CD 边各自目标红点。红方由 {n_clusters} 个集群（每群 '
                '{cluster_size} 架）协同拦截蓝方，另有 {n_aa} 辆地面防空车贴地机动'
                '对空拦截（不可跨越峡谷/瀑布）；山体可遮挡雷达视线（LOS），蓝方可贴山'
                '规避。决策变量为每架蓝方无人机的 K={k} 个三维中途航点坐标（x,y,z，'
                '共 D={dim} 维），蓝方拥有高度自由度、有限爬升速率与能源预算（耗尽'
                '坠毁）；协同演化时红方拦截者的巡逻航点也作为一个独立 DE 种群'
                '（D_red={rd} 维）与蓝方交替对抗。目标是让尽可能多的蓝方突破防线，'
                '同时降低绕行、爬升、能源与禁飞区代价。'
            ).format(n_attack=cfg.n_attack, n_clusters=cfg.n_clusters,
                     cluster_size=cfg.cluster_size, n_aa=cfg.n_aa,
                     k=cfg.n_waypoints, dim=cfg.dim, rd=cfg.red_dim),
            'model': (
                '运动学模型：双方均以恒定速度运动，每步航向改变受最小转弯半径限制'
                '（蓝方 {as_:.0f} m/s / 半径 {ar:.0f} m、红方 {ds:.0f} m/s / 半径 '
                '{dr:.0f} m）。红方以圆锥形侦察范围巡逻，一旦蓝方进入其侦察范围即'
                '锁定并持续追击（脱离巡逻直至目标被击落或逃逸）；协同演化时未发现'
                '目标则沿自身 K_red 个巡逻航点闭环巡逻。协同拦截判据：当 ≥{mc} 架'
                '红方同时位于某架蓝方前方圆锥内（水平 ±{half:.0f}°、垂直 ±{vhalf:.0f}°、'
                '三维距离 <{ir:.0f} m）时，该蓝方被判定拦截。三维物理：蓝方拥有高度'
                '自由度，每步以 ≤{cr:.0f} m 速率'
                '爬升/下降（受地形下限 + {hc:.0f} m 与上限 {ma:.0f} m 约束），爬升'
                '累计爬山能耗；能源按水平飞行 + 爬升额外扣减，耗尽即坠毁；拦截捕获'
                '还需视线（LOS）通畅——若蓝方与红方之间被山体遮挡，则无法被雷达捕获。'
            ).format(as_=cfg.attack_speed, ar=cfg.attack_turn_radius,
                     ds=cfg.defend_speed, dr=cfg.defend_turn_radius,
                     mc=cfg.intercept_min_count, half=half, vhalf=vhalf,
                     ir=cfg.intercept_radius,
                     hc=cfg.h_clearance, cr=cfg.max_climb_rate, ma=cfg.max_alt),
            'scoring': (
                '目标函数 cost = -reward（DE 求最小化），reward = '
                '{wa:.0f}·突破数 - {wl:.0f}·被拦截数 - {wcr:.0f}·坠毁数'
                ' - {wt:.0f}·时间 - {wnf:.0f}·禁飞步数 - {wb:.0f}·越界步数'
                ' - {wp:.0f}·(水平航程/L-1) - {wcl:.0f}·(累计爬升/地形起伏)'
                ' - {ws:.0f}·(与红方最小距离/4R)。'
            ).format(wa=cfg.w_arrive, wl=cfg.w_lost, wcr=cfg.w_crash, wt=cfg.w_time,
                     wnf=cfg.w_nofly, wb=cfg.w_bounds, wp=cfg.w_path,
                     wcl=cfg.w_climb, ws=cfg.w_safety),
            'constraints': [
                f'通道边界：蓝方越出对抗区域（纵深 {cfg.depth / 1000:.0f} km × '
                f'带宽 {cfg.width / 1000:.0f} km）判罚（权重 {cfg.w_bounds:.0f}/步）。',
                f'球形禁飞区：进入红色球形禁飞区判罚（权重 {cfg.w_nofly:.0f}/步）。'
                if cfg.no_fly_zones else '球形禁飞区：本任务未设置禁飞区，此项不生效。',
                f'高度约束：飞行高度被地形下限（地面 + {cfg.h_clearance:.0f} m）与'
                f'上限 {cfg.max_alt:.0f} m 夹取，爬升速率 ≤ {cfg.max_climb_rate:.0f} m/步。',
                f'能源约束：初始能源 {cfg.energy_capacity:.0f}，每步水平飞行消耗 '
                f'{cfg.energy_per_step:.2f} + 爬升 {cfg.climb_energy:.3f}/m，'
                f'耗尽即坠毁（罚 {cfg.w_crash:.0f}）。',
                f'突防时限：超过 {cfg.time_limit:.0f} s 未到达判超时。',
                f'协同拦截：≥{cfg.intercept_min_count} 架红方进入前方圆锥（水平 ±{half:.0f}°'
                f'、垂直 ±{vhalf:.0f}°、三维距离 < {cfg.intercept_radius:.0f} m）即被拦截。',
                f'视线遮挡（LOS）：蓝方与红方之间被山体遮挡时，雷达无法捕获'
                f'（贴山规避）。' if cfg.los_block else '视线遮挡：本任务关闭 LOS，山体不遮挡雷达。',
                f'运动学约束：双方每步航向改变受最小转弯半径限制。',
                f'绕行惩罚：实际路径长度 / 直线距离 L - 1（权重 {cfg.w_path:.0f}）。',
                f'地面防空车：{cfg.n_aa} 辆贴地机动、对空拦截（水平 ≤ '
                f'{cfg.aa_range / 1000:.1f} km、仰角 ≤ {cfg.aa_vert_half_angle:.0f}°），'
                f'进入攻击范围即发射拦截导弹（速度 {cfg.missile_speed:.0f} m/s，'
                f'快于无人机）追踪命中，不可跨越峡谷/瀑布。' if cfg.n_aa
                else '地面防空车：本任务未部署。',
                '峡谷/瀑布地貌：蓝方空中飞越不受限，地面防空车不可跨越'
                '（可翻越普通高低地势）。' if (cfg.terrain_canyons or cfg.terrain_waterfalls)
                else '峡谷/瀑布地貌：本任务未生成。',
                '到达判定：抵达 CD 边上的目标红点记为突破成功。',
            ],
            'fid_note': (
                f'本想定 U{fid}：{cfg.n_clusters} 个集群 × 每群 {cfg.cluster_size} 架，'
                f'对抗带宽 {cfg.width / 1000:.0f} km，'
                + (f'{len(cfg.no_fly_zones)} 个球形禁飞区。'
                   if cfg.no_fly_zones else '无禁飞区。')
            ),
            'optimization': (
                f'演化优化：蓝方决策变量 x∈[-1,1]^{cfg.dim} 为 {cfg.n_attack} 架无人机的 '
                f'K={cfg.n_waypoints} 个三维航点（最小航点数 {MIN_WAYPOINTS["swarm"]}）；'
                f'红方决策变量 y∈[-1,1]^{cfg.red_dim} 为 {cfg.n_interceptors} 架拦截者各 '
                f'K_red={cfg.n_int_waypoints} 个二维巡逻航点。协同演化：蓝、红两方各用一个 '
                f'DE 种群，每代交替对抗——蓝方以 cost=-reward 最小化（突破最多、代价最小），'
                f'红方以 red_cost 最小化（拦截最多）。红方巡逻航点决定其侦察圆锥的布防位置，'
                f'一旦蓝方进入某架红方的圆锥侦察范围，该红方即锁定并持续追击，形成「布防'
                f'巡逻 + 接触追击」的对抗式学习。评估预算驱动自适应参数。'
            ),
        })

    return info


# ===========================================================================
# 自检（可直接 python uav_adversarial.py 运行）
# ===========================================================================
if __name__ == '__main__':
    for scen in list_scenarios():
        for fid in range(1, SCENARIO_NFUNCS[scen] + 1):
            p = get_uav_problem(scen, fid=fid)
            x = np.zeros(p.dim)
            c = p(x)
            print(f'{p!r}  cost(x=0)={c:.1f}  env.dim={p.cfg.dim}')
        # 随机解代价分布
        rng = np.random.default_rng(1)
        costs = [p(rng.uniform(-1, 1, p.dim)) for _ in range(200)]
        print(f'  随机解 cost: min={min(costs):.1f} med={np.median(costs):.1f} '
              f'max={max(costs):.1f}')

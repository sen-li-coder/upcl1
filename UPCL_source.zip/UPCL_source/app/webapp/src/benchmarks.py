# -*- coding: utf-8 -*-
"""
Benchmark functions for continuous black-box optimisation.
Includes 7 standard continuous optimization functions at D dimensions.
All functions are minimization problems with global minimum f(x*) = 0 (except noted).
"""

import numpy as np


class BenchmarkFunction:
    """Base class for benchmark functions."""

    def __init__(self, dim, bounds=(-100.0, 100.0)):
        self.dim = dim
        self.lower, self.upper = bounds
        self.name = self.__class__.__name__

    def __call__(self, x):
        raise NotImplementedError

    def get_bounds(self):
        return np.full(self.dim, self.lower), np.full(self.dim, self.upper)


class Sphere(BenchmarkFunction):
    """Sphere function: f(x) = sum(x_i^2)
    Global minimum: f(0) = 0
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-100.0, 100.0))

    def __call__(self, x):
        return float(np.sum(x ** 2))


class Rastrigin(BenchmarkFunction):
    """Rastrigin function: f(x) = 10*D + sum(x_i^2 - 10*cos(2*pi*x_i))
    Global minimum: f(0) = 0
    Highly multimodal with many local optima.
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-5.12, 5.12))

    def __call__(self, x):
        return float(10.0 * self.dim + np.sum(x ** 2 - 10.0 * np.cos(2.0 * np.pi * x)))


class Ackley(BenchmarkFunction):
    """Ackley function:
    f(x) = -20*exp(-0.2*sqrt(mean(x_i^2))) - exp(mean(cos(2*pi*x_i))) + 20 + e
    Global minimum: f(0) = 0
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-32.0, 32.0))

    def __call__(self, x):
        term1 = -20.0 * np.exp(-0.2 * np.sqrt(np.mean(x ** 2)))
        term2 = -np.exp(np.mean(np.cos(2.0 * np.pi * x)))
        return float(term1 + term2 + 20.0 + np.e)


class Rosenbrock(BenchmarkFunction):
    """Rosenbrock function (banana):
    f(x) = sum_{i=1}^{D-1} [100*(x_{i+1} - x_i^2)^2 + (1 - x_i)^2]
    Global minimum: f(1,...,1) = 0
    Narrow, parabolic-shaped valley.
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-30.0, 30.0))

    def __call__(self, x):
        return float(np.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (1.0 - x[:-1]) ** 2))


class Schwefel(BenchmarkFunction):
    """Schwefel function:
    f(x) = 418.9829*D - sum(x_i * sin(sqrt(|x_i|)))
    Global minimum: f(420.9687,...,420.9687) = 0
    Deceptive: second best local optimum is far from global.
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-500.0, 500.0))

    def __call__(self, x):
        return float(418.9829 * self.dim - np.sum(x * np.sin(np.sqrt(np.abs(x)))))


class Griewank(BenchmarkFunction):
    """Griewank function:
    f(x) = sum(x_i^2)/4000 - prod(cos(x_i/sqrt(i))) + 1
    Global minimum: f(0) = 0
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-600.0, 600.0))

    def __call__(self, x):
        i = np.arange(1, self.dim + 1)
        sum_term = np.sum(x ** 2) / 4000.0
        prod_term = np.prod(np.cos(x / np.sqrt(i)))
        return float(sum_term - prod_term + 1.0)


class Levy(BenchmarkFunction):
    """Levy function:
    w_i = 1 + (x_i - 1)/4
    f(x) = sin^2(pi*w_1) + sum_{i=1}^{D-1} (w_i - 1)^2 * (1 + 10*sin^2(pi*w_i + 1))
           + (w_D - 1)^2 * (1 + sin^2(2*pi*w_D))
    Global minimum: f(1,...,1) = 0
    """

    def __init__(self, dim):
        super().__init__(dim, bounds=(-10.0, 10.0))

    def __call__(self, x):
        w = 1.0 + (x - 1.0) / 4.0
        term1 = np.sin(np.pi * w[0]) ** 2
        term2 = np.sum((w[:-1] - 1.0) ** 2 * (1.0 + 10.0 * np.sin(np.pi * w[:-1] + 1.0) ** 2))
        term3 = (w[-1] - 1.0) ** 2 * (1.0 + np.sin(2.0 * np.pi * w[-1]) ** 2)
        return float(term1 + term2 + term3)


def get_benchmark(name, dim):
    """Factory function to get benchmark by name."""
    benchmarks = {
        'Sphere': Sphere,
        'Rastrigin': Rastrigin,
        'Ackley': Ackley,
        'Rosenbrock': Rosenbrock,
        'Schwefel': Schwefel,
        'Griewank': Griewank,
        'Levy': Levy,
    }
    if name not in benchmarks:
        raise ValueError(f"Unknown benchmark: {name}. Available: {list(benchmarks.keys())}")
    return benchmarks[name](dim)


def get_all_benchmarks(dim):
    """Return list of all 7 benchmark functions."""
    names = ['Sphere', 'Rastrigin', 'Ackley', 'Rosenbrock', 'Schwefel', 'Griewank', 'Levy']
    return [(name, get_benchmark(name, dim)) for name in names]


if __name__ == '__main__':
    # Quick sanity test
    for name, func in get_all_benchmarks(5):
        lb, ub = func.get_bounds()
        x0 = np.random.uniform(lb, ub)
        # Test global optimum (approximate)
        if name == 'Rosenbrock':
            x_opt = np.ones(5)
        elif name == 'Schwefel':
            x_opt = np.full(5, 420.9687)
        else:
            x_opt = np.zeros(5)
        print(f"{name:12s}: f(random)={func(x0):.4e}, f(opt~)={func(x_opt):.4e}, bounds=[{lb[0]:.0f},{ub[0]:.0f}]")

# -*- coding: utf-8 -*-
"""
Paired experiments for the Universal Proposal Correction Layer (UPCL).

For every (host, function, run) triple the same seed is used for the two
arms:

    arm O :  H                       (unmodified host)
    arm U :  H + UPCL                (host with the external correction layer)

Both arms consume the same evaluation budget: UPCL replaces the proposal
instead of adding a candidate, so one evaluation is spent per target vector
in either arm.  UPCL draws from its own random stream, therefore the host's
random sequence is untouched and the two arms start from the identical
initial population (common random numbers).
"""

import os
import json
import time
import numpy as np
from pathlib import Path
from collections import defaultdict

from de_hosts import get_host, get_all_host_names
from benchmarks import get_benchmark
from upcl_framework import UPCLController, ACTION_NAMES


# ===========================================================================
# Reporting convention
# ===========================================================================
# Improvements are reported in orders of magnitude (decades) of the median
# best-so-far, not as a percentage of a quantity that converges to zero.
# FLOOR caps the credit an arm receives for going below the numerical
# resolution of the search; see UPCLPairedExperiment.gain_decades.
FLOOR = 1e-8


def gain_decades(orig, corr, floor=FLOOR):
    """Orders of magnitude by which ``corr`` beats ``orig`` (median based)."""
    o = float(np.median(orig))
    u = float(np.median(corr))
    return float(np.log10(max(o, floor)) - np.log10(max(u, floor)))


# ===========================================================================
# Single-run driver
# ===========================================================================
def run_host_with_optional_upcl(host_name, fobj, dim, lb, ub, seed,
                                max_evals, use_upcl=False,
                                upcl_config=None, pop_size=None):
    """Run one host instance, with or without the correction layer."""
    host = get_host(host_name, dim, lb, ub, seed=seed, pop_size=pop_size)
    conv, nevs = [], []
    controller = None

    if use_upcl:
        # Own RNG stream: the host's random sequence is never consumed by UPCL.
        controller = UPCLController(dim, lb, ub, seed=seed + 977,
                                    config=upcl_config)
        host.gen_begin_fn = controller.begin_generation
        host.proposal_fn = controller.propose
        host.post_eval_fn = controller.observe

    def cb(h):
        conv.append(h.best_so_far)
        nevs.append(h.nevals)

    t0 = time.time()
    best_f, best_x, curve, evec = host.run(fobj, max_evals, callback=cb)
    elapsed = time.time() - t0

    if len(conv) == 0:
        conv = curve.tolist()
        nevs = evec.tolist()

    out = {
        'best_f': float(best_f),
        'convergence': list(conv),
        'evals': list(nevs),
        'wall_time_s': float(elapsed),
        'final_nevals': int(nevs[-1]) if len(nevs) else 0,
        'host_name': host_name,
        'use_upcl': bool(use_upcl),
        'seed': int(seed),
        'dim': int(dim),
    }
    if controller is not None:
        out['upcl'] = controller.stats()
    return out


# ===========================================================================
# Paired experiment driver
# ===========================================================================
class UPCLPairedExperiment:
    """Paired (H vs. H+UPCL) evaluation over hosts x functions x runs."""

    def __init__(self, dim=10, n_runs=8, max_evals=20000,
                 host_names=None, func_names=None, pop_size=None,
                 upcl_config=None, results_dir='results/upcl',
                 seed_base=20240001):
        self.dim = dim
        self.n_runs = n_runs
        self.max_evals = max_evals
        self.host_names = host_names if host_names else get_all_host_names()
        self.func_names = func_names if func_names else [
            'Sphere', 'Rastrigin', 'Ackley', 'Rosenbrock',
            'Schwefel', 'Griewank', 'Levy']
        self.pop_size = pop_size
        self.upcl_config = upcl_config
        self.seed_base = seed_base
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    def _seed_for(self, host_name, func_name, run_id):
        h = sum(ord(c) for c in host_name)
        f = sum(ord(c) for c in func_name)
        return self.seed_base + run_id * 100003 + h * 101 + f

    # ------------------------------------------------------------------
    def run_all(self, verbose=True):
        all_results = []
        total = len(self.host_names) * len(self.func_names) * self.n_runs * 2
        count = 0
        t_start = time.time()

        for host_name in self.host_names:
            for func_name in self.func_names:
                func = get_benchmark(func_name, self.dim)
                lb, ub = func.get_bounds()
                pair_orig, pair_upcl = [], []

                for run_id in range(self.n_runs):
                    seed = self._seed_for(host_name, func_name, run_id)

                    r_o = run_host_with_optional_upcl(
                        host_name, func, self.dim, lb, ub, seed,
                        self.max_evals, use_upcl=False, pop_size=self.pop_size)
                    r_o['func_name'] = func_name
                    r_o['run_id'] = run_id
                    pair_orig.append(r_o)
                    all_results.append(r_o)
                    count += 1

                    r_u = run_host_with_optional_upcl(
                        host_name, func, self.dim, lb, ub, seed,
                        self.max_evals, use_upcl=True,
                        upcl_config=self.upcl_config, pop_size=self.pop_size)
                    r_u['func_name'] = func_name
                    r_u['run_id'] = run_id
                    pair_upcl.append(r_u)
                    all_results.append(r_u)
                    count += 1

                    if verbose:
                        pct = 100.0 * count / total
                        dec = (np.log10(max(r_o['best_f'], FLOOR))
                               - np.log10(max(r_u['best_f'], FLOOR)))
                        rho = r_u.get('upcl', {}).get('policy_rate', 0.0)
                        el = time.time() - t_start
                        eta = el / max(count, 1) * (total - count)
                        print(f"[{pct:5.1f}%] {host_name:>10s} {func_name:11s} "
                              f"r{run_id:02d}: orig={r_o['best_f']:.3e} "
                              f"upcl={r_u['best_f']:.3e} dec={dec:+6.2f} "
                              f"rho={rho:.3f} | {el:.0f}s eta={eta:.0f}s",
                              flush=True)

                pair_obj = {
                    'host': host_name, 'func': func_name, 'dim': self.dim,
                    'max_evals': self.max_evals,
                    'original': pair_orig, 'corrected': pair_upcl,
                }
                fname = (self.results_dir /
                         f"pair_{host_name.replace('/', '_')}_{func_name}_D{self.dim}.json")
                with open(fname, 'w', encoding='utf-8') as f:
                    json.dump(pair_obj, f, indent=1, default=str)

        summary = self.aggregate(all_results)
        with open(self.results_dir / f'summary_D{self.dim}.json', 'w',
                  encoding='utf-8') as f:
            json.dump(summary, f, indent=2, default=str)
        self.print_summary(summary)
        return all_results, summary

    # ------------------------------------------------------------------
    gain_decades = staticmethod(gain_decades)

    def aggregate(self, all_results):
        orig_map, upcl_map = defaultdict(dict), defaultdict(dict)
        for r in all_results:
            key = (r['host_name'], r['func_name'])
            slot = r['run_id']
            (upcl_map if r['use_upcl'] else orig_map)[key][slot] = r

        summary = []
        for key in sorted(set(list(orig_map) + list(upcl_map))):
            hn, fn = key
            o = np.array([orig_map[key][i]['best_f'] for i in sorted(orig_map[key])])
            u = np.array([upcl_map[key][i]['best_f'] for i in sorted(upcl_map[key])])
            diffs = o - u                      # positive => UPCL better
            try:
                from scipy.stats import wilcoxon
                if np.any(diffs != 0):
                    p_two = float(wilcoxon(u, o, zero_method='wilcox',
                                           alternative='two-sided').pvalue)
                    med = float(np.median(diffs))
                    direction = ('win' if med > 0 else 'loss' if med < 0 else 'neutral') \
                        if p_two < 0.05 else 'neutral'
                else:
                    p_two, med, direction = 1.0, 0.0, 'neutral'
                cohen_d = float(np.mean(diffs) / (np.std(diffs, ddof=1) + 1e-30))
            except Exception:
                p_two, med, direction, cohen_d = float('nan'), 0.0, 'neutral', float('nan')

            rho = np.mean([upcl_map[key][i].get('upcl', {}).get('policy_rate', 0.0)
                           for i in sorted(upcl_map[key])])
            rho_all = np.mean([upcl_map[key][i].get('upcl', {}).get('intervention_rate', 0.0)
                               for i in sorted(upcl_map[key])])
            shift = np.mean([upcl_map[key][i].get('upcl', {}).get('mean_relative_shift', 0.0)
                             for i in sorted(upcl_map[key])])
            om, um = float(np.mean(o)), float(np.mean(u))
            summary.append({
                'host': hn, 'func': fn,
                'orig_mean': om, 'orig_median': float(np.median(o)),
                'upcl_mean': um, 'upcl_median': float(np.median(u)),
                'improvement_pct': float((om - um) / (abs(om) + 1e-30) * 100.0),
                # Primary aggregate: orders of magnitude gained, median based.
                'gain_dec': self.gain_decades(o, u),
                'improved_runs': int(np.sum(u < o)),
                'total_runs': int(len(o)),
                'wilcoxon_p_two_sided': p_two,
                'result_direction': direction,
                'cohen_d': cohen_d,
                'intervention_rate': float(rho_all),
                'policy_rate': float(rho),
                'mean_relative_shift': float(shift),
            })
        return summary

    # ------------------------------------------------------------------
    def print_summary(self, summary):
        print("\n" + "=" * 118)
        print(f"UPCL paired summary :: D={self.dim}, max_evals={self.max_evals}, "
              f"n_runs={self.n_runs}")
        print("=" * 118)
        print(f"{'Host':>10s} {'Func':>11s} {'OrigMed':>12s} {'+UPCLMed':>12s} "
              f"{'dec':>7s} {'Imp%':>9s} {'Wins':>7s} {'p':>8s} {'rho':>6s} "
              f"{'dir':>8s}")
        print("-" * 118)
        per_host = defaultdict(list)
        for r in summary:
            print(f"{r['host']:>10s} {r['func']:>11s} {r['orig_median']:>12.4e} "
                  f"{r['upcl_median']:>12.4e} {r.get('gain_dec', float('nan')):>+7.3f} "
                  f"{r['improvement_pct']:>+8.2f}% "
                  f"{r['improved_runs']:>3d}/{r['total_runs']:<2d} "
                  f"{r['wilcoxon_p_two_sided']:>8.4f} "
                  f"{r['policy_rate']:>6.3f} {r['result_direction']:>8s}")
            per_host[r['host']].append(r)
        print("-" * 118)
        print(f"{'Host':>10s} {'meanDec':>9s} {'medDec':>8s} {'#Imp':>7s} "
              f"{'#Sig':>6s} {'meanRho':>8s}   (Imp% shown for reference only)")
        tot_imp = tot_sig = 0
        for hn, rows in per_host.items():
            dec = np.mean([r.get('gain_dec', 0.0) for r in rows])
            dec_med = np.median([r.get('gain_dec', 0.0) for r in rows])
            om = np.mean([r['orig_mean'] for r in rows])
            um = np.mean([r['upcl_mean'] for r in rows])
            imp = (om - um) / (abs(om) + 1e-30) * 100
            n_imp = sum(1 for r in rows if r.get('gain_dec', 0.0) > 0)
            n_sig = sum(1 for r in rows if r['wilcoxon_p_two_sided'] < 0.05)
            rho = np.mean([r['policy_rate'] for r in rows])
            tot_imp += n_imp
            tot_sig += n_sig
            print(f"{hn:>10s} {dec:>+9.3f} {dec_med:>+8.3f} "
                  f"{n_imp:>4d}/{len(rows):<2d} {n_sig:>3d}/{len(rows):<2d} "
                  f"{rho:>8.3f}   {imp:+9.1f}%")
        print("-" * 118)
        print(f"TOTAL improved: {tot_imp}/{len(summary)}   "
              f"significant (p<0.05): {tot_sig}/{len(summary)}   "
              f"mean decades {np.mean([r.get('gain_dec', 0.0) for r in summary]):+.3f}")
        print()


# ===========================================================================
# Configuration presets
# ===========================================================================
UPCL_CONFIGS = {
    # Default operating point used in the paper: exploration confined to the
    # early phase and a high bar for intervening.
    'default': {
        'lam': 0.9, 'margin': 0.20, 'margin_adapt': 0.6,
        'ucb_kappa': 0.35,
        'eps0': 0.15, 'eps_min': 0.0, 'eps_gens': 60,
    },
    # Aggressive operating point: low bar, exploration never switched off.
    # Used as the ablation that motivates the minimal-intervention principle.
    'aggressive': {
        'lam': 0.25, 'margin': 0.05, 'margin_adapt': 0.0,
        'ucb_kappa': 0.10,
        'eps0': 0.25, 'eps_min': 0.05, 'eps_gens': 300,
    },
    # Aggressive + P 禁用：与 aggressive 完全相同的解锁参数（低 margin、探索
    # 常开），仅关闭投影(P)，用于归因 aggressive 的负优化是否主要由 P 主导
    # （对比 aggressive_no_project vs aggressive vs bare）。
    'aggressive_no_project': {
        'lam': 0.25, 'margin': 0.05, 'margin_adapt': 0.0,
        'ucb_kappa': 0.10,
        'eps0': 0.25, 'eps_min': 0.05, 'eps_gens': 300,
        'disable_actions': ('P',),
    },
    # margin 中间态扫描：保持 aggressive 的常开探索(eps 不衰减)与低干预成本
    # (lam/ucb 低)，仅逐步抬高 identity 的保护裕度 margin，验证 minimal-
    # intervention 假说——是否存在一个"低频但有效"的干预率区间。
    # aggressive 为 margin=0.05(干预率~70%，负优化)；default 为 margin=0.20
    # +adapt(干预率~0，中性)。中间态 margin=0.10/0.15 应产生 10~40% 的中间
    # 干预率，用于定位"最小干预"的最优点是否存在。
    'aggressive_margin10': {
        'lam': 0.25, 'margin': 0.10, 'margin_adapt': 0.0,
        'ucb_kappa': 0.10,
        'eps0': 0.25, 'eps_min': 0.05, 'eps_gens': 300,
    },
    'aggressive_margin15': {
        'lam': 0.25, 'margin': 0.15, 'margin_adapt': 0.0,
        'ucb_kappa': 0.10,
        'eps0': 0.25, 'eps_min': 0.05, 'eps_gens': 300,
    },
    # 根因验证：aggressive 的负优化是否来自"r_hat 对几何扰动(P/C)收益的
    # 系统性高估"。descriptor_mask 只保留 theta_align（唯一在 DE 上普适为正
    # 的信号），剔除 rho_step/kappa_crowd/nu_novel 等在 DE/rand/1 上判别方向
    # 反转的分量，看 P 的选中率是否回落、dec 是否转正。
    'aggressive_mild_theta': {
        'lam': 0.25, 'margin': 0.05, 'margin_adapt': 0.0,
        'ucb_kappa': 0.10,
        'eps0': 0.25, 'eps_min': 0.05, 'eps_gens': 300,
        'contract': 0.7, 'expand': 1.4,
        'descriptor_mask': (0, 1, 0, 0, 0),
    },
    # Single-factor ablations.  Each one removes exactly one term of the
    # decision rule Q(z,a) = r_hat - lambda*c(a) - kappa_u/sqrt(1+n_eff)
    # + mu_t*1[a=I] so that the observed difference can be attributed to it.
    'no_margin': {'margin_adapt': 0.0},     # mu_t = mu_0 (constant bar)
    'no_cost': {'lam': 0.0},                # corrections are free
    'no_uncert': {'ucb_kappa': 0.0},        # act on thin evidence
    # Kept for reference: several terms changed at once, so the difference is
    # not attributable to any single one.
    'no_minimal': {'lam': 0.0, 'margin': 0.0},
    # Ablation A1: no response memory (always identity + exploration only).
    'no_memory': {'mem_capacity': 1, 'prior_strength': 0.0},
    # Ablation A2: no exploration (pure exploitation of the response model).
    'no_explore': {'eps0': 0.0, 'eps_min': 0.0},
    # Conservative operating point: exploration confined to the early phase,
    # high intervention bar.  Used to keep the layer neutral on hosts that
    # already adapt their own step size.
    'conservative': {
        'lam': 0.9, 'margin': 0.20, 'margin_adapt': 0.6,
        'ucb_kappa': 0.35,
        'eps0': 0.15, 'eps_min': 0.0, 'eps_gens': 60,
    },
    # Random-correction control (Exp4).  The response model is removed and
    # every proposal receives an action drawn uniformly from the complete
    # action set {I, C, E, R, P}, i.e. probability 1/5 each.  The geometric
    # transforms are the ones of the full layer, so the *perturbation* is
    # present in this arm exactly as in the full one; what is removed is the
    # choice, i.e. the online response model that decides which transform
    # fits the descriptor of the current proposal.  Full-vs-random therefore
    # separates "perturbing a proposal helps" from "choosing the perturbation
    # online helps".  The control is deliberately strong: it corrects 4/5 of
    # all proposals, roughly eight times the rate of the full layer, so a win
    # of the full layer cannot be explained away by it perturbing more.
    'random': {
        'mem_capacity': 1, 'prior_strength': 0.0,
        'lam': 0.0, 'margin': 0.0, 'margin_adapt': 0.0, 'ucb_kappa': 0.0,
        'eps0': 1.0, 'eps_min': 1.0,
        'explore_weights': (0.2, 0.2, 0.2, 0.2, 0.2),
    },
    # 方案1验证：停滞感知反射。非停滞时与 default 行为完全一致；
    # 一旦种群最优连续 stagnation_window 代无改善（停滞），反射/扩张的
    # 成本从封印值降到 stagnation_*_cost，让响应模型在停滞时有机会
    # 尝试反射跳出局部最优。default 配置不含这些开关，行为不变。
    'stagnation_reflect': {
        'stagnation_enable': True,
        'stagnation_window': 30,
        'stagnation_tol': 1e-12,
        'stagnation_reflect_cost': 0.5,
        'stagnation_expand_cost': 0.4,
        'stagnation_reflect_bonus': 0.8,
        'stagnation_expand_bonus': 0.5,
    },
    # 正确机制候选：停滞感知的大幅扩张。DE 停滞的本质是差分向量
    # F*(x_r2-x_r3) 坍缩，反射(翻转已坍缩的 d)无意义，唯一能真正跳出的是
    # 把坍缩的步长临时放大(stagnation_expand_factor=3.0)，等效于在停滞时
    # 恢复差分向量的有效长度。反射保持封印(cost 2.0 / bonus 0)，只解锁
    # 大幅扩张 E，以干净归因"停滞扩张"本身的效果。非停滞期继承 default
    # 的高门槛(干预率≈0)，保护 DE 的无偏探索。
    'stagnation_expand': {
        'stagnation_enable': True,
        'stagnation_window': 30,
        'stagnation_tol': 1e-12,
        'stagnation_expand_factor': 3.0,
        'stagnation_expand_cost': 0.3,
        'stagnation_expand_bonus': 0.6,
        'stagnation_reflect_cost': 2.0,
        'stagnation_reflect_bonus': 0.0,
        # 封印 P/C/R：只保留 I 与 E。避免 stagnation_reflect 在 F2 上出现的
        # "停滞期 P 风暴"（r_hat 高估投影导致 59 万次投影、dec -7.43）。
        # 探索期 E 仍是 1.4×（接近恒等、影响极小），仅积累 E 的响应样本；
        # 停滞期 E 用 stagnation_expand_factor=3.0 大幅扩张，等效于恢复
        # 坍缩差分向量的有效长度，实现"步长重启"跳出局部最优。
        'disable_actions': ('P', 'C', 'R'),
    },
    # 定向重启：停滞时沿运行成功方向 s_hat 做"大步长投影"（而非 E 那种无
    # 方向的随机放大）。Rastrigin 等函数的局部最优是"深且窄"的，无方向大
    # 跳跃(stagnation_expand)跳不出去；而 s_hat 累积的是此前持续下降的方
    # 向，沿它大步跳跃更可能逃离当前盆地。只留 I 与 P，探索期 P 保持原步长
    # (factor=1.0)且被 default 高 margin 压住≈pass-through，停滞期 P 步长
    # ×3.0 并加乐观 bonus 使其真正被选中。
    'stagnation_project': {
        'stagnation_enable': True,
        'stagnation_window': 30,
        'stagnation_tol': 1e-12,
        'stagnation_project_factor': 3.0,
        'stagnation_project_bonus': 1.2,
        'disable_actions': ('C', 'E', 'R'),
    },
    # 描述子精简：只保留 theta_align 与 eta_elite 两个普适正信号，
    # 移除宿主相关的 rho_step / kappa_crowd / nu_novel（这些在 DE/rand/1、
    # DE/rand/2 上判别方向反转为负，见 exp5_descriptor_influence）。
    'desc_theta_eta': {'descriptor_mask': (0, 1, 1, 0, 0)},
    # 温和几何：收缩/扩张更保守，减少激进几何扰动带来的 worse。
    'mild_geometry': {'contract': 0.7, 'expand': 1.4},
    # 温和几何参数扫描 + 与描述子精简的组合（用于锁定最优）。
    'mild2_geometry': {'contract': 0.8, 'expand': 1.3},
    'mild3_geometry': {'contract': 0.6, 'expand': 1.5},
    'mild_desc': {'contract': 0.7, 'expand': 1.4, 'descriptor_mask': (0, 1, 1, 0, 0)},
    # 描述子进一步收紧：eta_elite 在策略集成类宿主(MPEDE/SaDE)上反转为负，
    # 只保留唯一普适正信号 theta_align，配合温和几何锁定劣化场景。
    'mild_theta': {'contract': 0.7, 'expand': 1.4, 'descriptor_mask': (0, 1, 0, 0, 0)},
    # 方案1：ARD 自动相关性。去掉手工 descriptor_mask（含 mild_theta 的硬掩码），
    # 改由每个 host×function 独立在线学习各描述子分量的相关性（逐分量带宽）。
    # 几何保持 default（contract=0.7/expand=1.4），以单独测量 ARD 本身的贡献。
    'ard': {'ard_enable': True},
    # P/C 消融：分别禁用投影(P)与收缩(C)，定位 worse 的病灶动作。
    'no_project': {'disable_actions': ('P',)},
    'no_contract': {'disable_actions': ('C',)},
}


def get_config(name='default'):
    cfg = dict(UPCL_CONFIGS['default'])
    if name != 'default':
        cfg.update(UPCL_CONFIGS[name])
    return cfg

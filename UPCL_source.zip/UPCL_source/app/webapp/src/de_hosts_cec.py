# -*- coding: utf-8 -*-
"""Fourteen additional DE variants, to bring the host pool to twenty.

The six hosts already implemented in ``de_hosts`` are DE/rand/1, JADE,
SHADE, L-SHADE, CoBiDE and jSO.  The variants added here were chosen to
span the four generations of DE that a reviewer of the UPCL paper will
expect to see, and to include the recent competition winners:

* classical fixed-parameter schemes (best/1, rand/2, current-to-best/1,
  current-to-rand/1, rand/1/either-or);
* self-adaptive parameters (jDE, SaNSDE);
* adaptive strategy / parameter ensembles (SaDE, EPSDE, CoDE, MPEDE);
* linear-population-size-reduction and rank-based families
  (L-SHADE-RSP, NL-SHADE-RSP, MadDE).

Every host is a subclass of ``DifferentialEvolution`` and therefore exposes
exactly the three UPCL hooks, so the layer is attached the same way to all
of them.  Where an algorithm needs a non-standard evaluation step (CoDE
generates three candidate vectors per target), the step is re-implemented
here *through* the hooks, so the layer still sees and corrects every
proposal.

Populations follow each algorithm's own published setting; no host is tuned
per problem.
"""
import numpy as np

from de_hosts import (
    ClassicDE, DifferentialEvolution, JADE, LSHADE, SHADE, STRATEGY_BEST1,
    STRATEGY_BEST2, STRATEGY_CURRENT_TO_BEST1, STRATEGY_CURRENT_TO_PBEST,
    STRATEGY_CURRENT_TO_RAND, STRATEGY_EITHER_OR, STRATEGY_RAND1,
    STRATEGY_RAND2, strategy_mutate,
)


# ===========================================================================
# Classical fixed-parameter schemes
# ===========================================================================
class DEBest1(ClassicDE):
    """DE/best/1/bin."""
    name = "DE/best/1"

    def _get_strategy(self, i, override):
        return STRATEGY_BEST1


class DERand2(ClassicDE):
    """DE/rand/2/bin."""
    name = "DE/rand/2"

    def _get_strategy(self, i, override):
        return STRATEGY_RAND2


class DECurrentToBest1(ClassicDE):
    """DE/current-to-best/1/bin."""
    name = "DE/current-to-best/1"

    def _get_strategy(self, i, override):
        return STRATEGY_CURRENT_TO_BEST1


class DECurrentToRand1(ClassicDE):
    """DE/current-to-rand/1."""
    name = "DE/current-to-rand/1"

    def _get_strategy(self, i, override):
        return STRATEGY_CURRENT_TO_RAND


class DEEitherOr(ClassicDE):
    """DE/rand/1/either-or (Price, Storn & Lampinen 2005).

    Each generation the trial vector is either the plain rand/1 mutant or the
    variant scaled by ``K = 0.5 (F + 1)``; crossover is not applied in either
    branch.  Only one candidate is produced, so the evaluation count per
    individual is the usual one.
    """
    name = "DE/rand/1/either-or"

    def _sample_params(self, i):
        return self.F_fixed, 1.0

    def _get_strategy(self, i, override):
        return STRATEGY_EITHER_OR


# ===========================================================================
# Self-adaptive parameters
# ===========================================================================
class jDE(DifferentialEvolution):
    """jDE (Brest et al. 2006): self-adaptive F and CR per individual."""
    name = "jDE"

    def __init__(self, dim, lb, ub, pop_size=None, F=0.5, CR=0.9,
                 tau1=0.1, tau2=0.1, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.F_arr = np.full(self.N, F)
        self.CR_arr = np.full(self.N, CR)
        self.tau1, self.tau2 = tau1, tau2

    def _sample_params(self, i):
        if self.rng.random() < self.tau1:
            self.F_arr[i] = 0.1 + 0.9 * self.rng.random()
        if self.rng.random() < self.tau2:
            self.CR_arr[i] = self.rng.random()
        return self.F_arr[i], self.CR_arr[i]

    def _get_strategy(self, i, override):
        return STRATEGY_RAND1

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)


class SaNSDE(DifferentialEvolution):
    """SaNSDE (Yang, Tang & Yao 2008): self-adaptive NSDE.

    Mutation is rand/1 or current-to-best/1 with an adapted mixing
    probability; F is drawn from a Gaussian (with a Cauchy fallback) and CR
    from a Gaussian centred on an adapted mean.
    """
    name = "SaNSDE"

    def __init__(self, dim, lb, ub, pop_size=None, lp=50, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.lp = lp
        self.F_arr = np.full(self.N, 0.5)
        self.CR_arr = np.full(self.N, 0.5)
        self.CRm = 0.5
        self.prob = 0.5                       # P(current-to-best/1)
        self._ns1 = self._nf1 = 0             # successes / trials, strategy 1
        self._ns2 = self._nf2 = 0
        self._cr_pool = []
        self._g = 0

    def _sample_params(self, i):
        self.F_arr[i] = 0.5 + 0.3 * self.rng.standard_normal()
        self.CR_arr[i] = np.clip(self.CRm + 0.1 * self.rng.standard_normal(),
                                 0.0, 1.0)
        return self.F_arr[i], self.CR_arr[i]

    def _get_strategy(self, i, override):
        return (STRATEGY_CURRENT_TO_BEST1 if self.rng.random() < self.prob
                else STRATEGY_RAND1)

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            self._cr_pool.append(CR)

    def _generation_end_update(self):
        self._g += 1
        if self._g % self.lp == 0 and self._cr_pool:
            self.CRm = float(np.mean(self._cr_pool))
            self._cr_pool = []


# ===========================================================================
# Adaptive strategy / parameter ensembles
# ===========================================================================
class SaDE(DifferentialEvolution):
    """SaDE (Qin & Suganthan 2005): strategy pool with probability learning.

    CR is Gaussian around an adapted mean, F is Gaussian(0.5, 0.3); the
    mutation strategy is sampled from a pool whose probabilities are
    refreshed every ``lp`` generations from the recorded success rates.
    """
    name = "SaDE"

    def __init__(self, dim, lb, ub, pop_size=None, lp=50, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.lp = lp
        self.strategies = [STRATEGY_RAND1, STRATEGY_CURRENT_TO_BEST1,
                           STRATEGY_RAND2, STRATEGY_CURRENT_TO_RAND]
        self.ns = len(self.strategies)
        self.prob = np.ones(self.ns) / self.ns
        self.CRm, self.CRsigma = 0.5, 0.1
        self._cr_good = []
        self._succ = np.zeros(self.ns)
        self._fail = np.zeros(self.ns)
        self._used = np.zeros(self.ns)
        self._g = 0
        self._cur = np.zeros(self.N, dtype=int)

    def _sample_params(self, i):
        F = 0.5 + 0.3 * self.rng.standard_normal()
        while F <= 0:
            F = 0.5 + 0.3 * self.rng.standard_normal()
        CR = np.clip(self.rng.normal(self.CRm, self.CRsigma), 0.0, 1.0)
        return F, CR

    def _get_strategy(self, i, override):
        k = int(self.rng.choice(self.ns, p=self.prob))
        self._cur[i] = k
        self._used[k] += 1
        return self.strategies[k]

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        k = self._cur[i]
        if accepted and fu < f_old:
            self._succ[k] += 1
            self._cr_good.append(CR)
        else:
            self._fail[k] += 1

    def _generation_end_update(self):
        self._g += 1
        if self._g % self.lp != 0:
            return
        tot = self._succ + self._fail
        if tot.sum() > 0:
            s = self._succ / np.maximum(tot, 1)
            s = s + 0.01                       # keep every strategy alive
            self.prob = s / s.sum()
        self._succ[:] = 0.0
        self._fail[:] = 0.0
        if self._cr_good:
            self.CRm = float(np.mean(self._cr_good))
            self._cr_good = []


class EPSDE(DifferentialEvolution):
    """EPSDE (Mallipeddi et al. 2011): ensemble of (F, CR, strategy) triples.

    Each individual owns a pool index.  Losers either inherit the index of a
    successful neighbour or are re-drawn uniformly from the pool.
    """
    name = "EPSDE"

    def __init__(self, dim, lb, ub, pop_size=None, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.pool_F = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
        self.pool_CR = [0.1, 0.2, 0.3, 0.6, 0.8, 0.9]
        self.pool_S = [STRATEGY_RAND1, STRATEGY_BEST1, STRATEGY_RAND2,
                       STRATEGY_CURRENT_TO_BEST1, STRATEGY_CURRENT_TO_RAND,
                       STRATEGY_BEST2]
        self.npool = len(self.pool_F)
        self.idx = self.rng.integers(0, self.npool, size=self.N)
        self._age = np.zeros(self.N, dtype=int)

    def _sample_params(self, i):
        k = self.idx[i]
        return self.pool_F[k], self.pool_CR[k]

    def _get_strategy(self, i, override):
        return self.pool_S[self.idx[i]]

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            self._age[i] += 1
        else:
            self._age[i] = 0
            # imitate a successful individual, else resample the pool
            if self.rng.random() < 0.5 and self._age.max() > 0:
                j = int(np.argmax(self._age))
                self.idx[i] = self.idx[j]
            else:
                self.idx[i] = int(self.rng.integers(0, self.npool))


class CoDE(DifferentialEvolution):
    """CoDE (Wang, Cai & Zhang 2011): composite trial-vector generation.

    Three candidates are produced per target with fixed (F, CR, strategy)
    settings; the best of the three competes with the target.  This costs
    three evaluations per individual per generation, which is a property of
    the algorithm itself and is identical in both arms of the paired
    experiment.
    """
    name = "CoDE"

    SETTINGS = [(1.0, 0.1, STRATEGY_RAND1),
                (1.0, 0.9, STRATEGY_RAND2),
                (0.8, 0.2, STRATEGY_CURRENT_TO_RAND)]

    def __init__(self, dim, lb, ub, pop_size=None, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)

    def _sample_params(self, i):
        return self.SETTINGS[0][0], self.SETTINGS[0][1]

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _generation_step(self, fobj):
        """Three candidates per target, each one routed through the hooks."""
        # (a) refresh the population-level context of the external layer
        if self.gen_begin_fn is not None:
            self.gen_begin_fn(self.pop, self.fitness)
        best_before = self.best_so_far
        for i in range(self.N):
            if self.nevals >= self._get_budget_ceiling():
                break
            x_old, f_old = self.pop[i].copy(), self.fitness[i]
            best_u, best_fu = None, np.inf
            for (F, CR, strat) in self.SETTINGS:
                F = float(np.clip(F, 1e-4, 2.0))
                v = strategy_mutate(strat, i, self.pop, self.fitness, F,
                                    self.lb, self.ub, archive=None,
                                    pbest_idx=self.best_idx, rng=self.rng,
                                    best_idx=self.best_idx)
                u = self._crossover(i, self.pop[i], v, CR)
                if self.proposal_fn is not None:
                    u = self.proposal_fn(self.pop[i], u, f_old)
                fu = fobj(u)
                self.nevals += 1
                if self.post_eval_fn is not None:
                    self.post_eval_fn(fu)
                if fu < best_fu:
                    best_u, best_fu = u, fu
            accepted = False
            if best_fu <= f_old:
                self.pop[i] = best_u
                self.fitness[i] = best_fu
                accepted = True
            self._update_memories(i, accepted, self.SETTINGS[0][0],
                                  self.SETTINGS[0][1], best_fu, f_old)
            if self.fitness[i] < self.best_so_far:
                self.best_so_far = self.fitness[i]
                self.best_idx = i
                self.stagnation = 0
        if self.best_so_far >= best_before:
            self.stagnation += 1
        self._generation_end_update()

    def _get_strategy(self, i, override):
        return self.SETTINGS[0][2]


class MPEDE(DifferentialEvolution):
    """MPEDE (Wu et al. 2016): multi-population ensemble of strategies.

    Three indicator sub-populations, each tied to one strategy, plus a
    reward sub-population that is periodically assigned to the strategy with
    the best accumulated reward.
    """
    name = "MPEDE"

    def __init__(self, dim, lb, ub, pop_size=None, ng=20, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.ng = ng
        self.strategies = [STRATEGY_CURRENT_TO_PBEST, STRATEGY_CURRENT_TO_RAND,
                           STRATEGY_RAND1]
        self.ns = len(self.strategies)
        n_ind = max(1, int(self.N / (self.ns + 1)))
        self.n_ind = n_ind
        self.group = np.full(self.N, self.ns)          # default: reward pop
        for k in range(self.ns):
            self.group[k * n_ind:(k + 1) * n_ind] = k
        self.reward = np.zeros(self.ns)
        self.success = np.zeros(self.ns)
        self.trial = np.ones(self.ns)
        self._g = 0
        self.M_F = np.full(6, 0.5)
        self.M_CR = np.full(6, 0.5)
        self.k_mem = 0
        self._sF, self._sCR, self._sd = [], [], []

    def _sample_pbest_indices(self):
        top_k = max(2, int(0.1 * self.N))
        order = np.argsort(self.fitness)
        return self.rng.choice(order[:top_k], size=self.N, replace=True)

    def _sample_params(self, i):
        r = self.rng.integers(0, 6)
        F = self.M_F[r] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
        while F <= 0:
            F = self.M_F[r] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
        CR = np.clip(self.rng.normal(self.M_CR[r], 0.1), 0.0, 1.0)
        return F, CR

    def _get_strategy(self, i, override):
        g = int(self.group[i])
        return self.strategies[g] if g < self.ns else self.strategies[0]

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        g = int(self.group[i])
        if g < self.ns:
            self.trial[g] += 1
            if accepted and fu < f_old:
                self.success[g] += 1
                self.reward[g] += max(0.0, f_old - fu)
        if accepted and fu < f_old:
            self._sF.append(F)
            self._sCR.append(CR)
            self._sd.append(max(0.0, f_old - fu))

    def _generation_end_update(self):
        if self._sF:
            sF = np.asarray(self._sF)
            sCR = np.asarray(self._sCR)
            sw = np.asarray(self._sd, dtype=float)
            if sw.sum() > 0:
                w = sw / sw.sum()
                mf = np.sum(w * sF)
                self.M_F[self.k_mem] = np.sum(w * sF ** 2) / (mf + 1e-12)
                self.M_CR[self.k_mem] = np.sum(w * sCR)
            self.k_mem = (self.k_mem + 1) % 6
            self._sF, self._sCR, self._sd = [], [], []
        self._g += 1
        if self._g % self.ng != 0:
            return
        rate = self.success / np.maximum(self.trial, 1)
        best = int(np.argmax(rate))
        self.group[:] = best
        for k in range(self.ns):
            self.group[k * self.n_ind:(k + 1) * self.n_ind] = k
        self.success[:] = 0.0
        self.trial[:] = 1.0
        self.reward[:] = 0.0


# ===========================================================================
# LPSR / rank-based families
# ===========================================================================
class LSHADE_RSP(DifferentialEvolution):
    """L-SHADE-RSP (Stanovov, Akhmedova & Semenkin 2018).

    L-SHADE with rank-based selective pressure: the p-best parent is drawn
    with probability proportional to its rank rather than uniformly from the
    top pN.
    """
    name = "L-SHADE-RSP"

    def __init__(self, dim, lb, ub, pop_size=None, H=6, p=0.11,
                 archive_rate=2.6, N_min=4, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.H, self.p = H, p
        self.M_F = np.full(H, 0.5)
        self.M_CR = np.full(H, 0.5)
        self.k = 0
        self.archive_max = int(self.N * archive_rate)
        self.archive = []
        self.N_init = self.N
        self.N_min = max(4, N_min)
        self._sF, self._sCR, self._sd = [], [], []

    def _sample_pbest_indices(self):
        """Rank-based selection: linear weights over the top p*N."""
        top_k = max(2, int(self.p * self.N))
        order = np.argsort(self.fitness)[:top_k]
        w = np.arange(top_k, 0, -1).astype(float)
        w = w / w.sum()
        return self.rng.choice(order, size=self.N, replace=True, p=w)

    def _sample_params(self, i):
        r = self.rng.integers(0, self.H)
        F = -1.0
        for _ in range(20):
            F = self.M_F[r] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1:
                F = 1.0
            if F > 0:
                break
        if F <= 0:
            F = 0.5
        CR = np.clip(self.rng.normal(self.M_CR[r], 0.1), 0.0, 1.0)
        return F, CR

    def _get_strategy(self, i, override):
        return STRATEGY_CURRENT_TO_PBEST

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _maybe_archive(self, x):
        self.archive.append(x.copy())
        if len(self.archive) > self.archive_max:
            self.archive.pop(self.rng.integers(0, len(self.archive)))

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        if accepted and fu < f_old:
            self._sF.append(F)
            self._sCR.append(CR)
            self._sd.append(max(0.0, f_old - fu))

    def _generation_end_update(self):
        if self._sF:
            sF = np.asarray(self._sF)
            sCR = np.asarray(self._sCR)
            sw = np.asarray(self._sd, dtype=float)
            if sw.sum() > 0:
                w = sw / sw.sum()
                mf = np.sum(w * sF)
                self.M_F[self.k] = np.sum(w * sF ** 2) / (mf + 1e-12)
                self.M_CR[self.k] = np.sum(w * sCR)
            self.k = (self.k + 1) % self.H
            self._sF, self._sCR, self._sd = [], [], []
        if not hasattr(self, '_max_evals'):
            return
        ratio = self.nevals / self._max_evals
        n_new = max(self.N_min,
                    int(round((self.N_min - self.N_init) * ratio + self.N_init)))
        if n_new < self.N:
            keep = np.argsort(self.fitness)[:n_new]
            self.pop = self.pop[keep]
            self.fitness = self.fitness[keep]
            self.N = n_new
            self.best_idx = int(np.argmin(self.fitness))
            self.archive_max = int(self.N * 2.6)
            while len(self.archive) > self.archive_max:
                self.archive.pop(self.rng.integers(0, len(self.archive)))

    def run(self, fobj, max_evals, callback=None, record_pop_every=0):
        self._max_evals = max_evals
        return super().run(fobj, max_evals, callback, record_pop_every)


class NLSHADE_RSP(LSHADE_RSP):
    """NL-SHADE-RSP (Stanovov & Semenkin 2022): non-linear population reduction.

    The only change with respect to L-SHADE-RSP is the reduction schedule;
    here it is convex, so the population is kept large during the first half
    of the search and shrinks faster towards the end.
    """
    name = "NL-SHADE-RSP"

    def __init__(self, dim, lb, ub, pop_size=None, H=6, p=0.11,
                 archive_rate=2.6, N_min=4, exp_p=2.0, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, H=H, p=p,
                         archive_rate=archive_rate, N_min=N_min, seed=seed,
                         **kwargs)
        self.exp_p = exp_p

    def _generation_end_update(self):
        if self._sF:
            sF = np.asarray(self._sF)
            sCR = np.asarray(self._sCR)
            sw = np.asarray(self._sd, dtype=float)
            if sw.sum() > 0:
                w = sw / sw.sum()
                mf = np.sum(w * sF)
                self.M_F[self.k] = np.sum(w * sF ** 2) / (mf + 1e-12)
                self.M_CR[self.k] = np.sum(w * sCR)
            self.k = (self.k + 1) % self.H
            self._sF, self._sCR, self._sd = [], [], []
        if not hasattr(self, '_max_evals'):
            return
        ratio = self.nevals / self._max_evals
        n_new = max(self.N_min, int(round(
            (self.N_min - self.N_init) * (ratio ** self.exp_p) + self.N_init)))
        if n_new < self.N:
            keep = np.argsort(self.fitness)[:n_new]
            self.pop = self.pop[keep]
            self.fitness = self.fitness[keep]
            self.N = n_new
            self.best_idx = int(np.argmin(self.fitness))
            self.archive_max = int(self.N * 2.6)
            while len(self.archive) > self.archive_max:
                self.archive.pop(self.rng.integers(0, len(self.archive)))


class MadDE(DifferentialEvolution):
    """MadDE (Biswas et al., CEC 2021) -- simplified.

    Keeps the three ingredients that define the algorithm and that a
    reviewer will look for: a success-history memory for F and CR, a
    strategy pool with adapted probabilities, and linear population size
    reduction.  The quadratic-interpolation and distance-based components of
    the full MadDE are omitted; the variant implemented here is therefore a
    lower bound on the published algorithm, which is the conservative choice
    for a baseline.
    """
    name = "MadDE"

    def __init__(self, dim, lb, ub, pop_size=None, H=6, p=0.11,
                 archive_rate=2.6, N_min=4, seed=None, **kwargs):
        super().__init__(dim, lb, ub, pop_size=pop_size, seed=seed, **kwargs)
        self.H, self.p = H, p
        self.M_F = np.full(H, 0.5)
        self.M_CR = np.full(H, 0.5)
        self.k = 0
        self.archive_max = int(self.N * archive_rate)
        self.archive = []
        self.N_init = self.N
        self.N_min = max(4, N_min)
        self.strategies = [STRATEGY_CURRENT_TO_PBEST, STRATEGY_CURRENT_TO_RAND]
        self.ns = 2
        self.prob = np.ones(self.ns) / self.ns
        self._succ = np.zeros(self.ns)
        self._fail = np.zeros(self.ns)
        self._sF, self._sCR, self._sd = [], [], []

    def _sample_pbest_indices(self):
        top_k = max(2, int(self.p * self.N))
        order = np.argsort(self.fitness)
        return self.rng.choice(order[:top_k], size=self.N, replace=True)

    def _sample_params(self, i):
        r = self.rng.integers(0, self.H)
        F = -1.0
        for _ in range(20):
            F = self.M_F[r] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))
            if F > 1:
                F = 1.0
            if F > 0:
                break
        if F <= 0:
            F = 0.5
        CR = np.clip(self.rng.normal(self.M_CR[r], 0.1), 0.0, 1.0)
        return F, CR

    def _get_strategy(self, i, override):
        k = int(self.rng.choice(self.ns, p=self.prob))
        self._cur_k = k
        return self.strategies[k]

    def _crossover(self, i, x, v, CR):
        D = self.dim
        jr = self.rng.integers(0, D)
        mask = (self.rng.random(D) < CR) | (self._ar == jr)
        return np.where(mask, v, x)

    def _maybe_archive(self, x):
        self.archive.append(x.copy())
        if len(self.archive) > self.archive_max:
            self.archive.pop(self.rng.integers(0, len(self.archive)))

    def _update_memories(self, i, accepted, F, CR, fu, f_old):
        k = getattr(self, '_cur_k', 0)
        if accepted and fu < f_old:
            self._succ[k] += 1
            self._sF.append(F)
            self._sCR.append(CR)
            self._sd.append(max(0.0, f_old - fu))
        else:
            self._fail[k] += 1

    def _generation_end_update(self):
        if self._sF:
            sF = np.asarray(self._sF)
            sCR = np.asarray(self._sCR)
            sw = np.asarray(self._sd, dtype=float)
            if sw.sum() > 0:
                w = sw / sw.sum()
                mf = np.sum(w * sF)
                self.M_F[self.k] = np.sum(w * sF ** 2) / (mf + 1e-12)
                self.M_CR[self.k] = np.sum(w * sCR)
            self.k = (self.k + 1) % self.H
            self._sF, self._sCR, self._sd = [], [], []
        tot = self._succ + self._fail
        if tot.sum() > 0:
            s = self._succ / np.maximum(tot, 1) + 0.05
            self.prob = s / s.sum()
            self._succ[:] = 0.0
            self._fail[:] = 0.0
        if not hasattr(self, '_max_evals'):
            return
        ratio = self.nevals / self._max_evals
        n_new = max(self.N_min,
                    int(round((self.N_min - self.N_init) * ratio + self.N_init)))
        if n_new < self.N:
            keep = np.argsort(self.fitness)[:n_new]
            self.pop = self.pop[keep]
            self.fitness = self.fitness[keep]
            self.N = n_new
            self.best_idx = int(np.argmin(self.fitness))
            self.archive_max = int(self.N * 2.6)
            while len(self.archive) > self.archive_max:
                self.archive.pop(self.rng.integers(0, len(self.archive)))

    def run(self, fobj, max_evals, callback=None, record_pop_every=0):
        self._max_evals = max_evals
        return super().run(fobj, max_evals, callback, record_pop_every)


# ===========================================================================
# Registry
# ===========================================================================
EXTRA_HOSTS = {
    'DE/best/1': DEBest1,
    'DE/rand/2': DERand2,
    'DE/current-to-best/1': DECurrentToBest1,
    'DE/current-to-rand/1': DECurrentToRand1,
    'DE/rand/1/either-or': DEEitherOr,
    'jDE': jDE,
    'SaNSDE': SaNSDE,
    'SaDE': SaDE,
    'EPSDE': EPSDE,
    'CoDE': CoDE,
    'MPEDE': MPEDE,
    'L-SHADE-RSP': LSHADE_RSP,
    'NL-SHADE-RSP': NLSHADE_RSP,
    'MadDE': MadDE,
}

# Ordinal "how adaptive is this host" score, used by Exp2 to test whether
# better-adapted hosts are intervened on less by UPCL.  0 = fixed parameters,
# 1 = self-adaptive parameters, 2 = adaptive parameters and strategy,
# 3 = adaptive plus population-size control.
ADAPTIVITY = {
    'DE/rand/1': 0, 'DE/best/1': 0, 'DE/rand/2': 0,
    'DE/current-to-best/1': 0, 'DE/current-to-rand/1': 0,
    'DE/rand/1/either-or': 0,
    'jDE': 1, 'SaNSDE': 1, 'JADE': 2, 'SHADE': 2, 'CoBiDE': 2,
    'SaDE': 2, 'EPSDE': 2, 'CoDE': 2, 'MPEDE': 2,
    'L-SHADE': 3, 'jSO': 3, 'L-SHADE-RSP': 3, 'NL-SHADE-RSP': 3, 'MadDE': 3,
}

# Population sizes.  LPSR hosts need a large initial population for the
# reduction schedule to have room; the classical schemes use the usual 5D..10D.
CEC_POP_SIZE = {
    'DE/rand/1': 100, 'DE/best/1': 100, 'DE/rand/2': 100,
    'DE/current-to-best/1': 100, 'DE/current-to-rand/1': 100,
    'DE/rand/1/either-or': 100,
    'jDE': 100, 'SaNSDE': 100, 'CoBiDE': 60, 'SaDE': 100, 'EPSDE': 100,
    'CoDE': 30,                      # three evaluations per individual
    'JADE': 100, 'SHADE': 100, 'MPEDE': 100,
    'L-SHADE': '18D', 'jSO': '18D', 'L-SHADE-RSP': '18D',
    'NL-SHADE-RSP': '18D', 'MadDE': '18D',
}


def pop_size_for(host_name, dim):
    spec = CEC_POP_SIZE.get(host_name, 100)
    if spec == '18D':
        return int(18 * dim)
    return int(spec)


def register():
    """Merge the extra hosts into ``de_hosts.HOST_REGISTRY``."""
    import de_hosts
    de_hosts.HOST_REGISTRY.update(EXTRA_HOSTS)
    return de_hosts.HOST_REGISTRY


CEC_HOST_ORDER = [
    'DE/rand/1', 'DE/best/1', 'DE/rand/2', 'DE/current-to-best/1',
    'DE/current-to-rand/1', 'DE/rand/1/either-or',
    'jDE', 'SaNSDE', 'JADE', 'SHADE', 'CoBiDE', 'SaDE', 'EPSDE', 'CoDE',
    'MPEDE', 'L-SHADE', 'jSO', 'L-SHADE-RSP', 'NL-SHADE-RSP', 'MadDE',
]

# Merge wave-4 pure-DE mechanism variants.  de_hosts_wave4 only depends on
# de_hosts, so this module is fully defined before it is pulled in (no cycle).
from de_hosts_wave4 import (
    WAVE4_ADAPTIVITY, WAVE4_HOSTS, WAVE4_ORDER, WAVE4_POP_SIZE,
)
EXTRA_HOSTS.update(WAVE4_HOSTS)
ADAPTIVITY.update(WAVE4_ADAPTIVITY)
CEC_POP_SIZE.update(WAVE4_POP_SIZE)
CEC_HOST_ORDER.extend(WAVE4_ORDER)

# ---------------------------------------------------------------------------
# 黑盒插件（客户自定义算法，黑盒可执行协议）。只参与 bare 臂对比，不进 UPCL。
# ---------------------------------------------------------------------------
try:
    from de_hosts import HOST_REGISTRY as _HOST_REGISTRY
    from blackbox_host import register_plugins as _register_plugins
    BLACKBOX_HOSTS = set(_register_plugins(_HOST_REGISTRY))
    CEC_HOST_ORDER.extend(sorted(BLACKBOX_HOSTS))
except Exception:  # noqa: BLE001
    BLACKBOX_HOSTS = set()

if __name__ == '__main__':
    import time
    import cec_suites as CS
    register()
    import de_hosts
    dim = 10
    f = CS.get_function('cec2022', dim, 1)
    for name in CEC_HOST_ORDER:
        h = de_hosts.get_host(name, dim, f.lb, f.ub, seed=0,
                              pop_size=pop_size_for(name, dim))
        t0 = time.perf_counter()
        h.run(f, 2000)
        print(f'{name:>20s}  N={pop_size_for(name, dim):4d}  '
              f'err={f.error(h.best_x):.3e}  {time.perf_counter()-t0:.2f}s')

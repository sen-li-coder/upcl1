# -*- coding: utf-8 -*-
"""结果分析纯函数：从 results/cec/raw 读 JSON，产出前端可渲染的数据。

移植自 gui_launcher.py 的 _collect_curves / _collect_mechanism /
_compute_rank_test / _scan_archive / _export_results，逻辑保持一致。
"""
import csv
import io
import json
import math
import re
from statistics import mean, median, stdev

import numpy as np

from . import constants as C
from . import workspace


def _jnum(v):
    """把 numpy 标量归一为 JSON 安全数值；NaN/Inf 返回 None。

    后端响应经 Starlette JSONResponse(allow_nan=False) 序列化，
    numpy.bool_/numpy.nan 都会直接抛异常导致 500。
    """
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _resample_curve(vals, n=C.RHO_CURVE_PTS):
    m = len(vals)
    if m == 0:
        return []
    if m == 1:
        return [float(vals[0])] * n
    out = []
    for j in range(n):
        t = j / (n - 1)
        idx = t * (m - 1)
        i = min(int(idx), m - 2)
        f = idx - i
        out.append(float(vals[i]) * (1 - f) + float(vals[i + 1]) * f)
    return out


def _cell_path(suite, dim, host, fid):
    return C.RAW / suite / f'D{dim}' / f'{host.replace("/", "-")}__F{fid}.json'


# ===========================================================================
# 多用户数据视图：用户私有目录优先，公共目录兜底
# ===========================================================================
def _raw_dirs(user=None):
    dirs = []
    if user:
        dirs.append(workspace.user_raw(user))
    dirs.append(C.RAW)
    return dirs


def _tables_dirs(user=None):
    dirs = []
    if user:
        dirs.append(workspace.user_tables(user))
    dirs.append(C.TABLES_DIR)
    return dirs


def _figures_dirs(user=None):
    dirs = []
    if user:
        dirs.append(workspace.user_figures(user))
    dirs.append(C.FIGURES_DIR)
    return dirs


def _cell_files(suite, dim, host, fid, user=None):
    fn = f'{host.replace("/", "-")}__F{fid}.json'
    return [d / suite / f'D{dim}' / fn for d in _raw_dirs(user)]


def _load_cell(suite, dim, host, fid, user=None):
    """加载某个 cell：私有目录优先，公共目录兜底。"""
    for p in _cell_files(suite, dim, host, fid, user):
        if p.exists():
            data = _load_json(p)
            if data:
                return data
    return None


def _iter_cells(user=None):
    """遍历所有 cell 文件（私有优先覆盖公共同名），产出绝对路径。"""
    seen = set()
    for d in _raw_dirs(user):
        if not d.is_dir():
            continue
        for p in sorted(d.rglob('*.json')):
            rel = p.relative_to(d)
            if rel in seen:
                continue
            seen.add(rel)
            yield p


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return None


# ===========================================================================
# 收敛曲线
# ===========================================================================
def collect_curves(suite, dim, fids, hosts, arms, stat='中位数', log_y=True,
                   user=None):
    """返回 {'xs': [...], 'curves': [{'label':..., 'ys': [...]}, ...]}"""
    if not any((d / suite / f'D{dim}').is_dir() for d in _raw_dirs(user)):
        return {'xs': [], 'curves': []}
    xs = None
    curves = []
    for host in hosts:
        for fid in fids:
            data = _load_cell(suite, dim, host, fid, user)
            if not data:
                continue
            for arm in arms:
                data_arm = arm
                if arm == 'upcl':
                    keys = {k for r in data.get('runs', []) or []
                            for k in r if k not in ('run', 'seed')}
                    data_arm = 'upcl' if 'upcl' in keys else 'full'
                series = []
                for r in data.get('runs', []) or []:
                    rec = r.get(data_arm)
                    if isinstance(rec, dict) and 'err_curve' in rec:
                        if xs is None:
                            xs = [float(v) for v in (rec.get('grid') or
                                    range(1, len(rec['err_curve']) + 1))]
                        series.append(rec['err_curve'])
                if not series:
                    continue
                n = len(series[0])
                ys = []
                for i in range(n):
                    vals = [s[i] for s in series if i < len(s)]
                    if not vals:
                        continue
                    v = median(vals) if stat == '中位数' else mean(vals)
                    if log_y:
                        v = math.log10(max(v, 1e-300))
                    ys.append(v)
                host_label = host if arm == 'bare' else f'{host}-UPCL'
                label = (f'{host_label} F{fid}' if len(fids) > 1 else host_label)
                curves.append({'label': label, 'ys': ys})
    return {'xs': xs or [], 'curves': curves}


# ===========================================================================
# 机制分析
# ===========================================================================
def collect_mechanism(suite, dim, fids, hosts, user=None):
    """读取每个 (host, fid) 的 dec / 干预率 / 描述子效应 / 演化曲线。"""
    cells = []
    for host in hosts:
        for fid in fids:
            data = _load_cell(suite, dim, host, fid, user)
            if not data:
                continue
            runs = [r for r in (data.get('runs') or []) if isinstance(r, dict)]
            if not runs:
                continue
            arm_keys = {k for r in runs for k in r
                        if k not in ('run', 'seed') and isinstance(r[k], dict)}
            bare_key = 'bare' if 'bare' in arm_keys else None
            upcl_key = ('upcl' if 'upcl' in arm_keys
                        else 'full' if 'full' in arm_keys else None)
            if bare_key is None or upcl_key is None:
                continue

            def _err(key):
                return [float(r[key]['err_final']) for r in runs
                        if key in r and isinstance(r[key], dict)
                        and 'err_final' in r[key]]

            err_b, err_u = _err(bare_key), _err(upcl_key)
            if not err_b or not err_u:
                continue
            dec = (math.log10(max(median(err_b), 1e-300))
                   - math.log10(max(median(err_u), 1e-300)))

            ir, pr = [], []
            desc = {name: [] for name, _ in C.DESC_NAMES}
            rc_all, rpc_all = [], []
            for r in runs:
                rec = r.get(upcl_key)
                if not isinstance(rec, dict):
                    continue
                st = rec.get('upcl')
                if not isinstance(st, dict):
                    continue
                if isinstance(st.get('intervention_rate'), (int, float)):
                    ir.append(float(st['intervention_rate']))
                if isinstance(st.get('policy_rate'), (int, float)):
                    pr.append(float(st['policy_rate']))
                di = st.get('descriptor_influence')
                if isinstance(di, dict):
                    for k, (name, _lab) in enumerate(C.DESC_NAMES):
                        v = di.get(f'z{k}_effect')
                        if isinstance(v, (int, float)):
                            desc[name].append(float(v))
                if isinstance(st.get('rho_curve'), list) and st['rho_curve']:
                    rc_all.append(_resample_curve(st['rho_curve']))
                if isinstance(st.get('rho_policy_curve'), list) and st['rho_policy_curve']:
                    rpc_all.append(_resample_curve(st['rho_policy_curve']))

            def _med_col(curves):
                if not curves:
                    return None
                return [median(col) for col in zip(*curves)]

            cells.append({
                'host': host, 'fid': fid, 'dec': dec,
                'intervention_rate': (median(ir) if ir else None),
                'policy_rate': (median(pr) if pr else None),
                'desc': {name: (median(v) if v else None)
                         for name, v in desc.items()},
                'rho_curve': _med_col(rc_all),
                'rho_policy_curve': _med_col(rpc_all),
            })
    return cells


def aggregate_mechanism(cells, use_policy=True):
    """把 cell 列表聚合为 5 个图所需的数据结构。"""
    if not cells:
        return None
    dec_by_host = {}
    rate_by_host = {}
    for c in cells:
        dec_by_host.setdefault(c['host'], []).append(c['dec'])
        rv = c['policy_rate'] if use_policy else c['intervention_rate']
        if rv is not None:
            rate_by_host.setdefault(c['host'], []).append(rv)

    host_order = sorted(dec_by_host)
    dec_vals = [median(dec_by_host[h]) for h in host_order]
    rate_vals = [median(rate_by_host[h]) if rate_by_host.get(h)
                 else None for h in host_order]

    # 描述子效应（跨 host × 函数中位数）
    desc_agg = {name: [] for name, _ in C.DESC_NAMES}
    for c in cells:
        for name, _lab in C.DESC_NAMES:
            v = c['desc'].get(name)
            if v is not None:
                desc_agg[name].append(v)
    desc_labels = [name for name, _ in C.DESC_NAMES]
    desc_vals = [median(desc_agg[name]) if desc_agg[name] else None
                 for name in desc_labels]

    # 干预率演化曲线（每 host 一条，跨函数取中位数）
    rho_by_host = {}
    for c in cells:
        curve = c['rho_policy_curve'] if use_policy else c['rho_curve']
        if curve:
            rho_by_host.setdefault(c['host'], []).append(curve)
    rho_curves = []
    for h in host_order:
        if h in rho_by_host:
            med = [median(col) for col in zip(*rho_by_host[h])]
            rho_curves.append({'name': h, 'data': med})

    # 机制散点：x=干预率 ρ，y=效应量 dec
    scatter = [{'name': h,
                'x': (median(rate_by_host[h]) if rate_by_host.get(h) else None),
                'y': median(dec_by_host[h])} for h in host_order]

    return {
        'host_order': host_order,
        'dec': [{'name': h, 'value': v} for h, v in zip(host_order, dec_vals)],
        'rate': [{'name': h, 'value': v} for h, v in zip(host_order, rate_vals)],
        'desc': [{'name': n, 'value': v}
                 for n, v in zip(desc_labels, desc_vals)],
        'rho_curves': rho_curves,
        'scatter': scatter,
    }


# ===========================================================================
# 秩和检验
# ===========================================================================
def compute_rank_test(progress_cb=None, user=None):
    """对 raw 每个 cell 的两臂做 Mann-Whitney U + 配对 Wilcoxon。"""
    from scipy import stats
    files = list(_iter_cells(user))
    if not files:
        return []
    total = len(files)
    rows = []
    for idx, p in enumerate(files):
        if progress_cb is not None:
            progress_cb(idx, total)
        d = _load_json(p)
        if not d:
            continue
        arms = {}
        for r in d.get('runs', []) or []:
            for k, v in r.items():
                if k in ('run', 'seed') or not isinstance(v, dict):
                    continue
                if 'err_final' not in v:
                    continue
                arms.setdefault(k, []).append(float(v['err_final']))
        keys = sorted(arms)
        if len(keys) < 2:
            continue
        a, b = keys[0], keys[1]
        xa, xb = arms[a], arms[b]
        if len(xa) < 2 or len(xb) < 2:
            continue
        try:
            _, p_mwu = stats.mannwhitneyu(xa, xb, alternative='two-sided')
        except Exception:
            p_mwu = float('nan')
        n = min(len(xa), len(xb))
        try:
            _, p_wil = stats.wilcoxon(xa[:n], xb[:n])
        except Exception:
            p_wil = float('nan')
        sig = (p_mwu < 0.05)
        loga = [math.log10(max(x, 1e-300)) for x in xa]
        logb = [math.log10(max(x, 1e-300)) for x in xb]
        diff = median(logb) - median(loga)
        if sig:
            direction = f'{b} 更好' if diff < 0 else f'{b} 更差'
        else:
            direction = '无显著差异'
        rows.append({
            'suite': d.get('suite', ''), 'dim': d.get('dim', ''),
            'host': d.get('host', ''), 'fid': d.get('fid', ''),
            'func': d.get('func', ''), 'category': d.get('category', ''),
            'arm_a': a, 'arm_b': b, 'n': int(len(xa)),
            'p_mwu': _jnum(p_mwu), 'p_wil': _jnum(p_wil),
            'significant': bool(sig),
            'direction': direction,
            'mean_log10_a': _jnum(mean(loga)),
            'mean_log10_b': _jnum(mean(logb)),
        })
    return rows


# ===========================================================================
# 数据存档
# ===========================================================================
def _read_cell_meta(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            head = fh.read(8192)
    except Exception:
        return None, set()
    m = re.search(r'"runs_complete"\s*:\s*(\d+)', head)
    rc = int(m.group(1)) if m else 0
    m = re.search(r'"arms"\s*:\s*\[([^\]]*)\]', head)
    arms = set(re.findall(r'"([a-zA-Z]+)"', m.group(1))) if m else set()
    return rc, arms


def scan_archive(user=None):
    """返回 {'summary': [...], 'cells': {(suite,dim): [[host,fid,runs,arms,状态],...]},
             'tables': [...], 'figures': [...]}"""
    summary = []
    cells = {}
    for suite in C.ARCHIVE_SUITES:
        fids = C.SUITE_FIDS.get(suite, [])
        if not fids:
            continue
        for dim in C.SUITE_LEGAL_DIMS.get(suite, []):
            # 分母只用真实 DE 算法（排除插件/黑盒宿主），否则满格也达不到 100%
            hosts = (C.CEC_HOSTS if (suite, dim) in C.WAVE4_DIMS
                     else C.LEGACY_HOSTS)
            states = {'完整': 0, '缺模式': 0, '模式数异': 0,
                      'R5': 0, '其他': 0, '缺失': 0}
            rows = []
            total = len(hosts) * len(fids)
            for host in hosts:
                expected = ({'bare', 'full'} if host in C.WAVE4_HOSTS
                            else {'bare', 'upcl'})
                for fid in fids:
                    p = next((f for f in _cell_files(suite, dim, host, fid, user)
                              if f.exists()), None)
                    if p is None:
                        states['缺失'] += 1
                        rows.append([host, fid, '', '', '缺失'])
                        continue
                    rc, arms = _read_cell_meta(p)
                    if rc is None:
                        states['缺失'] += 1
                        rows.append([host, fid, '?', '', '损坏'])
                        continue
                    if rc >= 30:
                        if arms == expected:
                            st = '完整'
                        elif arms == {'bare'}:
                            st = '缺模式'
                        else:
                            st = '模式数异'
                    elif rc == 5:
                        st = 'R5'
                    else:
                        st = '其他'
                    states[st] += 1
                    rows.append([host, fid, rc, ','.join(sorted(arms)), st])
            done = total - states['缺失']
            if done == 0:
                continue
            summary.append({
                'suite': suite, 'dim': dim, 'total': total,
                'done': done, 'pct': done / total if total else 0.0,
                **states})
            cells[f'{suite},{dim}'] = rows

    def _names(dirs, pattern):
        seen, out = set(), []
        for d in dirs:
            if not d.is_dir():
                continue
            for p in sorted(d.glob(pattern)):
                if p.name in seen:
                    continue
                seen.add(p.name)
                out.append(p.name)
        return out

    tables = _names(_tables_dirs(user), '*.csv')
    figures = _names(_figures_dirs(user), '*.png')
    n_json = sum(1 for _ in _iter_cells(user))
    return {'summary': summary, 'cells': cells,
            'tables': tables, 'figures': figures, 'n_json': n_json}


def read_table(name, user=None):
    """读 analysis CSV 的前若干行，返回 {'header': [...], 'rows': [[...]]}。"""
    if not name.endswith('.csv'):
        return None
    for d in _tables_dirs(user):
        p = d / name
        if not p.exists():
            continue
        try:
            with open(p, 'r', encoding='utf-8-sig') as fh:
                reader = csv.reader(fh)
                rows = [row for row in reader]
        except Exception:
            return None
        return {'name': name, 'header': rows[0] if rows else [],
                'rows': rows[1:201]}
    return None


# ===========================================================================
# 导出结果表格
# ===========================================================================
def export_results_csv(user=None):
    """生成结果汇总 CSV 文本，返回 (filename, csv_text) 或 None。"""
    files = list(_iter_cells(user))
    if not files:
        return None
    arm_set = set()
    cells = []
    for p in files:
        d = _load_json(p)
        if not d:
            continue
        arms = {}
        for r in d.get('runs', []) or []:
            for k, v in r.items():
                if k in ('run', 'seed') or not isinstance(v, dict):
                    continue
                if 'err_final' not in v:
                    continue
                arms.setdefault(k, []).append(float(v['err_final']))
                arm_set.add(k)
        if not arms:
            continue
        cells.append({
            'suite': d.get('suite', ''), 'dim': d.get('dim', ''),
            'host': d.get('host', ''), 'fid': d.get('fid', ''),
            'func': d.get('func', ''), 'category': d.get('category', ''),
            'n': max(len(v) for v in arms.values()), 'arms': arms})
    if not cells:
        return None
    arms_sorted = sorted(arm_set)
    buf = io.StringIO()
    w = csv.writer(buf)
    header = ['suite', 'dim', 'host', 'fid', 'func', 'category', 'n']
    for a in arms_sorted:
        header += [f'{a}_均值', f'{a}_标准差', f'{a}_中位数', f'{a}_最优']
    w.writerow(header)
    for c in sorted(cells, key=lambda x: (str(x['suite']), str(x['dim']),
                                          str(x['host']), str(x['fid']))):
        row = [c['suite'], c['dim'], c['host'], c['fid'],
               c['func'], c['category'], c['n']]
        for a in arms_sorted:
            vals = c['arms'].get(a, [])
            if vals:
                row += [mean(vals),
                        stdev(vals) if len(vals) > 1 else 0.0,
                        median(vals), min(vals)]
            else:
                row += ['', '', '', '']
        w.writerow(row)
    import time
    name = f'结果汇总_{time.strftime("%Y%m%d_%H%M%S")}.csv'
    return name, buf.getvalue()


def export_rank_csv(rows):
    """把显著性检验 rows 导出为 CSV 文本。"""
    buf = io.StringIO()
    w = csv.writer(buf)
    header = ['suite', 'dim', 'host', 'fid', 'func', 'category',
              'arm_a', 'arm_b', 'n', 'p_mannwhitneyu', 'p_wilcoxon',
              'significant', 'direction', 'mean_log10_a', 'mean_log10_b']
    w.writerow(header)
    for r in sorted(rows, key=lambda x: (str(x['suite']), str(x['dim']),
                                         str(x['host']), str(x['fid']))):
        w.writerow([r['suite'], r['dim'], r['host'], r['fid'],
                    r['func'], r['category'], r['arm_a'], r['arm_b'],
                    r['n'], r['p_mwu'], r['p_wil'], r['significant'],
                    r['direction'], r['mean_log10_a'], r['mean_log10_b']])
    return buf.getvalue()


# ===========================================================================
# 算法对比分析（多视图：分布 / 排名 / 收敛速度 ERT / 配对 / 热力图）
# ===========================================================================
def collect_compare(suite, dim, fids, hosts, arms, target=-2.0, user=None):
    """读 raw，产出多视图对比数据供前端渲染。"""
    if not any((d / suite / f'D{dim}').is_dir() for d in _raw_dirs(user)):
        return {'ok': False, 'msg': '该测试集/维度暂无结果数据'}

    series = {}     # label -> log10(err_final) 分布
    ert_by = {}     # label -> ERT(FES) 列表
    paired = []     # bare vs upcl 同 seed 配对
    heat_fids = []
    heat = {}       # host -> fid -> arm -> mean log10 err

    for host in hosts:
        for fid in fids:
            data = _load_cell(suite, dim, host, fid, user)
            if not data:
                continue
            runs = [r for r in (data.get('runs') or []) if isinstance(r, dict)]
            if not runs:
                continue
            arm_keys = {k for r in runs for k in r
                        if k not in ('run', 'seed') and isinstance(r[k], dict)}
            bare_key = 'bare' if 'bare' in arm_keys else None
            upcl_key = ('upcl' if 'upcl' in arm_keys
                        else 'full' if 'full' in arm_keys else None)

            if fid not in heat_fids:
                heat_fids.append(fid)

            for arm in arms:
                key = bare_key if arm == 'bare' else upcl_key
                if not key:
                    continue
                label = host if arm == 'bare' else f'{host}-UPCL'
                vals = [math.log10(max(float(r[key]['err_final']), 1e-300))
                        for r in runs if key in r and isinstance(r[key], dict)
                        and 'err_final' in r[key]]
                if not vals:
                    continue
                series.setdefault(label, []).extend(vals)
                heat.setdefault(host, {}).setdefault(fid, {})[arm] = mean(vals)
                erts = []
                for r in runs:
                    rec = r.get(key)
                    if not isinstance(rec, dict):
                        continue
                    ec, gd = rec.get('err_curve'), rec.get('grid')
                    if not isinstance(ec, list) or not ec or not isinstance(gd, list):
                        continue
                    hit = None
                    for gv, ev in zip(gd, ec):
                        if math.log10(max(float(ev), 1e-300)) <= target:
                            hit = float(gv)
                            break
                    erts.append(hit if hit is not None else float(gd[-1]))
                if erts:
                    ert_by.setdefault(label, []).extend(erts)

            if bare_key and upcl_key:
                for r in runs:
                    rb, ru = r.get(bare_key), r.get(upcl_key)
                    if (isinstance(rb, dict) and isinstance(ru, dict)
                            and 'err_final' in rb and 'err_final' in ru):
                        paired.append({
                            'host': host, 'fid': fid,
                            'bare': math.log10(max(float(rb['err_final']), 1e-300)),
                            'upcl': math.log10(max(float(ru['err_final']), 1e-300)),
                        })

    ranking = []
    for label, vals in series.items():
        if not vals:
            continue
        ranking.append({'label': label, 'mean': mean(vals),
                        'median': median(vals), 'best': min(vals),
                        'worst': max(vals),
                        'std': stdev(vals) if len(vals) > 1 else 0.0,
                        'n': len(vals)})
    ranking.sort(key=lambda x: x['mean'])

    host_list = [h for h in hosts if h in heat]
    heatmap = {
        'fids': heat_fids, 'hosts': host_list,
        'bare_z': [[heat.get(h, {}).get(f, {}).get('bare', None)
                    for f in heat_fids] for h in host_list],
        'upcl_z': [[heat.get(h, {}).get(f, {}).get('upcl',
                    heat.get(h, {}).get(f, {}).get('full'))
                    for f in heat_fids] for h in host_list],
    }

    return {
        'ok': True, 'target': target,
        'series': {k: sorted(v) for k, v in series.items()},
        'ranking': ranking,
        'ert': [{'label': k, 'median': (median(v) if v else None), 'values': v}
                for k, v in sorted(ert_by.items())],
        'paired': paired,
        'heatmap': heatmap,
    }


# ===========================================================================
# 二维地形图采样
# ===========================================================================
def landscape_sample(suite, dim, fid, host, arm='bare', fes_mult=10000,
                     n_frames=20, runs=1, progress_cb=None):
    """调用 landscape_probe.sample 并把 numpy 数组转成 JSON 可序列化结构。"""
    from landscape_probe import sample as lp_sample
    data = lp_sample(suite, dim, fid, host, arm=arm, fes_mult=fes_mult,
                     n_frames=n_frames, runs=runs, progress_cb=progress_cb)
    X, Y, Z = data['landscape']
    traces = []
    for t in data['traces']:
        traces.append({
            'gens': t['gens'],
            'nevals': t['nevals'],
            'pop': [p.tolist() for p in t['pop']],
        })
    err_curves = [{'grid': g.tolist(), 'err': e.tolist()}
                  for g, e in data['err_curves']]
    return {
        'suite': data['suite'], 'dim': data['dim'], 'fid': data['fid'],
        'host': data['host'], 'arm': data['arm'],
        'func': data['func'], 'func_name': data['func_name'],
        'lb': data['lb'], 'ub': data['ub'], 'f_opt': data['f_opt'],
        'x_opt': data['x_opt'], 'best_x': data['best_x'],
        'landscape': {
            'x': np.asarray(X[0], dtype=float).tolist(),
            'y': np.asarray(Y[:, 0], dtype=float).tolist(),
            'z': np.asarray(Z, dtype=float).tolist(),
        },
        'z_log': data.get('z_log'),
        'z_rank': data.get('z_rank'),
        'contours': data.get('contours', []),
        'traces': traces,
        'err_curves': err_curves,
    }

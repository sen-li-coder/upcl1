# -*- coding: utf-8 -*-
"""FastAPI 主入口：静态前端 + 实验任务 + 结果分析 + UAV 仿真 API。

启动：python -m web.server  或  uvicorn web.server:app --host 127.0.0.1 --port 8000
"""
import asyncio
import threading
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import (Depends, FastAPI, File, Form, Request, UploadFile,
                     WebSocket, WebSocketDisconnect)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import auth
from . import constants as C
from . import ontology_api
from . import plugins_api
from . import results_api
from . import uav_api
from . import afsim_api
from . import workspace
from .task_manager import manager

STATIC_DIR = Path(__file__).resolve().parent / 'static'

app = FastAPI(title='进化算法机制研究平台', version='1.0.0')
app.add_middleware(
    CORSMiddleware, allow_origins=['*'], allow_methods=['*'],
    allow_headers=['*'])


@app.middleware('http')
async def _no_cache_static(request, call_next):
    """静态资源禁用缓存：前端迭代频繁，避免浏览器缓存旧版 JS/CSS/HTML。"""
    response = await call_next(request)
    if request.url.path.endswith(('.js', '.css', '.html')):
        response.headers['Cache-Control'] = \
            'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
    return response


@app.middleware('http')
async def _auth(request: Request, call_next):
    """对 /api/* 统一鉴权（登录接口除外），并把用户名写入 request.state.user。"""
    path = request.url.path
    if path.startswith('/api/') and path != '/api/auth/login':
        token = request.headers.get('Authorization', '')
        if token.startswith('Bearer '):
            token = token[7:].strip()
        elif not token:
            # 兼容 <img>/文件下载等无法带自定义请求头的场景：允许 ?token= 查询参数
            token = request.query_params.get('token') or None
        else:
            token = None
        username = auth.get_username_by_token(token)
        if not username:
            return JSONResponse(status_code=401,
                                content={'detail': '未登录或登录已过期'})
        request.state.user = username
    return await call_next(request)


def _user(request: Request) -> Optional[str]:
    return getattr(request.state, 'user', None)


# ---------------------------------------------------------------------------
# 认证与用户管理
# ---------------------------------------------------------------------------
class LoginReq(BaseModel):
    username: str
    password: str


class PasswordReq(BaseModel):
    old_password: str
    new_password: str


class UserCreateReq(BaseModel):
    username: str
    password: str
    role: str = 'user'


class UserResetReq(BaseModel):
    password: str


@app.post('/api/auth/login')
def auth_login(req: LoginReq):
    token = auth.authenticate(req.username, req.password)
    if not token:
        return JSONResponse(status_code=401,
                            content={'detail': '用户名或密码错误'})
    return {'token': token, 'username': req.username,
            'role': auth.get_role(req.username)}


@app.post('/api/auth/logout')
def auth_logout(request: Request):
    token = request.headers.get('Authorization', '')
    if token.startswith('Bearer '):
        token = token[7:].strip()
    auth.logout(token)
    return {'ok': True}


@app.get('/api/auth/me')
def auth_me(request: Request):
    username = _user(request)
    return {'username': username,
            'role': auth.get_role(username) if username else None}


@app.post('/api/auth/password')
def auth_password(request: Request, req: PasswordReq):
    return auth.change_password(_user(request), req.old_password,
                                req.new_password)


@app.get('/api/users')
def users_list(request: Request):
    auth.require_admin(request)
    return {'users': auth.list_users()}


@app.post('/api/users')
def users_create(request: Request, req: UserCreateReq):
    auth.require_admin(request)
    return auth.create_user(req.username, req.password, req.role)


@app.delete('/api/users/{username}')
def users_delete(request: Request, username: str):
    auth.require_admin(request)
    return auth.delete_user(username)


@app.post('/api/users/{username}/reset')
def users_reset(request: Request, username: str, req: UserResetReq):
    auth.require_admin(request)
    return auth.reset_password(username, req.password)

# ---------------------------------------------------------------------------
# 后台任务（UAV / 地形图 / 秩和检验 等 CPU 密集任务）
# ---------------------------------------------------------------------------
_tasks: Dict[str, Dict[str, Any]] = {}
_tasks_lock = threading.Lock()


def _new_task() -> str:
    tid = uuid.uuid4().hex
    with _tasks_lock:
        _tasks[tid] = {'state': 'running', 'progress': 0.0, 'message': '',
                       'result': None, 'error': None, 'live': {},
                       'cancel': threading.Event()}
    return tid


def _run_task(tid: str, fn, *args, **kwargs):
    def _wrapper():
        t = _tasks[tid]
        try:
            t['result'] = fn(*args, **kwargs)
            t['state'] = 'done'
            t['progress'] = 1.0
        except Exception as exc:  # noqa: BLE001
            t['state'] = 'error'
            t['error'] = str(exc)
    threading.Thread(target=_wrapper, daemon=True).start()


def _set_progress(tid: str, frac: float, msg: str = ''):
    with _tasks_lock:
        t = _tasks.get(tid)
        if t is not None:
            t['progress'] = max(0.0, min(1.0, float(frac)))
            if msg:
                t['message'] = msg


# ---------------------------------------------------------------------------
# 元数据
# ---------------------------------------------------------------------------
@app.get('/api/meta')
def get_meta(request: Request):
    user = _user(request)
    return {
        'suites': C.SUITES,
        'suite_labels': C.SUITE_LABELS,
        'legal_dims': {k: list(v) for k, v in C.SUITE_LEGAL_DIMS.items()},
        'available_dims': C.available_dims(user),
        'nfuncs': C.SUITE_NFUNCS,
        'suite_fids': C.SUITE_FIDS,
        'hosts': plugins_api.available_hosts(user),
        'plugins': plugins_api.plugin_meta(user),
        'legacy_hosts': C.LEGACY_HOSTS,
        'wave4_hosts': sorted(C.WAVE4_HOSTS),
        'arm_display': C.ARM_DISPLAY,
        'desc_names': [{'name': n, 'desc': d} for n, d in C.DESC_NAMES],
        'rho_curve_pts': C.RHO_CURVE_PTS,
    }


# ---------------------------------------------------------------------------
# 客户算法接入（黑盒插件）：列表 / 创建 / 删除 / 冒烟自检
# ---------------------------------------------------------------------------
@app.get('/api/plugins')
def plugins_list(request: Request):
    return {'plugins': plugins_api.list_plugins(_user(request))}


@app.post('/api/plugins')
def plugins_create(payload: Dict[str, Any], request: Request):
    return plugins_api.create_plugin(payload, _user(request))


@app.post('/api/plugins/upload')
async def plugins_upload(request: Request, name: str = Form(''),
                         file: UploadFile = File(...)):
    content = await file.read()
    return plugins_api.save_upload(name, file.filename, content, _user(request))


@app.delete('/api/plugins/{name}')
def plugins_delete(name: str, request: Request):
    return plugins_api.delete_plugin(name, _user(request))


@app.post('/api/plugins/{name}/test')
def plugins_test(name: str, request: Request):
    tid = _new_task()
    user = _user(request)

    def fn():
        return plugins_api.smoke_test(name, user)

    _run_task(tid, fn)
    return {'task_id': tid}


@app.get('/api/uav/meta')
def get_uav_meta():
    return uav_api.uav_meta()


@app.get('/api/uav/paper')
def get_uav_paper(fid: int = 1):
    """论文实验数据（地图一 F1-F4 × 29 算法，基线 vs 增加 UPCL）。"""
    return uav_api.paper_data(fid)


@app.get('/api/uav/fig/{name}')
def get_uav_paper_fig(name: str):
    """论文配图（results/apps/figures）。"""
    p = uav_api.paper_figure(name)
    if p is None:
        return Response(status_code=404)
    return FileResponse(p)


@app.get('/api/uav/paper/table/{name}')
def get_uav_paper_table(name: str):
    """论文数据表下载（results/apps/tables）。"""
    p = uav_api.paper_table(name)
    if p is None:
        return Response(status_code=404)
    return FileResponse(p, filename=name)


@app.get('/api/uav/paper/trace')
def get_uav_paper_trace(host: str, fid: int = 1, run: int = 0, arm: str = 'full'):
    """论文实验某次运行的轨迹重放（返回结构与 /api/uav/run 一致，供真三维回放）。"""
    try:
        return uav_api.paper_trace(fid=fid, host=host, run=run, arm=arm)
    except ValueError as exc:
        return JSONResponse(status_code=404, content={'detail': str(exc)})


@app.get('/api/uav/repr')
def get_uav_repr(host: str = '', run: int = 0):
    """代表轨迹：每个「场景 × 任务」的二维代表曲线（bare vs full）。

    ``host`` 留空 = 全局最优口径（各臂独立取最好一次）；
    传入 ``host``（如 ``NL-SHADE-RSP``）= 固定该算法、两臂同 run 的公平对比口径。
    """
    return uav_api.repr_trajectories(host=host, run=run)


@app.get('/api/uav/describe')
def get_uav_describe(scenario: str = 'intercept', fid: int = 1,
                     n_waypoints: Optional[int] = None,
                     n_attack: Optional[int] = None,
                     n_infantry: Optional[int] = None):
    return uav_api.describe_uav(scenario, fid, n_waypoints,
                                n_attack, n_infantry)


@app.get('/api/uav/map')
def get_uav_map(scenario: str = 'intercept', fid: int = 1,
                n_waypoints: Optional[int] = None,
                n_attack: Optional[int] = None,
                n_infantry: Optional[int] = None):
    return uav_api.map_geometry(scenario, fid, n_waypoints,
                                n_attack, n_infantry)


# ---------------------------------------------------------------------------
# AFSIM 2.9 高保真复核
# ---------------------------------------------------------------------------
@app.get('/api/afsim/meta')
def get_afsim_meta():
    """引擎状态 + 可复核用例清单 + 未建模项说明。"""
    return afsim_api.meta()


class AfsimRunReq(BaseModel):
    host: str
    fid: int = 1
    run: int = 0
    arm: str = 'full'
    refresh: bool = False


@app.post('/api/afsim/run')
def post_afsim_run(req: AfsimRunReq):
    """把一局 LASE 解送进真实 mission.exe 复核（同步执行，约 1-3 s）。"""
    try:
        return afsim_api.run(req.host, req.fid, req.run, req.arm, req.refresh)
    except FileNotFoundError as exc:
        return JSONResponse(status_code=404, content={'detail': str(exc)})
    except (ValueError, IndexError) as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.get('/api/afsim/scenario')
def get_afsim_scenario(fid: int = 1):
    """当前想定说明：战场 / 双方兵力 / 判定 / 决策变量 / 目标函数（来自 EnvConfig）。"""
    try:
        return afsim_api.scenario(fid)
    except (KeyError, ValueError) as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.get('/api/afsim/summary')
def get_afsim_summary(host: str, fid: int = 1, run: int = 0, arm: str = 'full'):
    """已跑过的复核摘要（读 afsim_check.json，不重跑）。"""
    try:
        return afsim_api.summary(host, fid, run, arm)
    except FileNotFoundError as exc:
        return JSONResponse(status_code=404, content={'detail': str(exc)})


@app.get('/api/afsim/warlock')
def get_afsim_warlock():
    """已录制的 warlock.exe 官方界面演示视频清单（按算法 / 任务 / run 分组）。"""
    return afsim_api.warlock_demos()


class AfsimTrainReq(BaseModel):
    host: str
    fid: int = 1
    evals: int = 2000
    seed: int = 20261018


@app.get('/api/afsim/train/hosts')
def get_afsim_train_hosts():
    """在线训练可选的算法（= 平台真实宿主池）与预算上下限。"""
    return {'hosts': afsim_api.available_hosts(),
            'fids': sorted(afsim_api.TASK_NAMES),
            'tasks': {str(k): v for k, v in afsim_api.TASK_NAMES.items()},
            'min_evals': afsim_api.TRAIN_MIN_EVALS,
            'max_evals': afsim_api.TRAIN_MAX_EVALS}


@app.post('/api/afsim/train')
def post_afsim_train(req: AfsimTrainReq):
    """在线训练：后台真实跑一次 DE（LASE 适应度 + 周期 AFSIM 检查点），前端轮询进度。"""
    if not (afsim_api.TRAIN_MIN_EVALS <= int(req.evals) <= afsim_api.TRAIN_MAX_EVALS):
        return JSONResponse(status_code=400, content={
            'detail': '评估预算需在 %d ~ %d 之间'
                      % (afsim_api.TRAIN_MIN_EVALS, afsim_api.TRAIN_MAX_EVALS)})
    if int(req.fid) not in afsim_api.TASK_NAMES:
        return JSONResponse(status_code=400, content={'detail': '未知任务 F%s' % req.fid})
    if req.host not in afsim_api.available_hosts():
        return JSONResponse(status_code=400, content={'detail': '未知算法 %s' % req.host})
    tid = _new_task()

    def _live(payload):
        # 每次回调都带完整快照（curve / checkpoints），前端直接替换即可，不怕漏轮询
        with _tasks_lock:
            t = _tasks.get(tid)
            if t is not None:
                t.setdefault('live', {}).update(payload)

    _run_task(tid, afsim_api.train, req.host, int(req.fid), int(req.evals),
              int(req.seed),
              progress_cb=lambda frac, msg='': _set_progress(tid, frac, msg),
              live_cb=_live,
              cancel_event=_tasks[tid]['cancel'])
    return {'ok': True, 'tid': tid, 'host': req.host, 'fid': int(req.fid),
            'evals': int(req.evals), 'seed': int(req.seed)}


@app.get('/api/afsim/train/runs')
def get_afsim_train_runs():
    """已保存的训练结果清单（train_result.json，按时间倒序）。"""
    return afsim_api.train_runs()


@app.get('/api/afsim/train/result')
def get_afsim_train_result(label: str):
    """读回一次已保存的训练：曲线 / 检查点 / 最优决策向量 / 引擎遥测。"""
    try:
        return afsim_api.train_result(label)
    except (ValueError, FileNotFoundError) as exc:
        return JSONResponse(status_code=404, content={'detail': str(exc)})


class AfsimWarlockReq(BaseModel):
    label: str
    launch: bool = True


@app.post('/api/afsim/warlock/demo')
def post_afsim_warlock_demo(req: AfsimWarlockReq):
    """把训练得到的解生成 warlock 想定，并在本机拉起真实 AFSIM 图形前端演示。"""
    try:
        if req.launch:
            return afsim_api.warlock_launch(req.label)
        return afsim_api.warlock_prepare(req.label)
    except FileNotFoundError as exc:
        return JSONResponse(status_code=404, content={'detail': str(exc)})
    except (ValueError, OSError) as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.get('/api/afsim/artefact/{name}')
def get_afsim_artefact(name: str, host: str, fid: int = 1, run: int = 0,
                       arm: str = 'full', label: str = ''):
    """下载想定 / 日志 / 事件 / 对比 JSON（在线训练产物用 label 指定目录）。"""
    try:
        p = afsim_api.artefact(host, fid, run, arm, name, label or None)
    except (ValueError, FileNotFoundError) as exc:
        return JSONResponse(status_code=404, content={'detail': str(exc)})
    stem = label or ('%s_F%d_run%d_%s' % (host, fid, run, arm))
    fname = name if name != 'events.evt' else ('%s_events.evt' % stem)
    return FileResponse(p, filename=fname)


# ---------------------------------------------------------------------------
# 实验任务
# ---------------------------------------------------------------------------
class StartReq(BaseModel):
    suite: str
    dim: int
    hosts: List[str]
    runs: int = 30
    workers: int = 19
    evals_mult: float = 10000
    upcl: bool = True


def _status_for(request: Request):
    """按用户返回实验状态：非归属用户的实验对他人不可见。"""
    user = _user(request)
    role = auth.get_role(user) if user else None
    st = manager.status()
    if role == 'admin' or st.get('user') in (None, user):
        return st
    return {'state': 'idle', 'running': False, 'pid': None, 'suite': None,
            'dim': None, 'user': None, 'log_path': None, 'started_at': None,
            'progress': {}}


def _can_control(request: Request) -> bool:
    user = _user(request)
    role = auth.get_role(user) if user else None
    return role == 'admin' or manager.status().get('user') == user


@app.post('/api/experiment/start')
def experiment_start(req: StartReq, request: Request):
    return manager.start(req.suite, req.dim, req.hosts, req.runs,
                         req.workers, req.evals_mult, req.upcl,
                         user=_user(request))


@app.post('/api/experiment/stop')
def experiment_stop(request: Request):
    if not _can_control(request):
        return {'ok': False, 'msg': '无权操作当前实验'}
    return manager.stop()


@app.post('/api/experiment/resume')
def experiment_resume(request: Request):
    if not _can_control(request):
        return {'ok': False, 'msg': '无权操作当前实验'}
    return manager.resume()


@app.post('/api/experiment/kill')
def experiment_kill(request: Request):
    if not _can_control(request):
        return {'ok': False, 'msg': '无权操作当前实验'}
    return manager.kill()


@app.get('/api/experiment/status')
def experiment_status(request: Request):
    return _status_for(request)


@app.get('/api/experiment/progress')
def experiment_progress(request: Request):
    st = _status_for(request)
    workers = manager.worker_status() if st.get('running') else []
    return {'status': st, 'workers': workers}


# ---------------------------------------------------------------------------
# 实验进度 WebSocket
# ---------------------------------------------------------------------------
@app.websocket('/ws/experiment')
async def ws_experiment(ws: WebSocket, token: str = None):
    await ws.accept()
    user = auth.get_username_by_token(token)
    if not user:
        await ws.close(code=1008)
        return
    role = auth.get_role(user)
    seq = 0
    tick = 0
    try:
        while True:
            st = manager.status()
            mine = (role == 'admin' or st.get('user') in (None, user))
            if mine:
                lines, seq = manager.tail_since(seq)
                for line in lines:
                    await ws.send_json({'type': 'log',
                                        'line': line.rstrip('\n')})
                await ws.send_json({'type': 'status', 'status': st})
                tick += 1
                if tick % 2 == 0:
                    await ws.send_json({'type': 'workers',
                                        'workers': manager.worker_status()})
            else:
                await ws.send_json({'type': 'status', 'status': {
                    'state': 'idle', 'running': False, 'pid': None,
                    'suite': None, 'dim': None, 'user': None,
                    'log_path': None, 'started_at': None, 'progress': {}}})
            # 接收前端消息（ping 等），非阻塞
            try:
                await asyncio.wait_for(ws.receive_text(), timeout=0.4)
            except asyncio.TimeoutError:
                pass
            await asyncio.sleep(0.1)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 结果分析
# ---------------------------------------------------------------------------
class ConvergenceReq(BaseModel):
    suite: str
    dim: int
    fids: List[int]
    hosts: List[str]
    arms: List[str] = ['bare', 'upcl']
    stat: str = '中位数'
    log_y: bool = True


@app.post('/api/convergence')
def convergence(req: ConvergenceReq, request: Request):
    return results_api.collect_curves(
        req.suite, req.dim, req.fids, req.hosts, req.arms,
        stat=req.stat, log_y=req.log_y, user=_user(request))


class CompareReq(BaseModel):
    suite: str
    dim: int
    fids: List[int]
    hosts: List[str]
    arms: List[str] = ['bare', 'upcl']
    target: float = -2.0


@app.post('/api/compare')
def compare(req: CompareReq, request: Request):
    return results_api.collect_compare(
        req.suite, req.dim, req.fids, req.hosts, req.arms,
        target=req.target, user=_user(request))


class MechanismReq(BaseModel):
    suite: str
    dim: int
    fids: List[int]
    hosts: List[str]
    use_policy: bool = True


@app.post('/api/mechanism')
def mechanism(req: MechanismReq, request: Request):
    cells = results_api.collect_mechanism(
        req.suite, req.dim, req.fids, req.hosts, user=_user(request))
    agg = results_api.aggregate_mechanism(cells, req.use_policy)
    return {'cells': cells, 'agg': agg,
            'desc_names': [n for n, _ in C.DESC_NAMES]}


@app.post('/api/rank_test')
def rank_test_start(request: Request):
    tid = _new_task()
    user = _user(request)

    def cb(done, total):
        _set_progress(tid, done / total if total else 0,
                      f'检验中 {done}/{total}')

    def fn():
        return results_api.compute_rank_test(progress_cb=cb, user=user)

    _run_task(tid, fn)
    return {'task_id': tid}


@app.get('/api/rank_test/export')
def rank_test_export(request: Request):
    rows = results_api.compute_rank_test(user=_user(request))
    csv_text = results_api.export_rank_csv(rows)
    return Response(content=csv_text, media_type='text/csv',
                    headers={'Content-Disposition':
                             'attachment; filename="显著性检验.csv"'})


# ---------------------------------------------------------------------------
# 数据存档
# ---------------------------------------------------------------------------
@app.get('/api/archive')
def archive(request: Request):
    return results_api.scan_archive(user=_user(request))


@app.get('/api/figure/{name}')
def get_figure(name: str, request: Request):
    user = _user(request)
    dirs = [workspace.user_figures(user)] if user else []
    dirs.append(C.FIGURES_DIR)
    p = next((d / name for d in dirs if (d / name).exists()), None)
    if p is None:
        return Response(status_code=404)
    return FileResponse(p)


@app.get('/api/table_raw/{name}')
def get_table_raw(name: str, request: Request):
    user = _user(request)
    dirs = [workspace.user_tables(user)] if user else []
    dirs.append(C.TABLES_DIR)
    p = next((d / name for d in dirs if (d / name).exists()), None)
    if p is None:
        return Response(status_code=404)
    return FileResponse(p, filename=name)


@app.get('/api/archive/table/{name}')
def archive_table(name: str, request: Request):
    data = results_api.read_table(name, user=_user(request))
    if data is None:
        return Response(status_code=404)
    return data


@app.get('/api/export')
def export_csv(request: Request):
    out = results_api.export_results_csv(user=_user(request))
    if out is None:
        return {'ok': False, 'msg': '暂无结果数据'}
    name, csv_text = out
    return Response(content=csv_text, media_type='text/csv',
                    headers={'Content-Disposition':
                             f'attachment; filename="{name}"'})


# ---------------------------------------------------------------------------
# 二维地形图（后台任务）
# ---------------------------------------------------------------------------
class LandscapeReq(BaseModel):
    suite: str
    dim: int
    fid: int
    host: str
    arm: str = 'bare'
    fes_mult: float = 10000
    n_frames: int = 20
    runs: int = 1


@app.post('/api/landscape')
def landscape_start(req: LandscapeReq):
    tid = _new_task()

    def cb(frac, msg):
        _set_progress(tid, frac, msg)

    def fn():
        return results_api.landscape_sample(
            req.suite, req.dim, req.fid, req.host, arm=req.arm,
            fes_mult=req.fes_mult, n_frames=req.n_frames, runs=req.runs,
            progress_cb=cb)

    _run_task(tid, fn)
    return {'task_id': tid}


# ---------------------------------------------------------------------------
# UAV 仿真（后台任务）
# ---------------------------------------------------------------------------
class UavReq(BaseModel):
    scenario: str = 'intercept'
    fid: int = 1
    n_waypoints: Optional[int] = None
    n_attack: Optional[int] = None
    n_infantry: Optional[int] = None
    host: str = 'SHADE'
    evals_mult: int = 300
    arm: str = 'bare'
    difficulty: str = '规则拦截（默认）'
    drl_algo: str = '进化策略（ES）'
    coevolve: bool = False


class UavPretrainReq(BaseModel):
    scenario: str = 'intercept'
    fid: int = 1
    n_waypoints: Optional[int] = None
    difficulty: str = '强化学习·对抗'
    drl_algo: str = '进化策略（ES）'
    target_capture: float = 0.6


class UavRedReq(BaseModel):
    """红方优化课题请求（F1 兵力部署 / F2 预警 / F3 拦截 / F4 协同）。"""

    mode: str = 'intercept'
    fid: int = 1
    host: str = 'NL-SHADE-RSP'
    evals_mult: int = 200
    opponent: str = 'straight'      # straight=直扑基地；best=强突防 best-of-N
    blue_runs: int = 3              # opponent='best' 时蓝方独立求解次数
    blue_evals: int = 2000          # 每次蓝方求解的评估预算
    seed: int = 1


@app.post('/api/uav/pretrain')
def uav_pretrain(req: UavPretrainReq):
    tid = _new_task()
    cancel = _tasks[tid]['cancel']

    def cb(frac, msg):
        _set_progress(tid, frac, msg)

    def fn():
        return uav_api.pretrain_uav(
            req.scenario, req.fid, req.n_waypoints, req.difficulty, req.drl_algo,
            target_capture=req.target_capture, progress_cb=cb,
            cancel_event=cancel)

    _run_task(tid, fn)
    return {'task_id': tid}


@app.post('/api/uav/run')
def uav_run(req: UavReq):
    tid = _new_task()
    cancel = _tasks[tid]['cancel']

    def cb(nevals, max_evals):
        _set_progress(tid, nevals / max(max_evals, 1),
                      f'优化中 {nevals}/{max_evals}')

    def fn():
        return uav_api.run_uav(
            req.scenario, req.fid, req.n_waypoints, req.host,
            req.evals_mult, req.arm, req.difficulty, req.drl_algo,
            progress_cb=cb, cancel_event=cancel,
            n_attack=req.n_attack, n_infantry=req.n_infantry,
            coevolve=req.coevolve)

    _run_task(tid, fn)
    return {'task_id': tid}


# ---------------------------------------------------------------------------
# 红方优化课题（F1 兵力部署 / F2 预警 / F3 拦截 / F4 协同）
# ---------------------------------------------------------------------------
# 与上面的蓝方「/api/uav/run」并列：蓝方优化「怎么突进去」，红方优化「怎么防住
# 一批固定的蓝方」。结果结构与 /api/uav/run 同源，因此 3D 沙盘回放、存档与对比
# （/api/uav/archive?scenario=red）都能直接复用。
@app.get('/api/uav/red/describe')
def get_uav_red_describe(mode: str = 'intercept', fid: int = 1):
    """红方课题说明：决策变量 / 约束清单 / 目标函数 / 蓝方对手口径。

    约束清单与 ``uav_red`` 里真正执行的 ``check()`` 同源 —— 界面上 C5 那一行会
    按课题显示「本课题已豁免」，不会出现界面与实现两套说法。
    """
    try:
        return uav_api.describe_uav_red(mode, fid)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.post('/api/uav/red/run')
def uav_red_run(req: UavRedReq):
    """跑一次红方优化（后台任务，前端沿用 LASE.taskPoll 轮询）。"""
    tid = _new_task()
    cancel = _tasks[tid]['cancel']

    def cb(nevals, max_evals):
        _set_progress(tid, nevals / max(max_evals, 1),
                      f'红方优化中 {nevals}/{max_evals}')

    def fn():
        return uav_api.run_uav_red(
            req.mode, req.fid, req.host, req.evals_mult, req.opponent,
            req.blue_runs, req.blue_evals, req.seed,
            progress_cb=cb, cancel_event=cancel)

    _run_task(tid, fn)
    return {'task_id': tid}


# ---------------------------------------------------------------------------
# 红方优化模型的本体 / 知识图谱（由 uav_red 注册表现场生成，无外部本体文件）
# ---------------------------------------------------------------------------
# 与上面的「课题说明」同源：约束 / 变量 / 单元 / 指标都从 uav_red 与 uav_api 的
# 注册表读取，因此图上内容与仿真实现不会出现两套说法。
@app.get('/api/ontology/uav/filters')
def get_uav_ontology_filters(scenario: str = ''):
    """筛选下拉的候选项：场景（intercept / swarm）、想定（U*）与课题（F1–F4）。

    与两张图同源（默认视图 = 已登记场景 + 首个想定 + 首个课题）；``scenario`` 给定
    未登记场景时只用于提示缺口，不改变已登记场景的可选项。
    """
    return ontology_api.filter_options(scenario=scenario)


@app.get('/api/ontology/uav')
def get_uav_ontology(mode: str = '', scenario: str = ''):
    """本体图（类别层）：根问题 → 课题 → 决策变量 → 单元 → 约束 → 目标项 / 对手 / 指标。

    ``mode`` 省略 / ``all`` = 全量元模型；给定课题 = 该课题的切片（含豁免约束标注）。
    ``scenario`` 未登记红方模型时返回缺口视图（``supported=False``），不套用其他场景口径。
    """
    try:
        return ontology_api.build_ontology(mode=mode, scenario=scenario)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.get('/api/ontology/uav/kg')
def get_uav_ontology_kg(fid: str = '', mode: str = '', scenario: str = ''):
    """知识图谱（实例层）：场景 → 想定（U1/U3/U4）→ 课题 → 变量 / 单元编成 → 约束 → 指标。

    ``fid`` / ``mode`` 省略或 ``all`` = 该维度不筛（总览）；两个都给 = 单个想定
    子图，如 ``?scenario=intercept&fid=3&mode=intercept``（U3 双机拦截下的 F3 拦截）。
    """
    try:
        return ontology_api.build_kg(fid=fid, mode=mode, scenario=scenario)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.get('/api/ontology/uav/matrix')
def get_uav_ontology_matrix(scenario: str = ''):
    """「约束 × 课题」矩阵：行 = C1–C6，列 = F1–F4，格 = 生效 / 豁免 + 检查单元。

    场景未登记红方模型时返回 ``supported=False`` 与缺口提示。
    """
    try:
        return ontology_api.constraint_matrix(scenario=scenario)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})


@app.get('/api/ontology/uav/export')
def export_uav_ontology(kind: str = 'ontology', fmt: str = 'jsonld',
                        fid: str = '', mode: str = '', scenario: str = ''):
    """导出三元组：``kind=ontology|kg``，``fmt=jsonld|csv``（可直接喂 Neo4j / GraphRAG）。

    导出跟随当前视图口径（``scenario`` / ``fid`` / ``mode``），文件名带 scope key。
    """
    try:
        text, filename, media = ontology_api.export_graph(
            kind, fmt, fid=fid, mode=mode, scenario=scenario)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={'detail': str(exc)})
    return Response(content=text, media_type=media,
                    headers={'Content-Disposition':
                             f'attachment; filename="{filename}"'})


# ---------------------------------------------------------------------------
# UAV 仿真数据存档（记录先前运行结果，供回放查看）
# ---------------------------------------------------------------------------
@app.get('/api/uav/archive')
def uav_archive_list(request: Request):
    return uav_api.list_uav_archive(user=_user(request))


@app.post('/api/uav/archive')
def uav_archive_save(payload: Dict[str, Any], request: Request):
    return uav_api.save_uav_archive(payload, user=_user(request))


@app.get('/api/uav/archive/load')
def uav_archive_load(scenario: str, name: str, request: Request):
    return uav_api.load_uav_archive(scenario, name, user=_user(request))


@app.delete('/api/uav/archive')
def uav_archive_delete(scenario: str, name: str, request: Request):
    return {'ok': uav_api.delete_uav_archive(scenario, name, user=_user(request))}


@app.post('/api/task/{tid}/cancel')
def task_cancel(tid: str):
    with _tasks_lock:
        t = _tasks.get(tid)
        if t is not None and t['state'] == 'running':
            t['cancel'].set()
            return {'ok': True}
    return {'ok': False}


@app.get('/api/task/{tid}')
def task_status(tid: str):
    with _tasks_lock:
        t = _tasks.get(tid)
        if t is None:
            return {'state': 'not_found'}
        return {'state': t['state'], 'progress': t['progress'],
                'message': t['message'], 'result': t['result'],
                'error': t['error'], 'live': t.get('live') or {}}


# ---------------------------------------------------------------------------
# 静态前端（最后挂载，避免吞掉 API 路由）
# ---------------------------------------------------------------------------
app.mount('/', StaticFiles(directory=str(STATIC_DIR), html=True), name='static')

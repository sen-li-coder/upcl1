# -*- coding: utf-8 -*-
"""实验任务管理器：编排 run_upcl_cec.py 子进程 + tail 日志 + 解析进度。

与 gui_launcher.py 的「subprocess.Popen + 读日志」同构，计算层零改动。
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import constants as C
from . import workspace

_PROGRESS_RE = re.compile(
    r'\s*(\d+)/(\d+)\s*\(([\d.]+)%\)\s*elapsed\s+([\d.]+)\s*min'
    r'\s*eta\s+([\d.]+)\s*min')

# 保留给前端的日志缓冲行数
_TAIL_LIMIT = 4000


class ExperimentManager:
    def __init__(self):
        self._lock = threading.Lock()
        self.proc = None
        self._tail_thread = None
        self.state = 'idle'            # idle / running / stopping / done / error
        self.suite = None
        self.dim = None
        self.started_at = None
        self.user = None               # 当前实验归属用户（None=公共区/本地）
        self._stop_requested_at = None
        self.exit_code = None

        # 启动参数（resume 复用）
        self._params = None

        # 日志缓冲（tail 线程写，WebSocket 读）
        self._log_lock = threading.Lock()
        self._tail_buffer = []          # list[str]
        self._tail_seq = 0              # 单调递增序号
        self.last_progress = {}         # 最近一次进度解析结果

        self._log_fh = None

    def _paths(self):
        """当前实验的 (out_dir, log_dir, stop_file, pause_file, status_dir)。

        用户私有实验写 ``data/users/<u>/results/cec/``，本地/公共写
        ``results/cec/``。
        """
        if self.user:
            out = workspace.user_results(self.user)
            logs = workspace.user_logs(self.user)
            return out, logs, out / '.stop', out / '.pause', logs / '.workers'
        return C.RAW.parent, C.LOG_DIR, C.STOP_FILE, C.PAUSE_FILE, C.STATUS_DIR

    # ------------------------------------------------------------------ 状态
    def _snapshot_state(self):
        with self._lock:
            running = self.proc is not None and self.proc.poll() is None
            return self.state, running, (self.proc.pid if self.proc else None)

    def status(self):
        state, running, pid = self._snapshot_state()
        _, log_dir, _, _, _ = self._paths()
        return {
            'state': state,
            'running': running,
            'pid': pid,
            'suite': self.suite,
            'dim': self.dim,
            'user': self.user,
            'log_path': str(log_dir / f'{self.suite}_D{self.dim}.log')
            if self.suite else None,
            'started_at': self.started_at,
            'progress': self.last_progress,
        }

    # ------------------------------------------------------------------ 启动
    def start(self, suite, dim, hosts, runs, workers, evals_mult, upcl, user=None):
        with self._lock:
            state, running, _ = self._snapshot_state()
            if running:
                return {'ok': False, 'msg': '已有实验在运行，请先停止或等待完成'}
            if not hosts:
                return {'ok': False, 'msg': '请至少选择一个算法'}

            self.user = user
            out_dir, log_dir, stop_file, pause_file, _ = self._paths()

            log_dir.mkdir(parents=True, exist_ok=True)
            log_path = log_dir / f'{suite}_D{dim}.log'
            if log_path.exists():
                log_path.unlink()

            cmd = [sys.executable, '-X', 'utf8', '-u', str(C.RUN_SCRIPT),
                   '--stage', 'main',
                   '--suites', suite,
                   '--dims', str(dim),
                   '--hosts'] + list(hosts) + [
                   '--runs', str(runs),
                   '--workers', str(workers),
                   '--evals-mult', str(evals_mult),
                   '--out-dir', str(out_dir)]
            if not upcl:
                cmd.append('--no-upcl')

            # 清掉陈旧标记（run_upcl_cec 内部也会清，这里双保险）
            for f in (stop_file, pause_file):
                if f.exists():
                    f.unlink()

            # 用户私有实验：把插件目录通过环境变量传给子进程，worker spawn
            # 继承后 blackbox_host 才能加载/执行该用户的私有插件。
            env = None
            if user:
                env = dict(os.environ)
                env['UPCL_PLUGINS_DIR'] = str(workspace.user_plugins(user))

            self._log_fh = open(log_path, 'w', encoding='utf-8')
            self.proc = subprocess.Popen(
                cmd, cwd=str(C.ROOT),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=1, env=env)
            self.state = 'running'
            self.suite = suite
            self.dim = dim
            self.started_at = time.time()
            self._stop_requested_at = None
            self.exit_code = None
            self.last_progress = {}
            self._params = dict(suite=suite, dim=dim, hosts=list(hosts),
                                runs=runs, workers=workers,
                                evals_mult=evals_mult, upcl=upcl, user=user)
            with self._log_lock:
                self._tail_buffer = []
                self._tail_seq = 0

            self._tail_thread = threading.Thread(
                target=self._tail_loop, args=(log_path,), daemon=True)
            self._tail_thread.start()
            return {'ok': True, 'pid': self.proc.pid, 'cmd': cmd}

    def _tail_loop(self, log_path):
        """读子进程 stdout，逐行写日志文件 + 缓冲 + 解析进度。"""
        try:
            for raw in iter(self.proc.stdout.readline, b''):
                text = raw.decode('utf-8', errors='replace')
                if self._log_fh is not None:
                    self._log_fh.write(text)
                    self._log_fh.flush()
                with self._log_lock:
                    self._tail_buffer.append(text)
                    self._tail_seq += 1
                    if len(self._tail_buffer) > _TAIL_LIMIT:
                        self._tail_buffer = self._tail_buffer[-_TAIL_LIMIT:]
                self._parse_progress(text)
        except Exception:
            pass
        finally:
            try:
                self.proc.wait()
            except Exception:
                pass
            self.exit_code = self.proc.poll()
            if self._log_fh is not None:
                self._log_fh.close()
                self._log_fh = None
            with self._lock:
                if self._stop_requested_at is not None:
                    self.state = 'done'   # 优雅停止完成
                elif self.exit_code == 0:
                    self.state = 'done'
                else:
                    self.state = 'error'
            self._stop_requested_at = None

    def _parse_progress(self, text):
        m = _PROGRESS_RE.search(text)
        if m:
            self.last_progress = {
                'finished': int(m.group(1)),
                'total': int(m.group(2)),
                'pct': float(m.group(3)),
                'elapsed_min': float(m.group(4)),
                'eta_min': float(m.group(5)),
            }

    # ------------------------------------------------------------------ 控制
    def stop(self):
        """优雅停止：写 .stop 标记，子进程在 cell 边界停。"""
        _, _, stop_file, _, _ = self._paths()
        stop_file.parent.mkdir(parents=True, exist_ok=True)
        stop_file.write_text('stop', encoding='utf-8')
        with self._lock:
            if self.proc is not None and self.proc.poll() is None:
                self.state = 'stopping'
                self._stop_requested_at = time.time()
        return {'ok': True}

    def resume(self):
        """续跑：删 .stop/.pause，用原参数重新启动（--resume 默认开启）。"""
        _, _, stop_file, pause_file, _ = self._paths()
        for f in (stop_file, pause_file):
            if f.exists():
                f.unlink()
        p = self._params
        if not p:
            return {'ok': False, 'msg': '没有可续跑的任务'}
        return self.start(p['suite'], p['dim'], p['hosts'], p['runs'],
                          p['workers'], p['evals_mult'], p['upcl'],
                          p.get('user'))

    def kill(self):
        """强制终止整棵进程树。"""
        with self._lock:
            pid = self.proc.pid if self.proc else None
        if pid is None:
            return {'ok': False, 'msg': '无运行中的进程'}
        try:
            subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'],
                           capture_output=True, timeout=15)
        except Exception as e:
            try:
                self.proc.kill()
            except Exception:
                pass
        self.state = 'error'
        return {'ok': True}

    # ------------------------------------------------------------------ 数据
    def tail_since(self, seq):
        """返回 seq 之后的日志行 + 新 seq。"""
        with self._log_lock:
            if seq >= self._tail_seq:
                return [], self._tail_seq
            # _tail_buffer 只保留最近 _TAIL_LIMIT 行；buffer[0] 对应的全局序号
            # 是 _tail_seq - len(buffer)，需按该偏移换算，否则裁剪后索引会错位。
            base = self._tail_seq - len(self._tail_buffer)
            start = max(0, seq - base)
            lines = self._tail_buffer[start:]
            return lines, self._tail_seq

    def worker_status(self):
        """读取当前实验 logs/.workers 下的实时 worker 状态。"""
        _, _, _, _, status_dir = self._paths()
        workers = []
        if status_dir.is_dir():
            for p in sorted(status_dir.glob('w*.json')):
                try:
                    with open(p, 'r', encoding='utf-8') as fh:
                        workers.append(json.load(fh))
                except Exception:
                    continue
        done = []
        done_log = status_dir / 'done.log'
        if done_log.exists():
            try:
                with open(done_log, 'r', encoding='utf-8') as fh:
                    tail = fh.readlines()[-20:]
                for line in tail:
                    try:
                        done.append(json.loads(line))
                    except Exception:
                        continue
            except Exception:
                pass
        return {'workers': workers, 'done': done}


manager = ExperimentManager()

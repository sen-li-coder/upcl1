# -*- coding: utf-8 -*-
"""Web 后端常量与路径（与 gui_launcher.py 保持一致，但不依赖 tkinter）。

算法清单单一数据源仍是 src/de_hosts_cec.py 的 CEC_HOST_ORDER。
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # e:/LASE
SRC = ROOT / 'src'
sys.path.insert(0, str(SRC))

DATA_DIR = ROOT / 'data'                            # 多用户私有数据根目录

RAW = ROOT / 'results' / 'cec' / 'raw'
STOP_FILE = ROOT / 'results' / 'cec' / '.stop'
PAUSE_FILE = ROOT / 'results' / 'cec' / '.pause'
LOG_DIR = ROOT / 'results' / 'cec' / 'logs'
STATUS_DIR = LOG_DIR / '.workers'                   # worker 实时状态
TABLES_DIR = ROOT / 'results' / 'cec' / 'tables'
FIGURES_DIR = ROOT / 'results' / 'cec' / 'figures'
RUN_SCRIPT = SRC / 'run_upcl_cec.py'
PLUGINS_DIR = ROOT / 'plugins'                     # 客户自定义算法（黑盒插件）目录

GRACE_SECONDS = 30 * 60

# 29 个算法：仅作为 import 失败时的回退，顺序必须与 CEC_HOST_ORDER 一致
_H0 = [
    'DE/rand/1', 'DE/best/1', 'DE/rand/2', 'DE/current-to-best/1',
    'DE/current-to-rand/1', 'DE/rand/1/either-or',
    'jDE', 'SaNSDE',
    'JADE', 'SHADE', 'CoBiDE', 'SaDE', 'EPSDE', 'CoDE', 'MPEDE',
    'L-SHADE', 'jSO', 'L-SHADE-RSP', 'NL-SHADE-RSP', 'MadDE',
    'jDE100', 'j2020', 'DISH', 'DISK', 'LSHADE-cnEpSin', 'SinDE',
    'IMODE', 'PaDE', 'SHADE-ILS',
]


def _load_host_order():
    try:
        import de_hosts_cec
        order = list(de_hosts_cec.CEC_HOST_ORDER)
        if order:
            return order
    except Exception:
        pass
    return list(_H0)


HOSTS = _load_host_order()

SUITES = ['cec2017', 'cec2022', 'cec2013', 'cec2014', 'cec2015']
SUITE_LABELS = {'cec2017': 'CEC2017', 'cec2022': 'CEC2022',
                'cec2013': 'CEC2013', 'cec2014': 'CEC2014',
                'cec2015': 'CEC2015'}
SUITE_LEGAL_DIMS = {'cec2017': (30, 50), 'cec2022': (10, 20),
                    'cec2013': (10, 30, 50, 100),
                    'cec2014': (10, 20, 30, 50, 100),
                    'cec2015': (10, 30)}
SUITE_NFUNCS = {'cec2017': 29, 'cec2022': 12, 'cec2013': 28,
                'cec2014': 30, 'cec2015': 15}

# 前 20 旧宿主（期望 bare+upcl），后 9 wave4 变体（期望 bare+full）
LEGACY_HOSTS = HOSTS[:20]
WAVE4_HOSTS = set(HOSTS[20:])


def _load_blackbox_hosts():
    """客户黑盒插件宿主（plugins/*.json）：可被选中运行，但从不产出 CEC 数据。

    这类宿主不是 DE 算法，不参与 CEC 完成度统计（公共目录里的 LLMMock/LLMTest
    两个演示插件已退役归档，故当前通常为空集）。
    """
    try:
        import de_hosts_cec
        return set(getattr(de_hosts_cec, 'BLACKBOX_HOSTS', ()) or ())
    except Exception:
        return set()


BLACKBOX_HOSTS = _load_blackbox_hosts()

# CEC 数据完成度只用真实算法做分母（文档口径 = 29 个）
CEC_HOSTS = [h for h in HOSTS if h not in BLACKBOX_HOSTS]

# wave4 变体实际参与运行的 (suite, dim) 集合；其余维度只有 legacy 宿主。
# 数据存档的「总 cell」分母据此计算：在集合内的维度按全量 29 宿主计，
# 未跑 wave4 的维度按 legacy 20 宿主计。cec2017 D50 的 wave4 变体在其他
# 机器补跑中，数据拷入前会显示为「缺失」从而拉低完成百分比，拷入后自动补满。
WAVE4_DIMS = {('cec2017', 30), ('cec2017', 50), ('cec2022', 10),
              ('cec2022', 20)}
ARCHIVE_SUITES = ['cec2022', 'cec2017', 'cec2013']
SUITE_FIDS = {
    'cec2022': list(range(1, 13)),
    'cec2017': [1] + list(range(3, 31)),
    'cec2013': list(range(1, 29)),
}

# 绘图臂语义：bare=基线；upcl/full 统一为「增加 UPCL」
ARM_DISPLAY = {'bare': '基线', 'upcl': '增加 UPCL'}

# 5 个描述子（z0~z4）：与 gui_launcher.py DESC_NAMES 一致（中文名作为 key）
DESC_NAMES = [
    ('ρ 步长比', '相对步长（对数尺度，种群相对）'),
    ('θ 方向对齐', '与已学成功方向的对齐'),
    ('η 精英距离', '与当前精英方向的对齐'),
    ('κ 拥挤度', '落点与参考点的最近距离'),
    ('ν 新颖度', '方向相对原型集的新颖度'),
]
RHO_CURVE_PTS = 50


_AVAILABLE_DIMS_CACHE = None


def available_dims(user=None):
    """扫描 RAW（+用户私有 raw）下每个 suite 实际存在的 D{int} 目录。

    返回 {suite: [dims]}，用户私有目录与公共目录取并集。数据现状
    （results/cec/raw）：cec2022 只有 D20、cec2017 有 D30/D50、cec2013 只有
    D10。前端维度下拉与默认值以此为准，避免选到无数据维度。
    """
    dirs = [RAW]
    if user:
        from . import workspace
        dirs.insert(0, workspace.user_raw(user))
    out = {}
    for base in dirs:
        if not base.is_dir():
            continue
        for sd in base.iterdir():
            if not sd.is_dir():
                continue
            dims = set()
            for dd in sd.iterdir():
                m = re.match(r'D(\d+)$', dd.name)
                if dd.is_dir() and m:
                    dims.add(int(m.group(1)))
            if dims:
                out.setdefault(sd.name, set()).update(dims)
    return {k: sorted(v) for k, v in out.items()}

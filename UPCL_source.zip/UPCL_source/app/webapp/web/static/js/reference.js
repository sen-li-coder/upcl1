/* 算法与测试集说明页：集中介绍平台集成的算法与基准，写清楚出处、摘要与大致做法 */
LASE.register('reference', {
  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'reference' });
    page.innerHTML = `
      <div class="card intro-card">
        <div class="card-title">${LASE.t('平台说明')}</div>
        <p>${LASE.t('本平台集成了 {0} 种差分进化（DE）算法变体与 {1} 套 CEC 单目标基准测试集，并叠加 UPCL 机制探针做「纯算法 vs 纯算法 + UPCL」的对照研究。下方列出了每个算法与测试集的出处、摘要与大致做法，也可在其它页面悬停算法名称或点击「ⓘ」查看。', LASE.meta.hosts.length, LASE.meta.suites.length)}</p>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('UPCL 机制')}</div>
        <p style="line-height:1.8;margin:0">${LASE._esc(LASE.upclIntro)}</p>
        <div style="margin-top:10px">
          <button class="btn" onclick="LASE.navigate('mechanism')">${LASE.t('前往「机制分析」查看描述子与效应量 →')}</button>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('差分进化算法（{0} 种）', LASE.meta.hosts.length)}</div>
        <p class="hint" style="margin:0 0 12px">${LASE.t('点击「出处」可在 Google Scholar 检索对应论文。')}</p>
        <div class="ref-grid" id="ref-hosts"></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('测试集（CEC 基准）')}</div>
        <p class="hint" style="margin:0 0 12px">${LASE.t('点击链接查看官方说明。')}</p>
        <div class="ref-grid" id="ref-suites"></div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._renderHosts();
    this._renderSuites();
  },

  _scholar(name, r) {
    return 'https://scholar.google.com/scholar?q='
      + encodeURIComponent(name + ' ' + String(r || '').replace(/[^A-Za-z0-9 ]/g, ' '));
  },

  _renderHosts() {
    const box = document.getElementById('ref-hosts');
    box.innerHTML = LASE.meta.hosts.map(h => {
      const info = LASE.hostInfo[h] || {};
      const src = info.r || '';
      const link = src ? `<a href="${this._scholar(h, src)}" target="_blank" rel="noopener">${LASE._esc(src)} ↗</a>` : '<span class="muted">—</span>';
      return `<div class="ref-card">
        <div class="ref-name">${LASE._esc(h)}</div>
        <div class="ref-src">${link}</div>
        <div class="ref-desc">${LASE._esc(info.d || '')}</div>
        <div class="ref-abs">${LASE._esc(info.abs || '')}</div>
      </div>`;
    }).join('');
  },

  _renderSuites() {
    const box = document.getElementById('ref-suites');
    box.innerHTML = LASE.meta.suites.map(s => {
      const si = LASE.suiteInfo[s] || {};
      const url = si.url || '';
      const link = url
        ? `<a href="${url}" target="_blank" rel="noopener">${LASE.t('官方说明 ↗')}</a>`
        : '';
      return `<div class="ref-card">
        <div class="ref-name">${LASE._esc(si.name || s)}</div>
        <div class="ref-src">${LASE._esc(s)}</div>
        <div class="ref-desc">${LASE._esc(si.desc || '')}</div>
        <div class="ref-abs">${link}</div>
      </div>`;
    }).join('');
  },
});

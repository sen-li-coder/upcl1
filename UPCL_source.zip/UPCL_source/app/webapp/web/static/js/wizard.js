/* 算法接入向导：一步步引导客户把自己的算法（黑盒可执行程序）接入平台 */
LASE.register('wizard', {
  _step: 0,
  _form: { name: '', desc: '', abs: '', ref: '', exec: '', extra_args: '', timeout_s: 600, params: [] },
  _testStop: null,
  _testResult: null,

  _steps: [
    { t: '准备程序', d: '理解黑盒协议' },
    { t: '填写信息', d: '算法描述与命令' },
    { t: '确认保存', d: '生成插件文件' },
    { t: '冒烟自检', d: '验证协议与收敛' },
    { t: '完成', d: '去对比你的算法' },
  ],

  // 最小可运行示例（Python 随机搜索），演示黑盒协议；客户可下载后改写成自己的算法。
  _template: `# 黑盒算法接入示例（随机搜索）。用任意语言改写，只要遵守 stdin/stdout JSON 协议。
import json, sys, random

def read_msg():
    line = sys.stdin.readline()
    return json.loads(line) if line else None

def send(obj):
    print(json.dumps(obj), flush=True)

def main():
    rng = None
    dim = lb = ub = None
    x = best_x = None
    best_f = None
    while True:
        msg = read_msg()
        if msg is None:
            break
        cmd = msg.get('cmd')
        if cmd == 'init':
            dim = msg['dim']; lb = msg['lb']; ub = msg['ub']
            rng = random.Random(msg.get('seed', 0))
            x = [rng.uniform(lb[i], ub[i]) for i in range(dim)]
            send({'cmd': 'eval', 'x': x})
        elif cmd == 'f':
            f = msg['f']
            if best_f is None or f < best_f:
                best_f, best_x = f, x[:]
            # 简单随机搜索：在当前解附近扰动
            for i in range(dim):
                x[i] = min(max(x[i] + rng.gauss(0, (ub[i] - lb[i]) * 0.05), lb[i]), ub[i])
            send({'cmd': 'eval', 'x': x})
        elif cmd == 'stop':
            break

if __name__ == '__main__':
    main()
`,

  _protocolHtml: `
    <p>${LASE.t('平台作为「评估服务」，你的程序负责搜索；两者通过')} <b>stdin / stdout 的 JSON 行</b>${LASE.t('通信（UTF-8，每行一个 JSON）：')}</p>
    <ol style="margin:6px 0 10px;padding-left:20px;line-height:1.9">
      <li>${LASE.t('启动后，平台先发一行')} <code>{"cmd":"init","dim":10,"lb":[...],"ub":[...],"max_evals":100000,"seed":20240000,"params":{...}}</code>${LASE.t('，其中')} <code>params</code> ${LASE.t('是你填写的全部算法参数（可任意增删）。')}</li>
      <li>${LASE.t('你的程序需要评估某个解 x 时，打印')} <code>{"cmd":"eval","x":[1.2,-3.4,...]}</code>。</li>
      <li>${LASE.t('平台计算 f(x) 后回一行')} <code>{"cmd":"f","f":123.456}</code>。</li>
      <li>${LASE.t('评估次数达到预算后，平台回')} <code>{"cmd":"stop"}</code> ${LASE.t('并关闭输入，此时应正常退出。')}</li>
    </ol>
    <p class="muted">${LASE.t('平台会自动记录每一次评估，并维护「已评估点最小值」作为收敛曲线，你无需上报历史最优。')}</p>`,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'wizard' });
    page.innerHTML = `
      <div class="card intro-card">
        <div class="card-title">${LASE.t('算法接入向导')}</div>
        <p>${LASE.t('按步骤把你的算法接进平台。接入方式为<b>黑盒可执行协议</b>：你用任意语言写一个可执行程序，平台作为评估服务向它提供 f(x)。不需要提供任何源码，接好后即可在「实验运行」页与内置 {0} 种算法对比。', LASE.meta ? LASE.meta.hosts.length : '多')}</p>
      </div>
      <div class="card">
        <div class="wiz-steps" id="wiz-steps"></div>
        <div class="wiz-body" id="wiz-body"></div>
        <div class="wiz-actions" id="wiz-actions"></div>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('已接入的算法（插件）')}</div>
        <div id="wiz-plugins"></div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._renderSteps();
    this._renderStep();
    this._renderActions();
  },

  show() {
    this._refreshPlugins();
  },

  // ------------------------------------------------------------------ 步骤条
  _renderSteps() {
    const box = document.getElementById('wiz-steps');
    box.innerHTML = this._steps.map((s, i) => `
      <div class="wiz-step ${i === this._step ? 'on' : ''} ${i < this._step ? 'done' : ''}" data-i="${i}">
        <span class="wiz-step-no">${i + 1}</span>
        <span class="wiz-step-t">${LASE._esc(LASE.t(s.t))}</span>
        <span class="wiz-step-d">${LASE._esc(LASE.t(s.d))}</span>
      </div>`).join('');
    box.querySelectorAll('.wiz-step').forEach(el => {
      el.onclick = () => { this._step = parseInt(el.dataset.i); this._renderSteps(); this._renderStep(); this._renderActions(); };
    });
  },

  _renderStep() {
    const box = document.getElementById('wiz-body');
    if (this._step === 0) box.innerHTML = this._renderStep0();
    else if (this._step === 1) box.innerHTML = this._renderStep1();
    else if (this._step === 2) box.innerHTML = this._renderStep2();
    else if (this._step === 3) box.innerHTML = this._renderStep3();
    else box.innerHTML = this._renderStep4();
    this._bindStep();
  },

  _bindStep() {
    if (this._step === 1) {
      this._renderParamRows();
      const up = document.getElementById('wz-upload');
      const fi = document.getElementById('wz-file');
      if (up && fi) up.onclick = () => fi.click();
      if (fi) fi.onchange = () => this._upload(fi);
      const add = document.getElementById('wz-add-param');
      if (add) add.onclick = () => { this._form.params.push({ k: '', v: '' }); this._renderParamRows(); };
      const llm = document.getElementById('wz-llm');
      if (llm) llm.onclick = () => this._applyLlmTemplate();
    }
  },

  _renderActions() {
    const box = document.getElementById('wiz-actions');
    box.innerHTML = '';
    if (this._step > 0) LASE.btn(box, LASE.t('上一步'), '', () => this._go(-1));
    if (this._step < 4) LASE.btn(box, LASE.t('下一步'), 'primary', () => this._next());
  },

  _go(d) { this._step += d; this._renderSteps(); this._renderStep(); this._renderActions(); },

  _next() {
    if (this._step === 1) {
      const f = this._readForm();
      if (!f.name) { alert(LASE.t('请填写算法名称')); return; }
      if (!f.exec) { alert(LASE.t('请上传可执行文件或填写可执行命令')); return; }
    }
    if (this._step === 2) { this._save(); return; }
    if (this._step === 3) { this._go(1); return; }
    this._go(1);
  },

  // ------------------------------------------------------------------ 各步骤
  _renderStep0() {
    return `
      <h3 class="wiz-h">${LASE.t('第 1 步 · 准备你的可执行程序')}</h3>
      ${this._protocolHtml}
      <div class="wiz-code-title">${LASE.t('最小可运行示例（Python 随机搜索）')}</div>
      <pre class="wiz-code">${LASE._esc(this._template)}</pre>
      <div style="margin-top:10px">
        <button class="btn" id="wiz-dl-template">${LASE.t('下载示例模板 my_algorithm.py')}</button>
        <span class="hint" style="margin-left:8px">${LASE.t('下载后改写其中的搜索逻辑，编译/保存成可执行程序（exe 或脚本）。')}</span>
      </div>`;
  },

  _renderStep1() {
    const f = this._form;
    return `
      <h3 class="wiz-h">${LASE.t('第 2 步 · 填写算法信息')}</h3>
      <div class="wiz-form">
        <div class="field" style="min-width:280px">
          <label>${LASE.t('算法名称（必填，将显示在算法列表中）')}</label>
          <input type="text" id="wz-name" value="${LASE._esc(f.name)}" placeholder="${LASE.t('例如 MyPSO / MyGA')}">
        </div>
        <div class="field" style="min-width:480px">
          <label>${LASE.t('可执行程序（点「上传文件」自动填写，也可手动输入命令）')}</label>
          <div class="wiz-exec-row">
            <input type="text" id="wz-exec" value="${LASE._esc(f.exec)}" placeholder="${LASE.t('上传 .exe / .py 后自动填充')}">
            <button class="btn" id="wz-upload" type="button">${LASE.t('📁 上传文件')}</button>
            <input type="file" id="wz-file" accept=".exe,.bat,.cmd,.com,.py" style="display:none">
          </div>
        </div>
        <div class="field" style="width:100%">
          <label>${LASE.t('或者，接入一个大模型算法（无需上传文件）')}</label>
          <div>
            <button class="btn" id="wz-llm" type="button">${LASE.t('🤖 使用大模型优化器（DeepSeek）')}</button>
            <span class="hint" style="margin-left:8px">${LASE.t('自动填好可执行命令与参数模板，你只需填 API Key。')}</span>
          </div>
        </div>
        <div class="field" style="min-width:280px">
          <label>${LASE.t('附加命令行参数（可选，空格分隔）')}</label>
          <input type="text" id="wz-args" value="${LASE._esc(f.extra_args)}" placeholder="${LASE.t('例如 --pop 100')}">
        </div>
        <div class="field" style="width:100%">
          <label>${LASE.t('算法参数（可选，会通过 init 消息的 <code>params</code> 字段传给程序，可任意增删）')}</label>
          <div id="wz-params"></div>
          <button class="btn" id="wz-add-param" type="button">${LASE.t('+ 添加参数')}</button>
        </div>
        <div class="field" style="min-width:140px">
          <label>${LASE.t('超时秒数（可选）')}</label>
          <input type="number" id="wz-timeout" value="${f.timeout_s}" min="10" max="3600" step="10">
        </div>
        <div class="field" style="min-width:280px">
          <label>${LASE.t('一句话机制说明（可选）')}</label>
          <input type="text" id="wz-desc" value="${LASE._esc(f.desc)}" placeholder="${LASE.t('例如 带惯性权重的粒子群优化')}">
        </div>
        <div class="field" style="min-width:480px">
          <label>${LASE.t('摘要（可选）')}</label>
          <input type="text" id="wz-abs" value="${LASE._esc(f.abs)}" placeholder="${LASE.t('大致做了什么')}">
        </div>
        <div class="field" style="min-width:280px">
          <label>${LASE.t('出处（可选）')}</label>
          <input type="text" id="wz-ref" value="${LASE._esc(f.ref)}" placeholder="${LASE.t('作者 & 年份')}">
        </div>
      </div>`;
  },

  _renderStep2() {
    const f = this._form;
    const paramsStr = JSON.stringify(this._paramsToObj(f.params));
    return `
      <h3 class="wiz-h">${LASE.t('第 3 步 · 确认并保存')}</h3>
      <div class="wiz-form">
        <div class="wiz-kv"><span>${LASE.t('算法名称')}</span><b>${LASE._esc(f.name || '—')}</b></div>
        <div class="wiz-kv"><span>${LASE.t('可执行命令')}</span><b class="mono">${LASE._esc(f.exec || '—')}</b></div>
        <div class="wiz-kv"><span>${LASE.t('附加参数')}</span><b class="mono">${LASE._esc(f.extra_args || LASE.t('（无）'))}</b></div>
        <div class="wiz-kv"><span>${LASE.t('算法参数')}</span><b class="mono">${LASE._esc(paramsStr)}</b></div>
        <div class="wiz-kv"><span>${LASE.t('超时')}</span><b>${f.timeout_s}s</b></div>
        <div class="wiz-kv"><span>${LASE.t('说明')}</span><b>${LASE._esc(f.desc || '—')}</b></div>
        <div class="wiz-kv"><span>${LASE.t('出处')}</span><b>${LASE._esc(f.ref || '—')}</b></div>
      </div>
      <p class="hint" style="margin-top:10px">${LASE.t('点击「下一步」会生成插件文件到')} <span class="mono">plugins/</span> ${LASE.t('目录，并注册进算法列表。')}</p>
      <div id="wz-save-msg" style="margin-top:8px"></div>`;
  },

  _renderStep3() {
    return `
      <h3 class="wiz-h">${LASE.t('第 4 步 · 冒烟自检')}</h3>
      <p>${LASE.t('系统会用 <b>cec2022 · D10 · F1</b> 跑 1000 次评估，验证协议链路能通、目标值有下降。')}</p>
      <div id="wz-test-msg" style="margin:10px 0"></div>
      <div class="progress-bar"><div id="wz-test-bar"></div></div>
      <div class="progress-text" id="wz-test-progress">${LASE.t('等待开始')}</div>
      <div id="wz-test-result" style="margin-top:12px"></div>`;
  },

  _renderStep4() {
    const f = this._form;
    const ok = this._testResult && this._testResult.ok;
    return `
      <h3 class="wiz-h">${LASE.t('第 5 步 · 完成')}</h3>
      <div class="wiz-done">
        <div class="wiz-done-ico">${ok ? '✅' : '🧩'}</div>
        <div class="wiz-done-txt">
          <b>「${LASE._esc(f.name || '')}」${LASE.t('已接入平台')}</b>
          <p class="hint">${ok
            ? LASE.t('自检通过：协议通信正常，目标值有下降。现在可以去对比你的算法了。')
            : LASE.t('可前往「实验运行」页，勾选你的算法与内置算法做对比（跑 bare 纯算法臂）。')}</p>
        </div>
      </div>
      <div style="margin-top:14px">
        <button class="btn primary" onclick="LASE.navigate('experiment')">${LASE.t('前往「实验运行」对比 →')}</button>
        <button class="btn" onclick="LASE.navigate('dashboard')">${LASE.t('返回主界面')}</button>
        <button class="btn" id="wz-restart">${LASE.t('再接入一个算法')}</button>
      </div>`;
  },

  // ------------------------------------------------------------------ 表单读取
  _readForm() {
    const g = id => document.getElementById(id);
    this._form.name = (g('wz-name')?.value || '').trim();
    this._form.exec = (g('wz-exec')?.value || '').trim();
    this._form.extra_args = (g('wz-args')?.value || '').trim();
    this._form.timeout_s = parseFloat(g('wz-timeout')?.value || '600') || 600;
    this._form.desc = (g('wz-desc')?.value || '').trim();
    this._form.abs = (g('wz-abs')?.value || '').trim();
    this._form.ref = (g('wz-ref')?.value || '').trim();
    this._form.params = this._readParamsFromDom();
    return this._form;
  },

  _readParamsFromDom() {
    const out = [];
    document.querySelectorAll('#wz-params .wiz-param-row').forEach(row => {
      const k = (row.querySelector('.pz-k')?.value || '').trim();
      const v = row.querySelector('.pz-v')?.value ?? '';
      if (k) out.push({ k, v });
    });
    return out;
  },

  _coerceStr(v) {
    const s = String(v ?? '').trim();
    if (s === '') return '';
    if (s === 'true' || s === 'false') return s === 'true';
    if (/^-?\d+$/.test(s)) return parseInt(s, 10);
    if (/^-?(\d+\.\d*|\.\d+|\d+)([eE][-+]?\d+)?$/.test(s)) return parseFloat(s);
    return s;
  },

  _paramsToObj(list) {
    const obj = {};
    (list || []).forEach(p => {
      const k = (p.k || '').trim();
      if (k) obj[k] = this._coerceStr(p.v);
    });
    return obj;
  },

  _renderParamRows() {
    const box = document.getElementById('wz-params');
    if (!box) return;
    if (!this._form.params.length) this._form.params = [{ k: '', v: '' }];
    box.innerHTML = this._form.params.map((p, i) => `
      <div class="wiz-param-row">
        <input type="text" class="pz-k" data-i="${i}" placeholder="${LASE.t('参数名，如 pop_size / F / use_restart')}" value="${LASE._esc(p.k || '')}">
        <input type="text" class="pz-v" data-i="${i}" placeholder="${LASE.t('值，如 100 / 0.5 / true')}" value="${LASE._esc(p.v ?? '')}">
        <button class="btn danger" data-del="${i}" type="button" title="${LASE.t('删除')}">✕</button>
      </div>`).join('');
    box.querySelectorAll('.pz-k').forEach(el => el.oninput = () => { this._form.params[+el.dataset.i].k = el.value; });
    box.querySelectorAll('.pz-v').forEach(el => el.oninput = () => { this._form.params[+el.dataset.i].v = el.value; });
    box.querySelectorAll('[data-del]').forEach(el => el.onclick = () => {
      this._form.params.splice(+el.dataset.del, 1);
      if (!this._form.params.length) this._form.params.push({ k: '', v: '' });
      this._renderParamRows();
    });
  },

  _applyLlmTemplate() {
    const f = this._form;
    f.exec = 'python _builtin/llm_optimizer.py';
    f.params = [
      { k: 'api_key', v: '' },
      { k: 'base_url', v: 'https://api.deepseek.com' },
      { k: 'model', v: 'deepseek-chat' },
      { k: 'temperature', v: '0.7' },
      { k: 'max_tokens', v: '4096' },
      { k: 'task_hint', v: '' },
      { k: 'history_window', v: '20' },
    ];
    if (!f.desc) f.desc = '大模型优化器（LLM-as-Optimizer，OPRO 风格）';
    const ex = document.getElementById('wz-exec');
    if (ex) ex.value = f.exec;
    const ds = document.getElementById('wz-desc');
    if (ds) ds.value = f.desc;
    this._renderParamRows();
    alert(LASE.t('已填入大模型优化器模板。请在下方的「算法参数」里填写 api_key（DeepSeek 密钥），其余参数可保持默认。'));
  },

  async _upload(input) {
    const name = (document.getElementById('wz-name')?.value || '').trim();
    if (!name) { alert(LASE.t('请先填写算法名称，再上传可执行文件')); input.value = ''; return; }
    const file = input.files && input.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('name', name);
    fd.append('file', file);
    const r = await LASE.api('/api/plugins/upload', { method: 'POST', body: fd });
    if (r && r.ok) {
      const ex = document.getElementById('wz-exec');
      if (ex) ex.value = r.exec;
      this._form.exec = r.exec;
    } else {
      alert((r && r.msg) || LASE.t('上传失败'));
    }
    input.value = '';
  },

  // ------------------------------------------------------------------ 保存 / 自检
  async _save() {
    const f = this._form;
    const msg = document.getElementById('wz-save-msg');
    const body = {
      name: f.name, exec: f.exec, desc: f.desc, abs: f.abs, ref: f.ref,
      extra_args: f.extra_args ? f.extra_args.split(/\s+/) : [],
      params: this._paramsToObj(f.params),
      timeout_s: f.timeout_s,
    };
    const r = await LASE.api('/api/plugins', { method: 'POST', body });
    if (r.ok) {
      msg.innerHTML = LASE.msg(LASE.t('插件已保存并注册成功'), 'ok');
      // 动态刷新算法列表，使实验运行页能立即看到
      if (!LASE.meta.hosts.includes(r.name)) LASE.meta.hosts.push(r.name);
      this._testResult = null;
      this._go(1);
      this._runTest();
    } else {
      msg.innerHTML = LASE.msg(r.msg || LASE.t('保存失败'), 'err');
    }
  },

  async _runTest() {
    const f = this._form;
    const msg = document.getElementById('wz-test-msg');
    const bar = document.getElementById('wz-test-bar');
    const prog = document.getElementById('wz-test-progress');
    const res = document.getElementById('wz-test-result');
    msg.innerHTML = LASE.msg(LASE.t('正在启动自检…'), 'info');
    res.innerHTML = '';
    bar.style.width = '15%';
    prog.textContent = LASE.t('自检运行中…（黑盒程序启动 + 1000 次评估，可能需数秒到数十秒）');
    const r = await LASE.api('/api/plugins/' + encodeURIComponent(f.name) + '/test', { method: 'POST' });
    if (this._testStop) this._testStop();
    this._testStop = LASE.taskPoll(r.task_id, {
      onProgress: () => { prog.textContent = LASE.t('自检运行中…（黑盒程序启动 + 1000 次评估，可能需数秒到数十秒）'); },
      onDone: (result) => {
        bar.style.width = '100%';
        prog.textContent = LASE.t('自检完成');
        this._testResult = result || {};
        if (result && result.ok) {
          res.innerHTML = `
            <div class="wiz-test-ok">
              <b>${LASE.t('自检通过')}</b>
              <div class="wiz-kv"><span>${LASE.t('评估次数')}</span><b>${result.nevals}</b></div>
              <div class="wiz-kv"><span>${LASE.t('初始误差')}</span><b class="mono">${result.err_first == null ? '—' : result.err_first.toExponential(3)}</b></div>
              <div class="wiz-kv"><span>${LASE.t('最终误差')}</span><b class="mono">${result.err_final.toExponential(3)}</b></div>
              <div class="wiz-kv"><span>${LASE.t('耗时')}</span><b>${result.wall_s}s</b></div>
            </div>`;
        } else {
          res.innerHTML = `<div class="wiz-test-err"><b>${LASE.t('自检失败')}</b><p>${LASE._esc((result && result.msg) || LASE.t('未知错误'))}</p></div>`;
        }
      },
      onError: (e) => { prog.textContent = LASE.t('自检异常'); res.innerHTML = `<div class="wiz-test-err"><b>${LASE.t('异常')}</b><p>${LASE._esc(e || '')}</p></div>`; },
    });
  },

  // ------------------------------------------------------------------ 已装插件
  async _refreshPlugins() {
    const box = document.getElementById('wiz-plugins');
    if (!box) return;
    try {
      const r = await LASE.api('/api/plugins');
      const list = r.plugins || [];
      if (!list.length) {
        box.innerHTML = '<p class="hint">' + LASE.t('暂无插件。按上方步骤接入你的第一个算法。') + '</p>';
        return;
      }
      box.innerHTML = list.map(p => `
        <div class="wiz-plugin">
          <div class="wiz-plugin-info">
            <div class="wiz-plugin-name">${LASE._esc(p.name)} ${p.validated ? '<span class="tag green">' + LASE.t('已自检') + '</span>' : ''}</div>
            <div class="wiz-plugin-meta mono">${LASE._esc(p.exec)}${p.extra_args && p.extra_args.length ? ' ' + LASE._esc(p.extra_args.join(' ')) : ''}</div>
            ${p.desc ? `<div class="hint">${LASE._esc(p.desc)}</div>` : ''}
          </div>
          <div class="wiz-plugin-acts">
            <button class="btn" data-test="${LASE._esc(p.name)}">${LASE.t('自检')}</button>
            <button class="btn danger" data-del="${LASE._esc(p.name)}">${LASE.t('删除')}</button>
          </div>
        </div>`).join('');
      box.querySelectorAll('[data-test]').forEach(b => b.onclick = () => { this._form.name = b.dataset.test; this._step = 3; this._renderSteps(); this._renderStep(); this._renderActions(); this._runTest(); });
      box.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
        if (!confirm(LASE.t('确定删除插件「{0}」？', b.dataset.del))) return;
        await LASE.api('/api/plugins/' + encodeURIComponent(b.dataset.del), { method: 'DELETE' });
        LASE.meta.hosts = LASE.meta.hosts.filter(h => h !== b.dataset.del);
        this._refreshPlugins();
      });
    } catch (e) { /* 忽略 */ }
  },
});

// 下载示例模板
document.addEventListener('click', (e) => {
  if (e.target && e.target.id === 'wiz-dl-template') {
    const blob = new Blob([LASE.pages.wizard._template], { type: 'text/plain' });
    LASE.downloadDataUrl(URL.createObjectURL(blob), 'my_algorithm.py');
  }
  if (e.target && e.target.id === 'wz-restart') {
    LASE.pages.wizard._form = { name: '', desc: '', abs: '', ref: '', exec: '', extra_args: '', timeout_s: 600, params: [] };
    LASE.pages.wizard._testResult = null;
    LASE.pages.wizard._step = 0;
    LASE.pages.wizard._renderSteps();
    LASE.pages.wizard._renderStep();
    LASE.pages.wizard._renderActions();
  }
});

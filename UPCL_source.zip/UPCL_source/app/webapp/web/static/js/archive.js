/* 数据存档页：完成度总览 + cell 状态 + 分析表格 + 图片 */
LASE.register('archive', {
  _data: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'archive' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('存档完成度总览')}</div>
        <div style="overflow:auto"><table class="tbl" id="arch-summary"></table></div>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('Cell 详细状态')}</div>
        <div class="row"><div class="field" id="arch-sel"></div></div>
        <div style="overflow:auto; max-height:420px; margin-top:8px"><table class="tbl" id="arch-cells"></table></div>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-title">${LASE.t('分析表格（CSV）')}</div>
          <div id="arch-tables" class="hint"></div>
          <div style="overflow:auto; max-height:300px; margin-top:8px"><table class="tbl" id="arch-table-view"></table></div>
        </div>
        <div class="card">
          <div class="card-title">${LASE.t('结果图片')}</div>
          <div class="legend" style="margin-bottom:8px">
            <span><span class="dot" style="background:#2c5f8a"></span>${LASE.t('点击放大')}</span>
          </div>
          <div id="arch-figures" style="display:flex; flex-wrap:wrap; gap:10px"></div>
        </div>
      </div>`;
    c.appendChild(page);
    this.page = page;
  },

  async show() { await this._load(); },

  async _load() {
    this._data = await LASE.api('/api/archive');
    this._renderSummary();
    this._renderSelect();
    this._renderTables();
    this._renderFigures();
  },

  _renderSummary() {
    const s = this._data.summary;
    const tbl = document.getElementById('arch-summary');
    if (!s.length) { tbl.innerHTML = '<tr><td class="muted">' + LASE.t('暂无数据') + '</td></tr>'; return; }
    let html = `<tr><th>${LASE.t('测试集')}</th><th>${LASE.t('维度')}</th><th>${LASE.t('总 cell')}</th><th>${LASE.t('已完成')}</th><th>${LASE.t('进度')}</th>` +
      `<th>${LASE.t('完整')}</th><th>${LASE.t('缺模式')}</th><th>${LASE.t('模式数异')}</th><th>R5</th><th>${LASE.t('其他')}</th><th>${LASE.t('缺失')}</th></tr>`;
    s.forEach(r => {
      html += `<tr><td>${r.suite}</td><td>D${r.dim}</td><td>${r.total}</td><td>${r.done}</td>` +
        `<td><b>${(r.pct * 100).toFixed(1)}%</b></td>` +
        `<td class="tag full">${r['完整']}</td><td class="tag bare">${r['缺模式']}</td>` +
        `<td class="tag arm">${r['模式数异']}</td><td class="tag r5">${r['R5']}</td>` +
        `<td class="tag other">${r['其他']}</td><td class="tag missing">${r['缺失']}</td></tr>`;
    });
    tbl.innerHTML = html;
  },

  _renderSelect() {
    const sel = document.getElementById('arch-sel');
    sel.innerHTML = '<label>' + LASE.t('选择 (测试集 / 维度)') + '</label>';
    const s = LASE.el('select');
    const keys = Object.keys(this._data.cells);
    keys.forEach(k => {
      const [suite, dim] = k.split(',');
      s.appendChild(LASE.el('option', { value: k, text: `${suite} · D${dim}` }));
    });
    s.onchange = () => this._renderCells(s.value);
    sel.appendChild(s);
    if (keys.length) this._renderCells(keys[0]);
  },

  _renderCells(key) {
    const tbl = document.getElementById('arch-cells');
    const rows = this._data.cells[key] || [];
    if (!rows.length) { tbl.innerHTML = '<tr><td class="muted">' + LASE.t('暂无') + '</td></tr>'; return; }
    let html = `<tr><th>${LASE.t('算法')}</th><th>${LASE.t('函数')}</th><th>runs_complete</th><th>arms</th><th>${LASE.t('状态')}</th></tr>`;
    rows.forEach(r => {
      const [host, fid, rc, arms, st] = r;
      const cls = st === '完整' ? 'full' : st === '缺模式' ? 'bare' :
        st === '模式数异' ? 'arm' : st === 'R5' ? 'r5' : 'other';
      html += `<tr><td>${host}</td><td>F${fid}</td><td class="mono">${rc}</td>` +
        `<td class="mono">${arms}</td><td><span class="tag ${cls}">${LASE.t(st)}</span></td></tr>`;
    });
    tbl.innerHTML = html;
  },

  _renderTables() {
    const box = document.getElementById('arch-tables');
    const tables = this._data.tables || [];
    box.innerHTML = tables.length
      ? LASE.t('点击查看：') : LASE.t('暂无分析表格');
    tables.forEach(name => {
      const b = LASE.el('button', { class: 'btn', text: name, style: 'margin:3px' });
      b.onclick = async () => {
        const d = await LASE.api('/api/archive/table/' + encodeURIComponent(name));
        this._renderTableView(d);
      };
      box.appendChild(b);
    });
  },

  _renderTableView(d) {
    const tbl = document.getElementById('arch-table-view');
    if (!d) { tbl.innerHTML = ''; return; }
    let html = '<tr>' + d.header.map(h => `<th>${h}</th>`).join('') + '</tr>';
    d.rows.forEach(r => { html += '<tr>' + r.map(v => `<td class="mono">${v}</td>`).join('') + '</tr>'; });
    tbl.innerHTML = html;
  },

  _renderFigures() {
    const box = document.getElementById('arch-figures');
    const figs = this._data.figures || [];
    if (!figs.length) { box.innerHTML = '<span class="muted">' + LASE.t('暂无图片') + '</span>'; return; }
    box.innerHTML = '';
    figs.forEach(name => {
      const wrap = LASE.el('div', { style: 'display:flex; flex-direction:column; align-items:center; gap:5px;' });
      const img = LASE.el('img', {
        src: '/api/figure/' + encodeURIComponent(name) + '?token=' + encodeURIComponent(LASE.token()),
        alt: name, style: 'width:150px; border:1px solid #e3e8ef; border-radius:4px; cursor:pointer',
        title: LASE.t('点击放大'),
      });
      img.onclick = () => window.open(img.src, '_blank');
      const b = LASE.el('button', { class: 'btn', text: LASE.t('保存图片'), style: 'font-size:11px; padding:3px 10px;' });
      b.onclick = () => this._saveFigure(name);
      wrap.appendChild(img);
      wrap.appendChild(b);
      box.appendChild(wrap);
    });
  },

  async _saveFigure(name) {
    try {
      const res = await fetch('/api/figure/' + encodeURIComponent(name) + '?token=' + encodeURIComponent(LASE.token()));
      if (!res.ok) { alert(LASE.t('图片获取失败')); return; }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const filename = name.toLowerCase().endsWith('.png') ? name : name + '.png';
      LASE.downloadDataUrl(url, filename);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { alert(LASE.t('保存失败：') + e); }
  },
});

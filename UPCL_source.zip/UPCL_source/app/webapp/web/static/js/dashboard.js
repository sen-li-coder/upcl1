/* 主界面（仪表盘）：项目概览 + 数据统计 + 快速入口 */
LASE.register('dashboard', {
  _data: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'dashboard' });
    page.innerHTML = `
      <div class="hero">
        <div class="hero-title">${LASE.t('进化算法机制研究平台')}</div>
        <div class="hero-sub">${LASE.t('统一实验运行、收敛曲线、机制剖析与适应度地形可视化的一体化工作台')}</div>
      </div>
      <div class="kpi-grid" id="dash-kpi"></div>
      <div class="grid-2">
        <div class="card">
          <div class="card-title">${LASE.t('数据完成度')}</div>
          <div id="dash-progress"></div>
        </div>
        <div class="card">
          <div class="card-title">${LASE.t('快速入口')}</div>
          <div class="quick-grid" id="dash-quick"></div>
        </div>
      </div>`;
    c.appendChild(page);
    this.page = page;
  },

  async show() {
    try { this._data = await LASE.api('/api/archive'); }
    catch (e) { this._data = null; }
    this._renderKpi();
    this._renderProgress();
    this._renderQuick();
  },

  _renderKpi() {
    const meta = LASE.meta;
    const a = this._data;
    let done = 0, total = 0;
    (a && a.summary || []).forEach(r => { done += r.done; total += r.total; });
    const pct = total ? (done / total * 100) : 0;
    const kpis = [
      { k: LASE.t('算法'), v: meta.hosts.length, ico: '🧬' },
      { k: LASE.t('测试集'), v: meta.suites.length, ico: '📊' },
      { k: LASE.t('结果文件'), v: a ? a.n_json : '-', ico: '📦' },
      { k: LASE.t('分析表格'), v: a ? a.tables.length : '-', ico: '📑' },
      { k: LASE.t('结果图片'), v: a ? a.figures.length : '-', ico: '🖼' },
      { k: LASE.t('总体完成度'), v: (a ? pct.toFixed(1) : '0.0') + '%', ico: '✅' },
    ];
    const box = document.getElementById('dash-kpi');
    if (!box) return;  // 页面已切走时容器可能已被移除
    box.innerHTML = kpis.map(k => `
      <div class="kpi">
        <div class="kpi-ico">${k.ico}</div>
        <div class="kpi-v">${k.v}</div>
        <div class="kpi-k">${k.k}</div>
      </div>`).join('');
  },

  _renderProgress() {
    const box = document.getElementById('dash-progress');
    if (!box) return;
    const s = this._data && this._data.summary || [];
    if (!s.length) { box.innerHTML = '<div class="muted">' + LASE.t('暂无数据') + '</div>'; return; }
    box.innerHTML = s.map(r => `
      <div class="prog-row">
        <div class="prog-label">${r.suite} · D${r.dim}</div>
        <div class="progress-bar" style="flex:1"><div style="width:${(r.pct * 100).toFixed(1)}%"></div></div>
        <div class="prog-num mono">${r.done}/${r.total}</div>
      </div>`).join('');
  },

  _renderQuick() {
    const box = document.getElementById('dash-quick');
    if (!box) return;
    const defs = [
      ['reference', '📚', LASE.t('算法与测试集'), LASE.t('算法出处与基准说明')],
      ['experiment', '▶', LASE.t('实验运行'), LASE.t('配置并启动 CEC 对比实验')],
      ['convergence', '📈', LASE.t('收敛曲线'), LASE.t('多算法误差收敛对比')],
      ['mechanism', '🧬', LASE.t('机制分析'), LASE.t('UPCL 干预机制剖析')],
      ['landscape', '🗺', LASE.t('地形图'), LASE.t('二维 / 三维适应度地形')],
      ['archive', '📦', LASE.t('数据存档'), LASE.t('完成度与结果浏览')],
      ['uav', '🛩', LASE.t('UAV 仿真'), LASE.t('无人机突防与拦截 / 集群突防对抗仿真')],
      ['wizard', '🧩', LASE.t('算法接入'), LASE.t('接入你的自定义算法')],
    ];
    box.innerHTML = defs.map(d => `
      <div class="quick" data-page="${d[0]}">
        <div class="quick-ico">${d[1]}</div>
        <div class="quick-t">${d[2]}</div>
        <div class="quick-d">${d[3]}</div>
      </div>`).join('');
    box.querySelectorAll('.quick').forEach(el => {
      el.onclick = () => LASE.navigate(el.dataset.page);
    });
  },
});

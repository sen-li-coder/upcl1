/* 实验运行页：配置 + 提交/暂停/续跑/强杀 + 进度 + 日志 + worker 状态 */
LASE.register('experiment', {
  _ws: null,
  _logLines: [],
  _selHosts: null,
  _meta: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'experiment' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('实验配置')}</div>
        <div class="row" id="exp-cfg"></div>
        <div style="margin-top:12px">
          <label class="muted" id="exp-host-label">${LASE.t('算法（{0} 个，将鼠标悬停在名称上查看机制与出处）', LASE.meta ? LASE.meta.hosts.length : 30)}</label>
          <div style="margin:6px 0" id="exp-host-btns"></div>
          <div id="exp-hosts"></div>
        </div>
        <div class="row" style="margin-top:14px">
          <button class="btn primary" id="exp-start">${LASE.t('开始实验')}</button>
          <button class="btn" id="exp-stop">${LASE.t('暂停')}</button>
          <button class="btn green" id="exp-resume">${LASE.t('续跑')}</button>
          <button class="btn danger" id="exp-kill">${LASE.t('强制终止')}</button>
          <span class="muted" id="exp-msg"></span>
        </div>
        <div style="margin-top:12px; max-width:720px">
          <div class="progress-bar"><div id="exp-bar"></div></div>
          <div class="progress-text" id="exp-progress">${LASE.t('空闲')}</div>
        </div>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-title">${LASE.t('实时日志')}</div>
          <div class="log-console" id="exp-log"></div>
        </div>
        <div class="card">
          <div class="card-title">${LASE.t('Worker 状态')}</div>
          <div style="overflow:auto; max-height:360px"><table class="tbl" id="exp-workers"></table></div>
        </div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._buildCfg();
    this._bind();
    this._connectWS();
    this._hostsKey = LASE.meta.hosts.join('\u0001');
  },

  show() {
    this._refreshStatus();
    // 客户通过「算法接入」向导新增插件后，这里动态刷新算法 chip（新算法默认选中）
    const key = LASE.meta.hosts.join('\u0001');
    if (this._hostsKey !== key) {
      this._hostsKey = key;
      LASE.meta.hosts.forEach(h => this._selHosts.add(h));
      this._renderHosts();
      const lbl = document.getElementById('exp-host-label');
      if (lbl) lbl.textContent = LASE.t('算法（{0} 个，将鼠标悬停在名称上查看机制与出处）', LASE.meta.hosts.length);
    }
  },

  _buildCfg() {
    const meta = LASE.meta;
    const cfg = document.getElementById('exp-cfg');
    cfg.innerHTML = '';
    this._selHosts = new Set(meta.hosts);

    const fillDims = (suite) => {
      this._dimSel.innerHTML = '';
      LASE.dimsOf(suite).forEach(d =>
        this._dimSel.appendChild(LASE.el('option', { value: 'D' + d, text: 'D' + d })));
      if (this._dimSel.options.length) this._dimSel.value = this._dimSel.options[0].value;
    };
    const suiteSel = LASE.select(cfg, LASE.t('测试集'), meta.suites, 'cec2022', (v) => {
      fillDims(v);
    }, () => {
      const si = LASE.suiteInfo[this._suiteSel.value];
      if (!si) return '';
      return '<p>' + LASE._esc(si.desc) + '</p>'
        + '<p class="muted">' + LASE._esc(si.name) + '</p>'
        + '<a href="' + si.url + '" target="_blank" rel="noopener">' + LASE.t('查看官方说明 ↗') + '</a>';
    });
    const dimSel = LASE.select(cfg, LASE.t('维度'), [], '');
    // 必须先给 this._dimSel / this._suiteSel 赋值，再调用 fillDims：
    // fillDims 内部要写 this._dimSel.innerHTML，顺序颠倒会抛
    // "Cannot set properties of undefined"，使本页初始化中断、按钮全部失效。
    this._dimSel = dimSel;
    this._suiteSel = suiteSel;
    fillDims('cec2022');

    this._runsInp = LASE.numInput(cfg, LASE.t('重复次数 runs'), 30, 1, 100, 1);
    this._workersInp = LASE.numInput(cfg, LASE.t('并行进程 workers'), 19, 1, 64, 1);
    this._evalsInp = LASE.numInput(cfg, LASE.t('评估预算 ×D'), 10000, 1000, 1000000, 1000);
    const f = LASE.el('div', { class: 'field' });
    const upclLab = LASE.el('label', { text: LASE.t('UPCL 对照') });
    f.appendChild(upclLab);
    LASE.info(upclLab, LASE.t('什么是 UPCL？'), '<p>' + LASE._esc(LASE.upclIntro) + '</p>');
    const upclSel = LASE.el('select');
    upclSel.appendChild(LASE.el('option', { value: '1', text: LASE.t('开启（纯算法 + UPCL 对照）') }));
    upclSel.appendChild(LASE.el('option', { value: '0', text: LASE.t('关闭（仅纯算法）') }));
    f.appendChild(upclSel);
    cfg.appendChild(f);
    this._upclSel = upclSel;

    // host 选择按钮
    const hb = document.getElementById('exp-host-btns');
    hb.innerHTML = '';
    LASE.btn(hb, LASE.t('全选'), '', () => { this._selHosts = new Set(meta.hosts); this._renderHosts(); });
    LASE.btn(hb, LASE.t('清空'), '', () => { this._selHosts = new Set(); this._renderHosts(); });
    this._renderHosts();
  },

  _renderHosts() {
    const wrap = document.getElementById('exp-hosts');
    LASE.chipGroup(wrap, LASE.meta.hosts, this._selHosts);
  },

  _bind() {
    document.getElementById('exp-start').onclick = () => this._start();
    document.getElementById('exp-stop').onclick = () => this._control('/api/experiment/stop');
    document.getElementById('exp-resume').onclick = () => this._control('/api/experiment/resume');
    document.getElementById('exp-kill').onclick = () => {
      if (confirm(LASE.t('确定强制终止整个实验进程树？'))) this._control('/api/experiment/kill');
    };
  },

  async _start() {
    const meta = LASE.meta;
    const suite = this._suiteSel.value;
    const dim = parseInt(this._dimSel.value.replace('D', ''));
    const hosts = meta.hosts.filter(h => this._selHosts.has(h));
    if (!hosts.length) { alert(LASE.t('请选择至少一个算法')); return; }
    const body = {
      suite, dim, hosts,
      runs: parseInt(this._runsInp.value),
      workers: parseInt(this._workersInp.value),
      evals_mult: parseFloat(this._evalsInp.value),
      upcl: this._upclSel.value === '1',
    };
    const r = await LASE.api('/api/experiment/start', { method: 'POST', body });
    document.getElementById('exp-msg').innerHTML = r.ok
      ? LASE.msg(LASE.t('已启动'), 'ok') : LASE.msg(r.msg, 'err');
    this._refreshStatus();
  },

  async _control(path) {
    const r = await LASE.api(path, { method: 'POST' });
    document.getElementById('exp-msg').innerHTML = r.ok
      ? LASE.msg(LASE.t('已执行'), 'ok') : LASE.msg(r.msg || LASE.t('失败'), 'err');
    this._refreshStatus();
  },

  async _refreshStatus() {
    try {
      const r = await LASE.api('/api/experiment/progress');
      this._applyStatus(r.status);
      this._applyWorkers(r.workers);
    } catch (e) { /* 忽略 */ }
  },

  _applyStatus(s) {
    if (!s) return;
    const bar = document.getElementById('exp-bar');
    const prog = document.getElementById('exp-progress');
    const p = s.progress || {};
    if (s.state === 'running' || s.state === 'stopping') {
      bar.style.width = (p.pct || 0) + '%';
      prog.textContent = LASE.t('运行中 {0}/{1} ({2}%)', p.finished || 0, p.total || '?', p.pct || 0) +
        ' · ' + LASE.t('已用 {0} min · 预计剩余 {1} min', p.elapsed_min || 0, p.eta_min || '?') +
        (s.state === 'stopping' ? ' · ' + LASE.t('正在暂停…') : '');
    } else if (s.state === 'done') {
      bar.style.width = '100%';
      prog.textContent = LASE.t('已完成');
    } else if (s.state === 'error') {
      prog.textContent = LASE.t('已结束（异常）');
    } else {
      bar.style.width = '0%';
      prog.textContent = LASE.t('空闲');
    }
  },

  _applyWorkers(w) {
    const tbl = document.getElementById('exp-workers');
    if (!w) return;
    const ws = w.workers || [];
    if (!ws.length) {
      tbl.innerHTML = '<tr><td class="muted">' + LASE.t('暂无 worker 状态') + '</td></tr>';
      return;
    }
    const keys = [];
    const seen = new Set();
    ws.forEach(x => Object.keys(x).forEach(k => {
      if (!seen.has(k) && keys.length < 10) { seen.add(k); keys.push(k); }
    }));
    let html = '<tr>' + keys.map(k => `<th>${k}</th>`).join('') + '</tr>';
    ws.forEach(x => {
      html += '<tr>' + keys.map(k => {
        let v = x[k];
        if (v === undefined || v === null) v = '';
        else if (typeof v === 'number') v = (Math.round(v * 100) / 100);
        else if (typeof v !== 'string') v = JSON.stringify(v);
        return `<td class="mono">${String(v).slice(0, 40)}</td>`;
      }).join('') + '</tr>';
    });
    tbl.innerHTML = html;
  },

  _connectWS() {
    if (!LASE.user) return;   // 未登录不连接 WebSocket
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const t = LASE.token();
    const ws = new WebSocket(
      `${proto}://${location.host}/ws/experiment?token=${encodeURIComponent(t)}`);
    this._ws = ws;
    ws.onopen = () => { /* 连接成功 */ };
    ws.onmessage = (ev) => {
      let m;
      try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (m.type === 'log') this._appendLog(m.line);
      else if (m.type === 'status') this._applyStatus(m.status);
      else if (m.type === 'workers') this._applyWorkers(m.workers);
    };
    ws.onclose = () => { setTimeout(() => this._connectWS(), 2000); };
    ws.onerror = () => { try { ws.close(); } catch (e) {} };
  },

  _appendLog(line) {
    this._logLines.push(line);
    if (this._logLines.length > 2000) this._logLines.shift();
    const el = document.getElementById('exp-log');
    el.textContent = this._logLines.join('\n');
    el.scrollTop = el.scrollHeight;
  },
});

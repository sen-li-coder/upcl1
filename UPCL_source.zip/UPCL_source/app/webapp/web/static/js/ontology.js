/* 本体与知识图谱页。
 *
 * 三块内容都由后端（web/ontology_api.py）从 src/uav_red.py 的注册表现场生成：
 *   - 本体（类别层）：根问题 → 课题 → 决策变量 → 单元 → 约束 → 目标项 / 对手 / 指标；
 *   - 知识图谱（实例层）：场景 → 想定 U1/U3/U4 → 课题 → 变量 / 单元编成 → 生效约束 → 指标；
 *   - 约束 × 课题矩阵（表格）：行 C1–C6、列 F1–F4、格 = 生效 / 豁免 + 检查单元。
 * 因此图上内容与仿真实现同源，不存在「界面一套、代码一套」。
 *
 * 视图口径三维：**场景**（intercept / swarm，全局）× 想定（U*）× 课题（F1–F4）。
 * 未登记红方模型的场景（swarm）由后端返回缺口视图（supported=false）：不列课题、不套用
 * intercept 数值，页面显式提示。
 *
 * 节点信息分两段：**文字描述**（desc，这个实体在战场上是什么、意味着什么，直接可读）
 * 在前；**技术参数**（params，决策维度 / 取值域 / 罚分项 / 结果表列名）在后、小字灰显。
 * 描述里不出现代码标识（后端 _prose 已把常量名换成中文说法），代码口径只出现在参数段。
 *
 * 两张图各有一个「绘图形式」下拉：网络图（拓扑与豁免）/ 分层树图（层级归属）/
 * 旭日图（层与节点的占比）/ 明细表（文字描述与关系整列直接可读，无需悬停）。
 * 另有「节点上显示描述」开关，把 desc 直接写到节点标签的第二行。形式只改画法，
 * 数据始终是同一份（后端下发的 nodes / edges）。
 * 导出 JSON-LD / CSV 三元组，可直接喂 GraphRAG / Neo4j。
 */
LASE.register('ontology', {
  _g: { ontology: null, kg: null },
  _matrix: null,
  _charts: {},
  // 渲染上下文按图分开存（本体 / 知识图谱各一份），避免互相覆盖
  _ctx: { ontology: null, kg: null },
  // 上次布局用的画布宽度：窗口变化后据此判断要不要按新宽度重画
  _lastW: { ontology: 0, kg: 0 },
  // 绘图形式（本体 / 知识图谱各自记忆）：graph 网络图 | tree 分层树图 |
  // sunburst 旭日图 | table 明细表
  _form: { ontology: 'graph', kg: 'graph' },
  // 是否把文字描述直接画在节点标签的第二行（图形态专用；明细表形式恒为整列显示）
  _showDesc: true,
  _showMetric: true,
  // 视图口径：scenario = 全局场景（同时作用于本体 / 知识图谱 / 矩阵）；
  // mode / fid 为 'all' 时该维度不筛
  // 默认视图：知识图谱 = 首个想定 + 首个课题（单个任务），本体 = 全量总览
  _sel: { scenario: 'intercept', ontology: { mode: 'all' }, kg: { fid: 'all', mode: 'all' } },
  _filters: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'ontology' });
    page.innerHTML = this._html();
    c.appendChild(page);
    this.page = page;
    this._bind();
    // 网络图的节点坐标是按画布宽度算出来的**像素**坐标：画布宽度一变就必须重算，
    // 否则 ECharts 会把整套坐标等比压缩，而字号是固定的 —— 结果就是字压字、层名跑出画布。
    // 树图的高度也按画布宽度重算，所以窗口变化统一走「按宽度重画」（200ms 防抖）。
    let resizeTimer = null;
    window.addEventListener('resize', () => {
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => this._relayout(), 200);
    });
  },

  // 本页是否可见：隐藏时画布宽度是 0，按 0 布局会把图画坏（切回本页时再画，见 show）
  _visible() {
    return !!(this.page && this.page.offsetParent !== null);
  },

  // 画布宽度变了才需要重画（明细表形式没有画布）
  _widthChanged(kind) {
    const el = this.page.querySelector(kind === 'kg' ? '#ontk-chart' : '#ont-chart');
    if (!el || this._form[kind] === 'table') return false;
    return (el.clientWidth || 0) !== (this._lastW[kind] || 0);
  },

  _relayout() {
    if (!this._visible()) return;
    ['ontology', 'kg'].forEach(k => {
      if (!this._g[k] || !this._widthChanged(k)) return;
      try { this._render(k); } catch (e) { /* 忽略 */ }
    });
  },

  // 切回本页：页面隐藏期间窗口尺寸可能变过，此时按当前宽度重画一次
  show() {
    this._relayout();
  },

  _html() {
    return `
      <div class="card">
        <div class="card-title">${LASE.t('数据来源（单一事实来源）')}</div>
        <div class="row">
          <label class="hint" style="display:flex; align-items:center; gap:6px">
            ${LASE.t('场景筛选')}<select id="ont-scenario"></select></label>
          <button class="btn" id="ont-reset">${LASE.t('刷新筛选候选项')}</button>
        </div>
        <div class="hint">${LASE.t('两张图都由 src/uav_red.py 与 uav_api.py 的注册表现场生成，不读任何外部本体文件，因此图上内容与仿真实现永远一致；每次生成都是重新读取代码。')}</div>
        <div class="hint">${LASE.t('视图口径三维：场景（全局）× 想定 × 课题。想定与课题都选定 = 该任务这一张图（决策维度、部署区域、单元编成、生效与豁免约束都按该口径重算）；被豁免的约束画成灰虚线并标注「豁免」，不再靠「缺边」暗示。')}</div>
        <div class="hint">${LASE.t('节点信息分两段：文字描述 = 这个实体在战场上是什么、意味着什么（直接可读，不含代码标识）；技术参数 = 决策维度 / 取值域 / 罚分项 / 结果表列名等代码口径，只在后面以小字灰显，不充当描述。切到未登记红方模型的场景会看到缺口视图，不会套用已登记场景的数值。')}</div>
        <div class="hint">${LASE.t('两张图都可切换绘图形式（只改画法，不改数据）：网络图看拓扑与豁免；分层树图看层级归属；旭日图看各层与各节点的占比；明细表把文字描述与关系整列摊开、直接可读。另有「节点上显示描述」开关，可把描述直接写到节点标签的第二行。')}</div>
        <div class="hint mono" id="ont-src" style="margin-top:6px"></div>
        <div class="hint" id="ont-note" style="margin-top:6px"></div>
        <div class="hint" id="ont-warn" style="color:#c0392b; margin-top:6px"></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('优化模型本体（类别层）')}</div>
        <div class="row">
          <label class="hint" style="display:flex; align-items:center; gap:6px">
            ${LASE.t('课题筛选')}<select id="ont-mode"></select></label>
          <label class="hint" style="display:flex; align-items:center; gap:6px">
            ${LASE.t('绘图形式')}<select id="ont-form">${this._formOptions('graph')}</select></label>
          <label class="hint" style="display:flex; align-items:center; gap:6px; cursor:pointer">
            <input type="checkbox" id="ont-desc" checked>${LASE.t('节点上显示描述')}
          </label>
          <button class="btn primary" id="ont-gen">${LASE.t('生成本体图')}</button>
          <button class="btn" id="ont-img">${LASE.t('下载图片')}</button>
          <button class="btn" id="ont-jsonld">${LASE.t('导出 JSON-LD')}</button>
          <button class="btn" id="ont-csv">${LASE.t('导出 CSV 三元组')}</button>
        </div>
        <div class="hint" id="ont-stat" style="margin-top:8px">${LASE.t('尚未生成')}</div>
        <div class="hint" id="ont-gap" style="display:none; color:#b9770e; margin-top:6px"></div>
        <div id="ont-chart" style="width:100%; height:660px"></div>
        <div id="ont-table" style="display:none; overflow-x:auto"></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('知识图谱（实例层）')}</div>
        <div class="row">
          <label class="hint" style="display:flex; align-items:center; gap:6px">
            ${LASE.t('想定筛选')}<select id="ontk-fid"></select></label>
          <label class="hint" style="display:flex; align-items:center; gap:6px">
            ${LASE.t('课题筛选')}<select id="ontk-mode"></select></label>
          <label class="hint" style="display:flex; align-items:center; gap:6px">
            ${LASE.t('绘图形式')}<select id="ontk-form">${this._formOptions('graph')}</select></label>
          <label class="hint" style="display:flex; align-items:center; gap:6px; cursor:pointer">
            <input type="checkbox" id="ontk-desc" checked>${LASE.t('节点上显示描述')}
          </label>
          <button class="btn primary" id="ontk-gen">${LASE.t('生成知识图谱')}</button>
          <button class="btn" id="ontk-img">${LASE.t('下载图片')}</button>
          <button class="btn" id="ontk-jsonld">${LASE.t('导出 JSON-LD')}</button>
          <button class="btn" id="ontk-csv">${LASE.t('导出 CSV 三元组')}</button>
          <label class="hint" style="display:flex; align-items:center; gap:6px; cursor:pointer">
            <input type="checkbox" id="ontk-metric" checked>${LASE.t('显示指标')}
          </label>
        </div>
        <div class="hint" id="ontk-stat" style="margin-top:8px">${LASE.t('尚未生成')}</div>
        <div class="hint" id="ontk-gap" style="display:none; color:#b9770e; margin-top:6px"></div>
        <div id="ontk-chart" style="width:100%; height:660px"></div>
        <div id="ontk-table" style="display:none; overflow-x:auto"></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('约束 × 课题矩阵（豁免关系一次看全）')}</div>
        <div class="hint">${LASE.t('行 = 约束 C1–C6，列 = 课题 F1–F4，格 = 该约束在该课题下「生效」还是「豁免」；表头给出各想定的决策维度，格内标注真正被检查的单元。表格比网络图更适合回答「哪条约束管哪个课题、哪条被豁免」。')}</div>
        <div class="hint" id="ont-matrix-stat" style="margin-top:8px">${LASE.t('尚未生成')}</div>
        <div id="ont-matrix" style="margin-top:8px; overflow-x:auto"></div>
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="card-title">${LASE.t('图例（节点类型）')}</div>
          <div id="ont-legend" class="hint"></div>
        </div>
        <div class="card">
          <div class="card-title">${LASE.t('关系（谓词）')}</div>
          <div id="ont-rel" class="hint"></div>
          <div class="hint" id="ont-exempt-note" style="margin-top:8px; color:#c0392b"></div>
          <div class="hint" id="ont-export-note" style="margin-top:8px"></div>
        </div>
      </div>`;
  },

  // 绘图形式下拉的候选（本体 / 知识图谱共用一套画法）
  _formOptions(cur) {
    return [['graph', '网络图'], ['tree', '分层树图'], ['sunburst', '旭日图'],
      ['table', '明细表（描述整列可读）']]
      .map(o => `<option value="${o[0]}"${o[0] === cur ? ' selected' : ''}>`
        + `${LASE.t(o[1])}</option>`).join('');
  },

  _bind() {
    const q = id => this.page.querySelector('#' + id);
    // 绘图形式：只重画，不重取（数据没变）
    q('ont-form').onchange = (e) => {
      this._form.ontology = e.target.value;
      if (this._g.ontology) this._render('ontology');
    };
    q('ontk-form').onchange = (e) => {
      this._form.kg = e.target.value;
      if (this._g.kg) this._render('kg');
    };
    // 「节点上显示描述」是全局开关：两个勾选框同步，两张图一起重画
    const setDesc = (v) => {
      this._showDesc = !!v;
      ['ont-desc', 'ontk-desc'].forEach(id => {
        const el = q(id);
        if (el) el.checked = this._showDesc;
      });
      if (this._g.ontology) this._render('ontology');
      if (this._g.kg) this._render('kg');
    };
    q('ont-desc').onchange = (e) => setDesc(e.target.checked);
    q('ontk-desc').onchange = (e) => setDesc(e.target.checked);
    q('ont-gen').onclick = () => this._load('ontology');
    q('ont-img').onclick = () => this._saveImg('ontology');
    q('ont-jsonld').onclick = () => this._export('ontology', 'jsonld');
    q('ont-csv').onclick = () => this._export('ontology', 'csv');
    q('ontk-gen').onclick = () => this._load('kg');
    q('ontk-img').onclick = () => this._saveImg('kg');
    q('ontk-jsonld').onclick = () => this._export('kg', 'jsonld');
    q('ontk-csv').onclick = () => this._export('kg', 'csv');
    q('ontk-metric').onchange = (e) => {
      this._showMetric = !!e.target.checked;
      if (this._g.kg) this._render('kg');
    };
    // 场景是全局口径：切换后本体 / 知识图谱 / 矩阵一起重取（想定与课题候选项也跟着场景走）
    q('ont-scenario').onchange = (e) => this._onScenario(e.target.value);
    q('ont-reset').onclick = () => this._onScenario(this._sel.scenario);
    // 切换想定 / 课题 → 按该任务的实际口径重新生成（维度、ROI、生效与豁免约束、
    // 单元编成都由后端重算，不在前端做近似过滤）
    q('ont-mode').onchange = (e) => { this._sel.ontology.mode = e.target.value; this._load('ontology'); };
    q('ontk-mode').onchange = (e) => { this._sel.kg.mode = e.target.value; this._load('kg'); };
    q('ontk-fid').onchange = (e) => { this._sel.kg.fid = e.target.value; this._load('kg'); };
  },

  async show() {
    if (!this._filters) await this._loadFilters();
    if (!this._g.ontology) await this._load('ontology');
    if (!this._g.kg) await this._load('kg');
    if (!this._matrix) await this._loadMatrix();
  },

  async _onScenario(sc) {
    if (!sc) return;
    this._sel.scenario = String(sc);
    this._filters = null;               // 想定 / 课题候选项跟随场景重取
    await this._loadFilters();
    await this._load('ontology');
    await this._load('kg');
    await this._loadMatrix();
  },

  // 筛选候选项与默认视图都取自后端（同源：RED_SCENARIOS + RED_FIDS + MODE_SLOTS）
  async _loadFilters() {
    try {
      const f = await LASE.api('/api/ontology/uav/filters' + this._scenarioQuery());
      if (!f || f._unauthorized) return;
      this._filters = f;
      if (f.scenario) this._sel.scenario = String(f.scenario);
      // 默认视图：知识图谱 = 首个想定 + 首个课题；本体 = 全量总览
      this._sel.kg.fid = (f.default_fid === null || f.default_fid === undefined)
        ? 'all' : String(f.default_fid);
      this._sel.kg.mode = f.default_topic || 'all';
      this._sel.ontology.mode = 'all';
      this._fillSelects();
    } catch (e) { this._filters = null; }
  },

  _fillSelects() {
    const f = this._filters;
    if (!f) return;
    const q = id => this.page.querySelector('#' + id);
    const fill = (sel, opts, cur, allLabel) => {
      if (!sel) return;
      const list = opts || [];
      // 未登记场景下课题候选项为空：下拉置空并禁用，避免看起来「这个场景也有 F1–F4」
      sel.innerHTML = (list.length ? [`<option value="all">${LASE.t(allLabel)}</option>`] : [])
        .concat(list.map(o => `<option value="${o.value}">${o.label}</option>`)).join('');
      sel.disabled = !list.length;
      sel.value = (!list.length || cur === null || cur === undefined || cur === 'all')
        ? 'all' : String(cur);
    };
    const ssel = q('ont-scenario');
    if (ssel) {
      ssel.innerHTML = (f.scenarios || []).map(o => `<option value="${o.value}">${o.label}`
        + `${o.registered ? '' : LASE.t('（未登记红方模型）')}</option>`).join('');
      ssel.value = this._sel.scenario;
    }
    fill(q('ontk-fid'), f.fids, this._sel.kg.fid, '全部想定');
    fill(q('ontk-mode'), f.topics, this._sel.kg.mode, '全部课题');
    fill(q('ont-mode'), f.topics, this._sel.ontology.mode, '全部课题');
  },

  _scenarioQuery() {
    return this._sel.scenario ? '?scenario=' + encodeURIComponent(this._sel.scenario) : '';
  },

  _url(kind) {
    const p = [];
    if (this._sel.scenario) p.push('scenario=' + encodeURIComponent(this._sel.scenario));
    if (kind === 'kg') {
      if (this._sel.kg.fid !== 'all') p.push('fid=' + encodeURIComponent(this._sel.kg.fid));
      if (this._sel.kg.mode !== 'all') p.push('mode=' + encodeURIComponent(this._sel.kg.mode));
      return '/api/ontology/uav/kg' + (p.length ? '?' + p.join('&') : '');
    }
    if (this._sel.ontology.mode !== 'all') {
      p.push('mode=' + encodeURIComponent(this._sel.ontology.mode));
    }
    return '/api/ontology/uav' + (p.length ? '?' + p.join('&') : '');
  },

  async _load(kind) {
    const stat = this.page.querySelector(kind === 'kg' ? '#ontk-stat' : '#ont-stat');
    if (!this._filters) await this._loadFilters();
    stat.textContent = LASE.t('生成中…');
    try {
      const g = await LASE.api(this._url(kind));
      if (!g || g._unauthorized) return;
      this._g[kind] = g;
      // 以后端回传的口径为准（唯一事实来源），并回填下拉
      if (g.selection) {
        if (g.selection.scenario) this._sel.scenario = String(g.selection.scenario);
        if (kind === 'kg') {
          this._sel.kg.fid = g.selection.fid === null ? 'all' : String(g.selection.fid);
          this._sel.kg.mode = g.selection.mode === null ? 'all' : String(g.selection.mode);
        } else {
          this._sel.ontology.mode = g.selection.mode === null ? 'all' : String(g.selection.mode);
        }
      }
      this._fillSelects();
      this._render(kind);
    } catch (e) {
      stat.textContent = LASE.t('生成失败：') + e;
    }
  },

  // 未登记红方模型的场景：显式提示缺口，绝不静默套用已登记场景的口径
  _renderGap(kind, g) {
    const box = this.page.querySelector(kind === 'kg' ? '#ontk-gap' : '#ont-gap');
    if (!box) return;
    if (g && g.supported === false) {
      box.style.display = 'block';
      box.innerHTML = `<b>${LASE.t('缺口视图：该场景尚未登记红方模型')}</b>`
        + (g.note ? `<div style="margin-top:4px">${g.note}</div>` : '')
        + (g.warnings || []).map(w => `<div style="margin-top:4px">• ${w}</div>`).join('');
    } else {
      box.style.display = 'none';
      box.innerHTML = '';
    }
  },

  // ---- 分层布局：x 由 layer 决定，y 在层内均匀铺开，避免力导向的随机性 ----
  _layout(ctx) {
    const g = ctx.g;
    const el = this.page.querySelector(ctx.kind === 'kg' ? '#ontk-chart' : '#ont-chart');
    // 必须用画布的真实宽度：ECharts 会把节点坐标等比映射到画布框里，只有「布局宽度 =
    // 画布宽度」时缩放才是 1，节点标签才和顶部的层名对齐（宽度取 0 是页面隐藏，不在此列）。
    const W = Math.max(360, el.clientWidth || 900);
    const H = 660;
    const maxLayer = g.layers.length ? g.layers[g.layers.length - 1].index : 0;
    // 最后一层的标签画在节点左侧（见 _graphOption 的 label.position），右侧不需要 320px
    // 留白；把这部分宽度让给层间距 dx，右侧标签才不会撞到下一层的节点。
    // 左右留白随画布宽度收放：窄画布上把省下来的宽度也让给 dx。
    const padL = Math.round(Math.min(90, Math.max(48, W * 0.075)));
    const padR = Math.round(Math.min(60, Math.max(28, W * 0.05)));
    const dx = (W - padL - padR) / Math.max(1, maxLayer);
    const groups = {};
    ctx.nodes.forEach(n => { (groups[n.layer] = groups[n.layer] || []).push(n); });
    const pos = {};
    Object.keys(groups).forEach(k => {
      const list = groups[k].slice().sort((a, b) => (a.type < b.type ? -1 : a.type > b.type ? 1
        : a.label.localeCompare(b.label, 'zh')));
      const n = list.length;
      const dy = Math.min(74, (H - 120) / Math.max(1, n - 1 || 1));
      const y0 = H / 2 - dy * (n - 1) / 2;
      list.forEach((node, i) => { pos[node.id] = [padL + node.layer * dx, n === 1 ? H / 2 : y0 + i * dy]; });
    });
    return { W, H, pos, maxLayer, dx };
  },

  // 画布高度：树图节点多，固定 660px 会把标签压在一起；按叶子数抬高（有上限）
  _treeHeight(ctx, nodes) {
    const layerCount = (ctx.g.layers || [])
      .filter(L => nodes.some(n => n.layer === L.index)).length;
    const leaves = nodes.length + layerCount + 1;
    const per = this._showDesc ? 30 : 20;
    return Math.max(660, Math.min(1900, leaves * per));
  },

  // HTML 转义（描述与参数里的文字原样显示，不让 <> 破坏结构）
  _esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  },

  // 画在节点上的短描述（去掉会破坏 rich 语法的字符）
  _shortDesc(s, n) {
    const t = String(s || '').replace(/\s+/g, ' ').replace(/[{}|]/g, ' ');
    return t.length > n ? t.slice(0, n) + '…' : t;
  },

  // 节点信息：**文字描述**在前（使用者直接读），**技术参数**小字在后（代码口径）
  _tipHtml(n, ctx) {
    ctx = ctx || {};
    if (!n) return '';
    const rels = (ctx.outRel || {})[n.id] || [];
    const relTxt = rels.length
      ? `<div style="margin-top:8px">${rels.map(r => (r.exempt
        ? `<span style="color:#98a6b5">${this._esc(r.text)}（${LASE.t('豁免')}）</span>`
        : this._esc(r.text))).join('<br>')}</div>`
      : '';
    const desc = this._esc(n.desc || '');
    const params = this._esc(n.params || '');
    const body = (desc ? `<div style="max-width:440px; white-space:normal; margin-top:6px; `
      + `line-height:1.5">${desc}</div>` : '')
      + (params ? `<div style="max-width:440px; white-space:normal; margin-top:6px; `
        + `font-size:11.5px; color:#98a6b5"><span style="color:#aab5c0">`
        + `${LASE.t('技术参数')}：</span>${params}</div>` : '');
    return `<div style="max-width:460px"><b>${this._esc(n.label || '')}</b>`
      + `<span class="muted" style="margin-left:6px">`
      + `${this._esc((ctx.typeLabel || {})[n.type] || n.type || '')}</span>`
      + body + relTxt + '</div>';
  },

  _render(kind) {
    const g = this._g[kind];
    if (!g) return;
    this._renderGap(kind, g);

    const chartEl = this.page.querySelector(kind === 'kg' ? '#ontk-chart' : '#ont-chart');
    const tableEl = this.page.querySelector(kind === 'kg' ? '#ontk-table' : '#ont-table');
    const form = this._form[kind] || 'graph';

    const drop = (kind === 'kg' && !this._showMetric);
    const nodes = g.nodes.filter(n => !(drop && n.type === 'Metric'));
    const ids = new Set(nodes.map(n => n.id));
    const edges = g.edges.filter(e => ids.has(e.source) && ids.has(e.target));

    const types = g.types.filter(t => nodes.some(n => n.type === t.name));
    const typeLabel = {};
    g.types.forEach(t => { typeLabel[t.name] = LASE.t(t.label); });
    const labelOf = {};
    nodes.forEach(n => { labelOf[n.id] = n.label; });
    const nodeIndex = {};
    nodes.forEach(n => { nodeIndex[n.id] = n; });
    const outRel = {};
    edges.forEach(e => {
      (outRel[e.source] = outRel[e.source] || []).push({
        text: LASE.t(e.label) + ' → ' + (labelOf[e.target] || e.target),
        exempt: !!e.exempt,
      });
    });
    // 本次渲染的上下文：各画法共用（换画法不换数据）；按图分开存，两张图不会互相覆盖
    const ctx = { kind, g, nodes, edges, types, typeLabel, labelOf, nodeIndex, outRel };
    this._ctx[kind] = ctx;

    if (form === 'table') {
      // 明细表：文字描述整列摊开、直接可读，不依赖悬停
      if (chartEl) chartEl.style.display = 'none';
      if (tableEl) { tableEl.style.display = 'block'; tableEl.innerHTML = this._tableHtml(ctx); }
    } else {
      if (tableEl) { tableEl.style.display = 'none'; tableEl.innerHTML = ''; }
      if (chartEl) {
        chartEl.style.display = 'block';
        // 树图按叶子数抬高画布，否则标签会挤成一团（其余画法固定 660px）
        chartEl.style.height = (form === 'tree' ? this._treeHeight(ctx, nodes) : 660) + 'px';
      }
      if (!this._charts[kind]) this._charts[kind] = echarts.init(chartEl);
      // 记下这次布局用的画布宽度：宽度没变就不用重画（见 _widthChanged）
      this._lastW[kind] = (chartEl && chartEl.clientWidth) || 0;
      const opt = form === 'tree' ? this._treeOption(ctx)
        : form === 'sunburst' ? this._sunburstOption(ctx) : this._graphOption(ctx);
      this._charts[kind].setOption(opt, true);
      this._charts[kind].resize();
    }

    const st = g.stats;
    const formName = { graph: '网络图', tree: '分层树图', sunburst: '旭日图', table: '明细表' };
    this.page.querySelector(kind === 'kg' ? '#ontk-stat' : '#ont-stat').textContent =
      LASE.t('当前视图：{0} · ', g.scope || '') +
      LASE.t('节点 {0} · 关系 {1} · 三元组 {2} · 生成于 {3}',
        st.n_nodes, st.n_edges, st.n_triples, g.generated_at) +
      LASE.t(' · 绘图形式：{0}', LASE.t(formName[form] || form)) +
      (form === 'table' ? LASE.t('（文字描述整列可读）') : '') +
      (drop ? LASE.t('（已隐藏指标层）') : '');
    this.page.querySelector('#ont-src').textContent = g.sources.join('  |  ');
    const note = this.page.querySelector('#ont-note');
    if (note) note.textContent = (g.supported === false) ? '' : (g.note || '');
    const warns = Object.keys(this._g)
      .map(k => (this._g[k] && this._g[k].warnings) || []).reduce((a, b) => a.concat(b), []);
    this.page.querySelector('#ont-warn').textContent =
      warns.length ? LASE.t('生成告警：') + warns.join('；') : '';
    this._renderLegend(types, edges);
    const nExc = edges.filter(e => e.exempt).length;
    this.page.querySelector('#ont-exempt-note').textContent = nExc
      ? LASE.t('灰色虚线 = 该课题豁免此约束（不判罚），本视图共 {0} 条。', nExc) : '';
    this.page.querySelector('#ont-export-note').textContent =
      LASE.t('JSON-LD 前缀 uo = {0}，可直接导入 GraphRAG / 图数据库；CSV 为 (subject, predicate, object) 三元组，可用 Neo4j LOAD CSV 载入。',
        g.namespace);
  },

  // 出度（用于树图 / 旭日图的扇区大小与占比）
  _deg(ctx) {
    const d = {};
    (ctx.edges || []).forEach(e => { d[e.source] = (d[e.source] || 0) + 1; });
    return d;
  },

  _colorOf(ctx, type) {
    return ((ctx.types || []).find(t => t.name === type) || {}).color;
  },

  // ---- 画法 1：网络图（分层布局 + 豁免灰虚线 + 描述直接写在节点上）----
  _graphOption(ctx) {
    const g = ctx.g;
    const nodes = ctx.nodes;
    const edges = ctx.edges;
    const showDesc = this._showDesc;

    const catIndex = {};
    const categories = ctx.types.map((t, i) => {
      catIndex[t.name] = i;
      return { name: LASE.t(t.label), itemStyle: { color: t.color } };
    });

    const { pos, maxLayer, dx } = this._layout(ctx);
    // 字号与「节点上的描述」长度都跟着层间距 dx 走：画布变窄时逐档压缩，
    // 宁可只留名称，也不让固定字号的文字互相压在一起（完整描述仍在悬停与明细表里）。
    const labelFs = dx >= 152 ? 12 : 11;
    const descN = dx >= 165 ? 12 : (dx >= 136 ? 8 : 0);
    const data = nodes.map(n => {
      // 描述直接写在节点标签的第二行：只给较大的节点（根 / 课题 / 单元 / 约束），
      // 小节点（变量 / 指标）留给悬停。
      const d = (showDesc && descN && n.size >= 34 && n.desc)
        ? this._shortDesc(n.desc, descN) : '';
      return {
        name: n.id, x: pos[n.id][0], y: pos[n.id][1],
        symbolSize: n.size, category: catIndex[n.type],
        itemStyle: { color: this._colorOf(ctx, n.type) },
        label: {
          show: true, fontSize: n.size >= 40 ? labelFs : labelFs - 1.5, color: '#1c3656',
          // 最后一层的标签画在节点左侧，避免贴到画布右边缘被裁掉
          position: n.layer >= maxLayer ? 'left' : 'right',
          formatter: d ? `${n.label}\n{desc|${d}}` : n.label,
          rich: { desc: { fontSize: labelFs - 2, color: '#77869a', lineHeight: labelFs + 2 } },
        },
      };
    });
    // 豁免边：灰虚线 + 边上直接写「豁免」，避免只靠「缺边」暗示
    const links = edges.map(e => {
      const link = {
        source: e.source, target: e.target, value: LASE.t(e.label), rel: e.rel,
        lineStyle: e.exempt
          ? { width: 1.4, type: 'dashed', color: '#98a6b5', opacity: 0.9, curveness: 0.16 }
          : { width: 1, opacity: 0.45, curveness: 0.08 },
      };
      if (e.exempt) {
        // ECharts graph 的边标签是 links[].label（edgeLabel 只作用于 series 级）
        link.label = {
          show: true, formatter: LASE.t('豁免'), fontSize: 10, color: '#7a8a99',
          backgroundColor: 'rgba(255,255,255,0.85)', padding: [1, 3], borderRadius: 3,
        };
      }
      return link;
    });

    const graphic = g.layers.map(L => {
      const layerNodes = nodes.filter(n => n.layer === L.index);
      if (!layerNodes.length) return null;
      return {
        type: 'text', left: pos[layerNodes[0].id][0] - 34, top: 4,
        style: { text: LASE.t(L.name), fill: '#7a8a99', fontSize: 11, fontWeight: 600 },
      };
    }).filter(Boolean);

    return {
      animation: false,
      tooltip: {
        confine: true,
        formatter: (p) => (p.dataType === 'edge'
          ? p.data.value : this._tipHtml(ctx.nodeIndex[p.name], ctx)),
      },
      graphic,
      series: [{
        type: 'graph', layout: 'none', roam: true, draggable: true,
        left: 0, right: 0, top: 30, bottom: 0,
        categories,
        data, links,
        labelLayout: { hideOverlap: true },
        edgeSymbol: ['none', 'arrow'], edgeSymbolSize: 5,
        lineStyle: { color: '#9fb0c4' },
        emphasis: { focus: 'adjacency', label: { fontWeight: 'bold' } },
      }],
    };
  },

  // ---- 画法 2：分层树图（层 → 节点，可折叠；节点可带一行描述）----
  _treeOption(ctx) {
    const g = ctx.g;
    const deg = this._deg(ctx);
    const showDesc = this._showDesc;
    const layers = [];
    (g.layers || []).forEach(L => {
      const list = ctx.nodes.filter(n => n.layer === L.index);
      if (!list.length) return;
      layers.push({
        name: LASE.t(L.name),
        itemStyle: { color: '#dbe4ee' },
        children: list.map(n => ({
          name: n.label + (showDesc && n.desc ? '\n' + this._shortDesc(n.desc, 26) : ''),
          raw: n,
          value: Math.max(1, deg[n.id] || 0),
          itemStyle: { color: this._colorOf(ctx, n.type) },
        })),
      });
    });
    return {
      animation: false,
      tooltip: {
        confine: true,
        formatter: (p) => (p.data && p.data.raw
          ? this._tipHtml(p.data.raw, ctx)
          : `<b>${this._esc(p.name)}</b><div class="muted">`
            + LASE.t('该层的节点分组') + '</div>'),
      },
      series: [{
        type: 'tree', orient: 'LR', roam: true,
        data: [{ name: LASE.t(g.title || '红方优化模型'), children: layers }],
        initialTreeDepth: 4, symbolSize: 8, expandAndCollapse: true,
        top: '1%', bottom: '1%', left: '5%', right: '22%',
        label: {
          position: 'left', verticalAlign: 'middle', align: 'right',
          fontSize: 11.5, color: '#1c3656', lineHeight: 14,
        },
        leaves: { label: { position: 'right', verticalAlign: 'middle', align: 'left' } },
        lineStyle: { color: '#c3cfdd', width: 1, curveness: 0.4 },
        emphasis: { focus: 'descendant' },
      }],
    };
  },

  // ---- 画法 3：旭日图（内环层、外环节点；扇区大小 ∝ 该节点的关系数）----
  _sunburstOption(ctx) {
    const g = ctx.g;
    const deg = this._deg(ctx);
    const children = [];
    (g.layers || []).forEach(L => {
      const list = ctx.nodes.filter(n => n.layer === L.index);
      if (!list.length) return;
      children.push({
        name: LASE.t(L.name),
        itemStyle: { color: '#eef3f9' },
        children: list.map(n => ({
          name: n.label, raw: n,
          value: Math.max(1, deg[n.id] || 0),
          itemStyle: { color: this._colorOf(ctx, n.type) },
        })),
      });
    });
    return {
      animation: false,
      tooltip: {
        confine: true,
        formatter: (p) => (p.data && p.data.raw
          ? this._tipHtml(p.data.raw, ctx)
          : `<b>${this._esc(p.name)}</b><div class="muted">`
            + LASE.t('该层的节点分组') + '</div>'),
      },
      series: [{
        type: 'sunburst', radius: [0, '96%'], center: ['50%', '50%'],
        data: children, sort: null, nodeClick: false, roam: true,
        label: { rotate: 'radial', minAngle: 8, fontSize: 11, color: '#1c3656' },
        levels: [{}, { r0: '16%', r: '40%', label: { rotate: 0 } },
          { r0: '40%', r: '72%' }],
        itemStyle: { borderColor: '#fff', borderWidth: 1 },
        emphasis: { focus: 'ancestor' },
      }],
    };
  },

  // ---- 画法 4：明细表（文字描述 + 技术参数 + 关系，整列直接可读）----
  _tableHtml(ctx) {
    const esc = this._esc;
    const layerName = {};
    (ctx.g.layers || []).forEach(L => { layerName[L.index] = L.name; });
    const head = ['层级', '类型', '名称', '文字描述（直接可读）', '技术参数（代码口径）', '关系']
      .map(h => `<th style="text-align:left; white-space:nowrap">${LASE.t(h)}</th>`).join('');
    const rows = ctx.nodes.map(n => {
      const rels = (ctx.outRel[n.id] || []).map(r => (r.exempt
        ? `<span style="color:#98a6b5">${esc(r.text)}（${LASE.t('豁免')}）</span>`
        : esc(r.text)));
      const dot = `<span style="display:inline-block; width:9px; height:9px; border-radius:50%; `
        + `background:${this._colorOf(ctx, n.type)}; margin-right:5px"></span>`;
      return `<tr>
        <td class="muted" style="white-space:nowrap">${esc(layerName[n.layer] || '')}</td>
        <td style="white-space:nowrap">${dot}${esc(ctx.typeLabel[n.type] || n.type)}</td>
        <td><b>${esc(n.label)}</b></td>
        <td style="white-space:normal; line-height:1.5">${esc(n.desc || '') || '<span class="muted">—</span>'}</td>
        <td class="muted" style="white-space:normal; line-height:1.5; min-width:170px">`
        + `${esc(n.params || '') || '—'}</td>
        <td class="muted" style="white-space:normal; line-height:1.5; min-width:210px">`
        + `${rels.join('<br>') || '—'}</td>
      </tr>`;
    }).join('');
    return `<table class="tbl"><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table>`;
  },

  _renderLegend(types, edges) {
    const box = this.page.querySelector('#ont-legend');
    box.innerHTML = types.map(t =>
      `<div style="display:flex; align-items:center; gap:8px; margin:4px 0">
        <span style="width:12px; height:12px; border-radius:50%; background:${t.color}; display:inline-block"></span>
        <b>${LASE.t(t.label)}</b></div>`).join('');
    const rels = {};
    edges.forEach(e => { rels[e.label] = (rels[e.label] || 0) + 1; });
    this.page.querySelector('#ont-rel').innerHTML = Object.keys(rels).map(k =>
      `<div style="margin:4px 0">${LASE.t(k)} <span class="muted">×${rels[k]}</span></div>`).join('');
  },

  // ---- 约束 × 课题矩阵（表格形态：豁免关系一次看全）----
  async _loadMatrix() {
    const stat = this.page.querySelector('#ont-matrix-stat');
    const box = this.page.querySelector('#ont-matrix');
    if (!this._filters) await this._loadFilters();
    if (stat) stat.textContent = LASE.t('生成中…');
    try {
      const m = await LASE.api('/api/ontology/uav/matrix' + this._scenarioQuery());
      if (!m || m._unauthorized) return;
      this._matrix = m;
      this._renderMatrix();
    } catch (e) {
      if (stat) stat.textContent = LASE.t('生成失败：') + e;
    }
  },

  _renderMatrix() {
    const m = this._matrix;
    if (!m) return;
    const stat = this.page.querySelector('#ont-matrix-stat');
    const box = this.page.querySelector('#ont-matrix');
    if (m.supported === false) {
      stat.textContent = LASE.t('当前视图：{0} · ', m.scope || '')
        + LASE.t('本场景尚未登记红方模型，暂无约束 × 课题矩阵。');
      box.innerHTML = `<div class="hint" style="color:#b9770e">`
        + `<b>${LASE.t('缺口视图：该场景尚未登记红方模型')}</b>`
        + (m.warnings || []).map(w => `<div style="margin-top:4px">• ${w}</div>`).join('')
        + `</div>`;
      return;
    }
    const head = ['<th style="text-align:left">' + LASE.t('约束') + '</th>']
      .concat(m.columns.map(c => `<th>${c.label}`
        + `<div class="muted" style="font-weight:400">${c.dims}</div></th>`)).join('');
    const rows = m.rows.map(r => {
      const cells = r.cells.map(c => {
        const on = c.state === 'active';
        return `<td style="${on ? 'color:#1c7c3c;font-weight:600' : 'color:#98a6b5'}"`
          + ` title="${LASE.t('检查单元')}：${c.units}">${LASE.t(c.state_label)}</td>`;
      }).join('');
      return `<tr><td style="text-align:left"><b>${r.cid} ${r.name}</b>`
        + `<div class="muted" style="font-weight:400">${r.units}</div></td>${cells}</tr>`;
    }).join('');
    box.innerHTML = `<table class="tbl"><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table>`;
    const st = m.stats;
    stat.textContent = LASE.t('当前视图：{0} · ', m.scope || '')
      + LASE.t('约束 {0} × 课题 {1} = {2} 格 · 生效 {3} · 豁免 {4} · 生成于 {5}',
        st.n_rows, st.n_cols, st.n_cells, st.n_active, st.n_exempt, m.generated_at)
      + (m.warnings.length ? LASE.t('（有告警，见上方）') : '');
  },

  _saveImg(kind) {
    if ((this._form[kind] || 'graph') === 'table') {
      alert(LASE.t('明细表形式没有画布图片可下载，请先切换为网络图 / 分层树图 / 旭日图。'));
      return;
    }
    const chart = this._charts[kind];
    if (!chart) { alert(LASE.t('请先生成图谱')); return; }
    const g = this._g[kind];
    const sk = (g && g.scope_key) ? '_' + g.scope_key : '';
    LASE.saveChart(chart, (kind === 'kg' ? LASE.t('UAV-红方知识图谱')
      : LASE.t('UAV-红方优化模型本体')) + sk);
  },

  _exportQuery(kind, fmt) {
    const p = ['kind=' + kind, 'fmt=' + fmt];
    if (this._sel.scenario) p.push('scenario=' + encodeURIComponent(this._sel.scenario));
    const sel = kind === 'kg' ? this._sel.kg : { mode: this._sel.ontology.mode };
    if (kind === 'kg' && sel.fid !== 'all') p.push('fid=' + encodeURIComponent(sel.fid));
    if (sel.mode !== 'all') p.push('mode=' + encodeURIComponent(sel.mode));
    return p.join('&');
  },

  async _export(kind, fmt) {
    try {
      const res = await LASE.api(`/api/ontology/uav/export?${this._exportQuery(kind, fmt)}`,
        { raw: true });
      if (!res.ok) { alert(LASE.t('导出失败：') + res.status); return; }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const g = this._g[kind];
      const sk = (g && g.scope_key) ? '_' + g.scope_key : '';
      const name = (kind === 'kg' ? 'uav_red_kg' : 'uav_red_ontology') + sk +
        (fmt === 'csv' ? '_triples.csv' : '.jsonld');
      LASE.downloadDataUrl(url, name);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch (e) {
      alert(LASE.t('导出失败：') + e);
    }
  },
});

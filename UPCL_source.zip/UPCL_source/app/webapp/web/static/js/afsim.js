/* AFSIM 2.9 高保真复核页
 * 把 UAV 页存档里的一局 LASE 解（best_x）重新送进真实 AFSIM mission.exe 运行，
 * 展示：引擎元信息 / 战场俯视轨迹 / 三列对比（LASE 原始、LASE 无遮挡、AFSIM）/ 事件流。
 * 数据全部来自 /api/afsim/*，不做任何前端模拟。 */
// 后端 comparison 行的 metric 是代码键，这里给出可读名（小字仍保留键名与单位）
const METRIC_LABEL = {
  n_arrived: '到达架数',
  n_lost: '被击落架数',
  path_length: '累计航程',
  flight_time: '编队终态时刻',
  min_dist: '最近接近距离',
  nofly_steps: '禁飞区侵入',
  n_fired: '武器发射',
  n_hit: '命中',
  n_sensor_tracks: '传感器航迹',
};

LASE.register('afsim', {
  init() {
    this._meta = null;
    this._data = null;
    this._busy = false;
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'afsim' });
    page.innerHTML = `
      <div class="card afs-hero">
        <div class="card-title">${LASE.t('AFSIM 高保真复核')}</div>
        <p style="margin:0 0 6px">${LASE.t('把 UAV 页某一局存档解（决策向量）原样送进真实 AFSIM 2.9 引擎重跑：航路飞行、防空车开火、命中毁伤全部由 mission.exe 计算，本页只做数据搬运与并排对比。')}</p>
        <p class="muted" style="margin:0">${LASE.t('判定规则照抄 LASE（二维水平距离 + 垂直锥），武器用 AFSIM 隐式武器与球形杀伤；三维山地、楼房掩体、巡逻兵交火未建模，已在下方「方法与差异」逐条声明。')}</p>
        <p class="afs-scn-brief" id="afs-scn-brief"><span class="muted">${LASE.t('正在读取想定参数…')}</span></p>
        <div class="afs-badges" id="afs-badges">
          <span class="afs-badge">${LASE.t('正在探测引擎…')}</span>
        </div>
      </div>

      <div class="card afs-train" id="afs-train">
        <div class="card-title">${LASE.t('在线训练（选算法 → 真实优化 → AFSIM 复核）')}</div>
        <p class="hint" style="margin:0 0 10px">${LASE.t('这里不是回放存档：点开始训练，后端会真的起一个该算法实例，逐代生成航点候选并用 LASE 的 intercept 仿真打分；每花掉 1/6 预算把当前最优解送进 mission.exe 实跑一次（检查点），训练结束再把最终解完整复核一遍，自动接到下方俯视图。进度、曲线、检查点都是这次真实运行的输出。')}</p>
        <div class="afs-controls">
          <label class="afs-field"><span>${LASE.t('算法')}</span><select id="afs-tr-host"></select></label>
          <label class="afs-field"><span>${LASE.t('任务')}</span><select id="afs-tr-task"></select></label>
          <label class="afs-field"><span>${LASE.t('评估预算')}</span><select id="afs-tr-evals">
            <option value="400">400</option>
            <option value="2000" selected>2000</option>
            <option value="6000">6000</option>
          </select></label>
          <label class="afs-field"><span>${LASE.t('随机种子')}</span>
            <input id="afs-tr-seed" type="number" step="1" value="20261018"></label>
          <button class="btn primary" id="afs-tr-start">${LASE.t('开始训练')}</button>
          <button class="btn" id="afs-tr-stop" disabled>${LASE.t('停止')}</button>
          <span class="afs-status muted" id="afs-tr-status"></span>
        </div>
        <div class="afs-prog"><div class="afs-prog-bar" id="afs-tr-bar"></div></div>
        <div class="afs-train-grid">
          <div class="afs-train-conv">
            <div class="afs-train-sub muted">${LASE.t('实时收敛曲线（最优代价 vs 评估次数）')}</div>
            <canvas id="afs-tr-canvas" height="150"></canvas>
            <div class="afs-train-stats muted" id="afs-tr-stats">${LASE.t('尚未开始')}</div>
          </div>
          <div class="afs-train-ck">
            <div class="afs-train-sub muted">${LASE.t('AFSIM 检查点（每 1/6 预算抽当前最优解实跑）')}</div>
            <div id="afs-tr-ck"><span class="muted">${LASE.t('尚未开始')}</span></div>
          </div>
        </div>
        <div class="afs-train-actions">
          <button class="btn" id="afs-tr-demo" disabled>${LASE.t('在真实 AFSIM 中演示（打开 Warlock）')}</button>
          <span class="afs-saved muted" id="afs-tr-saved">${LASE.t('训练结果自动保存为 train_result.json，可直接回放或送进 Warlock')}</span>
        </div>
        <div class="afs-train-sub muted" style="margin:14px 0 6px">${LASE.t('已保存的训练（载入即回放，不必重跑）')}</div>
        <div class="afs-runs" id="afs-tr-runs"><span class="muted">${LASE.t('正在读取…')}</span></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('复核用例')}</div>
        <div class="afs-controls">
          <label class="afs-field"><span>${LASE.t('任务')}</span><select id="afs-task"></select></label>
          <label class="afs-field"><span>${LASE.t('算法')}</span><select id="afs-host"></select></label>
          <label class="afs-field"><span>${LASE.t('run')}</span><select id="afs-run"></select></label>
          <label class="afs-field"><span>${LASE.t('实验臂')}</span><select id="afs-arm">
            <option value="full">${LASE.t('full 臂（DE + UPCL 叠加）')}</option>
            <option value="bare">${LASE.t('bare 臂（纯 DE）')}</option>
          </select></label>
          <button class="btn primary" id="afs-run-btn">${LASE.t('用 AFSIM 复核')}</button>
          <button class="btn" id="afs-refresh-btn">${LASE.t('强制重跑')}</button>
          <span class="afs-status muted" id="afs-status"></span>
        </div>
        <div class="afs-links" id="afs-downloads"></div>
      </div>

      <div class="card afs-film">
        <div class="card-title">${LASE.t('原版 AFSIM 图形前端演示（Warlock · 样例）')}</div>
        <p class="hint" style="margin:0 0 10px">${LASE.t('这段录屏由 AFSIM 2.9 自带图形前端 warlock.exe 实时渲染：平台图标与平台名、射程环与探测半径、航迹线、控制台遥测行、底部时钟与运行状态全部来自引擎，不是前端 Canvas 绘制的动画。切换算法或任务，可直接看不同决策向量在同一引擎里的表现。录屏只作样例，现场计算请用上方「在线训练」。')}</p>
        <div class="afs-film-pick">
          <label>${LASE.t('算法')}<select id="afs-film-host"></select></label>
          <label>${LASE.t('任务')}<select id="afs-film-fid"></select></label>
          <label>${LASE.t('第几局')}<select id="afs-film-run"></select></label>
          <span class="afs-film-meta muted" id="afs-film-meta"></span>
        </div>
        <div class="afs-film-wrap">
          <video id="afs-film" controls preload="metadata" playsinline>
            ${LASE.t('当前浏览器无法播放 MP4')}
          </video>
        </div>
        <div class="afs-film-bar">
          <span class="muted" id="afs-film-note">${LASE.t('加载演示录屏清单…')}</span>
          <a class="btn" id="afs-film-dl" download>${LASE.t('下载原版演示视频')}</a>
        </div>
      </div>

      <div class="afs-grid">
        <div class="card afs-map-card">
          <div class="card-title">${LASE.t('战场俯视图（AFSIM 遥测）')}</div>
          <p class="hint afs-canvas-hint">${LASE.t('下图为按 AFSIM 遥测逐帧重绘的俯视图（可拖时间轴、导出动画），不是录屏；原版图形前端画面见上方视频。')}</p>
          <div class="afs-canvas-wrap"><canvas id="afs-canvas"></canvas></div>
          <div class="afs-legend" id="afs-legend"></div>
          <div class="afs-player">
            <button class="btn" id="afs-play">▶ ${LASE.t('播放')}</button>
            <input type="range" id="afs-slider" min="0" max="1000" value="1000">
            <span class="afs-clock muted" id="afs-clock">t = 0.00 s</span>
            <label class="afs-field"><span>${LASE.t('倍速')}</span><select id="afs-speed">
              <option value="0.5">0.5×</option><option value="1" selected>1×</option><option value="2">2×</option>
            </select></label>
            <button class="btn" id="afs-shot">${LASE.t('下载图片')}</button>
            <button class="btn" id="afs-video">${LASE.t('导出俯视动画')}</button>
          </div>
        </div>
        <div class="card">
          <div class="card-title">${LASE.t('复核结果')}</div>
          <div class="afs-kpi" id="afs-kpi"></div>
          <div class="afs-verdict" id="afs-verdict"></div>
        </div>
      </div>

      <div class="card" id="afs-scenario">
        <div class="card-title">${LASE.t('想定说明与优化问题')}</div>
        <p class="hint" style="margin:0 0 10px">${LASE.t('这里的 AFSIM 想定不是引擎自带样例：WSF 文本由本页按 LASE 的 EnvConfig 现场生成，蓝方中途航点是唯一由算法决定的量，红方（防空车 / 拦截直升机 / 预警雷达）是固定规则的环境。')}</p>
        <div id="afs-scn"><span class="muted">${LASE.t('正在读取想定参数…')}</span></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('三列对比')}</div>
        <p class="hint" style="margin:0 0 10px">${LASE.t('LASE 原始 = 含三维山地与 LOS 遮挡；LASE 无遮挡 = 关掉遮挡后重放同一解，等价于 AFSIM 的平坦地面假设；Δ = AFSIM − LASE 无遮挡，用来判断桥接本身是否走样。')}</p>
        <div id="afs-table"></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('AFSIM 事件流')}</div>
        <div class="afs-events" id="afs-events"><span class="muted">${LASE.t('尚未运行')}</span></div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('方法与差异')}</div>
        <div id="afs-notes"></div>
      </div>
    `;
    // 只移除本页旧节点。注意：这里曾经写成 c.innerHTML = ''，
    // 会把先于本页初始化的 dashboard / reference / refs / research 四页一并删掉，
    // 导致「主界面、算法与测试集、论文及参考资料、研究思路」四页白屏。
    const prev = c.querySelector(':scope > .page[data-page="afsim"]');
    if (prev && prev !== page) prev.remove();
    c.appendChild(page);

    this._page = page;
    this._cv = page.querySelector('#afs-canvas');
    this._lastW = 0;
    this._onResize = () => { if (this._data && document.body.contains(this._cv)) this._draw(); };
    window.addEventListener('resize', this._onResize);
    // 页面首次挂载时容器可能还是 0 宽（进场动画/display 切换），用 ResizeObserver 补偿
    this._ro = new ResizeObserver(entries => {
      if (!this._data || !document.body.contains(this._cv)) return;
      const w = Math.round(entries[0].contentRect.width);
      if (Math.abs(w - this._lastW) >= 8) this._draw();
    });
    const wrapEl = page.querySelector('.afs-canvas-wrap');
    if (wrapEl) this._ro.observe(wrapEl);

    this._t = null;
    this._playing = false;
    this._raf = null;
    this._speed = 1;
    this._recording = false;
    const speedSel = page.querySelector('#afs-speed');
    speedSel.addEventListener('change', () => { this._speed = parseFloat(speedSel.value) || 1; });
    page.querySelector('#afs-play').addEventListener('click', () => this._togglePlay());
    page.querySelector('#afs-slider').addEventListener('input', e => {
      this._pause();
      this._setT(this._dur() * (parseInt(e.target.value, 10) || 0) / 1000);
    });
    page.querySelector('#afs-shot').addEventListener('click', () => this._savePng());
    page.querySelector('#afs-video').addEventListener('click', () => this._exportVideo());

    page.querySelector('#afs-run-btn').addEventListener('click', () => this._run(false));
    page.querySelector('#afs-refresh-btn').addEventListener('click', () => this._run(true));
    ['#afs-host', '#afs-arm'].forEach(sel => {
      page.querySelector(sel).addEventListener('change', () => this._syncRuns());
    });
    page.querySelector('#afs-task').addEventListener('change', () => {
      this._syncRuns();
      this._loadScenario(parseInt(page.querySelector('#afs-task').value, 10) || 1);
    });
    this._loadMeta();
    this._initTrain();
    this._initFilm();
  },

  destroy() {
    this._pause();
    if (this._trTimer) { clearInterval(this._trTimer); this._trTimer = null; }
    if (this._trRO) { this._trRO.disconnect(); this._trRO = null; }
    if (this._onResize) window.removeEventListener('resize', this._onResize);
    if (this._ro) { this._ro.disconnect(); this._ro = null; }
  },

  // ---------------- 原版图形前端（Warlock）演示录屏 ----------------
  async _initFilm() {
    const hostSel = document.getElementById('afs-film-host');
    if (!hostSel) return;
    let data = null;
    try {
      const r = await fetch('media/afsim_warlock_demos.json', { cache: 'no-cache' });
      if (r.ok) data = await r.json();
    } catch (e) { data = null; }
    const items = (data && data.items) || [];
    if (!items.length) {
      document.getElementById('afs-film-note').textContent = LASE.t('暂无演示录屏');
      return;
    }
    this._film = items;
    const hosts = items.map(d => d.host).filter((h, i, a) => a.indexOf(h) === i);
    hostSel.innerHTML = hosts.map(h => `<option value="${h}">${h}</option>`).join('');
    hostSel.value = hosts.indexOf('CoBiDE') >= 0 ? 'CoBiDE' : hosts[0];
    ['#afs-film-host', '#afs-film-fid', '#afs-film-run'].forEach(sel => {
      const el = document.querySelector(sel);
      if (el) el.addEventListener('change', () => this._applyFilm(true));
    });
    this._applyFilm(false);
  },

  _applyFilm(autoplay) {
    const items = this._film || [];
    const hostSel = document.getElementById('afs-film-host');
    const fidSel = document.getElementById('afs-film-fid');
    const runSel = document.getElementById('afs-film-run');
    if (!hostSel || !fidSel || !runSel || !items.length) return;
    const host = hostSel.value;
    const pool = items.filter(d => d.host === host);
    const fids = pool.map(d => d.fid).filter((f, i, a) => a.indexOf(f) === i).sort((a, b) => a - b);
    const prevFid = parseInt(fidSel.value, 10);
    const curFid = fids.indexOf(prevFid) >= 0 ? prevFid : fids[0];
    fidSel.innerHTML = fids.map(f => {
      const it = pool.find(d => d.fid === f) || {};
      return `<option value="${f}">F${f} ${LASE.t(it.task || '')}</option>`;
    }).join('');
    fidSel.value = String(curFid);
    const runs = pool.filter(d => d.fid === curFid).sort((a, b) => a.run - b.run);
    const prevRun = parseInt(runSel.value, 10);
    const curRun = runs.some(d => d.run === prevRun) ? prevRun : runs[0].run;
    runSel.innerHTML = runs.map(d => `<option value="${d.run}">run ${d.run}</option>`).join('');
    runSel.value = String(curRun);
    const it = runs.find(d => d.run === curRun) || runs[0];

    const v = document.getElementById('afs-film');
    v.pause();
    if (it.poster) v.setAttribute('poster', it.poster + '?v=' + it.mtime);
    else v.removeAttribute('poster');
    v.innerHTML = `<source src="${it.url}?v=${it.mtime}" type="video/mp4">`;
    v.load();
    if (autoplay) { const p = v.play(); if (p && p.catch) p.catch(() => {}); }

    document.getElementById('afs-film-meta').textContent =
      `${it.host} · F${it.fid} ${LASE.t(it.task || '')} · run ${it.run} · 60 s · ${(it.bytes / 1048576).toFixed(2)} MB`;
    document.getElementById('afs-film-note').textContent =
      LASE.t('录屏取自 AFSIM 官方界面：每一局想定都由该算法该任务的 LASE 决策向量生成，画面元素全部来自引擎。');
    const dl = document.getElementById('afs-film-dl');
    dl.href = it.url;
    dl.setAttribute('download', it.url.split('/').pop());
  },

  // ---------------- 在线训练：真实 DE 优化 + 周期 AFSIM 复核 ----------------
  async _initTrain() {
    const hostSel = document.getElementById('afs-tr-host');
    if (!hostSel) return;
    this._trCurve = [];
    this._trCk = [];
    this._trTid = null;
    this._trTimer = null;
    this._label = '';
    try {
      const info = await LASE.api('/api/afsim/train/hosts');
      this._trInfo = info;
      const hosts = info.hosts || [];
      hostSel.innerHTML = hosts.map(h => `<option value="${h}">${h}</option>`).join('');
      hostSel.value = hosts.indexOf('CoBiDE') >= 0 ? 'CoBiDE' : (hosts[0] || '');
      const tasks = info.tasks || {};
      const taskSel = document.getElementById('afs-tr-task');
      taskSel.innerHTML = (info.fids || []).map(f =>
        `<option value="${f}">F${f} · ${LASE.t(tasks[String(f)] || '')}</option>`).join('');
      taskSel.value = '1';
    } catch (e) {
      const s = document.getElementById('afs-tr-status');
      if (s) s.textContent = LASE.t('训练接口不可用：') + ((e && e.message) || e);
      return;
    }
    document.getElementById('afs-tr-start').addEventListener('click', () => this._trainStart());
    document.getElementById('afs-tr-stop').addEventListener('click', () => this._trainStop());
    document.getElementById('afs-tr-demo').addEventListener('click', () => this._demoWarlock(this._label));
    const runsBox = document.getElementById('afs-tr-runs');
    if (runsBox) {
      runsBox.addEventListener('click', ev => {
        const btn = ev.target.closest('button[data-act]');
        if (!btn) return;
        const lbl = btn.getAttribute('data-label') || '';
        if (btn.getAttribute('data-act') === 'load') this._loadRun(lbl);
        else this._demoWarlock(lbl);
      });
    }
    this._loadRuns();
    this._drawConv();
    // 曲线画布宽度跟随列宽：首次挂载时容器可能还没布局出宽度（clientWidth=0），
    // 不补偿会让位图停在 320px、只占左侧一半，所以用 ResizeObserver 重画。
    const cv = document.getElementById('afs-tr-canvas');
    if (cv && window.ResizeObserver) {
      this._trLastW = 0;
      if (this._trRO) this._trRO.disconnect();
      this._trRO = new ResizeObserver(() => {
        const w = Math.round(cv.clientWidth || 0);
        if (w >= 240 && Math.abs(w - (this._trLastW || 0)) >= 2) this._drawConv();
      });
      this._trRO.observe(cv);
    }
  },

  async _trainStart() {
    if (this._trTid) return;
    const host = document.getElementById('afs-tr-host').value;
    const fid = parseInt(document.getElementById('afs-tr-task').value, 10) || 1;
    const evals = parseInt(document.getElementById('afs-tr-evals').value, 10) || 2000;
    const seed = parseInt(document.getElementById('afs-tr-seed').value, 10) || 20261018;
    this._trCurve = [];
    this._trCk = [];
    this._trDone = null;
    this._label = '';
    this._warlock = false;
    document.getElementById('afs-tr-demo').disabled = true;
    this._drawConv();
    document.getElementById('afs-tr-ck').innerHTML =
      `<span class="muted">${LASE.t('等待第一个检查点…')}</span>`;
    document.getElementById('afs-tr-stats').textContent = LASE.t('训练中，暂无数据');
    document.getElementById('afs-tr-start').disabled = true;
    document.getElementById('afs-tr-stop').disabled = false;
    this._setProg(0.01, LASE.t('已提交，等待第一代…'));
    try {
      const r = await LASE.api('/api/afsim/train',
        { method: 'POST', body: { host, fid, evals, seed } });
      this._trTid = r.tid;
    } catch (e) {
      this._setProg(0, LASE.t('训练失败：') + ((e && e.message) || e));
      document.getElementById('afs-tr-start').disabled = false;
      document.getElementById('afs-tr-stop').disabled = true;
      return;
    }
    this._trTimer = setInterval(() => this._trainPoll(), 700);
  },

  _trainStop() {
    if (!this._trTid) return;
    this._setProg(0.02, LASE.t('正在停止…'));
    LASE.api('/api/task/' + this._trTid + '/cancel',
      { method: 'POST', body: {} }).catch(() => {});
  },

  _setProg(frac, msg) {
    const bar = document.getElementById('afs-tr-bar');
    if (bar) bar.style.width = (Math.max(0, Math.min(1, frac)) * 100).toFixed(1) + '%';
    const st = document.getElementById('afs-tr-status');
    if (st && msg !== undefined && msg !== null) st.textContent = msg;
  },

  _fmt(v) {
    if (v === null || v === undefined || !isFinite(v)) return '—';
    return Number(v).toFixed(1);
  },

  async _trainPoll() {
    if (!this._trTid) return;
    let st = null;
    try {
      st = await LASE.api('/api/task/' + this._trTid);
    } catch (e) { return; }
    const live = st.live || {};
    if (Array.isArray(live.curve) && live.curve.length) {
      this._trCurve = live.curve;
      this._drawConv();
    }
    if (Array.isArray(live.checkpoints) && live.checkpoints.length) {
      this._trCk = live.checkpoints;
      this._renderCk(this._trCk);
    }
    if (st.state === 'running') {
      const n = live.nevals || 0;
      const budget = live.budget || 0;
      this._setProg(Math.max(0.02, st.progress || 0),
        `${LASE.t('训练中')} ${n}/${budget} · ${LASE.t('第')} ${live.gen || '—'} ${LASE.t('代')}` +
        ` · ${LASE.t('最优代价')} ${this._fmt(live.best)}`);
      if (n) {
        document.getElementById('afs-tr-stats').textContent =
          `${live.gen || '—'} ${LASE.t('代')} · ${n}/${budget} ${LASE.t('次评估')}` +
          ` · ${LASE.t('最优代价')} ${this._fmt(live.best)}`;
      }
      return;
    }
    if (this._trTimer) { clearInterval(this._trTimer); this._trTimer = null; }
    this._trTid = null;
    document.getElementById('afs-tr-start').disabled = false;
    document.getElementById('afs-tr-stop').disabled = true;
    if (st.state === 'error') {
      const err = String(st.error || '');
      const cancelled = err.indexOf('cancelled') >= 0;
      this._setProg(st.progress || 0,
        (cancelled ? LASE.t('已停止') : LASE.t('训练失败：')) + (cancelled ? '' : err));
      return;
    }
    const r = st.result || {};
    this._trDone = r;
    this._applyRun(r);
    this._loadRuns();
  },

  // 把一份训练结果（新跑完的或从磁盘载回的）铺到卡片与下方所有图表上
  _applyRun(r) {
    this._trCurve = Array.isArray(r.curve) ? r.curve : [];
    this._trCk = Array.isArray(r.checkpoints) ? r.checkpoints : [];
    this._drawConv();
    this._renderCk(this._trCk);
    this._setProg(1, `${LASE.t('训练完成')} · ${LASE.t('初代')} ${this._fmt(r.cost_first)}` +
      ` → ${LASE.t('最终')} ${this._fmt(r.cost_best)} · ${this._fmt(r.wall_time_s)} s`);
    const af = (r.afsim || {}).metrics || {};
    document.getElementById('afs-tr-stats').textContent =
      `${r.host} · F${r.fid} ${LASE.t(r.task || '')} · ${r.dim}D · pop ${r.pop_size}` +
      ` · ${r.used_evals || r.budget}/${r.budget} ${LASE.t('次评估')}` +
      ` · AFSIM ${LASE.t('到达')} ${this._num(af.n_arrived, 0)} / ${LASE.t('损失')} ${this._num(af.n_lost, 0)}`;
    // 训练结果接管下方俯视图、三列对比与下载链接（走 label= 目录）
    this._label = r.label || '';
    this._warlock = !!r.has_warlock || !!r.warlock_txt;
    const demo = document.getElementById('afs-tr-demo');
    if (demo) demo.disabled = !this._label;
    const saved = document.getElementById('afs-tr-saved');
    if (saved) {
      saved.textContent = r.saved_to && String(r.saved_to).indexOf('save_error') !== 0
        ? LASE.t('已保存：') + r.saved_to
        : LASE.t('训练结果自动保存为 train_result.json，可直接回放或送进 Warlock');
    }
    if (r.afsim && r.afsim.ok) {
      this._data = r.afsim;
      this._renderAll();
    }
  },

  async _loadRuns() {
    const box = document.getElementById('afs-tr-runs');
    if (!box) return;
    let data = null;
    try { data = await LASE.api('/api/afsim/train/runs'); } catch (e) { data = null; }
    this._trRuns = (data && data.runs) || [];
    this._renderRuns(this._trRuns);
  },

  _renderRuns(list) {
    const box = document.getElementById('afs-tr-runs');
    if (!box) return;
    if (!list || !list.length) {
      box.innerHTML = `<span class="muted">${LASE.t('暂无已保存的训练')}</span>`;
      return;
    }
    box.innerHTML = list.map(r => {
      const arr = (r.n_arrived === null || r.n_arrived === undefined) ? '—' : r.n_arrived;
      const lost = (r.n_lost === null || r.n_lost === undefined) ? '—' : r.n_lost;
      return '<div class="afs-run-row">' +
        `<div class="afs-run-main"><b>${r.label}</b>` +
        `<span class="muted">${r.host} · F${r.fid} ${LASE.t(r.task || '')} · ` +
        `${r.used_evals || r.budget} ${LASE.t('次评估')} · seed ${r.seed} · ${r.saved_at || ''}</span>` +
        `<span class="muted">${LASE.t('初代')} ${this._fmt(r.cost_first)} → ${LASE.t('最终')} ` +
        `${this._fmt(r.cost_best)} · AFSIM ${LASE.t('到达')} ${arr} / ${LASE.t('损失')} ${lost}</span></div>` +
        '<div class="afs-run-btns">' +
        `<button class="btn" data-act="load" data-label="${r.label}">${LASE.t('载入回放')}</button>` +
        `<button class="btn" data-act="demo" data-label="${r.label}">${LASE.t('在 Warlock 中演示')}</button>` +
        '</div></div>';
    }).join('');
  },

  async _loadRun(label) {
    if (!label) return;
    const el = document.getElementById('afs-tr-saved');
    if (el) el.textContent = LASE.t('正在载入训练结果…');
    try {
      const r = await LASE.api('/api/afsim/train/result?label=' + encodeURIComponent(label));
      this._applyRun(r);
      // 把选择器同步成这条记录的参数，方便「原样重跑」
      const setSel = (sel, val) => {
        const el2 = document.querySelector(sel);
        if (!el2) return;
        if (Array.from(el2.options).some(o => o.value === String(val))) el2.value = String(val);
      };
      setSel('#afs-tr-host', r.host);
      setSel('#afs-tr-task', r.fid);
      const bud = document.querySelector('#afs-tr-evals');
      if (bud && r.budget) {
        const v = String(r.budget);
        if (!Array.from(bud.options).some(o => o.value === v)) {
          const o = document.createElement('option');
          o.value = v;
          o.textContent = v + LASE.t('（已保存）');
          bud.appendChild(o);
        }
        bud.value = v;
      }
      const seedEl = document.querySelector('#afs-tr-seed');
      if (seedEl && r.seed !== undefined && r.seed !== null) seedEl.value = String(r.seed);
      if (el) el.textContent = LASE.t('已载入：') + (r.label || label);
    } catch (e) {
      if (el) el.textContent = LASE.t('载入失败：') + ((e && e.message) || e);
    }
  },

  async _demoWarlock(label) {
    if (!label) return;
    const el = document.getElementById('afs-tr-saved');
    if (el) el.textContent = LASE.t('正在生成 warlock 想定…');
    try {
      const r = await LASE.api('/api/afsim/warlock/demo',
        { method: 'POST', body: { label, launch: true } });
      if (el) el.textContent = LASE.t('已在 Warlock 中打开：') + (r.warlock_txt || r.dir || '');
      this._warlock = true;
      if (this._data) this._renderLinks(this._data);
      this._loadRuns();
    } catch (e) {
      if (el) el.textContent = LASE.t('打开失败：') + ((e && e.message) || e);
    }
  },

  _renderCk(list) {
    const box = document.getElementById('afs-tr-ck');
    if (!box) return;
    if (!list || !list.length) {
      box.innerHTML = `<span class="muted">${LASE.t('等待第一个检查点…')}</span>`;
      return;
    }
    const head = '<div class="afs-ck-row is-head">' +
      `<span>#</span><span>${LASE.t('评估')}</span><span>${LASE.t('代价')}</span>` +
      `<span>${LASE.t('到达')}</span><span>${LASE.t('损失')}</span><span>${LASE.t('引擎')}</span></div>`;
    const rows = list.map((c, i) => '<div class="afs-ck-row">' +
      `<span>${i + 1}</span><span>${c.evals}</span><span>${this._fmt(c.cost)}</span>` +
      `<span>${c.n_arrived === null || c.n_arrived === undefined ? '—' : c.n_arrived}</span>` +
      `<span>${c.n_lost === null || c.n_lost === undefined ? '—' : c.n_lost}</span>` +
      `<span>${c.ok ? this._fmt(c.wall_s) + ' s' : LASE.t('失败')}</span></div>`).join('');
    box.innerHTML = head + rows;
  },

  _drawConv() {
    const cv = document.getElementById('afs-tr-canvas');
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    const cw = Math.round(cv.clientWidth || 0);
    if (cw < 40) return;                      // 还没布局出宽度，等 ResizeObserver 再画
    const w = cw;
    const h = 150;
    this._trLastW = w;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
      cv.width = Math.round(w * dpr);
      cv.height = Math.round(h * dpr);
    }
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const ink = getComputedStyle(document.body).color || '#888';
    const pad = { l: 48, r: 12, t: 12, b: 22 };
    ctx.strokeStyle = 'rgba(140,150,170,.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(pad.l, pad.t, w - pad.l - pad.r, h - pad.t - pad.b);
    const pts = (this._trCurve || []).filter(p => p && isFinite(p[0]) && isFinite(p[1]));
    if (pts.length < 2) {
      ctx.fillStyle = ink;
      ctx.globalAlpha = 0.55;
      ctx.font = '12px system-ui, sans-serif';
      ctx.fillText(LASE.t('尚无数据'), pad.l + 8, pad.t + 20);
      ctx.globalAlpha = 1;
      return;
    }
    const xs = pts.map(p => p[0]);
    const ys = pts.map(p => p[1]);
    const x0 = Math.min.apply(null, xs);
    const x1 = Math.max.apply(null, xs) || 1;
    let y0 = Math.min.apply(null, ys);
    let y1 = Math.max.apply(null, ys);
    if (y1 - y0 < 1e-6) { y0 -= 1; y1 += 1; }
    const X = v => pad.l + (w - pad.l - pad.r) * (v - x0) / Math.max(1e-9, x1 - x0);
    const Y = v => pad.t + (h - pad.t - pad.b) * (1 - (v - y0) / (y1 - y0));
    ctx.strokeStyle = '#4f8dfd';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(X(p[0]), Y(p[1])) : ctx.moveTo(X(p[0]), Y(p[1]))));
    ctx.stroke();
    const last = pts[pts.length - 1];
    ctx.fillStyle = '#4f8dfd';
    ctx.beginPath();
    ctx.arc(X(last[0]), Y(last[1]), 3.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = ink;
    ctx.globalAlpha = 0.7;
    ctx.font = '11px system-ui, sans-serif';
    ctx.fillText(this._fmt(y1), 4, pad.t + 4);
    ctx.fillText(this._fmt(y0), 4, h - pad.b);
    ctx.fillText(String(x0), pad.l, h - 6);
    ctx.textAlign = 'right';
    ctx.fillText(String(x1), w - pad.r, h - 6);
    ctx.textAlign = 'left';
    ctx.globalAlpha = 1;
  },

  // ---------------- 引擎元信息与用例清单 ----------------
  async _loadMeta() {
    const s = this._p('#afs-status');
    s.textContent = LASE.t('正在探测 AFSIM 引擎…');
    try {
      this._meta = await LASE.api('/api/afsim/meta');
    } catch (e) {
      s.textContent = LASE.t('元信息加载失败：') + (e && e.message ? e.message : e);
      this._p('#afs-badges').innerHTML =
        `<span class="afs-badge is-off">${LASE.t('引擎不可用')}</span>`;
      return;
    }
    this._renderBadges();
    this._renderNotes();
    const m = this._meta;
    const task = this._p('#afs-task');
    task.innerHTML = (m.tasks || []).map(t =>
      `<option value="${t.fid}">F${t.fid} · ${LASE.t(t.name)}</option>`).join('');
    const host = this._p('#afs-host');
    host.innerHTML = (m.hosts || []).map(h => `<option value="${h}">${h}</option>`).join('');
    if (m.defaults) {
      task.value = String(m.defaults.fid || 1);
      if (m.defaults.host) host.value = m.defaults.host;
    }
    this._syncRuns();
    this._loadScenario(parseInt(task.value, 10) || 1);
    s.textContent = '';
    if (m.ready && m.n_cases) this._run(false);
    else s.textContent = LASE.t('引擎不可用或没有可复核的存档');
  },

  _renderBadges() {
    const m = this._meta, e = (m && m.engine) || {};
    const box = this._p('#afs-badges');
    if (!box) return;
    const items = [];
    if (m.ready) {
      items.push(`<span class="afs-badge is-ok">${LASE.t('真实引擎 · 非 mock')}</span>`);
      items.push(`<span class="afs-badge">AFSIM ${e.version || '2.9'}</span>`);
      if (e.built) items.push(`<span class="afs-badge">${LASE.t('构建')} ${e.built}</span>`);
      items.push(`<span class="afs-badge">${e.plugins ? e.plugins.length : 0} ${LASE.t('个插件')}</span>`);
      items.push(`<span class="afs-badge">${e.warlock ? 'mission.exe + warlock.exe' : 'mission.exe'}</span>`);
      items.push(`<span class="afs-badge">${m.n_cases} ${LASE.t('个可复核存档')}</span>`);
    } else {
      items.push(`<span class="afs-badge is-off">${LASE.t('引擎不可用')}</span>`);
      items.push(`<span class="afs-badge is-off">${e.reason || ''}</span>`);
    }
    box.innerHTML = items.join('');
  },

  _renderNotes() {
    const m = this._meta || {};
    const notes = m.notes || {};
    const box = this._p('#afs-notes');
    if (!box) return;
    const li = (m.not_modeled || []).map(x => `<li>${LASE.t(x)}</li>`).join('');
    box.innerHTML = `
      <div class="afs-note-grid">
        <div><div class="afs-note-h">${LASE.t('判定规则')}</div><p>${LASE.t(notes.rule || '')}</p></div>
        <div><div class="afs-note-h">${LASE.t('已声明的建模差')}</div><p>${LASE.t(notes.difference || '')}</p></div>
      </div>
      <div class="afs-note-h" style="margin-top:10px">${LASE.t('未建模项（不参与对比）')}</div>
      <ul class="afs-note-list">${li}</ul>
      <p class="muted" style="margin:8px 0 0">${LASE.t('想定与产物落盘在 results/apps/afsim_check/<用例>/：input.txt（想定）、mission.log（引擎日志）、out/events.evt（事件）、afsim_check.json（对比结果），可在上方直接下载。')}</p>`;
  },

  // ---------------- 想定说明与优化问题 ----------------
  async _loadScenario(fid) {
    const box = this._p('#afs-scn');
    if (!box) return;
    const key = String(fid || 1);
    if (this._scn && String(this._scn.fid) === key) { this._renderScenario(this._scn); return; }
    box.innerHTML = `<span class="muted">${LASE.t('正在读取想定参数…')}</span>`;
    try {
      this._scn = await LASE.api('/api/afsim/scenario?fid=' + key);
    } catch (e) {
      box.innerHTML = `<span class="muted">${LASE.t('想定说明加载失败：')}${e && e.message ? e.message : e}</span>`;
      return;
    }
    this._renderScenario(this._scn);
  },

  _renderScenario(d) {
    const t = s => LASE.t(s);
    const box = this._p('#afs-scn');
    if (!box) return;
    const m = d.map, tm = d.time, de = d.decision, ob = d.objective;
    const bl = d.blue, rd = d.red;
    const f0 = v => String(Math.round(v));
    const f1 = v => (Math.round(v * 10) / 10).toFixed(1);
    const f3 = v => (Math.round(v * 1000) / 1000).toFixed(3);
    const fmt = (s, o) => String(s).replace(/\{(\w+)\}/g, (x, k) => (o[k] !== undefined ? o[k] : x));
    const pts = a => (a || []).map(p => `(${f0(p[0])}, ${f0(p[1])})`).join('  ');
    const kv = (k, v) => `<div class="afs-scn-kv"><span class="afs-scn-k">${k}</span><span class="afs-scn-v">${v}</span></div>`;
    const chip = v => `<span class="afs-scn-chip">${v}</span>`;
    const li = arr => `<ul class="afs-note-list">${(arr || []).map(x => `<li>${t(x)}</li>`).join('')}</ul>`;

    // 英雄区一句话摘要
    const brief = this._p('#afs-scn-brief');
    if (brief) {
      brief.innerHTML = fmt(t('当前想定：F{fid} {task} — 蓝方 {u} 架无人机 + {i} 名步兵（D={dim} 航路决策）vs 红方 {aa} 辆防空车 + {heli} 架拦截直升机 + 预警雷达，{w}×{h} m 战场 {sec} s'),
        { fid: d.fid, task: t(d.task), u: bl.uav.n, i: bl.inf.n, dim: de.dim,
          aa: rd.aa.n, heli: rd.heli.n, w: f0(m.w), h: f0(m.h), sec: f1(tm.seconds) }) +
        ` <a class="afs-scn-jump" href="#afs-scenario">${t('看想定与优化问题 ↓')}</a>`;
    }

    const blueRows = [
      kv(fmt(t('无人机 ×{n}'), { n: bl.uav.n }),
        fmt(t('速度 {v} m/s（{u} 单位/步）· 转弯率 {tr} rad/s（最小转弯半径 {r} m）· 巡航高度 ≤ {alt} m · {k} 个中途航点（到达半径 {rr} m）· 能耗 {e}/步，爬升另计（{cl} m/s），耗尽即坠毁'),
          { v: f0(bl.uav.speed), u: f1(bl.uav.speed * tm.dt), tr: f1(bl.uav.turn),
            r: f0(bl.uav.speed / bl.uav.turn), alt: f0(bl.uav.alt_max), k: bl.uav.waypoints,
            rr: f0(bl.uav.reach_r), e: f0(bl.uav.energy), cl: f0(bl.uav.climb) })),
      kv(fmt(t('步兵 ×{n}'), { n: bl.inf.n }),
        fmt(t('速度 {v} m/s（{u} 单位/步）· 单兵血量 {hp} · 射程 {rr} m · 从起点三角队形出发，抵达基地后持续攻击'),
          { v: f0(bl.inf.speed), u: f1(bl.inf.speed * tm.dt), hp: f0(bl.inf.hp), rr: f0(bl.inf.range) })),
    ];
    const aa = rd.aa;
    const heli = rd.heli;
    const redRows = [
      kv(fmt(t('防空车 ×{n}'), { n: aa.n }),
        fmt(t('阵地 {p} · 对空半径 {r} m、垂直 ±{va}° · 冷却 {cd} s · 导弹 {ms} m/s（命中半径 {mr} m、燃料 {fu} 步）'),
          { p: pts(aa.pos), r: f0(aa.range), va: f0(aa.vert_deg), cd: f1(aa.reload_s),
            ms: f0(aa.missile_speed), mr: f0(aa.missile_r), fu: aa.missile_fuel })),
      kv(fmt(t('拦截直升机 ×{n}'), { n: heli.n }),
        fmt(t('停机坪 {p} · 速度 {v} m/s · 捕获半径 {r} m · 只咬前方 ±{hh}°（水平）/ ±{hv}°（垂直）锥内的目标'),
          { p: pts(heli.pos), v: f0(heli.speed), r: f0(heli.catch_r),
            hh: f0(heli.cone_h_deg), hv: f0(heli.cone_v_deg) })),
      kv(t('预警雷达'),
        fmt(t('位于 {p}、半径 {r} m；雷达探测到的目标达到 {al} 架才令直升机起飞'),
          { p: pts([rd.radar.pos]), r: f0(rd.radar.range), al: rd.radar.alert })),
      kv(t('禁飞区'),
        rd.nfz.n
          ? fmt(t('{n} 个球形空域：{list}'), { n: rd.nfz.n, list: rd.nfz.zones.map(z => `(${f0(z[0])}, ${f0(z[1])}, ${f0(z[2])}) r=${f0(z[3])}`).join('  ') })
          : t('本任务不设禁飞区')),
      kv(t('巡逻兵 / 楼房 / 基地血量'),
        `<span class="muted">${fmt(t('{pt} 名巡逻兵、{bd} 栋楼房、基地 {hp} HP —— 只存在于 LASE 仿真，AFSIM 侧未建模'), { pt: rd.patrol.n, bd: rd.base.bld, hp: f0(rd.base.hp) })}</span>`),
    ];

    const decRows = [
      `<tr><td>${t('无人机中途航点')}</td>
        <td class="afs-scn-num">${bl.uav.n} × ${bl.uav.waypoints} × 3 = ${de.blocks[0].n}</td>
        <td>${fmt(t('每架 {k} 个中途点，每点含 x、y 与相对爬升三个分量'), { k: bl.uav.waypoints })}</td>
        <td>${fmt(t('x、y 线性映射到 [0, {w}] × [0, {h}] m；爬升偏移 ∈ [0, {off}] m，叠加在贴地高度 + {clr} m 之上'), { w: f0(de.map_w), h: f0(de.map_h), off: f0(de.max_alt_offset), clr: f0(de.h_clearance) })}</td></tr>`,
      `<tr><td>${t('步兵中途航点')}</td>
        <td class="afs-scn-num">${bl.inf.n} × ${bl.inf.waypoints} × 2 = ${de.blocks[1].n}</td>
        <td>${fmt(t('每名 {k} 个中途点，每点含 x、y 两个分量'), { k: bl.inf.waypoints })}</td>
        <td>${fmt(t('x、y 映射到 [0, {w}] × [0, {h}] m（地面机动，无高度自由度）'), { w: f0(de.map_w), h: f0(de.map_h) })}</td></tr>`,
    ].join('');

    const obRows = (ob.terms || []).map(x => `<tr>
      <td class="afs-scn-num">${x.sign}</td>
      <td class="afs-scn-num">${f0(x.w)}</td>
      <td>${t(x.label)}</td></tr>`).join('');

    box.innerHTML = `
      <div class="afs-scn-head">
        ${chip(`${t('战场')} ${f0(m.w)} × ${f0(m.h)} m`)}
        ${chip(fmt(t('时限 {sec} s（{steps} 步 × {dt} s）'), { sec: f1(tm.seconds), steps: tm.steps, dt: tm.dt }))}
        ${chip(`${t('决策维度')} D = ${de.dim} · ${de.encoding}`)}
        ${chip(`${t('地形')} ${m.terrain ? fmt(t('三维合成山地，起伏 {amp} m'), { amp: f0(m.terrain_amp) }) : t('平坦地面')}`)}
      </div>
      <div class="afs-scn-cols">
        <div>
          <div class="afs-note-h">${t('蓝方（算法优化的对象）')}</div>
          ${blueRows.join('')}
        </div>
        <div>
          <div class="afs-note-h">${t('红方（固定规则的环境）')}</div>
          ${redRows.join('')}
        </div>
      </div>
      <p class="afs-scn-judge">${fmt(t('判定：水平距目标区中心 ≤ {r} m 记到达；进入拦截锥且落在命中半径 {h} m 内记击落；机间 < {c} m、越界或超时同样终止'), { r: f0(d.judge.arrive_r), h: f0(d.judge.catch_r), c: f0(d.judge.collision_r) })}</p>

      <div class="afs-note-h" style="margin-top:16px">${t('算法优化的是什么')}</div>
      <p class="afs-scn-sub">${fmt(t('决策向量 {dim} 维，编码域 {enc}，下表两段相加即 {dim} 维；{fix}'), { dim: de.dim, enc: de.encoding, fix: t(de.fixed) })}</p>
      <table class="afs-scn-tbl">
        <thead><tr><th>${t('分段')}</th><th>${t('维度')}</th><th>${t('含义')}</th><th>${t('解码到想定')}</th></tr></thead>
        <tbody>${decRows}</tbody>
      </table>

      <p class="afs-scn-sub" style="margin-top:14px">${fmt(t('目标函数（越小越好）：{expr}，下表 {n} 项按符号累加后取负即 cost。'), { expr: ob.expr, n: (ob.terms || []).length })}</p>
      <table class="afs-scn-tbl afs-scn-terms">
        <thead><tr><th>${t('符号')}</th><th>${t('权重')}</th><th>${t('项')}</th></tr></thead>
        <tbody>${obRows}</tbody>
      </table>
      <p class="afs-scn-note">${t('目标函数只在 LASE 侧可算：AFSIM 侧没有基地血量、巡逻兵与地形遮挡，因此只回映 6 项几何与毁伤指标，不能重算 cost；这也是「同假设下结论是否一致」只用那 6 项判定的原因。')}</p>

      <div class="afs-note-grid" style="margin-top:14px">
        <div><div class="afs-note-h">${t('AFSIM 引擎实际算什么')}</div>${li(d.afsim_scope.modeled)}</div>
        <div><div class="afs-note-h">${t('引擎侧不建模')}</div>${li(d.afsim_scope.not_modeled)}</div>
      </div>
      <p class="afs-scn-note">${t(d.env_note)}</p>`;
  },

  // ---------------- 用例联动 ----------------
  _cases() {
    return (this._meta && this._meta.cases) || [];
  },

  _curCase() {
    const host = this._p('#afs-host').value;
    const fid = parseInt(this._p('#afs-task').value, 10) || 1;
    return this._cases().find(c => c.host === host && c.fid === fid) || null;
  },

  _syncRuns() {
    const box = this._p('#afs-run');
    if (!box) return;
    const c = this._curCase();
    const n = c ? Math.max(1, c.runs) : 1;
    let html = '';
    for (let i = 0; i < n; i++) html += `<option value="${i}">run ${i}</option>`;
    box.innerHTML = html;
    const arm = this._p('#afs-arm');
    if (c && c.arms && c.arms.length && !c.arms.includes(arm.value)) arm.value = c.arms[0];
    this._renderLinks(null);
  },

  async _run(refresh) {
    if (this._busy) return;
    const host = this._p('#afs-host').value;
    if (!host) return;
    const body = {
      host,
      fid: parseInt(this._p('#afs-task').value, 10) || 1,
      run: parseInt(this._p('#afs-run').value, 10) || 0,
      arm: this._p('#afs-arm').value,
      refresh: !!refresh,
    };
    this._busy = true;
    const btn = this._p('#afs-run-btn');
    btn.disabled = true;
    const s = this._p('#afs-status');
    s.textContent = LASE.t('mission.exe 运行中…');
    try {
      const data = await LASE.api('/api/afsim/run', { method: 'POST', body });
      this._data = data;
      this._label = '';                      // 回到存档用例：产物链接按 host/fid/run/arm 拼
      this._warlock = false;
      if (!data.ok) {
        s.textContent = LASE.t('引擎报错：') + ((data.error || []).join(' ') || 'unknown');
      } else {
        s.textContent = `${LASE.t('完成')} · ${data.wall_time_s}s` +
          (data.cached ? ` · ${LASE.t('命中缓存')}` : '');
      }
      this._renderAll();
    } catch (e) {
      s.textContent = LASE.t('复核失败：') + (e && e.message ? e.message : e);
    } finally {
      this._busy = false;
      btn.disabled = false;
    }
  },

  // ---------------- 渲染 ----------------
  _renderAll() {
    const d = this._data;
    if (!d) return;
    this._renderKpi();
    this._renderTable();
    this._renderEvents();
    this._renderLinks(d);
    this._resetPlayer();
    this._draw();
  },

  _num(v, digits) {
    if (v === null || v === undefined) return '—';
    if (typeof v !== 'number') return String(v);
    return Number.isInteger(v) ? String(v) : v.toFixed(digits === undefined ? 1 : digits);
  },

  _renderKpi() {
    const d = this._data, m = d.metrics || {};
    const box = this._p('#afs-kpi');
    if (!box) return;
    const item = (label, val, unit) =>
      `<div class="afs-kpi-item"><div class="afs-kpi-num">${val}<span>${unit || ''}</span></div>
       <div class="afs-kpi-label">${label}</div></div>`;
    box.innerHTML = [
      item(LASE.t('到达'), this._num(m.n_arrived), LASE.t('架')),
      item(LASE.t('被击落'), this._num(m.n_lost), LASE.t('架')),
      item(LASE.t('开火'), this._num(m.n_fired), LASE.t('发')),
      item(LASE.t('命中'), this._num(m.n_hit), LASE.t('发')),
      item(LASE.t('航程'), this._num(m.path_length, 0), 'm'),
      item(LASE.t('最近距离'), this._num(m.min_dist, 0), 'm'),
    ].join('');

    const lf = d.lase_flat || {}, ls = d.lase || {};
    const colon = LASE.lang() === 'en' ? ': ' : '：';
    const verdict = this._p('#afs-verdict');
    let cls = 'is-warn', txt;
    if (!d.ok) {
      cls = 'is-bad';
      txt = LASE.t('引擎未跑通，请查看日志下载项。');
    } else if (lf.n_arrived === m.n_arrived && lf.n_lost === m.n_lost) {
      cls = 'is-ok';
      txt = LASE.t('同假设下结论一致') + `${colon}${LASE.t('到达')} ${m.n_arrived} / ${LASE.t('损失')} ${m.n_lost}`;
    } else {
      txt = LASE.t('同假设下仍有差异') +
        `${colon}LASE ${LASE.t('LASE 无遮挡')} ${lf.n_arrived}/${lf.n_lost} vs AFSIM ${m.n_arrived}/${m.n_lost}`;
    }
    verdict.className = 'afs-verdict ' + cls;
    verdict.innerHTML = `<b>${txt}</b><div class="muted" style="margin-top:6px">` +
      `${LASE.t('LASE 原始口径')}${colon}${LASE.t('到达')} ${ls.n_arrived} / ${LASE.t('损失')} ${ls.n_lost} · ` +
      `${LASE.t('遥测')} ${this._num(m.frames)} ${LASE.t('帧')}</div>`;
  },

  _renderTable() {
    const d = this._data;
    const box = this._p('#afs-table');
    if (!box) return;
    if (!d.ok || !d.comparison || !d.comparison.length) {
      box.innerHTML = `<span class="muted">${LASE.t('无对比数据')}</span>`;
      return;
    }
    const cell = v => (v === null || v === undefined) ? '—' : this._num(v, Number.isInteger(v) ? 0 : 1);
    const rows = d.comparison.map(r => {
      let dcls = '';
      if (r.delta !== null && r.delta !== undefined) {
        const base = Math.max(Math.abs(r.lase_flat || 0), 1);
        dcls = Math.abs(r.delta) / base <= 0.05 ? 'is-good' : 'is-warn';
      }
      return `<tr>
        <td title="${r.note ? LASE.t(r.note) : ''}">${LASE.t(METRIC_LABEL[r.metric] || r.metric)}<span class="afs-row-note">${r.metric}${r.unit ? ' · ' + LASE.t(r.unit) : ''}</span></td>
        <td>${cell(r.lase)}</td><td>${cell(r.lase_flat)}</td><td><b>${cell(r.afsim)}</b></td>
        <td class="afs-delta ${dcls}">${r.delta === null || r.delta === undefined ? '—' : (r.delta > 0 ? '+' : '') + this._num(r.delta, 1)}</td>
      </tr>`;
    }).join('');
    box.innerHTML = `<table class="data-table afs-table">
      <thead><tr>
        <th>${LASE.t('指标')}</th><th>${LASE.t('LASE 原始')}</th>
        <th>${LASE.t('LASE 无遮挡')}</th><th>AFSIM 2.9</th>
        <th>${LASE.t('Δ（AFSIM − 无遮挡）')}</th>
      </tr></thead><tbody>${rows}</tbody></table>`;
  },

  _renderEvents() {
    const d = this._data;
    const box = this._p('#afs-events');
    if (!box) return;
    const evs = (d.events || []).filter(e => e.event !== 'PLATFORM_ADDED');
    if (!evs.length) {
      box.innerHTML = `<span class="muted">${LASE.t('本次运行没有武器/毁伤事件')}</span>`;
      return;
    }
    const NAME = {
      PLATFORM_BROKEN: LASE.t('平台被摧毁'),
      PLATFORM_DELETED: LASE.t('平台退场'),
      WEAPON_FIRED: LASE.t('武器发射'),
      WEAPON_HIT: LASE.t('命中'),
      WEAPON_MISSED: LASE.t('脱靶'),
      SENSOR_TRACK_INITIATED: LASE.t('传感器航迹起始'),
    };
    const rows = evs.slice(0, 240).map(e => {
      const cls = /BROKEN|HIT/.test(e.event) ? 'is-hot' : (/MISSED/.test(e.event) ? 'is-miss' : '');
      const t = (e.t === null || e.t === undefined) ? '—' : Number(e.t).toFixed(2);
      return `<tr class="${cls}"><td>${t}</td><td>${NAME[e.event] || e.event}</td>
        <td>${e.subject || ''}</td><td>${e.target || ''}</td></tr>`;
    }).join('');
    box.innerHTML = `<table class="data-table afs-evtable">
      <thead><tr><th>t (s)</th><th>${LASE.t('事件')}</th><th>${LASE.t('主体')}</th><th>${LASE.t('对象')}</th></tr></thead>
      <tbody>${rows}</tbody></table>`;
  },

  _renderLinks(d) {
    const box = this._p('#afs-downloads');
    if (!box) return;
    const host = this._p('#afs-host').value;
    const fid = parseInt(this._p('#afs-task').value, 10) || 1;
    const run = parseInt(this._p('#afs-run').value, 10) || 0;
    const arm = this._p('#afs-arm').value;
    // 在线训练的产物目录名不是 <host>_F<fid>_run<run>_<arm>，用 label 直指
    const q = this._label
      ? `host=${encodeURIComponent(host)}&fid=${fid}&label=${encodeURIComponent(this._label)}`
      : `host=${encodeURIComponent(host)}&fid=${fid}&run=${run}&arm=${arm}`;
    if (!d || !d.ok) { box.innerHTML = ''; return; }
    const tok = `&token=${encodeURIComponent(LASE.token())}`;
    const link = (name, label) =>
      `<a class="afs-dl" href="/api/afsim/artefact/${name}?${q}${tok}" target="_blank" rel="noopener">${label}</a>`;
    box.innerHTML = [
      link('input.txt', LASE.t('想定 input.txt')),
      this._warlock ? link('warlock.txt', LASE.t('Warlock 想定 warlock.txt')) : '',
      link('mission.log', LASE.t('引擎日志 mission.log')),
      link('events.evt', LASE.t('事件 events.evt')),
      link('afsim_check.json', LASE.t('对比 JSON')),
      `<span class="afs-dl-path">${d.work_dir || ''}</span>`,
    ].join('');
  },

  // ---------------- 回放（时间游标） ----------------
  _dur() {
    const tel = (this._data && this._data.telemetry) || {};
    let mx = 0;
    Object.keys(tel).forEach(n => {
      const pts = tel[n] || [];
      if (pts.length) mx = Math.max(mx, pts[pts.length - 1][0]);
    });
    return mx || 0;
  },

  _tcur() {
    const dur = this._dur();
    if (this._t === null || this._t === undefined) return dur;
    return Math.max(0, Math.min(dur, this._t));
  },

  _resetPlayer() {
    this._pause();
    const dur = this._dur();
    this._t = dur;
    this._syncPlayer();
  },

  _syncPlayer() {
    const dur = this._dur();
    const sl = this._p('#afs-slider');
    if (sl) sl.value = String(dur > 0 ? Math.round(this._tcur() / dur * 1000) : 1000);
    const ck = this._p('#afs-clock');
    if (ck) ck.textContent = dur > 0 ? `t = ${this._tcur().toFixed(2)} / ${dur.toFixed(2)} s` : 't = 0.00 s';
  },

  _setT(t) {
    const dur = this._dur();
    this._t = Math.max(0, Math.min(dur, t));
    this._syncPlayer();
    this._draw();
  },

  _togglePlay() { this._playing ? this._pause() : this._play(); },

  _play() {
    if (!this._data || !this._data.ok || this._recording) return;
    const dur = this._dur();
    if (dur <= 0) return;
    if (this._tcur() >= dur - 1e-6) this._t = 0;
    this._playing = true;
    const btn = this._p('#afs-play');
    if (btn) btn.textContent = '⏸ ' + LASE.t('暂停');
    let last = performance.now();
    const step = now => {
      if (!this._playing) return;
      const dt = Math.min(0.12, (now - last) / 1000) * this._speed;
      last = now;
      const t = this._tcur() + dt;
      if (t >= dur) { this._setT(dur); this._pause(); return; }
      this._setT(t);
      this._raf = requestAnimationFrame(step);
    };
    this._raf = requestAnimationFrame(step);
  },

  _pause() {
    this._playing = false;
    if (this._raf) { cancelAnimationFrame(this._raf); this._raf = null; }
    const btn = this._p('#afs-play');
    if (btn) btn.textContent = '▶ ' + LASE.t('播放');
  },

  // 轨迹在 tc 时刻的插值位置 → [x, y, dead]
  _headAt(pts, tc) {
    if (!pts || !pts.length) return null;
    const last = pts[pts.length - 1];
    if (tc >= last[0]) return [last[1], last[2], (last[4] || 0) >= 0.999];
    for (let i = 1; i < pts.length; i++) {
      if (pts[i][0] >= tc) {
        const a = pts[i - 1], b = pts[i];
        const span = (b[0] - a[0]) || 1;
        const f = Math.max(0, Math.min(1, (tc - a[0]) / span));
        return [a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f, false];
      }
    }
    return [pts[0][1], pts[0][2], false];
  },

  // ---------------- 绘制 ----------------
  _draw() {
    const d = this._data, cv = this._cv;
    if (!d || !d.ok || !cv || !d.geometry) return;
    const g = d.geometry, W = g.map[0], H = g.map[1];
    const wrap = cv.parentElement;
    // 容器尚未布局时退到卡片宽度，避免画成 280px 的小图
    let cssW = Math.round(wrap.clientWidth - 2);
    if (cssW < 320) {
      const card = wrap.parentElement;
      cssW = Math.max(320, Math.round((card ? card.clientWidth : 640) - 32));
    }
    this._lastW = cssW;
    const cssH = Math.round(cssW * H / W);
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(cssW * dpr);
    cv.height = Math.round(cssH * dpr);
    cv.style.width = cssW + 'px';
    cv.style.height = cssH + 'px';
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this._paint(ctx, cssW, cssH, this._tcur());
    this._renderLegend();
  },

  _renderLegend() {
    const lg = this._p('#afs-legend');
    if (!lg) return;
    lg.innerHTML = [
      ['#007AFF', LASE.t('无人机航迹（末端红叉 = 被击落）')],
      ['#34C759', LASE.t('步兵航迹（虚线）')],
      ['#FF3B30', LASE.t('防空车 / 交战半径')],
      ['#AF52DE', LASE.t('拦截直升机基地')],
      ['#0A84FF', LASE.t('预警雷达 / 探测半径')],
      ['#FF9500', LASE.t('目标区')],
    ].map(([c, t]) => `<span class="afs-lg"><i style="background:${c}"></i>${t}</span>`).join('');
  },

  // 把 tc 时刻的战场画到任意画布上（屏幕画布与视频导出共用）
  _paint(ctx, cssW, cssH, tc) {
    const d = this._data;
    if (!d || !d.geometry) return;
    const g = d.geometry, W = g.map[0];
    ctx.clearRect(0, 0, cssW, cssH);
    const s = cssW / W;
    const X = x => x * s, Y = y => cssH - y * s;

    // 底色 + 网格
    ctx.fillStyle = '#fbfbfd';
    ctx.fillRect(0, 0, cssW, cssH);
    ctx.strokeStyle = 'rgba(60,60,67,.08)';
    ctx.lineWidth = 1;
    for (let v = 100; v < W; v += 100) {
      ctx.beginPath(); ctx.moveTo(X(v), 0); ctx.lineTo(X(v), cssH); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, Y(v)); ctx.lineTo(cssW, Y(v)); ctx.stroke();
    }

    // 禁飞区
    (g.no_fly_zones || []).forEach(z => {
      ctx.fillStyle = 'rgba(255,59,48,.08)';
      ctx.strokeStyle = 'rgba(255,59,48,.45)';
      ctx.setLineDash([5, 4]);
      ctx.fillRect(X(z.x), Y(z.y + z.h), z.w * s, z.h * s);
      ctx.strokeRect(X(z.x), Y(z.y + z.h), z.w * s, z.h * s);
      ctx.setLineDash([]);
    });

    // 雷达 / 防空 / 目标区
    if (g.radar && g.radar_range) {
      ctx.beginPath();
      ctx.arc(X(g.radar[0]), Y(g.radar[1]), g.radar_range * s, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(10,132,255,.35)';
      ctx.setLineDash([3, 5]); ctx.stroke(); ctx.setLineDash([]);
    }
    (g.aa || []).forEach(p => {
      ctx.beginPath();
      ctx.arc(X(p[0]), Y(p[1]), (g.aa_range || 0) * s, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,59,48,.28)';
      ctx.setLineDash([2, 4]); ctx.stroke(); ctx.setLineDash([]);
    });
    ctx.beginPath();
    ctx.arc(X(g.target[0]), Y(g.target[1]), (g.target_radius || 55) * s, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,149,0,.12)'; ctx.fill();
    ctx.strokeStyle = 'rgba(255,149,0,.7)'; ctx.setLineDash([4, 3]); ctx.stroke(); ctx.setLineDash([]);

    const dot = (x, y, r, fill, stroke) => {
      ctx.beginPath(); ctx.arc(X(x), Y(y), r, 0, Math.PI * 2);
      ctx.fillStyle = fill; ctx.fill();
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; ctx.stroke(); }
    };

    // 航迹（只画到 tc，末端接插值点）
    const tel = d.telemetry || {};
    const palette = ['#007AFF', '#34C759', '#AF52DE', '#5AC8FA', '#FF2D55'];
    const blueNames = Object.keys(tel).filter(n => /^uav/.test(n)).sort();
    blueNames.forEach((name, i) => {
      const pts = (tel[name] || []).filter(p => p[0] <= tc);
      const head = this._headAt(tel[name], tc);
      if (!pts.length && !head) return;
      const col = palette[i % palette.length];
      const line = pts.concat(head ? [[tc, head[0], head[1], 0, 0]] : []);
      if (line.length >= 2) {
        ctx.beginPath();
        line.forEach((p, k) => (k ? ctx.lineTo(X(p[1]), Y(p[2])) : ctx.moveTo(X(p[1]), Y(p[2]))));
        ctx.strokeStyle = col; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke();
      }
      if (line.length) {
        const first = line[0];
        dot(first[1], first[2], 3.2, '#fff', col);
      }
      if (head) {
        const dead = head[2];
        dot(head[0], head[1], dead ? 5 : 4.2, dead ? '#FF3B30' : col, '#fff');
        if (dead) {
          ctx.beginPath();
          ctx.moveTo(X(head[0]) - 4, Y(head[1]) - 4); ctx.lineTo(X(head[0]) + 4, Y(head[1]) + 4);
          ctx.moveTo(X(head[0]) + 4, Y(head[1]) - 4); ctx.lineTo(X(head[0]) - 4, Y(head[1]) + 4);
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6; ctx.stroke();
        }
      }
    });
    // 步兵航迹（虚线）
    Object.keys(tel).filter(n => /^inf/.test(n)).forEach(name => {
      const pts = (tel[name] || []).filter(p => p[0] <= tc);
      const head = this._headAt(tel[name], tc);
      const line = pts.concat(head ? [[tc, head[0], head[1], 0, 0]] : []);
      if (line.length >= 2) {
        ctx.beginPath();
        line.forEach((p, k) => (k ? ctx.lineTo(X(p[1]), Y(p[2])) : ctx.moveTo(X(p[1]), Y(p[2]))));
        ctx.strokeStyle = 'rgba(52,199,89,.55)'; ctx.lineWidth = 1.3;
        ctx.setLineDash([4, 4]); ctx.stroke(); ctx.setLineDash([]);
      }
      if (head) dot(head[0], head[1], 3.4, '#34C759', '#fff');
    });

    // 地面单元与起点
    (g.aa || []).forEach(p => dot(p[0], p[1], 5, '#FF3B30', '#fff'));
    (g.heli || []).forEach(p => dot(p[0], p[1], 5, '#AF52DE', '#fff'));
    if (g.radar) dot(g.radar[0], g.radar[1], 4.5, '#0A84FF', '#fff');
    dot(g.start[0], g.start[1], 4.5, '#1C1C1E', '#fff');

    // 时间水印（视频里也能看到仿真时刻）
    const fs = Math.max(11, Math.round(cssW / 62));
    ctx.font = `${fs}px -apple-system, "Segoe UI", sans-serif`;
    ctx.fillStyle = 'rgba(60,60,67,.62)';
    ctx.textBaseline = 'top';
    ctx.fillText(`AFSIM  t = ${tc.toFixed(2)} s`, 10, 8);
    ctx.fillStyle = 'rgba(60,60,67,.34)';
    ctx.fillText(d.case || '', 10, 8 + fs * 1.35);
  },

  _savePng() {
    if (!this._data || !this._data.ok) { alert(LASE.t('请先运行复核')); return; }
    LASE.downloadCanvas(this._cv, `AFSIM_${this._data.case || 'case'}.png`);
  },

  // 保存视频：把 AFSIM 遥测回放录成 MP4（WebCodecs H.264 + mp4-muxer）
  async _exportVideo() {
    if (!this._data || !this._data.ok) { alert(LASE.t('请先运行复核')); return; }
    if (this._recording) return;
    if (typeof VideoEncoder === 'undefined' || !window.Mp4Muxer || !window.Mp4Muxer.Muxer) {
      alert(LASE.t('当前浏览器不支持 MP4 导出（需要 WebCodecs 与 mp4-muxer）'));
      return;
    }
    this._pause();
    const btn = this._p('#afs-video');
    const saved = this._t;
    this._recording = true;
    if (btn) { btn.disabled = true; btn.textContent = LASE.t('渲染中…'); }
    try {
      await this._encodeMp4(btn);
    } catch (e) {
      alert(LASE.t('视频编码失败：') + (e && e.message ? e.message : e));
    } finally {
      this._recording = false;
      this._t = saved;
      if (btn) { btn.disabled = false; btn.textContent = LASE.t('导出俯视动画'); }
      this._syncPlayer();
      this._draw();
    }
  },

  async _encodeMp4(btn) {
    const d = this._data;
    const SZ = 1024, fps = 24, hold = 0.6;
    const dur = this._dur();
    const total = dur + hold * 2;
    const nFrames = Math.max(2, Math.round(total * fps));
    const cv = document.createElement('canvas');
    cv.width = SZ; cv.height = SZ;
    const ctx = cv.getContext('2d');

    let codec = '';
    for (const c of ['avc1.4D4028', 'avc1.640028', 'avc1.42E01E']) {
      try {
        const s = await VideoEncoder.isConfigSupported({ codec: c, width: SZ, height: SZ, bitrate: 14000000, framerate: fps });
        if (s.supported) { codec = c; break; }
      } catch (e) { /* 逐个回退 */ }
    }
    if (!codec) throw new Error(LASE.t('浏览器不支持 H.264 编码'));

    const muxer = new window.Mp4Muxer.Muxer({
      target: new window.Mp4Muxer.ArrayBufferTarget(),
      video: { codec: 'avc', width: SZ, height: SZ },
      fastStart: 'in-memory',
    });
    let encodeError = null;
    const encoder = new VideoEncoder({
      output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
      error: e => { encodeError = e; },
    });
    encoder.configure({ codec, width: SZ, height: SZ, bitrate: 14000000, framerate: fps });

    for (let i = 0; i < nFrames; i++) {
      if (encodeError) break;
      const tc = Math.max(0, Math.min(dur, i / fps - hold));
      this._paint(ctx, SZ, SZ, tc);
      const frame = new VideoFrame(cv, {
        timestamp: Math.round(i * 1e6 / fps),
        duration: Math.round(1e6 / fps),
      });
      encoder.encode(frame, { keyFrame: i % (fps * 2) === 0 });
      frame.close();
      if (btn && i % 8 === 0) {
        btn.textContent = LASE.t('渲染中…') + ` ${Math.round(i * 100 / nFrames)}%`;
        await new Promise(r => setTimeout(r, 0));
      }
    }
    btn && (btn.textContent = LASE.t('编码中…'));
    try { await encoder.flush(); } catch (e) { /* ignore */ }
    try { encoder.close(); } catch (e) { /* ignore */ }
    muxer.finalize();
    if (encodeError) throw encodeError;

    const blob = new Blob([muxer.target.buffer], { type: 'video/mp4' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AFSIM_${d.case || 'case'}_topview.mp4`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 6000);
  },

  _p(sel) { return this._page ? this._page.querySelector(sel) : null; },
});

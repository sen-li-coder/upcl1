/* 算法对比分析页：最终误差分布 / 排名 / 收敛速度 ERT / 配对 / 热力图 */
LASE.register('compare', {
  _charts: {},

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'compare' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('对比分析参数')}</div>
        <div class="row" id="cmp-cfg"></div>
        <div style="margin-top:10px"><label class="muted">${LASE.t('函数 f')}</label>
          <div style="margin:6px 0" id="cmp-fid-btns"></div><div id="cmp-fids"></div></div>
        <div style="margin-top:10px"><label class="muted">${LASE.t('算法（{0} 个，悬停查看出处）', LASE.meta.hosts.length)}</label>
          <div style="margin:6px 0" id="cmp-host-btns"></div><div id="cmp-hosts"></div></div>
        <div style="margin-top:10px"><label class="muted" id="cmp-arm-lab">${LASE.t('模式')}</label><div id="cmp-arms"></div></div>
        <div style="margin-top:14px">
          <button class="btn primary" id="cmp-run">${LASE.t('加载数据并分析')}</button>
          <span class="hint">${LASE.t('跨算法 / 跨函数对比，全部取自 results/cec/raw')}</span>
        </div>
        <div style="margin-top:10px">
          <button class="btn" id="cmp-ref">${LASE.t('📚 查看算法与测试集说明')}</button>
        </div>
      </div>
      <div class="card"><div class="card-title">${LASE.t('最终误差分布（log10 误差，越低越好）')}</div>
        <div class="chart" id="cmp-dist"></div></div>
      <div class="card"><div class="card-title">${LASE.t('算法排名（平均 log10 误差）')}</div>
        <div class="chart" id="cmp-rank"></div></div>
      <div class="card"><div class="card-title">${LASE.t('收敛速度 ERT（达到目标精度的评估次数）')}</div>
        <div class="chart" id="cmp-ert"></div></div>
      <div class="card"><div class="card-title">${LASE.t('配对对比（纯算法 vs UPCL 增强，对角线下方 = 改善）')}</div>
        <div class="chart" id="cmp-paired"></div></div>
      <div class="card"><div class="card-title">${LASE.t('热力图（算法 × 函数，平均 log10 误差）')}</div>
        <div style="margin:6px 0" id="cmp-heat-arm"></div>
        <div class="chart" id="cmp-heat"></div></div>`;
    c.appendChild(page);
    this.page = page;
    ['dist', 'rank', 'ert', 'paired', 'heat'].forEach(k => {
      this._charts[k] = echarts.init(document.getElementById('cmp-' + k));
    });
    this._buildCfg();
    document.getElementById('cmp-run').onclick = () => this._run();
    document.getElementById('cmp-ref').onclick = () => LASE.navigate('reference');
    LASE.info(document.getElementById('cmp-arm-lab'), LASE.t('模式说明'), () => LASE.armInfoHtml());
    LASE.bindChartSave('cmp-dist', this._charts.dist, LASE.t('最终误差分布'));
    LASE.bindChartSave('cmp-rank', this._charts.rank, LASE.t('算法排名'));
    LASE.bindChartSave('cmp-ert', this._charts.ert, LASE.t('收敛速度ERT'));
    LASE.bindChartSave('cmp-paired', this._charts.paired, LASE.t('配对对比'));
    LASE.bindChartSave('cmp-heat', this._charts.heat, LASE.t('热力图'));
  },

  show() { Object.values(this._charts).forEach(ch => ch && ch.resize()); },

  _buildCfg() {
    const meta = LASE.meta;
    const cfg = document.getElementById('cmp-cfg');
    cfg.innerHTML = '';
    const fillDims = (suite) => {
      this._dimSel.innerHTML = '';
      LASE.dimsOf(suite).forEach(d =>
        this._dimSel.appendChild(LASE.el('option', { value: d, text: 'D' + d })));
      if (this._dimSel.options.length) this._dimSel.value = this._dimSel.options[0].value;
    };
    this._suiteSel = LASE.select(cfg, LASE.t('测试集'), meta.suites, 'cec2022', (v) => {
      fillDims(v);
      this._fids = new Set(meta.suite_fids[v] || []);
      this._renderFids();
    }, () => LASE.suiteInfoHtml(this._suiteSel.value));
    this._dimSel = LASE.select(cfg, LASE.t('维度'), [], '');
    fillDims('cec2022');
    const f = LASE.el('div', { class: 'field' });
    f.appendChild(LASE.el('label', { text: LASE.t('ERT 目标 log10 误差') }));
    const s = LASE.el('select');
    ['-1', '-2', '-4', '-8'].forEach(v =>
      s.appendChild(LASE.el('option', { value: v, text: v })));
    s.value = '-2';
    f.appendChild(s);
    cfg.appendChild(f);
    this._targetSel = s;

    this._fids = new Set(meta.suite_fids['cec2022']);
    this._hosts = new Set(meta.hosts);
    this._arms = new Set(['bare', 'upcl']);

    const hb = document.getElementById('cmp-host-btns');
    hb.innerHTML = '';
    LASE.btn(hb, LASE.t('全选'), '', () => { this._hosts = new Set(meta.hosts); this._renderHosts(); });
    LASE.btn(hb, LASE.t('清空'), '', () => { this._hosts = new Set(); this._renderHosts(); });
    const fb = document.getElementById('cmp-fid-btns');
    fb.innerHTML = '';
    LASE.btn(fb, LASE.t('全选'), '', () => { this._fids = new Set(meta.suite_fids[this._suiteSel.value]); this._renderFids(); });
    LASE.btn(fb, LASE.t('清空'), '', () => { this._fids = new Set(); this._renderFids(); });

    this._renderFids();
    this._renderHosts();
    this._renderArms();
    this._renderHeatArm();
  },

  _renderFids() {
    const fids = LASE.meta.suite_fids[this._suiteSel.value] || [];
    LASE.chipGroup(document.getElementById('cmp-fids'), fids, this._fids);
  },
  _renderHosts() {
    LASE.chipGroup(document.getElementById('cmp-hosts'), LASE.meta.hosts, this._hosts);
  },
  _renderArms() {
    const wrap = document.getElementById('cmp-arms');
    wrap.innerHTML = '';
    const el = LASE.el('div', { class: 'chip-list' });
    ['bare', 'upcl'].forEach(it => {
      const label = it === 'bare' ? LASE.t('纯算法') : LASE.t('UPCL 增强');
      const chip = LASE.el('span', { class: 'chip', text: label });
      if (this._arms.has(it)) chip.classList.add('on');
      chip.onclick = () => {
        chip.classList.toggle('on');
        chip.classList.contains('on') ? this._arms.add(it) : this._arms.delete(it);
      };
      el.appendChild(chip);
    });
    wrap.appendChild(el);
  },
  _renderHeatArm() {
    const wrap = document.getElementById('cmp-heat-arm');
    wrap.innerHTML = '';
    this._heatArm = 'bare';
    const el = LASE.el('div', { class: 'chip-list' });
    ['bare', 'upcl'].forEach(it => {
      const label = it === 'bare' ? LASE.t('纯算法') : LASE.t('UPCL 增强');
      const chip = LASE.el('span', { class: 'chip', text: label });
      if (it === 'bare') chip.classList.add('on');
      chip.onclick = () => {
        this._heatArm = it;
        wrap.querySelectorAll('.chip').forEach(x => x.classList.remove('on'));
        chip.classList.add('on');
        if (this._data) this._renderHeat(this._data);
      };
      el.appendChild(chip);
    });
    wrap.appendChild(el);
  },

  _five(vals) {
    const n = vals.length;
    if (!n) return [0, 0, 0, 0, 0];
    const q = p => {
      const idx = (n - 1) * p;
      const lo = Math.floor(idx), hi = Math.ceil(idx);
      return vals[lo] + (vals[hi] - vals[lo]) * (idx - lo);
    };
    return [vals[0], q(0.25), q(0.5), q(0.75), vals[n - 1]];
  },

  async _run() {
    const meta = LASE.meta;
    const body = {
      suite: this._suiteSel.value,
      dim: parseInt(this._dimSel.value),
      fids: meta.suite_fids[this._suiteSel.value].filter(x => this._fids.has(x)),
      hosts: meta.hosts.filter(h => this._hosts.has(h)),
      arms: ['bare', 'upcl'].filter(a => this._arms.has(a)),
      target: parseFloat(this._targetSel.value),
    };
    if (!body.hosts.length) { alert(LASE.t('请选择算法')); return; }
    if (!body.fids.length) { alert(LASE.t('请选择函数')); return; }
    const data = await LASE.api('/api/compare', { method: 'POST', body });
    if (!data.ok) { alert(data.msg || LASE.t('无数据')); return; }
    this._data = data;
    this._renderDist(data);
    this._renderRank(data);
    this._renderErt(data);
    this._renderPaired(data);
    this._renderHeat(data);
  },

  _renderDist(data) {
    const cats = Object.keys(data.series);
    const box = cats.map(k => this._five(data.series[k]));
    const scat = [];
    cats.forEach((k, i) => data.series[k].forEach((v, j) => {
      const jx = ((j * 2654435761) % 100) / 100 * 0.5 - 0.25;
      scat.push([i + jx, v]);
    }));
    this._charts.dist.setOption({
      toolbox: LASE.saveToolbox(LASE.t('最终误差分布')),
      tooltip: { trigger: 'item' },
      grid: { left: 120, right: 25, top: 30, bottom: 60 },
      xAxis: { type: 'category', data: cats, axisLabel: { rotate: 45, fontSize: 10 } },
      yAxis: { type: 'value', name: LASE.t('log10 误差') },
      series: [
        { name: LASE.t('分布'), type: 'boxplot', data: box, boxWidth: ['20%', '40%'] },
        { name: LASE.t('样本'), type: 'scatter', data: scat, symbolSize: 4,
          itemStyle: { opacity: 0.45 } },
      ],
    }, true);
  },

  _renderRank(data) {
    const rank = [...data.ranking].reverse();
    const labels = rank.map(r => r.label);
    const vals = rank.map(r => +r.mean.toFixed(3));
    this._charts.rank.setOption({
      toolbox: LASE.saveToolbox(LASE.t('算法排名')),
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: 120, right: 50, top: 20, bottom: 40 },
      xAxis: { type: 'value', name: LASE.t('平均 log10 误差') },
      yAxis: { type: 'category', data: labels, axisLabel: { fontSize: 10 } },
      series: [{
        type: 'bar', data: vals,
        itemStyle: { color: p => p.value < 0 ? '#4caf50' : '#f44336' },
        label: { show: true, position: 'right', fontSize: 9 },
      }],
    }, true);
  },

  _renderErt(data) {
    const cats = data.ert.map(e => e.label);
    const box = data.ert.map(e => this._five(e.values.slice().sort((a, b) => a - b)));
    this._charts.ert.setOption({
      toolbox: LASE.saveToolbox(LASE.t('收敛速度ERT')),
      tooltip: { trigger: 'item' },
      grid: { left: 120, right: 25, top: 30, bottom: 60 },
      xAxis: { type: 'category', data: cats, axisLabel: { rotate: 45, fontSize: 10 } },
      yAxis: { type: 'log', name: LASE.t('评估次数 (FES)') },
      series: [{ name: LASE.t('ERT'), type: 'boxplot', data: box, boxWidth: ['30%', '60%'] }],
    }, true);
  },

  _renderPaired(data) {
    const pts = data.paired.map(p => [p.bare, p.upcl]);
    if (!pts.length) { this._charts.paired.clear(); return; }
    let mn = Infinity, mx = -Infinity;
    pts.forEach(p => { mn = Math.min(mn, p[0], p[1]); mx = Math.max(mx, p[0], p[1]); });
    const pad = (mx - mn) * 0.1 || 1;
    this._charts.paired.setOption({
      toolbox: LASE.saveToolbox(LASE.t('配对对比')),
      tooltip: { trigger: 'item' },
      grid: { left: 55, right: 25, top: 30, bottom: 50 },
      xAxis: { type: 'value', name: LASE.t('纯算法 log10 误差'), min: mn - pad, max: mx + pad },
      yAxis: { type: 'value', name: LASE.t('UPCL 增强 log10 误差'), min: mn - pad, max: mx + pad },
      series: [{
        type: 'scatter', data: pts, symbolSize: 5, itemStyle: { opacity: 0.5 },
        markLine: { silent: true, lineStyle: { type: 'dashed', color: '#888' },
          data: [[{ coord: [mn, mn] }, { coord: [mx, mx] }]] },
      }],
    }, true);
  },

  _renderHeat(data) {
    const hm = data.heatmap;
    const z = this._heatArm === 'bare' ? hm.bare_z : hm.upcl_z;
    const cells = [];
    hm.hosts.forEach((h, i) => hm.fids.forEach((f, j) => {
      if (z[i][j] !== null && z[i][j] !== undefined) cells.push([j, i, +z[i][j].toFixed(2)]);
    }));
    if (!cells.length) { this._charts.heat.clear(); return; }
    this._charts.heat.setOption({
      toolbox: LASE.saveToolbox(LASE.t('热力图')),
      tooltip: { position: 'top', formatter: p =>
        `${hm.hosts[p.value[1]]} · F${hm.fids[p.value[0]]} · ${p.value[2]}` },
      grid: { left: 130, right: 25, top: 20, bottom: 60 },
      xAxis: { type: 'category', data: hm.fids.map(f => 'F' + f), axisLabel: { fontSize: 10 } },
      yAxis: { type: 'category', data: hm.hosts, axisLabel: { fontSize: 10 } },
      visualMap: { min: Math.min(...cells.map(c => c[2])),
        max: Math.max(...cells.map(c => c[2])), calculable: true,
        orient: 'horizontal', left: 'center', bottom: 0,
        inRange: { color: ['#4caf50', '#ffeb3b', '#f44336'] } },
      series: [{ type: 'heatmap', data: cells, label: { show: false } }],
    }, true);
  },
});

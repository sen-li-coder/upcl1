/* 研究思路页：把总体框架图（LLM 决策中枢 → 演化计算优化层 → AFSIM 仿真 → 蓝红对抗智能体 → 数据与反馈）
 * 拆成「框架分层 / 数据流 / 研究方案 / 关键技术 / 研究内容 / 创新点 / 目标与指标 / 平台落点」八段原生 DOM，
 * 不依赖位图，中英双语随全站切换。纯静态内容，无后端依赖。 */
LASE.register('research', {
  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'research' });
    page.innerHTML = `
      <div class="card intro-card">
        <div class="card-title">${LASE.t('研究思路')}</div>
        <p style="margin:0 0 8px">${LASE.t('以演化计算为优化引擎、深度强化学习为动态决策执行者、大语言模型为意图理解与方案生成者，在 AFSIM 仿真平台上构建红蓝对抗的策略优化闭环：LLM 把自然语言战术意图变成结构化候选方案，演化计算在候选种群上做全局搜索与约束处理，AFSIM 给出高保真评估信号，蓝红双方智能体在对抗中协同演化，评估数据回流驱动下一轮迭代，直至满足终止条件。')}</p>
        <p class="muted" style="margin:0">${LASE.t('本页把总体框架图拆成八段：先看框架分层的五个模块与流向，再看一次迭代的九步数据流，然后依次是研究方案、关键技术路线、研究内容、预期创新点、目标与评价指标，最后给出每个模块在本平台上的落点（可点击跳转）。')}</p>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('总体框架图')}</div>
        <p class="hint" style="margin:0 0 10px">${LASE.t('总体框架图原图：与下方各段一一对应，点图可看原始尺寸（1080×720）。')}</p>
        <figure class="rf-fig-wrap">
          <a class="rf-fig-link" href="img/research_framework.jpg" target="_blank" rel="noopener">
            <img class="rf-fig" src="img/research_framework.jpg?v=20261017-2"
                 alt="${LASE.t('总体研究框架图')}"
                 data-vector="img/research_framework.svg?v=20261017-3"
                 onerror="if(this.dataset.fallback!=='1'){this.dataset.fallback='1';this.src=this.dataset.vector;}else{this.closest('.rf-fig-wrap').hidden=true;document.getElementById('rf-fig-missing').hidden=false;}">
          </a>
          <figcaption class="rf-fig-cap">${LASE.t('总体研究框架：LLM 推理与决策中枢 → 演化计算优化层 → AFSIM 仿真平台 → 蓝红对抗智能体 → 数据与反馈，闭环迭代至终止条件。')}</figcaption>
        </figure>
        <div class="rf-fig-missing" id="rf-fig-missing" hidden>
          <b>${LASE.t('框架图未就位')}</b>
          <span>${LASE.t('把这张框架图另存为 static/img/research_framework.jpg 后刷新即显示；下方「框架分层」已把图中每个模块与箭头逐条落成文字，不依赖图片也能读全。')}</span>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('一、框架分层：五个模块与三条回路')}</div>
        <p class="hint" style="margin:0 0 12px">${LASE.t('自上而下是「意图 → 搜索 → 仿真 → 决策 → 反馈」，虚线框内是每轮迭代都要走一遍的对抗博弈回路。')}</p>
        <div class="rf-flow">
          <div class="rf-node is-llm">
            <div class="rf-node-head">🧠 ${LASE.t('LLM 推理与决策中枢')}</div>
            <div class="rf-node-sub">${LASE.t('负责「读懂意图、给出方案、解释理由」')}</div>
            <div class="rf-items">
              <div class="rf-item"><b>${LASE.t('战场态势理解')}</b><span class="d">${LASE.t('意图识别 / 任务解析')}</span></div>
              <div class="rf-item"><b>${LASE.t('方案生成与解释')}</b><span class="d">${LASE.t('战术规划 / 语义描述')}</span></div>
              <div class="rf-item"><b>${LASE.t('知识库与经验检索')}</b><span class="d">${LASE.t('规则 / 先验 / 约束')}</span></div>
            </div>
          </div>
          <div class="rf-arrow">${LASE.t('生成候选方案（结构化参数）')}</div>

          <div class="rf-node is-ec">
            <div class="rf-node-head">🧬 ${LASE.t('演化计算优化层')}</div>
            <div class="rf-node-sub">${LASE.t('负责「在候选空间里全局搜索，并把方案压到可行域内」')}</div>
            <div class="rf-tag-row">
              <span class="chip">${LASE.t('选择 Selection')}</span>
              <span class="chip">${LASE.t('变异 Mutation')}</span>
              <span class="chip">${LASE.t('交叉 Crossover')}</span>
              <span class="chip">${LASE.t('更新 Replacement')}</span>
            </div>
            <div class="rf-items">
              <div class="rf-item"><b>${LASE.t('候选方案种群管理')}</b><span class="d">${LASE.t('一个个体 = 一整套可提交给仿真的战术参数；跨代保留精英，避免重复评估高成本方案')}</span></div>
              <div class="rf-item"><b>${LASE.t('方案编码与约束处理')}</b><span class="d">${LASE.t('战术参数编码 · 约束条件（规则 / 可行性）· 适应度评价（仿真指标）')}</span></div>
            </div>
          </div>
          <div class="rf-arrow">${LASE.t('提交方案（蓝 / 红双方策略）⇄ 返回仿真结果（任务完成率 / 损失 / 时间等）')}</div>

          <div class="rf-node is-sim">
            <div class="rf-node-head">🖥 ${LASE.t('AFSIM 仿真平台')}</div>
            <div class="rf-node-sub">${LASE.t('负责「把方案放进想定里跑出可信指标」')}</div>
            <div class="rf-items">
              <div class="rf-item"><b>${LASE.t('战场环境建模')}</b><span class="d">${LASE.t('地形、气象、威胁区与传感器覆盖')}</span></div>
              <div class="rf-item"><b>${LASE.t('兵力装备建模')}</b><span class="d">${LASE.t('平台性能、武器包线、编成与初始态势')}</span></div>
              <div class="rf-item"><b>${LASE.t('规则引擎')}</b><span class="d">${LASE.t('交战判定、指挥关系与行为规则')}</span></div>
              <div class="rf-item"><b>${LASE.t('仿真运行与评估')}</b><span class="d">${LASE.t('多次重复实验，输出指标与事件轨迹')}</span></div>
            </div>
          </div>
          <div class="rf-arrow">${LASE.t('仿真数据（指标 / 轨迹）→ 沉淀为可复用资产')}</div>

          <div class="rf-node is-data">
            <div class="rf-node-head">🗄 ${LASE.t('数据与反馈')}</div>
            <div class="rf-node-sub">${LASE.t('负责「把一次仿真的花费变成下一次搜索的先验」')}</div>
            <div class="rf-tag-row">
              <span class="chip">${LASE.t('仿真数据')}</span>
              <span class="chip">${LASE.t('战术方案库')}</span>
              <span class="chip">${LASE.t('策略演化轨迹')}</span>
              <span class="chip">${LASE.t('性能评估结果')}</span>
            </div>
          </div>

          <div class="rf-loop">
            <div class="rf-loop-head">↻ ${LASE.t('蓝红对抗智能体：对抗博弈、策略迭代（协同进化）')}</div>
            <div class="rf-duo">
              <div class="rf-sub t">
                <div class="rf-sub-title">🔵 ${LASE.t('蓝方智能体（进攻）')}</div>
                <ul class="rf-steps" style="margin-top:6px;padding-left:16px">
                  <li>${LASE.t('基于 LLM 的高层意图规划')}</li>
                  <li>${LASE.t('基于 DRL 的动态决策执行')}</li>
                </ul>
                <div class="rf-tag-row">
                  <span class="chip">${LASE.t('任务分配')}</span>
                  <span class="chip">${LASE.t('路径规划')}</span>
                  <span class="chip">${LASE.t('火力协同')}</span>
                  <span class="chip">${LASE.t('战术调整')}</span>
                </div>
              </div>
              <div class="rf-sub d">
                <div class="rf-sub-title">🔴 ${LASE.t('红方智能体（防御）')}</div>
                <ul class="rf-steps" style="margin-top:6px;padding-left:16px">
                  <li>${LASE.t('基于 LLM 的防御策略生成')}</li>
                  <li>${LASE.t('基于 DRL 的实时响应决策')}</li>
                </ul>
                <div class="rf-tag-row">
                  <span class="chip">${LASE.t('防御部署')}</span>
                  <span class="chip">${LASE.t('资源调度')}</span>
                  <span class="chip">${LASE.t('威胁识别')}</span>
                  <span class="chip">${LASE.t('反制措施')}</span>
                </div>
              </div>
            </div>
            <div class="rf-arrow" style="border-top:1px dashed var(--separator); padding-top:8px">${LASE.t('迭代优化，直至满足终止条件（预算耗尽 / 收敛 / 达标即停）')}</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('二、数据流：一次迭代的九个步骤')}</div>
        <ol class="rf-steps">
          <li><b>${LASE.t('意图解析')}</b>：${LASE.t('LLM 读取战场态势与任务指令，输出结构化战术意图——目标、约束、可用兵力与时间窗。')}</li>
          <li><b>${LASE.t('候选生成')}</b>：${LASE.t('LLM 依据知识库与经验检索给出方案骨架，编码成可搜索的参数向量（不是自然语言句子）。')}</li>
          <li><b>${LASE.t('种群续代')}</b>：${LASE.t('演化层维护候选方案种群，复用上一轮的精英个体，避免高成本方案被重评。')}</li>
          <li><b>${LASE.t('演化算子')}</b>：${LASE.t('选择、变异、交叉、更新在参数空间做全局搜索，越界与违反规则的个体按约束修复。')}</li>
          <li><b>${LASE.t('方案提交')}</b>：${LASE.t('把蓝 / 红双方的策略参数按想定装载进 AFSIM，形成同场对抗的两个决策体。')}</li>
          <li><b>${LASE.t('仿真评估')}</b>：${LASE.t('AFSIM 跑完想定，返回任务完成率、红蓝损失、耗时等指标与事件轨迹。')}</li>
          <li><b>${LASE.t('适应度回填')}</b>：${LASE.t('仿真指标合成适应度（可加惩罚项），驱动种群选择与精英保留。')}</li>
          <li><b>${LASE.t('智能体执行')}</b>：${LASE.t('蓝红智能体用 LLM 做高层意图规划、用 DRL 做实时动作决策，在仿真中完成对抗。')}</li>
          <li><b>${LASE.t('收敛判断与回流')}</b>：${LASE.t('未达终止条件则带数据与反馈回到演化层；达标则输出策略方案库与评估报告。')}</li>
        </ol>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('三、研究方案')}</div>
        <div class="grid-2" style="gap:12px">
          <div class="rf-col">
            <div class="rf-col-h">1 ${LASE.t('总体思路')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.75">${LASE.t('以演化计算为优化引擎，结合深度强化学习与大语言模型，构建蓝红对抗智能体协同演化的策略优化框架，并在 AFSIM 仿真平台上进行验证，提升复杂战场环境下的作战效能。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">2 ${LASE.t('核心思路')}</div>
            <ul class="rf-steps" style="margin-top:8px;padding-left:16px">
              <li>${LASE.t('LLM 负责意图理解与方案生成')}</li>
              <li>${LASE.t('演化计算负责全局搜索与策略优化')}</li>
              <li>${LASE.t('DRL 负责动态决策与策略执行')}</li>
              <li>${LASE.t('AFSIM 提供高保真仿真环境与评价反馈')}</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('四、关键技术路线')}</div>
        <div class="rf-cols">
          <div class="rf-col">
            <div class="rf-col-h">① ${LASE.t('LLM 意图理解与战术生成')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('自然语言任务 → 结构化方案：把指挥员意图、战场态势与规则约束一起塞进提示，产出可被搜索与装载的战术参数。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">② ${LASE.t('演化计算种群优化')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('DE / GA 等算子 + 约束处理 + 适应度评价：面向高成本评估做小种群、少代数、精英复用的预算分配。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">③ ${LASE.t('DRL 多智能体对抗学习')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('策略执行 + 动态决策：在仿真回合内做实时动作选择，与演化层形成「外层搜参数、内层搜动作」的双层结构。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">④ ${LASE.t('AFSIM 仿真验证')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('战场环境 + 结果反馈：统一想定、统一指标，保证不同策略在同一把尺子上比较。')}</p>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('五、研究内容')}</div>
        <div class="rf-cols">
          <div class="rf-col">
            <div class="rf-col-h">1 ${LASE.t('架构设计与集成实现')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('构建 LLM + 演化计算 + DRL + AFSIM 的协同框架，完成各模块的接口设计与系统集成。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">2 ${LASE.t('演化算法优化策略设计')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('研究适用于高成本仿真的演化机制（如变异策略、自适应参数、约束处理），并与任务场景结合。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">3 ${LASE.t('对抗策略协同演化机制')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('设计蓝红双方的协同演化与对抗学习机制，实现策略的动态更新与适配。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">4 ${LASE.t('仿真验证与性能分析')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('在 AFSIM 中构建典型作战场景，开展对比实验，从任务完成率、损失、收敛速度、稳定性等方面进行评估。')}</p>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('六、预期创新点')}</div>
        <div class="rf-cols">
          <div class="rf-col">
            <div class="rf-col-h">① ${LASE.t('交叉融合机制')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('提出演化计算与 LLM、DRL 的协同优化框架，实现对复杂战场环境的全局搜索与智能决策。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">② ${LASE.t('适应性演化策略')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('设计面向昂贵仿真环境的优化机制，兼顾搜索效率与策略多样性。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">③ ${LASE.t('红蓝协同演化模型')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('构建双向智能体的协同演化机制，提升对抗环境下的策略适应性与鲁棒性。')}</p>
          </div>
          <div class="rf-col">
            <div class="rf-col-h">④ ${LASE.t('真实场景验证')}</div>
            <p style="margin:8px 0 0; font-size:12.5px; line-height:1.7">${LASE.t('基于 AFSIM 进行多场景仿真验证，证明方法在复杂战场环境下的有效性与可行性。')}</p>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('七、研究目标与评价指标')}</div>
        <div class="rf-target">
          <div class="rf-target-row"><b>${LASE.t('研究目标')}</b><span>${LASE.t('提升红蓝对抗中的策略生成与优化能力，实现高效、鲁棒、可解释的作战决策。')}</span></div>
          <div class="rf-target-row"><b>${LASE.t('评价指标')}</b>
            <span class="chip">${LASE.t('任务完成率')}</span>
            <span class="chip">${LASE.t('红蓝损失')}</span>
            <span class="chip">${LASE.t('收敛速度')}</span>
            <span class="chip">${LASE.t('策略多样性')}</span>
            <span class="chip">${LASE.t('泛化能力')}</span>
          </div>
          <p class="muted" style="margin:2px 0 0; font-size:12px">${LASE.t('前三项衡量「打得好不好」，后两项衡量「换场景还灵不灵」——策略多样性防止所有个体塌缩到同一招，泛化能力用留出想定检验。')}</p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('八、平台落点：框架各层在本平台的位置')}</div>
        <p class="hint" style="margin:0 0 10px">${LASE.t('这些页面已经是框架对应层的可运行版本，点按钮直接跳过去看数据。')}</p>
        <div class="rf-map">
          <div class="rf-map-row">
            <span>🧠 ${LASE.t('LLM 推理与决策中枢')} → ${LASE.t('论文及参考资料（LLM 线）与算法接入（黑盒插件口）')}</span>
            <button class="btn" onclick="LASE.navigate('refs')">${LASE.t('论文及参考资料 →')}</button>
          </div>
          <div class="rf-map-row">
            <span>🧬 ${LASE.t('演化计算优化层')} → ${LASE.t('算法与测试集、收敛曲线、机制分析（UPCL 干预率与修正量）')}</span>
            <button class="btn" onclick="LASE.navigate('convergence')">${LASE.t('收敛曲线 →')}</button>
          </div>
          <div class="rf-map-row">
            <span>🖥 ${LASE.t('AFSIM 仿真平台 / 蓝红对抗智能体')} → ${LASE.t('UAV 仿真：突防与拦截、集群突防对抗')}</span>
            <button class="btn" onclick="LASE.navigate('uav')">${LASE.t('UAV 仿真 →')}</button>
          </div>
          <div class="rf-map-row">
            <span>🗄 ${LASE.t('数据与反馈')} → ${LASE.t('数据存档、地形图、本体与知识图谱')}</span>
            <button class="btn" onclick="LASE.navigate('archive')">${LASE.t('数据存档 →')}</button>
          </div>
        </div>
      </div>`;
    c.appendChild(page);
    this.page = page;
  },
});

/* 前端框架：导航、页面注册、API 封装、任务轮询 */
(function () {
  const LASE = {
    pages: {},
    meta: null,
    uavMeta: null,
    current: null,
    user: null,            // 当前登录用户 { username, role }
    offline: false,        // 后端不可达（网络层失败）。必须与「未登录」严格区分

    // ================= 面向使用者的说明数据 =================
    // UPCL 机制说明：让使用者明确「开启 UPCL」到底在做什么。
    upclIntro: 'UPCL 是加在进化算法上的一层「机制探针」：每一代变异后，它先用 5 个描述子'
      + '（步长比 ρ、方向对齐 θ、精英距离 η、拥挤度 κ、新颖度 ν）实时刻画搜索状态，'
      + '再在检测到停滞时对候选解做一次「放大步长」的修正，帮助算法跳出局部最优。'
      + '开启后系统会同时运行「纯算法」与「纯算法 + UPCL」两种模式做对照，用来量化 UPCL 带来的改进。',

    // 29 个差分进化（DE）变体：d = 一句话机制，abs = 摘要（大致做了什么），r = 出处（作者与年份）。
    hostInfo: {
      'DE/rand/1': { d: '经典差分进化：随机选三个个体，用缩放差分向量做变异。', r: 'Storn & Price, 1997', abs: '最基础的 DE 变体：变异向量 v = x_r1 + F·(x_r2 − x_r3)，随机抽取三个互异个体，再配合二项交叉与一对一的贪心选择。结构最简单、探索能力强，常作为对比基线。' },
      'DE/best/1': { d: '以当前最优个体为基向量的经典 DE，收敛快但容易早熟。', r: 'Storn & Price, 1997', abs: '用当前种群最优个体 x_best 作为基向量，收敛速度快，但在多峰问题上容易早熟、陷入局部最优。' },
      'DE/rand/2': { d: '使用两对差分向量的经典 DE，探索能力更强。', r: 'Storn & Price, 1997', abs: '使用两对差分向量的加权和（x_r1 + F·(x_r2 − x_r3) + F·(x_r4 − x_r5)），扰动更强、探索更足，但收敛相对更慢。' },
      'DE/current-to-best/1': { d: '个体同时向最优解和随机方向靠拢的经典 DE。', r: 'Storn & Price, 1997', abs: '个体同时向当前最优解与随机方向靠拢，在开采与探索之间取得折中。' },
      'DE/current-to-rand/1': { d: '带随机旋转的经典 DE，支持旋转不变。', r: 'Storn & Price, 1997', abs: '在差分方向基础上叠加随机旋转，具备旋转不变性，更适合解空间被旋转的基准函数。' },
      'DE/rand/1/either-or': { d: 'either-or 变异：在 rand/1 与其缩放变体间二选一。', r: 'Price, Storn & Lampinen, 2005', abs: '在 rand/1 变异与其带缩放差分的变体之间二选一，增加算子的多样性。' },
      'jDE': { d: '每个个体自适应缩放因子 F 与交叉率 CR。', r: 'Brest et al., 2006', abs: '把缩放因子 F 与交叉率 CR 编码进每个个体，并以概率 τ 在每代自更新，无需外部人工整定参数。' },
      'SaNSDE': { d: '自适应邻域搜索 DE，F 用高斯/柯西混合采样。', r: 'Yang, Tang & Yao, 2008', abs: '自适应邻域搜索 DE：F 由高斯/柯西混合分布采样，策略概率与邻域半径在运行中自适应调整。' },
      'JADE': { d: '外部存档 + 自适应均值 μF/μCR。', r: 'Zhang & Sanderson, 2009', abs: '引入外部存档与 current-to-pbest 变异，F 与 CR 分别用 Lehmer/算术均值自适应更新，在 CEC 基准上表现优异。' },
      'SHADE': { d: '用成功历史记忆自适应 F/CR。', r: 'Tanabe & Fukunaga, 2013', abs: '用成功历史记忆 H 存储多组均值 M_F、M_CR，按当前代数随机取用生成参数，是 JADE 的成功历史扩展。' },
      'CoBiDE': { d: '协方差双线性交叉的 DE。', r: 'Wang et al., 2014', abs: '协方差双线性交叉 DE，利用种群协方差结构引导交叉操作，增强在旋转问题上的性能。' },
      'SaDE': { d: '多策略池概率自学习 DE。', r: 'Qin & Suganthan, 2005', abs: '维护多个变异策略池，按各策略近期成功率自适应选择策略，同时自适应 F 与 CR。' },
      'EPSDE': { d: 'F/CR/策略三元组集合自适应。', r: 'Mallipeddi et al., 2011', abs: '每个个体携带一组 (F, CR, 策略) 三元组，成功则保留、失败则重抽，实现三元组集合的自适应演化。' },
      'CoDE': { d: '三种试验向量组合生成的 DE。', r: 'Wang, Cai & Zhang, 2011', abs: '预先定义三种参数/策略组合，为每个目标生成三个试验向量并取最优，从而简化参数调优。' },
      'MPEDE': { d: '多种群策略集成的 DE。', r: 'Wu et al., 2016', abs: '多种群 DE：多个子种群使用不同变异策略并行搜索，并按贡献动态重分配计算资源。' },
      'L-SHADE': { d: 'SHADE + 线性种群缩减。', r: 'Tanabe & Fukunaga, 2014', abs: '在 SHADE 上叠加线性种群规模缩减（LPSR），随评估预算线性减少个体数，是 CEC2014 冠军的核心机制。' },
      'jSO': { d: '改进 SHADE，CEC2017 亚军。', r: 'Brest et al., 2017', abs: '对 SHADE 的 F/CR 随代数做有界调整，并引入新的种群缩减规则，获 CEC2017 单目标竞赛亚军。' },
      'L-SHADE-RSP': { d: 'SHADE + 秩选择压力。', r: 'Stanovov et al., 2018', abs: '在 SHADE 的选择环节加入基于秩的选择压力（RSP），增强精英个体的影响力。' },
      'NL-SHADE-RSP': { d: '非线性种群缩减 + 秩选择压力。', r: 'Stanovov & Semenkin, 2022', abs: '将线性种群缩减改为非线性缩减，并保留秩选择压力，是近年表现最强的 SHADE 变体之一。' },
      'MadDE': { d: '多策略自适应 DE，CEC2021 冠军。', r: 'Biswas et al., 2021', abs: '多策略自适应 DE，融合多种变异策略与自适应参数控制，获 CEC2021 单目标竞赛冠军。' },
      'jDE100': { d: '百维自适应 DE，CEC2019 冠军。', r: 'Brest et al., 2019', abs: '针对 100 维大规模优化设计的自适应 DE 变体，获 CEC2019 单目标竞赛冠军。' },
      'j2020': { d: 'jDE 2020 改进版。', r: 'Brest et al., 2020', abs: 'jDE 的 2020 改进版，进一步调整 F/CR 自适应机制与边界处理策略。' },
      'DISH': { d: '距离成功历史自适应。', r: 'Viktorin et al., 2019', abs: '距离成功历史（Distance-based parameter adaptation）自适应 DE，用个体间距离加权的成功信息更新 F/CR。' },
      'DISK': { d: '秩驱动的参数自适应。', r: 'Viktorin et al., 2020', abs: '基于秩的参数自适应 DE，用精英/失败个体的秩信息驱动 F/CR 的更新。' },
      'LSHADE-cnEpSin': { d: '正弦分量集成的 F，CEC2017 冠军。', r: 'Awad et al., 2017', abs: '在 L-SHADE 上集成正弦/余弦分量调整 F，并在不同阶段切换参数策略，获 CEC2017 单目标竞赛冠军。' },
      'SinDE': { d: '纯正弦驱动的 F 与 CR。', r: 'Draa et al., 2019', abs: '用正弦函数直接驱动 F 与 CR 的生成，结构极简、实现轻量。' },
      'IMODE': { d: '多算子自适应，CEC2020 冠军。', r: 'Sallam et al., 2020', abs: '多算子差分进化，融合多种变异/交叉算子并按成功率自适应，获 CEC2020 单目标竞赛冠军。' },
      'PaDE': { d: '个体级交叉率自适应。', r: 'Meng, Pan & Tseng, 2019', abs: '为每个个体独立自适应交叉率 CR，降低对参数的敏感度。' },
      'SHADE-ILS': { d: 'L-SHADE + 迭代局部搜索。', r: 'Molina, LaTorre & Herrera, 2018', abs: 'L-SHADE 与迭代局部搜索（ILS）结合，在停滞时用 ILS 精修，提升混合/复合函数上的精度。' },
    },

    // 测试集（CEC 基准）：名称、函数构成与官方说明链接。
    suiteInfo: {
      cec2013: { name: 'CEC 2013 单目标实参优化基准', desc: '28 个基准函数：单峰、多峰、复合与旋转函数。', url: 'https://www.ntu.edu.sg/home/epnsugan/index_files/CEC2013/CEC2013.htm' },
      cec2014: { name: 'CEC 2014 单目标实参优化基准', desc: '30 个基准函数：旋转/平移/复合函数。', url: 'https://www.ntu.edu.sg/home/epnsugan/index_files/CEC2014/CEC2014.htm' },
      cec2015: { name: 'CEC 2015 单目标实参数值优化基准', desc: '15 个基准函数（含大规模与复合函数）。', url: 'https://www.ntu.edu.sg/home/epnsugan/index_files/CEC2015/CEC2015.htm' },
      cec2017: { name: 'CEC 2017 单目标实参数值优化基准', desc: '29 个基准函数（10/30/50/100 维），含混合与复合函数。', url: 'https://www.ntu.edu.sg/home/epnsugan/index_files/CEC2017/CEC2017.htm' },
      cec2022: { name: 'CEC 2022 单目标无约束基准', desc: '12 个基准函数（10/20 维），含单峰、多峰、混合与复合函数。', url: 'https://www.ntu.edu.sg/home/epnsugan/index_files/CEC2022/CEC2022.htm' },
    },

    // UAV 场景说明
    scenarioInfo: {
      intercept: { name: '无人机突防与拦截（三维山地）', desc: '我方无人机在三维山地中突防，规避规则/强化学习拦截者、雷达与防空车，抵达军事基地。' },
      swarm: { name: '无人机集群突防对抗（三维山地）', desc: '无人机集群突防对抗（2020 华为杯研究生数学建模 D 题）：无人机集群突防，红方多集群协同拦截。' },
    },

    // UAV 对手难度说明
    difficultyInfo: {
      '无对手（纯路径规划）': { d: '无拦截者，纯路径规划问题，目标是最快安全到达。' },
      '规则拦截（默认）': { d: '拦截者按「追击最近目标」的规则运动，确定性可复现。' },
      '强化学习·弱': { d: '红方由强化学习策略控制（弱训练强度）。' },
      '强化学习·强': { d: '红方由强化学习策略控制（强训练强度）。' },
      '强化学习·对抗': { d: '红方由强化学习策略控制，随我方策略对抗演化。' },
    },

    // UAV DRL 对手策略优化器说明
    drlInfo: {
      '进化策略（ES）': { d: '进化策略（OpenES）：对策略参数加高斯噪声采样，按回报差估计梯度。' },
      '交叉熵方法（CEM）': { d: '交叉熵方法：采样一批参数，取精英子集更新均值与方差。' },
      '数值梯度（SPSA）': { d: '数值梯度（SPSA）：用有限差分估计梯度，无需可微动力学。' },
    },

    _navDefs: [
      ['dashboard', '🏠', '主界面'],
      ['reference', '📚', '算法与测试集'],
      ['refs', '📄', '论文及参考资料'],
      ['research', '🧭', '研究思路'],
      ['experiment', '▶', '实验运行'],
      ['convergence', '📈', '收敛曲线'],
      ['compare', '⚖️', '算法对比'],
      ['mechanism', '🧬', '机制分析'],
      ['landscape', '🗺', '地形图'],
      ['archive', '📦', '数据存档'],
      ['ontology', '🕸', '本体与知识图谱'],
      ['uav', '🛩', 'UAV 仿真'],
      ['afsim', '🛰', 'AFSIM 复核'],
      ['wizard', '🧩', '算法接入'],
      ['users', '👥', '用户管理'],
    ],

    // 侧边栏分组（只影响呈现归类与顺序，_navDefs 仍是唯一数据源）
    _navGroups: [
      { title: '总览', items: ['dashboard', 'reference', 'refs', 'research'] },
      { title: '实验', items: ['experiment', 'wizard'] },
      { title: '分析', items: ['convergence', 'compare', 'mechanism', 'landscape', 'archive', 'ontology'] },
      { title: '应用', items: ['uav', 'afsim'] },
      { title: '系统', items: ['users'] },
    ],

    // 每个页面的 Large Title 副标题（iOS 大标题惯例：标题 + 一句说明）
    _navSub: {
      dashboard: '平台概览与实验进度',
      reference: '宿主算法与测试集的元信息',
      refs: '演化计算 / 强化学习 / 大模型的代表文献',
      research: '框架五层、数据流与创新点',
      experiment: '配置并运行批量实验',
      convergence: '不同算法的收敛过程对比',
      compare: '多算法多指标横向对比',
      mechanism: 'UPCL 干预率与修正量分析',
      landscape: '适应度地形二维 / 三维可视化',
      archive: '实验结果与图表存档管理',
      ontology: '红方优化模型的本体与知识图谱',
      uav: '无人机突防与拦截 / 集群突防对抗仿真',
      afsim: '把存档解送进真实 AFSIM 2.9 引擎复核',
      wizard: '接入你自己的算法插件',
      users: '账号与角色管理',
    },

    // ================= 国际化（中/英一键切换） =================
    // 语言存 localStorage；t() 以「中文原文」为 key，英文时查 I18N_EN，未命中回退原文。
    // 字典集中维护在 js/i18n.js（window.LASE_I18N_EN），新增翻译只改那里。
    I18N_EN: window.LASE_I18N_EN || {},

    lang() {
      return localStorage.getItem('lase_lang') || 'zh';
    },

    t(s, ...args) {
      let out = s;
      if (this.lang() === 'en' && this.I18N_EN[s] !== undefined) out = this.I18N_EN[s];
      args.forEach((a, i) => { out = out.split('{' + i + '}').join(String(a)); });
      return out;
    },

    toggleLang() {
      const next = this.lang() === 'zh' ? 'en' : 'zh';
      localStorage.setItem('lase_lang', next);
      location.reload();
    },

    _applyI18n() {
      document.querySelectorAll('[data-i18n]').forEach(el => {
        el.textContent = this.t(el.getAttribute('data-i18n'));
      });
    },

    _renderLangBtn(bar) {
      const btn = this.el('button', { class: 'btn lang-btn' });
      btn.textContent = this.lang() === 'zh' ? 'EN' : '中文';
      btn.title = this.t('切换语言');
      btn.onclick = () => this.toggleLang();
      bar.appendChild(btn);
      return btn;
    },

    register(name, page) { this.pages[name] = page; },

    token() {
      return localStorage.getItem('lase_token') || '';
    },

    authHeaders(extra = {}) {
      const h = Object.assign({}, extra);
      if (this.token()) h['Authorization'] = 'Bearer ' + this.token();
      return h;
    },

    async api(path, opts = {}) {
      const init = { method: opts.method || 'GET', headers: {} };
      if (opts.body !== undefined) {
        if (typeof FormData !== 'undefined' && opts.body instanceof FormData) {
          // 文件上传：不手动设 Content-Type，让浏览器自动带 multipart boundary
          init.body = opts.body;
        } else {
          init.headers = { 'Content-Type': 'application/json' };
          init.body = JSON.stringify(opts.body);
        }
      }
      if (this.token()) init.headers['Authorization'] = 'Bearer ' + this.token();
      let res;
      try {
        res = await fetch(path, init);
      } catch (e) {
        // 只有"连不上后端"才会走到这里（fetch 抛 TypeError）。
        // 这与"登录失效"是两回事，绝不能顺手清 token。
        this._setOffline(true);
        const err = new Error(this.t('无法连接后端服务'));
        err.offline = true;
        throw err;
      }
      // 后端有响应（哪怕是 4xx/5xx）就说明连接是通的
      this._setOffline(false);
      if (opts.raw) return res;
      if (res.status === 401 && path !== '/api/auth/me' && path !== '/api/auth/login') {
        // 会话失效：回到登录页
        this._clearAuth();
        this._showLogin();
        return { _unauthorized: true };
      }
      return res.json();
    },

    async boot() {
      document.addEventListener('click', () => this._closePop());
      this._applyI18n();
      this._buildLogin();
      // 鉴权门禁：先校验 token，再加载数据、初始化页面
      const st = await this._initAuth();
      // 后端不可达 ≠ 未登录：明确告知 + 可重试，而不是把用户丢到登录页装死
      if (st === 'offline') { this._showOffline(); return; }
      if (!this.user) { this._showLogin(); return; }
      this._buildNav();       // 拿到角色后再构建导航（admin 多出「用户管理」）
      await this._loadData();
      if (this.offline) { this._showOffline(); return; }
    },

    _buildNav() {
      const nav = document.getElementById('nav');
      nav.innerHTML = '';
      // 角色过滤：admin 才可见「用户管理」
      const allowed = new Set(this._navDefs
        .filter(([name]) => name !== 'users' || (this.user && this.user.role === 'admin'))
        .map(([name]) => name));
      const defMap = {};
      this._navDefs.forEach(d => { defMap[d[0]] = d; });
      // 按分组渲染；未列入分组的项兜底追加到最后
      const groups = this._navGroups.map(g => ({ title: g.title, items: g.items.slice() }));
      const listed = new Set(this._navGroups.reduce((a, g) => a.concat(g.items), []));
      const rest = this._navDefs.map(d => d[0]).filter(n => allowed.has(n) && !listed.has(n));
      if (rest.length) groups.push({ title: '', items: rest });
      groups.forEach(g => {
        const items = g.items.filter(n => allowed.has(n));
        if (!items.length) return;
        const sec = document.createElement('div');
        sec.className = 'nav-section';
        if (g.title) {
          const h = document.createElement('div');
          h.className = 'nav-section-title';
          h.textContent = this.t(g.title);
          sec.appendChild(h);
        }
        items.forEach(name => {
          const d = document.createElement('div');
          d.className = 'nav-item';
          d.dataset.page = name;
          d.innerHTML = `<span class="ico">${defMap[name][1]}</span><span class="label">${this.t(defMap[name][2])}</span>`;
          d.onclick = () => this.navigate(name);
          sec.appendChild(d);
        });
        nav.appendChild(sec);
      });
    },

    // 页面 Large Title：把大标题插到页面最前面（幂等，切换时只更新文本）
    _ensurePageHead(name) {
      const page = document.querySelector('.page[data-page="' + name + '"]');
      if (!page) return;
      if (page.querySelector(':scope > .hero')) return;   // 首页 hero 已承担大标题，避免重复
      let head = page.querySelector(':scope > .page-head');
      if (!head) {
        head = document.createElement('div');
        head.className = 'page-head';
        page.insertBefore(head, page.firstChild);
      }
      const def = this._navDefs.find(d => d[0] === name);
      let h1 = head.querySelector('h1');
      if (!h1) { h1 = document.createElement('h1'); head.appendChild(h1); }
      h1.textContent = def ? this.t(def[2]) : '';
      const sub = this._navSub[name];
      let p = head.querySelector('p');
      if (sub) {
        if (!p) { p = document.createElement('p'); head.appendChild(p); }
        p.textContent = this.t(sub);
      } else if (p) {
        p.remove();
      }
    },

    // 返回 'ok' | 'anonymous' | 'offline'
    // 关键：只有后端"明确否认"这个 token 才算登录失效。连不上后端时必须保留 token，
    // 否则后端一挂就被误判成会话过期、token 被清掉，服务恢复后还得重新登录；
    // 更糟的是 boot() 会因此跳登录页直接 return，导航/页面全都不构建 → 界面看着像"失效"。
    async _initAuth() {
      const token = this.token();
      if (!token) { this.user = null; return 'anonymous'; }
      try {
        const me = await this.api('/api/auth/me');
        if (me && me.username) {
          this.user = { username: me.username, role: me.role };
          return 'ok';
        }
        this._clearAuth();
        return 'anonymous';
      } catch (e) {
        this.user = null;
        if (e && e.offline) return 'offline';
        this._clearAuth();
        return 'anonymous';
      }
    },

    _clearAuth() {
      localStorage.removeItem('lase_token');
      this.user = null;
      this._renderUserBar();
    },

    async _loadData() {
      // 加载元数据
      try {
        this.meta = await this.api('/api/meta');
        this.uavMeta = await this.api('/api/uav/meta');
        this._setConn(true);
      } catch (e) {
        this._setConn(false);
        // 后端不可达：别再往下渲染一个"空壳页面"骗自己，交给 boot() 显示离线页
        if (this.offline) return;
      }
      // 合并插件算法的说明文字（黑盒插件无硬编码 hostInfo，用插件描述动态补充）
      if (this.meta && this.meta.plugins) {
        for (const name in this.meta.plugins) {
          if (!this.hostInfo[name]) this.hostInfo[name] = this.meta.plugins[name];
        }
      }
      // 初始化所有页面
      for (const name in this.pages) {
        try { this.pages[name].init && this.pages[name].init(); }
        catch (e) {
          // 只 console.error 会让"页面看得见、按钮全是死的"且界面毫无提示，
          // 排查成本极高（本次故障就被这个静默吞异常掩盖了），故必须同时给出可见告警。
          console.error('init', name, e);
          this._pageInitError(name, e);
        }
      }
      // 自检：每个导航页都必须挂到 #content 上，否则切过去就是白屏。
      // 隐蔽性很高（afsim 页曾用 c.innerHTML='' 把先初始化的四页一起删掉且不报错），故留一条日志。
      const mounted = new Set(Array.from(document.querySelectorAll('#content > .page')).map(e => e.dataset.page));
      const missing = this._navDefs.map(d => d[0]).filter(n => !mounted.has(n));
      if (missing.length) console.error('页面未挂载，切换后将白屏：', missing);

      this._renderUserBar();
      this.navigate(this._navDefs[0][0]);
    },

    // 某个页面 init() 失败时，在其容器内插入一条可见告警（随该页面一起显示）
    _pageInitError(name, e) {
      const def = this._navDefs.find(d => d[0] === name);
      const label = def ? this.t(def[2]) : name;
      const box = this.el('div', { class: 'page-init-err' });
      box.innerHTML = '<b>' + this._esc(label) + '：' + this.t('页面初始化失败') + '</b>'
        + '<div class="mono">' + this._esc((e && e.message) || String(e)) + '</div>'
        + '<div>' + this.t('本页按钮可能无法使用，请把上面的错误信息反馈给开发者。') + '</div>';
      const host = (this.pages[name] && this.pages[name].page) || document.getElementById('content');
      if (host && host.appendChild) host.appendChild(box);
    },

    navigate(name) {
      this.current = name;
      document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.toggle('active', el.dataset.page === name);
      });
      document.querySelectorAll('.page').forEach(el => {
        el.classList.toggle('active', el.dataset.page === name);
      });
      const def = this._navDefs.find(d => d[0] === name);
      document.getElementById('page-title').textContent = def ? this.t(def[2]) : '';
      this._ensurePageHead(name);
      this._renderUserBar();
      const p = this.pages[name];
      if (p && p.show) { try { p.show(); } catch (e) { console.error(e); } }
    },

    // ================= 登录 / 登出 / 用户栏 =================
    _buildLogin() {
      if (document.getElementById('login-overlay')) return;
      const ov = this.el('div', { id: 'login-overlay', class: 'login-overlay' });
      ov.innerHTML = `
        <form class="login-card" id="login-card">
          <div class="login-logo">${this.t('进化算法平台')}</div>
          <div class="login-sub">${this.t('差分进化 · 机制研究 · 多用户隔离')}</div>
          <label class="login-field">
            <span>${this.t('用户名')}</span>
            <input type="text" id="login-user" autocomplete="username" placeholder="${this.t('请输入用户名')}">
          </label>
          <label class="login-field">
            <span>${this.t('密码')}</span>
            <input type="password" id="login-pass" autocomplete="current-password" placeholder="${this.t('请输入密码')}">
          </label>
          <div class="login-err" id="login-err"></div>
          <button type="submit" class="btn primary login-btn" id="login-btn">${this.t('登 录')}</button>
          <div class="login-tip">${this.t('默认管理员：admin / admin123（登录后请尽快修改）')}</div>
          <button type="button" class="btn" id="login-lang-btn">${this.lang() === 'zh' ? 'English' : '中文'}</button>
        </form>`;
      document.body.appendChild(ov);
      const card = document.getElementById('login-card');
      card.addEventListener('submit', (e) => { e.preventDefault(); this._doLogin(); });
      document.getElementById('login-lang-btn').onclick = () => this.toggleLang();
    },

    _showLogin() {
      this._renderUserBar();
      const ov = document.getElementById('login-overlay');
      if (ov) { ov.classList.add('show'); }
      const u = document.getElementById('login-user');
      if (u) setTimeout(() => u.focus(), 50);
    },

    _hideLogin() {
      const ov = document.getElementById('login-overlay');
      if (ov) ov.classList.remove('show');
    },

    // 后端不可达时的兜底页：说清原因 + 给出启动命令 + 可原地重试（不刷新也不丢输入）
    _showOffline() {
      this._setOffline(true);
      this._hideLogin();
      let ov = document.getElementById('offline-overlay');
      if (!ov) {
        ov = this.el('div', { id: 'offline-overlay', class: 'login-overlay show' });
        ov.innerHTML = `
          <div class="login-card">
            <div class="login-logo">${this.t('无法连接后端服务')}</div>
            <div class="login-sub">${this.t('地图与按钮都依赖本地后端，请先启动服务')}</div>
            <div class="login-cmd">python -m uvicorn web.server:app --host 127.0.0.1 --port 8000</div>
            <div class="login-tip">${this.t('工作目录 app/webapp；或直接双击 start_web.bat')}</div>
            <div class="login-err" id="offline-err"></div>
            <button type="button" class="btn primary login-btn" id="offline-retry">${this.t('重试连接')}</button>
          </div>`;
        document.body.appendChild(ov);
        document.getElementById('offline-retry').onclick = () => this._retryOffline();
      }
      ov.classList.add('show');
    },

    async _retryOffline() {
      const btn = document.getElementById('offline-retry');
      const err = document.getElementById('offline-err');
      if (err) err.textContent = '';
      if (btn) { btn.disabled = true; btn.textContent = this.t('重试中…'); }
      try {
        await this.api('/api/meta');
        location.reload();          // 后端已恢复：整页重走 boot()，回到正常流程
      } catch (e) {
        if (btn) { btn.disabled = false; btn.textContent = this.t('重试连接'); }
        if (err) err.textContent = this.t('仍然连不上，请确认后端已启动');
      }
    },

    async _doLogin() {
      const username = document.getElementById('login-user').value.trim();
      const password = document.getElementById('login-pass').value;
      const err = document.getElementById('login-err');
      err.textContent = '';
      if (!username || !password) { err.textContent = this.t('请输入用户名和密码'); return; }
      const btn = document.getElementById('login-btn');
      btn.disabled = true; btn.textContent = this.t('登录中…');
      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });
        const data = await res.json();
        if (res.ok && data.token) {
          localStorage.setItem('lase_token', data.token);
          // 刷新页面，让 boot() 走完整鉴权流程（避免二次登录时页面重复初始化）
          location.reload();
        } else {
          err.textContent = (data && data.detail) || this.t('用户名或密码错误');
        }
      } catch (e) {
        // 登录请求发不出去 = 后端没起。直接说清，别用"网络错误"这种模糊话
        this._setOffline(true);
        err.textContent = this.t('无法连接后端服务，请先启动后端（start_web.bat）');
      } finally {
        btn.disabled = false; btn.textContent = this.t('登 录');
      }
    },

    async _doLogout() {
      try { await this.api('/api/auth/logout', { method: 'POST' }); } catch (e) {}
      this._clearAuth();
      location.reload();
    },

    _renderUserBar() {
      const bar = document.getElementById('topbar-extra');
      if (!bar) return;
      bar.innerHTML = '';
      this._renderLangBtn(bar);
      if (this.user) {
        const tag = this.el('span', { class: 'user-chip' });
        tag.textContent = this.user.username
          + (this.user.role === 'admin' ? ' · ' + this.t('管理员') : '');
        bar.appendChild(tag);
        const btn = this.el('button', { class: 'btn', text: this.t('退出登录') });
        btn.onclick = () => this._doLogout();
        bar.appendChild(btn);
      }
    },

    _setConn(ok) {
      const el = document.getElementById('conn-status');
      el.textContent = '● ' + this.t(ok ? '后端已连接' : '后端未连接');
      el.id = 'conn-status';
      el.classList.toggle('ok', ok);
      el.classList.toggle('bad', !ok);
    },

    // 后端可达性（只看网络层，与 HTTP 状态码无关）。
    // 由 api() 每次请求后自动维护，所以左下角的连接状态会实时反映真实情况。
    _setOffline(flag) {
      this.offline = !!flag;
      this._setConn(!flag);
    },

    // 轮询后台任务
    taskPoll(taskId, { onProgress, onDone, onError, interval = 500 } = {}) {
      const timer = setInterval(async () => {
        let t;
        try { t = await this.api('/api/task/' + taskId); }
        catch (e) { clearInterval(timer); onError && onError(e); return; }
        if (t.state === 'running') {
          onProgress && onProgress(t.progress, t.message);
        } else if (t.state === 'done') {
          clearInterval(timer);
          onDone && onDone(t.result);
        } else if (t.state === 'error') {
          clearInterval(timer);
          onError && onError(t.error);
        } else if (t.state === 'not_found') {
          clearInterval(timer);
          onError && onError(this.t('任务不存在'));
        }
      }, interval);
      return () => clearInterval(timer);
    },

    /* 统一进度条：所有「开始仿真 / 预训练 / 采样 / 检验」这类长任务，都在按钮
       下方共用这一个控件。页面模板里放一个空容器（<div id="xxx-bar"></div>），
       这里按需注入「轨道 + 填充 + 文案」，返回控制器：
         start(msg)   显示并进入不确定态（后端还没报百分比时不至于停在 0%）
         set(p, msg)  p ∈ [0,1]，>0 时转确定态并按百分比铺满
         done(msg)    满格转绿；fail(msg) 转红；hide() 收起
       注意：后端 /api/task/{id} 的 progress 是真实进度（评估数 / 迭代数 / 单元数）。 */
    prog(id) {
      const T = s => this.t(s);
      const box = document.getElementById(id);
      if (!box) return { start() {}, set() {}, done() {}, fail() {}, hide() {} };
      if (!box.dataset.ready) {
        box.classList.add('prog-bar');
        box.innerHTML =
          '<div class="prog-track"><div class="prog-fill"></div></div>' +
          '<div class="prog-meta"><span class="prog-msg"></span>' +
          '<span class="prog-pct"></span></div>';
        box.dataset.ready = '1';
      }
      const fill = box.querySelector('.prog-fill');
      const msg = box.querySelector('.prog-msg');
      const pct = box.querySelector('.prog-pct');
      const state = s => {
        box.classList.remove('is-indet', 'is-run', 'is-done', 'is-fail');
        if (s) box.classList.add('is-' + s);
      };
      return {
        start(m) {
          box.style.display = 'block';
          state('indet');
          fill.style.width = '0%';
          msg.textContent = m || T('运行中…');
          pct.textContent = '';
        },
        set(p, m) {
          box.style.display = 'block';
          const v = Math.max(0, Math.min(1, Number(p) || 0));
          if (v > 0) {
            state('run');
            fill.style.width = (v * 100).toFixed(1) + '%';
            pct.textContent = Math.round(v * 100) + '%';
          }
          if (m) msg.textContent = m;
        },
        done(m) {
          box.style.display = 'block';
          state('done');
          fill.style.width = '100%';
          pct.textContent = '100%';
          if (m) msg.textContent = m;
        },
        fail(m) {
          box.style.display = 'block';
          state('fail');
          fill.style.width = '100%';
          pct.textContent = '';
          msg.textContent = m || T('失败');
        },
        hide() {
          box.style.display = 'none';
          state('');
        },
      };
    },

    // ---- 通用 UI 工具 ----
    el(tag, attrs = {}, html = '') {
      const e = document.createElement(tag);
      for (const k in attrs) {
        if (k === 'class') e.className = attrs[k];
        else if (k === 'text') e.textContent = attrs[k];
        else if (k.startsWith('on')) e[k.toLowerCase()] = attrs[k];
        else e.setAttribute(k, attrs[k]);
      }
      if (html) e.innerHTML = html;
      return e;
    },

    // 多选 chip 组（若为算法，hover 显示机制说明 + 出处）
    chipGroup(container, items, selectedSet, onChange) {
      container.innerHTML = '';
      const wrap = this.el('div', { class: 'chip-list' });
      items.forEach(it => {
        const c = this.el('span', { class: 'chip', text: it });
        const info = this.hostInfo && this.hostInfo[it];
        if (info) c.title = this.t(info.d) + '（' + info.r + '）' + (info.abs ? '\n' + this.t(info.abs) : '');
        if (selectedSet.has(it)) c.classList.add('on');
        c.onclick = () => {
          c.classList.toggle('on');
          if (c.classList.contains('on')) selectedSet.add(it);
          else selectedSet.delete(it);
          onChange && onChange(selectedSet);
        };
        wrap.appendChild(c);
      });
      container.appendChild(wrap);
    },

    // 某测试集实际可用的维度（优先磁盘扫描结果，回退合法维度）
    dimsOf(suite) {
      const m = this.meta;
      if (!m) return [];
      const avail = m.available_dims && m.available_dims[suite];
      if (avail && avail.length) return avail;
      return m.legal_dims[suite] || [];
    },

    // 下拉框（可选 infoHtml：在标签旁加「说明」图标，点击弹出）
    select(container, label, options, value, onChange, infoHtml) {
      const f = this.el('div', { class: 'field' });
      const lab = this.el('label', { text: label });
      f.appendChild(lab);
      if (infoHtml) this.info(lab, label, infoHtml);
      const s = this.el('select');
      options.forEach(o => {
        let v, t;
        if (Array.isArray(o)) { v = o[0]; t = o[1]; }
        else if (o && typeof o === 'object') {
          v = o.value; t = (o.text !== undefined ? o.text : o.label);
        } else { v = o; t = o; }
        const op = this.el('option', { value: v, text: t });
        s.appendChild(op);
      });
      s.value = value;
      s.onchange = () => onChange && onChange(s.value);
      f.appendChild(s);
      container.appendChild(f);
      return s;
    },

    numInput(container, label, value, min, max, step, onChange) {
      const f = this.el('div', { class: 'field' });
      f.appendChild(this.el('label', { text: label }));
      const inp = this.el('input', { type: 'number', value: value });
      if (min !== undefined) inp.min = min;
      if (max !== undefined) inp.max = max;
      if (step !== undefined) inp.step = step;
      inp.onchange = () => onChange && onChange(inp.value);
      f.appendChild(inp);
      container.appendChild(f);
      return inp;
    },

    btn(container, text, cls, onClick) {
      const b = this.el('button', { class: 'btn ' + (cls || ''), text });
      b.onclick = onClick;
      container.appendChild(b);
      return b;
    },

    // 图表下载图片工具箱：所有 ECharts 图统一在右上角注入下载按钮
    saveToolbox(name) {
      return {
        right: 8, top: 0,
        feature: {
          saveAsImage: { name: name || this.t('图表'), title: this.t('下载图片'), backgroundColor: '#fff', pixelRatio: 2 },
        },
      };
    },

    // 下载 canvas（导出为 PNG）
    downloadCanvas(canvas, filename) {
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    },

    // 把 canvas 导出成「论文插图」：原图 + 下方标题 + 图例 + 脚注（自动折行、自动扩高）
    // opts = {
    //   title: '图 · …',
    //   legend: [{ label, color, dash, shape, lineWidth, fill }],   // 元素图示（推荐）
    //   caption: ['…'],   // 纯文字说明，可选
    //   note: '口径 / 数据来源（一行）',
    // }
    // shape: 'line'(线型) | 'dot'(实心圆) | 'dotw'(白边圆，如起飞点/步兵) |
    //        'ring'(空心圆) | 'tri'(三角) | 'square'(方块) |
    //        'dashed-circle'(虚线圆，区域) | 'dashed-patch'(半透明填充+虚线圆)
    // 图例与脚注都被真正画进图片像素里，插进论文后不会丢说明。
    downloadFigure(canvas, filename, opts) {
      opts = opts || {};
      const lines = [];
      (opts.caption || []).forEach((s) => { if (s) lines.push(String(s)); });
      if (opts.note) lines.push(String(opts.note));
      const title = opts.title ? String(opts.title) : '';
      const legend = Array.isArray(opts.legend)
        ? opts.legend.filter(x => x && x.label) : [];

      const W = canvas.width;
      const fTitle = Math.max(15, Math.round(W / 44));
      const fBody = Math.max(12, Math.round(W / 56));
      const pad = Math.round(W / 38);
      const lh = Math.round(fBody * 1.65);
      const tFont = `600 ${fTitle}px system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif`;
      const bFont = `${fBody}px system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif`;

      const probe = document.createElement('canvas').getContext('2d');
      // 折行：先按空白切词，单个超长片段（中文长句 / 长文件名）再逐字符拆
      const wrap = (text, font, maxW) => {
        probe.font = font;
        const out = [];
        let cur = '';
        const push = () => { if (cur) { out.push(cur); cur = ''; } };
        String(text).split(/(\s+)/).forEach((tok) => {
          if (!tok) return;
          if (probe.measureText(cur + tok).width <= maxW) { cur += tok; return; }
          push();
          if (probe.measureText(tok).width <= maxW) {
            cur = tok.replace(/^\s+/, ''); return;
          }
          for (const ch of tok) {
            if (cur && probe.measureText(cur + ch).width > maxW) push();
            cur += ch;
          }
        });
        push();
        return out.length ? out : [''];
      };

      const maxW = W - pad * 2;
      const tLines = title ? wrap(title, tFont, maxW) : [];
      const bLines = [];
      lines.forEach((t) => wrap(t, bFont, maxW).forEach((x) => bLines.push(x)));

      // 图例：样例图形 + 短标签。宽图排两列（按列优先，读起来顺），窄图单列。
      const swW = Math.round(fBody * 2.7);
      const gap = Math.round(fBody * 0.9);
      const cols = (legend.length > 4 && maxW > 640) ? 2 : 1;
      const colW = Math.floor((maxW - (cols - 1) * gap * 3) / cols);
      const lItems = legend.map((it) => {
        const ls = wrap(String(it.label), bFont, Math.max(60, colW - swW - gap));
        return { it: it, lines: ls,
          h: Math.max(lh, ls.length * lh) + Math.round(fBody * 0.42) };
      });
      const rows = Math.ceil(lItems.length / cols) || 0;
      const rowH = lItems.length ? Math.max.apply(null, lItems.map(x => x.h)) : 0;
      const legendBlock = lItems.length ? rowH * rows + Math.round(pad * 0.5) : 0;

      const tBlock = tLines.length ? tLines.length * (fTitle + 8) + pad : 0;
      const bBlock = bLines.length ? bLines.length * lh + pad : 0;
      const out = document.createElement('canvas');
      out.width = W;
      out.height = canvas.height + pad + tBlock + legendBlock + bBlock + pad;
      const ctx = out.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, out.width, out.height);
      ctx.drawImage(canvas, 0, 0);

      let y = canvas.height + pad;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.font = tFont;
      ctx.fillStyle = '#111';
      tLines.forEach((ln) => { ctx.fillText(ln, pad, y); y += fTitle + 8; });

      if (lItems.length) {
        y += Math.round(pad * 0.35);
        const y0 = y;
        ctx.font = bFont;
        lItems.forEach((it, i) => {
          const ci = Math.floor(i / rows), ri = i % rows;
          const x = pad + ci * (colW + gap * 3);
          const yTop = y0 + ri * rowH;
          const yMid = yTop + Math.round(fBody * 0.8);
          this._legendSwatch(ctx, it.it, x, yMid, swW, fBody);
          ctx.fillStyle = '#333';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'top';
          it.lines.forEach((ln, k) => ctx.fillText(ln, x + swW + gap, yTop + k * lh));
        });
        y += rowH * rows + Math.round(pad * 0.4);
      }

      if (bLines.length) {
        y += Math.round(pad * 0.3);
        ctx.font = bFont;
        ctx.fillStyle = '#444';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        bLines.forEach((ln) => { ctx.fillText(ln, pad, y); y += lh; });
      }
      this.downloadCanvas(out, filename);
    },

    // 图例样例图形：把「颜色 / 线型 / 符号」本身画出来，右侧配短标签。
    _legendSwatch(ctx, it, x, yMid, w, fBody) {
      const color = it.color || '#333';
      const shape = it.shape || 'line';
      const lw = it.lineWidth || Math.max(1.6, fBody * 0.14);
      const cx = x + w / 2;
      ctx.save();
      ctx.lineWidth = lw;
      ctx.strokeStyle = color;
      ctx.fillStyle = it.fill || color;
      if (shape === 'line') {
        ctx.setLineDash(it.dash || []);
        ctx.beginPath();
        ctx.moveTo(x, yMid); ctx.lineTo(x + w, yMid); ctx.stroke();
      } else if (shape === 'dot' || shape === 'dotw') {
        const r = Math.max(3.2, fBody * 0.3);
        ctx.beginPath(); ctx.arc(cx, yMid, r, 0, Math.PI * 2); ctx.fill();
        if (shape === 'dotw') {
          ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, lw * 0.8); ctx.stroke();
        }
      } else if (shape === 'ring') {
        const r = Math.max(4, fBody * 0.36);
        ctx.beginPath(); ctx.arc(cx, yMid, r, 0, Math.PI * 2);
        ctx.strokeStyle = color; ctx.lineWidth = Math.max(1.8, lw); ctx.stroke();
      } else if (shape === 'tri') {
        const h = Math.max(5, fBody * 0.42);
        ctx.beginPath();
        ctx.moveTo(cx, yMid - h);
        ctx.lineTo(cx + h * 0.9, yMid + h * 0.65);
        ctx.lineTo(cx - h * 0.9, yMid + h * 0.65);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, lw * 0.6); ctx.stroke();
      } else if (shape === 'square') {
        const r = Math.max(3.4, fBody * 0.3);
        ctx.fillRect(cx - r, yMid - r, r * 2, r * 2);
      } else if (shape === 'dashed-circle' || shape === 'dashed-patch') {
        const r = Math.max(5, fBody * 0.46);
        ctx.beginPath(); ctx.arc(cx, yMid, r, 0, Math.PI * 2);
        if (shape === 'dashed-patch') { ctx.fillStyle = it.fill || color; ctx.fill(); }
        ctx.setLineDash(it.dash || [4, 3]);
        ctx.strokeStyle = color; ctx.lineWidth = Math.max(1.2, lw * 0.8); ctx.stroke();
      }
      ctx.restore();
    },

    // 下载 dataURL / blob URL 为文件
    downloadDataUrl(url, filename) {
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    },

    // 保存 ECharts 图表为 PNG（toolbox 小图标之外的显式按钮）
    saveChart(chart, name) {
      if (!chart) { alert(this.t('请先生成图表')); return; }
      const url = chart.getDataURL({ type: 'png', pixelRatio: 2, backgroundColor: '#fff' });
      if (!url) { alert(this.t('图表尚未渲染，无法保存')); return; }
      this.downloadDataUrl(url, (name || this.t('图表')) + '.png');
    },

    // 在卡片标题栏注入「保存图片」按钮（仅适用于纯文本标题，返回按钮）
    saveButton(titleEl, onClick) {
      const label = titleEl.textContent.trim();
      titleEl.textContent = '';
      titleEl.style.display = 'flex';
      titleEl.style.alignItems = 'center';
      titleEl.style.justifyContent = 'space-between';
      titleEl.style.gap = '8px';
      titleEl.appendChild(this.el('span', { text: label }));
      return this.btn(titleEl, this.t('保存图片'), '', onClick);
    },

    // 给指定图表容器所在卡片标题栏绑定「保存图片」按钮（幂等）
    bindChartSave(chartElId, chart, name) {
      const el = document.getElementById(chartElId);
      if (!el || !chart) return;
      const card = el.closest('.card');
      const title = card && card.querySelector('.card-title');
      if (title && !title.dataset.saveBound) {
        title.dataset.saveBound = '1';
        this.saveButton(title, () => this.saveChart(chart, name));
      }
    },

    msg(text, type) {
      const colors = { ok: '#2c7a4b', err: '#c0392b', info: '#2c5f8a' };
      return `<span style="color:${colors[type] || '#2c5f8a'}">${text}</span>`;
    },

    // 「说明」图标：点击弹出说明卡（可含链接）
    info(container, title, bodyHtml) {
      const ico = this.el('span', { class: 'info-ico', title: this.t('查看说明') });
      ico.textContent = 'ⓘ';
      ico.onclick = (e) => {
        e.stopPropagation();
        this._pop(ico, title, bodyHtml);
      };
      container.appendChild(ico);
      return ico;
    },

    // 某算法的说明卡 HTML（机制 + 摘要 + 出处 + 搜索链接）
    hostInfoHtml(name) {
      const info = this.hostInfo && this.hostInfo[name];
      if (!info) return '';
      const q = encodeURIComponent(name + ' ' + info.r.replace(/[^A-Za-z0-9 ]/g, ' '));
      return '<p>' + this._esc(this.t(info.d)) + '</p>'
        + (info.abs ? '<p class="muted">' + this._esc(this.t(info.abs)) + '</p>' : '')
        + '<p class="muted">' + this.t('出处：') + this._esc(info.r) + '</p>'
        + '<a href="https://scholar.google.com/scholar?q=' + q + '" target="_blank" rel="noopener">' + this.t('在 Google Scholar 检索该论文 ↗') + '</a>';
    },

    // 某测试集的说明卡 HTML（构成 + 官方链接）
    suiteInfoHtml(suite) {
      const si = this.suiteInfo && this.suiteInfo[suite];
      if (!si) return '';
      return '<p>' + this._esc(si.desc) + '</p>'
        + '<p class="muted">' + this._esc(si.name) + '</p>'
        + '<a href="' + si.url + '" target="_blank" rel="noopener">' + this.t('查看官方说明 ↗') + '</a>';
    },

    // 「模式」说明卡 HTML（纯算法 vs UPCL 增强）
    armInfoHtml() {
      return '<p><b>' + this.t('纯算法') + '</b>：' + this.t('不叠加任何 UPCL 修正的原始算法，作为基线。') + '</p>'
        + '<p><b>' + this.t('UPCL 增强') + '</b>：' + this.t('在纯算法之上叠加 UPCL 停滞检测与放大步长修正，用于量化 UPCL 增益。') + '</p>'
        + '<p class="muted">' + this._esc(this.upclIntro) + '</p>';
    },

    _esc(s) {
      return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    },

    _pop(anchor, title, bodyHtml) {
      this._closePop();
      const body = typeof bodyHtml === 'function' ? bodyHtml() : bodyHtml;
      const pop = this.el('div', { class: 'info-pop' });
      pop.innerHTML = '<div class="info-pop-title">' + this._esc(title || '') + '</div>'
        + '<div class="info-pop-body">' + (body || '') + '</div>';
      document.body.appendChild(pop);
      const r = anchor.getBoundingClientRect();
      pop.style.left = Math.round(r.left) + 'px';
      pop.style.top = Math.round(r.bottom + 6) + 'px';
      // 视口边界修正
      requestAnimationFrame(() => {
        const pr = pop.getBoundingClientRect();
        if (pr.right > window.innerWidth - 8) pop.style.left = (window.innerWidth - pr.width - 8) + 'px';
        if (pr.bottom > window.innerHeight - 8) pop.style.top = Math.round(r.top - pr.height - 6) + 'px';
      });
      this._popEl = pop;
    },

    _closePop() {
      if (this._popEl) { this._popEl.remove(); this._popEl = null; }
    },
  };

  window.LASE = LASE;
})();

/* 收敛曲线页 */
LASE.register('convergence', {
  _chart: null,
  _fids: null,
  _hosts: null,
  _arms: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'convergence' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('收敛曲线参数')}</div>
        <div class="row" id="conv-cfg"></div>
        <div style="margin-top:10px"><label class="muted">${LASE.t('函数 f')}</label>
          <div style="margin:6px 0" id="conv-fid-btns"></div><div id="conv-fids"></div></div>
        <div style="margin-top:10px"><label class="muted">${LASE.t('算法（{0} 个，悬停查看出处）', LASE.meta.hosts.length)}</label>
          <div style="margin:6px 0" id="conv-host-btns"></div><div id="conv-hosts"></div></div>
        <div style="margin-top:10px"><label class="muted" id="conv-arm-lab">${LASE.t('模式')}</label><div id="conv-arms"></div></div>
        <div style="margin-top:14px">
          <button class="btn primary" id="conv-plot">${LASE.t('绘制曲线')}</button>
          <span class="hint">${LASE.t('纵轴为 log10(误差)，越低越好')}</span>
        </div>
        <div style="margin-top:10px">
          <button class="btn" id="conv-ref">${LASE.t('📚 查看算法与测试集说明')}</button>
        </div>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('收敛曲线')}</div>
        <div class="chart" id="conv-chart"></div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._chart = echarts.init(document.getElementById('conv-chart'));
    this._buildCfg();
    document.getElementById('conv-plot').onclick = () => this._plot();
    document.getElementById('conv-ref').onclick = () => LASE.navigate('reference');
    LASE.info(document.getElementById('conv-arm-lab'), LASE.t('模式说明'), () => LASE.armInfoHtml());
    LASE.bindChartSave('conv-chart', this._chart, LASE.t('收敛曲线'));
  },

  show() { this._chart && this._chart.resize(); },

  _buildCfg() {
    const meta = LASE.meta;
    const cfg = document.getElementById('conv-cfg');
    cfg.innerHTML = '';
    const fillDims = (suite) => {
      this._dimSel.innerHTML = '';
      LASE.dimsOf(suite).forEach(d =>
        this._dimSel.appendChild(LASE.el('option', { value: d, text: 'D' + d })));
      if (this._dimSel.options.length) this._dimSel.value = this._dimSel.options[0].value;
    };
    this._suiteSel = LASE.select(cfg, LASE.t('测试集'), meta.suites, 'cec2022', (v) => {
      fillDims(v);
      this._fids = new Set(meta.suite_fids[v] || []);
      this._renderFids();
    }, () => LASE.suiteInfoHtml(this._suiteSel.value));
    this._dimSel = LASE.select(cfg, LASE.t('维度'), [], '');
    fillDims('cec2022');
    this._statSel = LASE.select(cfg, LASE.t('聚合方式'),
      [['中位数', LASE.t('中位数')], ['均值', LASE.t('均值')]], '中位数');
    const f = LASE.el('div', { class: 'field' });
    f.appendChild(LASE.el('label', { text: LASE.t('对数纵轴') }));
    const s = LASE.el('select');
    s.appendChild(LASE.el('option', { value: '1', text: 'log10(y)' }));
    s.appendChild(LASE.el('option', { value: '0', text: LASE.t('线性') }));
    f.appendChild(s);
    cfg.appendChild(f);
    this._logSel = s;

    this._fids = new Set(meta.suite_fids['cec2022']);
    this._hosts = new Set(meta.hosts);
    this._arms = new Set(['bare', 'upcl']);

    const hb = document.getElementById('conv-host-btns');
    hb.innerHTML = '';
    LASE.btn(hb, LASE.t('全选'), '', () => { this._hosts = new Set(meta.hosts); this._renderHosts(); });
    LASE.btn(hb, LASE.t('清空'), '', () => { this._hosts = new Set(); this._renderHosts(); });

    const fb = document.getElementById('conv-fid-btns');
    fb.innerHTML = '';
    LASE.btn(fb, LASE.t('全选'), '', () => { this._fids = new Set(meta.suite_fids[this._suiteSel.value]); this._renderFids(); });
    LASE.btn(fb, LASE.t('清空'), '', () => { this._fids = new Set(); this._renderFids(); });

    this._renderFids();
    this._renderHosts();
    this._renderArms();
  },

  _renderFids() {
    const meta = LASE.meta;
    const fids = meta.suite_fids[this._suiteSel.value] || [];
    LASE.chipGroup(document.getElementById('conv-fids'), fids, this._fids);
  },
  _renderHosts() {
    LASE.chipGroup(document.getElementById('conv-hosts'), LASE.meta.hosts, this._hosts);
  },
  _renderArms() {
    const items = ['bare', 'upcl'];
    const wrap = document.getElementById('conv-arms');
    wrap.innerHTML = '';
    const el = LASE.el('div', { class: 'chip-list' });
    items.forEach(it => {
      const label = it === 'bare' ? LASE.t('纯算法') : LASE.t('UPCL 增强');
      const chip = LASE.el('span', { class: 'chip', text: label });
      if (this._arms.has(it)) chip.classList.add('on');
      chip.onclick = () => {
        chip.classList.toggle('on');
        chip.classList.contains('on') ? this._arms.add(it) : this._arms.delete(it);
      };
      el.appendChild(chip);
    });
    wrap.appendChild(el);
  },

  async _plot() {
    const meta = LASE.meta;
    const suite = this._suiteSel.value;
    const dim = parseInt(this._dimSel.value);
    const body = {
      suite, dim,
      fids: meta.suite_fids[suite].filter(x => this._fids.has(x)),
      hosts: meta.hosts.filter(h => this._hosts.has(h)),
      arms: ['bare', 'upcl'].filter(a => this._arms.has(a)),
      stat: this._statSel.value,
      log_y: this._logSel.value === '1',
    };
    if (!body.hosts.length) { alert(LASE.t('请选择算法')); return; }
    const data = await LASE.api('/api/convergence', { method: 'POST', body });
    const series = data.curves.map(c => ({
      name: c.label, type: 'line', showSymbol: false,
      data: c.ys.map((y, i) => [data.xs[i], y]),
      lineStyle: { width: 1.6 },
    }));
    this._chart.setOption({
      toolbox: LASE.saveToolbox(LASE.t('收敛曲线')),
      tooltip: { trigger: 'axis' },
      legend: { type: 'scroll', bottom: 0, textStyle: { fontSize: 10 } },
      grid: { left: 55, right: 25, top: 30, bottom: 60 },
      xAxis: { type: 'value', name: LASE.t('评估次数（grid）'), min: data.xs[0] || 0, max: data.xs[data.xs.length - 1] || 0 },
      yAxis: { type: 'value', name: body.log_y ? LASE.t('log10(误差)') : LASE.t('误差') },
      dataZoom: [{ type: 'inside' }],
      series,
    }, true);
  },
});

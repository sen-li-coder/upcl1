/* 论文及参考资料页：按演化计算 / 深度强化学习 / 大语言模型三条线展示代表文献，
 * 每篇给出中文题名、原题、作者、出处、SCI 分区、摘要与平台落点，可分类 + 分区 + 年代筛选与关键词搜索。
 * 数据在 refs_data.js（window.LASE_REFS），本文件只负责渲染与交互。 */
LASE.register('refs', {
  _cat: 'all',
  _zone: 'all',
  _era: 'all',
  _q: '',

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'refs' });
    page.innerHTML = `
      <div class="card intro-card">
        <div class="card-title">${LASE.t('这份清单怎么用')}</div>
        <p style="margin:0 0 8px">${LASE.t('按三条技术线整理与平台直接相关的代表文献：演化计算（29 个 DE 宿主的来路）、深度强化学习（智能对手与策略搜索）、大语言模型（含与演化计算的交叉）。每篇都写清「它解决什么问题」和「在本平台落在哪」，可按方向、SCI 分区与年代筛选，也可用关键词搜索，再点 Scholar / DOI / arXiv 取原文。')}${this._stats()}</p>
        <p class="muted" style="margin:0">${LASE.t('分区为中科院《期刊分区表》升级版大类的近似值（1–4 区），仅作选题与投稿定位参考，以投稿当年官方版本为准；会议、预印本、教材专著与技术报告不参与分区，单列为「非期刊」。摘要为中文转述，引用与页码请以原刊为准。')}</p>
      </div>

      <div class="card">
        <div class="card-title">${LASE.t('三条线的脉络')}</div>
        <div id="refs-lines" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(250px, 1fr)); gap:14px"></div>
      </div>

      <div class="card">
        <div style="display:flex; flex-wrap:wrap; gap:8px 12px; align-items:center">
          <div class="seg" id="refs-seg"></div>
          <span class="muted" style="font-size:12px">${LASE.t('分区')}</span>
          <div class="seg" id="refs-zone"></div>
        </div>
        <div style="display:flex; flex-wrap:wrap; gap:8px 12px; align-items:center; margin-top:10px">
          <span class="muted" style="font-size:12px">${LASE.t('年代')}</span>
          <div class="seg" id="refs-era"></div>
        </div>
        <div style="display:flex; flex-wrap:wrap; gap:10px 14px; align-items:center; margin-top:10px">
          <div class="field" style="min-width:260px; flex:1 1 260px">
            <input type="text" id="refs-q" placeholder="${LASE.t('搜索题名 / 作者 / 期刊 / 摘要 / 标签，例如 JADE、Nature、遗传')}">
          </div>
          <span class="muted" id="refs-count" style="font-size:12px"></span>
        </div>
      </div>

      <div id="refs-list"></div>`;
    c.appendChild(page);
    this.page = page;
    this._renderLines();
    this._renderSeg();
    const q = page.querySelector('#refs-q');
    q.oninput = () => { this._q = q.value.trim().toLowerCase(); this._renderList(); };
    this._renderList();
  },

  _db() { return window.LASE_REFS || {}; },

  // 全库统计：总篇数 + 各区篇数（用于简介段的实时计数）
  _stats() {
    const d = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0 };
    let n = 0;
    this._keys().forEach(k => (this._db()[k].items || []).forEach(it => {
      n += 1;
      const z = this._zoneOf(it).z;
      d[z === null ? 0 : z] += 1;
    }));
    const parts = [1, 2, 3, 4].filter(z => d[z]).map(z => LASE.t('{0} 区 {1}', z, d[z]));
    if (d[0]) parts.push(LASE.t('非期刊') + ' ' + d[0]);
    return ` ${LASE.t('目前共 {0} 篇（{1}）。', n, parts.join(' · '))}`;
  },

  _keys() {
    const db = this._db();
    return ['ec', 'drl', 'llm'].filter(k => db[k]);
  },

  // 分区表按 key 长度降序，用 vn 前缀匹配（长名优先，避免 Nature 误吞 Nature Machine Intelligence）
  _jkeys() {
    if (!this.__jk) {
      const tb = this._db().journals || {};
      this.__jk = Object.keys(tb).sort((a, b) => b.length - a.length);
    }
    return this.__jk;
  },

  _zoneOf(it) {
    const tb = this._db().journals || {};
    const vn = it.vn || '';
    for (const k of this._jkeys()) {
      if (vn.indexOf(k) === 0) {
        const e = tb[k];
        return { z: e[0], s: e[1], k: e[2] || '' };
      }
    }
    return { z: null, s: '', k: '' };
  },

  _zoneLabel(z, kind) {
    if (z === null || z === 0) return LASE.t(kind || '非期刊');
    return LASE.t('SCI {0} 区', z) + (kind === 'Top' ? ' Top' : '');
  },

  _zoneColor(z) {
    if (z === 1) return ['#e6f4ec', '#1f7a4d'];
    if (z === 2) return ['#e8f0fb', '#2b5f9e'];
    if (z === 3) return ['#eef0f2', '#5b6470'];
    if (z === 4) return ['#f2f3f4', '#7c858f'];
    return ['#f5f6f7', '#8b939c'];
  },

  _zbadge(it) {
    const zo = this._zoneOf(it);
    const [bg, col] = this._zoneColor(zo.z);
    const txt = this._zoneLabel(zo.z, zo.k);
    return `<span class="chip" style="background:${bg}; color:${col}; border-color:${col}33; `
      + `font-size:10.5px; padding:1px 7px; white-space:nowrap">${LASE._esc(txt)}</span>`;
  },

  // 年代分段：2000 年前 / 2000–2009 / 2010–2019 / 2020 年至今（覆盖 1957–2026）
  _eras() {
    return [['all', LASE.t('全部年代')], ['pre', LASE.t('2000 年前')],
      ['00s', LASE.t('2000–2009')], ['10s', LASE.t('2010–2019')], ['20s', LASE.t('2020 年至今')]];
  },

  _eraOf(it) {
    const y = Number(it.y) || 0;
    if (y && y < 2000) return 'pre';
    if (y < 2010) return '00s';
    if (y < 2020) return '10s';
    return '20s';
  },

  // 顶部三个方向的小结：一句话脉络 + 篇数 + 平台落点 + 可点击跳转筛选
  _renderLines() {
    const db = this._db();
    const box = this.page.querySelector('#refs-lines');
    box.innerHTML = this._keys().map(k => {
      const g = db[k];
      const zs = g.items.map(it => this._zoneOf(it).z).filter(z => z >= 1 && z <= 4);
      const z1 = zs.filter(z => z === 1).length;
      return `<div class="ref-card" data-jump="${k}" style="cursor:pointer">
        <div class="ref-name" style="font-family:inherit">${g.icon} ${LASE.t(g.title)}
          <span class="muted" style="font-weight:400; font-size:12px">· ${g.items.length} ${LASE.t('篇')} · ${LASE.t('{0} 区 {1}', 1, z1)}</span></div>
        <div class="ref-abs">${LASE._esc(g.blurb)}</div>
        <div class="muted" style="font-size:11.5px">${LASE.t('点击只看这一类 →')}</div>
      </div>`;
    }).join('');
    box.querySelectorAll('[data-jump]').forEach(el => {
      el.onclick = () => {
        this._cat = el.dataset.jump;
        this._renderSeg(); this._renderList();
      };
    });
  },

  _renderSeg() {
    const db = this._db();
    const seg = this.page.querySelector('#refs-seg');
    const opts = [['all', LASE.t('全部')]].concat(
      this._keys().map(k => [k, db[k].icon + ' ' + LASE.t(db[k].title)]));
    seg.innerHTML = opts.map(([k, label]) =>
      `<button class="seg-btn${this._cat === k ? ' on' : ''}" data-cat="${k}">${LASE._esc(label)}</button>`
    ).join('');
    seg.querySelectorAll('[data-cat]').forEach(b => {
      b.onclick = () => { this._cat = b.dataset.cat; this._renderSeg(); this._renderList(); };
    });

    const zseg = this.page.querySelector('#refs-zone');
    const zopts = [['all', LASE.t('全部分区')]]
      .concat([1, 2, 3, 4].map(z => [String(z), LASE.t('{0} 区', z)]))
      .concat([['0', LASE.t('非期刊')]]);
    zseg.innerHTML = zopts.map(([k, label]) =>
      `<button class="seg-btn${this._zone === k ? ' on' : ''}" data-zone="${k}">${LASE._esc(label)}</button>`
    ).join('');
    zseg.querySelectorAll('[data-zone]').forEach(b => {
      b.onclick = () => { this._zone = b.dataset.zone; this._renderSeg(); this._renderList(); };
    });

    const eseg = this.page.querySelector('#refs-era');
    eseg.innerHTML = this._eras().map(([k, label]) =>
      `<button class="seg-btn${this._era === k ? ' on' : ''}" data-era="${k}">${LASE._esc(label)}</button>`
    ).join('');
    eseg.querySelectorAll('[data-era]').forEach(b => {
      b.onclick = () => { this._era = b.dataset.era; this._renderSeg(); this._renderList(); };
    });
  },

  _matches(it) {
    if (this._era !== 'all' && this._eraOf(it) !== this._era) return false;
    if (this._zone !== 'all') {
      const z = this._zoneOf(it).z;
      if (String(z === null ? 0 : z) !== this._zone) return false;
    }
    const q = this._q;
    if (!q) return true;
    const hay = [it.zh, it.en, it.au, it.vn, (it.tags || []).join(' '), it.abs, it.use]
      .join(' ').toLowerCase();
    return hay.indexOf(q) >= 0;
  },

  _link(it) {
    const scholar = 'https://scholar.google.com/scholar?q=' + encodeURIComponent(it.en);
    const parts = [`<a href="${scholar}" target="_blank" rel="noopener">Scholar ↗</a>`];
    if (it.doi) parts.push(`<a href="https://doi.org/${it.doi}" target="_blank" rel="noopener">DOI ↗</a>`);
    if (it.arxiv) parts.push(`<a href="https://arxiv.org/abs/${it.arxiv}" target="_blank" rel="noopener">arXiv ↗</a>`);
    return parts.join(' · ');
  },

  _card(it) {
    const esc = LASE._esc;
    const tags = (it.tags || []).map(t =>
      `<span class="chip" style="font-size:11px; padding:2px 9px">${esc(t)}</span>`).join('');
    const zo = this._zoneOf(it);
    return `<div class="ref-card">
      <div style="display:flex; gap:8px; align-items:flex-start; justify-content:space-between">
        <div class="ref-name" style="font-family:inherit; font-size:14px; line-height:1.45">${esc(it.zh)}</div>
        ${this._zbadge(it)}
      </div>
      <div style="font-size:11.5px; color:var(--label-2); line-height:1.5">${esc(it.en)}</div>
      <div class="ref-src">${esc(it.au)} · ${esc(it.vn)} · ${it.y} &nbsp; ${this._link(it)}</div>
      <div class="ref-abs">${esc(it.abs)}</div>
      <div class="ref-abs" style="border-left:2px solid var(--accent); padding-left:9px">
        <b style="color:var(--accent)">${LASE.t('平台落点')}</b>：${esc(it.use)}</div>
      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:2px">
        ${zo.s ? `<span class="chip" style="font-size:11px; padding:2px 9px">${esc(zo.s)}</span>` : ''}${tags}</div>
    </div>`;
  },

  _renderList() {
    const db = this._db();
    const keys = this._cat === 'all' ? this._keys() : [this._cat];
    const dist = { 1: 0, 2: 0, 3: 0, 4: 0, 0: 0 };
    let shown = 0, total = 0;
    const html = keys.map(k => {
      const g = db[k];
      if (!g) return '';
      total += g.items.length;
      const items = g.items.filter(it => {
        const ok = this._matches(it);
        if (ok) {
          const z = this._zoneOf(it).z;
          dist[z === null ? 0 : z] += 1;
          shown += 1;
        }
        return ok;
      });
      if (!items.length) return '';
      return `<div class="card">
        <div class="card-title">${g.icon} ${LASE.t(g.title)}
          <span class="muted" style="font-weight:400; font-size:12px">· ${items.length} ${LASE.t('篇')}</span></div>
        <p class="muted" style="font-size:12.5px; line-height:1.75; margin:0 0 14px">${LASE._esc(g.blurb)}</p>
        <div class="ref-grid">${items.map(it => this._card(it)).join('')}</div>
      </div>`;
    }).join('');

    const list = this.page.querySelector('#refs-list');
    list.innerHTML = html || `<div class="card"><p class="muted" style="margin:0">`
      + LASE.t('没有匹配的文献：换个关键词或分区，或点「全部」看完整清单。') + '</p></div>';

    const cnt = this.page.querySelector('#refs-count');
    if (cnt) {
      const parts = [];
      [1, 2, 3, 4].forEach(z => {
        if (dist[z]) parts.push(LASE.t('{0} 区 {1}', z, dist[z]));
      });
      if (dist[0]) parts.push(LASE.t('非期刊') + ' ' + dist[0]);
      const eraLabel = this._era === 'all' ? '' : this._eras().find(e => e[0] === this._era)[1];
      cnt.textContent = LASE.t('显示 {0} / {1} 篇', shown, total)
        + (parts.length ? ' · ' + parts.join(' · ') : '')
        + (eraLabel ? ' · ' + eraLabel : '')
        + (this._q ? LASE.t('（关键词：{0}）', this._q) : '');
    }
  },
});

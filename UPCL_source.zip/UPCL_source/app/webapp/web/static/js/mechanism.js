/* 机制分析页：效应量/干预率/描述子/演化曲线/散点 + 显著性检验 */
LASE.register('mechanism', {
  _charts: {},
  _fids: null,
  _hosts: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'mechanism' });
    page.innerHTML = `
      <div class="card intro-card">
        <div class="card-title">${LASE.t('什么是 UPCL 机制？')}</div>
        <p class="muted">${LASE.upclIntro}</p>
        <p class="muted">${LASE.t('本页从效应量（dec）、干预率、5 个描述子（z0~z4）等维度量化 UPCL 对每个算法的影响；dec 为正表示「UPCL 增强」后误差更低、效果更好。')}</p>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('机制分析参数')}</div>
        <div class="row" id="mech-cfg"></div>
        <div style="margin-top:10px"><label class="muted">${LASE.t('函数 f')}</label>
          <div style="margin:6px 0" id="mech-fid-btns"></div><div id="mech-fids"></div></div>
        <div style="margin-top:10px"><label class="muted">${LASE.t('算法（悬停查看出处）')}</label>
          <div style="margin:6px 0" id="mech-host-btns"></div><div id="mech-hosts"></div></div>
        <div style="margin-top:14px">
          <button class="btn primary" id="mech-analyze">${LASE.t('机制分析')}</button>
          <button class="btn" id="mech-rank">${LASE.t('显著性检验（秩和）')}</button>
          <a class="btn" href="/api/rank_test/export?token=${encodeURIComponent(LASE.token())}" target="_blank">${LASE.t('导出显著性 CSV')}</a>
          <span class="hint" id="mech-rank-prog"></span>
        </div>
        <div id="mech-prog-bar"></div>
      </div>
      <div class="grid-2">
        <div class="card"><div class="card-title">${LASE.t('效应量 dec（UPCL 增强 − 纯算法，log10 误差差）')}</div><div class="chart-sm" id="mech-dec"></div></div>
        <div class="card"><div class="card-title">${LASE.t('干预率（每代被 UPCL 修正的比例）')}</div><div class="chart-sm" id="mech-rate"></div></div>
      </div>
      <div class="grid-2">
        <div class="card"><div class="card-title">${LASE.t('描述子效应（z0~z4）')}</div><div class="chart-sm" id="mech-desc"></div></div>
        <div class="card"><div class="card-title">${LASE.t('ρ 与 dec 散点（每点=一个算法）')}</div><div class="chart-sm" id="mech-scat"></div></div>
      </div>
      <div class="card"><div class="card-title">${LASE.t('干预率演化曲线（按算法）')}</div><div class="chart" id="mech-rho"></div></div>
      <div class="card" id="mech-rank-card" style="display:none">
        <div class="card-title">${LASE.t('显著性检验结果')}</div>
        <div class="hint" style="margin-bottom:8px">${LASE.t('Mann-Whitney U 检验 + 配对 Wilcoxon，p < 0.05 判为显著')}</div>
        <div style="overflow:auto; max-height:520px"><table class="tbl" id="mech-rank-tbl"></table></div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._charts.dec = echarts.init(document.getElementById('mech-dec'));
    this._charts.rate = echarts.init(document.getElementById('mech-rate'));
    this._charts.desc = echarts.init(document.getElementById('mech-desc'));
    this._charts.scat = echarts.init(document.getElementById('mech-scat'));
    this._charts.rho = echarts.init(document.getElementById('mech-rho'));
    this._buildCfg();
    document.getElementById('mech-analyze').onclick = () => this._analyze();
    document.getElementById('mech-rank').onclick = () => this._rankTest();
    LASE.bindChartSave('mech-dec', this._charts.dec, LASE.t('机制-效应量'));
    LASE.bindChartSave('mech-rate', this._charts.rate, LASE.t('机制-干预率'));
    LASE.bindChartSave('mech-desc', this._charts.desc, LASE.t('机制-描述子效应'));
    LASE.bindChartSave('mech-scat', this._charts.scat, LASE.t('机制-散点'));
    LASE.bindChartSave('mech-rho', this._charts.rho, LASE.t('机制-干预率演化'));
  },

  show() { Object.values(this._charts).forEach(ch => ch && ch.resize()); },

  _buildCfg() {
    const meta = LASE.meta;
    const cfg = document.getElementById('mech-cfg');
    cfg.innerHTML = '';
    const fillDims = (suite) => {
      this._dimSel.innerHTML = '';
      LASE.dimsOf(suite).forEach(d =>
        this._dimSel.appendChild(LASE.el('option', { value: d, text: 'D' + d })));
      if (this._dimSel.options.length) this._dimSel.value = this._dimSel.options[0].value;
    };
    this._suiteSel = LASE.select(cfg, LASE.t('测试集'), meta.suites, 'cec2022', (v) => {
      fillDims(v);
      this._fids = new Set(meta.suite_fids[v] || []);
      this._renderFids();
    });
    this._dimSel = LASE.select(cfg, LASE.t('维度'), [], '');
    fillDims('cec2022');
    const f = LASE.el('div', { class: 'field' });
    f.appendChild(LASE.el('label', { text: LASE.t('干预率口径') }));
    const s = LASE.el('select');
    s.appendChild(LASE.el('option', { value: '1', text: LASE.t('策略干预率（policy）') }));
    s.appendChild(LASE.el('option', { value: '0', text: LASE.t('实际干预率') }));
    f.appendChild(s);
    cfg.appendChild(f);
    this._policySel = s;

    this._fids = new Set(meta.suite_fids['cec2022']);
    this._hosts = new Set(meta.hosts);
    const hb = document.getElementById('mech-host-btns');
    hb.innerHTML = '';
    LASE.btn(hb, LASE.t('全选'), '', () => { this._hosts = new Set(meta.hosts); this._renderHosts(); });
    LASE.btn(hb, LASE.t('清空'), '', () => { this._hosts = new Set(); this._renderHosts(); });
    const fb = document.getElementById('mech-fid-btns');
    fb.innerHTML = '';
    LASE.btn(fb, LASE.t('全选'), '', () => { this._fids = new Set(meta.suite_fids[this._suiteSel.value]); this._renderFids(); });
    LASE.btn(fb, LASE.t('清空'), '', () => { this._fids = new Set(); this._renderFids(); });
    this._renderFids();
    this._renderHosts();
  },

  _renderFids() {
    const meta = LASE.meta;
    const fids = meta.suite_fids[this._suiteSel.value] || [];
    LASE.chipGroup(document.getElementById('mech-fids'), fids, this._fids);
  },
  _renderHosts() {
    LASE.chipGroup(document.getElementById('mech-hosts'), LASE.meta.hosts, this._hosts);
  },

  _hostsSelected() {
    return LASE.meta.hosts.filter(h => this._hosts.has(h));
  },

  async _analyze() {
    const meta = LASE.meta;
    const suite = this._suiteSel.value;
    const dim = parseInt(this._dimSel.value);
    const body = {
      suite, dim,
      fids: meta.suite_fids[suite].filter(x => this._fids.has(x)),
      hosts: this._hostsSelected(),
      use_policy: this._policySel.value === '1',
    };
    if (!body.hosts.length) { alert(LASE.t('请选择算法')); return; }
    const data = await LASE.api('/api/mechanism', { method: 'POST', body });
    const agg = data.agg;
    if (!agg) { alert(LASE.t('无可用数据')); return; }

    // 效应量柱状图
    this._charts.dec.setOption({
      toolbox: LASE.saveToolbox(LASE.t('机制-效应量')),
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: 60, right: 20, top: 20, bottom: 80 },
      xAxis: { type: 'category', data: agg.dec.map(d => d.name), axisLabel: { rotate: 45, fontSize: 9 } },
      yAxis: { type: 'value', name: 'dec' },
      series: [{
        type: 'bar', data: agg.dec.map(d => d.value),
        itemStyle: { color: (p) => p.value >= 0 ? '#2c7a4b' : '#c0392b' },
      }],
    }, true);

    // 干预率柱状图
    this._charts.rate.setOption({
      toolbox: LASE.saveToolbox(LASE.t('机制-干预率')),
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: 60, right: 20, top: 20, bottom: 80 },
      xAxis: { type: 'category', data: agg.rate.map(d => d.name), axisLabel: { rotate: 45, fontSize: 9 } },
      yAxis: { type: 'value', name: LASE.t('干预率') },
      series: [{ type: 'bar', data: agg.rate.map(d => d.value), itemStyle: { color: '#2c5f8a' } }],
    }, true);

    // 描述子横向柱状图
    this._charts.desc.setOption({
      toolbox: LASE.saveToolbox(LASE.t('机制-描述子效应')),
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: 100, right: 30, top: 20, bottom: 30 },
      xAxis: { type: 'value', name: LASE.t('效应') },
      yAxis: { type: 'category', data: agg.desc.map(d => d.name) },
      series: [{
        type: 'bar', data: agg.desc.map(d => d.value),
        itemStyle: { color: (p) => p.value >= 0 ? '#2c7a4b' : '#c0392b' },
      }],
    }, true);

    // 散点：ρ vs dec
    this._charts.scat.setOption({
      toolbox: LASE.saveToolbox(LASE.t('机制-散点')),
      tooltip: { trigger: 'item', formatter: (p) => `${p.name}<br/>ρ=${p.value[0].toFixed(3)}<br/>dec=${p.value[1].toFixed(3)}` },
      grid: { left: 60, right: 30, top: 20, bottom: 50 },
      xAxis: { type: 'value', name: LASE.t('干预率 ρ') },
      yAxis: { type: 'value', name: 'dec' },
      series: [{
        type: 'scatter',
        data: agg.scatter.filter(s => s.x != null && s.y != null).map(s => ({ name: s.name, value: [s.x, s.y] })),
        label: { show: true, formatter: '{b}', position: 'top', fontSize: 9 },
      }],
    }, true);

    // 演化曲线
    this._charts.rho.setOption({
      toolbox: LASE.saveToolbox(LASE.t('机制-干预率演化')),
      tooltip: { trigger: 'axis' },
      legend: { type: 'scroll', bottom: 0, textStyle: { fontSize: 10 } },
      grid: { left: 55, right: 25, top: 25, bottom: 55 },
      xAxis: { type: 'value', name: LASE.t('归一化代数'), min: 0, max: 1 },
      yAxis: { type: 'value', name: LASE.t('干预率') },
      series: agg.rho_curves.map(c => ({
        name: c.name, type: 'line', showSymbol: false,
        data: c.data.map((y, i) => [i / Math.max(c.data.length - 1, 1), y]),
        lineStyle: { width: 1.5 },
      })),
    }, true);
  },

  async _rankTest() {
    const prog = document.getElementById('mech-rank-prog');
    prog.textContent = '';
    const bar = LASE.prog('mech-prog-bar');
    bar.start(LASE.t('检验中…'));
    const r = await LASE.api('/api/rank_test', { method: 'POST' });
    LASE.taskPoll(r.task_id, {
      onProgress: (p, m) => bar.set(p, m),
      onDone: (rows) => {
        bar.done(LASE.t('检验完成'));
        this._renderRank(rows);
      },
      onError: (e) => { bar.fail(LASE.t('检验失败：') + e); },
    });
  },

  _renderRank(rows) {
    const card = document.getElementById('mech-rank-card');
    card.style.display = '';
    const tbl = document.getElementById('mech-rank-tbl');
    const nSig = rows.filter(r => r.significant).length;
    let html = `<tr><th>suite</th><th>dim</th><th>host</th><th>fid</th><th>${LASE.t('类别')}</th>` +
      `<th>${LASE.t('模式')}</th><th>n</th><th>p(MWU)</th><th>p(Wilcoxon)</th><th>${LASE.t('结论')}</th><th>Δlog10</th></tr>`;
    rows.forEach(r => {
      const bg = r.significant ? ' style="background:#fdf0ef"' : '';
      const f4 = (v) => (typeof v === 'number' && isFinite(v)) ? v.toFixed(4) : '-';
      const d = r.mean_log10_b - r.mean_log10_a;
      html += `<tr${bg}><td>${r.suite}</td><td>D${r.dim}</td><td>${r.host}</td>` +
        `<td>F${r.fid}</td><td>${r.category}</td><td>${r.arm_a} vs ${r.arm_b}</td>` +
        `<td>${r.n}</td><td class="mono">${f4(r.p_mwu)}</td>` +
        `<td class="mono">${f4(r.p_wil)}</td>` +
        `<td>${r.significant ? '<b style="color:#c0392b">' + LASE.t('显著') + '</b>' : LASE.t('不显著')} · ${r.direction}</td>` +
        `<td class="mono">${isFinite(d) ? d.toFixed(3) : '-'}</td></tr>`;
    });
    tbl.innerHTML = html;
    card.scrollIntoView({ behavior: 'smooth' });
    document.getElementById('mech-rank').textContent =
      LASE.t('显著性检验（{0}/{1} 显著）', nSig, rows.length);
  },
});

/* 地形图页：二维热力图 + 等高线 + 三维曲面 + 种群演化 + 收敛曲线 */
LASE.register('landscape', {
  _mapChart: null,   // 2D
  _3dChart: null,    // 3D
  _errChart: null,
  _data: null,
  _frame: 0,
  _view: '2d',
  _playing: false,
  _anim: null,

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'landscape' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('地形图采样参数')}</div>
        <div class="row" id="land-cfg"></div>
        <div style="margin-top:14px">
          <button class="btn primary" id="land-run">${LASE.t('开始采样')}</button>
          <span class="muted" id="land-prog"></span>
        </div>
        <div id="land-prog-bar"></div>
      </div>
      <div class="card">
        <div class="card-title" style="display:flex; align-items:center; justify-content:space-between; gap:8px">
          <span>${LASE.t('适应度地形')}（<span id="land-view-label">${LASE.t('二维')}</span>）</span>
          <span style="display:flex; align-items:center; gap:8px">
            <button class="btn" id="land-save">${LASE.t('保存图片')}</button>
            <span class="seg" id="land-view-seg">
              <button class="seg-btn on" id="land-view-2d">${LASE.t('二维等高线')}</button>
              <button class="seg-btn" id="land-view-3d">${LASE.t('三维曲面')}</button>
            </span>
          </span>
        </div>
        <div class="chart" id="land-2d"></div>
        <div class="chart" id="land-3d" style="display:none"></div>
        <div class="row" style="margin-top:8px; align-items:center">
          <button class="btn" id="land-play">${LASE.t('▶ 播放演示')}</button>
          <label class="muted">${LASE.t('演化帧')}</label>
          <input type="range" id="land-slider" min="0" max="0" value="0" style="flex:1">
          <span class="muted mono" id="land-frame-label">0/0</span>
        </div>
        <div class="legend" style="margin-top:8px">
          <span><span class="dot" style="background:#00e5ff"></span>${LASE.t('种群个体')}</span>
          <span><span class="dot" style="background:#fff; border:1px solid #888"></span>${LASE.t('全局最优 x*')}</span>
          <span><span class="dot" style="background:transparent; border:2px solid #ffd400"></span>${LASE.t('算法找到的最优')}</span>
        </div>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('最优个体收敛')}</div>
        <div class="chart-sm" id="land-err"></div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._mapChart = echarts.init(document.getElementById('land-2d'));
    this._errChart = echarts.init(document.getElementById('land-err'));
    this._buildCfg();
    document.getElementById('land-run').onclick = () => this._run();
    document.getElementById('land-slider').oninput = (e) => {
      this._frame = parseInt(e.target.value);
      this._drawFrame();
    };
    document.getElementById('land-view-2d').onclick = () => this._switchView('2d');
    document.getElementById('land-view-3d').onclick = () => this._switchView('3d');
    document.getElementById('land-play').onclick = () => this._togglePlay();
    document.getElementById('land-save').onclick = () => {
      const is3d = this._view === '3d';
      LASE.saveChart(is3d ? this._3dChart : this._mapChart, LASE.t(is3d ? '地形图-三维' : '地形图-二维'));
    };
    LASE.bindChartSave('land-err', this._errChart, LASE.t('地形图-收敛'));
  },

  _stopPlay() {
    if (this._anim) { clearInterval(this._anim); this._anim = null; }
    this._playing = false;
    const btn = document.getElementById('land-play');
    if (btn) btn.textContent = LASE.t('▶ 播放演示');
  },

  _togglePlay() {
    const btn = document.getElementById('land-play');
    if (this._playing) {
      this._playing = false; btn.textContent = LASE.t('▶ 继续');
      if (this._anim) { clearInterval(this._anim); this._anim = null; }
    } else {
      const run = this._data && this._data.traces && this._data.traces[0];
      if (!run || !run.pop || !run.pop.length) return;
      this._playing = true; btn.textContent = LASE.t('⏸ 暂停');
      const n = run.pop.length;
      this._anim = setInterval(() => {
        this._frame = (this._frame + 1) % n;
        document.getElementById('land-slider').value = this._frame;
        this._drawFrame();
      }, 120);
    }
  },

  show() {
    this._mapChart && this._mapChart.resize();
    this._3dChart && this._3dChart.resize();
    this._errChart && this._errChart.resize();
    // 切回本页时若上次是在隐藏状态下绘制的 3D 曲面（0 尺寸），需重绘一次，
    // 否则 resize 后仍可能是白板。
    if (this._view === '3d' && this._3dChart && this._data) this._draw3d();
  },

  _switchView(v) {
    this._view = v;
    document.getElementById('land-2d').style.display = v === '2d' ? '' : 'none';
    document.getElementById('land-3d').style.display = v === '3d' ? '' : 'none';
    document.getElementById('land-view-label').textContent = LASE.t(v === '2d' ? '二维' : '三维');
    document.getElementById('land-view-2d').classList.toggle('on', v === '2d');
    document.getElementById('land-view-3d').classList.toggle('on', v === '3d');
    if (v === '2d') {
      this._mapChart && this._mapChart.resize();
    } else {
      if (!this._3dChart) this._3dChart = echarts.init(document.getElementById('land-3d'));
      if (this._data) this._draw3d();
      this._3dChart.resize();
    }
  },

  _buildCfg() {
    const meta = LASE.meta;
    const cfg = document.getElementById('land-cfg');
    cfg.innerHTML = '';
    const fillDims = (suite) => {
      this._dimSel.innerHTML = '';
      LASE.dimsOf(suite).forEach(d =>
        this._dimSel.appendChild(LASE.el('option', { value: d, text: 'D' + d })));
      if (this._dimSel.options.length) this._dimSel.value = this._dimSel.options[0].value;
    };
    const fillFids = (suite) => {
      this._fidSel.innerHTML = '';
      (meta.suite_fids[suite] || []).forEach(f =>
        this._fidSel.appendChild(LASE.el('option', { value: f, text: 'F' + f })));
      if (this._fidSel.options.length) this._fidSel.value = this._fidSel.options[0].value;
    };
    this._suiteSel = LASE.select(cfg, LASE.t('测试集'), meta.suites, 'cec2022', (v) => {
      fillDims(v); fillFids(v);
    });
    this._dimSel = LASE.select(cfg, LASE.t('维度'), [], '');
    this._fidSel = LASE.select(cfg, LASE.t('函数'), [], '');
    fillDims('cec2022');
    fillFids('cec2022');
    this._hostSel = LASE.select(cfg, LASE.t('算法'), meta.hosts, 'DE/rand/1');
    this._armSel = LASE.select(cfg, LASE.t('模式'), [['bare', LASE.t('纯算法')], ['upcl', LASE.t('UPCL 增强')]], 'bare');
    this._fesInp = LASE.numInput(cfg, LASE.t('评估预算 ×D'), 10000, 100, 1000000, 1000);
    this._frameInp = LASE.numInput(cfg, LASE.t('演化帧数'), 20, 5, 100, 1);
  },

  async _run() {
    const prog = document.getElementById('land-prog');
    prog.textContent = '';
    const bar = LASE.prog('land-prog-bar');
    bar.start(LASE.t('采样中…'));
    const body = {
      suite: this._suiteSel.value, dim: parseInt(this._dimSel.value),
      fid: parseInt(this._fidSel.value), host: this._hostSel.value,
      arm: this._armSel.value, fes_mult: parseFloat(this._fesInp.value),
      n_frames: parseInt(this._frameInp.value),
    };
    const r = await LASE.api('/api/landscape', { method: 'POST', body });
    LASE.taskPoll(r.task_id, {
      onProgress: (p, m) => bar.set(p, m),
      onDone: (data) => {
        bar.done(LASE.t('采样完成'));
        this._stopPlay();
        this._data = data;
        this._frame = 0;
        const trace0 = data.traces[0] || null;
        const n = trace0 ? trace0.pop.length : 0;
        const sl = document.getElementById('land-slider');
        sl.max = Math.max(0, n - 1); sl.value = 0;
        this._drawMap();
        if (this._view === '3d' && this._3dChart) this._draw3d();
        this._drawErr();
      },
      onError: (e) => { bar.fail(LASE.t('采样失败：') + e); },
    });
  },

  // ---- 工具：把 (x,y) 映射到地形高度（最近邻查表）----
  _zLog() { return this._data.z_log || this._data.landscape.z; },
  _zRank() { return this._data.z_rank || this._zLog(); },
  _lookup(Z, x, y) {
    const { lb, ub } = this._data;
    const n = Z.length, m = Z[0].length;
    const j = Math.max(0, Math.min(m - 1, Math.round((x - lb) / (ub - lb) * (m - 1))));
    const i = Math.max(0, Math.min(n - 1, Math.round((y - lb) / (ub - lb) * (n - 1))));
    return Z[i][j];
  },
  _zAt(x, y) { return this._lookup(this._zRank(), x, y); },    // 显示高度（分位 0~1）
  _zLogAt(x, y) { return this._lookup(this._zLog(), x, y); },  // 真实 log10 高度

  _heatData() {
    const Z = this._zRank();
    const xs = this._data.landscape.x, ys = this._data.landscape.y;
    const pts = [];
    for (let i = 0; i < ys.length; i++)
      for (let j = 0; j < xs.length; j++)
        pts.push([xs[j], ys[i], Z[i][j]]);
    return pts;
  },

  // surface 数据：扁平三元组数组 [x, y, z]（行主序：i 遍历 y、j 遍历 x）。
  // 注意：echarts-gl surface 无法解析「二维嵌套三元组数组」，必须传扁平数组，
  // 并显式给定 dataShape:[行数, 列数]（其 _getDataShape 自动推断会失败），
  // 否则曲面完全不渲染（白板）。三元组带真实 x/y 坐标，避免与 lb..ub 范围错位。
  _3dData() {
    const Z = this._zRank();
    const xs = this._data.landscape.x, ys = this._data.landscape.y;
    const pts = [];
    for (let i = 0; i < ys.length; i++)
      for (let j = 0; j < xs.length; j++)
        pts.push([xs[j], ys[i], Z[i][j]]);
    return pts;
  },

  _contourSeries() {
    // 等高线：按 level 分组，每组把闭合圈/开放弧串成连续多段线（polyline），
    // 黑描边 + 白内线双层，保证在浅色与深色地形背景上都清晰可见。
    const out = [];
    const mk = (data, color, width, z) => ({
      type: 'lines', coordinateSystem: 'cartesian2d', data,
      silent: true, zlevel: z,
      lineStyle: { color, width, opacity: 0.9 },
    });
    (this._data.contours || []).forEach((c) => {
      const loops = c.loops || c.segs || [];
      if (!loops.length) return;
      // 兼容旧格式 segs（4 元组）——转成单段 polyline
      const data = (c.loops ? loops : loops.map(s => [[s[0], s[1]], [s[2], s[3]]]))
        .map(loop => ({ coords: loop }));
      out.push(mk(data, 'rgba(0,0,0,0.85)', 2.0, 5));
      out.push(mk(data, '#fff', 0.9, 6));
    });
    return out;
  },

  _zRange() { return [0, 1]; },

  _markSeries2d() {
    const s = [];
    const xo = this._data.x_opt || [];
    const bx = this._data.best_x || [];
    if (xo.length >= 2) {
      s.push({
        name: LASE.t('全局最优 x*'), type: 'scatter',
        data: [[xo[0], xo[1]]], symbolSize: 14, zlevel: 8,
        symbol: 'path://M-1,-1 L1,1 M-1,1 L1,-1',
        itemStyle: { color: '#fff', borderColor: '#000', borderWidth: 1.5 },
      });
    }
    if (bx && bx.length >= 2) {
      s.push({
        name: LASE.t('算法最优'), type: 'scatter',
        data: [[bx[0], bx[1]]], symbolSize: 15, zlevel: 8,
        symbol: 'circle',
        itemStyle: { color: 'transparent', borderColor: '#ffd400', borderWidth: 2.5 },
      });
    }
    return s;
  },

  _drawMap() {
    // 页面可能在隐藏状态下 init（0 尺寸），绘制前强制 resize 一次，避免白底
    this._mapChart && this._mapChart.resize();
    const L = this._data.landscape;
    const [zmin, zmax] = this._zRange();
    // 热力图不设 progressive（否则大数据量下只渲染前 N 个格子，出现白底）
    const series = [
      { name: LASE.t('地形'), type: 'heatmap', data: this._heatData(),
        emphasis: { disabled: true }, progressive: 0, zlevel: 1,
        itemStyle: { borderWidth: 0 } },
      { name: LASE.t('种群'), type: 'scatter', symbolSize: 7, zlevel: 6,
        itemStyle: { color: '#00e5ff', borderColor: '#003040', borderWidth: 1 } },
      ...this._contourSeries(),
      ...this._markSeries2d(),
    ];
    this._mapChart.setOption({
      toolbox: LASE.saveToolbox(LASE.t('地形图-二维')),
      tooltip: { trigger: 'item', formatter: (p) => {
        if (p.seriesType === 'heatmap') {
          const log = this._zLogAt(p.value[0], p.value[1]);
          return `x1=${p.value[0].toFixed(2)}<br>x2=${p.value[1].toFixed(2)}<br>log10(f+1)=${log.toFixed(3)}`;
        }
        if (p.seriesType === 'scatter') return `${p.seriesName}<br>x1=${p.value[0].toFixed(2)}<br>x2=${p.value[1].toFixed(2)}`;
        return '';
      } },
      grid: { left: 55, right: 20, top: 20, bottom: 45 },
      xAxis: { type: 'value', name: 'x1', min: Math.min(...L.x), max: Math.max(...L.x) },
      yAxis: { type: 'value', name: 'x2', min: Math.min(...L.y), max: Math.max(...L.y) },
      visualMap: { seriesIndex: 0, dimension: 2, min: zmin, max: zmax,
        calculable: true, orient: 'horizontal', left: 'center', bottom: 0,
        text: [LASE.t('地形高度(分位) 高'), LASE.t('低')],
        inRange: { color: ['#313695', '#4575b4', '#74add1', '#fee090', '#f46d43', '#a50026'] } },
      series,
    }, true);
    this._drawFrame();
  },

  _draw3d() {
    // 与 _drawMap 一致：页面可能在隐藏/0 尺寸状态下 init 或上次渲染，
    // 绘制前强制 resize 一次，避免 3D 曲面白板。
    this._3dChart && this._3dChart.resize();
    const L = this._data.landscape;
    const { lb, ub } = this._data;
    const [zmin, zmax] = this._zRange();
    const xo = this._data.x_opt || [];
    const bx = this._data.best_x || [];
    const marks = [];
    if (xo.length >= 2) marks.push({ name: LASE.t('全局最优 x*'), value: [xo[0], xo[1], this._zAt(xo[0], xo[1])] });
    if (bx && bx.length >= 2) marks.push({ name: LASE.t('算法最优'), value: [bx[0], bx[1], this._zAt(bx[0], bx[1])] });
    this._3dChart.setOption({
      toolbox: LASE.saveToolbox(LASE.t('地形图-三维')),
      tooltip: {},
      visualMap: {
        show: false, seriesIndex: 0, dimension: 2, min: zmin, max: zmax,
        inRange: { color: ['#313695', '#4575b4', '#74add1', '#fee090', '#f46d43', '#a50026'] },
      },
      grid3D: {
        boxWidth: 110, boxDepth: 110, boxHeight: 70,
        axisPointer: { show: false },
        viewControl: { projection: 'perspective', distance: 230, alpha: 28, beta: -50 },
        // shading:'color' 走纯顶点颜色着色，不使用光照；显式配置 light 反而会让
        // 曲面变黑/不渲染，environment:'#fff' 会让 3D 背景变白。两者都去掉。
      },
      xAxis3D: { type: 'value', name: 'x1', min: lb, max: ub },
      yAxis3D: { type: 'value', name: 'x2', min: lb, max: ub },
      zAxis3D: { type: 'value', name: LASE.t('地形高度(分位)'), min: zmin, max: zmax },
      series: [
        { type: 'surface', data: this._3dData(),
          dataShape: [L.y.length, L.x.length],
          shading: 'color', silent: true,
          wireframe: { show: false },
          itemStyle: { opacity: 0.92 } },
        { type: 'scatter3D', name: LASE.t('种群'), symbolSize: 6,
          itemStyle: { color: '#00e5ff', borderColor: '#003040', borderWidth: 0.5 } },
        { type: 'scatter3D', name: LASE.t('全局最优 x*'), symbolSize: 10,
          data: marks.filter(m => m.name === LASE.t('全局最优 x*')).map(m => m.value),
          itemStyle: { color: '#fff', borderColor: '#000', borderWidth: 1 } },
        { type: 'scatter3D', name: LASE.t('算法最优'), symbolSize: 10,
          data: marks.filter(m => m.name === LASE.t('算法最优')).map(m => m.value),
          itemStyle: { color: '#ffd400', borderColor: '#7a5c00', borderWidth: 1 } },
      ],
    }, true);
    this._drawFrame();
  },

  _drawFrame() {
    if (!this._data) return;
    const traces = this._data.traces;
    const label = document.getElementById('land-frame-label');
    if (!traces.length || !traces[0].pop.length) { label.textContent = '0/0'; return; }
    const run = traces[0];
    const frameIdx = Math.min(this._frame, run.pop.length - 1);
    const pop = run.pop[frameIdx].map(p => [p[0], p[1]]);
    this._mapChart.setOption({ series: [{}, { data: pop }] });
    if (this._3dChart) {
      const pop3 = run.pop[frameIdx].map(p => [p[0], p[1], this._zAt(p[0], p[1])]);
      this._3dChart.setOption({ series: [{}, { data: pop3 }] });
    }
    const gens = run.gens ? run.gens[frameIdx] : '';
    const nevals = run.nevals ? run.nevals[frameIdx] : '';
    label.textContent = `${frameIdx + 1}/${run.pop.length} · ${LASE.t('代')}=${gens} · nevals=${nevals}`;
  },

  _drawErr() {
    const curves = this._data.err_curves;
    this._errChart.setOption({
      toolbox: LASE.saveToolbox(LASE.t('地形图-收敛')),
      tooltip: { trigger: 'axis' },
      grid: { left: 60, right: 25, top: 20, bottom: 40 },
      xAxis: { type: 'value', name: LASE.t('评估次数') },
      yAxis: { type: 'log', name: LASE.t('误差') },
      series: curves.map((c, i) => ({
        name: 'run ' + (i + 1), type: 'line', showSymbol: false,
        data: c.grid.map((g, j) => [g, Math.max(c.err[j], 1e-300)]),
      })),
    }, true);
  },
});

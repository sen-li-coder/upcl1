/* UAV 对抗仿真页：参数 + Canvas 战场动画 + 收敛曲线 + 统计 */

// 论文实验数据的指标中文名（后端返回英文 metric key，转成中文再走 i18n）
const UAV_PAPER_METRIC_LABELS = {
  csr_pct: '综合成功率',
  n_arrived: '抵达无人机数',
  n_lost: '损失无人机数',
  min_dist: '最小突防距离',
  first_capture: '首次被捕获时刻',
  nofly_steps: '禁飞区侵入步数',
  risk_time: '被雷达跟踪时长',
  bounds_steps: '越界步数',
  path_length: '路径长度',
  flight_time: '飞行时长',
  n_inf_arrived: '抵达基地步兵数',
  infantry_survival: '步兵存活率',
  base_hp: '基地剩余血量',
  n_patrol_killed: '击毙巡逻兵数',
  patrol_survival: '巡逻兵存活率',
  // §5.5 综合成功率与三个分量：不设阈值，直接给百分比（越高越好）
  base_weaken_pct: '基地削弱率',
  inf_breach_pct: '步兵突入率',
  patrol_kill_pct: '巡逻战果率',
};

LASE.register('uav', {
  _convChart: null,
  _map3dChart: null,
  _traceChart: null,
  _result: null,
  _anim: null,
  _frame: 0,
  _playing: false,
  _recording: false,    // 是否正在录制演示视频
  _playRate: 1,         // 播放倍速：0.25 / 0.5 / 1 / 1.25 / 1.5
  _view: null,          // 3D 视角 { alpha, beta, distance }，供手动视角按钮共享
  _sandbox: null,       // Three.js 沙盒渲染器 { renderer, scene, camera, controls, rafId, ... }
  _dropIdx: 0,          // 投放视角当前选中的无人机序号
  _dropFrame: 0,        // 投放视角独立播放帧指针
  _dropAnim: null,      // 投放视角播放定时器

  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'uav' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('仿真参数')}</div>
        <div class="row" id="uav-cfg"></div>
        <div class="muted" id="uav-view-hint" style="margin-top:8px; font-size:12px; display:none"></div>
        <div style="margin-top:14px">
          <button class="btn" id="uav-desc">${LASE.t('场景说明')}</button>
          <button class="btn" id="uav-paper">${LASE.t('任务实验数据')}</button>
          <button class="btn" id="uav-load-map">${LASE.t('加载地形')}</button>
          <button class="btn" id="uav-pretrain">${LASE.t('预训练捕获')}</button>
          <button class="btn primary" id="uav-run">${LASE.t('开始仿真')}</button>
          <button class="btn danger" id="uav-cancel">${LASE.t('取消')}</button>
          <span class="muted" id="uav-prog"></span>
        </div>
        <div id="uav-prog-bar"></div>
        <div class="muted" id="uav-blue-tip" style="margin-top:8px; font-size:12px">
          ${LASE.t('建议流程：先「预训练捕获」让强化学习直升机拦截者学会捕获直线突防目标，再「开始仿真」用演化算法重新设计逃逸。')}
        </div>
      </div>
      <div class="card" id="uav-paper-badge" style="display:none"></div>
      <div class="uav-stats" id="uav-stats" style="margin-bottom:14px"></div>
      <div class="card" id="uav-repr-card">
        <div class="card-title">${LASE.t('代表轨迹（任务 × 场景，二维）')}</div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin:2px 0 8px;
          background:#eef4fa; border-left:3px solid #2c5f8a; padding:8px 12px; border-radius:4px">
          <span style="font-size:12px; font-weight:700; color:#2c5f8a">${LASE.t('查看哪个算法的轨迹：')}</span>
          <span style="display:flex; gap:6px; align-items:center">
            <span class="muted" style="font-size:12px">${LASE.t('算法')}</span>
            <select id="uav-repr-host" title="${LASE.t('选择要查看的算法')}"
              style="font:inherit; font-size:12.5px; padding:4px 6px; max-width:260px;
              border:1px solid #b9c9da; border-radius:4px; background:#fff"></select>
          </span>
          <span style="display:flex; gap:6px; align-items:center">
            <span class="muted" style="font-size:12px">${LASE.t('运行次数')}</span>
            <select id="uav-repr-run" title="${LASE.t('选择第几次运行')}"
              style="font:inherit; font-size:12.5px; padding:4px 6px;
              border:1px solid #b9c9da; border-radius:4px; background:#fff"></select>
          </span>
          <span class="muted" id="uav-repr-count" style="font-size:11.5px"></span>
          <button class="btn" id="uav-repr-refresh">${LASE.t('重新载入')}</button>
        </div>
        <div class="muted" style="font-size:12px; margin-bottom:8px" id="uav-repr-note">
          ${LASE.t('每个「场景 × 任务」一张二维代表轨迹图：蓝线 = 纯算法基线（bare），橙线 = 增加 UPCL（full）；同色不同线型区分第几架无人机。在上方下拉框里可选「★全局最优」或 29 个宿主算法中的任意一个；点缩略图放大后，弹窗里同样能切换算法，并可把图片连同标题与图例一起导出，直接插入论文。')}
        </div>
        <div id="uav-repr-grid" class="uav-repr-grid"><div class="hint">${LASE.t('加载中…')}</div></div>
      </div>
      <div class="card" id="uav-outcome-card" style="display:none">
        <div class="card-title">${LASE.t('无人机结局说明')}</div>
        <div class="muted" style="font-size:12px; margin-bottom:8px">${LASE.t('逐架列出每架无人机本局的结局与失败原因；被击落 / 坠毁条目可点击播放局部动画。')}</div>
        <div id="uav-outcome-list"></div>
      </div>
      <div class="card" id="uav-soldier-card" style="display:none">
        <div class="card-title">${LASE.t('士兵结局说明')}</div>
        <div class="muted" style="font-size:12px; margin-bottom:8px">${LASE.t('逐人列出蓝方步兵与红方巡逻兵本局的结局（阵亡 / 存活 / 抵达基地）与剩余血量。')}</div>
        <div id="uav-soldier-list"></div>
      </div>
      <div class="card">
        <div class="card-title" style="display:flex; align-items:center; justify-content:space-between; gap:12px">
          <span id="uav-map-title" style="white-space:nowrap; flex:1 1 auto; min-width:0">${LASE.t('战场俯视图')}</span>
          <span style="display:flex; gap:6px; align-items:center; flex:0 0 auto; white-space:nowrap">
            <span class="row" id="uav-viewmode" style="gap:4px; display:none">
              <button class="btn" data-vm="3d">${LASE.t('3D 沙盘')}</button>
              <button class="btn" data-vm="2d">${LASE.t('2D 俯视图')}</button>
            </span>
            <button class="btn" id="uav-drop-view" style="display:none">${LASE.t('投放视角')}</button>
            <button class="btn" id="uav-map-download">${LASE.t('下载图片')}</button>
            <button class="btn" id="uav-video">${LASE.t('保存视频')}</button>
          </span>
        </div>
        <div class="legend" id="uav-legend" style="margin-bottom:6px">
          <span><span class="dot" style="background:#2c7a4b"></span>${LASE.t('到达')}</span>
          <span><span class="dot" style="background:#2c5f8a"></span>${LASE.t('飞行中')}</span>
          <span><span class="dot" style="background:#c0392b"></span>${LASE.t('被击落')}</span>
          <span><span class="dot" style="background:#e67e22"></span>${LASE.t('直升机（圆锥=侦察范围）')}</span>
          <span><span class="dot" style="background:#ff2020"></span>${LASE.t('防空车（红色锥=对空范围）')}</span>
          <span><span class="dot" style="background:#ffb347"></span>${LASE.t('拦截导弹')}</span>
          <span><span class="dot" style="background:#3cb371"></span>${LASE.t('预警雷达范围')}</span>
          <span><span class="dot" style="background:#f5c518"></span>${LASE.t('直升机停靠点（H）')}</span>
          <span><span class="dot" style="background:#888"></span>${LASE.t('禁飞区')}</span>
        </div>
        <div class="muted" id="uav-3d-hint" style="display:none; font-size:12px; margin-bottom:4px">${LASE.t('🖱 左键拖拽旋转 · 滚轮缩放（跟随光标） · 右键平移 · 单击地形聚焦该点；也可用下方视角按钮')}</div>
        <div class="row" id="uav-3d-viewctl" style="display:none; margin-bottom:8px; gap:4px">
          <button class="btn" data-view="rot-l">${LASE.t('◀ 左转')}</button>
          <button class="btn" data-view="rot-r">${LASE.t('右转 ▶')}</button>
          <button class="btn" data-view="pitch-up">${LASE.t('俯视 ▲')}</button>
          <button class="btn" data-view="pitch-down">${LASE.t('平视 ▼')}</button>
          <button class="btn" data-view="zoom-in">${LASE.t('放大 ＋')}</button>
          <button class="btn" data-view="zoom-out">${LASE.t('缩小 －')}</button>
          <button class="btn" data-view="reset">${LASE.t('重置视角')}</button>
        </div>
        <canvas id="uav-map"></canvas>
        <div class="chart" id="uav-map-3d" style="display:none;height:640px"></div>
        <div class="row" style="margin-top:8px; align-items:center">
          <button class="btn" id="uav-play">${LASE.t('▶ 播放')}</button>
          <button class="btn" id="uav-kill">${LASE.t('击落细节')}</button>
          <select id="uav-rate" title="${LASE.t('播放倍速')}" style="padding:4px 6px; border:1px solid var(--line); border-radius:6px; background:var(--bg2, #fff); color:var(--text, #333); font-size:12px">
            <option value="0.25">0.25×</option>
            <option value="0.5">0.5×</option>
            <option value="1" selected>1×</option>
            <option value="1.25">1.25×</option>
            <option value="1.5">1.5×</option>
          </select>
          <input type="range" id="uav-slider" min="0" max="0" value="0" style="flex:1">
          <span class="muted mono" id="uav-frame-label">0/0</span>
        </div>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('收敛曲线')}</div>
        <div class="chart-sm" id="uav-conv"></div>
      </div>
      <div class="card" id="uav-red-detail" style="display:none"></div>
      <div class="card">
        <div class="card-title">${LASE.t('蓝方实景轨迹')}</div>
        <div class="muted" style="font-size:12px; margin-bottom:8px">${LASE.t('在地形高程实景上，用曲线还原蓝方全部单位的行动轨迹：无人机（蓝）、步兵（橙）。')}</div>
        <div class="chart" id="uav-live-trace" style="height:520px"></div>
      </div>
      <div class="card">
        <div class="card-title" style="display:flex; align-items:center; justify-content:space-between">
          <span>${LASE.t('数据存档')}</span>
          <span style="display:flex; gap:6px">
            <button class="btn" id="uav-archive-save">${LASE.t('保存当前结果')}</button>
            <button class="btn" id="uav-archive-del-sel" disabled>${LASE.t('删除选中')}</button>
            <button class="btn danger" id="uav-archive-clear" disabled>${LASE.t('清空全部')}</button>
          </span>
        </div>
        <div class="muted" style="font-size:12px; margin-bottom:8px">${LASE.t('勾选后可批量删除，或一键清空；点击「加载」可回放查看。')}</div>
        <div id="uav-archive-list" class="hint">${LASE.t('加载中…')}</div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    this._convChart = echarts.init(document.getElementById('uav-conv'));
    this._traceChart = echarts.init(document.getElementById('uav-live-trace'));
    this._buildCfg();
    document.getElementById('uav-desc').onclick = () => this._showDescription();
    document.getElementById('uav-paper').onclick = () => this._showPaperData();
    document.getElementById('uav-repr-refresh').onclick = () => this._loadRepr(true);
    document.getElementById('uav-repr-grid').onclick = (e) => this._reprClick(e);
    document.getElementById('uav-load-map').onclick = () => this._loadMap();
    document.getElementById('uav-pretrain').onclick = () => this._pretrain();
    document.getElementById('uav-run').onclick = () => this._run();
    document.getElementById('uav-cancel').onclick = () => this._cancel();
    document.getElementById('uav-play').onclick = () => this._togglePlay();
    document.getElementById('uav-rate').onchange = (e) => this._setRate(e);
    document.getElementById('uav-kill').onclick = () => this._showKillDetail();
    document.getElementById('uav-map-download').onclick = () => this._downloadMap();
    document.getElementById('uav-video').onclick = () => this._exportVideo();
    document.getElementById('uav-drop-view').onclick = () => this._showDropView();
    document.getElementById('uav-3d-viewctl').onclick = (e) => this._viewCtl(e);
    document.getElementById('uav-viewmode').onclick = (e) => this._viewModeClick(e);
    document.getElementById('uav-archive-save').onclick = () => this._archiveSave();
    document.getElementById('uav-archive-del-sel').onclick = () => this._archiveDeleteSelected();
    document.getElementById('uav-archive-clear').onclick = () => this._archiveClear();
    document.getElementById('uav-archive-list').onclick = (e) => this._archiveClick(e);
    document.getElementById('uav-archive-list').onchange = (e) => this._archiveChange(e);
    document.getElementById('uav-slider').oninput = (e) => {
      this._frame = parseInt(e.target.value); this._draw();
    };
    LASE.bindChartSave('uav-conv', this._convChart, LASE.t('无人机-收敛曲线'));
    LASE.bindChartSave('uav-live-trace', this._traceChart, LASE.t('无人机-实景轨迹'));
    this._archiveSelected = new Set();
    this._archiveSyncToolbar();
    this._archiveLoad();
    this._loadRepr();          // 代表轨迹面板：4 场景 × 4 任务缩略图（懒加载，不阻塞页面）
    window.addEventListener('resize', () => this._resizeCanvas());
  },

  show() {
    [this._convChart, this._traceChart].forEach(ch => ch && ch.resize());
    this._resizeCanvas();
  },

  _buildCfg() {
    const meta = LASE.meta, u = LASE.uavMeta;
    this._scenarioNames = (u && u.scenario_names) || {};
    const cfg = document.getElementById('uav-cfg');
    cfg.innerHTML = '';
    // 优化视角：同一张实景地图，可选「设计蓝方逃逸航迹」或「设计红方防御部署」。
    // 后者把 F1-F4 读成红方课题（F1 兵力部署 / F2 预警 / F3 拦截 / F4 协同），
    // 蓝方改由固定的对手方案提供（直扑 / 强突防 best-of-N）。
    this._viewSel = LASE.select(cfg, LASE.t('优化视角'),
      [['blue', LASE.t('蓝方突防（设计逃逸航迹）')],
       ['red', LASE.t('红方防御（设计防御部署）')]], 'blue',
      () => this._onViewChange(), () => this._viewHintHtml());
    // 场景下拉框显示中文名（value 仍为英文 id，供后端识别）
    const scenOpts = (u.scenarios || []).map(s =>
      [s, LASE.t((u.scenario_names && u.scenario_names[s]) || s)]);
    this._scenSel = LASE.select(cfg, LASE.t('场景'), scenOpts, 'intercept',
      () => this._onScenarioChange(),
      () => {
        const si = LASE.scenarioInfo[this._scenSel.value];
        return si ? '<p>' + LASE._esc(LASE.t(si.desc)) + '</p>' : '';
      });
    // 任务（fid）下拉：同一场景下的多个任务。实景突防场景（地图一）的 F1-F4
    // 共享同一张地图，只有红方防御强度（拦截者数 / 禁飞区 / 拦截速度）不同。
    this._taskSel = LASE.select(cfg, LASE.t('任务'),
      this._taskOptions('intercept'), '1',
      () => this._onTaskChange(),
      () => this._taskHintHtml());
    this._hostSel = LASE.select(cfg, LASE.t('算法'), u.hosts, 'SHADE', null,
      () => LASE.hostInfoHtml(this._hostSel.value));
    this._armSel = LASE.select(cfg, LASE.t('模式'), [['bare', LASE.t('纯算法')], ['full', LASE.t('UPCL 增强')]], 'bare', null,
      '<p>' + LASE._esc(LASE.t(LASE.upclIntro)) + '</p>');
    this._coevSel = LASE.select(cfg, LASE.t('协同演化'),
      [['0', LASE.t('关闭（红方规则/DRL）')], ['1', LASE.t('开启（红蓝双方交替演化）')]], '0',
      () => this._syncDrlControls());
    this._diffSel = LASE.select(cfg, LASE.t('拦截难度'),
      (u.difficulty_options || []).map(v => [v, LASE.t(v)]), u.difficulty_options[0],
      () => this._syncDrlControls(),
      () => {
        const di = LASE.difficultyInfo[this._diffSel.value];
        return di ? '<p>' + LASE._esc(LASE.t(di.d)) + '</p>' : '';
      });
    this._drlSel = LASE.select(cfg, LASE.t('DRL 算法'),
      (u.drl_algo_options || []).map(v => [v, LASE.t(v)]), u.drl_algo_options[0], null,
      () => {
        const di = LASE.drlInfo[this._drlSel.value];
        return di ? '<p>' + LASE._esc(LASE.t(di.d)) + '</p>' : '';
      });
    this._captureInp = LASE.numInput(cfg, LASE.t('目标捕获率'), 0.6, 0.1, 1.0, 0.05);
    this._evalsInp = LASE.numInput(cfg, LASE.t('评估预算 ×D'), 300, 50, 5000, 50);
    this._wpInp = LASE.numInput(cfg, LASE.t('航点数(0=默认)'), 0, 0, 10, 1);
    this._cargoInp = LASE.numInput(cfg, LASE.t('运输机数(0=默认)'), 0, 0, 20, 1);
    this._relayInp = LASE.numInput(cfg, LASE.t('中继机数(0=默认)'), 0, 0, 20, 1);
    this._attackInp = LASE.numInput(cfg, LASE.t('逃逸无人机数(0=默认)'), 0, 0, 20, 1);
    this._infantryInp = LASE.numInput(cfg, LASE.t('蓝方步兵数(0=默认)'), 0, 0, 30, 1);
    // ===== 红方视角专属字段（默认隐藏，切到「红方防御」后显示）=====
    // 算法 / 评估预算 ×D / 任务(fid) 三个控件蓝红两侧共用：红方视角下它们分别
    // 表示「红方优化算法」「红方预算」「想定」。
    const rm = this._redMeta() || {};
    const rdef = rm.defaults || {};
    const tnames = rm.topic_names || {};
    this._redTopicSel = LASE.select(cfg, LASE.t('红方课题'),
      (rm.topic_order || []).map(m => [m, LASE.t(tnames[m] || m)]),
      rdef.mode || 'intercept',
      () => this._syncRedControls(), () => this._redTopicHint());
    this._redOppSel = LASE.select(cfg, LASE.t('蓝方对手'),
      (rm.opponents || []).map(o => [o.key, LASE.t(o.label)]),
      rdef.opponent || 'straight',
      () => this._syncRedControls(), () => this._redOppHint());
    this._redRunsInp = LASE.numInput(cfg, LASE.t('强突防求解次数'),
      rdef.blue_runs || 3, 1, 10, 1);
    this._redBlueEvalsInp = LASE.numInput(cfg, LASE.t('强突防预算 ×D'),
      rdef.blue_evals || 2000, 200, 20000, 200);
    this._syncRedControls();
  },

  // ===== 任务（fid）选择：场景 → 任务 → 该任务的场景信息 =====
  // 实景突防场景（地图一）的 F1-F4 是同一张地图上的四个任务，只有红方
  // 防御强度不同；任务清单与配置摘要由后端 /api/uav/meta 下发。

  _taskOptions(scen) {
    const u = LASE.uavMeta || {};
    const list = (u.task_options && u.task_options[scen]) || [1];
    return list.map(f => [String(f), this._taskLabel(scen, f)]);
  },

  _taskLabel(scen, fid) {
    const ti = this._taskInfo(scen, fid);
    const base = 'F' + fid;
    return (ti && ti.name) ? (base + ' · ' + LASE.t(ti.name)) : base;
  },

  _taskInfo(scen, fid) {
    const u = LASE.uavMeta || {};
    const m = (u.task_infos && u.task_infos[scen]) || {};
    return m[String(fid)] || null;
  },

  // 当前选中的任务编号（fid）：仿真 / 预训练 / 地形 / 场景说明请求统一用它
  _fid() {
    const v = this._taskSel ? parseInt(this._taskSel.value) : 1;
    return Number.isFinite(v) && v > 0 ? v : 1;
  },

  // 任务下拉的「说明」气泡：本任务的红方配置摘要
  _taskHintHtml() {
    const scen = this._scenSel ? this._scenSel.value : 'intercept';
    const ti = this._taskInfo(scen, this._fid());
    if (!ti) return '';
    const bits = [];
    if (ti.n_interceptors != null)
      bits.push(LASE.t('拦截者 {0} 架', ti.n_interceptors));
    if (ti.interceptor_speed != null)
      bits.push(LASE.t('拦截速度 {0}/步', ti.interceptor_speed));
    bits.push(ti.n_no_fly_zones ? LASE.t('禁飞区 {0} 个', ti.n_no_fly_zones)
      : LASE.t('无禁飞区'));
    const rows = [];
    if (ti.dim) rows.push('<p>' + LASE.t('维度 D={0}', ti.dim) + '</p>');
    if (bits.length) rows.push('<p>' + LASE._esc(bits.join(' · ')) + '</p>');
    if (scen === 'intercept')
      rows.push('<p class="muted">' + LASE._esc(LASE.t(
        'F1-F4 为同一张实景地图上的四个任务：地形、楼房、起飞点与敌我初始部署完全相同，只有红方防御强度递增。')) + '</p>');
    return rows.join('');
  },

  // 场景变化后重建任务下拉（不同场景任务数不同），尽量保留已选任务号。
  // 目前仅实景突防场景（地图一）支持任务切换：其他场景的 fid 语义对应不同的
  // 编码方式（洪涝为排列编码 / 航点编码），GUI 尚未暴露，故隐藏任务下拉并
  // 固定回 fid=1，保持既有行为不变。
  _syncTaskOptions() {
    if (!this._taskSel) return;
    const scen = this._scenSel ? this._scenSel.value : 'intercept';
    const keep = this._taskSel.value;
    const opts = this._taskOptions(scen);
    this._taskSel.innerHTML = '';
    opts.forEach(([v, t]) => {
      const op = document.createElement('option');
      op.value = v; op.textContent = t;
      this._taskSel.appendChild(op);
    });
    const supported = (scen === 'intercept');
    if (supported) {
      this._taskSel.value = opts.some(o => o[0] === keep) ? keep : opts[0][0];
    } else {
      this._taskSel.value = '1';
    }
    const wrap = this._taskSel.parentElement;
    if (wrap) wrap.style.display = supported ? '' : 'none';
  },

  _onTaskChange() {
    // 切换任务：清空旧结果（新任务的红方配置 / 禁飞区不同），需重跑或重载地形
    this._resetResult();
    const scen = this._scenSel ? this._scenSel.value : 'intercept';
    const prog = document.getElementById('uav-prog');
    if (prog) prog.textContent = LASE.t('已切换到 {0}',
      this._taskLabel(scen, this._fid()));
  },

  _isFloodScenario(s) {
    return s === 'flood' || s === 'flood_v2';
  },

  // 三维渲染场景：flood / flood_v2 之外，intercept / swarm 也使用三维山地对抗渲染
  _is3dScenario(s) {
    return s === 'flood' || s === 'flood_v2' || s === 'intercept' || s === 'swarm';
  },

  _isFlood() {
    return this._isFloodScenario(this._scenSel && this._scenSel.value);
  },

  _is3d() {
    return this._is3dScenario(this._scenSel && this._scenSel.value);
  },

  _isDrlDifficulty() {
    return ((this._diffSel && this._diffSel.value) || '').includes('强化学习');
  },

  _onScenarioChange() {
    // 切换场景：清空旧结果与 3D 图，避免 2D/3D 渲染错位；任务清单随场景重建
    this._resetResult();
    this._syncTaskOptions();
    this._syncDrlControls();
  },

  // 清空旧结果与三维视图（切换场景 / 任务后调用）
  _resetResult() {
    this._result = null;
    this._disposeSandbox();
    this._hideRedDetail();
    if (this._map3dChart) { this._map3dChart.dispose(); this._map3dChart = null; }
    const cv = document.getElementById('uav-map');
    const d3 = document.getElementById('uav-map-3d');
    const hint = document.getElementById('uav-3d-hint');
    const drop = document.getElementById('uav-drop-view');
    const vc = document.getElementById('uav-3d-viewctl');
    if (cv) cv.style.display = '';
    if (d3) d3.style.display = 'none';
    if (hint) hint.style.display = 'none';
    if (drop) drop.style.display = 'none';
    if (vc) vc.style.display = 'none';
    this._view = null;
  },

  _syncDrlControls() {
    const flood = this._isFlood();
    const coev = !!this._coevSel && this._coevSel.value === '1';
    // 协同演化：红方运动由巡逻航点（red_x）+ 规则追击驱动，后端会忽略 opponent，
    // 因此「无对手」与「强化学习」档在协同演化下失效，禁用并自动回退到规则拦截档。
    if (this._diffSel) {
      const invalid = v => coev && (v.includes('强化学习') || v.includes('无对手'));
      const cur = this._diffSel.value;
      [...this._diffSel.options].forEach(op => { op.disabled = invalid(op.value); });
      if (invalid(cur)) {
        const l1 = [...this._diffSel.options].find(o => o.value.includes('规则拦截'));
        if (l1) this._diffSel.value = l1.value;
      }
    }
    const drl = !flood && !coev && this._isDrlDifficulty();
    // 三维救援场景无对抗对手，隐藏难度/DRL/捕获率/预训练
    if (this._diffSel && this._diffSel.parentElement)
      this._diffSel.parentElement.style.display = flood ? 'none' : '';
    [this._drlSel, this._captureInp].forEach(s => {
      if (s && s.parentElement) s.parentElement.style.display = drl ? '' : 'none';
    });
    // 协同演化：仅对抗/集群场景有效（红蓝双方航点交替演化）；洪涝无对抗对手，隐藏
    if (this._coevSel && this._coevSel.parentElement)
      this._coevSel.parentElement.style.display = flood ? 'none' : '';
    // 航点数：仅对抗/集群场景有效（每架无人机路径点数 K）；
    // 洪涝 fid=1 为排列编码，无航点数概念，隐藏
    if (this._wpInp && this._wpInp.parentElement)
      this._wpInp.parentElement.style.display = flood ? 'none' : '';
    // 中继机数：仅洪涝场景有效（参与维度 D = n_service*2 + n_relay*3）
    if (this._relayInp && this._relayInp.parentElement)
      this._relayInp.parentElement.style.display = flood ? '' : 'none';
    // 运输机数：当前 GUI 固定 fid=1（排列编码，固定 8 架实体机），n_cargo 不参与
    // 维度与调度，属死选项，隐藏；日后暴露 waypoints 编码（fid=3/4）再启用
    if (this._cargoInp && this._cargoInp.parentElement)
      this._cargoInp.parentElement.style.display = 'none';
    // 逃逸无人机数：仅集群突防场景有效（起点一致、各自航点轨迹随机）
    const swarm = this._scenSel && this._scenSel.value === 'swarm';
    if (this._attackInp && this._attackInp.parentElement)
      this._attackInp.parentElement.style.display = swarm ? '' : 'none';
    // 蓝方步兵数：仅突防对抗场景有效（蓝方士兵协同无人机进攻，参与维度 D）
    const intercept = this._scenSel && this._scenSel.value === 'intercept';
    if (this._infantryInp && this._infantryInp.parentElement)
      this._infantryInp.parentElement.style.display = intercept ? '' : 'none';
    const btn = document.getElementById('uav-pretrain');
    if (btn) btn.style.display = drl ? '' : 'none';
    this._syncScenarioUi();
  },

  _syncScenarioUi() {
    const flood = this._isFlood();
    const sc = this._scenSel && this._scenSel.value;
    const title = document.getElementById('uav-map-title');
    if (title) title.textContent = this._isRed()
      ? LASE.t('三维山地 · 红方防御优化视图')
      : (flood ? LASE.t('山区地形 · 三维救援视图')
      : (sc === 'swarm' ? LASE.t('三维山地 · 集群突防对抗视图')
        : sc === 'intercept' ? LASE.t('三维山地 · 突防对抗视图') : LASE.t('战场俯视图')));
    const legend = document.getElementById('uav-legend');
    if (legend) legend.innerHTML = flood
      ? `<span><span class="dot" style="background:#2c7a4b"></span>${LASE.t('投送成功')}</span>
         <span><span class="dot" style="background:#2c5f8a"></span>${LASE.t('飞行中')}</span>
         <span><span class="dot" style="background:#c0392b"></span>${LASE.t('电池耗尽')}</span>
         <span><span class="dot" style="background:#7d3c98"></span>${LASE.t('中继机')}</span>
         <span><span class="dot" style="background:#e67e22"></span>${LASE.t('受灾点')}</span>
         <span><span class="dot" style="background:#1a1a1a"></span>${LASE.t('救灾基地')}</span>`
      : (sc === 'swarm'
        ? `<span><span class="dot" style="background:#2c7a4b"></span>${LASE.t('突破成功')}</span>
           <span><span class="dot" style="background:#2c5f8a"></span>${LASE.t('突防中')}</span>
           <span><span class="dot" style="background:#c0392b"></span>${LASE.t('被拦截')}</span>
           <span><span class="dot" style="background:#7d3c98"></span>${LASE.t('坠毁（能源耗尽）')}</span>
           <span><span class="dot" style="background:#e67e22"></span>${LASE.t('红方直升机（圆锥=协同拦截）')}</span>
           <span><span class="dot" style="background:#556b2f"></span>${LASE.t('地面防空车')}</span>
           <span><span class="dot" style="background:#1a5276"></span>${LASE.t('峡谷/瀑布（防空车不可跨越）')}</span>
           <span><span class="dot" style="background:#ff6b6b"></span>${LASE.t('球形禁飞区')}</span>
           <span><span class="dot" style="background:#f5c518"></span>${LASE.t('直升机停靠点（H）')}</span>
           <span><span class="dot" style="background:#8a6f4d"></span>${LASE.t('山地（可遮挡 LOS）')}</span>`
        : `<span><span class="dot" style="background:#2c7a4b"></span>${LASE.t('到达')}</span>
           <span><span class="dot" style="background:#2c5f8a"></span>${LASE.t('飞行中')}</span>
           <span><span class="dot" style="background:#c0392b"></span>${LASE.t('被击落')}</span>
           <span><span class="dot" style="background:#7d3c98"></span>${LASE.t('坠毁（能源耗尽）')}</span>
           <span><span class="dot" style="background:#e67e22"></span>${LASE.t('直升机（圆锥=侦察范围）')}</span>
           <span><span class="dot" style="background:#ff6b6b"></span>${LASE.t('球形禁飞区')}</span>
           <span><span class="dot" style="background:#3cb371"></span>${LASE.t('预警雷达范围')}</span>
           <span><span class="dot" style="background:#f5c518"></span>${LASE.t('直升机停靠点（H）')}</span>
           <span><span class="dot" style="background:#8a6f4d"></span>${LASE.t('山地（可遮挡 LOS）')}</span>`);
    // 红方视角额外画出防空车与巡逻兵（红方的火力/感知单元）
    if (legend && this._isRed())
      legend.innerHTML += `<span><span class="dot" style="background:#556b2f"></span>${LASE.t('地面防空车')}</span>`;
  },

  _runTaskId: null,

  async _run() {
    if (this._isRed()) return this._runRed();   // 红方视角走 /api/uav/red/run
    const prog = document.getElementById('uav-prog');
    prog.textContent = '';
    const bar = LASE.prog('uav-prog-bar');
    bar.start(LASE.t('仿真中…'));
    const body = {
      scenario: this._scenSel.value, fid: this._fid(),
      n_waypoints: parseInt(this._wpInp.value) || null,
      n_cargo: parseInt(this._cargoInp.value) || null,
      n_relay: parseInt(this._relayInp.value) || null,
      n_attack: parseInt(this._attackInp.value) || null,
      n_infantry: parseInt(this._infantryInp.value) || null,
      host: this._hostSel.value, evals_mult: parseInt(this._evalsInp.value),
      arm: this._armSel.value, difficulty: this._diffSel.value,
      drl_algo: this._drlSel.value,
      coevolve: this._coevSel.value === '1',
    };
    const r = await LASE.api('/api/uav/run', { method: 'POST', body });
    this._runTaskId = r.task_id;
    LASE.taskPoll(r.task_id, {
      onProgress: (p, m) => bar.set(p, m),
      onDone: (data) => { bar.done(LASE.t('仿真完成')); this._renderResult(data); },
      onError: (e) => {
        bar.fail(e === 'cancelled' ? LASE.t('已取消') : LASE.t('仿真失败：') + e);
      },
    });
  },

  async _pretrain() {
    const prog = document.getElementById('uav-prog');
    prog.textContent = '';
    const bar = LASE.prog('uav-prog-bar');
    bar.start(LASE.t('预训练中…'));
    const body = {
      scenario: this._scenSel.value, fid: this._fid(),
      n_waypoints: parseInt(this._wpInp.value) || null,
      difficulty: this._diffSel.value, drl_algo: this._drlSel.value,
      target_capture: parseFloat(this._captureInp.value) || 0.6,
    };
    const r = await LASE.api('/api/uav/pretrain', { method: 'POST', body });
    this._runTaskId = r.task_id;
    LASE.taskPoll(r.task_id, {
      onProgress: (p, m) => bar.set(p, m || LASE.t('预训练 {0}%', Math.round(p * 100))),
      onDone: (data) => {
        if (data && data.ok === false) {
          bar.fail(data.msg || LASE.t('无需预训练'));
          return;
        }
        const cr = (data.capture_rate || 0) * 100;
        const msg = LASE.t('预训练完成：捕获率 {0}%', cr.toFixed(0)) +
          (data.reached ? LASE.t('（已达标）') : LASE.t('（未达标）')) + LASE.t('，可直接开始仿真');
        if (data.reached) bar.done(msg); else bar.fail(msg);
      },
      onError: (e) => {
        bar.fail(e === 'cancelled' ? LASE.t('已取消') : LASE.t('预训练失败：') + e);
      },
    });
  },

  async _cancel() {
    if (this._runTaskId) await LASE.api('/api/task/' + this._runTaskId + '/cancel', { method: 'POST' });
  },

  // ===== 优化视角（蓝方突防 / 红方防御）=====
  // 同一张实景地图的两种读法：blue = 优化蓝方逃逸航迹（红方按固定规则追击），
  // red = 固定一名蓝方对手、优化红方部署。后端分别是 /api/uav/run 与
  // /api/uav/red/run，两者返回同源的 geometry / frames / conv，因此战场俯视图、
  // 三维沙盘、收敛曲线与结局卡片全部共用，只有汇总口径不同。

  _isRed() {
    return !!this._viewSel && this._viewSel.value === 'red';
  },

  _viewHintHtml() {
    if (this._isRed())
      return '<p>' + LASE._esc(LASE.t(
        '红方视角：固定一个蓝方突防方案（直扑 / 强突防），优化红方的部署、预警与拦截协同；代价越小越好。')) + '</p>';
    return '<p>' + LASE._esc(LASE.t(
      '蓝方视角：优化 F1-F4 的突防航迹，红方按固定规则（最近存活目标追击 + 速度优势）拦截。')) + '</p>';
  },

  _onViewChange() {
    this._resetResult();
    // 红方课题只存在于实景突防场景（intercept），切到红方视角时把场景锁死
    if (this._isRed() && this._scenSel && this._scenSel.value !== 'intercept') {
      this._scenSel.value = 'intercept';
      this._syncTaskOptions();
    }
    const desc = document.getElementById('uav-desc');
    if (desc) desc.textContent = LASE.t(this._isRed() ? '课题说明' : '场景说明');
    this._syncRedControls();
  },

  _redMeta() {
    return (LASE.uavMeta && LASE.uavMeta.red) || null;
  },

  _redTopicInfo() {
    const rm = this._redMeta();
    const mode = this._redTopicSel ? this._redTopicSel.value : '';
    return ((rm && rm.topics) || []).find(t => t.mode === mode) || null;
  },

  // 红方视角下的控件可见性：隐藏蓝方专属项（模式/协同演化/难度/DRL/捕获率/
  // 航点数/步兵数等），显示课题 / 蓝方对手 / 强突防预算
  _syncRedControls() {
    this._syncDrlControls();          // 先按蓝方口径恢复一次可见性
    const red = this._isRed();
    const set = (el, vis) => { if (el && el.parentElement) el.parentElement.style.display = vis ? '' : 'none'; };
    set(this._redTopicSel, red);
    set(this._redOppSel, red);
    const best = red && this._redOppSel && this._redOppSel.value === 'best';
    set(this._redRunsInp, best);
    set(this._redBlueEvalsInp, best);
    if (red) {
      [this._armSel, this._coevSel, this._diffSel, this._drlSel, this._captureInp,
       this._wpInp, this._attackInp, this._infantryInp, this._cargoInp, this._relayInp]
        .forEach(el => set(el, false));
      if (this._scenSel) this._scenSel.disabled = true;
      const pre = document.getElementById('uav-pretrain');   // 预训练只服务蓝方 DRL 对手
      if (pre) pre.style.display = 'none';
      const btip = document.getElementById('uav-blue-tip');  // 蓝方建议流程提示不适用红方
      if (btip) btip.style.display = 'none';
    } else {
      if (this._scenSel) this._scenSel.disabled = false;
      const btip = document.getElementById('uav-blue-tip');
      if (btip) btip.style.display = '';
      // 切回蓝方视角：恢复被红方视角藏起来的字段（模式 / 协同演化等与场景相关）
      const sc = this._scenSel ? this._scenSel.value : 'intercept';
      const floodNow = this._isFlood();
      set(this._armSel, true);
      set(this._coevSel, !floodNow);
      set(this._wpInp, !floodNow);
      set(this._attackInp, sc === 'swarm');
      set(this._infantryInp, sc === 'intercept');
    }
    const run = document.getElementById('uav-run');
    if (run) run.textContent = LASE.t(red ? '开始优化' : '开始仿真');
    const hint = document.getElementById('uav-view-hint');
    if (hint && red) {
      const ti = this._redTopicInfo();
      const dim = ti && ti.dims ? ti.dims[String(this._fid())] : null;
      const bits = [LASE.t('红方流程：选「红方课题」与「蓝方对手」，再点「开始仿真」优化红方部署。')];
      if (dim) bits.push(LASE.t('本课题在 {0} 下决策维度 D={1}', 'U' + this._fid(), dim));
      if (ti) bits.push(LASE.t('{0} 个决策槽位', ti.n_slots));
      if (ti && ti.c5_exempt) bits.push(LASE.t('已豁免 C5'));
      hint.style.display = '';
      hint.textContent = bits.join(' · ');
    } else if (hint) {
      hint.style.display = 'none';
      hint.textContent = '';
    }
    this._syncScenarioUi();
  },

  _redTopicHint() {
    const ti = this._redTopicInfo();
    if (!ti) return '';
    const dims = ti.dims || {};
    const rows = ['<p>' + LASE._esc(Object.keys(dims)
      .map(f => 'U' + f + ' D=' + dims[f]).join(' · ')) + '</p>'];
    rows.push('<p>' + LASE._esc(LASE.t('{0} 个决策槽位，详见「课题说明」', ti.n_slots)) + '</p>');
    if (ti.c5_exempt)
      rows.push('<p class="muted">' + LASE._esc(LASE.t(
        '本课题豁免 C5（停机坪可在雷达探测范围内），停机坪部署区域放开到全图。')) + '</p>');
    return rows.join('');
  },

  _redOppHint() {
    const rm = this._redMeta();
    const key = this._redOppSel ? this._redOppSel.value : '';
    const o = ((rm && rm.opponents) || []).find(x => x.key === key);
    return o ? '<p>' + LASE._esc(LASE.t(o.text)) + '</p>' : '';
  },

  async _runRed() {
    const prog = document.getElementById('uav-prog');
    if (prog) prog.textContent = '';
    const bar = LASE.prog('uav-prog-bar');
    bar.start(LASE.t('红方优化中…'));
    const best = this._redOppSel && this._redOppSel.value === 'best';
    const body = {
      mode: this._redTopicSel.value,
      fid: this._fid(),
      host: this._hostSel.value,
      evals_mult: parseInt(this._evalsInp.value) || 200,
      opponent: this._redOppSel.value,
      blue_runs: best ? (parseInt(this._redRunsInp.value) || 3) : 1,
      blue_evals: best ? (parseInt(this._redBlueEvalsInp.value) || 2000) : 0,
      seed: 1,
    };
    let r;
    try {
      r = await LASE.api('/api/uav/red/run', { method: 'POST', body });
    } catch (e) {
      bar.fail(LASE.t('红方优化失败：') + (e && e.message ? e.message : e));
      return;
    }
    this._runTaskId = r.task_id;
    LASE.taskPoll(r.task_id, {
      onProgress: (p, m) => bar.set(p, m),
      onDone: (data) => { bar.done(LASE.t('优化完成')); this._renderResult(data); },
      onError: (e) => {
        bar.fail(e === 'cancelled' ? LASE.t('已取消') : LASE.t('红方优化失败：') + e);
      },
    });
  },

  _hideRedDetail() {
    const box = document.getElementById('uav-red-detail');
    if (box) { box.style.display = 'none'; box.innerHTML = ''; }
  },

  // 红方口径的统计卡：代价 / 基线增益 / 可行性 / 蓝方突防与击落
  _redStatsHtml(r) {
    const b = r.baseline || {};
    const bc = (typeof b.cost === 'number') ? b.cost : null;
    // 代价越小越好，故「改善」= 基线代价 - 优化后代价，正值才是变好
    const gain = (bc !== null && typeof r.cost === 'number') ? bc - r.cost : null;
    const pct = (gain !== null && bc) ? gain / Math.abs(bc) * 100 : null;
    const gap = (r.coverage || {}).gap;
    const col = (v) => v === null ? '#334155'
      : (v > 0 ? '#2c7a4b' : (v < 0 ? '#c0392b' : '#8899aa'));
    const feas = r.feasible ? LASE.t('可行') : LASE.t('违约 {0} 条', r.n_violations || 0);
    return `
      <div class="stat-box"><div class="v">${r.cost.toFixed(2)}</div><div class="k">${LASE.t('红方代价')}（${LASE.t('越小越好')}）</div></div>
      <div class="stat-box"><div class="v">${bc === null ? '—' : bc.toFixed(2)}</div><div class="k">${LASE.t('出厂基线代价')}</div></div>
      <div class="stat-box"><div class="v" style="color:${col(gain)}">${gain === null ? '—' : (gain > 0 ? '+' : '') + gain.toFixed(2)}</div><div class="k">${LASE.t('相对基线改善')}</div></div>
      <div class="stat-box"><div class="v" style="color:${col(pct)}">${pct === null ? '—' : (pct > 0 ? '+' : '') + pct.toFixed(1) + '%'}</div><div class="k">${LASE.t('改善比例')}</div></div>
      <div class="stat-box"><div class="v" style="color:${r.feasible ? '#2c7a4b' : '#c0392b'}">${feas}</div><div class="k">${LASE.t('约束可行性')}</div></div>
      <div class="stat-box"><div class="v">${r.arrived}/${r.n_drones}</div><div class="k">${LASE.t('蓝方突防成功')}</div></div>
      <div class="stat-box"><div class="v">${r.lost}</div><div class="k">${LASE.t('击落蓝方架次')}</div></div>
      <div class="stat-box"><div class="v">${typeof gap === 'number' ? (gap * 100).toFixed(1) + '%' : '—'}</div><div class="k">${LASE.t('覆盖缺口')}</div></div>
      <div class="stat-box"><div class="v">${r.dim}</div><div class="k">${LASE.t('决策维度')}</div></div>
      <div class="stat-box"><div class="v">${(r.wall_time_s || 0).toFixed(1)} s</div><div class="k">${LASE.t('总耗时')}</div></div>`;
  },

  // 红方优化结果卡片：逐指标对比（基线 → 优化后）/ 可行性 / 最优方案 /
  // 蓝方对手口径 / 约束清单 / 编成。数据全部来自 /api/uav/red/run 的 payload。
  _renderRedDetail(r) {
    const box = document.getElementById('uav-red-detail');
    if (!box) return;
    const esc = (s) => LASE._esc(s == null ? '' : String(s));
    const num = (v, d) => (typeof v === 'number' && isFinite(v))
      ? v.toFixed(d == null ? 2 : d) : '—';
    const tbl = (head, rows) => {
      const th = head.map((h, i) => `<th style="padding:6px 10px; background:#eef4fa; color:#2c5f8a; ` +
        `font-weight:600; white-space:nowrap; border-bottom:1px solid #cfdce8; ` +
        `text-align:${i ? 'right' : 'left'}">${esc(h)}</th>`).join('');
      const tr = rows.map(cs => '<tr>' + cs.map((c, i) =>
        `<td style="padding:6px 10px; border-bottom:1px solid #f0f3f7; ` +
        `text-align:${i ? 'right' : 'left'}${i ? '; white-space:nowrap' : ''}">${c}</td>`
      ).join('') + '</tr>').join('');
      return `<table style="border-collapse:collapse; width:100%; font-size:12.5px">` +
        `<thead><tr>${th}</tr></thead><tbody>${tr}</tbody></table>`;
    };
    const sec = (title, html, sub) => `<div style="margin-bottom:16px">` +
      `<div style="font-weight:700; color:#7d3c98; font-size:13px; margin-bottom:6px">${esc(title)}` +
      (sub ? `<span class="muted" style="font-weight:400; font-size:11.5px; margin-left:8px">${esc(sub)}</span>` : '') +
      `</div>${html}</div>`;

    const hdr = r.header || {};
    const parts = [`<div class="card-title">${esc(hdr.title || LASE.t('红方优化结果'))}</div>`];
    if (hdr.subtitle)
      parts.push(`<div class="muted" style="font-size:12px; margin:-6px 0 12px">${esc(hdr.subtitle)}</div>`);

    // 1. 逐指标对比：基线（出厂红方配置，同一蓝方对手下重放）→ 优化后
    const rows = (r.delta || []).map(d => {
      const up = d.direction === 'higher' || d.direction === 'up';
      const good = up ? d.delta > 0 : d.delta < 0;
      const bad = up ? d.delta < 0 : d.delta > 0;
      const c = good ? '#2c7a4b' : (bad ? '#c0392b' : '#8899aa');
      const verdict = good ? LASE.t('改善') : (bad ? LASE.t('变差') : LASE.t('持平'));
      return [`${esc(LASE.t(d.label))} <span style="color:#aab4bf">${up ? '↑' : '↓'}</span>`,
        num(d.base, 1), num(d.opt, 1),
        `<span style="color:${c}; font-weight:600">${d.delta > 0 ? '+' : ''}${num(d.delta, 1)}</span>`,
        `<span style="color:${c}">${esc(verdict)}</span>`];
    });
    if (rows.length)
      parts.push(sec(LASE.t('逐指标对比（基线 = 出厂红方配置，同一蓝方对手下重放）'),
        tbl([LASE.t('指标'), LASE.t('基线'), LASE.t('优化后'), LASE.t('变化'), LASE.t('判定')], rows),
        LASE.t('↑ 越大越好 · ↓ 越小越好')));

    // 2. 代价拆分 + 可行性 + 违约条目
    const vio = r.violations || [];
    const feas = `<div style="font-size:12.5px; line-height:1.9">` +
      `${esc(LASE.t('总代价 {0} = 目标值 {1} + 罚分 {2}', num(r.cost, 2), num(r.objective, 2), num(r.penalty, 2)))}<br>` +
      (vio.length
        ? `<span style="color:#c0392b">${esc(LASE.t('违反 {0} 条约束（分级罚分实现，罚分系数 800）', vio.length))}</span>` +
          vio.map(v => `<div style="margin-left:10px">· <b>${esc(v.code || '')}</b> ${esc(LASE.t(v.name))}` +
            `${v.severity ? `（${esc(LASE.t('严重度'))} ${num(v.severity, 2)}）` : ''}：${esc(v.text)}</div>`).join('')
        : `<span style="color:#2c7a4b">${esc(LASE.t('全部约束满足（可行解）'))}</span>`) +
      `</div>`;
    parts.push(sec(LASE.t('约束可行性'), feas));

    // 3. 最优解的可读描述
    const plan = r.plan || {};
    const pkeys = Object.keys(plan);
    if (pkeys.length) {
      const planHtml = `<table style="border-collapse:collapse; width:100%; font-size:12.5px"><tbody>` +
        pkeys.map(k => `<tr><td style="padding:5px 10px; border-bottom:1px solid #f0f3f7; ` +
          `color:#5a6b7b; width:210px">${esc(LASE.t(k))}</td>` +
          `<td style="padding:5px 10px; border-bottom:1px solid #f0f3f7">${esc(plan[k])}</td></tr>`).join('') +
        `</tbody></table>`;
      parts.push(sec(LASE.t('最优解（可读描述）'), planHtml));
    }

    // 4. 蓝方对手口径 + 耗时拆分
    if (r.blue) {
      parts.push(sec(LASE.t('蓝方对手口径'), `<div style="font-size:12.5px; line-height:1.9">` +
        `${esc(LASE.t('解算方式：{0}', r.opponent_label || ''))}<br>` +
        `${esc(LASE.t('蓝方最优突防解：{0}（{1} × {2} evals · {3}）',
          num(r.blue.cost, 2), r.blue.runs, r.blue.evals, r.blue.host))}<br>` +
        `${esc(LASE.t('优化耗时 {0}s（其中蓝方对手 {1}s）',
          num(r.wall_time_s, 1), num(r.blue_wall_s, 1)))}</div>`));
    } else {
      parts.push(sec(LASE.t('蓝方对手口径'), `<div style="font-size:12.5px">` +
        `${esc(LASE.t('蓝方对手为解析式直扑方案，无搜索开销；换「强突防」才考验红方。'))}</div>`));
    }

    // 5. 约束清单（C1..C6，标出本课题生效/豁免）
    const cs = r.constraints || [];
    if (cs.length) {
      parts.push(sec(LASE.t('约束条件（分级罚分实现，罚分系数 800）'),
        tbl([LASE.t('编号'), LASE.t('约束'), LASE.t('状态')],
          cs.map(c => [`<b>${esc(c.id)}</b>`, esc(LASE.t(c.name)) +
            (c.note ? `<div class="muted" style="font-size:11.5px; white-space:normal; text-align:left">${esc(LASE.t(c.note))}</div>` : ''),
            c.active ? `<span style="color:#c0392b">${esc(LASE.t('生效'))}</span>`
                     : `<span style="color:#2c7a4b">${esc(LASE.t('已豁免'))}</span>`]))));
    }

    // 6. 编成
    const FM = {
      n_drones: LASE.t('蓝方无人机'), n_infantry: LASE.t('蓝方步兵'),
      n_interceptors: LASE.t('红方直升机'), n_aa: LASE.t('防空车'),
      n_patrol: LASE.t('巡逻兵'), n_waypoints: LASE.t('航点数'),
      n_int_waypoints: LASE.t('拦截航路点数'), n_steps: LASE.t('仿真步数'),
      n_units: LASE.t('红方单元数'), n_attack: LASE.t('逃逸无人机数'),
    };
    const fm = r.formation || {};
    const fkeys = Object.keys(fm);
    if (fkeys.length)
      parts.push(sec(LASE.t('编成'), `<div style="font-size:12.5px; line-height:1.9">` +
        fkeys.map(k => `${esc(FM[k] || k)} ${fm[k]}`).join(' · ') + `</div>`));

    box.style.display = '';
    box.innerHTML = parts.join('');
  },

  async _loadMap() {
    const scen = this._scenSel ? this._scenSel.value : 'flood';
    if (!this._is3dScenario(scen)) {
      alert(LASE.t('请先选择三维场景（山区救援 / 三维山地对抗），再加载三维地形'));
      return;
    }
    const nCargo = this._cargoInp ? (parseInt(this._cargoInp.value) || 0) : 0;
    const nRelay = this._relayInp ? (parseInt(this._relayInp.value) || 0) : 0;
    const nAttack = this._attackInp ? (parseInt(this._attackInp.value) || 0) : 0;
    const nInfantry = this._infantryInp ? (parseInt(this._infantryInp.value) || 0) : 0;
    const qs = new URLSearchParams({ scenario: scen, fid: this._fid() });
    if (nCargo) qs.set('n_cargo', nCargo);
    if (nRelay) qs.set('n_relay', nRelay);
    if (nAttack) qs.set('n_attack', nAttack);
    if (nInfantry) qs.set('n_infantry', nInfantry);
    const prog = document.getElementById('uav-prog');
    prog.textContent = LASE.t('生成地形中…');
    let geo;
    try { geo = await LASE.api('/api/uav/map?' + qs.toString()); }
    catch (e) { prog.textContent = ''; alert(LASE.t('加载地形失败：') + (e && e.message || e)); return; }
    prog.textContent = '';
    if (!geo || !geo.terrain) { alert(LASE.t('该场景无三维地形数据')); return; }
    // 构造最小结果（仅几何，无动画帧），进入三维地形浏览
    this._result = { geometry: geo, frames: [], conv: [], evals: [], waypoints: [], relay_pts: [] };
    this._frame = 0;
    const oc = document.getElementById('uav-outcome-card');
    if (oc) oc.style.display = 'none';
    const sc = document.getElementById('uav-soldier-card');
    if (sc) sc.style.display = 'none';
    const sl = document.getElementById('uav-slider');
    sl.max = 0; sl.value = 0;
    document.getElementById('uav-frame-label').textContent = LASE.t('地形浏览模式');
    const drop = document.getElementById('uav-drop-view');
    if (drop) drop.style.display = 'none';
    this._prepare3dMap();
    this._resizeCanvas();
    this._draw();
  },

  async _showDescription() {
    if (this._isRed()) return this._showRedDescription();
    const scen = this._scenSel ? this._scenSel.value : 'intercept';
    const wp = this._wpInp ? (parseInt(this._wpInp.value) || 0) : 0;
    const nc = this._cargoInp ? (parseInt(this._cargoInp.value) || 0) : 0;
    const nr = this._relayInp ? (parseInt(this._relayInp.value) || 0) : 0;
    const na = this._attackInp ? (parseInt(this._attackInp.value) || 0) : 0;
    const ni = this._infantryInp ? (parseInt(this._infantryInp.value) || 0) : 0;
    const qs = new URLSearchParams({ scenario: scen, fid: this._fid() });
    if (wp) qs.set('n_waypoints', wp);   // 0 = 默认，省略让后端用场景默认值
    if (nc) qs.set('n_cargo', nc);
    if (nr) qs.set('n_relay', nr);
    if (na) qs.set('n_attack', na);
    if (ni) qs.set('n_infantry', ni);
    let info;
    try {
      info = await LASE.api('/api/uav/describe?' + qs.toString());
    } catch (e) {
      alert(LASE.t('加载场景说明失败：') + e);
      return;
    }
    this._renderDescriptionModal(info);
  },

  _renderDescriptionModal(info) {
    const old = document.getElementById('uav-desc-modal');
    if (old) old.remove();

    const overlay = document.createElement('div');
    overlay.id = 'uav-desc-modal';
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; ' +
      'display:flex; align-items:center; justify-content:center; padding:24px;';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    const panel = document.createElement('div');
    panel.style.cssText = 'background:#fff; border-radius:10px; width:min(820px,100%); ' +
      'max-height:88vh; display:flex; flex-direction:column; ' +
      'box-shadow:0 12px 40px rgba(0,0,0,.3); overflow:hidden;';

    const head = document.createElement('div');
    head.style.cssText = 'padding:16px 22px; background:#2c5f8a; color:#fff;';
    const taskLabel = this._taskLabel(
      info.scenario || (this._scenSel && this._scenSel.value), info.fid);
    head.innerHTML =
      `<div style="font-size:17px; font-weight:700">${LASE.t(info.name)} · ${LASE._esc(taskLabel)}</div>` +
      `<div style="font-size:12px; opacity:.85; margin-top:4px">` +
      `${LASE.t('决策维度 D={0} · 每机航点数 K={1}（最小 {2}）', info.dim, info.n_waypoints, info.min_waypoints)}` +
      ` · ${LASE.t('编码域 [-1,1]<sup>D</sup>')}</div>`;

    const body = document.createElement('div');
    body.style.cssText = 'padding:18px 22px; overflow:auto; font-size:13.5px; ' +
      'line-height:1.7; color:#333;';

    const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const section = (title, html) =>
      `<div style="margin-bottom:16px">` +
      `<div style="font-weight:700; color:#2c5f8a; margin-bottom:6px">${title}</div>` +
      `<div style="padding-left:6px">${html}</div></div>`;

    const constraints = (info.constraints || []).map((c, i) =>
      `<div style="margin:3px 0"><span style="color:#2c5f8a; font-weight:600">${i + 1}.</span> ` +
      `${esc(c)}</div>`).join('');
    const params = Object.entries(info.params || {}).map(([k, v]) =>
      `<div style="margin:2px 0"><span style="color:#888">${esc(k)}</span> = <b>${esc(v)}</b></div>`
    ).join('');

    body.innerHTML =
      section(LASE.t('要解决的问题'), esc(info.problem)) +
      section(LASE.t('模型在做什么'), esc(info.model)) +
      (info.optimization ? section(LASE.t('演化优化方式'), esc(info.optimization)) : '') +
      section(LASE.t('约束条件'), constraints) +
      section(LASE.t('目标函数 / 评分'), esc(info.scoring)) +
      section(LASE.t('本任务说明'), esc(info.fid_note)) +
      section(LASE.t('参数具体值'), params);

    const foot = document.createElement('div');
    foot.style.cssText = 'padding:12px 22px; border-top:1px solid #eee; text-align:right;';
    const close = document.createElement('button');
    close.className = 'btn';
    close.textContent = LASE.t('关闭');
    close.onclick = () => overlay.remove();
    foot.appendChild(close);

    panel.appendChild(head);
    panel.appendChild(body);
    panel.appendChild(foot);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  },

  // ===== 红方课题说明（红方视角下「课题说明」按钮） =====
  // 数据源 /api/uav/red/describe?mode=&fid=，与 uav_red.describe_topic 同源：
  // 决策槽位、约束（含本课题是否生效 / 豁免原因）、目标函数、对手口径都来自后端。
  async _showRedDescription() {
    const qs = new URLSearchParams({
      mode: this._redTopicSel ? this._redTopicSel.value : 'intercept',
      fid: this._fid(),
    });
    let info;
    try {
      info = await LASE.api('/api/uav/red/describe?' + qs.toString());
    } catch (e) {
      alert(LASE.t('加载课题说明失败：') + e);
      return;
    }
    this._renderRedDescriptionModal(info);
  },

  _renderRedDescriptionModal(info) {
    const old = document.getElementById('uav-desc-modal');
    if (old) old.remove();
    const esc = (s) => LASE._esc(s == null ? '' : String(s));

    const overlay = document.createElement('div');
    overlay.id = 'uav-desc-modal';
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; ' +
      'display:flex; align-items:center; justify-content:center; padding:24px;';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    const panel = document.createElement('div');
    panel.style.cssText = 'background:#fff; border-radius:10px; width:min(840px,100%); ' +
      'max-height:88vh; display:flex; flex-direction:column; ' +
      'box-shadow:0 12px 40px rgba(0,0,0,.3); overflow:hidden;';

    const head = document.createElement('div');
    head.style.cssText = 'padding:16px 22px; background:#7d3c98; color:#fff;';
    head.innerHTML =
      `<div style="font-size:17px; font-weight:700">${esc(LASE.t(info.name))} · U${esc(info.fid)}</div>` +
      `<div style="font-size:12px; opacity:.88; margin-top:4px">` +
      `${esc(LASE.t('决策变量（{0} 维）', info.dim))} · ${esc(LASE.t('编码域 [-1,1]<sup>D</sup>'))}` +
      (info.c5_exempt ? ' · ' + esc(LASE.t('已豁免 C5')) : '') + `</div>`;

    const body = document.createElement('div');
    body.style.cssText = 'padding:18px 22px; overflow:auto; font-size:13.5px; ' +
      'line-height:1.7; color:#333;';
    const section = (title, html) =>
      `<div style="margin-bottom:16px">` +
      `<div style="font-weight:700; color:#7d3c98; margin-bottom:6px">${esc(title)}</div>` +
      `<div style="padding-left:6px">${html}</div></div>`;

    // 决策变量：每个槽位的维度 + 部署区域（ROI）或取值区间
    const slots = (info.slots || []).map(s => {
      const bits = [`D=${s.dim}`];
      if (s.roi) bits.push(LASE.t('部署区域 x∈[{0}, {1}] · y∈[{2}, {3}]',
        s.roi[0][0], s.roi[0][1], s.roi[1][0], s.roi[1][1]));
      if (s.range) bits.push(LASE.t('取值区间 [{0}, {1}]', s.range[0], s.range[1]) +
        (s.unit ? ' ' + LASE.t(s.unit) : ''));
      return `<div style="margin:3px 0"><b>${esc(LASE.t(s.label))}</b> ` +
        `<span class="muted">${esc(bits.join(' · '))}</span></div>`;
    }).join('');

    // 约束：标出本课题是否生效 + 豁免原因（与代码里的 check() 同源）
    const cons = (info.constraints || []).map(c =>
      `<div style="margin:4px 0${c.active ? '' : '; color:#7a7a7a'}">` +
      `<b>${esc(c.id)}</b> ${esc(LASE.t(c.name))}` +
      (c.active ? '' : ` <span style="color:#2c7a4b">[${esc(LASE.t('本课题不生效'))}]</span>`) +
      `<span class="muted"> ${esc(LASE.t(c.text))}</span>` +
      (c.note ? `<div class="muted" style="font-size:12px">${esc(LASE.t(c.note))}</div>` : '') +
      `</div>`).join('');

    const obj = (info.objective || []).map(o =>
      `<div style="margin:2px 0"><b style="color:#7d3c98">${esc(o.sign)}</b> ` +
      `${esc(LASE.t(o.term))}：${esc(LASE.t(o.text))}</div>`).join('');

    const opps = (info.opponents || []).map(o =>
      `<div style="margin:4px 0"><b>${esc(LASE.t(o.label))}</b>：` +
      `<span class="muted">${esc(LASE.t(o.text))}</span></div>`).join('');

    const fm = info.formation || {};
    const fmTxt = Object.keys(fm).map(k => `${esc(k)} = ${fm[k]}`).join(' · ');
    const notes = (info.notes || []).map(n => `<div style="margin:3px 0">· ${esc(LASE.t(n))}</div>`).join('');

    body.innerHTML =
      section(LASE.t('决策变量（{0} 维）', info.dim), slots) +
      section(LASE.t('约束条件（分级罚分实现，罚分系数 800）'), cons) +
      section(LASE.t('目标函数 / 评分（越小越好）'), obj) +
      section(LASE.t('蓝方对手口径'), opps) +
      section(LASE.t('想定编成'), fmTxt) +
      (notes ? section(LASE.t('口径说明'), notes) : '');

    const foot = document.createElement('div');
    foot.style.cssText = 'padding:12px 22px; border-top:1px solid #eee; text-align:right;';
    const close = document.createElement('button');
    close.className = 'btn';
    close.textContent = LASE.t('关闭');
    close.onclick = () => overlay.remove();
    foot.appendChild(close);

    panel.appendChild(head);
    panel.appendChild(body);
    panel.appendChild(foot);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  },

  // ===== 任务实验数据（论文第 5 章：地图一 F1-F4 × 29 宿主算法） =====
  // 数据源是论文实验产物（后端 /api/uav/paper 读 results/apps/tables），
  // 与下面「数据存档」区（GUI 自己跑出来的结果）相互独立。

  async _showPaperData(fid) {
    const useFid = fid || this._fid();
    const prog = document.getElementById('uav-prog');
    if (prog) prog.textContent = LASE.t('读取任务实验数据…');
    let data;
    try {
      data = await LASE.api('/api/uav/paper?fid=' + encodeURIComponent(useFid));
    } catch (e) {
      if (prog) prog.textContent = '';
      alert(LASE.t('加载任务实验数据失败：') + e);
      return;
    }
    if (prog) prog.textContent = '';
    this._renderPaperModal(data);
  },

  _paperFigUrl(file) {
    return '/api/uav/fig/' + encodeURIComponent(file) +
      '?token=' + encodeURIComponent(LASE.token());
  },

  _paperFmt(key, v) {
    if (v == null || !isFinite(v)) return '—';
    if (/(success|survival|ratio|_pct)$/.test(key)) return (v * 100).toFixed(1) + '%';
    if (Math.abs(v) >= 1000) return v.toFixed(0);
    if (Math.abs(v) >= 100) return v.toFixed(1);
    return v.toFixed(2);
  },

  // 单元格：基线 → 增加 UPCL，下方小字是论文给的正向化增益（正 = UPCL 更好）
  _paperCellHtml(m, r) {
    const b = (r.bare || {})[m.key];
    const f = (r.full || {})[m.key];
    const g = (r.gain || {})[m.key];
    const dir = m.direction === 'lower_better' ? LASE.t('越小越好') : LASE.t('越大越好');
    let html = `<td style="text-align:right; white-space:nowrap" title="${LASE._esc(m.key)}（${LASE._esc(dir)}）">` +
      `<span class="muted">${this._paperFmt(m.key, b)}</span> → <b>${this._paperFmt(m.key, f)}</b>`;
    if (g != null && Math.abs(g) > 1e-9) {
      const col = g > 0 ? '#1a7f37' : '#c0392b';
      html += `<div style="font-size:10.5px; color:${col}; font-weight:600">` +
        `${g > 0 ? '+' : ''}${this._paperFmt(m.key, g)}</div>`;
    }
    return html + '</td>';
  },

  _paperHeadHtml(data) {
    const cells = (data.metrics || []).map(m => {
      const label = LASE.t(UAV_PAPER_METRIC_LABELS[m.key] || m.key);
      const mark = m.key === this._paperSort ? ' ▾' : '';
      return `<th data-sort="${m.key}" style="cursor:pointer; white-space:nowrap" ` +
        `title="${LASE._esc(m.key)} ${LASE._esc(LASE.t('点击按该指标排序'))}">` +
        `${LASE._esc(label)}${mark}</th>`;
    }).join('');
    // 「轨迹回放」放在算法名右边（第二列）：指标列有十几列，放最后一列会被横向滚动挡住
    return `<tr><th style="text-align:center">#</th><th style="white-space:nowrap">${LASE.t('算法')}</th>` +
      `<th style="white-space:nowrap" title="${LASE._esc(LASE.t('点 R1/R2/R3 回放该次运行的三维轨迹'))}">` +
      `${LASE.t('轨迹回放')}</th>` +
      `<th style="white-space:nowrap" title="${LASE._esc(LASE.t('论文里的跨任务综合评分'))}">${LASE.t('综合分')}</th>` +
      `<th style="white-space:nowrap" title="${LASE.t('该算法在 CEC 基准上的排名')}">CEC</th>${cells}` +
      `</tr>`;
  },

  // 轨迹回放按钮：每个算法一行，按该任务实际的运行次数给出 R1/R2/R3
  _paperTraceCell(r, data) {
    const n = Math.max(1, Math.min(9, Number(data && data.n_runs) || 3));
    let btns = '';
    for (let k = 0; k < n; k++) {
      btns += `<button class="btn" data-host="${LASE._esc(r.host)}" data-run="${k}" ` +
        `style="font-size:11.5px; padding:2px 8px; font-weight:600" ` +
        `title="${LASE._esc(LASE.t('回放该次运行的三维轨迹'))}">R${k + 1}</button>`;
    }
    return `<td style="white-space:nowrap"><div style="display:flex; gap:3px">${btns}</div></td>`;
  },

  _paperRowsHtml(data, sortKey) {
    const dirs = {};
    (data.metrics || []).forEach(m => { dirs[m.key] = m.direction; });
    const rows = data.rows.slice();
    const k = sortKey || (data.metrics[0] || {}).key;
    if (k && dirs[k]) {
      const s = dirs[k] === 'lower_better' ? 1 : -1;   // 指标好的排前面
      rows.sort((a, b) => {
        const va = (a.full || {})[k];
        const vb = (b.full || {})[k];
        if (va == null && vb == null) return a.host.localeCompare(b.host);
        if (va == null) return 1;
        if (vb == null) return -1;
        return s * (va - vb);
      });
    }
    return rows.map((r, i) => {
      const cells = (data.metrics || []).map(m => this._paperCellHtml(m, r)).join('');
      const comp = r.composite == null ? '—' : r.composite.toFixed(3);
      return '<tr>' +
        `<td style="text-align:center" class="muted">${i + 1}</td>` +
        `<td style="white-space:nowrap"><b>${LASE._esc(r.host)}</b></td>` +
        this._paperTraceCell(r, data) +
        `<td style="text-align:right">${comp}</td>` +
        `<td style="text-align:center" class="muted">${r.cec_rank == null ? '—' : r.cec_rank}</td>` +
        cells + '</tr>';
    }).join('');
  },

  _paperTasksHtml(data) {
    const scen = data.scenario || 'intercept';
    const opts = (LASE.uavMeta && LASE.uavMeta.task_options &&
      LASE.uavMeta.task_options[scen]) || [1, 2, 3, 4];
    const btns = opts.map(f => {
      const on = Number(f) === Number(data.fid);
      return `<button class="btn${on ? ' primary' : ''}" data-fid="${f}" style="font-size:12px">` +
        `${LASE._esc(this._taskLabel(scen, f))}</button>`;
    }).join(' ');
    const arm = this._paperArm === 'bare' ? 'bare' : 'full';
    const armBtns = [['full', LASE.t('回放：增加 UPCL')],
      ['bare', LASE.t('回放：纯算法基线')]].map(([k, label]) =>
      `<button class="btn${k === arm ? ' primary' : ''}" data-arm="${k}" ` +
      `style="font-size:12px">${LASE._esc(label)}</button>`).join(' ');
    return `<div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center; margin-bottom:8px">` +
      `<span class="muted" style="font-size:12px">${LASE.t('切换任务：')}</span>${btns}` +
      `<span class="muted" style="font-size:12px; margin-left:12px">${LASE.t('轨迹回放臂：')}</span>` +
      `${armBtns}</div>`;
  },

  _paperSummaryHtml(data) {
    const bits = [
      LASE.t('宿主算法 {0} 个', data.n_hosts),
      LASE.t('决策维度 D={0}', data.dim),
      LASE.t('每格：基线 → 增加 UPCL，小字为增益（正 = UPCL 更好）'),
    ];
    const sp = data.spearman;
    const spTxt = (sp && sp.rho != null)
      ? LASE.t('UAV 排名与 CEC 排名（{0} 个算法）的 Spearman ρ = {1}，p = {2}',
        sp.n, sp.rho, sp.p) : '';
    return `<div style="font-size:12px; color:#555; margin-bottom:4px">` +
      `${LASE._esc(bits.join(' · '))}</div>` +
      (spTxt ? `<div style="font-size:12px; color:#555; margin-bottom:6px">` +
        `${LASE._esc(spTxt)}</div>` : '') +
      `<div style="font-size:12px; color:#2c5f8a; background:#eef4fa; ` +
      `border-left:3px solid #2c5f8a; padding:6px 10px; border-radius:4px; margin-bottom:8px">` +
      `${LASE.t('表格「轨迹回放」列的 R1/R2/R3 = 该算法第 1/2/3 次运行，点一下就会关闭本窗口，并在页面下方用真三维沙盘重放该次轨迹（可鼠标拖拽旋转，可切 2D 俯视图）。')}` +
      `</div>`;
  },

  // 配图按钮分两组：本任务图（文件名含 {fid}，增益热力图 / 增益森林图 /
  // 排名散点 / 代表轨迹等均已按任务出图，随任务切换变化）默认展开；
  // 只剩「4 个任务合并成一张」的论文正文原图与任务无关的战场地形图收进折叠区，
  // 并明确标注「切换任务不会变」，避免被误读成数据错误。
  _paperFigButtons(figs) {
    const btn = (f) => `<button class="btn" data-fig="${LASE._esc(f.file)}" ` +
      `style="font-size:12px; text-align:left">${LASE._esc(LASE.t(f.label))}</button>`;
    const cap = (t) => `<div class="muted" style="font-size:11px; margin:2px 0 0">` +
      `${LASE._esc(t)}</div>`;
    const mine = figs.filter(f => f.per_task);
    const other = figs.filter(f => !f.per_task);
    let out = '';
    if (mine.length) {
      out += cap(LASE.t('本任务图（随任务切换变化）')) + mine.map(btn).join('');
    }
    if (other.length) {
      out += `<details style="margin-top:4px">` +
        `<summary style="font-size:11.5px; color:#666; cursor:pointer; line-height:1.5">` +
        `${LASE._esc(LASE.t('跨任务合并口径图（{0} 张：4 个任务合成一张、切换任务不会变；本任务版见上方，另有与任务无关的战场地形图）',
          other.length))}</summary>` +
        `<div style="display:flex; flex-direction:column; gap:6px; margin-top:6px">` +
        other.map(btn).join('') + `</div></details>`;
    }
    return out;
  },

  // 本任务多维对比图：全部由本任务的 rows / metrics 实时绘制，
  // 所以切换 F1–F4 得到的是三张不同的图，且能横向比较全部算法。
  _paperChartsHtml(data) {
    const charts = [
      ['bars', LASE.t('各算法本任务表现（bare vs full）')],
      ['heat', LASE.t('多维增益热力图（算法 × 指标）')],
      ['scatter', LASE.t('多维权衡迁移（bare → full）')],
    ];
    return `<div style="font-weight:600; font-size:13px; margin:2px 0 6px">` +
      `${LASE.t('本任务多维对比（随任务切换变化）')}</div>` +
      // 名次口径：跨任务综合名次来自 uav_value_rank.csv，本任务名次来自
      // uav_task_rank.csv（4 主指标 z-score、只限本任务），两者可切换
      `<div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin:2px 0 8px; ` +
      `background:#eef4fa; border-left:3px solid #2c5f8a; padding:7px 12px; border-radius:4px">` +
      `<span style="font-size:12px; font-weight:700; color:#2c5f8a">${LASE.t('名次口径：')}</span>` +
      `<select id="uav-paper-sort" style="font:inherit; font-size:12.5px; padding:4px 6px; ` +
      `border:1px solid #b9c9da; border-radius:4px; background:#fff">` +
      `<option value="task"${this._paperSort !== 'paper' ? ' selected' : ''}>` +
      `${LASE.t('本任务名次（按本任务表现排，随任务变化）')}</option>` +
      `<option value="paper"${this._paperSort === 'paper' ? ' selected' : ''}>` +
      `${LASE.t('论文跨任务综合名次（固定不变）')}</option></select>` +
      `<span class="muted" style="font-size:11.5px">` +
      `${LASE.t('三张图的行序与 #n 共用此口径。跨任务综合名次取自 uav_value_rank.csv；本任务名次取自 uav_task_rank.csv（4 个主指标 z-score、只统计本任务），与「排名散点（本任务）」论文图同口径。')}</span>` +
      `</div>` +
      `<div class="muted" style="font-size:11.5px; margin-bottom:8px">` +
      `${LASE.t('下面三张图由本任务的 {0} 个算法 × {1} 个指标实时绘制，随任务切换而变化；点「下载（含图例）」导出的 PNG 自带标题、颜色/形状图例与一行数据口径，可直接插入论文。',
        data.n_hosts, (data.metrics || []).length)}</div>` +
      `<div style="display:flex; gap:14px; flex-wrap:wrap">` +
      charts.map(([id, title]) => `<div style="flex:1 1 400px; min-width:330px">` +
        `<div style="display:flex; align-items:center; justify-content:space-between; gap:8px">` +
        `<span style="font-size:12px; font-weight:600">${LASE._esc(title)}</span>` +
        `<button class="btn" data-chart="${id}" style="font-size:11.5px">` +
        `${LASE.t('下载（含图例）')}</button></div>` +
        `<canvas data-chart-cv="${id}" ` +
        `style="width:100%; height:auto; border:1px solid #e3e8ef; border-radius:6px; ` +
        `background:#fff; margin-top:4px"></canvas>` +
        `</div>`).join('') +
      `</div>`;
  },

  _drawPaperCharts(body, data) {
    const pick = (id) => (body.querySelector ? body.querySelector(`[data-chart-cv="${id}"]`) : null);
    const rows = (data.rows || []).slice();
    const metrics = data.metrics || [];
    try {
      const c1 = pick('bars');
      if (c1) this._chartBars(c1, rows, metrics);
      const c2 = pick('heat');
      if (c2) this._chartHeat(c2, rows, metrics);
      const c3 = pick('scatter');
      if (c3) this._chartScatter(c3, rows, metrics);
    } catch (e) { /* 绘图失败不应影响弹窗其余内容 */ }
    // 名次口径切换：三张图按新口径重画（导出时也读同一个状态）
    const sel = body.querySelector ? body.querySelector('#uav-paper-sort') : null;
    if (sel) {
      sel.onchange = () => {
        this._paperSort = sel.value === 'paper' ? 'paper' : 'task';
        this._drawPaperCharts(body, data);
      };
    }
  },

  _downloadPaperChart(body, id, data) {
    const cv = body.querySelector ? body.querySelector(`[data-chart-cv="${id}"]`) : null;
    if (!cv) return;
    LASE.downloadFigure(cv, LASE.t('无人机-本任务对比-{0}-F{1}.png', id, data.fid),
      this._paperChartMeta(id, data));
  },

  // canvas 统一按逻辑尺寸绘制 + 设备像素比放大；显示宽度交给 CSS（保持比例、自适应）
  _chartCtx(cv, W, H) {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(W * dpr);
    cv.height = Math.round(H * dpr);
    cv.style.width = '100%';
    cv.style.height = 'auto';
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, W, H);
    return ctx;
  },

  _chartFont(ctx, size, weight) {
    ctx.font = `${weight || 400} ${size}px system-ui, -apple-system, "Segoe UI", ` +
      `"Microsoft YaHei", sans-serif`;
  },

  _chartLegend(ctx, x, y, items) {
    let cx = x;
    this._chartFont(ctx, 11.5);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    items.forEach(([color, label]) => {
      ctx.fillStyle = color;
      ctx.fillRect(cx, y - 5, 10, 10);
      ctx.fillStyle = '#444';
      ctx.fillText(label, cx + 14, y);
      cx += 14 + ctx.measureText(label).width + 18;
    });
  },

  _chartNum(v) {
    const a = Math.abs(v);
    if (a >= 1000) return (v / 1000).toFixed(a >= 10000 ? 0 : 1) + 'k';
    if (a >= 10) return v.toFixed(1);
    if (a >= 1) return v.toFixed(2);
    if (a === 0) return '0';
    return v.toFixed(3);
  },

  // 三张实时图的「行序 / 名次」口径：
  //   'task'  = 本任务名次（随任务切换而变）
  //   'paper' = 论文跨任务综合名次（tables/uav_value_rank.csv，固定不变）
  // 本任务名次优先走后端给的 r.task_rank（tables/uav_task_rank.csv：4 主指标
  // z-score、bare 臂、总体只限本任务），与「排名散点（本任务）」论文图同口径；
  // 后端没镜像该表时退回前端按本任务各指标现算（兼容旧数据）。
  _paperSort: 'task',

  // 每个算法在「本任务」的整体表现名次（1 = 最好）。有后端名次就直接用；
  // 否则把所有有区分度的指标按方向统一归一化后取 full 臂均值再排序，
  // 并列时退回论文综合名次。
  _paperTaskRank(rows, metrics) {
    const paper = {};
    rows.forEach((r) => { paper[r.host] = r.uav_rank || 999; });
    const api = {};
    rows.forEach((r) => {
      if (r.task_rank != null) api[r.host] = Number(r.task_rank);
    });
    if (Object.keys(api).length) {
      const order = rows.map(r => r.host).sort((a, b) =>
        (api[a] || 999) - (api[b] || 999) || paper[a] - paper[b] || (a < b ? -1 : 1));
      const rank = {}, score = {};
      order.forEach((h, i) => {
        rank[h] = api[h] || (i + 1);
        score[h] = -rank[h];       // 仅用于「越大越好」的统一比较
      });
      return { order: order, rank: rank, score: score, n_live: order.length,
               source: 'api' };
    }
    const ms = metrics || [];
    const dirOf = {};
    ms.forEach((m) => { dirOf[m.key] = m.direction; });
    const spans = {};
    ms.forEach((m) => {
      const k = m.key;
      const vals = [];
      rows.forEach((r) => {
        const b = (r.bare || {})[k], f = (r.full || {})[k];
        if (b != null) vals.push(b);
        if (f != null) vals.push(f);
      });
      if (vals.length < 2) { spans[k] = null; return; }
      const lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
      spans[k] = (hi - lo < 1e-12) ? null : [lo, hi];
    });
    const live = ms.map(m => m.key).filter(k => spans[k]);
    const score = {};
    rows.forEach((r) => {
      let s = 0, n = 0;
      live.forEach((k) => {
        const v = (r.full || {})[k];
        if (v == null) return;
        let t = (v - spans[k][0]) / (spans[k][1] - spans[k][0]);
        if (dirOf[k] === 'lower_better') t = 1 - t;
        s += t; n += 1;
      });
      score[r.host] = n ? s / n : null;
    });
    const order = rows.map(r => r.host).sort((a, b) => {
      const sa = score[a], sb = score[b];
      if (sa == null && sb == null) return paper[a] - paper[b];
      if (sa == null) return 1;
      if (sb == null) return -1;
      if (Math.abs(sb - sa) > 1e-9) return sb - sa;
      return paper[a] - paper[b] || (a < b ? -1 : 1);
    });
    const rank = {};
    order.forEach((h, i) => { rank[h] = i + 1; });
    return { order: order, rank: rank, score: score, n_live: live.length,
             source: 'frontend' };
  },

  // 按当前行序口径输出排序后的 rows 与每行显示用的名次
  _paperOrder(rows, metrics) {
    const tr = this._paperTaskRank(rows, metrics);
    const paper = {};
    rows.forEach((r) => { paper[r.host] = r.uav_rank || 999; });
    const useTask = this._paperSort !== 'paper';
    const key = (h) => (useTask ? (tr.rank[h] || 999) : paper[h]);
    const sorted = rows.slice().sort((a, b) => key(a.host) - key(b.host)
      || paper[a.host] - paper[b.host] || (a.host < b.host ? -1 : 1));
    const rankOf = {};
    sorted.forEach((r, i) => { rankOf[r.host] = i + 1; });
    return { rows: sorted, rankOf: rankOf, taskRank: tr.rank, paper: paper };
  },

  // 默认展示的指标：本任务数据里取值有区分度的那一个。
  // 论文数据中 mission_success 常为常量 0（四任务均未完全成功），
  // 若直接拿它当默认，条形图会退化成一片零长条，故先按方差筛选。
  _chartDefaultMetric(metrics, rows) {
    const spread = (k) => {
      const vals = [];
      rows.forEach((r) => {
        const b = (r.bare || {})[k], f = (r.full || {})[k];
        if (b != null) vals.push(b);
        if (f != null) vals.push(f);
      });
      if (vals.length < 2) return 0;
      const lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
      const scale = Math.max(1e-9, Math.abs(hi) + Math.abs(lo));
      return (hi - lo) / scale;          // 相对幅度，跨量纲可比
    };
    const live = metrics.filter(m => spread(m.key) > 1e-6);
    const arr = live.length ? live : metrics;
    return arr.filter(m => m.key === 'csr_pct')[0] || arr[0] || {};
  },

  // 图 1：横向双色条形——每算法一行，蓝 = bare、橙 = full，按当前行序口径排列
  _chartBars(cv, rows, metrics) {
    const sel = this._chartDefaultMetric(metrics, rows);
    const key = sel.key;
    const ord = this._paperOrder(rows, metrics);
    const items = ord.rows.map(r => ({
      host: r.host, rank: ord.rankOf[r.host],
      b: (r.bare || {})[key], f: (r.full || {})[key],
    })).filter(it => it.b != null || it.f != null);
    const W = 920, padL = 140, padR = 70, padT = 58, padB = 30, rowH = 21;
    const H = Math.max(300, items.length * rowH + padT + padB);
    const ctx = this._chartCtx(cv, W, H);
    if (!items.length || !key) {
      this._chartFont(ctx, 13);
      ctx.fillStyle = '#888';
      ctx.fillText(LASE.t('该指标在本任务下没有可用数据'), 20, 30);
      return;
    }
    const vals = [];
    items.forEach((it) => {
      if (it.b != null) vals.push(it.b);
      if (it.f != null) vals.push(it.f);
    });
    const hiRaw = Math.max.apply(null, vals), loRaw = Math.min.apply(null, vals);
    const lo = Math.min(0, loRaw);
    const hi = hiRaw > lo ? hiRaw : lo + 1;
    const span = (hi - lo) || 1;
    const X = (v) => padL + ((v - lo) / span) * (W - padL - padR);

    this._chartLegend(ctx, padL, 22, [
      ['#2563eb', LASE.t('bare 纯算法基线')],
      ['#e8590c', LASE.t('full 增加 UPCL')],
    ]);
    this._chartFont(ctx, 11.5, 600);
    ctx.fillStyle = '#333';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(LASE.t('指标：{0}', LASE.t(key)), W - 8, 20);
    this._chartFont(ctx, 11);
    ctx.fillStyle = '#2c5f8a';
    ctx.fillText(this._paperSort === 'paper'
      ? LASE.t('行序 = 论文跨任务综合名次')
      : LASE.t('行序 = 本任务名次（随任务变化）'), W - 8, 36);

    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    this._chartFont(ctx, 10.5);
    for (let i = 0; i <= 5; i++) {
      const v = lo + span * i / 5;
      const x = X(v);
      ctx.strokeStyle = i === 0 ? '#c8ced6' : '#eef1f5';
      ctx.beginPath();
      ctx.moveTo(x, padT - 6);
      ctx.lineTo(x, H - padB + 2);
      ctx.stroke();
      ctx.fillStyle = '#999';
      ctx.fillText(this._chartNum(v), x, H - padB + 6);
    }
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const y = padT + i * rowH;
      ctx.fillStyle = '#444';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      this._chartFont(ctx, 11);
      const nm = (it.rank ? `#${it.rank} ` : '') + it.host;
      ctx.fillText(nm.length > 20 ? nm.slice(0, 19) + '…' : nm, padL - 8, y + 10);
      if (it.b != null) {
        ctx.fillStyle = '#2563eb';
        ctx.fillRect(padL, y + 2, Math.max(1, X(it.b) - padL), 7);
      }
      if (it.f != null) {
        ctx.fillStyle = '#e8590c';
        ctx.fillRect(padL, y + 11, Math.max(1, X(it.f) - padL), 7);
      }
    }
  },

  // 图 2：多维增益热力图——行 = 算法、列 = 指标；绿 = UPCL 更好、红 = 更差
  // （后端 gain 已统一方向：正 = UPCL 更好，故直接用符号着色）
  _chartHeat(cv, rows, metrics) {
    const keys = metrics.slice(0, 12);
    const ord = this._paperOrder(rows, metrics);
    rows = ord.rows;
    const cellW = 64, cellH = 20, padL = 140, padT = 58, padB = 26;
    const W = Math.max(560, padL + keys.length * cellW + 16);
    const H = Math.max(280, padT + rows.length * cellH + padB);
    const ctx = this._chartCtx(cv, W, H);
    if (!rows.length || !keys.length) {
      this._chartFont(ctx, 13);
      ctx.fillStyle = '#888';
      ctx.fillText(LASE.t('暂无可用指标'), 20, 30);
      return;
    }
    const abs = [];
    rows.forEach((r) => keys.forEach((m) => {
      const g = (r.gain || {})[m.key];
      if (g != null) abs.push(Math.abs(g));
    }));
    abs.sort((a, b) => a - b);
    const med = abs.length ? abs[Math.floor(abs.length / 2)] : 0.1;
    const scale = Math.max(0.05, med * 2);
    const color = (g) => {
      if (g == null) return '#f4f6f8';
      const t = Math.tanh(g / scale);
      if (Math.abs(t) < 0.02) return '#eef1f5';   // 增益≈0（含常量指标）用中性灰
      return t >= 0 ? `rgba(44,122,75,${Math.min(0.92, Math.abs(t))})`
        : `rgba(192,57,43,${Math.min(0.92, Math.abs(t))})`;
    };
    const dark = (g) => g != null && Math.abs(Math.tanh(g / scale)) > 0.55;

    this._chartLegend(ctx, padL, 22, [['#2c7a4b', LASE.t('绿 = UPCL 更好')],
      ['#c0392b', LASE.t('红 = UPCL 更差')], ['#f4f6f8', LASE.t('浅灰 = 无数据')]]);
    ctx.fillStyle = '#888';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    this._chartFont(ctx, 11);
    ctx.fillText(LASE.t('颜色深浅按本任务增益幅度归一，越深差异越大'), padL + 300, 22);

    keys.forEach((m, j) => {
      ctx.save();
      ctx.translate(padL + j * cellW + cellW / 2, padT - 10);
      ctx.rotate(-Math.PI / 5);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#555';
      this._chartFont(ctx, 10.5);
      const label = LASE.t(m.key);
      ctx.fillText(label.length > 9 ? label.slice(0, 8) + '…' : label, -6, 0);
      ctx.restore();
    });
    rows.forEach((r, i) => {
      const y = padT + i * cellH;
      ctx.fillStyle = '#444';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      this._chartFont(ctx, 11);
      const rk = ord.rankOf[r.host] || r.uav_rank;
      const nm = (rk ? `#${rk} ` : '') + r.host;
      ctx.fillText(nm.length > 20 ? nm.slice(0, 19) + '…' : nm, padL - 8, y + cellH / 2);
      keys.forEach((m, j) => {
        const g = (r.gain || {})[m.key];
        const x = padL + j * cellW;
        ctx.fillStyle = color(g);
        ctx.fillRect(x + 1, y + 1, cellW - 2, cellH - 2);
        if (g != null) {
          ctx.fillStyle = dark(g) ? '#fff' : '#333';
          ctx.textAlign = 'center';
          this._chartFont(ctx, 10);
          ctx.fillText(g.toFixed(2), x + cellW / 2, y + cellH / 2);
        }
      });
    });
  },

  // 图 3：二维权衡迁移——把本任务的指标分成「效果」与「代价」两组，各自在
  // 全部算法×两个臂上归一化后取平均（统一成越高越好），每个算法画一条
  // bare → full 的箭头（空心圆 = 基线，实心点 = 增加 UPCL）。
  // 箭头指向右上 = 两个维度同时改善；指向左上/右下 = 存在取舍。
  // 可用指标随任务不同，故箭头簇形状随 F1–F4 变化，可横向比较各算法的选择。
  _chartScatter(cv, rows, metrics) {
    const W = 640, H = 620, padL = 66, padR = 30, padT = 58, padB = 58;
    const ctx = this._chartCtx(cv, W, H);
    const keys = metrics.map(m => m.key);
    if (!rows.length || !keys.length) {
      this._chartFont(ctx, 13);
      ctx.fillStyle = '#888';
      ctx.fillText(LASE.t('该任务暂无可用于权衡分析的指标'), 20, 30);
      return;
    }
    const dirOf = {};
    metrics.forEach((m) => { dirOf[m.key] = m.direction; });

    // 「效果」= 任务完成度类；「代价」= 资源/风险/时间类。两组都取越高越好。
    // 常量指标（如本数据的 nofly_steps / risk_time）不提供任何区分度，
    // 会把两个轴的差异压平，故先剔除。csr_pct 是 §5.5 的综合成功率。
    const EFF = ['csr_pct', 'n_arrived', 'n_inf_arrived',
      'infantry_survival', 'base_hp', 'n_patrol_killed'];
    const COST = ['n_lost', 'risk_time', 'bounds_steps', 'nofly_steps',
      'path_length', 'flight_time', 'min_dist', 'first_capture',
      'patrol_survival'];

    const spans = {};
    keys.forEach((k) => {
      const vals = [];
      rows.forEach((r) => {
        const b = (r.bare || {})[k], f = (r.full || {})[k];
        if (b != null) vals.push(b);
        if (f != null) vals.push(f);
      });
      if (!vals.length) { spans[k] = null; return; }
      const lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
      spans[k] = (hi - lo < 1e-12) ? null : [lo, hi];
    });
    // 只在「有区分度（spans 非空）」且属于该维度的指标里选；若某组为空，
    // 退化为把所有有区分度的指标均分两组，保证图总能画出来。
    const liveKeys = keys.filter(k => spans[k]);
    let effKeys = liveKeys.filter(k => EFF.indexOf(k) >= 0);
    let costKeys = liveKeys.filter(k => COST.indexOf(k) >= 0);
    if (!effKeys.length || !costKeys.length) {
      const half = Math.ceil(liveKeys.length / 2);
      effKeys = effKeys.length ? effKeys : liveKeys.slice(0, half);
      costKeys = costKeys.length ? costKeys : liveKeys.slice(half);
    }
    const norm = (v, k) => {
      const sp = spans[k];
      if (sp == null) return 0.5;          // 常量指标不提供区分度，取中点
      let t = (v - sp[0]) / (sp[1] - sp[0]);
      if (dirOf[k] === 'lower_better') t = 1 - t;
      return t;
    };
    const score = (arm, ks) => {
      let s = 0, n = 0;
      ks.forEach((k) => {
        const v = (arm || {})[k];
        if (v == null || spans[k] === undefined) return;
        s += norm(v, k); n += 1;
      });
      return n ? s / n : null;
    };
    // 名字前缀用「本任务名次」（随任务变化），与条形图/热力图口径一致
    const ord = this._paperOrder(rows, metrics);
    const pts = rows.map(r => ({
      host: r.host, rank: ord.rankOf[r.host] || r.uav_rank, paper: r.uav_rank,
      bx: score(r.bare, effKeys), by: score(r.bare, costKeys),
      fx: score(r.full, effKeys), fy: score(r.full, costKeys),
    })).filter(p => p.bx != null && p.by != null && p.fx != null && p.fy != null);
    if (!pts.length) {
      this._chartFont(ctx, 13);
      ctx.fillStyle = '#888';
      ctx.fillText(LASE.t('该任务暂无可用于权衡分析的指标'), 20, 30);
      return;
    }

    const X = (t) => padL + t * (W - padL - padR);
    const Y = (t) => H - padB - t * (H - padT - padB);

    // 网格 + 0/0.5/1 刻度，「右上角 = 两个维度都更好」
    ctx.strokeStyle = '#eef1f5';
    for (let i = 0; i <= 5; i++) {
      const t = i / 5;
      ctx.beginPath(); ctx.moveTo(X(t), padT); ctx.lineTo(X(t), H - padB); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(padL, Y(t)); ctx.lineTo(W - padR, Y(t)); ctx.stroke();
    }
    ctx.strokeStyle = '#c8ced6';
    ctx.strokeRect(padL, padT, W - padL - padR, H - padT - padB);
    ctx.fillStyle = '#888';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    this._chartFont(ctx, 10.5);
    for (let i = 0; i <= 5; i++) {
      ctx.fillText((i / 5).toFixed(1), X(i / 5), H - padB + 5);
    }
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (let i = 0; i <= 5; i++) {
      ctx.fillText((i / 5).toFixed(1), padL - 6, Y(i / 5));
    }
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillStyle = '#555';
    this._chartFont(ctx, 12, 600);
    ctx.fillText(LASE.t('效果维度（完成度类指标归一化均值，已按方向统一，越右越好）'),
      (padL + W - padR) / 2, H - padB + 26);
    ctx.save();
    ctx.translate(18, (padT + H - padB) / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(LASE.t('代价维度（资源/风险/时间类指标归一化均值，已按方向统一，越上越好）'), 0, 0);
    ctx.restore();

    // 对角线 = 两个维度表现相当；点在线上方 = 效果优于代价（反之亦然）
    ctx.save();
    ctx.setLineDash([5, 4]);
    ctx.strokeStyle = '#b9c2cc';
    ctx.beginPath(); ctx.moveTo(X(0), Y(0)); ctx.lineTo(X(1), Y(1)); ctx.stroke();
    ctx.restore();
    ctx.fillStyle = '#a8b0b9';
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    this._chartFont(ctx, 10.5);
    ctx.fillText(LASE.t('对角虚线：两个维度表现相当'), X(0.42), Y(0.5));

    this._chartLegend(ctx, padL, 22, [
      ['#1a7f37', LASE.t('绿箭头 = 两个维度同时改善')],
      ['#c0392b', LASE.t('红箭头 = 至少一个维度变差')],
      ['#64748b', LASE.t('空心圆 = bare，实心点 = full')],
    ]);

    const head = (x0, y0, x1, y1, color) => {
      ctx.strokeStyle = color; ctx.fillStyle = color;
      ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      const a = Math.atan2(y1 - y0, x1 - x0);
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x1 - 7 * Math.cos(a - 0.42), y1 - 7 * Math.sin(a - 0.42));
      ctx.lineTo(x1 - 7 * Math.cos(a + 0.42), y1 - 7 * Math.sin(a + 0.42));
      ctx.closePath(); ctx.fill();
    };

    // 标注移动幅度最大的若干算法，避免 29 个名字互相压字
    const moved = pts.map(p => ({
      p, d: Math.hypot(p.fx - p.bx, p.fy - p.by),
    })).sort((a, b) => b.d - a.d);
    const label = {};
    moved.slice(0, 12).forEach((m) => { label[m.p.host] = true; });
    pts.forEach((p) => { if (p.rank && p.rank <= 3) label[p.host] = true; });

    pts.forEach((p) => {
      const x0 = X(p.bx), y0 = Y(p.by), x1 = X(p.fx), y1 = Y(p.fy);
      const better = (p.fx >= p.bx - 1e-9) && (p.fy >= p.by - 1e-9);
      const color = (Math.abs(p.fx - p.bx) < 1e-9 && Math.abs(p.fy - p.by) < 1e-9)
        ? '#94a3b8' : (better ? '#1a7f37' : '#c0392b');
      if (Math.hypot(x1 - x0, y1 - y0) > 1.5) head(x0, y0, x1, y1, color);
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 1.3;
      ctx.beginPath(); ctx.arc(x0, y0, 3.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(x1, y1, 3.4, 0, Math.PI * 2); ctx.fill();
      if (label[p.host]) {
        ctx.fillStyle = '#3d4653';
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        this._chartFont(ctx, 10);
        const nm = (p.rank ? `#${p.rank} ` : '') + p.host;
        ctx.fillText(nm.length > 18 ? nm.slice(0, 17) + '…' : nm, x1 + 5, y1 - 6);
      }
    });
  },

  // 三张本任务对比图的「导出用」标题 + 图例 + 一行口径。
  // 图例画的是颜色/形状样例本身（square 色块、箭头、圆点、虚线），只配极短标签；
  // 详细解读留在论文正文，不往图片里塞长句。
  _paperChartMeta(id, data) {
    const task = this._taskLabel(data.scenario || 'intercept', data.fid);
    const nM = (data.metrics || []).length;
    const lab = (k) => LASE.t(UAV_PAPER_METRIC_LABELS[k] || k);
    const src = LASE.t('数据来源：论文第 5 章既有实验结果（results/apps），非本次新跑；任务 {0}，{1} 个宿主算法，每格取中位数',
      task, data.n_hosts);
    const seed = LASE.t('bare 与 full 同随机种子，差值即增加 UPCL 的净变化');

    if (id === 'bars') {
      const sel = this._chartDefaultMetric(data.metrics || [], data.rows || []);
      return {
        title: LASE.t('图 · {0}：各算法本任务指标对比（bare 纯算法 vs full 增加 UPCL）', task),
        legend: [
          { label: LASE.t('bare 纯算法基线'), color: '#2563eb', shape: 'square' },
          { label: LASE.t('full 增加 UPCL'), color: '#e8590c', shape: 'square' },
        ],
        note: LASE.t('横轴从 0 起（条越短值越小）；行序 = {0}，#n 即该名次；当前指标 = {1}（{2}）；其余 {3} 个指标可在弹窗表格点列头切换；{4}；{5}',
          this._paperSortName(),
          lab(sel.key),
          sel.direction === 'lower_better' ? LASE.t('越小越好') : LASE.t('越大越好'),
          Math.max(0, nM - 1), seed, src),
      };
    }
    if (id === 'heat') {
      return {
        title: LASE.t('图 · {0}：UPCL 多维增益热力图（算法 × 指标）', task),
        legend: [
          { label: LASE.t('增加 UPCL 更好'), color: '#2c7a4b', shape: 'square' },
          { label: LASE.t('增加 UPCL 更差'), color: '#c0392b', shape: 'square' },
          { label: LASE.t('基本无变化'), color: '#eef1f5', shape: 'square' },
          { label: LASE.t('该指标无数据'), color: '#f4f6f8', shape: 'square' },
        ],
        note: LASE.t('单元格 = full − bare 并已统一方向（正 = UPCL 更好）；行 = 算法（行序 = {0}，#n 即该名次），列 = 指标；颜色深浅按本任务增益幅度归一；{1}；{2}',
          this._paperSortName(), seed, src),
      };
    }
    // scatter
    return {
      title: LASE.t('图 · {0}：算法选择的二维权衡迁移（bare → full）', task),
      legend: [
        { label: LASE.t('两维同时改善'), color: '#1a7f37', shape: 'line' },
        { label: LASE.t('至少一维变差'), color: '#c0392b', shape: 'line' },
        { label: LASE.t('两臂几乎重合'), color: '#94a3b8', shape: 'dot' },
        { label: LASE.t('空心圆 = bare 起点'), color: '#64748b', shape: 'ring' },
        { label: LASE.t('实心点 = full 终点'), color: '#1a7f37', shape: 'dot' },
        { label: LASE.t('对角虚线 = 两维相当'), color: '#b9c2cc', shape: 'line', dash: [5, 4] },
      ],
      note: LASE.t('横轴 = 效果维度（完成度类指标归一化均值），纵轴 = 代价维度（资源/风险/时间类指标归一化均值），均已按方向统一为越右/越上越好；名字前缀 #n = {0}；仅标注移动幅度最大的算法与该名次前 3 名；{1}；{2}',
        this._paperSortName(), seed, src),
    };
  },

  // 名次口径的显示名（条形图/热力图/散点图共用）
  _paperSortName() {
    return this._paperSort === 'paper'
      ? LASE.t('论文跨任务综合名次')
      : LASE.t('本任务名次');
  },

  _paperDownloadsHtml(data) {
    const items = (data.tables || []).map(n =>
      `<a class="btn" style="font-size:11.5px" target="_blank" ` +
      `href="/api/uav/paper/table/${encodeURIComponent(n)}?token=${encodeURIComponent(LASE.token())}">` +
      `${LASE._esc(n)}</a>`).join(' ');
    return items ? `<div style="margin-top:10px; font-size:12px">` +
      `<span class="muted">${LASE.t('数据表下载：')}</span> ${items}</div>` : '';
  },

  _renderPaperModal(data) {
    const old = document.getElementById('uav-paper-modal');
    if (old) old.remove();

    const overlay = document.createElement('div');
    overlay.id = 'uav-paper-modal';
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; ' +
      'display:flex; align-items:center; justify-content:center; padding:24px;';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    const panel = document.createElement('div');
    panel.style.cssText = 'background:#fff; border-radius:10px; width:min(1180px,100%); ' +
      'max-height:90vh; display:flex; flex-direction:column; ' +
      'box-shadow:0 12px 40px rgba(0,0,0,.3); overflow:hidden;';

    const head = document.createElement('div');
    head.style.cssText = 'padding:14px 20px; background:#2c5f8a; color:#fff;';
    head.innerHTML =
      `<div style="font-size:17px; font-weight:700">${LASE.t('任务实验数据')} · ` +
      `${LASE._esc(this._taskLabel(data.scenario || 'intercept', data.fid))}</div>` +
      `<div style="font-size:12px; opacity:.85; margin-top:4px">` +
      `${LASE.t('论文第 5 章：同一张地图上的四个任务，各宿主算法「基线 vs 增加 UPCL」的对比')}</div>`;

    const body = document.createElement('div');
    body.style.cssText = 'padding:14px 20px; overflow:auto; font-size:13px; line-height:1.6; color:#333;';

    const foot = document.createElement('div');
    foot.style.cssText = 'padding:10px 20px; border-top:1px solid #eee; text-align:right;';
    const close = document.createElement('button');
    close.className = 'btn';
    close.textContent = LASE.t('关闭');
    close.onclick = () => overlay.remove();
    foot.appendChild(close);

    if (!data || !data.available) {
      body.innerHTML = `<div class="muted">` +
        `${LASE.t('该任务暂无实验数据（需先把论文产物 results/apps 同步到 webapp）。')}</div>`;
    } else {
      this._paperSort = (this._paperSort &&
        (data.metrics || []).some(m => m.key === this._paperSort))
        ? this._paperSort : ((data.metrics[0] || {}).key);
      this._paperArm = this._paperArm === 'bare' ? 'bare' : 'full';
      const figs = data.figures || [];
      const first = figs.filter(f => f.key === 'task')[0] || figs[0];
      body.innerHTML =
        `<style>#uav-paper-table td, #uav-paper-table th { padding:3px 8px; ` +
        `border-bottom:1px solid #eef1f5; } #uav-paper-table th { position:sticky; top:0; ` +
        `background:#f5f7fa; z-index:1; }</style>` +
        this._paperTasksHtml(data) +
        this._paperSummaryHtml(data) +
        (first ? `<div style="display:flex; gap:12px; align-items:flex-start; margin:8px 0 12px; flex-wrap:wrap">` +
          `<img id="uav-paper-img" src="${this._paperFigUrl(first.file)}" alt="${LASE._esc(first.file)}" ` +
          `style="max-width:min(640px,100%); max-height:320px; border:1px solid #e3e8ef; ` +
          `border-radius:6px; cursor:zoom-in" title="${LASE._esc(LASE.t('点击放大'))}">` +
          `<div style="display:flex; flex-direction:column; gap:6px; min-width:240px">` +
          this._paperFigButtons(figs) +
          `</div></div>` : '') +
        this._paperChartsHtml(data) +
        `<div style="overflow:auto; max-height:44vh; border:1px solid #e3e8ef; border-radius:6px">` +
        `<table id="uav-paper-table" style="font-size:12px; border-collapse:collapse; width:100%">` +
        `<thead id="uav-paper-thead">${this._paperHeadHtml(data)}</thead>` +
        `<tbody id="uav-paper-tbody">${this._paperRowsHtml(data, this._paperSort)}</tbody>` +
        `</table></div>` +
        this._paperDownloadsHtml(data);

      body.onclick = (e) => {
        const img = document.getElementById('uav-paper-img');
        const figBtn = e.target.closest ? e.target.closest('[data-fig]') : null;
        const taskBtn = e.target.closest ? e.target.closest('[data-fid]') : null;
        const sortTh = e.target.closest ? e.target.closest('[data-sort]') : null;
        const traceBtn = e.target.closest ? e.target.closest('[data-run]') : null;
        const armBtn = e.target.closest ? e.target.closest('[data-arm]') : null;
        const chartBtn = e.target.closest ? e.target.closest('[data-chart]') : null;
        if (chartBtn) { this._downloadPaperChart(body, chartBtn.dataset.chart, data); return; }
        if (figBtn) { if (img) img.src = this._paperFigUrl(figBtn.dataset.fig); return; }
        if (taskBtn) { this._showPaperData(taskBtn.dataset.fid); return; }
        if (armBtn) {
          this._paperArm = armBtn.dataset.arm === 'bare' ? 'bare' : 'full';
          body.querySelectorAll('[data-arm]').forEach((b) => {
            b.classList.toggle('primary', b.dataset.arm === this._paperArm);
          });
          return;
        }
        if (traceBtn) {
          // 回放要在主页面渲染真三维沙盘，先收起本浮层，否则沙盘被浮层遮住
          overlay.remove();
          this._playPaperTrace(data.fid, traceBtn.dataset.host,
            Number(traceBtn.dataset.run),
            this._paperArm === 'bare' ? 'bare' : 'full');
          return;
        }
        if (sortTh) {
          this._paperSort = sortTh.dataset.sort;
          const thead = document.getElementById('uav-paper-thead');
          const tbody = document.getElementById('uav-paper-tbody');
          if (thead) thead.innerHTML = this._paperHeadHtml(data);
          if (tbody) tbody.innerHTML = this._paperRowsHtml(data, this._paperSort);
        }
      };
      const imgEl = document.getElementById('uav-paper-img');
      if (imgEl) imgEl.onclick = () => window.open(imgEl.src, '_blank');
      // 三张本任务对比图在浮层插入文档前先画好（canvas 脱离文档也能绘制），
      // 避免出现「先白块后补画」的闪烁。
      this._drawPaperCharts(body, data);
    }

    panel.appendChild(head);
    panel.appendChild(body);
    panel.appendChild(foot);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  },

  // 击落细节：从轨迹快照还原每架无人机被击落的瞬间（state 0→2），
  // 列出被击落时刻 / 位置 / 最近拦截者，点击可跳转到对应帧回放。
  // 从轨迹快照提取击落/坠毁事件（含类型、位置、施体），用于局部动画演示
  _extractKillEvents() {
    const frs = this._result.frames || [];
    const events = [];
    for (let t = 0; t < frs.length; t++) {
      const evs = frs[t].events || [];
      for (const ev of evs) {
        events.push({
          frame: t, step: frs[t].step, type: ev.t, drone: ev.d, src: ev.s,
          x: ev.x, y: ev.y, z: ev.z,
        });
      }
    }
    return events;
  },

  // 逐架汇总无人机结局：到达 / 被拦截机击落 / 被防空导弹击落 / 能源耗尽坠毁 / 超时未到达。
  // 依据最后一帧的终态 state，并结合时间线上该机的首个致命事件细分失败原因。
  _droneOutcomes() {
    const r = this._result;
    const frs = r.frames || [];
    const g = r.geometry || {};
    const swarm = g.scenario === 'swarm';
    const last = frs.length ? frs[frs.length - 1] : null;
    const n = last && last.drones ? last.drones.length : (g.n_drones || 0);
    // 每架无人机首个致命事件（细分失败原因 + 供点击跳转局部动画）
    const firstKill = new Array(n).fill(null);
    for (let t = 0; t < frs.length; t++) {
      for (const ev of (frs[t].events || [])) {
        const d = ev.d;
        if (d == null || d < 0 || d >= n || firstKill[d]) continue;
        if (ev.t === 'intercept' || ev.t === 'missile' || ev.t === 'crash') {
          firstKill[d] = {
            frame: t, step: frs[t].step, type: ev.t, drone: ev.d, src: ev.s,
            x: ev.x, y: ev.y, z: ev.z,
          };
        }
      }
    }
    const outs = [];
    for (let i = 0; i < n; i++) {
      const d = last && last.drones ? last.drones[i] : null;
      const st = d ? d[3] : 0;
      let reason, color, icon, kill = null;
      if (st === 1) {
        reason = swarm ? LASE.t('突破成功') : LASE.t('到达目标');
        color = '#2c7a4b'; icon = '✓';
      } else if (st === 2) {
        kill = firstKill[i];
        if (kill && kill.type === 'missile') {
          reason = LASE.t('被防空导弹击落（防空车 {0}）', kill.src + 1);
          color = '#d35400'; icon = '🚀';
        } else if (kill && kill.type === 'intercept') {
          reason = LASE.t('被直升机捕获击落（直升机 {0}）', kill.src + 1);
          color = '#c0392b'; icon = '🚁';
        } else {
          reason = LASE.t('被直升机击落');
          color = '#c0392b'; icon = '🚁';
        }
      } else if (st === 3) {
        reason = LASE.t('能源耗尽坠毁');
        color = '#7d3c98'; icon = '💥';
      } else if (st === 4) {
        reason = LASE.t('投弹自毁（完成任务）');
        color = '#e67e22'; icon = '💣';
      } else {
        reason = swarm ? LASE.t('突防超时（仍在飞行）') : LASE.t('超时未到达');
        color = '#8a6f4d'; icon = '⏱';
      }
      outs.push({ idx: i, st, reason, color, icon, kill });
    }
    return outs;
  },

  // 渲染「无人机结局说明」面板：逐架列出结局与失败原因，被击落 / 坠毁项可点击播放局部动画
  _renderOutcomes() {
    const card = document.getElementById('uav-outcome-card');
    const list = document.getElementById('uav-outcome-list');
    if (!card || !list) return;
    const g = this._result.geometry || {};
    if (g.scenario !== 'intercept' && g.scenario !== 'swarm') {
      card.style.display = 'none';
      return;
    }
    const outs = this._droneOutcomes();
    card.style.display = '';
    list.innerHTML = outs.map(o => {
      const ev = o.kill;
      const attrs = ev
        ? `data-kill-frame="${ev.frame}" data-kill-d="${o.idx}"`
        : '';
      return `<span ${attrs} class="uav-outcome-chip" style="display:inline-flex; align-items:center; ` +
        `gap:6px; padding:6px 12px; border:1px solid #eee; border-radius:6px; margin:4px 8px 4px 0; ` +
        `background:#fafafa; ${ev ? 'cursor:pointer' : ''}" title="${ev ? LASE.t('点击播放击落 / 坠毁动画') : ''}">` +
        `<b style="color:#2c5f8a">${LASE.t('无人机 {0}', o.idx + 1)}</b>` +
        `<span style="color:${o.color}; font-weight:600">${o.icon} ${o.reason}</span>` +
        (ev ? `<span style="color:#999; font-size:11px">step ${ev.step}</span>` : '') +
        `</span>`;
    }).join('');
    list.onclick = (e) => {
      const el = e.target.closest('[data-kill-frame]');
      if (!el) return;
      const frame = parseInt(el.dataset.killFrame, 10);
      const d = parseInt(el.dataset.killD, 10);
      const ev = outs[d] && outs[d].kill;
      if (ev && ev.frame === frame) this._playKillReplay(ev);
    };
  },

  // 渲染「士兵结局说明」面板：逐人列出蓝方步兵与红方巡逻兵的结局与剩余血量
  _renderSoldierOutcomes() {
    const card = document.getElementById('uav-soldier-card');
    const list = document.getElementById('uav-soldier-list');
    if (!card || !list) return;
    const g = this._result.geometry || {};
    if (g.scenario !== 'intercept') { card.style.display = 'none'; return; }
    const frs = this._result.frames || [];
    const last = frs.length ? frs[frs.length - 1] : null;
    if (!last || (!last.infantry && !last.patrol)) { card.style.display = 'none'; return; }
    card.style.display = '';
    const chip = (label, sub, color) =>
      `<span class="uav-outcome-chip" style="display:inline-flex; align-items:center; ` +
      `gap:6px; padding:6px 12px; border:1px solid #eee; border-radius:6px; margin:4px 8px 4px 0; ` +
      `background:#fafafa"><b style="color:#2c5f8a">${label}</b>` +
      `<span style="color:${color}; font-weight:600">${sub}</span></span>`;
    const inf = (last.infantry || []).map((p, i) => {
      const hp = Math.max(0, Math.round(p[3]));
      if (p[2] === 2) return chip(LASE.t('步兵 {0}', i + 1), LASE.t('阵亡'), '#c0392b');
      if (p[2] === 1) return chip(LASE.t('步兵 {0}', i + 1), LASE.t('抵达基地 · HP {0}', hp), '#2c7a4b');
      return chip(LASE.t('步兵 {0}', i + 1), LASE.t('未抵达 · HP {0}', hp), '#8a6f4d');
    }).join('');
    const pat = (last.patrol || []).map((p, j) => {
      const hp = Math.max(0, Math.round(p[3]));
      if (p[2] === 1) return chip(LASE.t('巡逻兵 {0}', j + 1), LASE.t('阵亡'), '#c0392b');
      return chip(LASE.t('巡逻兵 {0}', j + 1), LASE.t('存活 · HP {0}', hp), '#2c7a4b');
    }).join('');
    list.innerHTML =
      `<div style="font-size:12px; color:#888; margin:2px 8px 4px">${LASE.t('蓝方步兵（{0} 人）', (last.infantry || []).length)}</div>${inf}` +
      `<div style="font-size:12px; color:#888; margin:10px 8px 4px">${LASE.t('红方巡逻兵（{0} 人）', (last.patrol || []).length)}</div>${pat}`;
  },

  // 击落演示：列出本局所有击落 / 坠毁事件，点击条目播放「特写慢动作」局部动画
  // （防空车发射导弹命中 / 拦截机捕获击落 / 能源耗尽坠毁），不再仅跳帧回放。
  _showKillDetail() {
    const r = this._result;
    if (!r || !r.frames || !r.frames.length) { alert(LASE.t('请先运行仿真')); return; }
    const g = r.geometry || {};
    if (this._isFloodScenario(g.scenario)) { alert(LASE.t('物资投送场景无击落概念')); return; }

    const events = this._extractKillEvents();
    const TYPE = {
      missile:  { label: LASE.t('防空车导弹击落'), color: '#d35400', icon: '🚀' },
      intercept:{ label: LASE.t('直升机捕获击落'), color: '#c0392b', icon: '🚁' },
      crash:    { label: LASE.t('能源耗尽坠毁'),   color: '#7f8c8d', icon: '💥' },
    };

    const old = document.getElementById('uav-kill-modal');
    if (old) old.remove();
    const overlay = document.createElement('div');
    overlay.id = 'uav-kill-modal';
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:9999; ' +
      'display:flex; align-items:center; justify-content:center; padding:24px;';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    const panel = document.createElement('div');
    panel.style.cssText = 'background:#fff; border-radius:10px; width:min(760px,100%); ' +
      'max-height:84vh; display:flex; flex-direction:column; ' +
      'box-shadow:0 12px 40px rgba(0,0,0,.35); overflow:hidden;';

    const head = document.createElement('div');
    head.style.cssText = 'padding:14px 20px; background:#c0392b; color:#fff;';
    head.innerHTML = `<div style="font-size:16px; font-weight:700">${LASE.t('击落演示')}</div>` +
      `<div style="font-size:12px; opacity:.85; margin-top:2px">` +
      `${LASE.t('本局共 {0} 起击落 / 坠毁事件，点击条目播放特写慢动作动画', events.length)}</div>`;

    const body = document.createElement('div');
    body.style.cssText = 'padding:12px 16px; overflow:auto; font-size:13px; color:#333;';
    if (!events.length) {
      body.innerHTML = `<div style="padding:28px; text-align:center; color:#888">` +
        `${LASE.t('本局无无人机被击落 / 坠毁')}</div>`;
    } else {
      let rows = '';
      events.forEach((ev, idx) => {
        const ty = TYPE[ev.type] || { label: ev.type, color: '#888', icon: '·' };
        const srcTxt = ev.type === 'crash' ? '—'
          : ev.type === 'missile' ? LASE.t('防空车 {0}', ev.src + 1)
          : LASE.t('直升机 {0}', ev.src + 1);
        rows +=
          `<div data-kill-idx="${idx}" style="display:flex; align-items:center; gap:10px; ` +
          `padding:10px 12px; margin:5px 0; border:1px solid #eee; border-radius:6px; ` +
          `cursor:pointer; transition:background .12s;" ` +
          `onmouseenter="this.style.background='#fdf3f1'" onmouseleave="this.style.background=''">` +
          `<span style="min-width:26px; text-align:center; font-size:16px">${ty.icon}</span>` +
          `<span style="min-width:104px; font-weight:700; color:${ty.color}">${ty.label}</span>` +
          `<span style="min-width:64px">${LASE.t('无人机 {0}', ev.drone + 1)}</span>` +
          `<span style="min-width:56px; color:#888">step ${ev.step}</span>` +
          `<span style="min-width:88px; color:#888">${LASE.t('施体 {0}', srcTxt)}</span>` +
          `<span style="margin-left:auto; color:#2c5f8a">${LASE.t('▶ 播放动画')}</span></div>`;
      });
      body.innerHTML = rows;
      body.addEventListener('click', (e) => {
        const row = e.target.closest('[data-kill-idx]');
        if (!row) return;
        const ev = events[parseInt(row.dataset.killIdx)];
        overlay.remove();
        this._playKillReplay(ev);
      });
    }

    const foot = document.createElement('div');
    foot.style.cssText = 'padding:12px 20px; border-top:1px solid #eee; text-align:right;';
    const close = document.createElement('button');
    close.className = 'btn';
    close.textContent = LASE.t('关闭');
    close.onclick = () => overlay.remove();
    foot.appendChild(close);

    panel.appendChild(head);
    panel.appendChild(body);
    panel.appendChild(foot);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  },

  // 特写慢动作播放一次击落事件：镜头拉近到事件点，慢速回放事件前后一段
  _playKillReplay(ev) {
    // 停止上一次演示与正常播放
    if (this._killReplay) this._stopKillReplay(true);
    if (this._playing) this._togglePlay();
    // 确保 3D 沙盒已构建
    if (!this._sandbox || !this._sandbox.built) this._draw();
    const sb = this._sandbox;
    if (!sb || !sb.built) return;

    const len = this._result.frames.length;
    const pre = 50, post = 55;
    const rp = {
      ev,
      start: Math.max(0, ev.frame - pre),
      end: Math.min(len - 1, ev.frame + post),
      cur: Math.max(0, ev.frame - pre),
      savedCam: sb.camera.position.clone(),
      savedTarget: sb.controls.target.clone(),
      timer: null,
    };
    this._killReplay = rp;

    // 特写镜头：目标移到事件点，相机拉近
    const focus = sb.P(ev.x, ev.y, ev.z);
    sb.controls.target.copy(focus);
    sb.camera.position.copy(focus).add(new THREE.Vector3(12, 10, 18));
    sb.controls.update();

    this._showKillBanner(ev);
    const btn = document.getElementById('uav-play');
    if (btn) { btn.textContent = LASE.t('演示中…'); btn.disabled = true; }

    this._frame = rp.cur;
    document.getElementById('uav-slider').value = rp.cur;
    this._updateSandboxFrame();
    rp.timer = setInterval(() => this._stepKillReplay(), 170);
  },

  _stepKillReplay() {
    const rp = this._killReplay;
    if (!rp) return;
    if (rp.cur > rp.end) { this._stopKillReplay(true); return; }
    this._frame = rp.cur;
    document.getElementById('uav-slider').value = rp.cur;
    this._updateSandboxFrame();
    rp.cur++;
  },

  _stopKillReplay(restoreView) {
    const rp = this._killReplay;
    if (!rp) return;
    if (rp.timer) clearInterval(rp.timer);
    this._killReplay = null;
    const sb = this._sandbox;
    if (sb && restoreView !== false) {
      sb.controls.target.copy(rp.savedTarget);
      sb.camera.position.copy(rp.savedCam);
      sb.controls.update();
    }
    const btn = document.getElementById('uav-play');
    if (btn) { btn.textContent = LASE.t('▶ 播放'); btn.disabled = false; }
    const banner = document.getElementById('uav-kill-banner');
    if (banner) banner.remove();
    // 停在事件帧附近，便于观察，并刷新画面与视角
    this._frame = Math.min(rp.ev.frame, (this._result.frames.length || 1) - 1);
    document.getElementById('uav-slider').value = this._frame;
    this._draw();
  },

  _showKillBanner(ev) {
    const old = document.getElementById('uav-kill-banner');
    if (old) old.remove();
    const TYPE = {
      missile:  { label: LASE.t('防空车导弹命中'), color: '#d35400' },
      intercept:{ label: LASE.t('直升机捕获击落'), color: '#c0392b' },
      crash:    { label: LASE.t('能源耗尽坠毁'),   color: '#7f8c8d' },
    };
    const ty = TYPE[ev.type] || { label: ev.type, color: '#888' };
    const b = document.createElement('div');
    b.id = 'uav-kill-banner';
    b.style.cssText = 'position:fixed; top:64px; left:50%; transform:translateX(-50%); ' +
      'z-index:1000; background:rgba(20,24,30,.85); color:#fff; padding:8px 16px; ' +
      'border-radius:20px; font-size:13px; box-shadow:0 4px 16px rgba(0,0,0,.3); ' +
      'display:flex; align-items:center; gap:10px;';
    b.innerHTML = `<span style="width:10px; height:10px; border-radius:50%; background:${ty.color}; display:inline-block"></span>` +
      `<span>${LASE.t('特写慢动作：{0} · 无人机 {1}', ty.label, ev.drone + 1)}</span>` +
      `<button id="uav-kill-exit" class="btn" style="padding:2px 10px; font-size:12px">${LASE.t('退出演示')}</button>`;
    document.body.appendChild(b);
    b.querySelector('#uav-kill-exit').onclick = () => this._stopKillReplay(true);
  },

  _renderResult(r) {
    this._result = r;
    this._compareMode = false;
    this._compareResults = null;
    // 论文实验数据回放时显示来源提示条（实时仿真 / 存档回放则隐藏）
    this._paperBadge(r);
    const g = r.geometry || {};
    const flood = this._isFloodScenario(g.scenario);
    const is3d = this._is3dScenario(g.scenario);
    // 红方优化结果（代价为负、越小越好）与洪涝一样不能用对数轴
    const red = !!r.red_mode;
    const linConv = flood || red;
    // 统计
    const box = document.getElementById('uav-stats');
    box.style.display = '';
    if (flood) {
      const gm = (r.gen_metrics && r.gen_metrics.length)
        ? r.gen_metrics[r.gen_metrics.length - 1] : null;
      const comm = gm && typeof gm.comm_ok === 'boolean'
        ? (gm.comm_ok ? LASE.t('连通') : LASE.t('中断')) : '—';
      const energy = gm && typeof gm.energy === 'number'
        ? gm.energy.toFixed(1) + ' kWh' : '—';
      const ft = gm && typeof gm.flight_time === 'number'
        ? (gm.flight_time >= 3600 ? (gm.flight_time / 3600).toFixed(1) + ' h'
           : gm.flight_time >= 60 ? (gm.flight_time / 60).toFixed(0) + ' min'
           : gm.flight_time.toFixed(0) + ' s') : '—';
      box.innerHTML = `
        <div class="stat-box"><div class="v">${r.best_f.toFixed(1)}</div><div class="k">${LASE.t('目标函数值')}</div></div>
        <div class="stat-box"><div class="v">${r.arrived}/${r.n_drones}</div><div class="k">${LASE.t('投送成功')}</div></div>
        <div class="stat-box"><div class="v">${r.lost}</div><div class="k">${LASE.t('电池耗尽')}</div></div>
        <div class="stat-box"><div class="v">${comm}</div><div class="k">${LASE.t('通信链路')}</div></div>
        <div class="stat-box"><div class="v">${energy}</div><div class="k">${LASE.t('能耗')}</div></div>
        <div class="stat-box"><div class="v">${ft}</div><div class="k">${LASE.t('飞行时间')}</div></div>
        <div class="stat-box"><div class="v">${r.dim}</div><div class="k">${LASE.t('决策维度')}</div></div>`;
    } else if (r.red_mode) {
      // 红方视角：代价 / 可行性 / 基线增益 / 蓝方突防与击落
      box.innerHTML = this._redStatsHtml(r);
    } else {
      // intercept / swarm：多维对抗指标（飞行轨迹 / 捕获时间 / 路径效率 / 曲率 / 爬升）
      const m = r.metrics || {};
      const num = (v) => (typeof v === 'number' && isFinite(v)) ? v : null;
      const len = (v) => (num(v) === null ? '—'
        : v >= 1000 ? (v / 1000).toFixed(1) + ' km' : v.toFixed(0) + ' m');
      const ft = num(m.flight_time) === null ? '—' : m.flight_time.toFixed(0) + ' s';
      const cap = num(m.first_capture) === null ? '—'
        : (m.first_capture < 0 ? LASE.t('未被捕获') : m.first_capture.toFixed(0) + ' s');
      const risk = num(m.risk_time) === null ? '—' : m.risk_time.toFixed(0) + ' s';
      const eff = num(m.path_efficiency) === null ? '—'
        : (m.path_efficiency * 100).toFixed(0) + '%';
      const curv = num(m.curvature) === null ? '—' : m.curvature.toFixed(1) + ' rad';
      const swarm = g.scenario === 'swarm';
      const mode = r.coevolve ? LASE.t('协同演化') : (this._isDrlDifficulty() ? LASE.t('DRL 对抗') : LASE.t('规则追击'));
      // 士兵存活率与生命情况（仅 intercept 空地协同场景）
      const infStat = (!swarm && num(m.infantry_survival) !== null) ? `
        <div class="stat-box"><div class="v">${(m.infantry_survival * 100).toFixed(0)}%</div><div class="k">${LASE.t('步兵存活率')}</div></div>
        <div class="stat-box"><div class="v">${m.infantry_avg_hp.toFixed(0)}</div><div class="k">${LASE.t('步兵平均血量')}</div></div>
        <div class="stat-box"><div class="v">${(m.patrol_survival * 100).toFixed(0)}%</div><div class="k">${LASE.t('巡逻兵存活率')}</div></div>
        <div class="stat-box"><div class="v">${m.patrol_avg_hp.toFixed(0)}</div><div class="k">${LASE.t('巡逻兵平均血量')}</div></div>` : '';
      box.innerHTML = `
        <div class="stat-box"><div class="v">${r.best_f.toFixed(2)}</div><div class="k">${LASE.t('目标函数值')}</div></div>
        <div class="stat-box"><div class="v">${r.arrived}/${r.n_drones}</div><div class="k">${swarm ? LASE.t('突破架次') : LASE.t('到达架次')}</div></div>
        <div class="stat-box"><div class="v">${r.lost}</div><div class="k">${swarm ? LASE.t('被拦截') : LASE.t('被击落')}</div></div>
        <div class="stat-box"><div class="v">${r.crashed || 0}</div><div class="k">${LASE.t('坠毁')}</div></div>
        <div class="stat-box"><div class="v">${mode}</div><div class="k">${LASE.t('对抗模式')}</div></div>
        <div class="stat-box"><div class="v">${ft}</div><div class="k">${LASE.t('任务耗时')}</div></div>
        <div class="stat-box"><div class="v">${cap}</div><div class="k">${swarm ? LASE.t('首次拦截') : LASE.t('首次捕获')}</div></div>
        <div class="stat-box"><div class="v">${len(m.path_length)}</div><div class="k">${LASE.t('飞行轨迹')}</div></div>
        <div class="stat-box"><div class="v">${eff}</div><div class="k">${LASE.t('路径效率')}</div></div>
        <div class="stat-box"><div class="v">${len(m.climb)}</div><div class="k">${LASE.t('累计爬升')}</div></div>
        <div class="stat-box"><div class="v">${risk}</div><div class="k">${LASE.t('风险暴露')}</div></div>
        <div class="stat-box"><div class="v">${curv}</div><div class="k">${LASE.t('轨迹曲率')}</div></div>
        <div class="stat-box"><div class="v">${r.max_evals}</div><div class="k">${LASE.t('评估次数')}</div></div>
        <div class="stat-box"><div class="v">${r.dim}</div><div class="k">${LASE.t('决策维度')}</div></div>
        ${infStat}`;
    }
    // 无人机结局说明（逐架失败 / 成功原因）+ 士兵结局说明（步兵 / 巡逻兵）
    this._renderOutcomes();
    this._renderSoldierOutcomes();
    // 收敛曲线（flood / 红方优化的 cost 可为负，用线性轴；其余 cost 恒正，用对数轴）
    const convData = linConv
      ? r.evals.map((e, i) => [e, r.conv[i]])
      : r.evals.map((e, i) => [e, Math.max(r.conv[i], 1e-300)]);
    this._convChart.setOption({
      toolbox: LASE.saveToolbox(LASE.t('无人机-收敛曲线')),
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(15, 23, 42, 0.92)',
        borderColor: '#334155', borderWidth: 1,
        padding: [8, 12],
        textStyle: { color: '#e2e8f0', fontSize: 12 },
        axisPointer: { lineStyle: { color: '#94a3b8' } },
      },
      grid: { left: 62, right: 24, top: 22, bottom: 40 },
      xAxis: {
        type: 'value', name: LASE.t('评估次数'),
        axisLine: { lineStyle: { color: '#cbd5e1' } },
        axisLabel: { color: '#64748b' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: '#eef2f7' } },
      },
      yAxis: {
        type: linConv ? 'value' : 'log', name: LASE.t('目标值'),
        ...(linConv ? {} : { min: Math.min(...r.conv.map(x => Math.max(x, 1e-300))) }),
        axisLine: { show: false },
        axisLabel: { color: '#64748b' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: '#eef2f7' } },
      },
      series: [{
        name: LASE.t('最优目标值'), type: 'line', showSymbol: false, smooth: true,
        data: convData,
        lineStyle: { width: 2.2, color: '#2563eb', shadowColor: 'rgba(37, 99, 235, 0.30)', shadowBlur: 8 },
        itemStyle: { color: '#2563eb' },
        areaStyle: {
          color: {
            type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(37, 99, 235, 0.22)' },
              { offset: 1, color: 'rgba(37, 99, 235, 0.00)' },
            ],
          },
        },
      }],
    }, true);
    // 红方视角：在收敛曲线后追加红方专属结果卡片（逐指标对比 / 最优方案 / 约束）
    if (r.red_mode) this._renderRedDetail(r); else this._hideRedDetail();
    // 蓝方实景轨迹（地形高程 + 无人机/步兵行动轨迹曲线）
    this._renderLiveTrace(r);
    // 动画（旧存档可能不含 frames：只展示统计与收敛曲线，不渲染动画）
    const frs = r.frames || [];
    const sl = document.getElementById('uav-slider');
    if (!frs.length) {
      this._frame = 0;
      sl.max = 0; sl.value = 0;
      document.getElementById('uav-frame-label').textContent = LASE.t('无动画数据');
      return;
    }
    this._frame = 0;
    sl.max = frs.length - 1; sl.value = 0;
    if (is3d) this._prepare3dMap();
    this._resizeCanvas();
    // 三维场景显示 2D / 3D 切换并沿用用户上次选择（二维俯视图与三维沙盘同源）
    this._applyView();
    this._draw();
  },

  // 蓝方实景轨迹：地形高程着色背景 + 无人机（蓝）/ 步兵（橙）行动轨迹曲线
  _renderLiveTrace(r) {
    const g = r.geometry || {};
    const flood = this._isFloodScenario(g.scenario);
    const frs = r.frames || [];
    const terrain = g.terrain;

    // —— 地形高程背景（heatmap，自然地貌色带，模拟实景俯视）——
    const heatData = [];
    let zmin = 0, zmax = 1;
    if (terrain && terrain.xs && terrain.ys && terrain.Z) {
      const xs = terrain.xs, ys = terrain.ys, Z = terrain.Z;
      for (let i = 0; i < ys.length; i++) {
        const row = Z[i];
        for (let j = 0; j < xs.length; j++) {
          const v = row ? row[j] : 0;
          if (v !== null && v !== undefined && isFinite(v)) {
            heatData.push([xs[j], ys[i], v]);
            if (heatData.length === 1) { zmin = v; zmax = v; }
            else { if (v < zmin) zmin = v; if (v > zmax) zmax = v; }
          }
        }
      }
    }

    // —— 蓝方单位轨迹：无人机（flood 用 cargo）+ 步兵 ——
    const droneTraces = this._trackUnits(frs, flood ? 'cargos' : 'drones');
    const infTraces = flood ? [] : this._trackUnits(frs, 'infantry');
    const heatOffset = heatData.length ? 1 : 0;
    const nD = droneTraces.length;

    const series = [];
    if (heatData.length) {
      series.push({
        name: LASE.t('地形高程'), type: 'heatmap', data: heatData,
        silent: true, emphasis: { disabled: true },
        itemStyle: { borderWidth: 0 }, z: 1,
      });
    }
    // 无人机轨迹（蓝，平滑曲线，同名合并图例）
    droneTraces.forEach((pts) => {
      series.push({
        name: LASE.t('无人机'), type: 'line', data: pts, showSymbol: false, smooth: 0.3,
        lineStyle: { width: 1.5, color: '#2563eb', opacity: 0.85,
          shadowColor: 'rgba(37, 99, 235, 0.35)', shadowBlur: 5 },
        itemStyle: { color: '#2563eb' },
        emphasis: { focus: 'series', lineStyle: { width: 2.4, opacity: 1 } }, z: 3,
      });
    });
    // 步兵轨迹（橙，虚线平滑曲线）
    infTraces.forEach((pts) => {
      series.push({
        name: LASE.t('步兵'), type: 'line', data: pts, showSymbol: false, smooth: 0.3,
        lineStyle: { width: 1.8, color: '#d97706', opacity: 0.9, type: 'dashed',
          shadowColor: 'rgba(217, 119, 6, 0.35)', shadowBlur: 5 },
        itemStyle: { color: '#d97706' },
        emphasis: { focus: 'series', lineStyle: { width: 2.6, opacity: 1 } }, z: 3,
      });
    });

    // —— 目标 / 基地标记 ——
    const targets = [];
    if (g.base_pos) targets.push([g.base_pos[0], g.base_pos[1]]);
    else if (Array.isArray(g.base) && g.base.length >= 2) targets.push([g.base[0], g.base[1]]);
    else if (g.target_pos) targets.push([g.target_pos[0], g.target_pos[1]]);
    if (targets.length) {
      series.push({
        name: LASE.t('目标'), type: 'scatter', data: targets,
        symbol: 'circle', symbolSize: 16,
        itemStyle: { color: '#dc2626', borderColor: '#fff', borderWidth: 2.5,
          shadowColor: 'rgba(220, 38, 38, 0.5)', shadowBlur: 10 },
        label: { show: true, formatter: LASE.t('目标'), position: 'right', color: '#dc2626',
          fontSize: 12, fontWeight: 'bold' },
        z: 5,
      });
    }

    // 图例只显示实际存在的类别
    const legendData = [];
    if (nD) legendData.push(LASE.t('无人机'));
    if (infTraces.length) legendData.push(LASE.t('步兵'));
    if (targets.length) legendData.push(LASE.t('目标'));

    const option = {
      toolbox: LASE.saveToolbox(LASE.t('无人机-实景轨迹')),
      tooltip: {
        trigger: 'item',
        backgroundColor: 'rgba(15, 23, 42, 0.92)',
        borderColor: '#334155', borderWidth: 1, padding: [8, 12],
        textStyle: { color: '#e2e8f0', fontSize: 12 },
        formatter: (p) => {
          if (p.seriesType === 'heatmap') return LASE.t('地形高程 ') + Number(p.value[2]).toFixed(1);
          if (p.seriesType === 'scatter') return LASE.t('目标 / 基地');
          const idx = p.seriesIndex;
          if (idx >= heatOffset && idx < heatOffset + nD) {
            return LASE.t('无人机 #{0}', idx - heatOffset + 1)
              + '<br/>x ' + Number(p.value[0]).toFixed(1) + ' · y ' + Number(p.value[1]).toFixed(1);
          }
          return LASE.t('步兵 #{0}', idx - heatOffset - nD + 1)
            + '<br/>x ' + Number(p.value[0]).toFixed(1) + ' · y ' + Number(p.value[1]).toFixed(1);
        },
      },
      legend: {
        data: legendData, top: 4, left: 'center',
        icon: 'roundRect', itemWidth: 14, itemHeight: 5, itemGap: 16,
        textStyle: { color: '#475569', fontSize: 12 },
      },
      grid: { left: 54, right: 24, top: 32, bottom: 54 },
      xAxis: {
        type: 'value', name: 'x', scale: true,
        axisLine: { lineStyle: { color: '#cbd5e1' } },
        axisLabel: { color: '#94a3b8' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.18)' } },
      },
      yAxis: {
        type: 'value', name: 'y', scale: true,
        axisLine: { lineStyle: { color: '#cbd5e1' } },
        axisLabel: { color: '#94a3b8' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.18)' } },
      },
      series,
    };
    if (heatData.length) {
      option.visualMap = {
        dimension: 2, min: zmin, max: zmax, calculable: false, seriesIndex: 0,
        orient: 'horizontal', left: 'center', bottom: 0,
        itemWidth: 14, itemHeight: 110,
        inRange: { color: ['#2f6b3a', '#5b8c4a', '#9bbf6a', '#c9c07a', '#b08a5a', '#8a6a4a'] },
        text: [LASE.t('高'), LASE.t('低')], textGap: 6, textStyle: { color: '#94a3b8', fontSize: 11 }, show: true,
      };
    }
    this._traceChart.setOption(option, true);
  },

  // 从帧序列中逐单位追踪 x-y 轨迹（每个单位一条折线）
  _trackUnits(frs, key) {
    const traces = [];
    let n = 0;
    for (const fr of frs) {
      const list = fr[key];
      if (list && list.length > n) n = list.length;
    }
    for (let k = 0; k < n; k++) {
      const pts = [];
      for (const fr of frs) {
        const list = fr[key];
        const u = list ? list[k] : null;
        if (u && typeof u[0] === 'number' && typeof u[1] === 'number') pts.push([u[0], u[1]]);
      }
      if (pts.length >= 2) traces.push(pts);
    }
    return traces;
  },

  _downloadMap() {
    const is3d = !!(this._result && this._result.geometry
      && this._is3dScenario(this._result.geometry.scenario));
    if (!this._result) { alert(LASE.t('请先运行仿真')); return; }
    if (is3d) {
      const sb = this._sandbox;
      if (!sb) { alert(LASE.t('三维图尚未渲染')); return; }
      sb.renderer.render(sb.scene, sb.camera);
      const a = document.createElement('a');
      a.href = sb.renderer.domElement.toDataURL('image/png');
      a.download = LASE.t('无人机-三维沙盒视图.png');
      a.click();
      return;
    }
    const cv = document.getElementById('uav-map');
    LASE.downloadCanvas(cv, LASE.t('无人机-战场俯视图.png'));
  },

  // 保存视频：优先 WebCodecs(H.264) 导出 MP4（微信/手机可播放）；不支持则回退 MediaRecorder(webm)
  _exportVideo() {
    if (!this._result) { alert(LASE.t('请先运行仿真')); return; }
    const is3d = !!(this._result.geometry && this._is3dScenario(this._result.geometry.scenario));
    if (!is3d) { alert(LASE.t('保存视频仅支持三维沙盒场景')); return; }
    if (this._recording) return;
    if (!this._sandbox || !this._sandbox.built) this._draw();   // 确保沙盒已构建
    const sb = this._sandbox;
    if (!sb || !sb.built) { alert(LASE.t('三维沙盒初始化失败')); return; }
    const frs = this._result.frames || [];
    if (!frs.length) { alert(LASE.t('无动画数据，无法录制')); return; }

    // 暂停手动播放，从头开始完整录制一轮（录制结束后恢复原帧）
    if (this._playing) this._togglePlay();
    const savedFrame = this._frame;
    const btn = document.getElementById('uav-video');
    const sl = document.getElementById('uav-slider');
    this._recording = true;
    if (btn) { btn.textContent = LASE.t('录制中…'); btn.disabled = true; }

    if (typeof VideoEncoder !== 'undefined' && typeof OffscreenCanvas !== 'undefined' &&
        window.Mp4Muxer && window.Mp4Muxer.Muxer) {
      this._exportMp4(sb, frs, savedFrame, btn, sl);
      return;
    }
    this._exportVideoWebm(sb, frs, savedFrame, btn, sl);
  },

  // WebCodecs(H.264) + mp4-muxer 导出 MP4（微信/手机可直接播放）
  async _exportMp4(sb, frs, savedFrame, btn, sl) {
    const fps = 20, stepMs = 1000 / fps;
    const canvas = sb.renderer.domElement;
    // 目标偶数分辨率（限制最大 1600 宽，保证 H.264 编码尺寸合法）
    const scale = Math.min(1, 1600 / canvas.width);
    const w = Math.floor(canvas.width * scale / 2) * 2;
    const h = Math.floor(canvas.height * scale / 2) * 2;
    const off = new OffscreenCanvas(w, h);
    const ctx = off.getContext('2d');
    // 选定 H.264 codec（微信兼容：Main/High 优先，逐级回退 Baseline）
    let codec = '';
    for (const c of ['avc1.4D4028', 'avc1.640028', 'avc1.42E01E']) {
      try {
        const s = await VideoEncoder.isConfigSupported({ codec: c, width: w, height: h, bitrate: 12000000, framerate: fps });
        if (s.supported) { codec = c; break; }
      } catch (e) {}
    }
    if (!codec) { this._exportVideoWebm(sb, frs, savedFrame, btn, sl); return; }

    const muxer = new window.Mp4Muxer.Muxer({
      target: new window.Mp4Muxer.ArrayBufferTarget(),
      video: { codec: 'avc', width: w, height: h },
      fastStart: 'in-memory',
    });
    let encodeError = null;
    let encoder;
    try {
      encoder = new VideoEncoder({
        output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
        error: (e) => { encodeError = e; },
      });
      encoder.configure({ codec, width: w, height: h, bitrate: 12000000, framerate: fps });
    } catch (e) { this._exportVideoWebm(sb, frs, savedFrame, btn, sl); return; }

    const total = frs.length;
    this._frame = 0;
    if (sl) sl.value = 0;
    this._draw();
    sb.renderer.render(sb.scene, sb.camera);

    const finish = async () => {
      try { await encoder.flush(); } catch (e) {}
      try { encoder.close(); } catch (e) {}
      muxer.finalize();
      this._recording = false;
      if (btn) { btn.textContent = LASE.t('保存视频'); btn.disabled = false; }
      this._frame = savedFrame;
      if (sl) sl.value = savedFrame;
      this._draw();
      if (encodeError) { alert(LASE.t('视频编码失败：') + (encodeError.message || encodeError)); return; }
      const blob = new Blob([muxer.target.buffer], { type: 'video/mp4' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = LASE.t('无人机演示视频.mp4');
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    };

    let idx = 0;
    const encodeFrame = () => {
      if (idx >= total) { finish(); return; }
      try {
        this._frame = idx;
        if (sl) sl.value = idx;
        this._draw();
        sb.renderer.render(sb.scene, sb.camera);   // 同步渲染，确保抓取到最新帧（含阵亡动画状态）
        ctx.drawImage(canvas, 0, 0, w, h);
        const frame = new VideoFrame(off, { timestamp: Math.round(idx * 1e6 / fps), duration: Math.round(1e6 / fps) });
        encoder.encode(frame, { keyFrame: idx % fps === 0 });
        frame.close();
      } catch (e) { encodeError = e; }
      idx++;
      setTimeout(encodeFrame, stepMs);
    };
    encodeFrame();
  },

  // 回退方案：MediaRecorder 录制 webm（旧浏览器）
  _exportVideoWebm(sb, frs, savedFrame, btn, sl) {
    let mime = '';
    for (const m of ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm', 'video/mp4']) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported(m)) { mime = m; break; }
    }
    if (!mime) {
      this._recording = false;
      if (btn) { btn.textContent = LASE.t('保存视频'); btn.disabled = false; }
      alert(LASE.t('当前浏览器不支持视频录制'));
      return;
    }

    const stream = sb.renderer.domElement.captureStream(30);
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 12000000 });
    const chunks = [];
    rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };

    this._frame = 0;
    if (sl) sl.value = 0;
    this._draw();

    rec.onstop = () => {
      this._recording = false;
      if (btn) { btn.textContent = LASE.t('保存视频'); btn.disabled = false; }
      this._frame = savedFrame;
      if (sl) sl.value = savedFrame;
      this._draw();
      const ext = mime.includes('mp4') ? 'mp4' : 'webm';
      const blob = new Blob(chunks, { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = LASE.t('无人机演示视频.{0}', ext);
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    };

    rec.start();
    const total = frs.length;
    const stepMs = 50;   // 每帧推进 50ms（画面约 20fps），录制流固定 30fps 采样
    let idx = 0;
    const timer = setInterval(() => {
      idx++;
      if (idx >= total) {
        clearInterval(timer);
        setTimeout(() => { try { rec.stop(); } catch (e) {} }, 150);
        return;
      }
      this._frame = idx;
      if (sl) sl.value = idx;
      this._draw();
    }, stepMs);
  },

  _togglePlay() {
    const btn = document.getElementById('uav-play');
    if (this._playing) {
      this._playing = false; btn.textContent = LASE.t('▶ 播放');
      if (this._anim) { clearInterval(this._anim); this._anim = null; }
    } else {
      if (!this._result || !this._result.frames.length) return;
      this._playing = true; btn.textContent = LASE.t('⏸ 暂停');
      this._startPlayTimer();
    }
  },

  // 按当前倍速启动/重启播放定时器：1× = 60ms/帧，倍速越高间隔越短
  _startPlayTimer() {
    if (this._anim) { clearInterval(this._anim); this._anim = null; }
    const rate = this._playRate || 1;
    const interval = Math.max(10, Math.round(60 / rate));
    this._anim = setInterval(() => {
      this._frame = (this._frame + 1) % this._result.frames.length;
      document.getElementById('uav-slider').value = this._frame;
      this._draw();
    }, interval);
  },

  // 倍速切换：更新状态，若正在播放则立即以新倍速重启定时器
  _setRate(e) {
    this._playRate = parseFloat(e.target.value) || 1;
    if (this._playing) this._startPlayTimer();
  },

  _resizeCanvas() {
    const is3d = !!(this._result && this._result.geometry
      && this._is3dScenario(this._result.geometry.scenario));
    if (is3d) {
      const sb = this._sandbox;
      const host = document.getElementById('uav-map-3d');
      if (sb && host) {
        const w = host.clientWidth || 800, h = host.clientHeight || 520;
        sb.camera.aspect = w / h;
        sb.camera.updateProjectionMatrix();
        sb.renderer.setSize(w, h);
      }
      return;
    }
    const cv = document.getElementById('uav-map');
    const w = cv.parentElement.clientWidth - 2;
    const dpr = window.devicePixelRatio || 1;
    cv.width = w * dpr; cv.height = 520 * dpr;
    cv.style.width = w + 'px'; cv.style.height = '520px';
    if (this._result) this._draw();
  },

  _range() {
    const g = this._result.geometry;
    const xs = [], ys = [];
    const push = (x, y) => { xs.push(x); ys.push(y); };
    g.interceptors0.forEach(p => push(p[0], p[1]));
    if (g.cluster_centers) g.cluster_centers.forEach(p => push(p[0], p[1]));
    if (g.target_pos) push(g.target_pos[0], g.target_pos[1]);
    if (g.start_pos) push(g.start_pos[0], g.start_pos[1]);
    if (g.no_fly_zones) g.no_fly_zones.forEach(z => {
      const r = z[3];   // 球形禁飞区 (cx,cy,cz,r)
      push(z[0] - r, z[1] - r); push(z[0] + r, z[1] + r);
    });
    this._result.frames.forEach(f => {
      f.drones.forEach(d => push(d[0], d[1]));
      f.interceptors.forEach(p => push(p[0], p[1]));
    });
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const padX = (maxX - minX) * 0.05 || 10, padY = (maxY - minY) * 0.05 || 10;
    return { minX: minX - padX, maxX: maxX + padX, minY: minY - padY, maxY: maxY + padY };
  },

  // ---------- 代表轨迹：每个「场景 × 任务」的二维代表曲线 ----------
  // 数据源 = 论文 raw（results/apps/raw/uav_intercept/D30），目前只有 intercept
  // 有实验数据：每个任务的 bare / full 两臂各取 err_final 最小的那次运行，由后端
  // 在同一地形上重放成二维轨迹。面板给出 4 场景 × 4 任务缩略图，点击放大；大图里
  // 可切换两臂显隐，并可把该次运行一键送进三维沙盘回放。
  _reprHost: '',      // '' = 全局最优口径；否则为指定算法（下拉可切换全部宿主）
  _reprRun: 0,        // 指定算法时第几次运行（两臂同 run，同种子，确保对比公平）
  _reprArmColor: { bare: '#2563eb', full: '#e8590c' },
  _reprDash: [[], [9, 4], [2, 3], [13, 4, 2, 4], [6, 3, 1, 3]],
  _reprStateColor: { 0: '#2c5f8a', 1: '#2c7a4b', 2: '#c0392b', 3: '#7d3c98', 4: '#e67e22' },

  async _loadRepr(force) {
    const grid = document.getElementById('uav-repr-grid');
    if (!grid) return;
    if (this._repr && !force) {
      this._renderReprGrid(); this._syncReprControls(); return;
    }
    grid.innerHTML = `<div class="hint">${LASE.t('加载中…')}</div>`;
    const q = this._reprHost
      ? `?host=${encodeURIComponent(this._reprHost)}&run=${Number(this._reprRun) || 0}` : '';
    try {
      this._repr = await LASE.api('/api/uav/repr' + q);
      this._reprTerrainCv = null;
      this._renderReprGrid();
      this._syncReprControls();
    } catch (e) {
      grid.innerHTML = `<div class="hint">${LASE.t('加载失败')}：` +
        `${LASE._esc((e && e.message) || e)}</div>`;
    }
  },

  // 口径控制条：算法下拉（首项「全局最优」+ 全部宿主）+ 运行次数下拉，并解释当前口径
  _syncReprControls() {
    const data = this._repr || {};
    const hostSel = document.getElementById('uav-repr-host');
    const runSel = document.getElementById('uav-repr-run');
    const note = document.getElementById('uav-repr-note');
    if (!hostSel || !runSel) return;
    if (hostSel.options.length !== (data.hosts || []).length + 1) {
      const opts = [`<option value="">${LASE._esc(LASE.t('★ 全局最优（各臂各取最好一次）'))}</option>`];
      (data.hosts || []).forEach((h) => {
        const rk = h.uav_rank ? `#${h.uav_rank} ` : '';
        opts.push(`<option value="${LASE._esc(h.host)}">${rk}${LASE._esc(h.host)}</option>`);
      });
      hostSel.innerHTML = opts.join('');
      hostSel.onchange = () => {
        this._reprHost = hostSel.value;
        this._reprRun = 0;
        this._loadRepr(true);
      };
    }
    const cnt = document.getElementById('uav-repr-count');
    if (cnt) {
      const nH = (data.hosts || []).length;
      if (nH) {
        cnt.textContent = LASE.t('共 {0} 个算法可选', nH);
      } else if (data.available === false) {
        cnt.textContent = LASE.t('暂无代表轨迹数据');
      } else {
        // 有轨迹数据却没有算法清单 → 后端进程还在跑旧代码（hosts 字段是后加的），
        // 重启 web 服务后刷新即可，避免只显示「共 0 个算法可选」让人以为数据丢了
        cnt.textContent = LASE.t('算法清单为空：后端仍在运行旧代码，请重启 web 服务后刷新页面');
      }
    }
    const n = Math.max(1, Number(data.n_runs) || 1);
    if (runSel.options.length !== n) {
      let o = '';
      for (let i = 0; i < n; i++) {
        o += `<option value="${i}">${LASE._esc(LASE.t('第 {0} 次运行', i + 1))}</option>`;
      }
      runSel.innerHTML = o;
      runSel.onchange = () => {
        this._reprRun = Number(runSel.value) || 0;
        this._loadRepr(true);
      };
    }
    hostSel.value = data.selected_host || '';
    runSel.value = String(data.selected_run || 0);
    const on = !!data.selected_host;
    runSel.disabled = !on;                 // 全局最优口径下「第几次运行」没有意义
    runSel.style.opacity = on ? '1' : '0.45';
    if (note) {
      note.innerHTML = on
        ? LASE.t('当前口径：固定算法 {0} 第 {1} 次运行，两臂取自同一次运行（同种子），两条曲线的差异就是 UPCL 的净效果；右上角可切换全部 {2} 个算法与运行次数。',
          `<b>${LASE._esc(data.selected_host)}</b>`, Number(data.selected_run) + 1,
          (data.hosts || []).length)
        : LASE.t('当前口径：全局最优——两臂各自取全部算法中 err_final 最小的一次运行，可能来自不同算法，只说明「这个任务能飞多好」，不能用来评价 UPCL 增益；要评估某个算法的增益，请先在右上角选择它。');
    }
  },

  // 4 场景（行）× 4 任务（列）缩略图网格：有数据的画二维代表轨迹，无数据的占位
  _renderReprGrid() {
    const data = this._repr, grid = document.getElementById('uav-repr-grid');
    if (!data || !grid) return;
    let html = '';
    (data.scenarios || []).forEach((sc, si) => {
      const tasks = sc.tasks || [];
      html += `<div class="uav-repr-rowhead">` +
        `<b>${LASE._esc(LASE.t(sc.name || sc.scenario))}</b>` +
        `<span class="muted"> ${LASE._esc(sc.scenario)}${sc.dim ? ' · D' + sc.dim : ''}` +
        ` · ${LASE._esc(LASE.t('{0} 个任务', tasks.length))}</span>` +
        (sc.has_data ? '' : ` <span class="uav-repr-tag">${LASE.t('暂无实验数据')}</span>`) +
        `</div>`;
      tasks.forEach((t) => {
        const label = this._reprTaskLabel(sc.scenario, t);
        html += `<div class="uav-repr-cell${t.has_data ? '' : ' empty'}" ` +
          `data-si="${si}" data-fid="${t.fid}"` +
          (t.has_data ? ` title="${LASE._esc(LASE.t('点击放大查看二维代表轨迹'))}"` : '') + `>` +
          `<canvas class="uav-repr-cv" width="480" height="480"></canvas>` +
          `<div class="uav-repr-cap"><b>${LASE._esc(label)}</b>` +
          `<div class="muted">${t.has_data ? this._reprCapLine(t) : LASE.t('暂无实验数据')}</div>` +
          `</div></div>`;
      });
    });
    grid.innerHTML = html;
    grid.querySelectorAll('.uav-repr-cell').forEach((cell) => {
      const si = Number(cell.dataset.si), fid = Number(cell.dataset.fid);
      const sc = (data.scenarios || [])[si];
      const t = sc && (sc.tasks || []).filter(x => x.fid === fid)[0];
      if (!t || !t.has_data) return;
      this._drawRepr(cell.querySelector('canvas'), sc, t,
        { arms: { bare: true, full: true } });
    });
  },

  // 任务标签：优先用 /api/uav/meta 的任务名，meta 还没到时退回接口自带的任务名
  _reprTaskLabel(scen, t) {
    const label = this._taskLabel(scen, t.fid);
    if (label.indexOf('·') >= 0 || !t.name) return label;
    return 'F' + t.fid + ' · ' + LASE.t(t.name);
  },

  // 缩略图下方一行小字：两臂的 err_final 与 UPCL 增益 Δ（err 越小越好，故 Δ<0 表示变好）
  _reprCapLine(t) {
    const pick = (arm) => (t.arms || []).filter(x => x.arm === arm)[0];
    const b = pick('bare'), f = pick('full');
    const num = (a) => (a ? `<span class="mono">${Number(a.err_final).toFixed(1)}</span>` : '—');
    const src = t.source || {};
    let who;
    if (src.mode === 'host') {
      who = `${LASE._esc(src.host)} · ${LASE.t('第 {0} 次运行', (src.run || 0) + 1)}`;
    } else if (b && f && b.host === f.host) {
      who = LASE._esc(b.host);
    } else {
      who = `${LASE._esc((b || {}).host || '—')} / ${LASE._esc((f || {}).host || '—')}`;
    }
    let delta = '';
    if (b && f) {
      const d = Number(f.err_final) - Number(b.err_final);
      delta = ` <span class="mono" style="color:${d < 0 ? '#2c7a4b' : '#c0392b'}">` +
        `Δ${d >= 0 ? '+' : ''}${d.toFixed(1)}</span>`;
    }
    return `<span style="color:${this._reprArmColor.bare}">${LASE.t('纯算法')}</span> ${num(b)}` +
      ` → <span style="color:${this._reprArmColor.full}">UPCL</span> ${num(f)}${delta}` +
      `<br><span class="muted">${who}</span>`;
  },

  // 论文插图用的「标题 + 图例 + 一行口径」：图例直接画出颜色/线型/符号本身，
  // 只配极短标签（详细解释写在论文正文里，不塞进图片）。导出时合成进 PNG 像素。
  _reprFigureMeta(sc, t) {
    const src = t.source || {};
    const arms = t.arms || [];
    let nDrone = 0;
    arms.forEach((a) => {
      nDrone = Math.max(nDrone, ((a.tracks || {}).drones || []).length);
    });
    const hostMode = src.mode === 'host';
    const BARE = this._reprArmColor.bare, FULL = this._reprArmColor.full;
    const DASH = this._reprDash;
    const n = Math.max(1, Math.min(4, nDrone || 1));
    const dashName = [LASE.t('实线'), LASE.t('长虚线'), LASE.t('点线'), LASE.t('点划线')];
    const legend = [
      // ① 两臂线色（最要紧，放最前）
      { label: LASE.t('纯算法基线（bare）'), color: BARE, shape: 'line' },
      { label: LASE.t('增加 UPCL（full）'), color: FULL, shape: 'line' },
    ];
    // ② 线型 = 机号（只在同一颜色内部起作用）
    for (let i = 0; i < n; i++) {
      legend.push({
        label: LASE.t('第 {0} 架无人机', i + 1) + '（' + dashName[i] + '）',
        color: BARE, shape: 'line', dash: DASH[i % DASH.length],
      });
    }
    // ③ 航迹类型 + 阵位符号 + 终局状态 + 区域
    legend.push(
      { label: LASE.t('红方拦截者航迹（细虚线）'), color: BARE, shape: 'line', dash: [5, 4] },
      { label: LASE.t('步兵航迹（浅灰）'), color: '#9aa0a6', shape: 'line', dash: [3, 3] },
      { label: LASE.t('红方拦截者阵位'), color: '#e67e22', shape: 'tri' },
      { label: LASE.t('红方防空车'), color: '#ff2020', shape: 'square' },
      { label: LASE.t('红方巡逻兵'), color: '#c0392b', shape: 'dot' },
      { label: LASE.t('蓝方步兵 / 起飞点'), color: '#2c5f8a', shape: 'dotw' },
      { label: LASE.t('终局：到达基地'), color: this._reprStateColor[1], shape: 'dotw' },
      { label: LASE.t('终局：被击落'), color: this._reprStateColor[2], shape: 'dotw' },
      { label: LASE.t('终局：坠毁'), color: this._reprStateColor[3], shape: 'dotw' },
      { label: LASE.t('终局：飞行中'), color: this._reprStateColor[0], shape: 'dotw' },
      { label: LASE.t('目标区（军事基地）'), color: '#2c7a4b',
        fill: 'rgba(44,122,75,.16)', shape: 'dashed-patch', dash: [5, 4] },
      { label: LASE.t('球形禁飞区'), color: 'rgba(120,120,120,.9)',
        shape: 'dashed-circle', dash: [4, 3] },
      { label: LASE.t('预警雷达探测范围'), color: '#3cb371',
        shape: 'dashed-circle', dash: [6, 5] },
    );
    return {
      title: LASE.t('图 · {0} 代表轨迹（{1}）',
        LASE.t(sc.name || sc.scenario), this._reprTaskLabel(sc.scenario, t)),
      legend: legend,
      note: (hostMode
        ? LASE.t('口径：算法 {0} 第 {1} 次运行（两臂同一次运行、同随机种子）',
          src.host, (src.run || 0) + 1)
        : LASE.t('口径：全局最优（两臂各自取 err_final 最小的一次运行，可能来自不同算法，不可用于评价 UPCL 增益）')) +
        '；' + LASE.t('底图：山地高程（浅绿 = 低地，灰白 = 山脊）；err_final 越小越好；数据来源：{0}',
          src.dir || '-'),
    };
  },

  // 共享地形底图（四个任务同一张山地地图）：一次性渲染成离屏画布后缩放复用
  _reprTerrainCanvas() {
    if (this._reprTerrainCv !== undefined) return this._reprTerrainCv;
    const tr = (this._repr || {}).terrain;
    let cv = null;
    if (tr && tr.Z && tr.Z.length && tr.Z[0].length) {
      const n = tr.Z.length, m = tr.Z[0].length;
      cv = document.createElement('canvas');
      cv.width = m; cv.height = n;
      const ctx = cv.getContext('2d');
      const img = ctx.createImageData(m, n);
      let zmin = tr.zmin, zmax = tr.zmax;
      if (zmin == null || zmax == null) {
        zmin = Infinity; zmax = -Infinity;
        tr.Z.forEach(row => row.forEach((v) => {
          if (v < zmin) zmin = v;
          if (v > zmax) zmax = v;
        }));
      }
      const span = (zmax - zmin) || 1;
      for (let i = 0; i < n; i++) {
        for (let j = 0; j < m; j++) {
          const v = Math.max(0, Math.min(1, (tr.Z[i][j] - zmin) / span));
          const p = (i * m + j) * 4;      // 低地浅绿 → 丘陵浅褐 → 山脊灰白
          img.data[p] = Math.round(222 + 26 * v);
          img.data[p + 1] = Math.round(232 - 10 * v);
          img.data[p + 2] = Math.round(214 + 30 * v);
          img.data[p + 3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
    }
    this._reprTerrainCv = cv;
    return cv;
  },

  _reprPoly(ctx, pts, mx, my, color, dash, lw, alpha) {
    if (!pts || pts.length < 2) return;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(mx(pts[0][0]), my(pts[0][1]));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(mx(pts[i][0]), my(pts[i][1]));
    ctx.strokeStyle = color;
    ctx.lineWidth = lw;
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    if (dash && dash.length) ctx.setLineDash(dash);
    ctx.stroke();
    ctx.restore();
  },

  _reprDot(ctx, x, y, r, fill, stroke) {
    ctx.save();
    ctx.beginPath(); ctx.arc(x, y, r, 0, 2 * Math.PI);
    ctx.fillStyle = fill; ctx.fill();
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.3; ctx.stroke(); }
    ctx.restore();
  },

  // 单张二维代表轨迹：地形底图 + 目标区/基地/起飞点/雷达/防空/楼房/兵力 + 两臂各机航迹
  _drawRepr(cv, sc, t, opts) {
    if (!cv || !t) return;
    opts = opts || {};
    const g = t.geometry;
    if (!g) return;
    const ctx = cv.getContext('2d');
    const W = cv.width, H = cv.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#fafbfc'; ctx.fillRect(0, 0, W, H);

    const mapW = g.map_w || g.width || 1000, mapH = g.map_h || g.depth || 1000;
    const pad = 0.02 * Math.max(mapW, mapH);
    const bx0 = -pad, bx1 = mapW + pad, by0 = -pad, by1 = mapH + pad;
    const s = Math.min(W / (bx1 - bx0), H / (by1 - by0));
    const ox = (W - (bx1 - bx0) * s) / 2, oy = (H - (by1 - by0) * s) / 2;
    const mx = (x) => ox + (x - bx0) * s;
    const my = (y) => H - oy - (y - by0) * s;
    const mr = (r) => r * s;
    const big = !!opts.big;
    const showLabels = !!opts.labels;
    const show = opts.arms || { bare: true, full: true };
    const fs = Math.max(9, Math.round(Math.min(W, H) / 44));
    // 缩略图由 CSS 缩到约 300px 显示（内部 480px），线宽/点半径按比例放大后
    // 屏幕上的观感才和大图一致
    const k = big ? 1 : 1.5;
    const col = this._reprArmColor;

    // ① 地形底图（世界 y 向上、画布 y 向下 → 垂直翻转）
    const tcv = this._reprTerrainCanvas();
    if (tcv) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(mx(0), my(mapH), mapW * s, mapH * s);
      ctx.clip();
      ctx.translate(mx(0), my(0));
      ctx.scale(1, -1);
      ctx.drawImage(tcv, 0, 0, mapW * s, mapH * s);
      ctx.restore();
    }

    const label = (txt, x, y, color) => {
      if (!showLabels) return;
      const px = mx(x), py = my(y);
      ctx.save();
      ctx.font = `600 ${fs}px system-ui, -apple-system, "Segoe UI", sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = ctx.measureText(txt).width;
      ctx.fillStyle = 'rgba(255,255,255,.72)';
      ctx.fillRect(px - w / 2 - 3, py - fs * 0.8, w + 6, fs * 1.6);
      ctx.fillStyle = color || '#444';
      ctx.fillText(txt, px, py);
      ctx.restore();
    };

    // ② 禁飞区（二维按水平半径画圆，与战场俯视图一致）
    (g.no_fly_zones || []).forEach((z) => {
      ctx.save();
      ctx.beginPath();
      ctx.arc(mx(z[0]), my(z[1]), Math.max(mr(z[3]), 1.5), 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(120,120,120,.20)'; ctx.fill();
      ctx.strokeStyle = 'rgba(120,120,120,.75)'; ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]); ctx.stroke();
      ctx.restore();
    });
    // ③ 楼房（巷战障碍，字段 [cx, cy, w, d]）
    (g.buildings || []).forEach((b) => {
      ctx.fillStyle = 'rgba(150,145,135,.55)';
      ctx.fillRect(mx(b[0] - b[2] / 2), my(b[1] + b[3] / 2),
        Math.max(b[2] * s, 1.5), Math.max(b[3] * s, 1.5));
    });
    // ④ 预警雷达探测范围
    if (g.radar_pos) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(mx(g.radar_pos[0]), my(g.radar_pos[1]), Math.max(mr(g.radar_range), 2), 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(60,179,113,.06)'; ctx.fill();
      ctx.strokeStyle = 'rgba(60,179,113,.7)'; ctx.lineWidth = 1;
      ctx.setLineDash([6, 5]); ctx.stroke();
      ctx.restore();
      this._reprDot(ctx, mx(g.radar_pos[0]), my(g.radar_pos[1]), 4 * k, '#3cb371', '#fff');
      label(LASE.t('预警雷达'), g.radar_pos[0], g.radar_pos[1] - 0.045 * mapH, '#2c7a4b');
    }
    // ⑤ 目标区 = 军事基地（到达判定半径按 base_radius）
    if (g.target_pos) {
      const rad = Math.max(mr(g.target_radius || 30), 5 * k);
      ctx.save();
      ctx.beginPath();
      ctx.arc(mx(g.target_pos[0]), my(g.target_pos[1]), rad, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(44,122,75,.16)'; ctx.fill();
      ctx.strokeStyle = '#2c7a4b'; ctx.lineWidth = 1.4 * k;
      ctx.setLineDash([5, 4]); ctx.stroke();
      ctx.restore();
      label(LASE.t('目标区（军事基地）'), g.target_pos[0], g.target_pos[1], '#2c7a4b');
    }
    // ⑥ 红方：防空车 / 巡逻兵 / 拦截者初始阵位
    (g.aa0 || []).forEach((p) => {
      const x = mx(p[0]), y = my(p[1]), r = 3.4 * k;
      ctx.fillStyle = '#ff2020';
      ctx.fillRect(x - r, y - r, r * 2, r * 2);
    });
    (g.patrol0 || []).forEach((p) => {
      this._reprDot(ctx, mx(p[0]), my(p[1]), 2.6 * k, '#c0392b', '#fff');
    });
    (g.interceptors0 || []).forEach((p) => {
      const x = mx(p[0]), y = my(p[1]), h = 4.6 * k;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(x, y - h);
      ctx.lineTo(x + h * 0.9, y + h * 0.65);
      ctx.lineTo(x - h * 0.9, y + h * 0.65);
      ctx.closePath();
      ctx.fillStyle = '#e67e22'; ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
      ctx.restore();
    });
    // ⑦ 蓝方：步兵 + 起飞点
    (g.infantry0 || []).forEach((p) => {
      this._reprDot(ctx, mx(p[0]), my(p[1]), 2.6 * k, '#2c5f8a', '#fff');
    });
    (g.starts || []).forEach((p, i) => {
      this._reprDot(ctx, mx(p[0]), my(p[1]), 3.4 * k, '#2c5f8a', '#fff');
      if (i === 0) label(LASE.t('起飞点'), p[0], p[1] - 0.05 * mapH, '#2c5f8a');
    });

    // ⑧ 两臂航迹：粗线 = 无人机（同色不同线型区分机号），细虚线 = 拦截者，浅灰 = 步兵
    (t.arms || []).forEach((a) => {
      if (!show[a.arm]) return;
      const c = col[a.arm] || '#666';
      (a.tracks.interceptors || []).forEach((pts) => {
        this._reprPoly(ctx, pts, mx, my, c, [5, 4], 1.35 * k, 0.45);
      });
      (a.tracks.infantry || []).forEach((pts) => {
        this._reprPoly(ctx, pts, mx, my, '#9aa0a6', [3, 3], k, 0.6);
      });
      (a.tracks.drones || []).forEach((pts, di) => {
        this._reprPoly(ctx, pts, mx, my, c, this._reprDash[di % this._reprDash.length],
          2.3 * k, 0.95);
        const p0 = pts[0], pz = pts[pts.length - 1];
        this._reprDot(ctx, mx(p0[0]), my(p0[1]), 2.6 * k, c, '#fff');
        const st = (a.final_states || [])[di];
        this._reprDot(ctx, mx(pz[0]), my(pz[1]), 3.6 * k,
          this._reprStateColor[st] || '#666', '#fff');
      });
    });

    // ⑨ 画面边框
    ctx.strokeStyle = '#e3e8ef';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox + 0.5, my(by1) + 0.5, (bx1 - bx0) * s - 1, (by1 - by0) * s - 1);
  },

  _reprClick(e) {
    const cell = e.target.closest ? e.target.closest('.uav-repr-cell') : null;
    if (!cell || cell.classList.contains('empty')) return;
    this._showReprModal(Number(cell.dataset.si), Number(cell.dataset.fid));
  },

  // 放大浮层：两臂信息卡（宿主 / 运行号 / err_final / 结局 / 三维回放）+ 臂显隐 + 大图
  _showReprModal(si, fid) {
    const data = this._repr || {};
    const sc = (data.scenarios || [])[si];
    const t = sc && (sc.tasks || []).filter(x => x.fid === fid)[0];
    if (!t || !t.has_data) return;
    const old = document.getElementById('uav-repr-modal');
    if (old) old.remove();
    this._reprArms = { bare: true, full: true };
    this._reprModal = { si: si, fid: fid };

    const overlay = document.createElement('div');
    overlay.id = 'uav-repr-modal';
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; ' +
      'display:flex; align-items:center; justify-content:center; padding:20px;';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    const panel = document.createElement('div');
    panel.style.cssText = 'background:#fff; border-radius:10px; width:min(1240px,100%); ' +
      'max-height:94vh; display:flex; flex-direction:column; ' +
      'box-shadow:0 12px 40px rgba(0,0,0,.3); overflow:hidden;';

    const head = document.createElement('div');
    head.style.cssText = 'padding:12px 20px; background:#2c5f8a; color:#fff;';
    head.innerHTML =
      `<div style="font-size:17px; font-weight:700">${LASE.t('二维代表轨迹')} · ` +
      `${LASE._esc(LASE.t(sc.name || sc.scenario))} · ` +
      `${LASE._esc(this._reprTaskLabel(sc.scenario, t))}</div>` +
      `<div style="font-size:12px; opacity:.85; margin-top:4px">` +
      (t.source && t.source.mode === 'host'
        ? `${LASE.t('口径：固定算法 {0} 第 {1} 次运行，两臂同一次运行（同种子），可直接比较 UPCL 增益',
          LASE._esc(t.source.host), (t.source.run || 0) + 1)}`
        : `${LASE.t('口径：全局最优——两臂各自取 err_final 最小的一次运行，可能来自不同算法，不能用于评价 UPCL 增益')}`) +
      (t.source ? `　·　${LASE._esc(LASE.t('取自 {0}（{1} 个 cell / {2} 次运行）',
        t.source.dir, t.source.n_cells, t.source.n_runs))}` : '') + `</div>` +
      // 弹窗里也能直接换算法 / 换运行次数，不必关掉再回列表
      `<div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin-top:8px; ` +
      `padding-top:8px; border-top:1px solid rgba(255,255,255,.25)">` +
      `<span style="font-size:12px; opacity:.9">${LASE.t('切换算法：')}</span>` +
      `<select id="uav-repr-modal-host" style="font:inherit; font-size:12px; padding:3px 6px; ` +
      `border-radius:4px; border:none; max-width:240px"></select>` +
      `<span style="font-size:12px; opacity:.9">${LASE.t('运行次数')}</span>` +
      `<select id="uav-repr-modal-run" style="font:inherit; font-size:12px; padding:3px 6px; ` +
      `border-radius:4px; border:none"></select>` +
      `<span style="font-size:11.5px; opacity:.8">` +
      `${LASE.t('切换后本弹窗按新算法重新绘制')}</span></div>`;

    // 弹窗内的算法 / 运行次数联动：换完先重载数据，再按同一「场景 × 任务」重开弹窗
    const hSel = head.querySelector('#uav-repr-modal-host');
    const rSel = head.querySelector('#uav-repr-modal-run');
    if (hSel && rSel) {
      const dd = this._repr || {};
      let o = `<option value="">${LASE._esc(LASE.t('★ 全局最优（各臂各取最好一次）'))}</option>`;
      (dd.hosts || []).forEach((h) => {
        const rk = h.uav_rank ? `#${h.uav_rank} ` : '';
        o += `<option value="${LASE._esc(h.host)}">${rk}${LASE._esc(h.host)}</option>`;
      });
      hSel.innerHTML = o;
      hSel.value = dd.selected_host || '';
      const nr = Math.max(1, Number(dd.n_runs) || 1);
      let ro = '';
      for (let i = 0; i < nr; i++) {
        ro += `<option value="${i}">${LASE._esc(LASE.t('第 {0} 次运行', i + 1))}</option>`;
      }
      rSel.innerHTML = ro;
      rSel.value = String(dd.selected_run || 0);
      rSel.disabled = !dd.selected_host;
      const go = async () => {
        this._reprHost = hSel.value;
        this._reprRun = Number(rSel.value) || 0;
        overlay.remove();                       // 先撤掉旧弹窗，避免重载时挂着旧数据
        await this._loadRepr(true);
        this._showReprModal(si, fid);
      };
      hSel.onchange = go;
      rSel.onchange = go;
    }

    const card = (a) => {
      const c = this._reprArmColor[a.arm] || '#666';
      const nDrone = (a.tracks.drones || []).length;
      const dash = (i) => ['——', '- - -', '····', '-·-·'][i % 4];
      return `<div style="border:1px solid #e3e8ef; border-left:4px solid ${c}; border-radius:6px; ` +
        `padding:8px 10px; flex:1 1 280px; min-width:260px">` +
        `<div style="font-weight:700; color:${c}">` +
        `${a.arm === 'bare' ? LASE.t('纯算法基线（bare）') : LASE.t('增加 UPCL（full）')}</div>` +
        `<div class="muted" style="font-size:12px">${LASE._esc(t.source && t.source.mode === 'host'
          ? LASE.t('算法') : LASE.t('最优解来自'))} ` +
        `<b>${LASE._esc(a.host)}</b>（R${a.run + 1}）</div>` +
        `<div style="font-size:12px; margin-top:4px">err_final ` +
        `<span class="mono">${Number(a.err_final).toFixed(3)}</span> · ` +
        `${LASE._esc(LASE.t('重放步数 {0}', a.n_steps))}</div>` +
        `<div style="font-size:12px">` +
        `${LASE._esc(LASE.t('到达 {0} · 击落 {1} · 坠毁 {2}', a.arrived, a.lost, a.crashed))}</div>` +
        `<div style="font-size:12px; margin-top:3px" class="muted">` +
        Array.from({ length: nDrone }, (_, i) => `${dash(i)} ${LASE.t('第 {0} 架', i + 1)}`)
          .join('　') + `</div>` +
        `<button class="btn" data-rsplay="${a.arm}" data-host="${LASE._esc(a.host)}" ` +
        `data-run="${a.run}" style="margin-top:6px; font-size:12px">` +
        `${LASE.t('在三维沙盘中回放此次运行')}</button></div>`;
    };

    const body = document.createElement('div');
    body.style.cssText = 'padding:12px 20px; overflow:auto; font-size:13px; color:#333;';
    body.innerHTML =
      `<div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:10px">` +
      (t.arms || []).map(card).join('') + `</div>` +
      `<div style="display:flex; gap:8px; align-items:center; margin-bottom:8px; flex-wrap:wrap">` +
      `<span class="muted" style="font-size:12px">${LASE.t('显示：')}</span>` +
      `<button class="btn primary" data-rsarm="bare" style="font-size:12px; ` +
      `border-left:4px solid ${this._reprArmColor.bare}">${LASE.t('纯算法基线（bare）')}</button>` +
      `<button class="btn primary" data-rsarm="full" style="font-size:12px; ` +
      `border-left:4px solid ${this._reprArmColor.full}">${LASE.t('增加 UPCL（full）')}</button>` +
      `<span class="muted" style="font-size:11.5px">` +
      `${LASE.t('粗线 = 无人机航迹（线型区分机号），细虚线 = 红方拦截者，浅灰虚线 = 步兵；灰圆 = 禁飞区，绿圈 = 目标区/基地，橙三角 = 拦截者阵位，红方块 = 防空车。')}</span>` +
      `</div>` +
      `<canvas id="uav-repr-canvas" width="1040" height="1040" ` +
      `style="width:100%; max-width:min(880px,100%); height:auto; display:block; margin:0 auto; ` +
      `border:1px solid #e3e8ef; border-radius:6px; background:#fafbfc"></canvas>`;

    const foot = document.createElement('div');
    foot.style.cssText = 'padding:10px 20px; border-top:1px solid #eee; display:flex; ' +
      'gap:8px; align-items:center; flex-wrap:wrap;';
    const note = document.createElement('span');
    note.className = 'muted';
    note.style.cssText = 'font-size:11.5px; flex:1 1 auto';
    note.textContent = LASE.t('导出的 PNG 会自动在图下方附上标题与脚注，写明每个元素的含义，可直接插入论文。');
    const dl = document.createElement('button');
    dl.className = 'btn';
    dl.textContent = LASE.t('下载图片（含图例）');
    dl.onclick = () => {
      const cv = document.getElementById('uav-repr-canvas');
      if (!cv) return;
      LASE.downloadFigure(cv,
        LASE.t('无人机-代表轨迹-{0}-F{1}.png', sc.scenario, fid),
        this._reprFigureMeta(sc, t));
    };
    const close = document.createElement('button');
    close.className = 'btn primary';
    close.textContent = LASE.t('关闭');
    close.onclick = () => overlay.remove();
    foot.appendChild(note); foot.appendChild(dl); foot.appendChild(close);

    panel.appendChild(head); panel.appendChild(body); panel.appendChild(foot);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    this._drawReprModal();

    body.onclick = (e) => {
      const armBtn = e.target.closest ? e.target.closest('[data-rsarm]') : null;
      if (armBtn) {
        const key = armBtn.dataset.rsarm;
        this._reprArms[key] = !this._reprArms[key];
        if (!this._reprArms.bare && !this._reprArms.full) this._reprArms[key] = true;
        body.querySelectorAll('[data-rsarm]').forEach((b) => {
          b.classList.toggle('primary', !!this._reprArms[b.dataset.rsarm]);
        });
        this._drawReprModal();
        return;
      }
      const playBtn = e.target.closest ? e.target.closest('[data-rsplay]') : null;
      if (playBtn) {
        // 回放要在主页面渲染真三维沙盘，先收起本浮层，否则沙盘被浮层遮住
        overlay.remove();
        this._playPaperTrace(fid, playBtn.dataset.host,
          Number(playBtn.dataset.run), playBtn.dataset.rsplay);
      }
    };
  },

  _drawReprModal() {
    const m = this._reprModal;
    if (!m) return;
    const cv = document.getElementById('uav-repr-canvas');
    const data = this._repr || {};
    const sc = (data.scenarios || [])[m.si];
    const t = sc && (sc.tasks || []).filter(x => x.fid === m.fid)[0];
    if (!cv || !t) return;
    this._drawRepr(cv, sc, t, { big: true, labels: true, arms: this._reprArms });
  },

  _draw() {
    if (!this._result) return;
    const is3d = this._result.geometry
      && this._is3dScenario(this._result.geometry.scenario);
    // 三维场景默认用 three.js 沙盘渲染；用户切到「2D 俯视图」时走下面的
    // Canvas 俯视图（同一份 frames，包含轨迹虚线 / 拦截者扇形 / 单位状态色）
    if (is3d && this._viewMode !== '2d') { this._draw3d(); return; }
    const cv = document.getElementById('uav-map');
    const ctx = cv.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const W = cv.width / dpr, H = cv.height / dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#fafbfc'; ctx.fillRect(0, 0, W, H);

    const g = this._result.geometry;
    const R = this._range();
    const mx = (x) => (x - R.minX) / (R.maxX - R.minX) * W;
    const my = (y) => H - (y - R.minY) / (R.maxY - R.minY) * H;
    const mr = (r) => r / (R.maxX - R.minX) * W;

    // 禁飞区（球形，二维俯视图按水平半径 z[3] 画圆）
    if (g.no_fly_zones) g.no_fly_zones.forEach(z => {
      ctx.beginPath(); ctx.arc(mx(z[0]), my(z[1]), Math.max(mr(z[3]), 2), 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(120,120,120,.25)'; ctx.fill();
      ctx.strokeStyle = '#888'; ctx.stroke();
    });

    // 目标区 / 集群中心
    if (g.target_pos) {
      ctx.beginPath(); ctx.arc(mx(g.target_pos[0]), my(g.target_pos[1]), Math.max(mr(g.target_radius), 4), 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(44,122,75,.18)'; ctx.fill();
      ctx.strokeStyle = '#2c7a4b'; ctx.setLineDash([5, 4]); ctx.stroke(); ctx.setLineDash([]);
    }
    if (g.cluster_centers) g.cluster_centers.forEach(p => {
      ctx.beginPath(); ctx.arc(mx(p[0]), my(p[1]), 5, 0, 2 * Math.PI);
      ctx.fillStyle = '#e67e22'; ctx.fill();
    });

    // 实际飞行轨迹（虚线）：由逐步快照还原每架无人机的真实路径，保证虚线
    // 与动画中的飞行路径一致（而非用直线段连接规划航点，导致虚线悬空不符）。
    const frs = this._result.frames || [];
    const nDrones = this._result.n_drones || (frs.length ? frs[0].drones.length : 0);
    for (let j = 0; j < nDrones; j++) {
      const pts = [];
      for (let t = 0; t < frs.length; t++) {
        const d = frs[t].drones && frs[t].drones[j];
        if (d) pts.push([d[0], d[1]]);
      }
      if (pts.length < 2) continue;
      ctx.beginPath();
      ctx.moveTo(mx(pts[0][0]), my(pts[0][1]));
      for (let i = 1; i < pts.length; i++) ctx.lineTo(mx(pts[i][0]), my(pts[i][1]));
      ctx.strokeStyle = '#aaa'; ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]);
    }
    // 规划航点（决策变量，小圆点标记）
    (this._result.waypoints || []).forEach(w => {
      w.forEach(p => { ctx.beginPath(); ctx.arc(mx(p[0]), my(p[1]), 2.5, 0, 2 * Math.PI); ctx.fillStyle = '#999'; ctx.fill(); });
    });

    const frame = this._result.frames[this._frame];
    if (!frame) return;
    document.getElementById('uav-frame-label').textContent =
      `${this._frame + 1}/${this._result.frames.length} · step=${frame.step}`;

    // 拦截者扇形 + 拦截者
    const unit = g.half_angle_unit === 'deg' ? Math.PI / 180 : 1;
    frame.interceptors.forEach(p => {
      const x = mx(p[0]), y = my(p[1]), heading = p[3];
      const radius = Math.max(mr(g.intercept_radius), 8);
      const half = g.intercept_half_angle * unit;
      ctx.beginPath(); ctx.moveTo(x, y);
      ctx.arc(x, y, radius, -heading - half, -heading + half);
      ctx.closePath();
      ctx.fillStyle = 'rgba(230,126,34,.22)'; ctx.fill();
      ctx.strokeStyle = 'rgba(230,126,34,.6)'; ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y, 5, 0, 2 * Math.PI);
      ctx.fillStyle = '#e67e22'; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.stroke();
    });

    // 无人机
    const colors = { 0: '#2c5f8a', 1: '#2c7a4b', 2: '#c0392b', 3: '#7d3c98', 4: '#e67e22' };
    frame.drones.forEach(d => {
      const x = mx(d[0]), y = my(d[1]), st = d[3], hd = d[4];
      ctx.beginPath(); ctx.arc(x, y, 6, 0, 2 * Math.PI);
      ctx.fillStyle = colors[st] || '#666'; ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      // 朝向
      ctx.beginPath(); ctx.moveTo(x, y);
      ctx.lineTo(x + Math.cos(hd) * 12, y - Math.sin(hd) * 12);
      ctx.strokeStyle = colors[st] || '#666'; ctx.lineWidth = 2; ctx.stroke();
    });
  },

  // ---------- 三维场景（flood / flood_v2 / intercept）----------
  // 视图模式：2D 俯视图 / 3D 沙盘（三维场景两者同源，可随时切换，二维图保留）
  _viewModeClick(e) {
    const t = e.target.closest ? e.target.closest('[data-vm]') : null;
    if (t) this._setViewMode(t.dataset.vm);
  },

  _setViewMode(mode) {
    this._viewMode = mode === '2d' ? '2d' : '3d';
    this._applyView();
    this._draw();
  },

  // 按当前视图模式显示 2D 画布或 3D 沙盘（含视角控件与鼠标提示的显隐）
  _applyView() {
    const geo = (this._result && this._result.geometry) || {};
    const scen = geo.scenario;
    const is3d = !!scen && this._is3dScenario(scen);
    const isFlood = scen === 'flood' || scen === 'flood_v2';
    const wrap = document.getElementById('uav-viewmode');
    const cv = document.getElementById('uav-map');
    const d3 = document.getElementById('uav-map-3d');
    const hint = document.getElementById('uav-3d-hint');
    const vc = document.getElementById('uav-3d-viewctl');
    const drop = document.getElementById('uav-drop-view');
    if (wrap) wrap.style.display = is3d ? '' : 'none';
    if (!is3d) this._viewMode = '2d';          // 非三维场景恒为俯视图
    const use3d = is3d && this._viewMode !== '2d';
    if (cv) cv.style.display = use3d ? 'none' : '';
    if (d3) d3.style.display = use3d ? '' : 'none';
    if (hint) hint.style.display = use3d ? '' : 'none';
    if (vc) vc.style.display = use3d ? '' : 'none';
    if (drop) drop.style.display = (use3d && isFlood) ? '' : 'none';
    if (!use3d) this._resizeCanvas();
    this._syncViewModeBtns();
  },

  _syncViewModeBtns() {
    const wrap = document.getElementById('uav-viewmode');
    if (!wrap || !wrap.querySelectorAll) return;
    const cur = this._viewMode === '2d' ? '2d' : '3d';
    wrap.querySelectorAll('[data-vm]').forEach((b) => {
      b.classList.toggle('primary', b.dataset.vm === cur);
    });
  },

  // 论文实验数据回放的来源提示条（说明轨迹是重放，并对照论文原始记录）
  _paperBadge(r) {
    const el = document.getElementById('uav-paper-badge');
    if (!el) return;
    const p = r && r.paper;
    if (!p) { el.style.display = 'none'; el.innerHTML = ''; return; }
    const armName = p.arm === 'bare' ? LASE.t('纯算法基线') : LASE.t('增加 UPCL');
    const n = (v) => (typeof v === 'number' && isFinite(v)) ? v : 0;
    const cmp = (a, b) => ((typeof p.consistent === 'boolean'
      ? p.consistent : n(a) === n(b))
      ? LASE.t('重放结局与论文记录一致')
      : LASE.t('重放结局与论文记录略有差异（统计口径随源代码版本演进变化）'));
    el.style.display = '';
    el.innerHTML =
      `<div class="card-title" style="margin-bottom:6px">${LASE.t('论文实验数据回放')}</div>` +
      `<div class="muted" style="font-size:12px; line-height:1.75">` +
      `${LASE.t('算法')} <b>${LASE._esc(r.host || '')}</b> · ` +
      `${LASE.t('任务')} <b>${LASE._esc(this._taskLabel('intercept', r.fid))}</b> · ` +
      `${LASE._esc(LASE.t('第 {0}/{1} 次运行', (p.run || 0) + 1, p.n_runs || 0))} · ` +
      `${LASE.t('模式')} <b>${LASE._esc(armName)}</b><br/>` +
      `${LASE.t('优化 seed')} ${p.seed} · ` +
      `${LASE.t('论文目标函数值')} ` +
      `${p.err_final == null ? '—' : p.err_final.toFixed(2)} · ` +
      `${LASE.t('论文耗时')} ` +
      `${p.wall_time_s == null ? '—' : (p.wall_time_s / 60).toFixed(1) + ' min'} · ` +
      `${LASE.t('重放步数')} ${p.n_steps}<br/>` +
      `${LASE.t('重放结局：到达 {0} · 击落 {1} · 坠毁 {2}（论文记录：到达 {3} · 击落 {4}）',
        n(p.replay_arrived), n(p.replay_lost), n(p.replay_crashed),
        n(p.paper_arrived), n(p.paper_lost))}<br/>` +
      `${LASE.t('三维轨迹由论文最优解在同一地形与拦截设置下重放，画面与结局统计取自重放结果：{0}。',
        cmp(p.paper_arrived, p.replay_arrived))}` +
      `</div>`;
  },

  // 回放论文实验的某一次运行（真三维沙盘 + 二维俯视图，复用实时仿真的渲染）
  async _playPaperTrace(fid, host, run, arm) {
    const prog = document.getElementById('uav-prog');
    if (prog) prog.textContent = LASE.t('重放论文轨迹…');
    try {
      const r = await LASE.api('/api/uav/paper/trace?fid=' + encodeURIComponent(fid) +
        '&host=' + encodeURIComponent(host) + '&run=' + encodeURIComponent(run) +
        '&arm=' + encodeURIComponent(arm));
      if (prog) prog.textContent = '';
      this._renderResult(r);
      const el = document.getElementById('uav-paper-badge');
      if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {
      if (prog) prog.textContent = '';
      alert(LASE.t('重放论文轨迹失败：') + e);
    }
  },

  _prepare3dMap() {
    const cv = document.getElementById('uav-map');
    const d3 = document.getElementById('uav-map-3d');
    const hint = document.getElementById('uav-3d-hint');
    const drop = document.getElementById('uav-drop-view');
    const vc = document.getElementById('uav-3d-viewctl');
    const isFlood = this._isFloodScenario(this._scenSel && this._scenSel.value);
    if (cv) cv.style.display = 'none';
    if (d3) d3.style.display = '';
    if (hint) hint.style.display = '';
    // 投放视角仅山区救援（cargos 投放）有意义，intercept 对抗无投放，隐藏
    if (drop) drop.style.display = isFlood ? '' : 'none';
    if (vc) vc.style.display = '';
    this._disposeSandbox();
    if (this._map3dChart) { this._map3dChart.dispose(); this._map3dChart = null; }
    this._view = null;
  },

  _disposeSandbox() {
    if (!this._sandbox) return;
    const sb = this._sandbox;
    if (sb.rafId) cancelAnimationFrame(sb.rafId);
    if (sb.controls) sb.controls.dispose();
    if (sb.scene) {
      sb.scene.traverse(o => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => {
            if (m.map) m.map.dispose();
            m.dispose();
          });
        }
      });
    }
    if (sb.renderer) {
      sb.renderer.dispose();
      const el = sb.renderer.domElement;
      if (el && el.parentNode) el.parentNode.removeChild(el);
    }
    this._sandbox = null;
  },

  // Three.js 沙盒渲染器（自由拖拽旋转/缩放/平移的真实 3D 场景）
  _ensureSandbox() {
    if (this._sandbox) return this._sandbox;
    if (typeof THREE === 'undefined' || !THREE.OrbitControls) return null;
    const host = document.getElementById('uav-map-3d');
    if (!host) return null;
    const W = host.clientWidth || 800, H = host.clientHeight || 520;

    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(W, H);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.touchAction = 'none';
    host.innerHTML = '';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#b8dff7');
    scene.fog = new THREE.Fog('#cfe6f7', 140, 340);

    const camera = new THREE.PerspectiveCamera(38, W / H, 0.1, 1000);
    camera.position.set(80, 72, 100);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.target.set(50, 6, 25);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI * 0.52;
    controls.minDistance = 8;
    controls.maxDistance = 260;
    controls.rotateSpeed = 0.9;
    controls.zoomSpeed = 1.1;
    controls.panSpeed = 0.9;
    controls.screenSpacePanning = true;

    const sb = {
      renderer, scene, camera, controls, rafId: 0, built: false,
      frame: { cargos: [], relays: [], blades: [], heliRotors: [], disasters: [],
               infantry: [], patrol: [], base: [0, 0] },
    };
    this._sandbox = sb;

    // —— 灵活查看：单击聚焦 + 滚轮朝光标缩放 ——
    // 让旋转中心（controls.target）跟随「正在查看的局部」，而非永远锁死在场景中心
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const pickTerrain = (clientX, clientY) => {
      if (!sb.terrain) return null;
      const r = renderer.domElement.getBoundingClientRect();
      mouse.set(((clientX - r.left) / r.width) * 2 - 1,
        -((clientY - r.top) / r.height) * 2 + 1);
      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObject(sb.terrain, false);
      return hits.length ? hits[0].point : null;
    };
    // 单击（非拖拽）地形：把旋转中心平滑移到该点，之后旋转就围绕这块局部进行
    let _downX = 0, _downY = 0, _downT = 0;
    renderer.domElement.addEventListener('pointerdown', (e) => {
      if (e.button === 0) { _downX = e.clientX; _downY = e.clientY; _downT = performance.now(); }
    });
    renderer.domElement.addEventListener('pointerup', (e) => {
      if (e.button !== 0) return;
      if (Math.hypot(e.clientX - _downX, e.clientY - _downY) > 5) return;
      if (performance.now() - _downT > 400) return;
      const p = pickTerrain(e.clientX, e.clientY);
      if (!p) return;
      sb._focusAnim = { from: controls.target.clone(), to: p.clone(), start: performance.now(), dur: 260 };
    });
    // 滚轮放大时，旋转中心向光标下的地形靠拢，实现「朝光标聚焦」
    renderer.domElement.addEventListener('wheel', (e) => {
      if (e.deltaY >= 0) return;   // 仅放大时聚焦，缩小保持默认
      const p = pickTerrain(e.clientX, e.clientY);
      if (!p) return;
      controls.target.lerp(p, 0.16);
      controls.update();
    }, { passive: true });

    const loop = () => {
      sb.rafId = requestAnimationFrame(loop);
      const t = performance.now() * 0.001;
      const dt = Math.min(0.05, t - (sb._lastT || t));
      sb._lastT = t;
      // 聚焦动画：easeInOutQuad 平滑移动旋转中心
      if (sb._focusAnim) {
        const a = sb._focusAnim;
        const k0 = Math.min(1, (performance.now() - a.start) / a.dur);
        const k = k0 < 0.5 ? 2 * k0 * k0 : 1 - Math.pow(-2 * k0 + 2, 2) / 2;
        sb.controls.target.lerpVectors(a.from, a.to, k);
        if (k0 >= 1) sb._focusAnim = null;
      }
      sb.controls.update();
      sb.frame.blades.forEach(b => { b.rotation.y = t * 45; });
      // 直升机旋翼：转速平滑逼近目标值（起飞加速 / 降落减速），再累加旋转角
      sb.frame.heliRotors.forEach(r => {
        const s = r.userData.spin + (r.userData.target - r.userData.spin) * Math.min(1, dt * 2.2);
        r.userData.spin = s;
        r.rotation.y += s * dt;
      });
      if (sb.frame.flag) {
        sb.frame.flag.rotation.y = Math.sin(t * 2.2) * 0.4 + Math.sin(t * 0.7) * 0.15;
      }
      // 防空车雷达旋转扫描 + 预警雷达站天线旋转 + 瀑布/河流水流滚动
      (sb.frame.aa_radars || []).forEach(r => { r.rotation.y = t * 2.4; });
      (sb.frame.radar_spins || []).forEach(r => { r.rotation.y = t * 1.8; });
      // 网状半球雷达罩：缓慢自转 + 透明度呼吸；扫描波束：快速绕 Y 旋转
      (sb.frame.radar_domes || []).forEach(d => {
        d.rotation.y = t * 0.30;
        d.material.opacity = 0.16 + 0.10 * (0.5 + 0.5 * Math.sin(t * 1.4));
      });
      (sb.frame.radar_sweeps || []).forEach(s => { s.rotation.y = t * 2.4; });
      (sb.frame.waterflowMats || []).forEach(m => { m.uniforms.uTime.value = t * 1.5; });
      if (sb.frame.riverflowTex) sb.frame.riverflowTex.offset.x = -t * 0.6;
      // 巡逻兵「发现入侵者」警示标志闪烁：脉动缩放 + 透明度呼吸
      (sb.frame.patrol || []).forEach(grp => {
        const a = grp.userData && grp.userData.alert;
        if (a && a.visible) {
          const k = 0.5 + 0.5 * Math.sin(t * 6.0);
          a.material.opacity = 0.35 + 0.65 * k;
          const s = 1.0 + 0.28 * k;
          a.scale.set(s, s, 1);
        }
      });
      // 士兵阵亡动画：快速倒地（easeOut）→ 尸体停留 → 缓慢淡出 + 血泊扩散，结束后隐藏
      (sb.frame.infantry || []).concat(sb.frame.patrol || []).forEach(grp => {
        if (!grp.userData.dead || grp.userData.deadDone) return;
        const T = grp.userData.deadT = (grp.userData.deadT || 0) + dt;
        const DUR = 1.8, FALL = 0.5;
        const k = Math.min(1, T / DUR);
        const f = Math.min(1, T / FALL);
        const e = 1 - Math.pow(1 - f, 3);             // easeOutCubic：0.5s 内倒地 90°
        grp.rotation.z = grp.userData.deadDir * (Math.PI / 2) * e;
        // 倒地动作完成后尸体保持姿态，随后整体缓慢淡出
        const fade = k < 0.4 ? 1 : Math.max(0, 1 - (k - 0.4) / 0.6);
        grp.traverse(o => { if (o.material && o.material.transparent) o.material.opacity = fade; });
        const ring = grp.userData.deathRing;
        if (ring) {
          const rk = Math.min(1, T / 0.9);
          const s = 0.3 + 3.6 * (1 - Math.pow(1 - rk, 2));
          ring.scale.set(s, s, 1);
          ring.material.opacity = 0.9 * (1 - rk);
        }
        if (T > DUR) {
          grp.visible = false;
          grp.userData.deadDone = true;
          if (ring) {
            sb.scene.remove(ring);
            ring.geometry.dispose();
            ring.material.dispose();
            grp.userData.deathRing = null;
          }
        }
      });
      // 拦截/击落/坠毁反馈动画（爆炸扩散、捕获光束淡出、无人机坠落）
      this._updateFx(sb, dt);
      renderer.render(scene, camera);
    };
    loop();
    return sb;
  },

  _viewCtl(e) {
    const btn = e.target.closest('button[data-view]');
    const sb = this._sandbox;
    if (!btn || !sb) return;
    const cam = sb.camera, tgt = sb.controls.target;
    const act = btn.dataset.view;
    if (act === 'reset') {
      cam.position.copy(sb.homeCam || new THREE.Vector3(80, 72, 100));
      tgt.copy(sb.homeTarget || new THREE.Vector3(50, 6, 25));
    } else if (act === 'zoom-in') {
      cam.position.lerp(tgt, 0.18);   // 拉近
    } else if (act === 'zoom-out') {
      cam.position.lerp(tgt, -0.22);  // 拉远
    } else {
      const off = cam.position.clone().sub(tgt);
      const sph = new THREE.Spherical().setFromVector3(off);
      if (act === 'rot-l') sph.theta -= 0.32;
      else if (act === 'rot-r') sph.theta += 0.32;
      else if (act === 'pitch-up') sph.phi = Math.max(0.06, sph.phi - 0.28);
      else if (act === 'pitch-down') sph.phi = Math.min(1.45, sph.phi + 0.28);
      cam.position.copy(tgt).add(new THREE.Vector3().setFromSpherical(sph));
    }
    sb.controls.update();
  },

  _draw3d() {
    const sb = this._ensureSandbox();
    if (!sb) return;
    if (!sb.built) {
      this._buildSandbox();
      sb.built = true;
    }
    this._updateSandboxFrame();
  },

  // ---------- 沙盒：坐标换算 / 配色 / 地形 / 水面 ----------
  _sandboxColor(h01) {
    // DEM 高程分层设色（hypsometric tinting）：绿(低) → 黄绿 → 黄棕 → 棕 → 灰 → 白(雪顶)
    const stops = [
      [0.00, [0.22, 0.48, 0.22]], [0.12, [0.35, 0.58, 0.24]],
      [0.30, [0.52, 0.66, 0.28]], [0.48, [0.72, 0.72, 0.36]],
      [0.62, [0.78, 0.60, 0.35]], [0.75, [0.66, 0.46, 0.30]],
      [0.86, [0.52, 0.36, 0.28]], [0.93, [0.66, 0.62, 0.58]],
      [0.98, [0.88, 0.88, 0.90]], [1.00, [1.00, 1.00, 1.00]],
    ];
    let a = stops[0], b = stops[stops.length - 1];
    for (let i = 0; i < stops.length - 1; i++) {
      if (h01 >= stops[i][0] && h01 <= stops[i + 1][0]) { a = stops[i]; b = stops[i + 1]; break; }
    }
    const tt = (h01 - a[0]) / ((b[0] - a[0]) || 1);
    return [a[1][0] + (b[1][0] - a[1][0]) * tt,
            a[1][1] + (b[1][1] - a[1][1]) * tt,
            a[1][2] + (b[1][2] - a[1][2]) * tt];
  },

  // 程序化生成地表细节纹理（Canvas 绘制，零外部资源）：
  // - color：浅底 + 随机色斑/草叶条纹，与顶点海拔色带相乘，消除纯色塑料感
  // - bump：灰度噪点高度图，模拟草叶/碎石等微观起伏
  _makeGroundTextures() {
    const S = 256;
    let seed = 42;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };

    const cc = document.createElement('canvas');
    cc.width = cc.height = S;
    const ctx = cc.getContext('2d');
    // 近白的纸张底 + 极微弱颗粒，让 DEM 分层设色色带保持纯净，仅保留质感
    ctx.fillStyle = '#f7f7f5';
    ctx.fillRect(0, 0, S, S);
    for (let i = 0; i < 2600; i++) {
      const v = 235 + rnd() * 20;
      ctx.fillStyle = `rgba(${v | 0},${v | 0},${v | 0},${0.05 + rnd() * 0.12})`;
      const sz = 1 + rnd() * 2;
      ctx.fillRect(rnd() * S, rnd() * S, sz, sz);
    }
    const colorTex = new THREE.CanvasTexture(cc);
    colorTex.wrapS = colorTex.wrapT = THREE.RepeatWrapping;
    if (THREE.sRGBEncoding !== undefined) colorTex.encoding = THREE.sRGBEncoding;

    const bc = document.createElement('canvas');
    bc.width = bc.height = S;
    const bctx = bc.getContext('2d');
    bctx.fillStyle = '#808080';
    bctx.fillRect(0, 0, S, S);
    for (let i = 0; i < 3800; i++) {
      const v = 90 + rnd() * 100;
      bctx.fillStyle = `rgb(${v | 0},${v | 0},${v | 0})`;
      const sz = 1 + rnd() * 2.5;
      bctx.fillRect(rnd() * S, rnd() * S, sz, sz);
    }
    const bumpTex = new THREE.CanvasTexture(bc);
    bumpTex.wrapS = bumpTex.wrapT = THREE.RepeatWrapping;

    return { color: colorTex, bump: bumpTex };
  },

  // 径向渐变软阴影贴片（contact shadow decal）：贴在地面物体底部，
  // 模拟物体与地面的接触阴影，消除「漂浮/悬浮」感
  _makeSoftShadowTexture() {
    const S = 128;
    const c = document.createElement('canvas');
    c.width = c.height = S;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(S / 2, S / 2, S * 0.02, S / 2, S / 2, S / 2);
    g.addColorStop(0, 'rgba(0,0,0,0.55)');
    g.addColorStop(0.45, 'rgba(0,0,0,0.28)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, S, S);
    return new THREE.CanvasTexture(c);
  },

  _buildSandbox() {
    const sb = this._sandbox;
    const scene = sb.scene;
    const g = this._result.geometry;
    const t = g.terrain;
    const xs = t.xs, ys = t.ys, Z = t.Z;
    const nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    let zmin = Infinity, zmax = -Infinity;
    for (let i = 0; i < ny; i++) for (let j = 0; j < nx; j++) {
      const v = Z[i][j]; if (v < zmin) zmin = v; if (v > zmax) zmax = v;
    }
    const xRange = xmax - xmin || 1, yRange = ymax - ymin || 1, zRange = zmax - zmin || 1;
    const S = 100 / xRange, Hh = 18 / zRange;
    const sx = x => (x - xmin) * S, sz = y => (y - ymin) * S, sy = z => (z - zmin) * Hh;
    const P = (x, y, z) => new THREE.Vector3((x - xmin) * S, (z - zmin) * Hh, (y - ymin) * S);
    sb.sx = sx; sb.sz = sz; sb.sy = sy; sb.P = P;
    sb.xmin = xmin; sb.xmax = xmax; sb.ymin = ymin; sb.ymax = ymax;
    sb.zmin = zmin; sb.zmax = zmax; sb.zRange = zRange;
    sb.terrainGrid = { xs, ys, Z, nx, ny };

    const center = P((xmin + xmax) / 2, (ymin + ymax) / 2, (zmin + zmax) / 2);
    sb.controls.target.copy(center);
    sb.camera.position.copy(center).add(new THREE.Vector3(28, 36, 34));
    sb.controls.update();
    sb.homeCam = sb.camera.position.clone();
    sb.homeTarget = center.clone();

    // 自然光照（Blender 风格）：半球光提供天空/地面环境基础，太阳方向光主导明暗，
    // 弱蓝色补光模拟天空散射提亮阴影面——避免「环境光过强把阴影洗掉」导致的悬浮感
    scene.add(new THREE.HemisphereLight('#cfe6ff', '#7a6a4e', 0.5));
    const sun = new THREE.DirectionalLight('#fff4e0', 2.1);
    sun.position.set(60, 90, 40);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -90; sun.shadow.camera.right = 90;
    sun.shadow.camera.top = 90; sun.shadow.camera.bottom = -90;
    sun.shadow.camera.near = 1; sun.shadow.camera.far = 320;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.6;
    scene.add(sun);
    const fill = new THREE.DirectionalLight('#bcd7ff', 0.35);
    fill.position.set(-40, 30, -50);
    scene.add(fill);

    const pos = new Float32Array(nx * ny * 3), col = new Float32Array(nx * ny * 3);
    const uv = new Float32Array(nx * ny * 2);
    let p = 0, up = 0;
    const UV_REPEAT = 10;   // 地表纹理在整幅地图上的平铺次数
    const cell = (xs[1] - xs[0]) || 1;
    for (let i = 0; i < ny; i++) for (let j = 0; j < nx; j++) {
      pos[p] = sx(xs[j]); pos[p + 1] = sy(Z[i][j]); pos[p + 2] = sz(ys[i]);
      const c = this._sandboxColor((Z[i][j] - zmin) / zRange);
      // DEM 山体阴影（hillshade）：地形法线点乘太阳方向，阳面亮/阴面暗，
      // 即使俯视也能看出山脊走向与立体纵深（标准 DEM 渲染的核心）
      const hx = (Z[i][Math.min(j + 1, nx - 1)] - Z[i][Math.max(j - 1, 0)]) / (2 * cell);
      const hz = (Z[Math.min(i + 1, ny - 1)][j] - Z[Math.max(i - 1, 0)][j]) / (2 * cell);
      const inv = 1 / Math.sqrt(hx * hx + hz * hz + 1);
      const nX = -hx * inv, nY = inv, nZ = -hz * inv;
      const sunLen = Math.sqrt(60 * 60 + 90 * 90 + 40 * 40); // 与 DirectionalLight 同向
      const sX = 60 / sunLen, sY = 90 / sunLen, sZ = 40 / sunLen;
      let hs = nX * sX + nY * sY + nZ * sZ;
      hs = 0.60 + 0.40 * Math.max(-1, Math.min(1, hs));
      col[p] = c[0] * hs; col[p + 1] = c[1] * hs; col[p + 2] = c[2] * hs;
      uv[up++] = (j / (nx - 1)) * UV_REPEAT;
      uv[up++] = (i / (ny - 1)) * UV_REPEAT;
      p += 3;
    }
    // 索引绕向必须让三角形法线朝上（+Y）：a,c,b 与 b,c,d 均为逆时针（俯视）。
    // 之前 a,b,c / b,d,c 的绕向使法线朝下，俯视时被背面剔除，地形“透明”，只能从下方看到。
    const idx = [];
    for (let i = 0; i < ny - 1; i++) for (let j = 0; j < nx - 1; j++) {
      const a = i * nx + j, b = a + 1, c = a + nx, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    // 程序化地表细节纹理（颜色斑驳 + 微观凹凸），叠加在海拔色带上，消除纯色塑料感
    const ground = this._makeGroundTextures();
    const terrain = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
      vertexColors: true, map: ground.color, bumpMap: ground.bump, bumpScale: 0.5,
      roughness: 0.95, metalness: 0.0,
    }));
    terrain.receiveShadow = true;
    scene.add(terrain);
    sb.terrain = terrain;   // 供单击聚焦 / 滚轮缩放做地形射线拾取

    this._addSandboxBase();
    this._addSandboxTrees();
    this._addSandboxScenery();
    this._addPowerGrid();
    this._addWildScenery();
    this._addSandboxVillages();
    this._addSandboxMilitary();
    const isFlood = this._isFloodScenario(g.scenario);
    const isAdversarial = g.scenario === 'intercept' || g.scenario === 'swarm';
    if (isFlood) {
      this._addSandboxBuildings();
      this._addSandboxTracks();
      this._addSandboxUnits();
      this._addSandboxMarkers();
      this._addSandboxLinks();
    } else if (isAdversarial) {
      this._addSandboxInterceptors();
      if (g.radar_pos && g.radar_range) this._addSandboxRadar();
      this._addSandboxDrones();
      this._addSandboxInterceptMarkers();
      this._addSandboxAA();
      if (g.base_pos && g.base_radius) {
        // 军事基地（最终目标攻击点）：标志建筑 + 血条 + 受击特效
        this._addSandboxBaseMarker();
      }
      if (g.scenario === 'intercept') {
        // 空地协同巷战独有：楼房掩体 + 步兵 + 巡逻兵
        this._addSandboxCqbBuildings();
        this._addSandboxInfantry();
        this._addSandboxPatrol();
      }
      // 蓝方单位行动轨迹（无人机 + 步兵），以曲线叠加在实景地形上
      this._addSandboxTracks();
    }
    this._addCompassMarkers();
    this._addAltitudeCeiling();
  },

  // 地图东南西北方位标记：放在地图边界外（不被树木/山体遮挡），明确地图朝向。
  // 后端约定：y 大 = 北、x 大 = 东（蓝方起点左下 → 基地右上即进攻方向）。
  _addCompassMarkers() {
    const sb = this._sandbox, g = this._result.geometry;
    if (!g || !g.terrain) return;
    // 依据地形实际边界动态定位（原实现硬编码 500/1030，仅适配 1000×1000 的
    // intercept 地图，对 swarm 等长方形/大尺寸地图会错乱）。
    const cx = (sb.xmin + sb.xmax) / 2;
    const cy = (sb.ymin + sb.ymax) / 2;
    const xr = (sb.xmax - sb.xmin) || 1;
    const yr = (sb.ymax - sb.ymin) || 1;
    const mx = Math.max(xr, yr) * 0.06;   // 边界外偏移（放置方位字）
    const mi = Math.max(xr, yr) * 0.02;   // 边界内偏移（取地形高度，地图外无网格）
    const defs = [
      { t: LASE.t('北'), x: cx, y: sb.ymax + mx, hx: cx, hy: sb.ymax - mi, color: '#e74c3c' },
      { t: LASE.t('南'), x: cx, y: sb.ymin - mx, hx: cx, hy: sb.ymin + mi, color: '#f39c12' },
      { t: LASE.t('东'), x: sb.xmax + mx, y: cy, hx: sb.xmax - mi, hy: cy, color: '#2c7a4b' },
      { t: LASE.t('西'), x: sb.xmin - mx, y: cy, hx: sb.xmin + mi, hy: cy, color: '#2c5f8a' },
    ];
    defs.forEach(d => {
      const spr = this._makeTextSprite(d.t, d.color);
      // 高度取地图边缘内侧地形（地图外无网格），再加抬升避免贴地
      const hz = this._terrainH(d.hx, d.hy) + 8;
      spr.position.copy(sb.P(d.x, d.y, hz));
      spr.scale.set(7, 7, 1);
      sb.scene.add(spr);
    });
  },

  // 飞行高度上限：在地图上方 max_alt 高度画一个矩形「天花板」线框，
  // 四角用垂直立柱连接到地面，直观展示蓝方最高可飞高度（此高度以上不可飞行）。
  _addAltitudeCeiling() {
    const sb = this._sandbox, g = this._result.geometry;
    if (!g || !g.terrain) return;
    const ma = Number(g.max_alt);
    if (!(ma > 0)) return;
    const x0 = sb.sx(sb.xmin), x1 = sb.sx(sb.xmax);
    const z0 = sb.sz(sb.ymin), z1 = sb.sz(sb.ymax);
    const yTop = sb.sy(ma);             // 最高飞行高度
    const yBot = sb.sy(sb.zmin);        // 地形最低点（基座顶面）
    const corner = [
      new THREE.Vector3(x0, yBot, z0), new THREE.Vector3(x1, yBot, z0),
      new THREE.Vector3(x1, yBot, z1), new THREE.Vector3(x0, yBot, z1),
    ];
    // 四角垂直立柱 + 顶面矩形边框
    const pts = [];
    for (let i = 0; i < 4; i++) {
      const a = corner[i], b = corner[(i + 1) % 4];
      const at = new THREE.Vector3(a.x, yTop, a.z);
      const bt = new THREE.Vector3(b.x, yTop, b.z);
      pts.push(a, at, at, bt);          // 立柱 + 顶面边
    }
    const cageGeo = new THREE.BufferGeometry().setFromPoints(pts);
    const cage = new THREE.LineSegments(cageGeo, new THREE.LineBasicMaterial({
      color: 0x5fb8ff, transparent: true, opacity: 0.55,
    }));
    cage.renderOrder = 2;
    sb.scene.add(cage);

    // 顶面：极淡半透明平面，示意「此高度以上不可飞行」
    const topGeo = new THREE.PlaneGeometry(x1 - x0, z1 - z0);
    topGeo.rotateX(-Math.PI / 2);
    const top = new THREE.Mesh(topGeo, new THREE.MeshBasicMaterial({
      color: 0x5fb8ff, transparent: true, opacity: 0.05,
      side: THREE.DoubleSide, depthWrite: false,
    }));
    top.position.set((x0 + x1) / 2, yTop, (z0 + z1) / 2);
    top.renderOrder = 1;
    sb.scene.add(top);

    // 顶部标签（横向字牌，始终面向相机）
    const label = this._makeLabelSprite(LASE.t('最高飞行高度 {0} m', Math.round(ma)), '#5fb8ff');
    label.position.set((x0 + x1) / 2, yTop + 1.6, z1 - 2.5);
    sb.scene.add(label);
  },

  // 横向字牌 sprite（比 _makeTextSprite 更宽，适配较长文字标签）
  _makeLabelSprite(text, color) {
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d');
    const font = 'bold 36px "Microsoft YaHei", "PingFang SC", sans-serif';
    ctx.font = font;
    const tw = Math.ceil(ctx.measureText(text).width);
    const W = Math.max(400, tw + 64);   // 按文字实际宽度加内边距，英文长标签不再被截断
    const H = 96;
    c.width = W; c.height = H;
    ctx.clearRect(0, 0, W, H);
    const r = 18;
    ctx.beginPath();
    ctx.moveTo(r, 0);
    ctx.lineTo(W - r, 0);
    ctx.arcTo(W, 0, W, H, r);
    ctx.arcTo(W, H, W - r, H, r);
    ctx.lineTo(r, H);
    ctx.arcTo(0, H, 0, H - r, r);
    ctx.arcTo(0, 0, r, 0, r);
    ctx.closePath();
    ctx.fillStyle = 'rgba(18, 28, 38, 0.72)';
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = color;
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.font = font;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, W / 2, H / 2);
    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 4;
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
    sprite.scale.set(4 * W / H, 4, 1);   // 世界高度固定 4，宽度随 canvas 等比，保持文字不变形
    return sprite;
  },

  _makeTextSprite(text, color) {
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, 128, 128);
    ctx.beginPath();
    ctx.arc(64, 64, 56, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(18, 28, 38, 0.72)';
    ctx.fill();
    ctx.lineWidth = 5;
    ctx.strokeStyle = color;
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 54px "Microsoft YaHei", "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 64, 66);
    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 4;
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
    return spr;
  },

  // 沙盒切块基座：封闭的地层 + 底部展示台，让地形从侧面看是完整切块而非悬空薄片
  _addSandboxBase() {
    const sb = this._sandbox;
    const x0 = sb.sx(sb.xmin), x1 = sb.sx(sb.xmax);
    const z0 = sb.sz(sb.ymin), z1 = sb.sz(sb.ymax);
    const W = x1 - x0, D = z1 - z0;
    const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    const topY = sb.sy(sb.zmin);         // 地层顶面 = 地形最低点
    const depth = 7;                      // 地层厚度
    const cy = topY - depth / 2;

    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x8a6f4d, roughness: 0.95 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(W, depth, D), bodyMat);
    body.position.set(cx, cy, cz);
    body.receiveShadow = true;
    sb.scene.add(body);

    // 沉积层条纹（侧面可见的深色横带，增强切块层次感）
    const layerMat = new THREE.MeshStandardMaterial({ color: 0x6e5538, roughness: 0.95 });
    for (let i = 1; i <= 3; i++) {
      const ly = topY - (depth * i) / 4;
      const layer = new THREE.Mesh(new THREE.BoxGeometry(W + 0.25, 0.4, D + 0.25), layerMat);
      layer.position.set(cx, ly, cz);
      sb.scene.add(layer);
    }

    // 底部深色展示台（略宽于地层，形成切块底座）
    const plinth = new THREE.Mesh(
      new THREE.BoxGeometry(W + 1.6, 0.8, D + 1.6),
      new THREE.MeshStandardMaterial({ color: 0x4b3b2a, roughness: 0.85 }));
    plinth.position.set(cx, topY - depth - 0.4, cz);
    plinth.receiveShadow = true;
    sb.scene.add(plinth);

    // 地形四周边界侧壁：从起伏的地形边缘垂直向下延伸到地层顶面，
    // 把原本「悬空」的地形边缘彻底封闭，侧面看是完整的地图切块
    this._addSandboxWalls();
  },

  // 地形边缘侧壁（沿边界起伏 + 垂直下落，封闭切块四周）
  _addSandboxWalls() {
    const sb = this._sandbox, g = sb.terrainGrid;
    if (!g) return;
    const { xs, ys, Z, nx, ny } = g;
    const topY = sb.sy(sb.zmin);
    const soil = [0.54, 0.43, 0.30];

    const buildEdge = (line) => {
      const pos = [], col = [], idx = [];
      for (let k = 0; k < line.length - 1; k++) {
        const a = line[k], b = line[k + 1];
        const ap = sb.P(a.x, a.y, a.z), bp = sb.P(b.x, b.y, b.z);
        const n = pos.length / 3;
        // 上边缘两点沿地形起伏，下边缘两点落到地层顶面（垂直壁）
        pos.push(ap.x, ap.y, ap.z, bp.x, bp.y, bp.z,
                 ap.x, topY, ap.z, bp.x, topY, bp.z);
        const ca = this._sandboxColor((a.z - sb.zmin) / sb.zRange);
        const cb = this._sandboxColor((b.z - sb.zmin) / sb.zRange);
        col.push(ca[0], ca[1], ca[2], cb[0], cb[1], cb[2],
                 soil[0], soil[1], soil[2], soil[0], soil[1], soil[2]);
        idx.push(n, n + 1, n + 2, n + 1, n + 3, n + 2);
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      geo.setIndex(idx);
      geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
        vertexColors: true, roughness: 0.95, flatShading: true, side: THREE.DoubleSide }));
      mesh.receiveShadow = true;
      sb.scene.add(mesh);
    };

    const eXmin = [], eXmax = [], eYmin = [], eYmax = [];
    for (let i = 0; i < ny; i++) eXmin.push({ x: xs[0], y: ys[i], z: Z[i][0] });
    for (let i = 0; i < ny; i++) eXmax.push({ x: xs[nx - 1], y: ys[i], z: Z[i][nx - 1] });
    for (let j = 0; j < nx; j++) eYmin.push({ x: xs[j], y: ys[0], z: Z[0][j] });
    for (let j = 0; j < nx; j++) eYmax.push({ x: xs[j], y: ys[ny - 1], z: Z[ny - 1][j] });
    buildEdge(eXmin);
    buildEdge(eXmax);
    buildEdge(eYmin);
    buildEdge(eYmax);
  },

  // ---------- 微观投放视角（canvas 2D 侧视剖面）----------
  _addSandboxTrees() {
    const sb = this._sandbox, g = this._result.geometry, t = g.terrain;
    const xs = t.xs, ys = t.ys, Z = t.Z, nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    const waterZ = sb.zmin + sb.zRange * 0.16;
    const hAt = (x, y) => this._terrainH(x, y);   // 双线性插值，贴合地形三角面，避免斜坡台阶
    let seed = 987654321;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const base = g.base || null, disasters = g.disasters || [];
    // swarm 停机坪（g.helipads）：周围保持约 2 km 净空，避免散布树木遮挡直升机
    const helipads = g.helipads || [];
    const N = 900;
    const trunks = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.18, 0.3, 1.0, 8),
      new THREE.MeshStandardMaterial({ color: 0x6b4a2b, roughness: 0.9 }), N);
    // 双层树冠：底层大锥 + 顶层小锥，平滑法线 + 更多边数，圆润写实
    const canopies = new THREE.InstancedMesh(
      new THREE.ConeGeometry(1.0, 1.6, 12),
      new THREE.MeshStandardMaterial({ roughness: 0.85 }), N);
    const canopiesTop = new THREE.InstancedMesh(
      new THREE.ConeGeometry(0.62, 1.4, 12),
      new THREE.MeshStandardMaterial({ roughness: 0.85 }), N);
    // 接触阴影贴片：每棵树底部一张径向渐变暗斑，锚定「落地感」，消除悬浮
    const shadowGeo = new THREE.PlaneGeometry(2.2, 2.2);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadows = new THREE.InstancedMesh(shadowGeo, new THREE.MeshBasicMaterial({
      map: this._makeSoftShadowTexture(), transparent: true, depthWrite: false, opacity: 0.9,
    }), N);
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0);
    const qId = new THREE.Quaternion();
    let placed = 0;
    for (let k = 0; k < N; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.12 || h01 > 0.62 || z < waterZ + 0.6) continue;
      if (base) {
        const dxb = x - base[0], dyb = y - base[1];
        if (dxb * dxb + dyb * dyb < 900 * 900) continue;
      }
      let near = false;
      for (const d of disasters) { const dxd = x - d[0], dyd = y - d[1]; if (dxd * dxd + dyd * dyd < 600 * 600) { near = true; break; } }
      if (near) continue;
      for (const hp of helipads) { const dxh = x - hp[0], dyh = y - hp[1]; if (dxh * dxh + dyh * dyh < 2000 * 2000) { near = true; break; } }
      if (near) continue;
      const s = 0.6 + rnd() * 0.9, rot = rnd() * Math.PI * 2;
      const px = sb.sx(x), pz = sb.sz(y), py = sb.sy(z);
      q.setFromAxisAngle(up, rot);
      m.compose(new THREE.Vector3(px, py + 0.5 * s, pz), q, new THREE.Vector3(s, s, s));
      trunks.setMatrixAt(placed, m);
      trunks.setColorAt(placed, new THREE.Color().setHSL(0.07, 0.4, 0.22 + rnd() * 0.12));
      m.compose(new THREE.Vector3(px, py + (1.0 + 0.8) * s, pz), q, new THREE.Vector3(s, s, s));
      canopies.setMatrixAt(placed, m);
      canopies.setColorAt(placed, new THREE.Color().setHSL(0.28 + rnd() * 0.08, 0.5, 0.26 + rnd() * 0.18));
      m.compose(new THREE.Vector3(px, py + (1.0 + 1.6 + 0.7) * s, pz), q, new THREE.Vector3(s, s, s));
      canopiesTop.setMatrixAt(placed, m);
      canopiesTop.setColorAt(placed, new THREE.Color().setHSL(0.32 + rnd() * 0.08, 0.55, 0.4 + rnd() * 0.2));
      m.compose(new THREE.Vector3(px, py + 0.12, pz), qId, new THREE.Vector3(s * 1.6, s * 1.6, 1));
      shadows.setMatrixAt(placed, m);
      placed++;
    }
    trunks.count = canopies.count = canopiesTop.count = shadows.count = placed;
    trunks.castShadow = canopies.castShadow = canopiesTop.castShadow = true;
    sb.scene.add(trunks, canopies, canopiesTop, shadows);
  },

  // 场景点缀：石头、水塘、散布民居、高压电线，增强沙盒真实感（确定性 RNG，可复现）
  _addSandboxScenery() {
    const sb = this._sandbox, g = this._result.geometry, t = g.terrain;
    const xs = t.xs, ys = t.ys, Z = t.Z, nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    const waterZ = sb.zmin + sb.zRange * 0.16;
    const hAt = (x, y) => this._terrainH(x, y);   // 双线性插值，贴合地形三角面，避免斜坡台阶
    let seed = 20261008;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const base = g.base || null, disasters = g.disasters || [];
    // swarm 停机坪（g.helipads）：周围保持约 2 km 净空，散布点缀不得进入
    const helipads = g.helipads || [];
    const avoid = (x, y, r) => {
      if (base) { const dx = x - base[0], dy = y - base[1]; if (dx * dx + dy * dy < r * r) return true; }
      for (const d of disasters) { const dx = x - d[0], dy = y - d[1]; if (dx * dx + dy * dy < r * r) return true; }
      for (const hp of helipads) { const dx = x - hp[0], dy = y - hp[1]; if (dx * dx + dy * dy < 2000 * 2000) return true; }
      return false;
    };
    const up = new THREE.Vector3(0, 1, 0);
    const q = new THREE.Quaternion(), qId = new THREE.Quaternion();
    const m = new THREE.Matrix4();

    // —— 1) 石头：灰色低多边形石块，随机压扁/拉长/旋转 ——
    const NR = 260;
    const rocks = new THREE.InstancedMesh(
      new THREE.IcosahedronGeometry(1, 0),
      new THREE.MeshStandardMaterial({ roughness: 0.95 }), NR);
    let pr = 0;
    for (let k = 0; k < NR; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.14 || h01 > 0.72 || z < waterZ + 0.4) continue;
      if (avoid(x, y, 500)) continue;
      const sx = 0.6 + rnd() * 2.0, sy = 0.35 + rnd() * 1.0, sz = 0.6 + rnd() * 2.0;
      q.setFromAxisAngle(up, rnd() * Math.PI * 2);
      m.compose(new THREE.Vector3(sb.sx(x), sb.sy(z) + 0.3 * sy, sb.sz(y)),
        q, new THREE.Vector3(sx, sy, sz));
      rocks.setMatrixAt(pr, m);
      rocks.setColorAt(pr, new THREE.Color().setHSL(0.06, 0.05, 0.34 + rnd() * 0.28));
      pr++;
    }
    rocks.count = pr;
    rocks.castShadow = true; rocks.receiveShadow = true;
    sb.scene.add(rocks);

    // —— 2) 水塘：低洼处半透明蓝色椭圆水面 ——
    const pondMat = new THREE.MeshStandardMaterial({
      color: 0x2f7fa8, transparent: true, opacity: 0.72, roughness: 0.15, metalness: 0.1 });
    const NP = 14;
    for (let k = 0; k < NP; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.16 || h01 > 0.34) continue;
      if (avoid(x, y, 400)) continue;
      const pond = new THREE.Mesh(new THREE.CircleGeometry(1, 24), pondMat);
      pond.scale.set(1.6 + rnd() * 3.0, 1.2 + rnd() * 2.4, 1);
      pond.rotation.x = -Math.PI / 2;
      pond.rotation.z = rnd() * Math.PI;
      pond.position.set(sb.sx(x), sb.sy(z) + 0.22, sb.sz(y));
      pond.receiveShadow = true;
      sb.scene.add(pond);
    }

    // —— 3) 房屋：散布民居（白墙 + 红瓦尖顶 + 接触阴影）——
    const NH = 24;
    const houseWall = new THREE.InstancedMesh(
      new THREE.BoxGeometry(2.2, 1.6, 2.2),
      new THREE.MeshStandardMaterial({ roughness: 0.8 }), NH);
    const houseRoof = new THREE.InstancedMesh(
      new THREE.ConeGeometry(1.6, 1.3, 4),
      new THREE.MeshStandardMaterial({ roughness: 0.7 }), NH);
    const hsGeo = new THREE.PlaneGeometry(3.8, 3.8); hsGeo.rotateX(-Math.PI / 2);
    const houseShadow = new THREE.InstancedMesh(hsGeo, new THREE.MeshBasicMaterial({
      map: this._makeSoftShadowTexture(), transparent: true, depthWrite: false, opacity: 0.85 }), NH);
    let ph = 0;
    for (let k = 0; k < NH; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.22 || h01 > 0.62 || z < waterZ + 1.0) continue;
      if (avoid(x, y, 700)) continue;
      const sc = 0.8 + rnd() * 0.7, rot = rnd() * Math.PI * 2;
      const px = sb.sx(x), py = sb.sy(z), pz = sb.sz(y);
      q.setFromAxisAngle(up, rot);
      m.compose(new THREE.Vector3(px, py + 0.8 * sc, pz), q, new THREE.Vector3(sc, sc, sc));
      houseWall.setMatrixAt(ph, m);
      houseWall.setColorAt(ph, new THREE.Color().setHSL(0.08, 0.12, 0.70 + rnd() * 0.18));
      const qr = new THREE.Quaternion().setFromAxisAngle(up, rot + Math.PI / 4);
      m.compose(new THREE.Vector3(px, py + (1.6 + 0.65) * sc, pz), qr, new THREE.Vector3(sc, sc, sc));
      houseRoof.setMatrixAt(ph, m);
      houseRoof.setColorAt(ph, new THREE.Color().setHSL(0.02 + rnd() * 0.05, 0.45, 0.32 + rnd() * 0.18));
      m.compose(new THREE.Vector3(px, py + 0.1, pz), qId, new THREE.Vector3(sc, sc, 1));
      houseShadow.setMatrixAt(ph, m);
      ph++;
    }
    houseWall.count = houseRoof.count = houseShadow.count = ph;
    houseWall.castShadow = houseRoof.castShadow = true;
    sb.scene.add(houseWall, houseRoof, houseShadow);
  },

  // 连通电网：散乱分布电线杆，再用最小生成树把全部杆连成一张连通网
  _addPowerGrid() {
    const sb = this._sandbox, g = this._result.geometry, t = g.terrain;
    const xs = t.xs, ys = t.ys, nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    const hAt = (x, y) => this._terrainH(x, y);
    let seed = 55667788;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const base = g.base || null, disasters = g.disasters || [], helipads = g.helipads || [];
    const waterZ = sb.zmin + sb.zRange * 0.16;
    const avoid = (x, y, r) => {
      if (base) { const dx = x - base[0], dy = y - base[1]; if (dx * dx + dy * dy < r * r) return true; }
      for (const d of disasters) { const dx = x - d[0], dy = y - d[1]; if (dx * dx + dy * dy < r * r) return true; }
      for (const hp of helipads) { const dx = x - hp[0], dy = y - hp[1]; if (dx * dx + dy * dy < 2000 * 2000) return true; }
      return false;
    };
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x4a4a4a, roughness: 0.6 });
    const wireMat = new THREE.MeshStandardMaterial({ color: 0x6a6f76, roughness: 0.35, metalness: 0.45 });

    // 节点集合：每个节点 { px, py, pz }（py 为挂点高度）
    const nodes = [];

    // 散乱生成电线杆：位置随机散乱，但最终都会被导线连成一张网
    const NP = 16;
    for (let k = 0; k < NP * 6 && nodes.length < NP + 1; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.18 || h01 > 0.64 || z < waterZ + 0.8) continue;
      if (avoid(x, y, 600)) continue;
      const px = sb.sx(x), py = sb.sy(z) + 7.0, pz = sb.sz(y);
      let tooClose = false;
      for (const nd of nodes) {
        const d = (nd.px - px) * (nd.px - px) + (nd.pz - pz) * (nd.pz - pz);
        if (d < 12 * 12) { tooClose = true; break; }
      }
      if (tooClose) continue;
      nodes.push({ px, py, pz });
    }

    // 画电线杆
    for (let i = 0; i < nodes.length; i++) {
      const nd = nodes[i];
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.28, 7.0, 8), poleMat);
      pole.position.set(nd.px, nd.py - 3.5, nd.pz);
      pole.castShadow = true; sb.scene.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 2.6), poleMat);
      arm.position.set(nd.px, nd.py, nd.pz); sb.scene.add(arm);
    }

    if (nodes.length < 2) return;

    // Prim 最小生成树：保证所有杆连成一张连通图
    const n = nodes.length;
    const dist2 = (a, b) => (a.px - b.px) * (a.px - b.px) + (a.py - b.py) * (a.py - b.py)
      + (a.pz - b.pz) * (a.pz - b.pz);
    const inTree = new Array(n).fill(false);
    inTree[0] = true;
    const edges = [];
    for (let it = 1; it < n; it++) {
      let bu = -1, bv = -1, bd = Infinity;
      for (let u = 0; u < n; u++) if (inTree[u]) {
        for (let v = 0; v < n; v++) if (!inTree[v]) {
          const d = dist2(nodes[u], nodes[v]);
          if (d < bd) { bd = d; bu = u; bv = v; }
        }
      }
      if (bv < 0) break;
      inTree[bv] = true;
      edges.push([bu, bv]);
    }

    // 每条边画三根悬链导线（沿横担分布）
    for (const [iu, iv] of edges) {
      const a = nodes[iu], b = nodes[iv];
      for (const dz of [-1.0, 0, 1.0]) {
        const pts = [];
        for (let i = 0; i <= 16; i++) {
          const tt = i / 16;
          const sag = Math.sin(Math.PI * tt) * 1.6;
          pts.push(new THREE.Vector3(
            a.px + (b.px - a.px) * tt,
            a.py + (b.py - a.py) * tt - sag,
            a.pz + (b.pz - a.pz) * tt + dz));
        }
        sb.scene.add(new THREE.Mesh(
          new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 20, 0.06, 5, false), wireMat));
      }
    }
  },

  // 野外点缀：灌木丛 + 草丛 + 风力发电机，丰富植被层次（确定性 RNG）
  _addWildScenery() {
    const sb = this._sandbox, g = this._result.geometry, t = g.terrain;
    const xs = t.xs, ys = t.ys, nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    const hAt = (x, y) => this._terrainH(x, y);
    let seed = 88442211;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const base = g.base || null, disasters = g.disasters || [], helipads = g.helipads || [];
    const waterZ = sb.zmin + sb.zRange * 0.16;
    const avoid = (x, y, r) => {
      if (base) { const dx = x - base[0], dy = y - base[1]; if (dx * dx + dy * dy < r * r) return true; }
      for (const d of disasters) { const dx = x - d[0], dy = y - d[1]; if (dx * dx + dy * dy < r * r) return true; }
      for (const hp of helipads) { const dx = x - hp[0], dy = y - hp[1]; if (dx * dx + dy * dy < 2000 * 2000) return true; }
      return false;
    };
    const up = new THREE.Vector3(0, 1, 0);
    const q = new THREE.Quaternion();
    const m = new THREE.Matrix4();

    const NB = 240;
    const bushes = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 0),
      new THREE.MeshStandardMaterial({ roughness: 0.95 }), NB);
    let pb = 0;
    for (let k = 0; k < NB; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.14 || h01 > 0.68 || z < waterZ + 0.5) continue;
      if (avoid(x, y, 350)) continue;
      const sc = 0.5 + rnd() * 1.1;
      q.setFromAxisAngle(up, rnd() * Math.PI * 2);
      m.compose(new THREE.Vector3(sb.sx(x), sb.sy(z) + 0.35 * sc, sb.sz(y)), q,
        new THREE.Vector3(sc, sc * (0.6 + rnd() * 0.3), sc));
      bushes.setMatrixAt(pb, m);
      bushes.setColorAt(pb, new THREE.Color().setHSL(0.26 + rnd() * 0.1, 0.42, 0.24 + rnd() * 0.16));
      pb++;
    }
    bushes.count = pb; bushes.castShadow = true; sb.scene.add(bushes);

    const NG = 520;
    const grass = new THREE.InstancedMesh(new THREE.ConeGeometry(0.16, 0.9, 5),
      new THREE.MeshStandardMaterial({ roughness: 0.95 }), NG);
    let pg = 0;
    for (let k = 0; k < NG; k++) {
      const x = xmin + rnd() * (xmax - xmin), y = ymin + rnd() * (ymax - ymin);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.14 || h01 > 0.62 || z < waterZ + 0.35) continue;
      if (avoid(x, y, 250)) continue;
      const sc = 0.6 + rnd() * 1.2;
      q.setFromAxisAngle(up, rnd() * Math.PI * 2);
      m.compose(new THREE.Vector3(sb.sx(x), sb.sy(z) + 0.45 * sc, sb.sz(y)), q,
        new THREE.Vector3(sc, sc, sc));
      grass.setMatrixAt(pg, m);
      grass.setColorAt(pg, new THREE.Color().setHSL(0.24 + rnd() * 0.1, 0.45, 0.32 + rnd() * 0.22));
      pg++;
    }
    grass.count = pg; grass.castShadow = true; sb.scene.add(grass);

    const NW = 10;
    const towerGeo = new THREE.CylinderGeometry(0.14, 0.42, 9.0, 10);
    const nacelleGeo = new THREE.BoxGeometry(1.2, 0.7, 0.7);
    const bladeGeo = new THREE.BoxGeometry(0.22, 0.06, 3.4);
    const towerMat = new THREE.MeshStandardMaterial({ color: 0xe8ecef, roughness: 0.6 });
    const bladeMat = new THREE.MeshStandardMaterial({ color: 0xdfe4e8, roughness: 0.5 });
    // 叶片半径约 3.4、机舱偏移 0.6：在地面内留约 6 个场景单位边距，防止发电机/叶片伸出沙盘
    const mx = (xmax - xmin) * 0.06, my = (ymax - ymin) * 0.06;
    for (let k = 0; k < NW; k++) {
      const x = xmin + mx + rnd() * (xmax - xmin - 2 * mx);
      const y = ymin + my + rnd() * (ymax - ymin - 2 * my);
      const z = hAt(x, y), h01 = (z - sb.zmin) / sb.zRange;
      if (h01 < 0.5 || h01 > 0.86) continue;
      if (avoid(x, y, 400)) continue;
      const px = sb.sx(x), py = sb.sy(z), pz = sb.sz(y);
      const tower = new THREE.Mesh(towerGeo, towerMat);
      tower.position.set(px, py + 4.5, pz); tower.castShadow = true; sb.scene.add(tower);
      const nacelle = new THREE.Mesh(nacelleGeo, towerMat);
      nacelle.position.set(px + 0.6, py + 9.0, pz); sb.scene.add(nacelle);
      const rotor = new THREE.Group();
      rotor.position.set(px + 0.6, py + 9.0, pz);
      for (let b = 0; b < 3; b++) {
        const blade = new THREE.Mesh(bladeGeo, bladeMat);
        blade.position.z = 1.7;
        blade.rotation.x = (b / 3) * Math.PI * 2;
        rotor.add(blade);
      }
      rotor.rotation.z = rnd() * Math.PI * 2;
      sb.scene.add(rotor);
    }
  },

  // 村庄聚落：按后端给出的村庄中心聚集成片民居（规模比散布民居更大更密，形成明显聚落）
  _addSandboxVillages() {
    const sb = this._sandbox, g = this._result.geometry;
    const villages = g.villages || [];
    if (!villages.length) return;
    const t = g.terrain;
    const xs = t.xs, ys = t.ys, Z = t.Z, nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    const hAt = (x, y) => this._terrainH(x, y);   // 双线性插值，贴合地形三角面，避免斜坡台阶
    let seed = 77889911;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const up = new THREE.Vector3(0, 1, 0);
    const q = new THREE.Quaternion(), qId = new THREE.Quaternion();
    const m = new THREE.Matrix4();

    // 先统计每村房屋数，得到总实例数
    let total = 0;
    const layout = villages.map(v => {
      const n = 9 + Math.floor(rnd() * 8);   // 每村 9~16 栋
      total += n;
      return { vx: v[0], vy: v[1], vr: v[2], n };
    });

    const wall = new THREE.InstancedMesh(
      new THREE.BoxGeometry(2.6, 2.0, 2.6),
      new THREE.MeshStandardMaterial({ roughness: 0.8 }), total);
    const roof = new THREE.InstancedMesh(
      new THREE.ConeGeometry(1.9, 1.6, 4),
      new THREE.MeshStandardMaterial({ roughness: 0.7 }), total);
    const shGeo = new THREE.PlaneGeometry(4.6, 4.6); shGeo.rotateX(-Math.PI / 2);
    const shadow = new THREE.InstancedMesh(shGeo, new THREE.MeshBasicMaterial({
      map: this._makeSoftShadowTexture(), transparent: true, depthWrite: false, opacity: 0.85 }), total);

    let idx = 0;
    layout.forEach(({ vx, vy, vr, n }) => {
      for (let k = 0; k < n; k++) {
        const ang = rnd() * Math.PI * 2;
        const rr = Math.sqrt(rnd()) * vr;
        const x = vx + Math.cos(ang) * rr, y = vy + Math.sin(ang) * rr;
        const z = hAt(x, y);
        const sc = 0.85 + rnd() * 0.7, rot = rnd() * Math.PI * 2;
        const px = sb.sx(x), py = sb.sy(z), pz = sb.sz(y);
        q.setFromAxisAngle(up, rot);
        m.compose(new THREE.Vector3(px, py + 1.0 * sc, pz), q, new THREE.Vector3(sc, sc, sc));
        wall.setMatrixAt(idx, m);
        wall.setColorAt(idx, new THREE.Color().setHSL(0.08, 0.12, 0.68 + rnd() * 0.2));
        const qr = new THREE.Quaternion().setFromAxisAngle(up, rot + Math.PI / 4);
        m.compose(new THREE.Vector3(px, py + (2.0 + 0.8) * sc, pz), qr, new THREE.Vector3(sc, sc, sc));
        roof.setMatrixAt(idx, m);
        roof.setColorAt(idx, new THREE.Color().setHSL(0.02 + rnd() * 0.05, 0.45, 0.30 + rnd() * 0.18));
        m.compose(new THREE.Vector3(px, py + 0.12, pz), qId, new THREE.Vector3(sc, sc, 1));
        shadow.setMatrixAt(idx, m);
        idx++;
      }
    });
    wall.count = roof.count = shadow.count = total;
    wall.castShadow = roof.castShadow = true;
    sb.scene.add(wall, roof, shadow);
  },

  // 悬崖上层军事管理区：指挥部 + 军营（成排营房）+ 防空导弹阵地 + 雷达 + 哨塔 + 碉堡 + 围墙 + 军用道路
  _addSandboxMilitary() {
    const sb = this._sandbox, g = this._result.geometry;
    const mil = g.military;
    if (!mil) return;
    const t = g.terrain;
    const xs = t.xs, ys = t.ys, Z = t.Z, nx = xs.length, ny = ys.length;
    const xmin = xs[0], xmax = xs[nx - 1], ymin = ys[0], ymax = ys[ny - 1];
    const S = sb.sx(1) - sb.sx(0);
    const hAt = (x, y) => this._terrainH(x, y);   // 双线性插值，贴合地形三角面，避免斜坡台阶
    const put = (obj, x, y, lift = 0) => {
      obj.position.set(sb.sx(x), sb.sy(hAt(x, y)) + lift, sb.sz(y));
      obj.traverse(o => { o.castShadow = true; o.receiveShadow = true; });
      sb.scene.add(obj);
      return obj;
    };
    const mat = (c, r = 0.65, m = 0.1) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
    const box = (w, h, d, c, r, m) => new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c, r, m));

    // —— 军用道路（泥地，贴地形铺石板）——
    const roadMat = mat(0x6f5c41, 1.0, 0);
    (mil.roads || []).forEach(([x0, y0, x1, y1]) => {
      const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy) || 1;
      const n = Math.max(2, Math.round(len / 250));
      for (let k = 0; k <= n; k++) {
        const a = k / n, x = x0 + dx * a, y = y0 + dy * a;
        const slab = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.08, 2.0), roadMat);
        slab.position.set(sb.sx(x), sb.sy(hAt(x, y)) + 0.04, sb.sz(y));
        slab.receiveShadow = true;
        sb.scene.add(slab);
      }
    });

    // —— 围墙（立柱 + 顶部横杆）——
    const postGeo = new THREE.CylinderGeometry(0.08, 0.1, 1.6, 6);
    const postMat = mat(0x55554e, 0.7, 0.4);
    const railMat = mat(0x6a6a60, 0.6, 0.4);
    (mil.fences || []).forEach(([x0, y0, x1, y1]) => {
      const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy) || 1;
      const n = Math.max(2, Math.round(len / 180));
      for (let k = 0; k <= n; k++) {
        const a = k / n, x = x0 + dx * a, y = y0 + dy * a;
        const post = new THREE.Mesh(postGeo, postMat);
        post.position.set(sb.sx(x), sb.sy(hAt(x, y)) + 0.8, sb.sz(y));
        post.castShadow = true;
        sb.scene.add(post);
      }
      const mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
      const rail = new THREE.Mesh(new THREE.BoxGeometry(len * S, 0.12, 0.12), railMat);
      rail.position.set(sb.sx(mx), sb.sy(hAt(mx, my)) + 1.5, sb.sz(my));
      rail.rotation.y = Math.atan2(dy, dx);
      rail.castShadow = true;
      sb.scene.add(rail);
    });

    // —— 指挥部 ——
    if (mil.command) {
      const [cx, cy] = mil.command;
      const grp = new THREE.Group();
      const main = box(7.0, 3.2, 4.5, 0x8a8f86, 0.55, 0.3); main.position.y = 1.6; grp.add(main);
      const cap = box(7.2, 0.4, 4.7, 0x6a6f68, 0.6, 0.3); cap.position.y = 3.4; grp.add(cap);
      const wing = box(4.0, 2.2, 3.0, 0x7a7f76, 0.6, 0.25); wing.position.set(4.5, 1.1, 0); grp.add(wing);
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.14, 5.0, 6), mat(0x55554e, 0.5, 0.6));
      mast.position.set(0, 5.0, 2.0); grp.add(mast);
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.3, 10, 10),
        new THREE.MeshStandardMaterial({ color: 0xb03030, emissive: 0x661111, emissiveIntensity: 0.5 }));
      ball.position.set(0, 7.6, 2.0); grp.add(ball);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 4.0, 6), mat(0xcccccc, 0.4, 0.6));
      pole.position.set(-3.8, 2.0, 0); grp.add(pole);
      const flag = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.9, 0.06),
        new THREE.MeshStandardMaterial({ color: 0xc83030, roughness: 0.6, side: THREE.DoubleSide }));
      flag.position.set(-2.9, 3.5, 0); grp.add(flag);
      put(grp, cx, cy);
    }

    // —— 军营（每处一排营房）——
    const barrackMat = mat(0x5d6b4a, 0.7, 0);
    const barrackRoof = mat(0x3a4630, 0.65, 0);
    (mil.barracks || []).forEach(([bx, by]) => {
      const grp = new THREE.Group();
      for (let c = 0; c < 4; c++) {
        const b = new THREE.Mesh(new THREE.BoxGeometry(3.6, 1.7, 2.2), barrackMat);
        b.position.set(c * 4.6, 0.85, 0); grp.add(b);
        const roof = new THREE.Mesh(new THREE.BoxGeometry(3.9, 0.18, 2.4), barrackRoof);
        roof.position.set(c * 4.6, 1.78, 0); grp.add(roof);
      }
      put(grp, bx, by);
    });

    // —— 防空导弹阵地（发射车 + 4 联装斜发射管）——
    const tubeGeo = new THREE.CylinderGeometry(0.18, 0.18, 2.8, 8);
    const tubeMat = mat(0x3a4034, 0.5, 0.3);
    (mil.sam_sites || []).forEach(([sx_, sy_]) => {
      const grp = new THREE.Group();
      const body = box(2.2, 1.0, 3.6, 0x4a5240, 0.5, 0.3); body.position.y = 0.5; grp.add(body);
      for (let k = 0; k < 4; k++) {
        const tube = new THREE.Mesh(tubeGeo, tubeMat);
        tube.position.set(-0.9 + k * 0.6, 1.2, 0.8);
        tube.rotation.x = -Math.PI / 2 + 0.55;
        grp.add(tube);
      }
      put(grp, sx_, sy_);
    });

    // —— 雷达站（机房 + 天线杆 + 倾斜抛物面）——
    (mil.radars || []).forEach(([rx_, ry_]) => {
      const grp = new THREE.Group();
      const room = box(2.5, 1.8, 2.5, 0x7a8078, 0.6, 0.2); room.position.y = 0.9; grp.add(room);
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.16, 2.6, 6), mat(0x55554e, 0.5, 0.5));
      mast.position.y = 2.4; grp.add(mast);
      const dish = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 1.3, 0.12, 20), mat(0x9aa0a0, 0.3, 0.7));
      dish.position.y = 3.8; dish.rotation.x = 0.5; grp.add(dish);
      put(grp, rx_, ry_);
    });

    // —— 哨塔（四条斜腿 + 平台 + 顶棚）——
    const legMat = mat(0x4a4a44, 0.6, 0.4);
    (mil.watchtowers || []).forEach(([wx, wy]) => {
      const grp = new THREE.Group();
      for (let k = 0; k < 4; k++) {
        const a = k * Math.PI / 2 + Math.PI / 4;
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 4.0, 6), legMat);
        leg.position.set(Math.cos(a) * 0.7, 2.0, Math.sin(a) * 0.7);
        leg.rotation.z = Math.cos(a) * 0.2;
        leg.rotation.x = -Math.sin(a) * 0.2;
        grp.add(leg);
      }
      const plat = box(2.2, 0.25, 2.2, 0x5a5a52, 0.6, 0.2); plat.position.y = 4.0; grp.add(plat);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(1.6, 1.0, 4), mat(0x3a4630, 0.7, 0));
      roof.position.y = 4.8; roof.rotation.y = Math.PI / 4; grp.add(roof);
      put(grp, wx, wy);
    });

    // —— 碉堡（底座 + 半球穹顶 + 射击孔）——
    (mil.bunkers || []).forEach(([bx2, by2]) => {
      const grp = new THREE.Group();
      const base = box(2.6, 1.0, 2.6, 0x6a6a62, 0.75, 0.1); base.position.y = 0.5; grp.add(base);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(1.3, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2),
        mat(0x6a6a62, 0.75, 0.1));
      dome.position.y = 1.0; grp.add(dome);
      const slit = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.2, 0.2), mat(0x222222, 1.0, 0));
      slit.position.set(0, 1.5, 1.32); grp.add(slit);
      put(grp, bx2, by2);
    });

    // —— 帐篷群（军绿色尖顶帐篷，生活区）——
    const tentBody = mat(0x5d6b4a, 0.8, 0);
    const tentDark = mat(0x3a4630, 0.8, 0);
    (mil.tents || []).forEach(([tx, ty]) => {
      const grp = new THREE.Group();
      const tent = new THREE.Mesh(new THREE.ConeGeometry(1.5, 1.7, 4), tentBody);
      tent.position.y = 0.85; tent.rotation.y = Math.PI / 4; grp.add(tent);
      const rim = new THREE.Mesh(new THREE.BoxGeometry(2.9, 0.12, 2.9), tentDark);
      rim.position.y = 0.06; grp.add(rim);
      const door = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.0, 0.1), tentDark);
      door.position.set(0, 0.5, 1.35); grp.add(door);
      put(grp, tx, ty);
    });

    // —— 岗亭（红白条纹哨位，南门两侧）——
    (mil.guard_posts || []).forEach(([gx, gy]) => {
      const grp = new THREE.Group();
      const booth = box(1.6, 1.8, 1.6, 0x8a8a82, 0.6, 0.2); booth.position.y = 0.9; grp.add(booth);
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.35, 1.62), mat(0xc83030, 0.5, 0));
      stripe.position.y = 1.0; grp.add(stripe);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(1.5, 0.7, 4), mat(0x5a5a52, 0.6, 0.2));
      roof.position.y = 2.15; roof.rotation.y = Math.PI / 4; grp.add(roof);
      put(grp, gx, gy);
    });

    // —— 军车（吉普/卡车：车头 + 货厢 + 篷布 + 四轮）——
    const tireGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 10);
    const tireMat = mat(0x1a1a1a, 0.9, 0);
    (mil.vehicles || []).forEach(([vx, vy], k) => {
      const grp = new THREE.Group();
      const cab = box(1.6, 1.2, 1.8, 0x5d6b4a, 0.5, 0.2); cab.position.set(0.9, 1.0, 0); grp.add(cab);
      const bed = box(2.2, 0.8, 2.0, 0x4a5240, 0.6, 0.1); bed.position.set(-0.7, 1.0, 0); grp.add(bed);
      const cover = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 2.0, 10, 1, false, 0, Math.PI),
        mat(0x5d6b4a, 0.7, 0));
      cover.rotation.z = Math.PI / 2; cover.position.set(-0.7, 1.5, 0); grp.add(cover);
      for (const [wx, wz] of [[0.9, -0.9], [0.9, 0.9], [-0.7, -0.9], [-0.7, 0.9]]) {
        const tire = new THREE.Mesh(tireGeo, tireMat);
        tire.rotation.x = Math.PI / 2; tire.position.set(wx, 0.4, wz); grp.add(tire);
      }
      grp.rotation.y = (k % 2 ? -1 : 1) * 0.5;
      put(grp, vx, vy);
    });

    // —— 沙袋工事（土黄色沙袋堆，掩体）——
    const sandGeo = new THREE.CylinderGeometry(0.45, 0.45, 1.1, 8);
    const sandMat = mat(0x9c8b5e, 0.95, 0);
    (mil.sandbags || []).forEach(([bx3, by3]) => {
      const grp = new THREE.Group();
      for (const [off, h] of [[0, 0.35], [0.4, 0.75], [-0.4, 0.75], [0, 1.15]]) {
        const s = new THREE.Mesh(sandGeo, sandMat);
        s.rotation.z = Math.PI / 2; s.position.set(off, h, 0); grp.add(s);
      }
      put(grp, bx3, by3);
    });

    // —— 燃料罐（卧式圆柱罐 + 两端封头 + 支座）——
    (mil.fuel_tanks || []).forEach(([fx2, fy2]) => {
      const grp = new THREE.Group();
      const tank = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 3.0, 14), mat(0x9aa0a0, 0.3, 0.6));
      tank.rotation.z = Math.PI / 2; tank.position.y = 1.2; grp.add(tank);
      for (const sgn of [-1, 1]) {
        const cap = new THREE.Mesh(new THREE.SphereGeometry(1.0, 14, 10), mat(0x8a9090, 0.3, 0.6));
        cap.position.set(sgn * 1.5, 1.2, 0); grp.add(cap);
        const leg = box(0.4, 0.5, 1.2, 0x55554e, 0.6, 0.3);
        leg.position.set(sgn * 0.8, 0.25, 0); grp.add(leg);
      }
      put(grp, fx2, fy2);
    });

    // —— 外围油桶组（红漆卧式油桶，停机坪加油点）——
    (mil.fuel_drums || []).forEach(([dx, dy], k) => {
      const grp = new THREE.Group();
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 1.1, 12), mat(0x9c2f2f, 0.4, 0.3));
      drum.rotation.z = Math.PI / 2; drum.position.y = 0.55; grp.add(drum);
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.57, 0.57, 0.16, 12), mat(0x3a3a3a, 0.5, 0.4));
      band.rotation.z = Math.PI / 2; band.position.y = 0.55; grp.add(band);
      grp.rotation.y = (k * 0.9);
      put(grp, dx, dy);
    });

    // —— 外围哨塔（四条腿钢架 + 木平台 + 斜顶，停机坪警戒）——
    (mil.outposts || []).forEach(([ox, oy]) => {
      const grp = new THREE.Group();
      const legMat = mat(0x5a5a52, 0.6, 0.3);
      for (const [lx, lz] of [[-1.1, -1.1], [1.1, -1.1], [-1.1, 1.1], [1.1, 1.1]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 4.2, 8), legMat);
        leg.position.set(lx, 2.1, lz); grp.add(leg);
      }
      const plat = box(3.0, 0.3, 3.0, 0x6b5b3e, 0.6, 0.2);
      plat.position.y = 4.35; grp.add(plat);
      const rail = box(3.2, 0.12, 3.2, 0x4a4434, 0.6, 0.2);
      rail.position.y = 4.55; grp.add(rail);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(2.6, 1.1, 4), mat(0x4a5240, 0.6, 0.1));
      roof.position.y = 5.3; roof.rotation.y = Math.PI / 4; grp.add(roof);
      put(grp, ox, oy);
    });

    // —— 外围树木（松树：双层树冠 + 树干，空地绿化）——
    const trunkMat = mat(0x6b4a2a, 0.85, 0);
    const leafMat = mat(0x3a6b34, 0.85, 0);
    (mil.trees || []).forEach(([tx3, ty3], k) => {
      const grp = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.5, 1.4, 8), trunkMat);
      trunk.position.y = 0.7; grp.add(trunk);
      const c1 = new THREE.Mesh(new THREE.ConeGeometry(2.0, 3.0, 8), leafMat);
      c1.position.y = 2.6; grp.add(c1);
      const c2 = new THREE.Mesh(new THREE.ConeGeometry(1.5, 2.2, 8), leafMat);
      c2.position.y = 4.0; grp.add(c2);
      grp.scale.setScalar(0.8 + (k % 3) * 0.15);
      put(grp, tx3, ty3);
    });
  },

  _addSandboxBuildings() {
    const sb = this._sandbox, g = this._result.geometry, P = sb.P;
    const base = g.base || [0, 0, 0], disasters = g.disasters || [];
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xece6d8, roughness: 0.7 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x4a6fa5, roughness: 0.6 });
    const winMat = new THREE.MeshStandardMaterial({ color: 0x2c4a6e, roughness: 0.25, metalness: 0.4 });
    const doorMat = new THREE.MeshStandardMaterial({ color: 0x7a5230, roughness: 0.7 });
    const bp = P(base[0], base[1], base[2]);
    const bShadowGeo = new THREE.PlaneGeometry(3.2, 3.2);
    bShadowGeo.rotateX(-Math.PI / 2);
    const bShadowMat = new THREE.MeshBasicMaterial({
      map: this._makeSoftShadowTexture(), transparent: true, depthWrite: false, opacity: 0.9 });
    [3, 4, 2, 3, 2, 4].forEach((h, i) => {
      const b = new THREE.Mesh(new THREE.BoxGeometry(1.6, h, 1.6), wallMat);
      const r = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.28, 1.75), roofMat);
      const ox = (i % 3 - 1) * 2.7, oz = Math.floor(i / 3) * 2.7 - 1.4;
      b.position.set(bp.x + ox, bp.y + h / 2, bp.z + oz);
      r.position.set(bp.x + ox, bp.y + h + 0.14, bp.z + oz);
      b.castShadow = r.castShadow = true;
      sb.scene.add(b, r);
      const bsd = new THREE.Mesh(bShadowGeo, bShadowMat);
      bsd.position.set(bp.x + ox, bp.y + 0.1, bp.z + oz);
      bsd.renderOrder = 1;
      sb.scene.add(bsd);
      // 四面窗户 + 正面门，丰富立面细节
      const wy = bp.y + h * 0.6, wy2 = bp.y + h * 0.32;
      for (let f = 0; f < 4; f++) {
        const a = f * Math.PI / 2;
        const dx = Math.cos(a) * 0.82, dz = Math.sin(a) * 0.82;
        const win = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.3, 0.04), winMat);
        win.position.set(bp.x + ox + dx, wy, bp.z + oz + dz);
        win.rotation.y = -a;
        sb.scene.add(win);
        const win2 = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.3, 0.04), winMat);
        win2.position.set(bp.x + ox + dx, wy2, bp.z + oz + dz);
        win2.rotation.y = -a;
        sb.scene.add(win2);
      }
      const door = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.55, 0.04), doorMat);
      door.position.set(bp.x + ox, bp.y + 0.28, bp.z + oz + 0.82);
      sb.scene.add(door);
    });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 4, 6),
      new THREE.MeshStandardMaterial({ color: 0x555555 }));
    pole.position.set(bp.x, bp.y + 2, bp.z - 3);
    sb.scene.add(pole);
    const poleTop = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0x333333 }));
    poleTop.position.set(bp.x, bp.y + 4.05, bp.z - 3);
    sb.scene.add(poleTop);
    // 旗帜用 pivot 挂在旗杆顶端，渲染循环里做风吹摆动
    const flagPivot = new THREE.Group();
    flagPivot.position.set(bp.x, bp.y + 3.9, bp.z - 3);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7, 6, 3),
      new THREE.MeshStandardMaterial({ color: 0xe63946, side: THREE.DoubleSide }));
    flag.position.x = 0.75;
    flagPivot.add(flag);
    sb.scene.add(flagPivot);
    sb.frame.flag = flagPivot;
    disasters.forEach(d => {
      const dp = P(d[0], d[1], d[2]);
      const tent = new THREE.Mesh(new THREE.ConeGeometry(1.0, 1.6, 4),
        new THREE.MeshStandardMaterial({ color: 0xe07b39, roughness: 0.8 }));
      tent.position.set(dp.x, dp.y + 0.8, dp.z);
      tent.rotation.y = Math.PI / 4;
      tent.castShadow = true;
      sb.scene.add(tent);
      const tsd = new THREE.Mesh(bShadowGeo, bShadowMat);
      tsd.position.set(dp.x, dp.y + 0.1, dp.z);
      tsd.scale.set(0.72, 0.72, 0.72);
      tsd.renderOrder = 1;
      sb.scene.add(tsd);
      // 顶杆 + 门帘，弱化纯锥体的简陋感
      const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.9, 6),
        new THREE.MeshStandardMaterial({ color: 0x555555 }));
      stick.position.set(dp.x, dp.y + 1.7, dp.z);
      sb.scene.add(stick);
      const flag2 = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.3),
        new THREE.MeshStandardMaterial({ color: 0xe63946, side: THREE.DoubleSide }));
      flag2.position.set(dp.x + 0.28, dp.y + 2.45, dp.z);
      sb.scene.add(flag2);
    });
  },

  _addSandboxTracks() {
    const sb = this._sandbox, frs = this._result.frames || [];
    if (!frs.length) return;
    const g = this._result.geometry || {};
    const isFlood = this._isFloodScenario(g.scenario);

    // 蓝方无人机轨迹（蓝）：flood 用 cargo，intercept/swarm 用 drone，抬升悬于地形之上
    const dKey = isFlood ? 'cargos' : 'drones';
    const nDrone = frs[0][dKey] ? frs[0][dKey].length : 0;
    const droneMat = new THREE.MeshStandardMaterial({
      color: 0x2b6cb0, emissive: 0x0a2a4a, emissiveIntensity: 0.35, roughness: 0.5 });
    for (let i = 0; i < nDrone; i++) {
      const pts = [];
      for (let k = 0; k < frs.length; k++) {
        const c = frs[k][dKey] && frs[k][dKey][i];
        if (c) pts.push(sb.P(c[0], c[1], c[2] + 15));
      }
      if (pts.length < 2) continue;
      const curve = new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.4);
      const tube = new THREE.Mesh(
        new THREE.TubeGeometry(curve, Math.min(160, pts.length * 3), 0.12, 8, false), droneMat);
      sb.scene.add(tube);
    }

    // 蓝方步兵轨迹（橙）：仅 intercept 空地协同有 infantry，贴地 + 抬升 2
    const inf = frs[0].infantry;
    if (inf && inf.length) {
      const infMat = new THREE.MeshStandardMaterial({
        color: 0xd97706, emissive: 0x3a1a00, emissiveIntensity: 0.35, roughness: 0.5 });
      for (let i = 0; i < inf.length; i++) {
        const pts = [];
        for (let k = 0; k < frs.length; k++) {
          const u = frs[k].infantry && frs[k].infantry[i];
          if (u) pts.push(sb.P(u[0], u[1], this._terrainH(u[0], u[1]) + 2));
        }
        if (pts.length < 2) continue;
        const curve = new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.4);
        const tube = new THREE.Mesh(
          new THREE.TubeGeometry(curve, Math.min(160, pts.length * 3), 0.18, 8, false), infMat);
        sb.scene.add(tube);
      }
    }
  },

  _makeQuad(color) {
    const grp = new THREE.Group();
    grp.add(new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.26, 0.72),
      new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.4 })));
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.06, 8, 16),
      new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.5, roughness: 0.4 }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 0.12; ring.userData.ring = true;
    grp.add(ring);
    const armMat = new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.5 });
    const propMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, roughness: 0.4 });
    const blades = [];
    for (let i = 0; i < 4; i++) {
      const a = (i * Math.PI) / 2 + Math.PI / 4;
      const cx = Math.cos(a) * 0.85, cz = Math.sin(a) * 0.85;
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.06, 0.12), armMat);
      arm.position.set(cx, 0.16, cz); arm.rotation.y = -a;
      grp.add(arm);
      const pivot = new THREE.Group();
      pivot.position.set(cx, 0.28, cz);
      pivot.add(new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.025, 0.14), propMat));
      grp.add(pivot);
      blades.push(pivot);
    }
    // 机头标记：+Z 前方，用于俯仰/朝向姿态显示（爬升扬起、俯冲落下）
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.38, 6),
      new THREE.MeshStandardMaterial({ color: 0xffb300, emissive: 0xff6d00, emissiveIntensity: 0.5 }));
    nose.rotation.x = -Math.PI / 2;   // 锥尖指向 +Z
    nose.position.set(0, 0.12, 0.52);
    grp.add(nose);
    grp.userData.blades = blades;
    return grp;
  },

  _addSandboxUnits() {
    const sb = this._sandbox, frs = this._result.frames || [];
    if (!frs.length) return;
    const frame = frs[Math.min(this._frame, frs.length - 1)];
    const cargos = frame.cargos || [];
    const COL = { 0: 0x00e5ff, 1: 0x00e676, 2: 0xff5252 };
    sb.frame.cargos = cargos.map((c, i) => {
      const st = c ? c[3] : 0;
      const grp = this._makeQuad(COL[st] || 0x00e5ff);
      grp.position.copy(sb.P(c[0], c[1], c[2] + 15));
      grp.userData.idx = i;
      sb.scene.add(grp);
      grp.userData.blades.forEach(b => sb.frame.blades.push(b));
      return grp;
    });
    const relayMat = new THREE.MeshStandardMaterial({
      color: 0x9b59b6, emissive: 0x9b59b6, emissiveIntensity: 0.3, roughness: 0.4 });
    const relayMetal = new THREE.MeshStandardMaterial({
      color: 0xd8d8d8, roughness: 0.3, metalness: 0.7 });
    sb.frame.relays = (frame.relays || []).map(r => {
      const grp = new THREE.Group();
      grp.add(new THREE.Mesh(new THREE.SphereGeometry(0.34, 12, 12), relayMat));
      const ringA = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.045, 8, 20), relayMetal);
      ringA.rotation.x = Math.PI / 2;
      grp.add(ringA);
      const ringB = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.045, 8, 20), relayMetal);
      ringB.rotation.z = Math.PI / 2;
      grp.add(ringB);
      const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.0, 6), relayMetal);
      ant.position.y = 0.75;
      grp.add(ant);
      const tip = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xff5252, emissive: 0xff5252, emissiveIntensity: 0.6 }));
      tip.position.y = 1.3;
      grp.add(tip);
      grp.position.copy(sb.P(r[0], r[1], r[2] + 10));
      grp.traverse(o => { o.castShadow = true; });
      sb.scene.add(grp);
      return grp;
    });
  },

  _addSandboxMarkers() {
    const sb = this._sandbox, g = this._result.geometry;
    (g.disasters || []).forEach(d => {
      const p = sb.P(d[0], d[1], d[2] + 30);
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 12),
        new THREE.MeshStandardMaterial({ color: 0xe63946, emissive: 0xe63946, emissiveIntensity: 0.6 }));
      ball.position.copy(p);
      sb.scene.add(ball);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.4, 6),
        new THREE.MeshStandardMaterial({ color: 0x555555 }));
      pole.position.set(p.x, p.y - 1.2, p.z);
      sb.scene.add(pole);
    });
    const base = g.base || [0, 0, 0];
    const bp = sb.P(base[0], base[1], base[2] + 30);
    const bball = new THREE.Mesh(new THREE.SphereGeometry(0.7, 14, 14),
      new THREE.MeshStandardMaterial({ color: 0x1c2833, emissive: 0x1c2833, emissiveIntensity: 0.3 }));
    bball.position.copy(bp);
    sb.scene.add(bball);
  },

  _addSandboxLinks() {
    const sb = this._sandbox, g = this._result.geometry;
    const base = g.base || [0, 0, 0], disasters = g.disasters || [];
    const relays = this._result.relay_pts || [];
    const mat = new THREE.LineDashedMaterial({ color: 0x9b59b6, dashSize: 0.6, gapSize: 0.4, transparent: true, opacity: 0.55 });
    const mk = (a, b) => {
      const geo = new THREE.BufferGeometry().setFromPoints(
        [sb.P(a[0], a[1], a[2] + 15), sb.P(b[0], b[1], b[2] + 15)]);
      const line = new THREE.Line(geo, mat);
      line.computeLineDistances();
      sb.scene.add(line);
    };
    disasters.forEach(d => {
      if (relays.length) relays.forEach(r => { mk(base, r); mk(r, d); });
      else mk(base, d);
    });
  },

  // ---------- intercept 三维山地对抗：拦截者 / 无人机 / 标记 ----------
  _makeCaptureFan(r, half) {
    // 侦察范围为三维圆锥：顶点在拦截者、开口朝机头前方（+Z）。
    // 圆锥半径 = r·sin(half)、高度 = r·cos(half)，与后端「水平角+垂直角+距离」判据一致。
    const coneR = r * Math.sin(half);
    const coneH = r * Math.cos(half);
    const geo = new THREE.ConeGeometry(coneR, coneH, 48, 1, true);
    geo.translate(0, -coneH / 2, 0);   // 顶点移到原点
    geo.rotateX(-Math.PI / 2);         // 开口朝 +Z（北）
    const grp = new THREE.Group();
    grp.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
      color: 0xff5252, transparent: true, opacity: 0.16, depthWrite: false,
      side: THREE.DoubleSide })));
    // 底面开口轮廓环，勾勒圆锥边界
    const rimPts = [];
    for (let i = 0; i <= 48; i++) {
      const a = (2 * Math.PI * i) / 48;
      rimPts.push(new THREE.Vector3(Math.cos(a) * coneR, Math.sin(a) * coneR, 0));
    }
    const rim = new THREE.LineLoop(
      new THREE.BufferGeometry().setFromPoints(rimPts),
      new THREE.LineBasicMaterial({ color: 0xff5252, transparent: true, opacity: 0.55 }));
    rim.position.z = coneH;
    grp.add(rim);
    return grp;
  },

  // 红方拦截机：直升机（机身 + 主旋翼 + 尾梁尾旋翼 + 滑橇起落架），机头朝 +Z，
  // 主/尾旋翼存入 userData.rotors，由渲染循环持续旋转
  _makeInterceptor() {
    const grp = new THREE.Group();
    const red = new THREE.MeshStandardMaterial({ color: 0xb03030, roughness: 0.4, metalness: 0.15 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x262a2e, roughness: 0.5 });
    const glass = new THREE.MeshStandardMaterial({ color: 0x88ccff, roughness: 0.2, metalness: 0.3, transparent: true, opacity: 0.75 });

    // 机身舱体：中段盒 + 前端半球鼻 + 后段收窄，机头朝 +Z
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.74, 2.4), red);
    grp.add(body);
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.52, 16, 12), red);
    nose.scale.set(1, 0.78, 1.05);
    nose.position.z = 1.45;
    grp.add(nose);
    const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 12), glass);
    canopy.scale.set(0.92, 0.7, 1.15);
    canopy.position.set(0, 0.3, 0.95);
    grp.add(canopy);

    // 顶部旋翼轴 + 主旋翼（水平，绕 Y 旋转）
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.55, 8), dark);
    mast.position.y = 0.64;
    grp.add(mast);
    const rotor = new THREE.Group();
    rotor.position.y = 0.92;
    const bGeo = new THREE.BoxGeometry(0.3, 0.05, 5.4);
    const b1 = new THREE.Mesh(bGeo, dark);
    const b2 = new THREE.Mesh(bGeo, dark);
    b2.rotation.y = Math.PI / 2;
    rotor.add(b1, b2);
    rotor.add(new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.14, 8), dark));
    grp.add(rotor);

    // 尾梁 + 垂直尾翼 + 尾旋翼（水平小风扇，绕 Y 旋转）
    const boom = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, 2.0), red);
    boom.position.set(0, 0.18, -1.95);
    grp.add(boom);
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.75, 0.55), red);
    fin.position.set(0, 0.55, -2.6);
    grp.add(fin);
    const tailRotor = new THREE.Group();
    tailRotor.position.set(0, 0.42, -2.85);
    const tGeo = new THREE.BoxGeometry(1.2, 0.05, 0.14);
    const t1 = new THREE.Mesh(tGeo, dark);
    const t2 = new THREE.Mesh(tGeo, dark);
    t2.rotation.y = Math.PI / 2;
    tailRotor.add(t1, t2);
    grp.add(tailRotor);

    // 滑橇起落架：两条平行滑橇 + 支撑杆
    const skidGeo = new THREE.BoxGeometry(0.16, 0.1, 2.3);
    for (const s of [-1, 1]) {
      const skid = new THREE.Mesh(skidGeo, dark);
      skid.position.set(s * 0.58, -0.44, -0.2);
      grp.add(skid);
      const legF = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.5, 0.1), dark);
      legF.position.set(s * 0.58, -0.2, 0.78);
      grp.add(legF);
      const legB = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.5, 0.1), dark);
      legB.position.set(s * 0.58, -0.2, -1.1);
      grp.add(legB);
    }

    grp.userData.rotors = [rotor, tailRotor];
    // 旋翼转速基础值（尾旋翼更快）：起降阶段随 phase/speed 平滑增减，表现加减速
    rotor.userData.base = 26;
    tailRotor.userData.base = 52;
    rotor.userData.spin = 0; rotor.userData.target = 0;
    tailRotor.userData.spin = 0; tailRotor.userData.target = 0;
    grp.traverse(o => { o.castShadow = true; });
    return grp;
  },

  _addSandboxInterceptors() {
    const sb = this._sandbox, g = this._result.geometry;
    const frs = this._result.frames || [];
    const frame = frs.length ? frs[0] : null;
    const irad = g.intercept_radius || 80;
    const ihalf = g.intercept_half_angle || (Math.PI / 3);
    // 直升机恢复原始可见尺寸（旋翼直径 ≈ 5.4 scene 单位 ≈ 1620 m）。swarm 现
    // 仅 2 架（左右各 1、单独停靠各自停机坪中心），无需为「编队重叠」缩小尺寸；
    // 捕获锥与直升机同比例缩放以保持相对视觉关系。
    const heliScale = 1.0;
    const fanScale = 1.0;
    sb.frame.interceptors = [];
    sb.frame.inter_fans = [];
    (g.interceptors0 || []).forEach((p, k) => {
      let x = p[0], y = p[1], z, h = 0;
      if (frame && frame.interceptors && frame.interceptors[k]) {
        x = frame.interceptors[k][0]; y = frame.interceptors[k][1];
        z = frame.interceptors[k][2]; h = frame.interceptors[k][3];
      } else {
        // 无帧（仅「加载地形」浏览）：红方无人机停靠待命（贴地停机坪），
        // swarm 与 intercept 一致（停靠基地两侧停机坪，雷达捕获后才起飞）。
        z = this._terrainH(x, y);
      }
      const grp = this._makeInterceptor();
      grp.scale.setScalar(heliScale);   // 直升机原始尺寸（左右各 1 架，无需为重叠缩小）
      // 初始按首帧 phase 决定高度：停靠(0)贴地 / 起降(1) / 巡航(2)。
      // swarm 现提供 phase 字段，与 intercept 一致按帧渲染。
      const ph0 = (frame && frame.interceptors && frame.interceptors[k]
                   && frame.interceptors[k][4] !== undefined)
        ? frame.interceptors[k][4] : 0;
      const gpos = sb.P(x, y, z);
      gpos.y = this._heliVizY(x, y, z, ph0);
      grp.position.copy(gpos);
      grp.rotation.y = Math.PI / 2 - h;
      sb.scene.add(grp);
      // 直升机旋翼加入专用旋转池（转速随 phase 加减速，见 _updateInterceptFrame）
      (grp.userData.rotors || []).forEach(r => sb.frame.heliRotors.push(r));
      const fan = this._makeCaptureFan(irad, ihalf);
      fan.scale.setScalar(fanScale);   // 捕获锥与直升机同比例（半径 = irad·sin(half)）
      fan.visible = (ph0 === 2);   // 停靠/起降阶段隐藏捕获锥，仅巡航拦截时显示
      const fpos = sb.P(x, y, z + 0.4);
      fpos.y = this._heliVizY(x, y, z, ph0);
      fan.position.copy(fpos);
      fan.rotation.y = Math.PI / 2 - h;
      sb.scene.add(fan);
      sb.frame.interceptors.push(grp);
      sb.frame.inter_fans.push(fan);
    });
    // 直升机停机坪（H）：swarm 用基地左右两侧的固定停机坪中心（g.helipads），
    // 红方直升机单独停靠在各自停机坪中心；intercept 等无 helipads 的场景按拦截机初始位置逐一绘制。
    const pads = (g.helipads && g.helipads.length) ? g.helipads : (g.interceptors0 || []);
    pads.forEach(p => this._addHelipad(p[0], p[1]));
  },

  // 直升机停靠点（H）：灰色圆形停机坪 + 白色外环 + 平铺的黄色「H」标记（贴地）
  _addHelipad(x, y) {
    const sb = this._sandbox;
    const gz = this._terrainH(x, y);
    const base = sb.P(x, y, gz);
    const pad = new THREE.Mesh(
      new THREE.CircleGeometry(4.2, 40),
      new THREE.MeshBasicMaterial({ color: 0x4a5057, transparent: true, opacity: 0.9, depthWrite: false }));
    pad.rotation.x = -Math.PI / 2;
    pad.position.set(base.x, base.y + 0.12, base.z);
    sb.scene.add(pad);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(3.9, 4.2, 48),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.75, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(base.x, base.y + 0.16, base.z);
    sb.scene.add(ring);
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#ffd54f';
    ctx.font = 'bold 92px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('H', 64, 68);
    const mark = new THREE.Mesh(
      new THREE.PlaneGeometry(3.4, 3.4),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false }));
    mark.rotation.x = -Math.PI / 2;
    mark.position.set(base.x, base.y + 0.24, base.z);
    sb.scene.add(mark);
  },

  // 雷达站 + 探测范围：位于 radar_pos，绿色半透明大圆盘表示探测范围，
  // 顶部旋转天线加入 radar_spins 持续旋转（雷达捕获入侵无人机后才出动直升机）
  _addSandboxRadar() {
    const sb = this._sandbox, g = this._result.geometry;
    const rp = g.radar_pos || (g.interceptors0 && g.interceptors0[0]) || [0, 0];
    const rr = g.radar_range || 520;
    const x = rp[0], y = rp[1];
    const gz = this._terrainH(x, y);
    const base = sb.P(x, y, gz);
    const sr = sb.sx(x + rr) - sb.sx(x);   // 探测半径换算为场景单位

    // 网状半球探测罩（线框，覆盖雷达站上方，表示立体预警范围，持续缓慢旋转）
    const domeMat = new THREE.MeshBasicMaterial({
      color: 0x22cc66, wireframe: true, transparent: true,
      opacity: 0.20, depthWrite: false });
    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(sr, 48, 24, 0, Math.PI * 2, 0, Math.PI / 2), domeMat);
    dome.position.set(base.x, base.y + 0.4, base.z);
    sb.scene.add(dome);
    // 地面投影外环（淡，标记覆盖边界）
    const brim = new THREE.Mesh(
      new THREE.RingGeometry(sr * 0.97, sr, 128),
      new THREE.MeshBasicMaterial({ color: 0x22cc66, transparent: true, opacity: 0.30, side: THREE.DoubleSide, depthWrite: false }));
    brim.rotation.x = -Math.PI / 2;
    brim.position.set(base.x, base.y + 0.08, base.z);
    sb.scene.add(brim);
    // 雷达扫描波束：窄经度切片（西瓜瓣状），绕 Y 快速旋转表示扫描
    const sweep = new THREE.Mesh(
      new THREE.SphereGeometry(sr * 0.98, 32, 16, -0.10, 0.20, 0, Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x66ff99, transparent: true, opacity: 0.13, side: THREE.DoubleSide, depthWrite: false }));
    sweep.position.set(base.x, base.y + 0.4, base.z);
    sb.scene.add(sweep);

    // 雷达站：底座 + 塔柱 + 顶部旋转天线
    const grp = new THREE.Group();
    const steel = new THREE.MeshStandardMaterial({ color: 0x8a919a, roughness: 0.5, metalness: 0.4 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x2b2f33, roughness: 0.6 });
    const baseM = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.6, 2.0, 12), dark);
    baseM.position.y = 1.0;
    grp.add(baseM);
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.6, 9.0, 12), steel);
    mast.position.y = 6.5;
    grp.add(mast);
    const ant = new THREE.Group();
    ant.position.y = 11.4;
    const spine = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 4.6), steel);
    ant.add(spine);
    const face = new THREE.Mesh(new THREE.BoxGeometry(3.4, 2.2, 0.2), steel);
    face.position.set(0, 0, 2.6);
    ant.add(face);
    const red = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 10),
      new THREE.MeshBasicMaterial({ color: 0xff3a3a }));
    red.position.y = 1.15;
    ant.add(red);
    grp.add(ant);
    grp.position.set(base.x, base.y, base.z);
    sb.scene.add(grp);
    if (!sb.frame.radar_spins) sb.frame.radar_spins = [];
    sb.frame.radar_spins.push(ant);
    if (!sb.frame.radar_domes) sb.frame.radar_domes = [];
    sb.frame.radar_domes.push(dome);
    if (!sb.frame.radar_sweeps) sb.frame.radar_sweeps = [];
    sb.frame.radar_sweeps.push(sweep);
  },

  _addSandboxDrones() {
    const sb = this._sandbox, frs = this._result.frames || [];
    if (!frs.length) return;
    const frame = frs[0];
    const COL = { 0: 0x00e5ff, 1: 0x00e676, 2: 0xff5252, 3: 0xaa55cc };
    sb.frame.drones = (frame.drones || []).map((d, i) => {
      const st = d ? d[3] : 0;
      const grp = this._makeQuad(COL[st] || 0x00e5ff);
      const pos = sb.P(d[0], d[1], d[2]);
      pos.y = this._flyVizY(d[0], d[1], d[2]);
      grp.position.copy(pos);
      grp.userData.idx = i;
      sb.scene.add(grp);
      grp.userData.blades.forEach(b => sb.frame.blades.push(b));
      return grp;
    });
  },

  // 地面防空车：贴地机动 + 对空拦截（不可跨越峡谷/瀑布），渲染为真实车载防空系统：
  // 履带式底盘 + 旋转炮塔 + 相控阵雷达 + 倾斜发射筒（红旗-17 风格）
  _makeAA() {
    const grp = new THREE.Group();
    const hullMat = new THREE.MeshStandardMaterial({ color: 0x3f4a3a, roughness: 0.55, metalness: 0.25 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x23272b, roughness: 0.7, metalness: 0.3 });
    const trackMat = new THREE.MeshStandardMaterial({ color: 0x181c1e, roughness: 0.85 });

    // 车体（带前倾棱角，更接近真实装甲车）
    const hull = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.4, 2.1), hullMat);
    hull.position.y = 0.42;
    grp.add(hull);
    const nose = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.28, 0.55), hullMat);
    nose.position.set(0, 0.62, -1.05); nose.rotation.x = 0.12;
    grp.add(nose);

    // 双侧履带（含驱动轮 + 负重轮）
    const wheelGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.14, 12);
    const idlerGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.14, 12);
    for (const side of [-1, 1]) {
      const track = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.34, 1.9), trackMat);
      track.position.set(side * 0.62, 0.22, 0);
      grp.add(track);
      const idler = new THREE.Mesh(idlerGeo, darkMat);
      idler.rotation.z = Math.PI / 2; idler.position.set(side * 0.62, 0.2, 0.85);
      grp.add(idler);
      for (let w = 0; w < 4; w++) {
        const wheel = new THREE.Mesh(wheelGeo, darkMat);
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(side * 0.62, 0.18, 0.55 - w * 0.4);
        grp.add(wheel);
      }
    }

    // 旋转炮塔座 + 雷达罩
    const turret = new THREE.Group();
    const turretBase = new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.52, 0.3, 16), hullMat);
    turretBase.position.y = 0.72;
    turret.add(turretBase);
    const radome = new THREE.Mesh(new THREE.SphereGeometry(0.26, 14, 10), darkMat);
    radome.position.y = 0.94;
    turret.add(radome);
    const panel = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.34, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x0c0f12, roughness: 0.35, metalness: 0.5 }));
    panel.position.set(0, 0.88, -0.42);
    turret.add(panel);

    // 倾斜发射筒（4 联装，仰角朝前），发射时导弹由此射出
    const tubeMat = new THREE.MeshStandardMaterial({ color: 0x2c3e30, roughness: 0.4, metalness: 0.5 });
    for (const side of [-1, 1]) {
      for (let t = 0; t < 2; t++) {
        const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.85, 10), tubeMat);
        tube.rotation.x = -1.05;   // 仰角朝前上方
        tube.position.set(side * 0.22, 0.9, -0.3 + t * 0.26);
        turret.add(tube);
      }
    }
    grp.add(turret);

    // 顶部雷达天线叶片（细长，旋转时清晰可见）
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.5),
      new THREE.MeshStandardMaterial({ color: 0x1a1d20, roughness: 0.3, metalness: 0.6 }));
    fin.position.y = 1.12;
    turret.add(fin);

    grp.userData.aa = true;
    grp.userData.radar = turret;   // 炮塔（雷达+发射筒）整体旋转，供渲染循环扫描
    grp.traverse(o => { o.castShadow = true; });
    return grp;
  },

  // 防空车对空攻击范围：以车顶为顶点、向上张开的红色漏斗（正立圆锥）。
  // 语义与后端判定一致：水平距离 <= aa_range 且 仰角 <= aa_vert_half_angle（度）。
  // 故底面半径 = aa_range（水平），锥高 = aa_range * tan(仰角)。
  // 水平/垂直比例不同，需分别按 S/V 换算到场景单位。
  _makeAAScanFan(range, vhalfDeg) {
    const sb = this._sandbox;
    const vhalf = vhalfDeg * Math.PI / 180;   // 仰角（母线与水平面夹角）
    const S = sb.sx(1) - sb.sx(0);   // 水平每米 -> 场景单位
    const V = sb.sy(1) - sb.sy(0);   // 垂直每米 -> 场景单位
    const coneR = range * S;                     // 底面半径 = aa_range（水平）
    const coneH = range * Math.tan(vhalf) * V;   // 锥高 = aa_range * tan(仰角)
    const geo = new THREE.ConeGeometry(coneR, coneH, 48, 1, true);
    // ConeGeometry 默认尖顶朝 +Y、底面开口朝 -Y；先绕 X 翻转 180° 再平移，
    // 使「顶点（窄端）落在车顶、开口（宽端）朝天」，即正立的对空攻击漏斗。
    geo.rotateX(Math.PI);
    geo.translate(0, coneH / 2, 0);   // 顶点移到原点（车顶），开口在 +coneH（天）
    const grp = new THREE.Group();
    grp.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
      color: 0xff2020, transparent: true, opacity: 0.13, depthWrite: false,
      side: THREE.DoubleSide })));
    // 底面开口轮廓环（红色，勾勒圆锥边界）
    const rimPts = [];
    for (let i = 0; i <= 48; i++) {
      const a = (2 * Math.PI * i) / 48;
      rimPts.push(new THREE.Vector3(Math.cos(a) * coneR, coneH, Math.sin(a) * coneR));
    }
    const rim = new THREE.LineLoop(
      new THREE.BufferGeometry().setFromPoints(rimPts),
      new THREE.LineBasicMaterial({ color: 0xff4040, transparent: true, opacity: 0.5 }));
    grp.add(rim);
    return grp;
  },

  // 瀑布流动水流纹理：深蓝->白 纵向渐变水体 + 密集高对比白色水流纹 + 泡沫斑，
  // 由 ShaderMaterial 平铺并滚动（uTime）模拟向下流水，四边软边缘在 shader 中实现
  _makeFlowingWaterTexture() {
    const c = document.createElement('canvas');
    c.width = 128; c.height = 512;
    const ctx = c.getContext('2d');
    const g0 = ctx.createLinearGradient(0, 0, 0, 512);
    g0.addColorStop(0.00, '#eaf6fd');   // 顶部：跌水白
    g0.addColorStop(0.22, '#5aaedb');   // 中上：浅蓝
    g0.addColorStop(0.50, '#2f7fb8');   // 中部：深蓝
    g0.addColorStop(0.80, '#6fbce6');   // 中下：蓝
    g0.addColorStop(1.00, '#f2faff');   // 底部：泡沫白
    ctx.fillStyle = g0;
    ctx.fillRect(0, 0, 128, 512);
    let seed = 7;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    // 密集高对比纵向水流纹（明显的白色水柱）
    for (let i = 0; i < 340; i++) {
      const x = rnd() * 128, y = rnd() * 512;
      const len = 40 + rnd() * 150, w = 1 + rnd() * 4;
      ctx.strokeStyle = `rgba(255,255,255,${0.45 + rnd() * 0.5})`;
      ctx.lineWidth = w;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.bezierCurveTo(x + (rnd() - 0.5) * 14, y + len * 0.35,
        x + (rnd() - 0.5) * 16, y + len * 0.7, x + (rnd() - 0.5) * 10, y + len);
      ctx.stroke();
    }
    // 白色泡沫斑块（水花）
    for (let i = 0; i < 80; i++) {
      const x = rnd() * 128, y = rnd() * 512, r = 1.5 + rnd() * 6;
      ctx.fillStyle = `rgba(255,255,255,${0.30 + rnd() * 0.55})`;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.283); ctx.fill();
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1, 1);
    tex.anisotropy = 8;
    return tex;
  },

  // 河流水面纹理：蓝色水体 + 横向波纹，供 render 循环滚动 offset.x 模拟河水沿 X 流动
  _makeRiverTexture() {
    const c = document.createElement('canvas');
    c.width = 256; c.height = 64;
    const ctx = c.getContext('2d');
    const g0 = ctx.createLinearGradient(0, 0, 0, 64);
    g0.addColorStop(0.0, '#2e86c1');
    g0.addColorStop(0.5, '#4fa3d8');
    g0.addColorStop(1.0, '#2e86c1');
    ctx.fillStyle = g0;
    ctx.fillRect(0, 0, 256, 64);
    let seed = 13;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    for (let i = 0; i < 46; i++) {
      const x = rnd() * 256, y = rnd() * 64;
      const len = 20 + rnd() * 90;
      ctx.strokeStyle = `rgba(255,255,255,${0.18 + rnd() * 0.4})`;
      ctx.lineWidth = 0.5 + rnd() * 1.5;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + len, y + (rnd() - 0.5) * 8);
      ctx.stroke();
    }
    // 河岸软边缘：宽度方向（v）中心不透明、上下渐隐
    ctx.globalCompositeOperation = 'destination-in';
    const vf = ctx.createLinearGradient(0, 0, 0, 64);
    vf.addColorStop(0, 'rgba(0,0,0,0)'); vf.addColorStop(0.22, 'rgba(0,0,0,1)');
    vf.addColorStop(0.78, 'rgba(0,0,0,1)'); vf.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = vf; ctx.fillRect(0, 0, 256, 64);
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1, 1);
    tex.anisotropy = 4;
    return tex;
  },

  // 白色水花径向渐变纹理（中心不透明、边缘透明），用于崖底溅起水花与跌水线
  _makeFoamTexture() {
    const S = 128;
    const c = document.createElement('canvas');
    c.width = c.height = S;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2);
    g.addColorStop(0, 'rgba(255,255,255,0.85)');
    g.addColorStop(0.5, 'rgba(255,255,255,0.45)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, S, S);
    return new THREE.CanvasTexture(c);
  },

  // 河流水面网格：沿河道长度/宽度采样地形，水面填满谷底凹陷、河岸软过渡贴合地形
  _buildRiverMesh(f) {
    const sb = this._sandbox;
    const x0 = f[0], x1 = f[2], y = (f[1] + f[3]) / 2, hw = f[4] || 0;
    const M = 48, K = 12, depth = 10;
    // 沿 X 采样河面基准高度（谷底最低点 + 水深）
    const base = [];
    for (let i = 0; i <= M; i++) {
      const x = x0 + (x1 - x0) * i / M;
      let hmin = Infinity;
      for (let s = -2; s <= 2; s++) hmin = Math.min(hmin, this._terrainHLinear(x, y + s * hw * 0.3));
      base.push(hmin + depth);
    }
    const sm = new Array(M + 1);
    for (let i = 0; i <= M; i++) {
      let acc = 0;
      for (let d = -5; d <= 5; d++) acc += base[Math.min(M, Math.max(0, i + d))];
      sm[i] = acc / 11;
    }
    const pos = [], uv = [], idx = [];
    for (let i = 0; i <= M; i++) {
      const x = x0 + (x1 - x0) * i / M;
      for (let k = 0; k <= K; k++) {
        const dk = -1 + 2 * k / K;
        const yy = y + dk * hw;
        const g = this._terrainHLinear(x, yy);
        const w = Math.pow(Math.max(0, 1 - Math.abs(dk)), 1.5);
        pos.push(sb.sx(x), sb.sy(g + (sm[i] - g) * w), sb.sz(yy));
        uv.push(i / M * 2, k / K);
      }
    }
    for (let i = 0; i < M; i++) for (let k = 0; k < K; k++) {
      const a = i * (K + 1) + k, c = a + 1, b = a + K + 1, d = b + 1;
      idx.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
      map: sb.frame.riverflowTex, color: 0xffffff, transparent: true, opacity: 0.85,
      side: THREE.DoubleSide, depthWrite: false }));
    mesh.renderOrder = 2;
    return mesh;
  },

  // 瀑布水幕：沿崖壁 tanh 过渡坡贴地形，ShaderMaterial 滚动水纹 + 固定四边软边缘
  _buildWaterfallMesh(f) {
    const sb = this._sandbox;
    const x0 = f[0], x1 = f[2], cy = (f[1] + f[3]) / 2, hw = f[4] || 0;
    const trans = hw * 0.45, Ytop = cy + trans, Ybot = cy - trans;
    // 水幕抬升量：随地形高差缩放，避免贴地 1 米在 3D 里被不透明岩壁/地形遮挡
    const lift = sb.zRange * 0.02;
    const M = 32, K = 18;
    const pos = [], uv = [], idx = [];
    for (let i = 0; i <= M; i++) {
      const u = i / M, x = x0 + (x1 - x0) * u;
      for (let k = 0; k <= K; k++) {
        const t = k / K, y = Ytop + (Ybot - Ytop) * t;
        pos.push(sb.sx(x), sb.sy(this._terrainHLinear(x, y) + lift), sb.sz(y));
        uv.push(u, t);
      }
    }
    for (let i = 0; i < M; i++) for (let k = 0; k < K; k++) {
      const a = i * (K + 1) + k, c = a + 1, b = a + K + 1, d = b + 1;
      idx.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    const mat = new THREE.ShaderMaterial({
      uniforms: { uTex: { value: sb.frame.waterflowTex }, uTime: { value: 0 } },
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: 'varying vec2 vUv; uniform sampler2D uTex; uniform float uTime;' +
        'void main(){ vec2 f = vec2(vUv.x * 2.0, vUv.y * 6.0 - uTime);' +
        'vec4 c = texture2D(uTex, f);' +
        'float ex = smoothstep(0.0, 0.22, vUv.x) * (1.0 - smoothstep(0.78, 1.0, vUv.x));' +
        'float ey = smoothstep(0.0, 0.08, vUv.y) * (1.0 - smoothstep(0.90, 1.0, vUv.y));' +
        'c.a *= ex * ey; gl_FragColor = c; }'
    });
    (sb.frame.waterflowMats = sb.frame.waterflowMats || []).push(mat);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.renderOrder = 3;
    return mesh;
  },

  // 断崖岩壁：顶部贴高地地形、底部贴低地地形，中间沿 tanh 坡过渡（非垂直矩形）
  _buildCliffMesh(f) {
    const sb = this._sandbox;
    const x0 = f[0], x1 = f[2], cy = (f[1] + f[3]) / 2, hw = f[4] || 0;
    const trans = hw * 0.5, Ytop = cy + trans, Ybot = cy - trans;
    const M = 64, K = 6;
    const pos = [], idx = [];
    for (let i = 0; i <= M; i++) {
      const x = x0 + (x1 - x0) * i / M;
      for (let k = 0; k <= K; k++) {
        const t = k / K, y = Ybot + (Ytop - Ybot) * t;
        pos.push(sb.sx(x), sb.sy(this._terrainHLinear(x, y) + 0.4), sb.sz(y));
      }
    }
    for (let i = 0; i < M; i++) for (let k = 0; k < K; k++) {
      const a = i * (K + 1) + k, b = a + 1, c = a + K + 1, d = c + 1;
      idx.push(a, b, c, b, d, c);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    return new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
      color: 0x8a7455, roughness: 0.95, side: THREE.DoubleSide }));
  },

  // 拦截导弹：细长弹体 + 发光鼻锥 + 尾焰（局部 +Y = 飞行方向）
  _makeMissile() {
    const grp = new THREE.Group();
    // 放大弹体尺寸，使高速拦截导弹在远景下依然清晰可见（原 0.5 长度过小）
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.11, 1.3, 8),
      new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.3, metalness: 0.7,
        emissive: 0x221100, emissiveIntensity: 0.3 }));
    grp.add(body);
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xff7722 }));
    nose.position.y = 0.68;
    grp.add(nose);
    // 加长发光尾焰，拖出明显尾迹
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.10, 0.85, 8),
      new THREE.MeshBasicMaterial({ color: 0xffb347, transparent: true, opacity: 0.9, depthWrite: false }));
    flame.position.y = -0.78;
    flame.rotation.x = Math.PI;   // 尾焰朝后（-Y）
    grp.add(flame);
    grp.userData.missile = true;
    return grp;
  },

  _addSandboxAA() {
    const sb = this._sandbox, g = this._result.geometry;
    const frs = this._result.frames || [];
    const frame = frs.length ? frs[0] : null;
    const aaRange = g.aa_range || 6000.0;
    const aaVhalf = g.aa_vert_half_angle || 60.0;
    sb.frame.aa = [];
    sb.frame.aa_fans = [];
    sb.frame.aa_radars = [];
    (g.aa0 || []).forEach((p, k) => {
      let x = p[0], y = p[1], z, h = 0;
      if (frame && frame.aa && frame.aa[k]) {
        x = frame.aa[k][0]; y = frame.aa[k][1];
        z = frame.aa[k][2]; h = frame.aa[k][3];
      } else {
        z = this._terrainH(x, y);
      }
      const grp = this._makeAA();
      grp.position.copy(sb.P(x, y, z));
      grp.rotation.y = Math.PI / 2 - h;
      sb.scene.add(grp);
      sb.frame.aa.push(grp);
      if (grp.userData.radar) sb.frame.aa_radars.push(grp.userData.radar);
      // 红色对空扫描锥：跟随车顶位置
      const fan = this._makeAAScanFan(aaRange, aaVhalf);
      fan.position.copy(sb.P(x, y, z + 0.5));
      sb.scene.add(fan);
      sb.frame.aa_fans.push(fan);
    });
  },

  // 单位血条：红色背景 = 已扣血量，绿色前景 = 剩余血量（scale.x 0~1 表示剩余比例），返回 { grp, fill }
  _makeHpBar(w) {
    const bg = new THREE.Mesh(new THREE.BoxGeometry(w, 0.14, 0.04),
      new THREE.MeshBasicMaterial({ color: 0xd63031, transparent: true, opacity: 0.9, depthWrite: false }));
    bg.renderOrder = 0;
    const fill = new THREE.Mesh(new THREE.BoxGeometry(w, 0.14, 0.04),
      new THREE.MeshBasicMaterial({ color: 0x2ecc71, transparent: true, opacity: 1.0, depthWrite: false }));
    fill.renderOrder = 1;                 // 绿色前景盖在红色背景之上
    fill.geometry.translate(0.5, 0, 0);   // 几何左缘对齐原点，便于 scale.x 从左侧收缩
    fill.position.x = -w / 2;
    const grp = new THREE.Group();
    grp.add(bg); grp.add(fill);
    return { grp, fill };
  },

  // 地面单位攻击范围环（薄环，贴地）
  _makeRangeRing(r, color) {
    const ring = new THREE.Mesh(new THREE.RingGeometry(Math.max(0, r - 0.12), r, 40),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    return ring;
  },

  // 士兵可视范围（显眼）：半透明填充圆盘 + 亮色粗外环，贴地；返回 Group
  _makeVisionRange(r, color) {
    const grp = new THREE.Group();
    const disc = new THREE.Mesh(new THREE.CircleGeometry(Math.max(0.5, r), 72),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }));
    disc.rotation.x = -Math.PI / 2;
    grp.add(disc);
    const rim = new THREE.Mesh(new THREE.RingGeometry(Math.max(0, r - 0.6), r, 72),
      new THREE.MeshBasicMaterial({ color: 0xffa000, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
    rim.rotation.x = -Math.PI / 2;
    rim.position.y = 0.02;
    grp.add(rim);
    return grp;
  },

  // 士兵「发现入侵者」警示标志：头顶悬浮的感叹号精灵（始终面向相机，循环中做闪烁动画）
  _makeAlertSprite() {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const ctx = c.getContext('2d');
    // 红色圆底 + 白色描边 + 高亮感叹号
    const g = ctx.createRadialGradient(32, 28, 4, 32, 32, 30);
    g.addColorStop(0, '#ff6b5e'); g.addColorStop(1, '#d92020');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(32, 32, 28, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 4; ctx.strokeStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(32, 32, 26, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 40px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('!', 32, 34);
    const tex = new THREE.CanvasTexture(c);
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: tex, transparent: true, depthWrite: false, depthTest: false }));
    spr.scale.set(1.3, 1.3, 1);
    spr.renderOrder = 999;
    spr.visible = false;
    return spr;
  },

  // 地面步兵 / 巡逻兵：躯干 + 头部 + 头盔 + 步枪，颜色区分蓝/红
  _makeCqbSoldier(color) {
    const grp = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.1 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.8 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xd8b28a, roughness: 0.7 });
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.26, 0.72, 8), bodyMat);
    body.position.y = 0.46;
    grp.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 10), skinMat);
    head.position.y = 1.0;
    grp.add(head);
    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), bodyMat);
    helmet.position.y = 1.03;
    grp.add(helmet);
    const gun = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.58), darkMat);
    gun.position.set(0.24, 0.72, 0.14);
    grp.add(gun);
    grp.traverse(o => { o.castShadow = true; });
    return grp;
  },

  // 士兵阵亡：标记倒地/淡出状态 + 血泊扩散环（尸体由渲染循环推进动画）
  _killSoldier(sb, grp, pos) {
    grp.userData.dead = true;
    grp.userData.deadT = 0;
    grp.userData.deadDir = Math.random() < 0.5 ? 1 : -1;
    grp.position.copy(pos);
    grp.rotation.set(0, 0, 0);
    // 隐藏附属物（血条 / 攻击环 / 可视环 / 警示标志）
    ['hpBar', 'ring', 'visionRing', 'alert'].forEach(k => {
      if (grp.userData[k]) grp.userData[k].visible = false;
    });
    // 材质切换为可透明，供淡出
    grp.traverse(o => {
      if (o.material) { o.material.transparent = true; o.material.depthWrite = false; }
    });
    // 血泊：实心红色圆盘，倒地瞬间扩散 + 淡出（醒目提示阵亡）
    const ring = new THREE.Mesh(new THREE.CircleGeometry(0.55, 48),
      new THREE.MeshBasicMaterial({ color: 0xb71c1c, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(pos.x, pos.y + 0.07, pos.z);
    ring.renderOrder = 5;
    sb.scene.add(ring);
    grp.userData.deathRing = ring;
  },

  // 士兵复活复位（回看/跳帧回到存活状态时，清除阵亡动画的倒地/透明/血泊）
  _reviveSoldier(sb, grp) {
    grp.userData.dead = false;
    grp.userData.deadDone = false;
    grp.rotation.set(0, 0, 0);
    grp.traverse(o => {
      if (o.material) { o.material.transparent = false; o.material.opacity = 1; o.material.depthWrite = true; }
    });
    if (grp.userData.deathRing) {
      sb.scene.remove(grp.userData.deathRing);
      grp.userData.deathRing.geometry.dispose();
      grp.userData.deathRing.material.dispose();
      grp.userData.deathRing = null;
    }
    if (grp.userData.hpBar) grp.userData.hpBar.visible = true;
    if (grp.userData.visionRing) grp.userData.visionRing.visible = true;
  },

  // 军事基地（无人机轰炸点 + 步兵攻击点）：圆形平台 + 中心碉堡 + 旗杆 + 血量条 + 边界环
  _addSandboxBaseMarker() {
    const sb = this._sandbox, g = this._result.geometry;
    const bp = g.base_pos || [0, 0];
    const bhp = g.base_hp || 300;
    const brad = g.base_radius || 55;
    const S = sb.sx(1) - sb.sx(0);
    const x = bp[0], y = bp[1], z = this._terrainH(x, y);
    const pos = sb.P(x, y, z);
    const R = brad * S;

    const grp = new THREE.Group();
    const plat = new THREE.Mesh(new THREE.CylinderGeometry(R, (R + 0.6), 0.5, 32),
      new THREE.MeshStandardMaterial({ color: 0x8a8f86, roughness: 0.85 }));
    plat.position.y = 0.25;
    grp.add(plat);
    const bunker = new THREE.Mesh(new THREE.BoxGeometry(R * 0.6, R * 0.5, R * 0.6),
      new THREE.MeshStandardMaterial({ color: 0x6a6a62, roughness: 0.8 }));
    bunker.position.y = R * 0.25 + 0.5;
    grp.add(bunker);
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, R * 0.9, 6),
      new THREE.MeshStandardMaterial({ color: 0x55554e, roughness: 0.5 }));
    mast.position.y = R * 0.45 + 0.5;
    grp.add(mast);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(R * 0.4, R * 0.2),
      new THREE.MeshStandardMaterial({ color: 0xe63946, side: THREE.DoubleSide }));
    flag.position.set(R * 0.2, R * 0.85 + 0.5, 0);
    grp.add(flag);
    grp.position.copy(pos);
    grp.traverse(o => { o.castShadow = true; o.receiveShadow = true; });
    sb.scene.add(grp);
    sb.frame.baseGrp = grp;

    const hpW = R * 1.4;
    const hp = this._makeHpBar(hpW);
    hp.grp.position.set(pos.x, pos.y + R * 1.15 + 1.2, pos.z);
    sb.scene.add(hp.grp);
    sb.frame.baseHpFill = hp.fill;
    sb.frame.baseHpMax = bhp;

    const ring = new THREE.Mesh(new THREE.RingGeometry(R * 0.98, R, 48),
      new THREE.MeshBasicMaterial({ color: 0x2ecc71, transparent: true, opacity: 0.6, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(pos.x, pos.y + 0.6, pos.z);
    sb.scene.add(ring);
    sb.frame.baseRing = ring;
  },

  // 巷战楼房（掩体）：贴地混凝土楼体 + 平顶 + 窗户，静止无更新
  _addSandboxCqbBuildings() {
    const sb = this._sandbox, g = this._result.geometry;
    const S = sb.sx(1) - sb.sx(0);
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xc9bfa8, roughness: 0.85 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x8b8577, roughness: 0.8 });
    const winMat = new THREE.MeshStandardMaterial({ color: 0x3a4a5a, roughness: 0.4, metalness: 0.3 });
    (g.buildings || []).forEach(([cx, cy, w, d]) => {
      const wS = w * S, dS = d * S;
      const hS = Math.max(1.2, (wS + dS) * 0.32);
      const pos = sb.P(cx, cy, this._terrainH(cx, cy));
      const body = new THREE.Mesh(new THREE.BoxGeometry(wS, hS, dS), wallMat);
      body.position.set(pos.x, pos.y + hS / 2, pos.z);
      body.castShadow = body.receiveShadow = true;
      sb.scene.add(body);
      const roof = new THREE.Mesh(new THREE.BoxGeometry(wS + 0.2, 0.18, dS + 0.2), roofMat);
      roof.position.set(pos.x, pos.y + hS + 0.09, pos.z);
      roof.castShadow = true;
      sb.scene.add(roof);
      const floors = Math.max(1, Math.round(hS / 0.6));
      for (let f = 0; f < floors; f++) {
        for (let k = 0; k < 2; k++) {
          const win = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.3, 0.04), winMat);
          win.position.set(pos.x + (k - 0.5) * wS * 0.5, pos.y + 0.35 + f * 0.6, pos.z + dS / 2 + 0.03);
          sb.scene.add(win);
        }
      }
    });
  },

  // 蓝方步兵团队：DE 优化航点路径（虚线贴地）+ 士兵 + 血条 + 攻击范围环
  _addSandboxInfantry() {
    const sb = this._sandbox, g = this._result.geometry;
    const S = sb.sx(1) - sb.sx(0);
    const range = g.infantry_range || 30;
    const infWps = this._result.infantry_waypoints || [];
    infWps.forEach((w) => {
      if (!w || w.length < 2) return;
      const pts = w.map(q => new THREE.Vector3(sb.sx(q[0]), sb.sy(this._terrainH(q[0], q[1])) + 0.3, sb.sz(q[1])));
      const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineDashedMaterial({ color: 0x2c7ab8, dashSize: 0.5, gapSize: 0.35, transparent: true, opacity: 0.7 }));
      line.computeLineDistances();
      sb.scene.add(line);
    });
    sb.frame.infantry = (g.infantry0 || []).map((p) => {
      const grp = this._makeCqbSoldier(0x2c7ab8);
      const pos = sb.P(p[0], p[1], this._terrainH(p[0], p[1]));
      grp.position.copy(pos);
      sb.scene.add(grp);
      const hp = this._makeHpBar(1.1);
      hp.grp.position.set(pos.x, pos.y + 1.7, pos.z);
      sb.scene.add(hp.grp);
      const ring = this._makeRangeRing(range * S, 0x2c7ab8);
      ring.position.set(pos.x, pos.y + 0.05, pos.z);
      sb.scene.add(ring);
      grp.userData.hpBar = hp.grp;
      grp.userData.hpFill = hp.fill;
      grp.userData.hpMax = g.infantry_hp || 100;
      grp.userData.ring = ring;
      return grp;
    });
  },

  // 红方巡逻兵：贴地机动 + 血条 + 攻击范围环（红色）+ 可视范围环（橙色，更大）
  _addSandboxPatrol() {
    const sb = this._sandbox, g = this._result.geometry;
    const S = sb.sx(1) - sb.sx(0);
    const range = g.patrol_range || 30;
    const vision = g.patrol_vision_range || (range * 2.5);
    sb.frame.patrol = (g.patrol0 || []).map((p) => {
      const grp = this._makeCqbSoldier(0xe63946);
      const pos = sb.P(p[0], p[1], this._terrainH(p[0], p[1]));
      grp.position.copy(pos);
      sb.scene.add(grp);
      const hp = this._makeHpBar(1.1);
      hp.grp.position.set(pos.x, pos.y + 1.7, pos.z);
      sb.scene.add(hp.grp);
      const ring = this._makeRangeRing(range * S, 0xe63946);
      ring.position.set(pos.x, pos.y + 0.05, pos.z);
      sb.scene.add(ring);
      // 可视范围（显眼）：半透明填充盘 + 亮色粗环，比攻击范围更大（先发现→通知同伴→靠近→攻击）
      const visionRing = this._makeVisionRange(vision * S, 0xf39c12);
      visionRing.position.set(pos.x, pos.y + 0.02, pos.z);
      sb.scene.add(visionRing);
      // 发现入侵者的头顶警示标志（闪烁动画，初始隐藏）
      const alert = this._makeAlertSprite();
      alert.position.set(pos.x, pos.y + 2.5, pos.z);
      sb.scene.add(alert);
      grp.userData.hpBar = hp.grp;
      grp.userData.hpFill = hp.fill;
      grp.userData.hpMax = g.patrol_hp || 100;
      grp.userData.ring = ring;
      grp.userData.visionRing = visionRing;
      grp.userData.alert = alert;
      return grp;
    });
  },

  _addSandboxInterceptMarkers() {
    const sb = this._sandbox, g = this._result.geometry;
    const mk = (p, color) => {
      if (!p) return;
      const pos = sb.P(p[0], p[1], this._terrainH(p[0], p[1]) + 5);
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.7, 14, 14),
        new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.5 }));
      ball.position.copy(pos);
      sb.scene.add(ball);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 3.2, 6),
        new THREE.MeshStandardMaterial({ color: 0x555555 }));
      pole.position.set(pos.x, pos.y - 1.6, pos.z);
      sb.scene.add(pole);
    };
    const starts = (g.starts && g.starts.length) ? g.starts : (g.start_pos ? [g.start_pos] : []);
    const targets = (g.targets && g.targets.length) ? g.targets : (g.target_pos ? [g.target_pos] : []);
    starts.forEach(s => mk(s, 0x00e676));
    targets.forEach(t => mk(t, 0xe63946));
    // 球形禁飞区：世界坐标下的球体 (cx,cy,cz,r)，按地形缩放比例渲染为椭球
    const hs = sb.sx(1) - sb.sx(0), vs = sb.sy(1) - sb.sy(0);
    (g.no_fly_zones || []).forEach(nf => {
      const sph = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 18),
        new THREE.MeshBasicMaterial({ color: 0xff6b6b, transparent: true, opacity: 0.16, depthWrite: false }));
      sph.position.copy(sb.P(nf[0], nf[1], nf[2]));
      sph.scale.set(nf[3] * hs, nf[3] * vs, nf[3] * hs);
      sb.scene.add(sph);
    });
    // 横向断崖岩壁：贴地形（顶部高地/底部低地，中间沿 tanh 坡过渡，非垂直矩形）
    (g.canyons || []).forEach(f => { sb.scene.add(this._buildCliffMesh(f)); });

    // 崖底河流：水平水面，填满谷底凹陷、河岸软过渡贴合地形
    if (g.rivers && g.rivers.length) sb.frame.riverflowTex = this._makeRiverTexture();
    (g.rivers || []).forEach(f => { sb.scene.add(this._buildRiverMesh(f)); });

    // 瀑布：贴崖壁曲面的竖直水幕（Shader 滚动水纹 + 软边缘）+ 崖顶跌水线 + 崖底水花
    if (g.waterfalls && g.waterfalls.length) {
      sb.frame.waterflowMats = [];
      sb.frame.waterflowTex = this._makeFlowingWaterTexture();
      const foamTex = this._makeFoamTexture();
      (g.waterfalls || []).forEach(f => {
        const x0 = f[0], y0 = f[1], x1 = f[2], y1 = f[3], hw = f[4] || 0;
        const foamGeo = new THREE.CircleGeometry(hw * 0.55 * hs, 20);
        const foamMat = new THREE.MeshBasicMaterial({ map: foamTex, color: 0xffffff, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false });
        const crestGeo = new THREE.PlaneGeometry((x1 - x0) * 0.98 * hs, hw * 0.14 * hs);
        const crestMat = new THREE.MeshBasicMaterial({ map: foamTex, color: 0xffffff, transparent: true, opacity: 0.7, side: THREE.DoubleSide, depthWrite: false });
        const cy = (y0 + y1) / 2;
        const trans = hw * 0.45, Ytop = cy + trans, Ybot = cy - trans;
        const lift = sb.zRange * 0.02;
        sb.scene.add(this._buildWaterfallMesh(f));
        // 崖底水花：沿崖脚向低地散布白色雾团，贴地形、边缘软
        for (let j = 0; j < 6; j++) {
          const u = (j + 0.5) / 6;
          const fx = x0 + (x1 - x0) * u;
          const fy = Ybot - (j % 3) * hw * 0.2;
          const foam = new THREE.Mesh(foamGeo, foamMat);
          foam.position.set(sb.sx(fx), sb.sy(this._terrainHLinear(fx, fy) + lift * 0.7), sb.sz(fy));
          foam.rotation.x = -Math.PI / 2;
          foam.scale.set(1 + (j % 2) * 0.4, 0.6 + (j % 3) * 0.15, 1);
          foam.renderOrder = 4;
          sb.scene.add(foam);
        }
        // 崖顶跌水线：白色亮条，贴崖顶地形
        const crest = new THREE.Mesh(crestGeo, crestMat);
        const ccx = (x0 + x1) / 2;
        crest.position.set(sb.sx(ccx), sb.sy(this._terrainHLinear(ccx, Ytop) + lift * 0.5), sb.sz(Ytop));
        crest.rotation.x = -Math.PI / 2;
        crest.renderOrder = 4;
        sb.scene.add(crest);
      });
    }
  },

  _updateInterceptFrame(frame) {
    const sb = this._sandbox;
    const COL = { 0: 0x00e5ff, 1: 0x00e676, 2: 0xff5252, 3: 0xaa55cc };
    const drones = frame.drones || [];
    // 本步拦截/击落/坠毁事件：触发一次性反馈动画（捕获光束 / 爆炸 / 坠落）
    if (!sb.frame.droneFx) sb.frame.droneFx = [];
    const step = frame.step || 0;
    if (step < (sb._lastFxStep || 0)) {
      // 时间轴回退（循环播放回到起点 / 拖动回放）：清空动画状态以支持重放
      (sb.frame.fx || []).forEach(f => { sb.scene.remove(f.grp); });
      sb.frame.fx = [];
      sb.frame.droneFx = [];
      sb._prevDroneViz = [];        // 同时清空俯仰参考，避免跨回退残留
      sb._lastFxStep = -1;
    }
    if (step > (sb._lastFxStep || -1)) {
      sb._lastFxStep = step;
      (frame.events || []).forEach(ev => this._spawnInterceptFx(ev, frame));
    }
    if (!sb._prevDroneViz) sb._prevDroneViz = [];
    sb.frame.drones.forEach((grp, i) => {
      const d = drones[i];
      if (!d) { grp.visible = false; return; }
      const fx = sb.frame.droneFx[i];
      // 存活：恢复（支持回放拖动）、正常渲染（含朝向 + 俯仰）
      if (d[3] === 0) {
        if (fx && fx.phase) delete sb.frame.droneFx[i];
        grp.visible = true;
        const pos = this._flyPos(d[0], d[1], d[2]);
        grp.position.copy(pos);
        this._orientQuad(grp, d[4], pos, sb._prevDroneViz[i]);
        sb._prevDroneViz[i] = pos.clone();
        this._setDroneRing(grp, 0x00e5ff);
        return;
      }
      // 突破/到达成功：绿色高亮
      if (d[3] === 1) {
        grp.visible = true;
        const pos = this._flyPos(d[0], d[1], d[2]);
        grp.position.copy(pos);
        this._orientQuad(grp, d[4], pos, sb._prevDroneViz[i]);
        sb._prevDroneViz[i] = pos.clone();
        this._setDroneRing(grp, 0x00e676);
        return;
      }
      // state=2 被拦截 / state=3 坠毁
      if (fx && fx.phase === 'falling') {
        // 坠落中：位置由 loop 里的坠落动画驱动，ring 变红/紫
        grp.visible = true;
        this._setDroneRing(grp, COL[d[3]] || 0xff5252);
      } else {
        // 已落地 / 跳帧死亡：隐藏
        grp.visible = false;
      }
    });
    const inters = frame.interceptors || [];
    sb.frame.interceptors.forEach((grp, k) => {
      const p = inters[k];
      const fan = sb.frame.inter_fans[k];
      if (!p) { grp.visible = false; if (fan) fan.visible = false; return; }
      grp.visible = true;
      const ph = (p[4] !== undefined) ? p[4] : 2;   // 直升机状态：0 停靠 1 起飞 2 巡航 3 返航 4 降落
      const pos = sb.P(p[0], p[1], p[2]);
      pos.y = this._heliVizY(p[0], p[1], p[2], ph);
      grp.position.copy(pos);
      grp.rotation.y = Math.PI / 2 - p[3];
      // 旋翼目标转速：停靠(0)=0、起飞(1)=随速度爬升、巡航/返航(2/3)=全速、降落(4)=随速度降低
      const cruiseSpeed = (this._result.geometry && this._result.geometry.interceptor_speed) || 12;
      const ratio = ph === 0 ? 0
        : (ph === 2 || ph === 3) ? 1
        : Math.max(0, Math.min(1, (p[5] !== undefined ? p[5] : 1) / cruiseSpeed));
      (grp.userData.rotors || []).forEach(r => { r.userData.target = (r.userData.base || 26) * ratio; });
      if (fan) {
        // 捕获圆锥仅在巡航拦截（phase 2）时可见
        fan.visible = ph === 2;
        if (fan.visible) {
          const fpos = sb.P(p[0], p[1], p[2] + 0.4);
          fpos.y = this._heliVizY(p[0], p[1], p[2], ph);
          fan.position.copy(fpos);
          fan.rotation.y = Math.PI / 2 - p[3];
        }
      }
    });
    const aa = frame.aa || [];
    (sb.frame.aa || []).forEach((grp, k) => {
      const p = aa[k];
      const fan = sb.frame.aa_fans[k];
      if (!p) { grp.visible = false; if (fan) fan.visible = false; return; }
      grp.visible = true;
      grp.position.copy(sb.P(p[0], p[1], p[2]));
      grp.rotation.y = Math.PI / 2 - p[3];
      if (fan) {
        fan.visible = true;
        fan.position.copy(sb.P(p[0], p[1], p[2] + 0.5));
      }
    });
    // 拦截导弹：按稳定 ID 匹配（后端 missiles = [id, x, y, z]），
    // 避免后端导弹列表压缩导致弹体索引错位（表现为「导弹飞一半消失/瞬移」）
    const missiles = frame.missiles || [];
    const mMap = sb.frame.missileMap || (sb.frame.missileMap = new Map());
    const prevPos = sb._prevMissilePos || (sb._prevMissilePos = new Map());
    const curIds = new Set();
    const TRAIL_N = 22;   // 导弹尾迹点数：展示追击飞行轨迹
    for (const p of missiles) {
      const id = p[0];
      curIds.add(id);
      let e = mMap.get(id);
      if (!e) {
        const m = this._makeMissile();
        m.userData.id = id;
        sb.scene.add(m);
        const tgeo = new THREE.BufferGeometry();
        tgeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(TRAIL_N * 3), 3));
        tgeo.setDrawRange(0, 0);
        const t = new THREE.Line(tgeo, new THREE.LineBasicMaterial({
          color: 0xffcc77, transparent: true, opacity: 0.6, depthWrite: false }));
        t.frustumCulled = false;
        t.userData.hist = [];
        sb.scene.add(t);
        e = { m, t };
        mMap.set(id, e);
        // 新导弹发射：在最近的防空车位置触发发射焰 + 烟尘，让「防空车发射导弹」可见
        const aa = frame.aa || [];
        let sx = p[1], sy = p[2], sz = p[3];
        let best = Infinity;
        for (const a of aa) {
          const dd = Math.hypot(a[0] - sx, a[1] - sy);
          if (dd < best) { best = dd; sx = a[0]; sy = a[1]; sz = a[2]; }
        }
        this._spawnLaunch(sx, sy, sz);
      }
      const m = e.m, t = e.t;
      m.visible = true;
      const mpos = sb.P(p[1], p[2], p[3]);
      mpos.y = this._flyVizY(p[1], p[2], p[3]);
      m.position.copy(mpos);
      const q = prevPos.get(id);
      if (q) {
        const dir = new THREE.Vector3(
          sb.sx(p[1]) - sb.sx(q[0]),
          this._flyVizY(p[1], p[2], p[3]) - this._flyVizY(q[0], q[1], q[2]),
          sb.sz(p[2]) - sb.sz(q[1]));
        if (dir.lengthSq() > 1e-8) {
          m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
        }
      }
      // 尾迹线：记录最近 TRAIL_N 帧位置，展示导弹追击轨迹
      t.visible = true;
      const hist = t.userData.hist;
      hist.push(mpos.x, mpos.y, mpos.z);
      if (hist.length > TRAIL_N * 3) hist.splice(0, hist.length - TRAIL_N * 3);
      const arr = t.geometry.attributes.position.array;
      for (let j = 0; j < TRAIL_N * 3; j++) arr[j] = (hist[j] !== undefined) ? hist[j] : mpos[j % 3];
      t.geometry.setDrawRange(0, Math.floor(hist.length / 3));
      t.geometry.attributes.position.needsUpdate = true;
    }
    // 移除已消失的导弹（命中/燃料耗尽/目标死亡），避免残留
    for (const [id, e] of mMap) {
      if (!curIds.has(id)) {
        e.m.visible = false;
        e.t.visible = false;
        e.t.userData.hist.length = 0;
        e.t.geometry.setDrawRange(0, 0);
        sb.scene.remove(e.m);
        sb.scene.remove(e.t);
        mMap.delete(id);
      }
    }
    // 记录本帧各导弹位置（供下一帧沿速度方向定朝向）
    prevPos.clear();
    for (const p of missiles) prevPos.set(p[0], [p[1], p[2], p[3]]);
    // 空地协同：蓝方步兵 / 红方巡逻兵 / 军事基地血量与位置更新
    const infantry = frame.infantry || [];
    (sb.frame.infantry || []).forEach((grp, i) => {
      const p = infantry[i];
      if (!p) { grp.visible = false; return; }
      const pos = sb.P(p[0], p[1], this._terrainH(p[0], p[1]));
      if (p[2] === 2) {
        // 阵亡：首次触发倒地/淡出动画，之后尸体由渲染循环接管
        if (!grp.userData.dead) this._killSoldier(sb, grp, pos);
        grp.visible = !grp.userData.deadDone;
        return;
      }
      if (grp.userData.dead || grp.userData.deadDone) this._reviveSoldier(sb, grp);
      grp.visible = true;
      grp.position.copy(pos);
      if (grp.userData.hpBar) grp.userData.hpBar.position.set(pos.x, pos.y + 1.7, pos.z);
      if (grp.userData.hpFill) {
        const ratio = Math.max(0, Math.min(1, p[3] / (grp.userData.hpMax || 1)));
        grp.userData.hpFill.scale.x = ratio;
        grp.userData.hpFill.material.color.setHex(0x2ecc71);   // 剩余血量 = 绿色
      }
      if (grp.userData.ring) {
        grp.userData.ring.position.set(pos.x, pos.y + 0.05, pos.z);
        grp.userData.ring.visible = p[2] === 0;
      }
    });
    const patrol = frame.patrol || [];
    (sb.frame.patrol || []).forEach((grp, i) => {
      const p = patrol[i];
      if (!p) { grp.visible = false; return; }
      const pos = sb.P(p[0], p[1], this._terrainH(p[0], p[1]));
      if (p[2] === 1) {
        // 阵亡：首次触发倒地/淡出动画，之后尸体由渲染循环接管
        if (!grp.userData.dead) this._killSoldier(sb, grp, pos);
        grp.visible = !grp.userData.deadDone;
        return;
      }
      if (grp.userData.dead || grp.userData.deadDone) this._reviveSoldier(sb, grp);
      grp.visible = true;
      grp.position.copy(pos);
      if (grp.userData.hpBar) grp.userData.hpBar.position.set(pos.x, pos.y + 1.7, pos.z);
      if (grp.userData.hpFill) {
        const ratio = Math.max(0, Math.min(1, p[3] / (grp.userData.hpMax || 1)));
        grp.userData.hpFill.scale.x = ratio;
        grp.userData.hpFill.material.color.setHex(0x2ecc71);   // 剩余血量 = 绿色
      }
      if (grp.userData.ring) {
        grp.userData.ring.position.set(pos.x, pos.y + 0.05, pos.z);
        grp.userData.ring.visible = p[2] === 0;
      }
      if (grp.userData.visionRing) {
        grp.userData.visionRing.position.set(pos.x, pos.y + 0.02, pos.z);
        grp.userData.visionRing.visible = p[2] === 0;
      }
      if (grp.userData.alert) {
        grp.userData.alert.position.set(pos.x, pos.y + 2.5, pos.z);
        grp.userData.alert.visible = (p[2] === 0 && p[4] === 1);
      }
    });
    const base = frame.base || [];
    let baseTxt = '';
    if (sb.frame.baseHpFill && base.length >= 2) {
      const ratio = Math.max(0, Math.min(1, base[0] / (base[1] || 1)));
      const c = ratio > 0.5 ? 0x2ecc71 : ratio > 0.25 ? 0xf1c40f : 0xe74c3c;
      sb.frame.baseHpFill.scale.x = ratio;
      sb.frame.baseHpFill.material.color.setHex(0x2ecc71);   // 剩余血量 = 绿色（红色背景 = 已扣）
      if (sb.frame.baseRing) {
        sb.frame.baseRing.material.color.setHex(c);
        sb.frame.baseRing.material.opacity = 0.15 + 0.45 * ratio;
      }
      if (sb.frame.baseGrp) sb.frame.baseGrp.visible = base[0] > 0;
      baseTxt = LASE.t(' · 基地 {0}/{1}', Math.max(0, Math.round(base[0])), Math.round(base[1]));
    }

    const nArr = drones.filter(d => d && (d[3] === 1 || d[3] === 4)).length;
    const nBomb = drones.filter(d => d && d[3] === 4).length;   // 投弹自毁
    const nLost = drones.filter(d => d && d[3] === 2).length;
    const nCrash = drones.filter(d => d && d[3] === 3).length;
    const swarm = this._result.geometry.scenario === 'swarm';
    const nInf = (frame.infantry || []).filter(p => p && p[2] === 1).length;
    const nInfDead = (frame.infantry || []).filter(p => p && p[2] === 2).length;
    const nPatDead = (frame.patrol || []).filter(p => p && p[2] === 1).length;
    document.getElementById('uav-frame-label').textContent =
      `${this._frame + 1}/${this._result.frames.length} · step=${frame.step} · ` +
      (swarm ? LASE.t('突破 {0} · 被拦截 {1}', nArr, nLost) : LASE.t('到达 {0} · 被击落 {1}', nArr, nLost)) +
      (nCrash ? LASE.t(' · 坠毁 {0}', nCrash) : '') +
      (nBomb ? LASE.t(' · 投弹自毁 {0}', nBomb) : '') +
      LASE.t(' · 共 {0}', drones.length) +
      (!swarm && frame.infantry ? LASE.t(' · 步兵到 {0}/{1}', nInf, frame.infantry.length) +
        (nInfDead ? `(-${nInfDead})` : '') +
        LASE.t(' · 击毙巡逻 {0}/{1}', nPatDead, (frame.patrol || []).length) : '') +
      baseTxt;
  },

  _updateSandboxFrame() {
    const sb = this._sandbox, frs = this._result.frames || [];
    if (!frs.length || !sb.frame) return;
    const frame = frs[Math.min(this._frame, frs.length - 1)];
    const scen = this._result.geometry.scenario;
    if (scen === 'intercept' || scen === 'swarm') {
      this._updateInterceptFrame(frame);
      return;
    }
    const cargos = frame.cargos || [];
    const COL = { 0: 0x00e5ff, 1: 0x00e676, 2: 0xff5252 };
    sb.frame.cargos.forEach((g, i) => {
      const c = cargos[i];
      if (!c) { g.visible = false; return; }
      g.visible = true;
      g.position.copy(sb.P(c[0], c[1], c[2] + 15));
      const col = COL[c[3]] || 0x00e5ff;
      g.traverse(o => { if (o.userData && o.userData.ring) { o.material.color.setHex(col); o.material.emissive.setHex(col); } });
    });
    const relays = frame.relays || [];
    sb.frame.relays.forEach((m, i) => {
      const r = relays[i];
      if (r) m.position.copy(sb.P(r[0], r[1], r[2] + 10));
    });
    const nArr = cargos.filter(c => c && c[3] === 1).length;
    document.getElementById('uav-frame-label').textContent =
      `${this._frame + 1}/${frs.length} · step=${frame.step} · ` + LASE.t('投送 {0}/{1}', nArr, cargos.length);
  },

  _terrainH(x, y) {
    // 统一双线性插值：与 _flyVizY/_heliVizY/水面/瀑布 及地形三角面（线性插值）同一基准，
    // 避免贴地实体（步兵/巡逻兵/基地/楼房/雷达/停机坪/军事设施）在斜坡上「浮空/埋地」。
    return this._terrainHLinear(x, y);
  },

  // 双线性插值的地形高度：让水面/瀑布/岩壁平滑贴合起伏地形（避免阶梯状）
  _terrainHLinear(x, y) {
    const t = this._result.geometry.terrain;
    if (!t) return 0;
    const xs = t.xs, ys = t.ys, Z = t.Z;
    const nx = xs.length, ny = ys.length;
    let j = 0; while (j < nx - 2 && xs[j + 1] < x) j++;
    let i = 0; while (i < ny - 2 && ys[i + 1] < y) i++;
    const j1 = Math.min(j + 1, nx - 1), i1 = Math.min(i + 1, ny - 1);
    let tx = (xs[j1] - xs[j]) ? (x - xs[j]) / (xs[j1] - xs[j]) : 0;
    let ty = (ys[i1] - ys[i]) ? (y - ys[i]) / (ys[i1] - ys[i]) : 0;
    tx = tx < 0 ? 0 : (tx > 1 ? 1 : tx);
    ty = ty < 0 ? 0 : (ty > 1 ? 1 : ty);
    const z00 = Z[i][j], z10 = Z[i][j1], z01 = Z[i1][j], z11 = Z[i1][j1];
    return (z00 * (1 - tx) + z10 * tx) * (1 - ty) + (z01 * (1 - tx) + z11 * tx) * ty;
  },

  // 飞行器视觉渲染高度（场景单位）：物理高度经地形垂直压缩后可能低于树木/哨塔/
  // 电线杆等景物的视觉尺寸，导致无人机「贴地穿树」；此处按「地面 + 离地高度的
  // 放大视觉映射」渲染，保证高于景物且爬升/俯冲连续可见。纯视觉修正，不改动
  // 仿真物理高度（h_clearance 等物理量不变）。
  _flyVizY(x, y, z) {
    const sb = this._sandbox;
    const ground = this._terrainHLinear(x, y);   // 双线性插值地面，避免网格台阶跳变
    const groundY = sb.sy(ground);
    const rel = Math.max(0, z - ground);         // 物理离地高度（米）
    const Hh = sb.sy(1) - sb.sy(0);              // 垂直缩放（每米 → 场景单位）
    const hClear = (this._result.geometry && this._result.geometry.h_clearance) || 30;
    const clearance = 7.0;                       // 树/电线杆最高约 7 单位
    // 自适应放大爬升：让典型离地高度 h_clearance 映射到约 1.5×树高，使爬升/俯冲在
    // 视觉上连续可见（原固定 groundY+10 制造视觉死区：离地 0~数百米视觉被钉住，
    // 突破阈值后突然「直线拉升」）。加高空上限避免极端高空飞出视野。
    const boost = Math.max(1.0, (clearance * 1.5) / Math.max(hClear * Hh, 1e-6));
    // 视觉放大上限：不得超过「最高飞行高度」天花板（max_alt 的渲染位置），
    // 否则无人机在高空会被放大渲染到天花板线框之外，看起来「飞出去了」。
    const ma = this._result.geometry && this._result.geometry.max_alt;
    const ceilingY = (ma > 0) ? sb.sy(ma) : Infinity;
    const vizRel = Math.min(rel * Hh * boost, clearance * 5.0,
                            Math.max(clearance, ceilingY - groundY));
    return Math.min(groundY + Math.max(vizRel, clearance), ceilingY);
  },

  // 飞行器场景坐标（已套用视觉净空抬升）
  _flyPos(x, y, z) {
    const p = this._sandbox.P(x, y, z);
    p.y = this._flyVizY(x, y, z);
    return p;
  },

  // 直升机拦截机视觉高度：停靠/起降阶段贴地（随离地高度平滑升降），巡航/返航阶段
  // 保留视觉净空抬升（高于树），使「起飞加速升空 / 返航降落」加减速过程连贯可见。
  _heliVizY(x, y, z, phase) {
    const sb = this._sandbox;
    const ground = this._terrainHLinear(x, y);
    const groundY = sb.sy(ground);
    const rel = Math.max(0, z - ground);
    const Hh = sb.sy(1) - sb.sy(0);
    const hClear = (this._result.geometry && this._result.geometry.h_clearance) || 30;
    // 直升机已恢复原始尺寸（heliScale = 1.0），clearance/skid 与拦截机渲染一致
    const heliScale = 1.0;
    const clearance = 7.0 * heliScale;
    const boost = Math.max(1.0, (clearance * 1.5) / Math.max(hClear * Hh, 1e-6));
    const vizRel = Math.min(rel * Hh * boost, clearance * 5.0);
    // 滑橇底部到 group 原点的距离：停靠时让滑橇精确触地（机身中心不再埋进地面）
    const skid = 0.49 * heliScale;
    // 停靠(0)/起飞(1)/降落(4)：滑橇触地并随离地高度平滑升降；巡航(2)/返航(3)：保留净空
    if (phase === 2 || phase === 3) return groundY + skid + Math.max(vizRel, clearance);
    return groundY + skid + vizRel;
  },

  // 设置四旋翼无人机环灯颜色
  _setDroneRing(grp, hex) {
    grp.traverse(o => {
      if (o.userData && o.userData.ring) { o.material.color.setHex(hex); o.material.emissive.setHex(hex); }
    });
  },

  // 无人机朝向 + 俯仰：水平按航向 head 对齐，垂直按相邻帧视觉位移计算俯仰角，
  // 使机头在爬升时自然扬起、俯冲时自然落下（带平滑，避免抖动）。
  _orientQuad(grp, head, curViz, prevViz) {
    grp.rotation.order = 'YXZ';
    grp.rotation.y = Math.PI / 2 - head;
    let pitch = grp.userData.pitch || 0;
    if (prevViz) {
      const dy = curViz.y - prevViz.y;
      const dh = Math.hypot(curViz.x - prevViz.x, curViz.z - prevViz.z);
      const target = dh > 1e-6 ? Math.atan2(dy, dh) : 0;
      const step = Math.max(-0.25, Math.min(0.25, (target - pitch) * 0.35));
      pitch += step;
    }
    grp.userData.pitch = pitch;
    grp.rotation.x = -pitch;   // 爬升(正俯仰)时绕局部横轴负转 → 机头(+Z)扬起
  },

  // 处理一帧拦截事件，触发「被拦截机捕获 / 被导弹击落 / 坠毁」反馈动画
  _spawnInterceptFx(ev, frame) {
    const sb = this._sandbox;
    if (!ev || ev.t == null) return;
    const x = ev.x, y = ev.y, z = ev.z, dIdx = ev.d;
    if (ev.t === 'missile') {
      this._spawnExplosion(x, y, z, 0xff8c1a);
      this._startDroneFall(dIdx, x, y, z);
    } else if (ev.t === 'intercept') {
      const inter = frame.interceptors && frame.interceptors[ev.s];
      const sx = inter ? inter[0] : x;
      const sy = inter ? inter[1] : y;
      const sz = inter ? inter[2] : z;
      this._spawnCaptureBeam(sx, sy, sz, x, y, z);
      this._startDroneFall(dIdx, x, y, z);
    } else if (ev.t === 'crash') {
      this._spawnExplosion(x, y, z, 0x8899aa);
      this._startDroneFall(dIdx, x, y, z);
    } else if (ev.t === 'bomb') {
      // 投弹自毁：基地受击爆炸（贴基地建筑地面），无人机直接消失（不坠落）
      this._spawnExplosion(x, y, z, 0xff3b1a, true);
    }
  },

  // 爆炸特效：火球膨胀 + 冲击环扩散 + 火花飞溅（一次性，loop 中更新淡出）
  // groundLevel=true 时贴地面（基地受击爆炸），否则按飞行器视觉净空抬升（空战爆炸）。
  _spawnExplosion(x, y, z, color, groundLevel) {
    const sb = this._sandbox;
    const grp = new THREE.Group();
    const fire = new THREE.Mesh(
      new THREE.SphereGeometry(0.6, 16, 16),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 1, depthWrite: false }));
    grp.add(fire);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.55, 0.78, 40),
      new THREE.MeshBasicMaterial({ color: 0xffd27f, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    grp.add(ring);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0xffe0a0, transparent: true, opacity: 1, depthWrite: false });
    const sparks = [];
    for (let i = 0; i < 10; i++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 6), sparkMat);
      s.userData.dir = new THREE.Vector3(
        (Math.random() - 0.5) * 2, Math.random() * 1.2, (Math.random() - 0.5) * 2).normalize();
      grp.add(s);
      sparks.push(s);
    }
    let pos;
    if (groundLevel) {
      // 贴基地建筑地面爆炸（落点在基地上空半米，不套用飞行净空抬升）
      pos = sb.P(x, y, this._terrainH(x, y));
      pos.y += 0.5;
    } else {
      pos = this._flyPos(x, y, z);
    }
    grp.position.copy(pos);
    sb.scene.add(grp);
    (sb.frame.fx = sb.frame.fx || []).push({ kind: 'explosion', grp, age: 0, dur: 1.1, fire, ring, sparks });
  },

  // 防空车导弹发射焰：向上喷射的火柱 + 火球 + 烟尘（火花方向偏上，视觉更醒目）
  _spawnLaunch(x, y, z) {
    const sb = this._sandbox;
    const grp = new THREE.Group();
    const fire = new THREE.Mesh(
      new THREE.SphereGeometry(0.85, 12, 12),
      new THREE.MeshBasicMaterial({ color: 0xfff2cc, transparent: true, opacity: 1, depthWrite: false }));
    grp.add(fire);
    // 向上喷射的火柱（细长锥，朝上）
    const jet = new THREE.Mesh(
      new THREE.ConeGeometry(0.4, 1.8, 10),
      new THREE.MeshBasicMaterial({ color: 0xffaa33, transparent: true, opacity: 0.9, depthWrite: false }));
    jet.position.y = 1.2;
    grp.add(jet);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.55, 0.85, 36),
      new THREE.MeshBasicMaterial({ color: 0x9aa0a6, transparent: true, opacity: 0.75, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    grp.add(ring);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0xffe0a0, transparent: true, opacity: 1, depthWrite: false });
    const sparks = [];
    for (let i = 0; i < 16; i++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6), sparkMat);
      s.userData.dir = new THREE.Vector3(
        (Math.random() - 0.5) * 0.6, Math.random() * 2.2 + 0.6, (Math.random() - 0.5) * 0.6).normalize();
      grp.add(s);
      sparks.push(s);
    }
    // 贴防空车车体渲染（车体在 group 原点上方约 0.5~0.8 单位），不要套飞行器视觉净空
    // 抬升（_flyPos 会把接近地面的点抬到地面+7 单位，火柱悬浮到高空）。
    grp.position.copy(sb.P(x, y, z));
    sb.scene.add(grp);
    (sb.frame.fx = sb.frame.fx || []).push({ kind: 'explosion', grp, age: 0, dur: 1.0, fire, ring, sparks, jet });
  },

  // 捕获锁定光束：拦截机 → 无人机 的红色连线（表示被拦截机捕获），短暂显示后淡出
  _spawnCaptureBeam(x1, y1, z1, x2, y2, z2) {
    const sb = this._sandbox;
    // 拦截机端用 _heliVizY（与拦截机渲染一致，含滑橇 skid 与净空），无人机端用 _flyVizY
    const a = sb.P(x1, y1, z1);
    a.y = this._heliVizY(x1, y1, z1, 2);   // 捕获发生在巡航拦截阶段
    const b = this._flyPos(x2, y2, z2);
    const geo = new THREE.BufferGeometry().setFromPoints([a, b]);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({
      color: 0xff2d2d, transparent: true, opacity: 0.95, depthWrite: false }));
    // 发光内芯
    const core = new THREE.Line(geo.clone(), new THREE.LineBasicMaterial({
      color: 0xffb0b0, transparent: true, opacity: 0.7, depthWrite: false }));
    line.add(core);
    sb.scene.add(line);
    (sb.frame.fx = sb.frame.fx || []).push({ kind: 'beam', grp: line, age: 0, dur: 0.7, line, core });
  },

  // 无人机坠落：记录状态，位置由 loop 中的坠落动画逐步下坠至地面
  _startDroneFall(dIdx, x, y, z) {
    const sb = this._sandbox;
    const fx = sb.frame.droneFx[dIdx] || (sb.frame.droneFx[dIdx] = {});
    fx.phase = 'falling';
    fx.age = 0;
    fx.vy = 0;
    fx.groundY = sb.sy(this._terrainHLinear(x, y)) + 0.5;
    const grp = sb.frame.drones && sb.frame.drones[dIdx];
    if (grp) grp.position.copy(this._flyPos(x, y, z));   // 从捕获点开始坠落
  },

  // 每帧更新拦截反馈动画：爆炸扩散 / 捕获光束淡出 / 无人机坠落（含落地烟尘）
  _updateFx(sb, dt) {
    const fxs = sb.frame.fx || (sb.frame.fx = []);
    for (let i = fxs.length - 1; i >= 0; i--) {
      const f = fxs[i];
      f.age += dt;
      const k = Math.min(1, f.age / f.dur);
      const e = 1 - k;
      if (k >= 1) {
        sb.scene.remove(f.grp);
        f.grp.traverse(o => {
          if (o.geometry) o.geometry.dispose();
          if (o.material) o.material.dispose();
        });
        fxs.splice(i, 1);
        continue;
      }
      if (f.kind === 'explosion') {
        f.fire.scale.setScalar(1 + k * 3.2);
        f.fire.material.opacity = e;
        f.ring.scale.setScalar(1 + k * 9);
        f.ring.material.opacity = 0.85 * e;
        if (f.jet) {   // 发射焰火柱：向上伸长后淡出
          f.jet.scale.set(1, 1 + k * 1.6, 1);
          f.jet.material.opacity = 0.9 * e;
        }
        f.sparks.forEach(s => {
          s.position.addScaledVector(s.userData.dir, 0.4 * dt);
          s.material.opacity = e;
        });
      } else if (f.kind === 'beam') {
        f.line.material.opacity = 0.95 * e;
        if (f.core) f.core.material.opacity = 0.7 * e;
      } else if (f.kind === 'puff') {
        f.ring.scale.setScalar(1 + k * 6);
        f.ring.material.opacity = 0.7 * e;
      }
    }
    // 无人机坠落
    const droneFx = sb.frame.droneFx;
    if (!droneFx) return;
    for (let i = 0; i < droneFx.length; i++) {
      const fx = droneFx[i];
      if (!fx || fx.phase !== 'falling') continue;
      const grp = sb.frame.drones && sb.frame.drones[i];
      fx.age += dt;
      fx.vy += 28 * dt;
      if (!grp) { fx.phase = 'down'; continue; }
      grp.position.y -= fx.vy * dt;
      grp.rotation.x += 0.07;
      grp.rotation.z += 0.05;
      if (grp.position.y <= fx.groundY) {
        grp.position.y = fx.groundY;
        fx.phase = 'down';
        grp.visible = false;
        const puff = new THREE.Mesh(
          new THREE.RingGeometry(0.5, 0.8, 32),
          new THREE.MeshBasicMaterial({ color: 0xcccccc, transparent: true, opacity: 0.7, side: THREE.DoubleSide, depthWrite: false }));
        puff.rotation.x = -Math.PI / 2;
        puff.position.set(grp.position.x, fx.groundY + 0.05, grp.position.z);
        sb.scene.add(puff);
        fxs.push({ kind: 'puff', grp: puff, age: 0, dur: 0.7, ring: puff });
      }
    }
  },

  _showDropView() {
    if (!this._result) { alert(LASE.t('请先运行仿真')); return; }
    this._closeDropView();
    const frs = this._result.frames || [];
    const nUnits = frs.length ? (frs[0].cargos || []).length : 0;
    if (!nUnits) { alert(LASE.t('无轨迹数据，请先运行仿真')); return; }
    if (this._dropIdx == null || this._dropIdx >= nUnits) this._dropIdx = 0;
    if (this._dropFrame == null || this._dropFrame >= frs.length) this._dropFrame = this._frame || 0;

    const overlay = document.createElement('div');
    overlay.id = 'uav-drop-modal';
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; ' +
      'display:flex; align-items:center; justify-content:center; padding:24px;';
    overlay.onclick = (e) => { if (e.target === overlay) this._closeDropView(); };

    const panel = document.createElement('div');
    panel.style.cssText = 'background:#fff; border-radius:12px; padding:16px; max-width:1000px; ' +
      'width:100%; box-shadow:0 12px 40px rgba(0,0,0,.3);';

    // 无人机切换按钮（按最终状态着色）
    const lastC = (frs[frs.length - 1].cargos || []);
    const DCOL = { 0: '#00e5ff', 1: '#00e676', 2: '#ff5252' };
    let segs = '';
    for (let i = 0; i < nUnits; i++) {
      const st = lastC[i] ? lastC[i][3] : 0;
      const active = i === this._dropIdx;
      segs += `<button class="btn" data-drop-idx="${i}" title="${LASE.t('运输机 U{0}', String(i + 1).padStart(2, '0'))}"` +
        ` style="padding:5px 12px;font-size:12px;${active ? `background:${DCOL[st] || '#00e5ff'};color:#111;border-color:${DCOL[st] || '#00e5ff'}` : ''}">` +
        `U${String(i + 1).padStart(2, '0')}</button>`;
    }

    panel.innerHTML =
      `<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:10px">
         <b>${LASE.t('投放视角 · 无人机物资投放微观演示')}</b>
         <span style="display:flex; gap:6px">
           <button class="btn" id="uav-drop-download">${LASE.t('下载图片')}</button>
           <button class="btn" id="uav-drop-close">${LASE.t('关闭')}</button>
         </span>
       </div>
       <div id="uav-drop-segs" style="display:flex; flex-wrap:wrap; gap:5px; margin-bottom:10px">${segs}</div>
       <canvas id="uav-drop-canvas" width="960" height="460"
         style="width:100%; height:auto; border:1px solid var(--line); border-radius:8px; background:#dbeafe"></canvas>
       <div class="row" style="margin-top:10px; gap:8px; align-items:center">
         <button class="btn" id="uav-drop-play">${LASE.t('播放')}</button>
         <input type="range" id="uav-drop-slider" min="0" max="${frs.length - 1}" value="${this._dropFrame}" style="flex:1">
         <span class="muted" id="uav-drop-frame" style="font-size:12px; white-space:nowrap"></span>
       </div>
       <div class="muted" id="uav-drop-note" style="font-size:12px; margin-top:6px"></div>`;
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    const segBox = document.getElementById('uav-drop-segs');
    segBox.onclick = (e) => {
      const b = e.target.closest('button[data-drop-idx]');
      if (!b) return;
      this._dropIdx = parseInt(b.dataset.dropIdx, 10);
      this._dropRefreshSegs();
      this._drawDropView();
    };
    document.getElementById('uav-drop-close').onclick = () => this._closeDropView();
    document.getElementById('uav-drop-download').onclick = () =>
      LASE.downloadCanvas(document.getElementById('uav-drop-canvas'), LASE.t('无人机-投放视角.png'));
    document.getElementById('uav-drop-play').onclick = () => this._toggleDropPlay();
    document.getElementById('uav-drop-slider').oninput = (e) => {
      this._dropFrame = parseInt(e.target.value, 10);
      this._drawDropView();
    };
    this._drawDropView();
  },

  _closeDropView() {
    const old = document.getElementById('uav-drop-modal');
    if (old) old.remove();
    if (this._dropAnim) { clearInterval(this._dropAnim); this._dropAnim = null; }
  },

  _toggleDropPlay() {
    const btn = document.getElementById('uav-drop-play');
    const frs = this._result.frames || [];
    if (this._dropAnim) {
      clearInterval(this._dropAnim); this._dropAnim = null;
      if (btn) btn.textContent = LASE.t('播放');
      return;
    }
    this._dropAnim = setInterval(() => {
      if (!this._result || !this._result.frames.length) { this._closeDropView(); return; }
      this._dropFrame = (this._dropFrame + 1) % this._result.frames.length;
      const sl = document.getElementById('uav-drop-slider');
      if (sl) sl.value = this._dropFrame;
      this._drawDropView();
    }, 80);
    if (btn) btn.textContent = LASE.t('暂停');
  },

  _dropRefreshSegs() {
    const box = document.getElementById('uav-drop-segs');
    if (!box) return;
    const frs = this._result.frames || [];
    const lastC = frs.length ? (frs[frs.length - 1].cargos || []) : [];
    const DCOL = { 0: '#00e5ff', 1: '#00e676', 2: '#ff5252' };
    box.querySelectorAll('button[data-drop-idx]').forEach(b => {
      const i = parseInt(b.dataset.dropIdx, 10);
      const st = lastC[i] ? lastC[i][3] : 0;
      const c = DCOL[st] || '#00e5ff';
      b.style.background = ''; b.style.color = ''; b.style.borderColor = '';
      if (i === this._dropIdx) { b.style.background = c; b.style.color = '#111'; b.style.borderColor = c; }
    });
  },

  _drawDropView() {
    const cv = document.getElementById('uav-drop-canvas');
    const note = document.getElementById('uav-drop-note');
    if (!cv) return;
    const g = this._result.geometry;
    const frs = this._result.frames || [];
    if (!frs.length) return;

    const nUnits = (frs[0].cargos || []).length;
    const idx = Math.min(this._dropIdx || 0, Math.max(0, nUnits - 1));
    const kFrame = Math.min(this._dropFrame || 0, frs.length - 1);
    const frame = frs[kFrame];
    const c = frame.cargos[idx];                       // [x, y, z, state]
    const last = frs[frs.length - 1].cargos[idx];      // 该机终点
    const base = g.base || [0, 0, 0];

    // 剖面方向固定 = 基地 → 该机终点（水平投影）
    const ex = last[0], ey = last[1];
    let dx = ex - base[0], dy = ey - base[1];
    const dl = Math.hypot(dx, dy) || 1;
    dx /= dl; dy /= dl;

    const groundZ = this._terrainH(ex, ey);
    const hoverZ = Math.max(last[2], groundZ + 25);    // 终点悬停投放高度

    // 固定逻辑分辨率（与 HTML 中 canvas 的 width/height 一致）。
    // 之前用 const W = cv.width 再乘 dpr，会把上次已放大的 bitmap 再乘一次 dpr，
    // 每次点击切机重绘就放大一档——这就是「点一下放大一次」的根因。
    const W = 960, H = 460;
    const ctx = cv.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    cv.width = W * dpr; cv.height = H * dpr;
    cv.style.width = W + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // 沿剖面采样地形（终点 ±220 m）
    const SPAN = 220, STEP = 6;
    const prof = [];
    let zmin = Infinity, zmax = -Infinity;
    for (let s = -SPAN; s <= SPAN; s += STEP) {
      const z = this._terrainH(ex + dx * s, ey + dy * s);
      prof.push([s, z]);
      if (z < zmin) zmin = z;
      if (z > zmax) zmax = z;
    }
    zmin = Math.min(zmin, groundZ) - 8;
    zmax = Math.max(zmax, hoverZ) + 32;

    const padL = 70, padR = 44, padT = 40, padB = 54;
    const X = s => padL + (s + SPAN) / (2 * SPAN) * (W - padL - padR);
    const Y = z => H - padB - (z - zmin) / (zmax - zmin) * (H - padT - padB);

    // 天空背景
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, '#dbeafe'); sky.addColorStop(1, '#eef6ff');
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);

    // 高度标尺（左侧，每 25 m）
    ctx.strokeStyle = 'rgba(0,0,0,0.12)'; ctx.fillStyle = '#667';
    ctx.font = '11px sans-serif'; ctx.textAlign = 'right';
    const z0 = Math.ceil(zmin / 25) * 25;
    for (let z = z0; z <= zmax; z += 25) {
      const y = Y(z);
      ctx.beginPath(); ctx.moveTo(padL - 4, y); ctx.lineTo(W - padR, y); ctx.stroke();
      ctx.fillText(z + 'm', padL - 8, y + 3);
    }

    // 地形剖面
    ctx.beginPath();
    ctx.moveTo(X(-SPAN), H - padB);
    prof.forEach(p => ctx.lineTo(X(p[0]), Y(p[1])));
    ctx.lineTo(X(SPAN), H - padB);
    ctx.closePath();
    const soil = ctx.createLinearGradient(0, Y(zmax), 0, H);
    soil.addColorStop(0, '#8a6d3b'); soil.addColorStop(1, '#5d4a2a');
    ctx.fillStyle = soil; ctx.fill();
    ctx.strokeStyle = '#3f3422'; ctx.lineWidth = 2;
    ctx.beginPath();
    prof.forEach((p, k) => k ? ctx.lineTo(X(p[0]), Y(p[1])) : ctx.moveTo(X(p[0]), Y(p[1])));
    ctx.stroke();

    // 受灾点（该机终点地面：帐篷 + 人群）
    const gx = X(0), gy = Y(groundZ);
    ctx.fillStyle = '#e67e22';
    ctx.beginPath(); ctx.arc(gx, gy - 4, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#c0392b';
    ctx.beginPath(); ctx.moveTo(gx - 12, gy); ctx.lineTo(gx, gy - 13); ctx.lineTo(gx + 12, gy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.fillRect(gx - 5, gy - 3, 2, 3); ctx.fillRect(gx + 3, gy - 3, 2, 3);
    ctx.fillStyle = '#c0392b';
    ctx.fillText(LASE.t('受灾点'), gx + 18, gy - 6);

    // 该机完整三维路径投影到本剖面（虚线）
    ctx.strokeStyle = 'rgba(44,95,138,0.4)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 2;
    ctx.beginPath();
    frs.forEach((fr, k) => {
      const cc = fr.cargos && fr.cargos[idx];
      if (!cc) return;
      const sx = (cc[0] - ex) * dx + (cc[1] - ey) * dy;
      const x = X(Math.max(-SPAN, Math.min(SPAN, sx)));
      const y = Y(cc[2]);
      k ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    });
    ctx.stroke(); ctx.setLineDash([]);

    // 无人机当前位置（投影 s，clamp 到剖面窗口内）
    const sNow = (c[0] - ex) * dx + (c[1] - ey) * dy;
    const sClamp = Math.max(-SPAN, Math.min(SPAN, sNow));
    const ux = X(sClamp), uy = Y(c[2]);

    // 状态颜色与货箱投放动画
    const st = last[3];
    const DCOL = { 0: '#00e5ff', 1: '#00e676', 2: '#ff5252' };
    const color = DCOL[st] || '#00e5ff';
    const t = frs.length > 1 ? kFrame / (frs.length - 1) : 1;

    // 货箱：投送成功（state=1）时机随播放进度从悬停高度下降到地面
    if (st === 1) {
      const boxZ = hoverZ - (hoverZ - groundZ) * t;
      const by = Y(boxZ);
      ctx.strokeStyle = '#555'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(ux, uy + 14); ctx.lineTo(ux, by - 6); ctx.stroke();
      ctx.fillStyle = '#b8860b'; ctx.fillRect(ux - 10, by - 12, 20, 12);
      ctx.strokeStyle = '#7a5c00'; ctx.lineWidth = 1;
      ctx.strokeRect(ux - 10, by - 12, 20, 12);
      ctx.fillStyle = '#7a5c00'; ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(LASE.t('物资'), ux, by + 1);
    }

    // 无人机四旋翼
    this._drawQuad(ctx, ux, uy, color);

    // 状态角标（右上角）
    const stText = { 0: LASE.t('飞行中'), 1: LASE.t('已投送'), 2: LASE.t('电池耗尽') }[st] || LASE.t('飞行中');
    ctx.fillStyle = color; ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'left';
    ctx.fillText('● ' + stText, W - padR - 110, padT - 12);

    // 标注
    ctx.fillStyle = '#334'; ctx.textAlign = 'left'; ctx.font = '12px sans-serif';
    ctx.fillText(LASE.t('运输机 U{0}', String(idx + 1).padStart(2, '0')), ux + 34, uy - 10);
    ctx.fillText(LASE.t('当前海拔 {0} m', Math.round(c[2])), ux + 34, uy + 6);
    ctx.fillText(LASE.t('悬停高度 ≈ {0} m（离地）', Math.round(hoverZ - groundZ)), gx + 18, gy - 40);
    ctx.fillText(LASE.t('投放点海拔 {0} m', Math.round(groundZ)), gx + 18, gy - 24);

    // 比例条
    ctx.strokeStyle = '#334'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(padL, H - 18); ctx.lineTo(padL + 100, H - 18); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(padL, H - 23); ctx.lineTo(padL, H - 13); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(padL + 100, H - 23); ctx.lineTo(padL + 100, H - 13); ctx.stroke();
    ctx.fillStyle = '#334'; ctx.fillText('100 m', padL + 34, H - 6);

    // 同步 slider 与帧标签
    const sl = document.getElementById('uav-drop-slider');
    if (sl) sl.value = kFrame;
    const fl = document.getElementById('uav-drop-frame');
    if (fl) fl.textContent = `${kFrame + 1}/${frs.length} · step=${frame.step}`;

    if (note) note.textContent =
      LASE.t('当前无人机 U{0}（最终状态：{1}）。剖面沿救灾基地 → 该机目标点连线方向，', String(idx + 1).padStart(2, '0'), stText) +
      LASE.t('展示无人机沿地形起伏飞行、在受灾点上空悬停并经吊绳将物资投放至地面的微观过程（虚线为该机完整航迹投影）。');
  },

  _drawQuad(ctx, x, y, color = '#34495e') {
    // 机身（用状态色强调，深描边）
    ctx.fillStyle = color; ctx.strokeStyle = '#1c2833'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.ellipse(x, y, 15, 7, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // 四旋翼臂 + 桨叶
    ctx.strokeStyle = '#5d6d7e'; ctx.lineWidth = 2;
    const arms = [[-13, 0], [13, 0]];
    arms.forEach(a => {
      ctx.beginPath(); ctx.moveTo(x + a[0] * 0.5, y); ctx.lineTo(x + a[0], y - a[1]); ctx.stroke();
    });
    const rotor = [[-13, 0], [13, 0]];
    rotor.forEach(r => {
      ctx.strokeStyle = 'rgba(52,73,94,0.5)'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(x + r[0] - 7, y + r[1]); ctx.lineTo(x + r[0] + 7, y + r[1]); ctx.stroke();
    });
    // 吊挂点 + 起落架
    ctx.strokeStyle = '#5d6d7e'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x - 8, y); ctx.lineTo(x - 8, y + 10); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x + 8, y); ctx.lineTo(x + 8, y + 10); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x - 8, y + 10); ctx.lineTo(x + 8, y + 10); ctx.stroke();
    ctx.fillStyle = '#f4f6f7'; ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fill();
  },

  // ---------------- 数据存档 ----------------
  _archiveSave() {
    if (!this._result) { alert(LASE.t('请先运行仿真')); return; }
    LASE.api('/api/uav/archive', { method: 'POST', body: this._result })
      .then(r => { alert(LASE.t('已存档：') + r.name); this._archiveLoad(); })
      .catch(e => alert(LASE.t('存档失败：') + (e && e.message || e)));
  },

  async _archiveLoad() {
    let data;
    try { data = await LASE.api('/api/uav/archive'); }
    catch (e) { return; }
    const groups = (data && data.groups) || [];
    this._archiveGroups = groups;
    const items = [];
    groups.forEach((g, gi) => {
      (g.items || []).forEach((it) => {
        it._g = gi;
        it._idx = items.length;
        it._config = g.config;
        items.push(it);
      });
    });
    this._archiveItems = items;
    this._archiveRender();
  },

  _archiveRender() {
    const box = document.getElementById('uav-archive-list');
    if (!box) return;
    const groups = this._archiveGroups || [];
    const items = this._archiveItems || [];
    const sel = this._archiveSelected || (this._archiveSelected = new Set());
    if (!items.length) {
      sel.clear();
      box.innerHTML = '<span class="muted">' + LASE.t('暂无存档（运行仿真后可存档，同场景同配置的算法结果会自动归档在一起以便对比）') + '</span>';
      this._archiveSyncToolbar();
      return;
    }
    const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const scenName = this._scenarioNames || {};
    const armName = a => (a === 'full' ? LASE.t('UPCL 增强') : LASE.t('纯算法'));
    const blocks = groups.map((g, gi) => {
      const cfg = g.config || {};
      const scenLabel = LASE.t(scenName[cfg.scenario] || cfg.scenario || '?');
      const gItems = items.filter(it => it._g === gi);
      const gSelCount = gItems.filter(it => sel.has(it._idx)).length;
      const rows = gItems.map((it) => {
        const label = esc(`${it.host || '?'} · ${armName(it.arm)}`);
        const ts = esc(it.timestamp || it.saved_at || '');
        const bf = typeof it.best_f === 'number' ? it.best_f.toFixed(2) : '—';
        const checked = sel.has(it._idx) ? 'checked' : '';
        return `<div class="uav-arch-row">
          <input type="checkbox" class="uav-arch-cb" data-i="${it._idx}" ${checked}>
          <div class="uav-arch-info">
            <div class="uav-arch-title">${label}</div>
            <div class="muted">${ts} · best_f=${bf} · ${it.arrived ?? 0}/${it.n_drones ?? '?'} ${LASE.t('到达')}</div>
          </div>
          <button class="btn" data-act="load" data-i="${it._idx}">${LASE.t('加载')}</button>
          <button class="btn danger" data-act="del" data-i="${it._idx}">${LASE.t('删除')}</button>
        </div>`;
      }).join('');
      return `<div class="uav-arch-group">
        <div class="uav-arch-group-head">
          <div class="uav-arch-group-title">
            <span class="tag">${esc(scenLabel)}</span>
            <b>${esc(cfg.label || ('F' + cfg.fid))}</b>
            <span class="muted">· ${LASE.t('{0} 个算法', gItems.length)}</span>
          </div>
          <button class="btn primary" data-act="compare" data-g="${gi}" ${gSelCount < 2 ? 'disabled' : ''}>${LASE.t('对比选中')}${gSelCount ? `（${gSelCount}）` : ''}</button>
        </div>
        ${rows}
      </div>`;
    }).join('');
    const allChecked = sel.size === items.length && items.length > 0;
    box.innerHTML =
      `<div class="uav-arch-toolbar">
        <label><input type="checkbox" id="uav-arch-select-all" ${allChecked ? 'checked' : ''}> ${LASE.t('全选')}</label>
        <span class="muted">${LASE.t('已选')} <b id="uav-arch-sel-count">${sel.size}</b> / ${items.length}</span>
        <span class="hint">${LASE.t('同一「地图 + 参数配置」分组内勾选 ≥2 个算法，点「对比选中」即可对比（跨组因场景不一致不能对比）')}</span>
      </div>` + blocks;
    this._archiveSyncToolbar();
  },

  _archiveClick(e) {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    if (btn.dataset.act === 'compare') {
      this._archiveCompare(parseInt(btn.dataset.g, 10));
      return;
    }
    const i = parseInt(btn.dataset.i, 10);
    const it = (this._archiveItems || [])[i];
    if (!it) return;
    if (btn.dataset.act === 'load') this._archiveLoadOne(it);
    else this._archiveDelete(it);
  },

  _archiveChange(e) {
    const items = this._archiveItems || [];
    const sel = this._archiveSelected || (this._archiveSelected = new Set());
    const t = e.target;
    if (t.id === 'uav-arch-select-all') {
      sel.clear();
      if (t.checked) items.forEach((_, i) => sel.add(i));
    } else if (t.classList.contains('uav-arch-cb')) {
      const i = parseInt(t.dataset.i, 10);
      if (t.checked) sel.add(i); else sel.delete(i);
    } else {
      return;
    }
    this._archiveRender();
  },

  _archiveQ(it) {
    return 'scenario=' + encodeURIComponent(it.scenario || '') +
      '&name=' + encodeURIComponent(it.name);
  },

  // 对比同场景同配置下的多个算法存档
  async _archiveCompare(gi) {
    const items = this._archiveItems || [];
    const sel = this._archiveSelected || new Set();
    const chosen = items.filter(it => it._g === gi && sel.has(it._idx));
    if (chosen.length < 2) { alert(LASE.t('请在同一分组内至少勾选 2 个算法结果')); return; }
    // 场景一致性校验：config_key 不一致（跨地图 / 跨参数配置）则拒绝对比
    const keys = new Set(chosen.map(it => it.config_key));
    if (keys.size > 1) { alert(LASE.t('所选结果的地图或参数配置不一致，不能对比。请只在同一分组内选择。')); return; }
    const loaded = [];
    for (const it of chosen) {
      let data;
      try { data = await LASE.api('/api/uav/archive/load?' + this._archiveQ(it)); }
      catch (err) { alert(LASE.t('加载失败：') + (err && err.message || err)); return; }
      if (!data) { alert(LASE.t('存档不存在：') + it.name); return; }
      loaded.push(data);
    }
    // 同步场景选择器（对比视图与所选存档场景一致）
    const it0 = chosen[0];
    if (it0.scenario && this._scenSel && this._scenSel.value !== it0.scenario) {
      this._scenSel.value = it0.scenario;
      this._onScenarioChange();
    }
    this._renderCompare(loaded);
  },

  _renderCompare(list) {
    this._compareMode = true;
    this._compareResults = list;
    const first = list[0];
    const g = first.geometry || {};
    const flood = this._isFloodScenario(g.scenario);
    const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const armName = a => (a === 'full' ? LASE.t('UPCL 增强') : LASE.t('纯算法'));

    // 1) 指标对比表（置于统计区，切换为块布局避免被 grid 压缩）
    const box = document.getElementById('uav-stats');
    box.style.display = 'block';
    let bestIdx = 0;
    list.forEach((r, i) => {
      const cur = list[bestIdx];
      if (typeof r.best_f === 'number' &&
          (typeof cur.best_f !== 'number' || r.best_f < cur.best_f)) bestIdx = i;
    });
    const rows = list.map((r, i) => {
      const bf = typeof r.best_f === 'number' ? r.best_f.toFixed(2) : '—';
      const arrived = (r.arrived ?? 0) + '/' + (r.n_drones ?? '?');
      const lost = r.lost ?? 0;
      const crashed = r.crashed ?? 0;
      const best = i === bestIdx ? ' best' : '';
      return `<tr class="${best}">
        <td><span class="swatch" style="background:${this._compareColor(i)}"></span>${esc(r.host || '?')} · ${esc(armName(r.arm))}</td>
        <td class="mono">${bf}</td>
        <td>${arrived}</td>
        <td>${lost}</td>
        <td>${crashed}</td>
        <td>${r.max_evals ?? '—'}</td>
      </tr>`;
    }).join('');
    box.innerHTML = `
      <div class="uav-compare-head">
        <b>${LASE.t('算法对比 · 同场景同配置（{0} 个结果）', list.length)}</b>
        <button class="btn" id="uav-compare-exit">${LASE.t('退出对比')}</button>
      </div>
      <div class="uav-compare-table">
        <table>
          <thead><tr><th>${LASE.t('算法')}</th><th>${LASE.t('目标函数值')}</th><th>${LASE.t('到达')}</th><th>${LASE.t('损失')}</th><th>${LASE.t('坠毁')}</th><th>${LASE.t('评估预算')}</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;
    const exitBtn = document.getElementById('uav-compare-exit');
    if (exitBtn) exitBtn.onclick = () => this._exitCompare();

    // 2) 收敛曲线多线叠加
    this._renderCompareConv(list, flood);
    // 3) 实景轨迹多线叠加
    this._renderCompareTrace(list);
  },

  _compareColor(i) {
    const colors = ['#2563eb', '#d97706', '#059669', '#dc2626', '#7c3aed', '#0891b2', '#db2777', '#65a30d'];
    return colors[i % colors.length];
  },

  _renderCompareConv(list, flood) {
    const series = list.map((r, i) => {
      const color = this._compareColor(i);
      const data = flood
        ? r.evals.map((e, j) => [e, r.conv[j]])
        : r.evals.map((e, j) => [e, Math.max(r.conv[j], 1e-300)]);
      return {
        name: r.host + (r.arm === 'full' ? ' · ' + LASE.t('UPCL 增强') : ''),
        type: 'line', showSymbol: false, smooth: true, data,
        lineStyle: { width: 2, color },
        itemStyle: { color },
        emphasis: { focus: 'series' },
      };
    });
    this._convChart.setOption({
      toolbox: LASE.saveToolbox(LASE.t('无人机-算法对比-收敛曲线')),
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(15, 23, 42, 0.92)',
        borderColor: '#334155', borderWidth: 1, padding: [8, 12],
        textStyle: { color: '#e2e8f0', fontSize: 12 },
        axisPointer: { lineStyle: { color: '#94a3b8' } },
      },
      legend: {
        data: series.map(s => s.name), top: 0, icon: 'roundRect',
        itemWidth: 14, itemHeight: 5, textStyle: { color: '#475569', fontSize: 11 },
      },
      grid: { left: 62, right: 24, top: 30, bottom: 40 },
      xAxis: {
        type: 'value', name: LASE.t('评估次数'),
        axisLine: { lineStyle: { color: '#cbd5e1' } },
        axisLabel: { color: '#64748b' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: '#eef2f7' } },
      },
      yAxis: {
        type: flood ? 'value' : 'log', name: LASE.t('目标值'),
        axisLine: { show: false },
        axisLabel: { color: '#64748b' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: '#eef2f7' } },
      },
      series,
    }, true);
  },

  _renderCompareTrace(list) {
    const first = list[0];
    const g = first.geometry || {};
    const flood = this._isFloodScenario(g.scenario);
    const terrain = g.terrain;

    // 地形高程背景（同配置下地图一致，取第一个结果即可）
    const heatData = [];
    let zmin = 0, zmax = 1;
    if (terrain && terrain.xs && terrain.ys && terrain.Z) {
      const xs = terrain.xs, ys = terrain.ys, Z = terrain.Z;
      for (let i = 0; i < ys.length; i++) {
        const row = Z[i];
        for (let j = 0; j < xs.length; j++) {
          const v = row ? row[j] : 0;
          if (v !== null && v !== undefined && isFinite(v)) {
            heatData.push([xs[j], ys[i], v]);
            if (heatData.length === 1) { zmin = v; zmax = v; }
            else { if (v < zmin) zmin = v; if (v > zmax) zmax = v; }
          }
        }
      }
    }

    const heatOffset = heatData.length ? 1 : 0;
    const series = [];
    if (heatData.length) {
      series.push({
        name: LASE.t('地形高程'), type: 'heatmap', data: heatData,
        silent: true, emphasis: { disabled: true },
        itemStyle: { borderWidth: 0 }, z: 1,
      });
    }
    const legendData = [];
    list.forEach((r, i) => {
      const color = this._compareColor(i);
      const name = r.host + (r.arm === 'full' ? ' · ' + LASE.t('UPCL 增强') : '');
      legendData.push(name);
      const frs = r.frames || [];
      const droneTraces = this._trackUnits(frs, flood ? 'cargos' : 'drones');
      const infTraces = flood ? [] : this._trackUnits(frs, 'infantry');
      droneTraces.forEach((pts) => {
        series.push({
          name, type: 'line', data: pts, showSymbol: false, smooth: 0.3,
          lineStyle: { width: 1.5, color, opacity: 0.85 },
          itemStyle: { color }, emphasis: { focus: 'series' }, z: 3,
        });
      });
      infTraces.forEach((pts) => {
        series.push({
          name: name + LASE.t('·步兵'), type: 'line', data: pts, showSymbol: false, smooth: 0.3,
          lineStyle: { width: 1.5, color, opacity: 0.6, type: 'dashed' },
          itemStyle: { color }, emphasis: { focus: 'series' }, z: 3,
        });
      });
    });

    // 目标 / 基地标记（取第一个结果，同配置下一致）
    const targets = [];
    if (g.base_pos) targets.push([g.base_pos[0], g.base_pos[1]]);
    else if (Array.isArray(g.base) && g.base.length >= 2) targets.push([g.base[0], g.base[1]]);
    else if (g.target_pos) targets.push([g.target_pos[0], g.target_pos[1]]);
    if (targets.length) {
      legendData.push(LASE.t('目标'));
      series.push({
        name: LASE.t('目标'), type: 'scatter', data: targets,
        symbol: 'circle', symbolSize: 16,
        itemStyle: { color: '#dc2626', borderColor: '#fff', borderWidth: 2.5,
          shadowColor: 'rgba(220, 38, 38, 0.5)', shadowBlur: 10 },
        label: { show: true, formatter: LASE.t('目标'), position: 'right', color: '#dc2626',
          fontSize: 12, fontWeight: 'bold' },
        z: 5,
      });
    }

    const option = {
      toolbox: LASE.saveToolbox(LASE.t('无人机-算法对比-轨迹')),
      tooltip: {
        trigger: 'item',
        backgroundColor: 'rgba(15, 23, 42, 0.92)',
        borderColor: '#334155', borderWidth: 1, padding: [8, 12],
        textStyle: { color: '#e2e8f0', fontSize: 12 },
        formatter: (p) => {
          if (p.seriesType === 'heatmap') return LASE.t('地形高程 ') + Number(p.value[2]).toFixed(1);
          if (p.seriesType === 'scatter') return LASE.t('目标 / 基地');
          return p.seriesName + '<br/>x ' + Number(p.value[0]).toFixed(1)
            + ' · y ' + Number(p.value[1]).toFixed(1);
        },
      },
      legend: {
        data: legendData, top: 4, left: 'center', icon: 'roundRect',
        itemWidth: 14, itemHeight: 5, itemGap: 12,
        textStyle: { color: '#475569', fontSize: 11 },
      },
      grid: { left: 54, right: 24, top: 32, bottom: 54 },
      xAxis: {
        type: 'value', name: 'x', scale: true,
        axisLine: { lineStyle: { color: '#cbd5e1' } },
        axisLabel: { color: '#94a3b8' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.18)' } },
      },
      yAxis: {
        type: 'value', name: 'y', scale: true,
        axisLine: { lineStyle: { color: '#cbd5e1' } },
        axisLabel: { color: '#94a3b8' },
        nameTextStyle: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.18)' } },
      },
      series,
    };
    if (heatData.length) {
      option.visualMap = {
        dimension: 2, min: zmin, max: zmax, calculable: false, seriesIndex: 0,
        orient: 'horizontal', left: 'center', bottom: 0,
        itemWidth: 14, itemHeight: 110,
        inRange: { color: ['#2f6b3a', '#5b8c4a', '#9bbf6a', '#c9c07a', '#b08a5a', '#8a6a4a'] },
        text: [LASE.t('高'), LASE.t('低')], textGap: 6, textStyle: { color: '#94a3b8', fontSize: 11 }, show: true,
      };
    }
    this._traceChart.setOption(option, true);
  },

  _exitCompare() {
    this._compareMode = false;
    this._compareResults = null;
    const box = document.getElementById('uav-stats');
    if (box) {
      box.style.display = '';
      box.innerHTML = '<span class="muted">' + LASE.t('运行仿真或加载存档后在此查看结果；对比视图已退出。') + '</span>';
    }
    if (this._convChart) this._convChart.clear();
    if (this._traceChart) this._traceChart.clear();
  },

  _archiveSyncToolbar() {
    const items = this._archiveItems || [];
    const sel = this._archiveSelected || new Set();
    const delSel = document.getElementById('uav-archive-del-sel');
    const clear = document.getElementById('uav-archive-clear');
    if (delSel) delSel.disabled = sel.size === 0;
    if (clear) clear.disabled = items.length === 0;
  },

  async _archiveLoadOne(it) {
    let data;
    try { data = await LASE.api('/api/uav/archive/load?' + this._archiveQ(it)); }
    catch (e) { alert(LASE.t('加载失败：') + (e && e.message || e)); return; }
    if (!data) { alert(LASE.t('存档不存在')); return; }
    // 同步场景与任务选择器（fid 已写入结果），再渲染
    if (it.scenario && this._scenSel && this._scenSel.value !== it.scenario) {
      this._scenSel.value = it.scenario;
      this._onScenarioChange();
    }
    if (it.fid && this._taskSel && this._taskSel.value !== String(it.fid)) {
      const want = String(it.fid);
      if ([...this._taskSel.options].some(o => o.value === want)) {
        this._taskSel.value = want;
        this._resetResult();
      }
    }
    this._renderResult(data);
  },

  async _archiveDelete(it) {
    if (!confirm(LASE.t('删除存档 {0} ？', it.name))) return;
    try { await LASE.api('/api/uav/archive?' + this._archiveQ(it), { method: 'DELETE' }); }
    catch (e) { alert(LASE.t('删除失败：') + (e && e.message || e)); return; }
    this._archiveLoad();
  },

  async _archiveDeleteSelected() {
    const items = this._archiveItems || [];
    const sel = this._archiveSelected || new Set();
    const targets = [...sel].map(i => items[i]).filter(Boolean);
    if (!targets.length) return;
    if (!confirm(LASE.t('删除选中的 {0} 条存档？', targets.length))) return;
    let ok = 0, fail = 0;
    for (const it of targets) {
      try {
        await LASE.api('/api/uav/archive?' + this._archiveQ(it), { method: 'DELETE' });
        ok++;
      } catch (e) { fail++; }
    }
    if (fail) alert(LASE.t('删除完成：成功 {0} 条，失败 {1} 条。', ok, fail));
    sel.clear();
    this._archiveLoad();
  },

  async _archiveClear() {
    const items = this._archiveItems || [];
    if (!items.length) return;
    if (!confirm(LASE.t('确定清空全部 {0} 条存档？此操作不可恢复。', items.length))) return;
    let ok = 0, fail = 0;
    for (const it of items) {
      try {
        await LASE.api('/api/uav/archive?' + this._archiveQ(it), { method: 'DELETE' });
        ok++;
      } catch (e) { fail++; }
    }
    if (fail) alert(LASE.t('清空完成：成功 {0} 条，失败 {1} 条。', ok, fail));
    (this._archiveSelected || new Set()).clear();
    this._archiveLoad();
  },
});

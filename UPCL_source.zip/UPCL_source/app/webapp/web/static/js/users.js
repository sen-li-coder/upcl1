/* 用户管理页（仅 admin）：创建 / 删除客户账号、重置密码 */
LASE.register('users', {
  init() {
    const c = document.getElementById('content');
    const page = LASE.el('div', { class: 'page', 'data-page': 'users' });
    page.innerHTML = `
      <div class="card">
        <div class="card-title">${LASE.t('新增账号')}</div>
        <div class="row">
          <div class="field"><label>${LASE.t('用户名')}</label><input type="text" id="usr-new-name" placeholder="${LASE.t('字母/数字/下划线/点/连字符')}"></div>
          <div class="field"><label>${LASE.t('密码（≥6 位）')}</label><input type="password" id="usr-new-pass" placeholder="${LASE.t('初始密码')}"></div>
          <div class="field"><label>${LASE.t('角色')}</label>
            <select id="usr-new-role">
              <option value="user">${LASE.t('客户（普通用户）')}</option>
              <option value="admin">${LASE.t('管理员')}</option>
            </select>
          </div>
          <button class="btn primary" id="usr-create">${LASE.t('创建账号')}</button>
          <span class="muted" id="usr-msg"></span>
        </div>
      </div>
      <div class="card">
        <div class="card-title">${LASE.t('账号列表')}</div>
        <div style="overflow:auto; max-height:600px"><table class="tbl" id="usr-tbl">
          <thead><tr><th>${LASE.t('用户名')}</th><th>${LASE.t('角色')}</th><th>${LASE.t('创建时间')}</th><th>${LASE.t('操作')}</th></tr></thead>
          <tbody></tbody>
        </table></div>
      </div>`;
    c.appendChild(page);
    this.page = page;
    document.getElementById('usr-create').onclick = () => this._create();
  },

  show() {
    this._refresh();
  },

  async _refresh() {
    const r = await LASE.api('/api/users');
    if (r._unauthorized) return;
    const tbody = document.querySelector('#usr-tbl tbody');
    tbody.innerHTML = '';
    (r.users || []).forEach(u => {
      const tr = document.createElement('tr');
      const role = u.role === 'admin' ? '<span class="tag arm">' + LASE.t('管理员') + '</span>'
        : '<span class="tag full">' + LASE.t('客户') + '</span>';
      const date = u.created_at ? new Date(u.created_at * 1000).toLocaleString() : '';
      tr.innerHTML = `<td class="mono">${LASE._esc(u.username)}</td><td>${role}</td>`
        + `<td class="muted">${date}</td><td></td>`;
      const td = tr.lastElementChild;
      if (u.username !== 'admin') {
        const del = LASE.btn(td, LASE.t('删除'), 'danger', async () => {
          if (!confirm(LASE.t('确定删除用户「{0}」？其私有数据目录将保留在磁盘上。', u.username))) return;
          const res = await LASE.api('/api/users/' + encodeURIComponent(u.username), { method: 'DELETE' });
          if (res._unauthorized) return;
          this._msg(res.ok ? LASE.t('已删除 {0}', u.username) : (res.msg || LASE.t('删除失败')), res.ok);
          this._refresh();
        });
        del.style.padding = '3px 12px'; del.style.fontSize = '12px';
        const reset = LASE.btn(td, LASE.t('重置密码'), '', () => this._reset(u.username));
        reset.style.padding = '3px 12px'; reset.style.fontSize = '12px';
      } else {
        td.innerHTML = '<span class="muted">' + LASE.t('内置管理员') + '</span>';
      }
      tbody.appendChild(tr);
    });
  },

  async _create() {
    const username = document.getElementById('usr-new-name').value.trim();
    const password = document.getElementById('usr-new-pass').value;
    const role = document.getElementById('usr-new-role').value;
    if (!username || !password) { this._msg(LASE.t('请填写用户名和密码'), false); return; }
    const r = await LASE.api('/api/users', { method: 'POST', body: { username, password, role } });
    if (r._unauthorized) return;
    if (r.ok) {
      document.getElementById('usr-new-name').value = '';
      document.getElementById('usr-new-pass').value = '';
    }
    this._msg(r.ok ? LASE.t('已创建账号 {0}', username) : (r.msg || LASE.t('创建失败')), r.ok);
    this._refresh();
  },

  async _reset(username) {
    const pwd = prompt(LASE.t('为「{0}」设置新密码（≥6 位）：', username));
    if (pwd == null) return;
    if (pwd.length < 6) { this._msg(LASE.t('密码至少 6 位'), false); return; }
    const r = await LASE.api('/api/users/' + encodeURIComponent(username) + '/reset',
      { method: 'POST', body: { password: pwd } });
    if (r._unauthorized) return;
    this._msg(r.ok ? LASE.t('已重置 {0} 的密码', username) : (r.msg || LASE.t('重置失败')), r.ok);
  },

  _msg(text, ok) {
    document.getElementById('usr-msg').innerHTML = LASE.msg(text, ok ? 'ok' : 'err');
  },
});

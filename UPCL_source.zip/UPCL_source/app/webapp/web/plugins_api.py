# -*- coding: utf-8 -*-
"""客户自定义算法（黑盒插件）的后端管理：扫描 / 创建 / 删除 / 冒烟自检。

插件以 JSON 描述文件存放在 ``<ROOT>/plugins/<name>.json``，字段：
    name       算法名（唯一，不能与内置算法重名）
    exec       可执行命令（字符串，支持 ``python xxx.py`` 或 exe 路径）
    extra_args 附加命令行参数（可选）
    timeout_s  单次运行超时秒数（可选，默认 600）
    desc       一句话机制说明（可选）
    abs        摘要（可选）
    ref        出处（可选）
"""
import json
import os
import re
import sys
from pathlib import Path

from . import constants as C
from . import workspace

PLUGINS_DIR = C.PLUGINS_DIR

# Windows 文件名非法字符 + 路径分隔符，算法名不允许出现
_NAME_FORBIDDEN = re.compile(r'[/\\:*?"<>|]')


def _plugin_dirs(user=None):
    """插件搜索目录：用户私有在前（可写），公共预置在后（只读）。"""
    dirs = []
    if user:
        dirs.append(workspace.user_plugins(user))
    dirs.append(C.PLUGINS_DIR)
    return dirs


def _builtin_names():
    """内置算法名集合（HOST_REGISTRY 中非黑盒的键）。

    注意：必须显式调用 ``de_hosts_cec.register()`` 把 CEC 扩展宿主 + wave4 变体
    合并进 ``HOST_REGISTRY``，否则这里只会返回 de_hosts 里的 6 个基础宿主，
    导致实验页算法列表不完整。
    """
    try:
        import de_hosts_cec
        de_hosts_cec.register()
        import de_hosts
        return {k for k, v in de_hosts.HOST_REGISTRY.items()
                if not getattr(v, 'is_blackbox', False)}
    except Exception:  # noqa: BLE001
        return set()


def _read(name, user=None):
    for d in _plugin_dirs(user):
        p = d / f'{name}.json'
        if not p.exists():
            continue
        try:
            data = json.loads(p.read_text(encoding='utf-8'))
            return data if isinstance(data, dict) else None
        except Exception:
            return None
    return None


def list_plugins(user=None):
    """返回当前可见的全部插件描述（用户私有优先，公共预置兜底）。"""
    seen, out = set(), []
    for d in _plugin_dirs(user):
        if not d.is_dir():
            continue
        for p in sorted(d.glob('*.json')):
            try:
                data = json.loads(p.read_text(encoding='utf-8'))
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            name = data.get('name', '')
            if name in seen:
                continue
            seen.add(name)
            out.append(_public(data))
    return out


def plugin_meta(user=None):
    """供 /api/meta 合并：{算法名: {desc, abs, ref}}，用于前端说明卡。"""
    meta = {}
    for p in list_plugins(user):
        meta[p['name']] = {
            'd': p.get('desc') or '',
            'abs': p.get('abs') or '',
            'r': p.get('ref') or '',
        }
    return meta


def available_hosts(user=None):
    """内置算法 + 当前可见插件（动态，运行中增删插件后无需重启后端）。"""
    names = sorted(_builtin_names())
    names += [p['name'] for p in list_plugins(user) if p['name'] not in names]
    return names


def _public(data):
    return {
        'name': data.get('name', ''),
        'exec': data.get('exec', ''),
        'extra_args': data.get('extra_args') or [],
        'params': data.get('params') or {},
        'timeout_s': data.get('timeout_s', 600),
        'desc': data.get('desc', ''),
        'abs': data.get('abs', ''),
        'ref': data.get('ref', ''),
        'validated': bool(data.get('validated', False)),
    }


def _coerce_value(v):
    """把字符串化的参数值还原为数字 / 布尔，否则保持字符串。"""
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    if s == '':
        return s
    low = s.lower()
    if low in ('true', 'false'):
        return low == 'true'
    if re.match(r'^-?\d+$', s):
        return int(s)
    if re.match(r'^-?(\d+\.\d*|\.\d+|\d+)([eE][-+]?\d+)?$', s):
        return float(s)
    return s


def _normalize_params(raw):
    """把前端参数规范成 {key: value}，支持 dict 或 [{k, v}] 列表两种形式。"""
    out = {}
    if isinstance(raw, dict):
        items = raw.items()
    elif isinstance(raw, (list, tuple)):
        items = []
        for it in raw:
            if isinstance(it, dict):
                items.append((it.get('k'), it.get('v')))
    else:
        return out
    for k, v in items:
        k = str(k or '').strip()
        if k:
            out[k] = _coerce_value(v)
    return out


def _writable_dir(user=None):
    return workspace.user_plugins(user) if user else C.PLUGINS_DIR


def create_plugin(payload, user=None):
    """校验并写入一个新插件描述文件（登录用户写到自己的私有目录）。"""
    name = str(payload.get('name') or '').strip()
    if not name:
        return {'ok': False, 'msg': '算法名不能为空'}
    if len(name) > 64:
        return {'ok': False, 'msg': '算法名过长（>64 字符）'}
    if _NAME_FORBIDDEN.search(name):
        return {'ok': False, 'msg': '算法名不能包含 / \\ : * ? " < > | 等字符'}
    if '__' in name:
        return {'ok': False, 'msg': '算法名不能包含双下划线 __'}
    if name in _builtin_names():
        return {'ok': False, 'msg': f'「{name}」与内置算法重名，请换个名称'}
    if not str(payload.get('exec') or '').strip():
        return {'ok': False, 'msg': '请填写可执行命令（exec）'}

    data = {
        'name': name,
        'exec': str(payload.get('exec')).strip(),
        'extra_args': [str(x) for x in (payload.get('extra_args') or [])],
        'params': _normalize_params(payload.get('params')),
        'timeout_s': float(payload.get('timeout_s') or 600),
        'desc': str(payload.get('desc') or '').strip(),
        'abs': str(payload.get('abs') or '').strip(),
        'ref': str(payload.get('ref') or '').strip(),
        'validated': False,
    }
    d = _writable_dir(user)
    d.mkdir(parents=True, exist_ok=True)
    path = d / f'{name}.json'
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                   encoding='utf-8')
    tmp.replace(path)
    return {'ok': True, 'name': name}


def save_upload(name, filename, content, user=None):
    """保存客户上传的可执行文件到用户私有 plugins/<name>/，返回 exec 命令。

    客户不必知道可执行命令：向导里点按钮选择 .exe（或 .py），这里自动落盘并
    生成相对路径命令，随后回填到向导的 exec 输入框。
    """
    name = str(name or '').strip()
    if not name:
        return {'ok': False, 'msg': '请先填写算法名称'}
    if len(name) > 64:
        return {'ok': False, 'msg': '算法名过长（>64 字符）'}
    if _NAME_FORBIDDEN.search(name) or '__' in name:
        return {'ok': False, 'msg': '算法名含非法字符，请先修正名称'}
    safe = os.path.basename(str(filename or '').replace('\\', '/'))
    if not safe or '.' not in safe:
        return {'ok': False, 'msg': '文件名为空'}
    ext = os.path.splitext(safe)[1].lower()
    if ext not in ('.exe', '.bat', '.cmd', '.com', '.py'):
        return {'ok': False, 'msg': '请上传 .exe（或 .py）可执行文件'}
    d = _writable_dir(user) / name
    d.mkdir(parents=True, exist_ok=True)
    dest = d / safe
    dest.write_bytes(content)
    if ext == '.py':
        exec_cmd = f'python {name}/{safe}'
    else:
        exec_cmd = f'{name}/{safe}'
    return {'ok': True, 'name': name, 'filename': safe, 'exec': exec_cmd}


def delete_plugin(name, user=None):
    name = str(name or '').strip()
    d = _writable_dir(user)
    p = d / f'{name}.json'
    if not p.exists():
        return {'ok': False, 'msg': f'插件「{name}」不存在'}
    p.unlink()
    return {'ok': True}


def smoke_test(name, user=None):
    """对某个插件跑一次真实 CEC 函数自检（cec2022 D10 F1，1000 次评估）。"""
    try:
        from blackbox_host import smoke_test as _smoke
        pd = str(workspace.user_plugins(user)) if user else None
        return _smoke(name, plugins_dir=pd)
    except Exception as exc:  # noqa: BLE001
        return {'ok': False, 'msg': f'自检异常：{exc!r}'}

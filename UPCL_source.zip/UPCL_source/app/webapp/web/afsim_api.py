# -*- coding: utf-8 -*-
"""AFSIM 2.9 高保真复核后端。

把 UAV 页存档里的一局解（``results/apps/raw/uav_intercept/D30``）重新送进真实
``mission.exe`` 运行，回传遥测 / 事件 / 三列对比（LASE 原始、LASE 无遮挡、AFSIM）。
"""
import json
import math
import re
import subprocess
import threading
import time
from pathlib import Path

from . import constants as C

import afsim_bridge as AB                      # SRC 已由 constants 注入 sys.path

_LOCK = threading.Lock()
_CACHE = {}
_ENGINE = AB.AfsimEngine()

TASK_NAMES = {
    1: '基线突防',
    2: '禁飞区绕行',
    3: '双机拦截',
    4: '强拦截对抗',
}


def case_root() -> Path:
    """Web 侧优先用镜像数据根，缺失时回落到仓库根。"""
    for cand in (C.ROOT / 'results' / 'apps' / 'raw' / 'uav_intercept' / 'D30',
                 AB.DEFAULT_CASE_ROOT):
        if cand.is_dir():
            return cand
    return AB.DEFAULT_CASE_ROOT


def _cache_key(host, fid, run, arm):
    return '%s|%d|%d|%s' % (host, int(fid), int(run), arm)


def meta() -> dict:
    info = _ENGINE.info()
    cases = AB.list_cases(case_root())
    hosts = sorted({c['host'] for c in cases})
    tasks = [{'fid': k, 'name': v} for k, v in sorted(TASK_NAMES.items())]
    default_host = 'CoBiDE' if 'CoBiDE' in hosts else (hosts[0] if hosts else '')
    return {
        'ready': bool(info.get('available')),
        'engine': info,
        'cases': cases,
        'hosts': hosts,
        'tasks': tasks,
        'n_cases': len(cases),
        'defaults': {'host': default_host, 'fid': 1, 'run': 0, 'arm': 'full'},
        'not_modeled': list(AB.NOT_MODELED),
        'notes': {
            'rule': '探测/攻击判定沿用 LASE 的二维水平距离 + 垂直锥公式，写在 AFSIM 脚本处理器里；'
                    '武器用 AFSIM 隐式武器 + 球形杀伤（半径 = missile_radius）。',
            'difference': 'AFSIM 隐式武器是理想拦截（无导弹转弯/燃料/脱靶），且平坦地面没有山体遮挡，'
                          '因此比 LASE 原始口径更强；对比表另给「LASE 无遮挡」同假设臂用于判读桥接忠实度。',
            'terrain': '三维合成山地、楼房掩体、20 名巡逻兵的地面交火与基地轰炸未建模。',
        },
        'cache_size': len(_CACHE),
    }


_SCN_CACHE = {}


def scenario(fid: int = 1) -> dict:
    """当前想定说明（按任务号）：战场 / 蓝方 / 红方 / 判定 / 决策变量 / 目标函数。

    数值全部来自 ``uav_adversarial._intercept_cfg(fid)``，即 LASE 第五章
    intercept 场景的真实 ``EnvConfig``，因此页面上的说明不会与仿真参数漂移。
    """
    fid = int(fid)
    hit = _SCN_CACHE.get(fid)
    if hit is not None:
        return hit
    problem = AB._lase_problem(fid, 0)
    cfg = problem.env.cfg
    dt = float(cfg.dt)
    steps = int(cfg.n_steps)
    zones = [[float(v) for v in z] for z in (cfg.no_fly_zones or [])]
    heli = [[float(p[0]), float(p[1])] for p in (cfg.interceptor_pos or [])]
    terms = [
        ('arrive', '+', cfg.w_arrive, '每架无人机到达目标区'),
        ('lost', '-', cfg.w_lost, '每架无人机被拦截击落'),
        ('crash', '-', cfg.w_crash, '每架无人机能源耗尽坠毁'),
        ('time', '-', cfg.w_time, '每架无人机超时未完成'),
        ('nofly', '-', cfg.w_nofly, '每步处于禁飞区（按步累计）'),
        ('bounds', '-', cfg.w_bounds, '每步越出战场边界（按步累计）'),
        ('collision', '-', cfg.w_collision, '每发生一次机间碰撞'),
        ('path', '-', cfg.w_path, '绕行惩罚 (航程 / 直线距离 − 1)'),
        ('climb', '-', cfg.w_climb, '爬山能耗 (总爬升 / 典型山高)'),
        ('safety', '+', cfg.w_safety, '安全裕度 (与拦截者最小距离 / 4R)'),
        ('base', '+', cfg.w_base, '基地轰炸进度 (1 − 剩余血量 / 满血)'),
        ('inf_arrive', '+', cfg.w_inf_arrive, '每名步兵抵达基地'),
        ('inf_lost', '-', cfg.w_inf_lost, '每名步兵阵亡'),
        ('patrol_kill', '+', cfg.w_patrol_kill, '每击杀一名巡逻兵'),
        ('success', '+', cfg.w_success, '整体成功（基地血量归零）'),
    ]
    data = {
        'fid': fid,
        'task': TASK_NAMES.get(fid, 'F%d' % fid),
        'scenario_name': 'intercept（LASE 第五章实景突防）',
        'map': {
            'w': float(cfg.map_w), 'h': float(cfg.map_h),
            'start': [float(cfg.start_pos[0]), float(cfg.start_pos[1])],
            'target': [float(cfg.target_pos[0]), float(cfg.target_pos[1])],
            'target_r': float(cfg.target_radius),
            'terrain': bool(cfg.terrain_enabled),
            'terrain_amp': float(cfg.terrain_amplitude),
        },
        'time': {'dt': dt, 'steps': steps, 'seconds': dt * steps},
        'blue': {
            'uav': {'n': int(cfg.n_drones), 'speed': float(cfg.drone_speed) / dt,
                    'turn': float(cfg.drone_turn_rate) / dt,
                    'alt_max': float(cfg.max_alt),
                    'climb': float(cfg.max_climb_rate) / dt,
                    'energy': float(cfg.energy_capacity),
                    'cost_step': float(cfg.energy_per_step),
                    'waypoints': int(cfg.n_waypoints),
                    'reach_r': float(cfg.wp_reach_radius)},
            'inf': {'n': int(cfg.n_infantry), 'speed': float(cfg.infantry_speed) / dt,
                    'hp': float(cfg.infantry_hp),
                    'range': float(cfg.infantry_range),
                    'waypoints': int(cfg.n_waypoints)},
        },
        'red': {
            'aa': {'n': int(cfg.n_aa),
                   'pos': [[float(p[0]), float(p[1])] for p in cfg.aa_pos],
                   'range': float(cfg.aa_range),
                   'vert_deg': math.degrees(float(cfg.aa_vert_half_angle)),
                   'reload_s': float(cfg.aa_reload) * dt,
                   'missile_speed': float(cfg.missile_speed) / dt,
                   'missile_r': float(cfg.missile_radius),
                   'missile_fuel': int(cfg.missile_fuel)},
            'heli': {'n': len(heli), 'pos': heli,
                     'speed': float(cfg.interceptor_speed) / dt,
                     'catch_r': float(cfg.intercept_radius),
                     'cone_h_deg': math.degrees(float(cfg.intercept_half_angle)),
                     'cone_v_deg': math.degrees(float(cfg.intercept_vert_half_angle))},
            'radar': {'pos': [float(cfg.radar_pos[0]), float(cfg.radar_pos[1])],
                      'range': float(cfg.radar_range),
                      'alert': int(cfg.alert_threshold)},
            'nfz': {'n': len(zones), 'zones': zones},
            'patrol': {'n': int(cfg.n_patrol),
                       'speed': float(cfg.patrol_speed) / dt,
                       'vision': float(cfg.patrol_vision_range),
                       'range': float(cfg.patrol_range)},
            'base': {'hp': float(cfg.base_hp), 'r': float(cfg.base_radius),
                     'bomb': float(cfg.bomb_damage),
                     'bld': int(getattr(cfg, 'n_buildings', 0))},
        },
        'judge': {
            'arrive_r': float(cfg.target_radius),
            'catch_r': float(cfg.intercept_radius),
            'collision_r': float(cfg.collision_radius),
            'seconds': dt * steps,
        },
        'decision': {
            'dim': int(cfg.dim),
            'encoding': '[-1, 1]^%d' % int(cfg.dim),
            'blocks': [
                {'key': 'uav_wp', 'n': int(cfg.n_drones * cfg.n_waypoints * 3),
                 'per_unit': int(cfg.n_waypoints), 'axis': 3},
                {'key': 'inf_wp', 'n': int(cfg.n_infantry * cfg.n_waypoints * 2),
                 'per_unit': int(cfg.n_waypoints), 'axis': 2},
            ],
            'map_w': float(cfg.map_w), 'map_h': float(cfg.map_h),
            'max_alt_offset': float(cfg.max_alt_offset),
            'h_clearance': float(cfg.h_clearance),
            'fixed': '起点 / 目标点 / 红方部署固定，只有中途航点由算法决定',
        },
        'objective': {
            'sense': 'min',
            'expr': 'cost = −reward',
            'terms': [{'key': k, 'sign': s, 'w': float(w), 'label': zh}
                      for k, s, w, zh in terms],
            'note': '目标函数只在 LASE 侧可算；AFSIM 侧没有基地血量 / 巡逻兵 / '
                    '地形遮挡，因此只回映 6 项几何与毁伤指标，不能重算 cost。',
        },
        'afsim_scope': {
            'modeled': [
                'WSF_AIR_MOVER / WSF_GROUND_MOVER：平台按航路点飞行（含转弯率、爬升率）',
                'WSF_GEOMETRIC_SENSOR + WSF_SCRIPT_PROCESSOR：探测与开火判定'
                '（水平距离 + 垂直锥，与 LASE 同一公式）',
                'WSF_IMPLICIT_WEAPON + WSF_SPHERICAL_LETHALITY：发射与球形杀伤',
                '引擎自身时间推进、事件记录（events.evt）与逐帧遥测（TL 行）',
            ],
            'not_modeled': list(AB.NOT_MODELED),
        },
        'env_note': '这里的 AFSIM 想定由本页按 LASE EnvConfig 现场生成（WSF 文本），'
                    '不是 AFSIM 官方样例想定；同一份决策向量进入引擎，飞行与毁伤由 '
                    'mission.exe 计算。',
    }
    _SCN_CACHE[fid] = data
    return data


def _clip_events(events, limit=240):
    if len(events) <= limit:
        return events
    head = events[:limit]
    return head + [{'t': None, 'event': '...', 'subject': '共 %d 条，已截断' % len(events),
                    'target': ''}]


def run(host: str, fid: int = 1, run: int = 0, arm: str = 'full',
        refresh: bool = False) -> dict:
    """跑一局复核；同参数重复请求走内存缓存（产物仍落盘）。"""
    arm = str(arm or 'full')
    if arm not in ('bare', 'full'):
        raise ValueError('arm 只能是 bare / full')
    key = _cache_key(host, fid, run, arm)
    if not refresh:
        with _LOCK:
            hit = _CACHE.get(key)
        if hit is not None:
            out = dict(hit)
            out['cached'] = True
            return out

    case = AB.load_case(host, fid=fid, run=run, arm=arm, results_root=case_root())
    label = '%s_F%d_run%d_%s' % (case['host'], case['fid'], case['run'], arm)
    res = AB.run_case(case['best_x'], fid=case['fid'], seed=case['seed'],
                      work_dir=AB.DEFAULT_OUT_ROOT / label, engine=_ENGINE,
                      case_label=label, timeout=600.0)
    res['cached'] = False
    res['case_info'] = {
        'host': case['host'],
        'fid': case['fid'],
        'task': TASK_NAMES.get(case['fid'], ''),
        'run': case['run'],
        'arm': arm,
        'seed': case['seed'],
        'err_final': case['err_final'],
        'max_evals': case['max_evals'],
        'file': str(case['file']),
    }
    res['events'] = _clip_events(res.get('events') or [])
    with _LOCK:
        _CACHE[key] = res
    return res


def artefact(host: str, fid: int, run: int, arm: str, name: str,
             label: str = '') -> Path:
    """产物下载：只允许白名单文件名，路径锁在 afsim_check/<case>/ 内。

    ``label`` 用于在线训练产物（目录名形如 ``train_CoBiDE_F1_e2000_s1``），
    不传则按存档用例的 ``<host>_F<fid>_run<run>_<arm>`` 拼。
    """
    allowed = {'afsim_check.json': 'afsim_check.json',
               'input.txt': 'input.txt',
               'mission.log': 'mission.log',
               'events.evt': 'out/events.evt',
               'warlock.txt': 'warlock.txt'}
    if name not in allowed:
        raise ValueError('不允许的文件：%s' % name)
    if label:
        if not re.fullmatch(r'[A-Za-z0-9_.\-]{1,80}', label):
            raise ValueError('非法目录名：%s' % label)
    else:
        label = '%s_F%d_run%d_%s' % (host, int(fid), int(run), str(arm))
    path = (AB.DEFAULT_OUT_ROOT / label / allowed[name]).resolve()
    base = AB.DEFAULT_OUT_ROOT.resolve()
    if base not in path.parents or not path.is_file():
        raise FileNotFoundError(name)
    return path


def summary(host: str, fid: int, run: int, arm: str) -> dict:
    """轻量摘要（不返回遥测），用于列表/徽章。"""
    label = '%s_F%d_run%d_%s' % (host, int(fid), int(run), str(arm))
    blob = AB.DEFAULT_OUT_ROOT / label / 'afsim_check.json'
    if not blob.is_file():
        raise FileNotFoundError(str(blob))
    data = json.loads(blob.read_text(encoding='utf-8'))
    return {k: data.get(k) for k in ('ok', 'metrics', 'lase', 'lase_flat',
                                     'comparison', 'case_info', 'wall_time_s')}


# ---------------------------------------------------------------------------
# 在线训练：选算法 → 真实 DE 优化（LASE 仿真当适应度）→ 周期 AFSIM 复核
# ---------------------------------------------------------------------------
_ENGINE_LOCK = threading.Lock()
_CK_FRACS = (1 / 6, 2 / 6, 3 / 6, 4 / 6, 5 / 6, 1.0)
TRAIN_MIN_EVALS = 120
TRAIN_MAX_EVALS = 60000


def available_hosts():
    """在线训练可选算法 = 平台真实宿主池（29 个 DE 变体）。"""
    import de_hosts_cec as DHC

    return list(DHC.CEC_HOST_ORDER)


def _plain(obj):
    """把 numpy 标量 / 非有限浮点数归一成可 JSON 化对象。"""
    import numpy as np

    if obj is None or isinstance(obj, (bool, int, str)):
        return obj
    if isinstance(obj, dict):
        return {str(k): _plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_plain(v) for v in obj]
    if isinstance(obj, (np.floating, float)):
        v = float(obj)
        return v if math.isfinite(v) else None
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    return obj


def train(host: str, fid: int = 1, evals: int = 2000, seed: int = 20261018,
          progress_cb=None, live_cb=None, cancel_event=None) -> dict:
    """在后台线程里真实跑一次 DE 训练，并把训练过程的解送进 AFSIM 复核。

    与 ``run`` 的区别：``run`` 只是「把已有存档解重放一遍」，这里是从零开始优化 ——
    每一代都用 LASE 的 intercept 仿真（15 项代价）评估候选航点，每花掉 1/6 预算就把
    当前最优解送进 ``mission.exe`` 跑一次真实引擎（检查点），训练结束再把最终解完整
    复核一遍（含三列对比与遥测），前端据此画进度条 / 收敛曲线 / 检查点表并接管俯视图。
    """
    import time

    import numpy as np

    import de_hosts
    import de_hosts_cec as DHC

    host = str(host)
    fid = int(fid)
    evals = int(evals)
    seed = int(seed)
    if evals < TRAIN_MIN_EVALS or evals > TRAIN_MAX_EVALS:
        raise ValueError('评估预算需在 %d ~ %d 之间' % (TRAIN_MIN_EVALS, TRAIN_MAX_EVALS))

    t0 = time.perf_counter()
    if progress_cb is not None:
        progress_cb(0.01, '构造 F%d 优化问题…' % fid)
    problem = AB._lase_problem(fid, seed)
    if progress_cb is not None:
        progress_cb(0.03, '初始化 %s（%d 维，种群 %d）…' % (host, int(problem.dim),
                                                      int(DHC.pop_size_for(host, int(problem.dim)))))
    dim = int(problem.dim)
    pop = int(DHC.pop_size_for(host, dim))
    opt = de_hosts.get_host(host, dim, problem.lb, problem.ub,
                            seed=seed, pop_size=pop)

    curve = []
    checkpoints = []
    ck_next = [0]
    ck_dir = AB.DEFAULT_OUT_ROOT / ('train_%s_F%d_ck' % (host, fid))
    state = {'nevals': 0, 'best': None, 'gen': 0}

    def _emit(**kw):
        if live_cb is not None:
            try:
                live_cb({k: _plain(v) for k, v in kw.items()})
            except Exception:                     # noqa: BLE001 (前端断开不影响训练)
                pass

    def _afsim_check(x, work_dir, keep, tag):
        with _ENGINE_LOCK:
            return AB.run_case(x, fid=fid, seed=seed, problem=problem,
                               work_dir=work_dir, engine=_ENGINE,
                               case_label=tag, timeout=600.0,
                               compare=False, keep=keep)

    def _cb(h):
        if cancel_event is not None and cancel_event.is_set():
            raise RuntimeError('cancelled')
        n = int(h.nevals)
        best = float(h.best_so_far)
        state['nevals'], state['best'] = n, best
        state['gen'] = int(getattr(h, 'g', 0)) or state['gen'] + 1
        curve.append([n, best])
        _emit(nevals=n, best=best, gen=state['gen'], budget=evals,
              curve=curve, progress=min(0.82, 0.82 * n / max(evals, 1)))
        if progress_cb is not None:
            progress_cb(min(0.82, 0.82 * n / max(evals, 1)),
                        '训练中 %d/%d · 最优代价 %.2f' % (n, evals, best))
        # 每花掉 1/6 预算，把当前最优解送进真实引擎看一眼（每次回调最多一次，
        # 预算很小时相邻检查点会落在同一代，跳过的档位直接丢弃，避免重复跑同一个解）
        if ck_next[0] < len(_CK_FRACS) and n >= evals * _CK_FRACS[ck_next[0]] - 1e-9:
            x = np.asarray(h.pop[int(h.best_idx)], dtype=float)
            try:
                res = _afsim_check(x, ck_dir, keep=False,
                                   tag='train_%s_F%d_ck%d' % (host, fid, ck_next[0] + 1))
                m = res.get('metrics') or {}
                ck = {'evals': n, 'gen': state['gen'], 'cost': best,
                      'ok': bool(res.get('ok')),
                      'n_arrived': m.get('n_arrived'), 'n_lost': m.get('n_lost'),
                      'n_fired': m.get('n_fired'), 'n_hit': m.get('n_hit'),
                      'wall_s': float(res.get('wall_time_s') or 0.0)}
            except Exception as exc:              # noqa: BLE001
                ck = {'evals': n, 'gen': state['gen'], 'cost': best, 'ok': False,
                      'error': str(exc), 'wall_s': 0.0}
            checkpoints.append(ck)
            while (ck_next[0] < len(_CK_FRACS)
                   and n >= evals * _CK_FRACS[ck_next[0]] - 1e-9):
                ck_next[0] += 1
            _emit(checkpoints=checkpoints)
            if progress_cb is not None:
                progress_cb(min(0.86, 0.82 * n / max(evals, 1) + 0.01),
                            '检查点 %d：AFSIM 到达 %s / 损失 %s'
                            % (len(checkpoints), ck.get('n_arrived'), ck.get('n_lost')))

    best_f, best_x, _conv, _ev = opt.run(problem, evals, callback=_cb)
    best_x = np.asarray(best_x, dtype=float).ravel()
    opt_wall = time.perf_counter() - t0

    if progress_cb is not None:
        progress_cb(0.88, '把最终解送进 AFSIM 复核…')

    label = 'train_%s_F%d_e%d_s%d' % (host, fid, evals, seed)
    with _ENGINE_LOCK:
        final = AB.run_case(best_x, fid=fid, seed=seed, problem=problem,
                            work_dir=AB.DEFAULT_OUT_ROOT / label, engine=_ENGINE,
                            case_label=label, timeout=600.0, compare=True)
    final['events'] = _clip_events(final.get('events') or [])

    cost, _state, metrics = problem.evaluate(best_x)
    if progress_cb is not None:
        progress_cb(1.0, '训练完成')

    first = curve[0][1] if curve else None
    out = {
        'ok': True,
        'host': host, 'fid': fid, 'task': TASK_NAMES.get(fid, 'F%d' % fid),
        'seed': seed, 'budget': evals,
        'used_evals': int(np.asarray(_ev).ravel()[-1]) if len(_ev) else int(evals),
        'dim': dim, 'pop_size': pop,
        'cost_first': None if first is None else float(first),
        'cost_best': float(best_f),
        'lase_cost': _plain(cost),
        'lase_metrics': _plain(metrics),
        'curve': _plain(curve),
        'checkpoints': _plain(checkpoints),
        'afsim': final,
        'label': label,
        'best_x': _plain([float(v) for v in best_x]),
        'wall_time_s': round(time.perf_counter() - t0, 2),
        'opt_wall_s': round(opt_wall, 2),
        'note': '适应度函数是 LASE 的 intercept 仿真（15 项代价）；AFSIM 只负责复核与'
                '检查点抽查，不参与选择，因此曲线上的代价与引擎指标可能不同源。',
    }
    # 结果落盘：曲线 / 检查点 / 最优决策向量 / 引擎指标都存下来，
    # 事后可原样回放，也可以直接生成 warlock 想定在官方 GUI 里演示。
    out['saved_to'] = _save_train_result(out)
    return out


# ---------------------------------------------------------------------------
# 训练结果持久化 / 回放 / 在真实 AFSIM（Warlock）中演示
# ---------------------------------------------------------------------------
_LABEL_RE = re.compile(r'[A-Za-z0-9_.\-]{1,80}')
_WL_BLOCK = (b'\r\n\r\n# --- Warlock / Mystic replay ---\r\n\r\n'
             b'event_pipe\r\n   file out/replay.aer\r\n   use_preset default\r\n'
             b'end_event_pipe\r\n')
TRAIN_SCHEMA = 'lase/afsim-train@1'


def _label_dir(label: str) -> Path:
    """把目录名解析成 ``afsim_check/`` 下的真实用例目录（拒绝路径穿越）。"""
    name = str(label or '')
    if not _LABEL_RE.fullmatch(name):
        raise ValueError('非法目录名：%s' % name)
    base = AB.DEFAULT_OUT_ROOT.resolve()
    path = (base / name).resolve()
    if base not in path.parents or not path.is_dir():
        raise FileNotFoundError(name)
    return path


def _save_train_result(payload: dict) -> str:
    """把一次训练写进 ``<用例目录>/train_result.json``（遥测仍留在 afsim_check.json）。"""
    label = str(payload.get('label') or '')
    if not label:
        return ''
    d = AB.DEFAULT_OUT_ROOT / label
    try:
        d.mkdir(parents=True, exist_ok=True)
        blob = {k: v for k, v in payload.items() if k != 'afsim'}
        afs = dict(payload.get('afsim') or {})
        afs.pop('telemetry', None)                 # 避免与 afsim_check.json 重复
        blob['afsim'] = afs
        blob['schema'] = TRAIN_SCHEMA
        blob['saved_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
        f = d / 'train_result.json'
        f.write_text(json.dumps(_plain(blob), ensure_ascii=False, indent=1),
                     encoding='utf-8', newline='\n')
        return str(f)
    except OSError as exc:                         # 存不下不影响本次训练结果
        return 'save_error: %s' % exc


def train_runs() -> dict:
    """列出已保存的训练结果（按保存时间倒序）。"""
    items = []
    base = AB.DEFAULT_OUT_ROOT
    if base.is_dir():
        for d in sorted(base.glob('train_*')):
            f = d / 'train_result.json'
            if not f.is_file():
                continue
            try:
                blob = json.loads(f.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                continue
            m = ((blob.get('afsim') or {}).get('metrics') or {})
            st = f.stat()
            items.append({
                'label': blob.get('label') or d.name,
                'host': blob.get('host'),
                'fid': blob.get('fid'),
                'task': blob.get('task'),
                'seed': blob.get('seed'),
                'budget': blob.get('budget'),
                'used_evals': blob.get('used_evals'),
                'cost_first': blob.get('cost_first'),
                'cost_best': blob.get('cost_best'),
                'n_arrived': m.get('n_arrived'),
                'n_lost': m.get('n_lost'),
                'dim': blob.get('dim'),
                'pop_size': blob.get('pop_size'),
                'wall_time_s': blob.get('wall_time_s'),
                'saved_at': blob.get('saved_at'),
                'mtime': int(st.st_mtime),
                'bytes': st.st_size,
                'has_warlock': (d / 'warlock.txt').is_file(),
            })
    items.sort(key=lambda r: -(r.get('mtime') or 0))
    return {'ok': True, 'n': len(items), 'runs': items}


def train_result(label: str) -> dict:
    """读回一次已保存的训练（曲线 / 检查点 / 最优解 / 引擎遥测），供页面直接回放。"""
    d = _label_dir(label)
    f = d / 'train_result.json'
    if not f.is_file():
        raise FileNotFoundError('train_result.json')
    blob = json.loads(f.read_text(encoding='utf-8'))
    # 遥测与三列对比存在 afsim_check.json 里，优先用它（画俯视图需要 telemetry）
    ck = d / 'afsim_check.json'
    if ck.is_file():
        try:
            full = json.loads(ck.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            full = None
        if isinstance(full, dict) and full.get('ok'):
            full['events'] = _clip_events(full.get('events') or [])
            blob['afsim'] = full
    blob['ok'] = True
    blob['reloaded'] = True
    blob['label'] = blob.get('label') or d.name
    blob['has_warlock'] = (d / 'warlock.txt').is_file()
    return _plain(blob)


def warlock_prepare(label: str) -> dict:
    """为某次训练（或存档用例）生成 warlock.exe 能直接打开/录像的想定。

    ``input.txt`` 是给 ``mission.exe`` 的批处理想定；Warlock 需要同一份文本但多一个
    ``event_pipe`` 录像块（否则 GUI 里无法回放）。这里就地生成 ``warlock.txt`` 与 ``out/``。
    """
    d = _label_dir(label)
    src = d / 'input.txt'
    if not src.is_file():
        raise FileNotFoundError('%s 缺少 input.txt' % d.name)
    raw = src.read_bytes()
    if b'event_pipe' not in raw:
        raw = raw.rstrip() + _WL_BLOCK
    wl = d / 'warlock.txt'
    wl.write_bytes(raw)
    (d / 'out').mkdir(exist_ok=True)
    return {'ok': True, 'label': d.name, 'dir': str(d),
            'input_txt': str(src), 'warlock_txt': str(wl),
            'bytes': wl.stat().st_size}


def warlock_launch(label: str) -> dict:
    """生成想定并拉起官方图形前端 warlock.exe（本地 GUI，独立进程，关服也不退）。"""
    prep = warlock_prepare(label)
    engine = AB.AfsimEngine()
    exe = Path(engine.warlock)
    if not exe.is_file():
        raise FileNotFoundError('未安装 warlock.exe：%s' % exe)
    # 同一时间只留一个 Warlock 实例，避免热键与录像目录互相干扰
    try:
        subprocess.run(['taskkill', '/F', '/IM', 'warlock.exe'],
                       capture_output=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        pass
    flags = 0x00000008 | 0x00000200          # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    proc = subprocess.Popen([str(exe), prep['warlock_txt']],
                            cwd=prep['dir'], creationflags=flags,
                            close_fds=True, stdin=subprocess.DEVNULL)
    prep.update({'launched': True, 'pid': proc.pid, 'exe': str(exe),
                 'engine': engine.info()})
    return prep


# ---------------------------------------------------------------------------
# 官方图形前端（Warlock）演示录屏
# ---------------------------------------------------------------------------
_DEMO_RE = re.compile(r'^afsim_warlock_(?P<host>.+?)_F(?P<fid>\d+)(?:_run(?P<run>\d+))?\.mp4$')
_DEMO_DIR = Path(__file__).resolve().parent / 'static' / 'media'


def warlock_demos() -> dict:
    """列出 static/media 下已录制的 warlock.exe 演示视频（按算法 / 任务分组）。"""
    items = []
    if _DEMO_DIR.is_dir():
        for p in sorted(_DEMO_DIR.glob("afsim_warlock_*.mp4")):
            m = _DEMO_RE.match(p.name)
            if not m:
                continue
            poster = p.with_suffix(".jpg")
            st = p.stat()
            items.append({
                "host": m.group("host"),
                "fid": int(m.group("fid")),
                "run": int(m.group("run") or 0),
                "url": "/media/" + p.name,
                "poster": ("/media/" + poster.name) if poster.is_file() else None,
                "bytes": st.st_size,
                "mtime": int(st.st_mtime),
            })
    items.sort(key=lambda d: (d["host"], d["fid"], d["run"]))
    return {"items": items, "count": len(items),
            "hosts": sorted({d["host"] for d in items}),
            "fids": sorted({d["fid"] for d in items})}

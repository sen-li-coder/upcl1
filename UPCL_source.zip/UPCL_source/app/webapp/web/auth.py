# -*- coding: utf-8 -*-
"""用户认证与会话管理（SQLite + PBKDF2 + 会话 token，纯标准库实现）。

多用户隔离的基础：管理员（admin）可创建/删除客户账号，客户登录后只能看到/
操作自己的数据。登录成功签发一个随机 token，前端放到 ``Authorization`` 请求
头里，后端通过 ``get_current_user`` 依赖解析出当前用户名。

首次 import 会自动建库并创建默认管理员账号：admin / admin123（请尽快修改）。
"""
import hashlib
import re
import secrets
import sqlite3
import threading
import time

from fastapi import HTTPException, Request

from . import constants as C

DB_PATH = C.DATA_DIR / 'auth.db'
_TOKEN_TTL = 7 * 24 * 3600          # 会话有效期：7 天
_PBKDF2_ITERS = 200_000

# 用户名校验：只允许字母/数字/下划线/点/连字符，防止路径穿越（用户名会作为目录名）
_USERNAME_RE = re.compile(r'^[A-Za-z0-9_.-]{1,32}$')

_lock = threading.Lock()


def _conn():
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _hash_password(password, salt_hex):
    return hashlib.pbkdf2_hmac(
        'sha256', password.encode('utf-8'),
        bytes.fromhex(salt_hex), _PBKDF2_ITERS).hex()


def _init_db():
    C.DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = _conn()
    try:
        conn.execute(
            'CREATE TABLE IF NOT EXISTS users('
            'id INTEGER PRIMARY KEY AUTOINCREMENT,'
            'username TEXT UNIQUE NOT NULL,'
            'password_hash TEXT NOT NULL,'
            'salt TEXT NOT NULL,'
            'role TEXT NOT NULL DEFAULT \'user\','
            'created_at REAL NOT NULL)')
        conn.execute(
            'CREATE TABLE IF NOT EXISTS sessions('
            'token TEXT PRIMARY KEY,'
            'username TEXT NOT NULL,'
            'created_at REAL NOT NULL,'
            'expires_at REAL NOT NULL)')
        conn.commit()
    finally:
        conn.close()
    _ensure_admin()


def _ensure_admin():
    with _lock:
        conn = _conn()
        try:
            row = conn.execute(
                "SELECT 1 FROM users WHERE username='admin'").fetchone()
            if row is None:
                salt = secrets.token_hex(16)
                h = _hash_password('admin123', salt)
                conn.execute(
                    'INSERT INTO users(username,password_hash,salt,role,created_at)'
                    ' VALUES(?,?,?,?,?)',
                    ('admin', h, salt, 'admin', time.time()))
                conn.commit()
        finally:
            conn.close()


# 首次 import 即建库 + 建默认 admin
_init_db()


# ---------------------------------------------------------------------------
# 用户管理
# ---------------------------------------------------------------------------
def get_role(username):
    conn = _conn()
    try:
        row = conn.execute(
            'SELECT role FROM users WHERE username=?', (username,)).fetchone()
        return row['role'] if row else None
    finally:
        conn.close()


def list_users():
    conn = _conn()
    try:
        rows = conn.execute(
            'SELECT username, role, created_at FROM users ORDER BY username'
        ).fetchall()
        return [{'username': r['username'], 'role': r['role'],
                 'created_at': r['created_at']} for r in rows]
    finally:
        conn.close()


def create_user(username, password, role='user'):
    username = str(username or '').strip()
    if not username:
        return {'ok': False, 'msg': '用户名不能为空'}
    if not _USERNAME_RE.match(username):
        return {'ok': False, 'msg': '用户名仅限字母/数字/下划线/点/连字符（≤32 字符）'}
    if role not in ('user', 'admin'):
        role = 'user'
    if not password or len(password) < 6:
        return {'ok': False, 'msg': '密码至少 6 位'}
    with _lock:
        conn = _conn()
        try:
            if conn.execute('SELECT 1 FROM users WHERE username=?',
                            (username,)).fetchone():
                return {'ok': False, 'msg': f'用户「{username}」已存在'}
            salt = secrets.token_hex(16)
            h = _hash_password(password, salt)
            conn.execute(
                'INSERT INTO users(username,password_hash,salt,role,created_at)'
                ' VALUES(?,?,?,?,?)',
                (username, h, salt, role, time.time()))
            conn.commit()
            return {'ok': True, 'username': username}
        finally:
            conn.close()


def delete_user(username):
    if username == 'admin':
        return {'ok': False, 'msg': '不能删除内置 admin 账号'}
    with _lock:
        conn = _conn()
        try:
            cur = conn.execute('DELETE FROM users WHERE username=?', (username,))
            conn.execute('DELETE FROM sessions WHERE username=?', (username,))
            conn.commit()
            if cur.rowcount == 0:
                return {'ok': False, 'msg': f'用户「{username}」不存在'}
            return {'ok': True}
        finally:
            conn.close()


def reset_password(username, new_password):
    if not new_password or len(new_password) < 6:
        return {'ok': False, 'msg': '密码至少 6 位'}
    with _lock:
        conn = _conn()
        try:
            if not conn.execute('SELECT 1 FROM users WHERE username=?',
                                (username,)).fetchone():
                return {'ok': False, 'msg': f'用户「{username}」不存在'}
            salt = secrets.token_hex(16)
            h = _hash_password(new_password, salt)
            conn.execute(
                'UPDATE users SET password_hash=?, salt=? WHERE username=?',
                (h, salt, username))
            # 改密后强制该用户所有会话失效
            conn.execute('DELETE FROM sessions WHERE username=?', (username,))
            conn.commit()
            return {'ok': True}
        finally:
            conn.close()


def change_password(username, old_password, new_password):
    """用户自助修改自己的密码。"""
    if authenticate(username, old_password) is None:
        return {'ok': False, 'msg': '原密码不正确'}
    return reset_password(username, new_password)


# ---------------------------------------------------------------------------
# 会话
# ---------------------------------------------------------------------------
def authenticate(username, password):
    """校验用户名密码，成功则签发并返回新 token，失败返回 None。"""
    username = str(username or '').strip()
    conn = _conn()
    try:
        row = conn.execute('SELECT * FROM users WHERE username=?',
                           (username,)).fetchone()
    finally:
        conn.close()
    if row is None:
        return None
    if _hash_password(password or '', row['salt']) != row['password_hash']:
        return None
    token = secrets.token_urlsafe(32)
    now = time.time()
    with _lock:
        conn = _conn()
        try:
            conn.execute('DELETE FROM sessions WHERE expires_at < ?', (now,))
            conn.execute(
                'INSERT INTO sessions(token,username,created_at,expires_at)'
                ' VALUES(?,?,?,?)',
                (token, username, now, now + _TOKEN_TTL))
            conn.commit()
        finally:
            conn.close()
    return token


def get_username_by_token(token):
    if not token:
        return None
    now = time.time()
    conn = _conn()
    try:
        row = conn.execute(
            'SELECT username FROM sessions WHERE token=? AND expires_at>?',
            (token, now)).fetchone()
        return row['username'] if row else None
    finally:
        conn.close()


def logout(token):
    if not token:
        return
    conn = _conn()
    try:
        conn.execute('DELETE FROM sessions WHERE token=?', (token,))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# FastAPI 依赖
# ---------------------------------------------------------------------------
def _token_from_request(request):
    auth = request.headers.get('Authorization', '')
    if auth.startswith('Bearer '):
        return auth[7:].strip()
    return None


def get_current_user(request: Request) -> str:
    token = _token_from_request(request)
    username = get_username_by_token(token)
    if not username:
        raise HTTPException(status_code=401, detail='未登录或登录已过期')
    return username


def require_admin(request: Request) -> str:
    username = get_current_user(request)
    if get_role(username) != 'admin':
        raise HTTPException(status_code=403, detail='需要管理员权限')
    return username

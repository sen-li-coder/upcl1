# -*- coding: utf-8 -*-
"""UAV 对抗仿真后端：构建问题 → 优化 → 返回 frames + 战场几何 + 收敛曲线。

移植自 uav_gui.py 的 _run_once / _on_done / _start_anim 链路，优化逻辑零改动。
"""
import hashlib
import json
import threading
import time
from datetime import datetime
from pathlib import Path

import numpy as np

from . import constants as C
from . import workspace

# 预训练好的红方 DRL 策略缓存（进程内），键 = (scenario, fid, n_waypoints,
# diff_key, drl_key)。「先预训练 → 再演化逃逸」两阶段流程的第二阶段从这里取用。
_pretrained = {}
_pretrained_lock = threading.Lock()


def _pretrained_key(scenario, fid, n_waypoints, diff_key, drl_key):
    return (str(scenario), int(fid), int(n_waypoints or 0),
            str(diff_key), str(drl_key))


def _get_pretrained(scenario, fid, n_waypoints, diff_key, drl_key):
    key = _pretrained_key(scenario, fid, n_waypoints, diff_key, drl_key)
    with _pretrained_lock:
        return _pretrained.get(key)


def _set_pretrained(scenario, fid, n_waypoints, diff_key, drl_key, policy):
    key = _pretrained_key(scenario, fid, n_waypoints, diff_key, drl_key)
    with _pretrained_lock:
        _pretrained[key] = policy


def _jsonable(obj):
    """递归把 numpy 标量/数组转成 Python 原生类型。"""
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    return obj


def uav_meta():
    import uav_adversarial
    import opponents
    scenarios = uav_adversarial.list_scenarios()
    # 任务（fid）元数据：每个场景的任务编号、可读名称与红方配置摘要，
    # 供前端「任务」下拉展示（实景突防场景 F1-F4 共享同一张地图）。
    task_options = {s: uav_adversarial.list_tasks(s) for s in scenarios}
    task_infos = {
        s: {str(f): uav_adversarial.task_info(s, f)
            for f in task_options[s]}
        for s in scenarios
    }
    return {
        'scenarios': scenarios,
        'scenario_names': uav_adversarial.SCENARIO_NAMES,
        'scenario_nfuncs': uav_adversarial.SCENARIO_NFUNCS,
        'scenario_dims': uav_adversarial.SCENARIO_DIMS,
        'task_options': task_options,
        'task_infos': task_infos,
        'hosts': C.HOSTS,
        'difficulty_options': opponents.DIFFICULTY_OPTIONS,
        'drl_algo_options': opponents.DRL_ALGO_OPTIONS,
        'arm_options': ['bare', 'full'],
        'evals_mult_options': [50, 100, 200, 300, 500, 1000, 2000],
        # 红方优化课题（F1 兵力部署 / F2 预警 / F3 拦截 / F4 协同）：作为「场景」
        # 下拉里的一个并列入口（value='red'），选中后前端切换到红方模式。
        'red': _red_meta_payload(),
    }


def describe_uav(scenario: str, fid: int = 1, n_waypoints=None,
                 n_attack=None, n_infantry=None):
    """返回场景的完整结构化说明（问题 / 模型 / 约束 / 评分 / 参数具体值）。"""
    import uav_adversarial
    return _jsonable(uav_adversarial.describe_scenario(
        scenario, fid=fid, n_waypoints=n_waypoints,
        n_attack=n_attack, n_infantry=n_infantry))


def _geometry(problem):
    cfg = problem.cfg
    env = problem.env
    inter0 = np.asarray(env.interceptors0, dtype=float).reshape(-1, 2).tolist()
    if problem.scenario == 'swarm':
        # swarm：三维山地集群突防，附带合成地形（供 3D 渲染）
        terrain_data = None
        zmin = zmax = 0.0
        if getattr(env, 'terrain', None) is not None:
            t = env.terrain
            xs, ys, Z = t.grid()
            step = max(1, len(xs) // 60)
            xs2, ys2 = xs[::step], ys[::step]
            Z2 = Z[::step, ::step]
            terrain_data = {'xs': xs2.tolist(), 'ys': ys2.tolist(),
                            'Z': Z2.tolist()}
            zmin, zmax = float(t.z_min), float(t.z_max)
        return {
            'scenario': 'swarm',
            'width': float(cfg.width), 'depth': float(cfg.depth),
            'start_pos': [float(env.starts[0][0]), float(env.starts[0][1])],
            'target_pos': [float(env.targets[0][0]), float(env.targets[0][1])],
            'starts': [[float(s[0]), float(s[1])] for s in env.starts],
            'targets': [[float(t[0]), float(t[1])] for t in env.targets],
            'cluster_centers': [[float(x), float(y)]
                                for x, y in cfg.cluster_centers],
            'no_fly_zones': [[float(c), float(d), float(z), float(r)]
                             for c, d, z, r in cfg.no_fly_zones],
            'interceptors0': inter0,
            'intercept_radius': float(cfg.intercept_radius),
            'intercept_half_angle': float(cfg.intercept_half_angle_rad),  # 弧度
            'half_angle_unit': 'rad',
            'n_drones': int(cfg.n_drones),
            'max_alt': float(getattr(cfg, 'max_alt', 500.0)),
            'terrain': terrain_data,
            'terrain_zmin': zmin, 'terrain_zmax': zmax,
            'h_clearance': float(getattr(cfg, 'h_clearance', 200.0)),
            'los_block': bool(getattr(cfg, 'los_block', True)),
            'aa0': [[float(p[0]), float(p[1])] for p in getattr(env, 'aa0', [])],
            'aa_range': float(getattr(cfg, 'aa_range', 6000.0)),
            'aa_vert_half_angle': float(getattr(cfg, 'aa_vert_half_angle', 60.0)),
            'canyons': [[float(v) for v in c]
                        for c in getattr(env, 'terrain_features', {}).get('canyons', [])],
            'waterfalls': [[float(v) for v in w]
                           for w in getattr(env, 'terrain_features', {}).get('waterfalls', [])],
            'rivers': [[float(v) for v in r]
                       for r in getattr(env, 'terrain_features', {}).get('rivers', [])],
            'villages': [[float(v) for v in vg]
                         for vg in getattr(env, 'terrain_features', {}).get('villages', [])],
            'military': _jsonable(getattr(env, 'terrain_features', {}).get('military', None)),
            # 军事基地（最终目标核心）：位置 + 血量上限 + 半径（前端标志建筑/血条/特效）
            'base_pos': [float(env.base_pos[0]), float(env.base_pos[1])],
            'base_hp': float(env.base_hp_max),
            'base_radius': float(env.base_radius),
            # 预警雷达：位置 + 探测半径（蓝方进入后红方无人机起飞拦截）
            'radar_pos': [float(env.radar_pos[0]), float(env.radar_pos[1])],
            'radar_range': float(env.radar_range),
            # 停机坪：军事基地左右两侧（红方无人机停靠待命点）
            'helipads': [[float(p[0]), float(p[1])] for p in env.helipads],
        }
    # intercept：三维山地对抗，附带合成地形（供 3D 渲染）
    terrain_data = None
    zmin = zmax = 0.0
    if getattr(env, 'terrain', None) is not None:
        t = env.terrain
        xs, ys, Z = t.grid()
        step = max(1, len(xs) // 60)
        xs2, ys2 = xs[::step], ys[::step]
        Z2 = Z[::step, ::step]
        terrain_data = {'xs': xs2.tolist(), 'ys': ys2.tolist(),
                        'Z': Z2.tolist()}
        zmin, zmax = float(t.z_min), float(t.z_max)
    return {
        'scenario': 'intercept',
        'map_w': float(cfg.map_w), 'map_h': float(cfg.map_h),
        'start_pos': [float(env.starts[0][0]), float(env.starts[0][1])],
        'target_pos': [float(env.targets[0][0]), float(env.targets[0][1])],
        'starts': [[float(s[0]), float(s[1])] for s in env.starts],
        'targets': [[float(t[0]), float(t[1])] for t in env.targets],
        # 目标区即军事基地，到达判定半径用 base_radius（与 3D 基地环一致）
        'target_radius': float(cfg.base_radius),
        'no_fly_zones': [[float(c), float(d), float(z), float(r)]
                         for c, d, z, r in cfg.no_fly_zones],
        'interceptors0': inter0,
        'intercept_radius': float(cfg.intercept_radius),
        'intercept_half_angle': float(cfg.intercept_half_angle),  # 弧度
        'half_angle_unit': 'rad',
        # 直升机巡航速度（米/步）：前端用于旋翼转速归一化，表现起降加减速
        'interceptor_speed': float(getattr(cfg, 'interceptor_speed', 12.0)),
        # 雷达站：位置 + 探测半径（捕获入侵无人机后才出动直升机拦截）
        'radar_pos': [float(cfg.radar_pos[0]), float(cfg.radar_pos[1])],
        'radar_range': float(cfg.radar_range),
        # 地面无人车（防空车）：初始位置（贴地 z）、对空攻击范围、对空垂直半角
        'aa0': [[float(p[0]), float(p[1]), float(p[2])]
                for p in getattr(env, 'aa0', [])],
        'aa_range': float(getattr(cfg, 'aa_range', 260.0)),
        # intercept 的 aa_vert_half_angle 在 EnvConfig 中为弧度（≈1.0472=60°），
        # 前端对空扫描锥按「度」绘制，故此处统一换算为度（与 swarm 的 60° 一致）。
        'aa_vert_half_angle': float(np.degrees(getattr(cfg, 'aa_vert_half_angle', 1.0472))),
        'n_drones': int(cfg.n_drones),
        'max_alt': float(getattr(cfg, 'max_alt', 320.0)),
        'terrain': terrain_data,
        'terrain_zmin': zmin, 'terrain_zmax': zmax,
        'h_clearance': float(getattr(cfg, 'h_clearance', 30.0)),
        'los_block': bool(getattr(cfg, 'los_block', True)),
        # 空地协同巷战：军事基地（攻击点）+ 步兵 + 巡逻兵 + 楼房
        'base_pos': [float(env.base[0]), float(env.base[1])],
        'base_hp': float(getattr(env, 'base_hp_max', cfg.base_hp)),
        'base_radius': float(cfg.base_radius),
        'bomb_damage': float(getattr(cfg, 'bomb_damage', 12.0)),
        'infantry0': [[float(s[0]), float(s[1])] for s in env.infantry0],
        'infantry_hp': float(cfg.infantry_hp),
        'infantry_range': float(cfg.infantry_range),
        'patrol0': [[float(s[0]), float(s[1])] for s in env.patrol0],
        'patrol_hp': float(cfg.patrol_hp),
        'patrol_range': float(cfg.patrol_range),
        'patrol_vision_range': float(cfg.patrol_vision_range),
        'buildings': [[float(b[0]), float(b[1]), float(b[2]), float(b[3])]
                      for b in env.buildings],
    }


def map_geometry(scenario='intercept', fid=1, n_waypoints=None,
                 n_attack=None, n_infantry=None):
    """只构建仿真环境并返回战场几何（不跑优化），供前端「加载地形」浏览。

    两个三维山地场景（突防与拦截 intercept / 集群突防对抗 swarm）返回三维
    山地战场几何，与 ``run_uav`` 末尾的 ``_geometry`` 完全一致。
    """
    import uav_adversarial
    problem = uav_adversarial.get_uav_problem(
        scenario, fid=fid, n_waypoints=n_waypoints, n_attack=n_attack,
        n_infantry=n_infantry)
    return _jsonable(_geometry(problem))


def pretrain_uav(scenario, fid, n_waypoints, difficulty, drl_algo,
                 target_capture=0.6, seed=12345, progress_cb=None,
                 cancel_event=None):
    """第一阶段：预训练红方 DRL 对手，直到对「直线突防」天真蓝方的捕获率达标。

    达标后把策略缓存到进程内，供随后的 ``run_uav``（第二阶段：演化蓝方逃逸）
    复用。返回预训练统计（捕获率 / 是否达标 / 训练曲线）。
    """
    import uav_adversarial
    import opponents

    diff_key = opponents.DIFFICULTY_BY_LABEL.get(difficulty, difficulty)
    drl_key = opponents.DRL_ALGO_BY_LABEL.get(drl_algo, drl_algo)

    if not opponents.is_drl_difficulty(diff_key):
        return {'ok': False,
                'msg': f'当前难度「{difficulty}」非强化学习对手，无需预训练'}

    problem = uav_adversarial.get_uav_problem(
        scenario, fid=fid, n_waypoints=n_waypoints)
    env = problem.env

    def cb(it, total, cr):
        if progress_cb is not None:
            progress_cb(it / max(int(total), 1),
                        f'预训练 {it}/{total} 捕获率 {cr * 100:.0f}%')

    res = opponents.train_opponent_to_capture(
        env, diff_key, drl_algo=drl_key, seed=seed,
        target_capture=target_capture, progress_cb=cb,
        cancel_event=cancel_event)

    _set_pretrained(scenario, fid, n_waypoints, diff_key, drl_key,
                    res['policy'])

    return {
        'ok': True,
        'scenario': scenario, 'fid': fid, 'difficulty': difficulty,
        'drl_algo': drl_algo,
        'capture_rate': res['capture_rate'],
        'target_capture': res['target_capture'],
        'reached': res['reached'],
        'iters': res['iters'],
        'curve': res['curve'],
        'n_drones': int(getattr(env.cfg, 'n_drones', 1)),
    }


def run_uav(scenario, fid, n_waypoints, host_name, evals_mult, arm,
            difficulty, drl_algo, seed=12345, progress_cb=None,
            cancel_event=None, n_attack=None, n_infantry=None,
            coevolve=False):
    """在调用线程内同步执行优化（由 server 的线程池/后台线程调用）。

    ``coevolve=True`` 时启用双种群协同演化：蓝方航点 DE 与红方拦截者航点 DE
    交替对抗演化（仅 intercept / swarm 生效）。
    """
    import de_hosts
    import de_hosts_cec as DHC
    import uav_adversarial
    import opponents
    import run_upcl_cec as RUC
    from upcl_framework import UPCLController

    diff_key = opponents.DIFFICULTY_BY_LABEL.get(difficulty, difficulty)
    drl_key = opponents.DRL_ALGO_BY_LABEL.get(drl_algo, drl_algo)

    opp = opponents.make_opponent(diff_key, drl_algo=drl_key, seed=fid * 101)
    problem = uav_adversarial.get_uav_problem(
        scenario, fid=fid, n_waypoints=n_waypoints, n_attack=n_attack,
        n_infantry=n_infantry, opponent=opp)

    if opponents.is_drl_difficulty(diff_key) and not bool(coevolve):
        # 优先复用「预训练」阶段缓存的已达标策略；未预训练则回退到即时训练。
        # 协同演化下红方由巡逻航点（red_x）+ 规则追击驱动，DRL 对手会被忽略，故跳过训练。
        cached = _get_pretrained(scenario, fid, n_waypoints, diff_key, drl_key)
        if cached is not None:
            problem.env.opponent = cached
        else:
            opponents.train_opponent(problem.env, diff_key, drl_key, seed=0)

    dim = problem.dim
    max_evals = int(evals_mult) * dim

    coevolving = (bool(coevolve) and hasattr(problem, 'red_dim')
                  and scenario in ('intercept', 'swarm'))

    host = de_hosts.get_host(host_name, dim, problem.lb, problem.ub,
                             seed=seed,
                             pop_size=DHC.pop_size_for(host_name, dim))
    controller = None
    if arm == 'full' and not coevolving:
        controller = UPCLController(dim, problem.lb, problem.ub,
                                    seed=seed + 977,
                                    config=RUC.get_config('default'))
        host.gen_begin_fn = controller.begin_generation
        host.post_eval_fn = controller.observe
        host.proposal_fn = controller.propose

    evaluate = getattr(problem, 'evaluate', None)
    gen_metrics = []
    red_best_x = None

    def _cb(h):
        if cancel_event is not None and cancel_event.is_set():
            raise RuntimeError('cancelled')
        if progress_cb is not None:
            progress_cb(int(h.nevals), int(max_evals))
        if evaluate is not None:
            try:
                bx = np.asarray(h.pop[h.best_idx], dtype=float)
                _, _, m = evaluate(bx)
                gen_metrics.append(m)
            except Exception:
                pass

    if coevolving:
        # 双种群协同演化：蓝方航点 DE 与红方拦截者航点 DE 交替对抗。
        env = problem.env
        red_dim = problem.red_dim
        red_host = de_hosts.get_host(host_name, red_dim, -1.0, 1.0,
                                     seed=seed + 777,
                                     pop_size=DHC.pop_size_for(host_name, red_dim))
        # 协同演化直接调用 initialize_population / _generation_step，绕过了
        # host.run()（_max_evals 只在 run() 里注入）。这里手动注入评估预算，
        # 否则依赖 _max_evals 的自适应机制（LPSR / cnEpSin / HS / ILS）会抛
        # AttributeError 或退化为无预算语义。
        host._max_evals = max_evals
        red_host._max_evals = max_evals
        # 阶段0：红方先按追击规则，给蓝方一个初始种群与最优解
        env.red_x = None
        host.initialize_population(
            lambda bx: float(problem(np.asarray(bx, dtype=float))))
        blue_best = np.asarray(host.pop[host.best_idx], dtype=float)
        # 红方初始种群（对初始蓝方最优）
        red_host.initialize_population(
            lambda rx: float(problem.red_cost(np.asarray(rx, dtype=float), blue_best)))
        red_best = np.asarray(red_host.pop[red_host.best_idx], dtype=float)
        env.red_x = red_best

        # 交替演化预算：在总预算 max_evals 内蓝红各演化若干代
        per_round = int(host.N + red_host.N)
        n_rounds = max(1, int(max_evals - host.nevals - red_host.nevals)
                       // max(1, per_round))
        conv = [float(host.best_so_far)]
        evals = [int(host.nevals + red_host.nevals)]
        for _ in range(n_rounds):
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError('cancelled')
            # 红方对当前蓝方最优演化一代
            red_host._generation_step(
                lambda rx: float(problem.red_cost(np.asarray(rx, dtype=float), blue_best)))
            red_host.g += 1
            red_best = np.asarray(red_host.pop[red_host.best_idx], dtype=float)
            env.red_x = red_best
            # 蓝方对当前红方最优演化一代
            host._generation_step(
                lambda bx: float(problem(np.asarray(bx, dtype=float))))
            host.g += 1
            blue_best = np.asarray(host.pop[host.best_idx], dtype=float)
            conv.append(float(host.best_so_far))
            evals.append(int(host.nevals + red_host.nevals))
            if progress_cb is not None:
                progress_cb(int(host.nevals + red_host.nevals), int(max_evals))
            if evaluate is not None:
                try:
                    _, _, m = evaluate(blue_best)
                    gen_metrics.append(m)
                except Exception:
                    pass
        best_x = blue_best
        red_best_x = red_best
        # 最终成绩以「当前蓝方最优 vs 最终红方最优」的实际对抗成本为准；
        # host.best_so_far 是跨代历史最小值，红方逐步变强后不再代表当前对抗强度。
        best_f = float(problem(np.asarray(best_x, dtype=float)))
    else:
        best_f, best_x, conv, evals = host.run(problem, max_evals, callback=_cb)

    cost, state, frames = problem.trajectory(best_x)

    return _pack_result(problem, best_x, frames, cost, {
        'scenario': scenario, 'fid': fid, 'host': host_name, 'arm': arm,
        'difficulty': difficulty, 'drl_algo': drl_algo,
        'dim': dim, 'max_evals': max_evals,
        'n_waypoints': n_waypoints, 'n_attack': n_attack,
        'n_infantry': n_infantry,
        'evals_mult': int(evals_mult), 'seed': int(seed),
        'best_f': float(best_f),
        'conv': [float(v) for v in conv],
        'evals': [float(v) for v in evals],
        'gen_metrics': _jsonable(gen_metrics),
        'upcl_stats': _jsonable(controller.stats()) if controller else None,
        'coevolve': bool(coevolving),
        'red_best_x': red_best_x,
    })


def _pack_combat_frames(frames, scenario='intercept'):
    """把环境回放帧序列化成前端可播放的 JSON（蓝方 run_uav 与红方课题共用）。

    三维山地对抗帧：drones / interceptors / aa / missiles / events /
    infantry / patrol / base。
    """
    return [{
        'step': fr['step'],
        'drones': [[float(d[0]), float(d[1]), float(d[2]), int(d[3]), float(d[4])]
                   for d in fr['drones']],
        'interceptors': [[float(p[0]), float(p[1]), float(p[2]), float(p[3]),
                          int(p[4]) if len(p) > 4 else 2,
                          float(p[5]) if len(p) > 5 else 0.0]
                         for p in fr['interceptors']],
        'aa': [[float(p[0]), float(p[1]), float(p[2]), float(p[3])]
               for p in fr.get('aa', [])],
        'missiles': [[float(m[0]), float(m[1]), float(m[2])]
                     for m in fr.get('missiles', [])],
        # 击落/坠毁事件，供前端播放「被防空车击落 / 被拦截机击落 / 坠毁」
        # 局部动画演示：{'t': 'intercept'|'missile'|'crash', 'd': 无人机,
        # 's': 施体索引, 'x','y','z': 事件位置}
        'events': [{'t': ev['t'], 'd': int(ev['d']), 's': int(ev.get('s', -1)),
                    'x': float(ev['x']), 'y': float(ev['y']), 'z': float(ev['z'])}
                   for ev in fr.get('events', [])],
        # 空地协同巷战：步兵 / 巡逻兵 / 军事基地
        'infantry': [[float(p[0]), float(p[1]), int(p[2]), float(p[3])]
                     for p in fr.get('infantry', [])],
        'patrol': [[float(p[0]), float(p[1]), int(p[2]), float(p[3])]
                   for p in fr.get('patrol', [])],
        'base': [float(b) for b in fr.get('base', [0.0, 0.0])],
    } for fr in frames]


def _pack_result(problem, best_x, frames, cost, meta):
    """把一次仿真打包成前端可渲染的结果对象（实时仿真与论文轨迹重放共用）。

    ``frames`` 来自 ``problem.trajectory(best_x)``（三维对抗为 drones /
    interceptors / aa / missiles / events / infantry / patrol / base 逐帧轨迹）。
    ``meta`` 提供调用方特有元数据；其中可选键 ``extra`` 的字典会合并进返回值，
    供论文轨迹重放附带来源信息（host / run / arm / 论文原始指标等）。
    """
    scenario = problem.scenario
    best_x = np.asarray(best_x, dtype=float)
    meta = dict(meta)
    extra = meta.pop('extra', None) or {}

    # 最终解的多维对比指标（飞行轨迹 / 捕获时间 / 路径效率 / 曲率 / 爬升等）。
    # 默认由环境对最终解重新评估得到，保证与帧轨迹同源自洽；调用方若显式传入
    # ``meta['metrics']``（例如需要展示存档记录值）则以其为准。
    final_metrics = meta.pop('metrics', None)
    if final_metrics is None:
        final_metrics = {}
        evaluate = getattr(problem, 'evaluate', None)
        if evaluate is not None:
            try:
                _, _, final_metrics = evaluate(best_x.ravel())
            except Exception:
                final_metrics = {}

    try:
        wps = problem.decode(best_x.ravel())
        waypoints = [[[float(wx), float(wy), float(wz)] for wx, wy, wz in w]
                     for w in wps]
        if scenario == 'intercept' and hasattr(problem, 'decode_infantry'):
            inf_wps = problem.decode_infantry(best_x.ravel())
            infantry_waypoints = [[[float(px), float(py)] for px, py in w]
                                  for w in inf_wps]
        else:
            infantry_waypoints = []
    except Exception:
        waypoints = []
        infantry_waypoints = []
    last = frames[-1]['drones'] if frames else []
    # 状态码：0 飞行 / 1 到达 / 2 被击落 / 3 坠毁 / 4 投弹完成自毁（intercept
    # 的任务成功态，自毁后不再渲染），故到达数需同时计 1 与 4。
    n_arr = sum(1 for d in last if d[3] in (1, 4))
    n_lost = sum(1 for d in last if d[3] == 2)
    n_crash = sum(1 for d in last if d[3] == 3)

    geometry = _geometry(problem)
    n_drones = int(problem.cfg.n_drones)

    # 帧序列化：三维山地对抗的 drones/interceptors/...
    frames_out = _pack_combat_frames(frames, scenario)

    out = {
        'scenario': scenario, 'dim': int(problem.dim),
        'best_x': [float(v) for v in best_x.ravel()],
        'waypoints': waypoints,
        'infantry_waypoints': infantry_waypoints,
        'geometry': geometry,
        'frames': frames_out,
        'arrived': n_arr, 'lost': n_lost, 'crashed': n_crash,
        'n_drones': n_drones,
        'metrics': _jsonable(final_metrics),
        'cost': float(cost),
        'describe': _jsonable(problem.cfg.describe()),
        'red_best_x': ([float(v) for v in np.asarray(meta['red_best_x'], dtype=float).ravel()]
                       if meta.get('red_best_x') is not None else None),
    }
    out.update(meta)
    out.update(extra)
    return out


# ---------------------------------------------------------------------------
# UAV 仿真数据存档（记录先前运行结果，供回放查看）
# ---------------------------------------------------------------------------

UAV_ARCHIVE_DIR = C.ROOT / 'results' / 'apps' / 'gui'


def _archive_dir(user=None):
    """UAV 存档目录：登录用户写各自私有目录，本地/公共写公共目录。"""
    return workspace.user_uav(user) if user else UAV_ARCHIVE_DIR


def _opt_int(v):
    return 0 if v is None else int(v)


def _config_of(payload):
    """从存档提取「场景一致性」配置（决定可否互相对比的一组参数）。

    同一 (scenario, fid, 各单元数, 对手难度, DRL 算法, 协同演化, 评估预算)
    的存档才允许互相对比；这些参数一致时，地形/布局/问题维度完全相同
    （uav_adversarial 的 _build_env 用 seed=0 + fid 确定性生成地图）。
    """
    if payload.get('red_mode'):
        # 红方课题：可比性由「课题 + 想定(fid) + 蓝方对手口径 + 评估预算」决定。
        # 同组的红方存档地形/编成/对手完全相同，可互相对比。
        return {
            'scenario': 'red',
            'fid': int(payload.get('fid', 1)),
            'red_mode': str(payload.get('red_mode')),
            'opponent': str(payload.get('opponent') or 'straight'),
            'blue_runs': _opt_int(payload.get('blue_runs')),
            'blue_evals': _opt_int(payload.get('blue_evals')),
            'evals_mult': _opt_int(payload.get('evals_mult')),
        }
    scenario = str(payload.get('scenario', 'unknown'))
    fid = int(payload.get('fid', 1))
    return {
        'scenario': scenario,
        'fid': fid,
        'n_waypoints': _opt_int(payload.get('n_waypoints')),
        'n_attack': _opt_int(payload.get('n_attack')),
        'n_infantry': _opt_int(payload.get('n_infantry')),
        'difficulty': str(payload.get('difficulty') or ''),
        'drl_algo': str(payload.get('drl_algo') or ''),
        'coevolve': bool(payload.get('coevolve', False)),
        'evals_mult': _opt_int(payload.get('evals_mult')),
    }


def _config_key(cfg):
    """稳定的分组目录名：f{fid}__{sha1 前 10 位}，同配置归档到同一目录。"""
    if cfg.get('red_mode'):
        sig = '|'.join([
            'red', str(cfg['fid']), str(cfg['red_mode']),
            str(cfg.get('opponent', '')), str(cfg.get('blue_runs', 0)),
            str(cfg.get('blue_evals', 0)), str(cfg.get('evals_mult', 0)),
        ])
    else:
        sig = '|'.join([
            cfg['scenario'], str(cfg['fid']),
            str(cfg['n_waypoints']),
            str(cfg['n_attack']), str(cfg['n_infantry']),
            cfg['difficulty'], cfg['drl_algo'],
            '1' if cfg['coevolve'] else '0', str(cfg['evals_mult']),
        ])
    h = hashlib.sha1(sig.encode('utf-8')).hexdigest()[:10]
    return f'f{cfg["fid"]}__{h}'


def _config_label(cfg):
    """配置的人类可读标签，用于存档分组标题展示。"""
    if cfg.get('red_mode'):
        import uav_red as UR
        parts = [f'F{cfg["fid"]}',
                 f'红方·{UR.MODE_NAMES.get(cfg["red_mode"], cfg["red_mode"])}']
        parts.append('对手：直扑' if cfg.get('opponent') == 'straight'
                     else f'对手：强突防×{cfg.get("blue_runs", 0)}')
        if cfg.get('evals_mult'):
            parts.append(f'预算×{cfg["evals_mult"]}')
        return ' · '.join(parts)
    parts = [f'F{cfg["fid"]}']
    if cfg['n_waypoints']:
        parts.append(f'航点×{cfg["n_waypoints"]}')
    if cfg['n_attack']:
        parts.append(f'突防×{cfg["n_attack"]}')
    if cfg['n_infantry']:
        parts.append(f'步兵×{cfg["n_infantry"]}')
    if cfg['coevolve']:
        parts.append('协同演化')
    elif cfg['difficulty']:
        parts.append(cfg['difficulty'])
    if cfg['drl_algo'] and '强化学习' in cfg['difficulty']:
        parts.append(cfg['drl_algo'])
    if cfg['evals_mult']:
        parts.append(f'预算×{cfg["evals_mult"]}')
    return ' · '.join(parts)


def _find_uav_archive(scenario, name, user=None):
    """按 scenario + 文件名定位存档（兼容旧 F{fid} 目录与新分组目录）。"""
    safe_name = Path(str(name)).name
    base = _archive_dir(user) / str(scenario)
    if not base.is_dir():
        return None
    for fp in base.rglob(safe_name):
        if fp.is_file():
            return fp
    return None


def _archive_meta(fp, d):
    """单条存档的轻量元信息。"""
    cfg = _config_of(d)
    return {
        'name': fp.name,
        'scenario': d.get('scenario'),
        'fid': d.get('fid'),
        'host': d.get('host'),
        'arm': d.get('arm'),
        'timestamp': d.get('timestamp'),
        'saved_at': d.get('saved_at'),
        'best_f': d.get('best_f'),
        'dim': d.get('dim'),
        'max_evals': d.get('max_evals'),
        'arrived': d.get('arrived'),
        'n_drones': d.get('n_drones'),
        'config_key': d.get('config_key') or _config_key(cfg),
        # 红方课题存档：课题名 / 对手口径 / 可行性与 cost，供存档列表直接展示
        'red_mode': d.get('red_mode'),
        'red_mode_name': d.get('red_mode_name'),
        'opponent': d.get('opponent'),
        'opponent_label': d.get('opponent_label'),
        'feasible': d.get('feasible'),
        'cost': d.get('cost'),
    }


def save_uav_archive(payload, user=None):
    """保存一次 UAV 仿真结果，按「地图 + 参数配置」分类归档。"""
    cfg = _config_of(payload)
    scenario = cfg['scenario']
    host = str(payload.get('host', 'unknown'))
    arm = str(payload.get('arm', 'bare'))
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    name = f'{host}__{arm}__{ts}.json'
    data = dict(payload)
    data.setdefault('schema', 1)
    data.setdefault('suite', 'uav_' + scenario)
    data.setdefault('seed', 12345)
    data.setdefault('timestamp', ts)
    data['saved_at'] = datetime.now().isoformat(timespec='seconds')
    data['config'] = cfg
    data['config_key'] = _config_key(cfg)
    path = _archive_dir(user) / scenario / data['config_key'] / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(_jsonable(data), f, ensure_ascii=False)
    return {'name': name, 'scenario': scenario, 'config_key': data['config_key']}


def list_uav_archive(user=None):
    """按「地图 + 参数配置」分组列出所有存档元信息。

    返回 ``{'groups': [...]}``，每个 group 含 ``config``（场景一致性配置，
    含 ``key``/``label``）与 ``items``（该配置下的各算法存档）；同 group
    内的存档场景完全一致，可互相对比。
    """
    groups = {}
    order = []
    archive = _archive_dir(user)
    if archive.is_dir():
        for scen_dir in sorted(archive.iterdir()):
            if not scen_dir.is_dir():
                continue
            for fp in sorted(scen_dir.rglob('*.json')):
                try:
                    with open(fp, encoding='utf-8') as f:
                        d = json.load(f)
                except Exception:
                    continue
                meta = _archive_meta(fp, d)
                key = meta['config_key']
                if key not in groups:
                    groups[key] = {'config': _config_of(d), 'items': []}
                    order.append(key)
                groups[key]['items'].append(meta)

    out = []
    for key in sorted(order, key=lambda k: (
            groups[k]['config']['scenario'], groups[k]['config']['fid'], k)):
        g = groups[key]
        cfg = g['config']
        cfg['key'] = key
        cfg['label'] = _config_label(cfg)
        g['items'].sort(key=lambda x: (
            str(x.get('host') or ''), str(x.get('arm') or ''),
            x.get('timestamp') or ''))
        out.append(g)
    return {'groups': out}


def load_uav_archive(scenario, name, user=None):
    """加载完整存档（含 frames/geometry，可直接回放）。"""
    p = _find_uav_archive(scenario, name, user)
    if not p:
        return None
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def delete_uav_archive(scenario, name, user=None):
    p = _find_uav_archive(scenario, name, user)
    if p and p.is_file():
        p.unlink()
        return True
    return False


# ---------------------------------------------------------------------------
# 论文实验数据（第 5 章：地图一 F1-F4 × 29 宿主算法，基线 vs 增加 UPCL）
# ---------------------------------------------------------------------------
# 数据由论文实验脚本产出（results/apps 的 raw / tables / figures），部署时随
# webapp 镜像到 app/webapp/results/apps。面板只读展示，不重算、不写回。

PAPER_APP_DIR = C.ROOT / 'results' / 'apps'

# 面板展示的核心指标：metric_cells.csv 的列前缀（{metric}_median / _mean）。
# 方向（higher_better / lower_better）取自 upcl_delta.csv，未收录按 higher_better。
PAPER_METRICS = [
    'n_arrived', 'n_lost', 'min_dist', 'first_capture',
    'nofly_steps', 'risk_time', 'bounds_steps', 'path_length', 'flight_time',
    'n_inf_arrived', 'infantry_survival', 'base_hp',
    'n_patrol_killed', 'patrol_survival',
]

# §5.5 分级任务完成度（uav_mission.csv）：不设阈值，直接给百分比。列名为
# （面板 key, csv 列）；面板存 0–1 比例，前端 ×100 显示。第一项 CSR 是论文的
# 综合成功率 = 0.50 削弱 + 0.25 突入 + 0.25 战果，取代了恒为零的二值成功列。
PAPER_MISSION = [
    ('csr_pct', 'composite_pct_median'),
    ('base_weaken_pct', 'damage_pct_median'),
    ('inf_breach_pct', 'breach_pct_median'),
    ('patrol_kill_pct', 'kill_pct_median'),
]

# 论文配图（{fid} 占位）。文件名含 {fid} 的是「按任务拆分」图：F1–F4 各一张，
# 面板随任务切换换图；不含 {fid} 的是 4 个任务合并口径（论文正文引用），
# 前端收进折叠区并标注「切换任务不会变」，避免被误读成数据错误。
PAPER_FIGURES = [
    ('task', 'fig_uav_task_F{fid}.png', '本任务场景与实验结果'),
    ('trajectory', 'fig_uav_trajectory_NL-SHADE-RSP_F{fid}.png', '代表轨迹（本任务）'),
    ('gain_heatmap', 'fig_uav_gain_heatmap_F{fid}.png', '增益热力图（本任务）'),
    ('gain_forest', 'fig_uav_gain_forest_F{fid}.png', '增益森林图（本任务）'),
    ('rank_scatter', 'fig_uav_rank_scatter_F{fid}.png', '排名散点（本任务）'),
    ('gain_heatmap_pooled', 'fig_uav_gain_heatmap.png', '增益热力图（4 任务合并）'),
    ('gain_forest_pooled', 'fig_uav_gain_forest.png', '增益森林图（4 任务合并）'),
    ('rank_scatter_pooled', 'fig_uav_rank_scatter.png', '排名散点（4 任务合并）'),
    ('terrain', 'fig_intercept_terrain_3d.png', '战场三维地形'),
]


def _read_csv_rows(path):
    """读 CSV（utf-8-sig，兼容 Excel 导出的 BOM）；文件缺失返回空表。"""
    import csv
    p = Path(path)
    if not p.is_file():
        return []
    with open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def _fnum(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _int0(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


_paper_cache = {}
_paper_lock = threading.Lock()


def paper_data(fid=1):
    """地图一（intercept）论文实验数据：F{fid} 下各宿主算法的指标与 UPCL 增益。

    ``rows[i] = {host, bare:{metric: v}, full:{...}, gain:{...}}``：分别为基线臂、
    增加 UPCL 臂的指标中位数，以及论文 ``upcl_delta.csv`` 的增益列（正 = 增加
    UPCL 后更好，方向已按指标语义统一）；另带 ``uav_rank``（跨任务综合名次，
    ``uav_value_rank.csv``）与 ``task_rank``（本任务名次，``uav_task_rank.csv``，
    4 主指标 z-score、只统计本任务）。数据未镜像到 webapp 时返回
    ``available=False``，前端据此给出提示。
    """
    fid = int(fid or 1)
    tdir = PAPER_APP_DIR / 'tables'
    cells_p = tdir / 'uav_metric_cells.csv'
    if not cells_p.is_file():
        return {'available': False, 'fid': fid}
    delta_p = tdir / 'uav_upcl_delta.csv'
    rank_p = tdir / 'uav_rank_by_fid.csv'
    value_p = tdir / 'uav_value_rank.csv'
    task_p = tdir / 'uav_task_rank.csv'
    mission_p = tdir / 'uav_mission.csv'
    key = (fid, cells_p.stat().st_mtime_ns,
           delta_p.stat().st_mtime_ns if delta_p.is_file() else 0,
           task_p.stat().st_mtime_ns if task_p.is_file() else 0,
           mission_p.stat().st_mtime_ns if mission_p.is_file() else 0)
    with _paper_lock:
        cached = _paper_cache.get(key)
    if cached is not None:
        return cached

    # 增益与指标方向（每个 cell 的每个指标一行）
    direction, gain = {}, {}
    for r in _read_csv_rows(delta_p):
        if _int0(r.get('fid')) != fid:
            continue
        m = r.get('metric') or ''
        direction[m] = r.get('direction') or 'higher_better'
        gain.setdefault(r.get('host') or '', {})[m] = _fnum(r.get('gain'))

    # 各宿主算法的基线 / 增加 UPCL 指标（论文数据里 full 与 upcl 同义）
    by_host, dim = {}, None
    for r in _read_csv_rows(cells_p):
        if _int0(r.get('fid')) != fid:
            continue
        host = r.get('host') or ''
        arm = r.get('arm') or ''
        if not host or arm not in ('bare', 'full', 'upcl'):
            continue
        arm = 'full' if arm == 'upcl' else arm
        rec = by_host.setdefault(host, {
            'host': host, 'bare': {}, 'full': {}, 'gain': gain.get(host, {})})
        if dim is None:
            dim = _int0(r.get('dim')) or None
        for m in PAPER_METRICS:
            rec[arm][m] = _fnum(r.get(m + '_median'))

    # 分级任务完成度：三列百分比并入每行的 bare/full，前端按普通指标渲染
    mission_p = tdir / 'uav_mission.csv'
    for r in _read_csv_rows(mission_p):
        if _int0(r.get('fid')) != fid:
            continue
        host = r.get('host') or ''
        if host not in by_host:
            continue
        arm = 'full' if r.get('arm') == 'upcl' else (r.get('arm') or '')
        if arm not in ('bare', 'full'):
            continue
        for key, col in PAPER_MISSION:
            v = _fnum(r.get(col))
            if v is not None:
                by_host[host][arm][key] = v / 100.0

    # 综合分 / 综合排名 / CEC 排名（论文里的跨任务综合排序）
    composite = {}
    for r in _read_csv_rows(value_p):
        host = r.get('host') or ''
        if host:
            composite[host] = {
                'composite': _fnum(r.get('composite')),
                'uav_rank': _int0(r.get('uav_rank')) or None,
                'cec_rank': _int0(r.get('cec_rank')) or None,
            }

    # 按任务名次（tables/uav_task_rank.csv：4 主指标 z-score、bare 臂、总体只限
    # 本任务）。前端「本任务名次」排序与「排名散点（本任务）」图共用此口径，
    # 保证表里 #1 与图上 #1 一致；表未镜像时前端退回自算。
    task_rank = {}
    for r in _read_csv_rows(task_p):
        if _int0(r.get('fid')) != fid:
            continue
        host = r.get('host') or ''
        if host:
            task_rank[host] = {'task_rank': _int0(r.get('task_rank')) or None,
                               'task_composite': _fnum(r.get('task_composite'))}

    rows = list(by_host.values())
    for rec in rows:
        rec.update(composite.get(rec['host'], {}))
        rec.update(task_rank.get(rec['host'], {}))
        # 完成度增益：full - bare（越高越好，单位与列一致，为 0–1 比例）
        for key, _col in PAPER_MISSION:
            b, f = rec['bare'].get(key), rec['full'].get(key)
            if b is not None and f is not None:
                rec['gain'][key] = f - b
    # 默认按综合排名排（无综合分的排最后），前端仍可点列重排
    rows.sort(key=lambda r: (r.get('uav_rank') or 999, r['host']))
    if not rows:            # 该任务没有实验数据（例如 fid 超出 1..4）
        return {'available': False, 'fid': fid}

    spearman = None
    for r in _read_csv_rows(rank_p):
        if _int0(r.get('fid')) == fid:
            spearman = {'rho': _fnum(r.get('spearman_rho')),
                        'p': _fnum(r.get('p')), 'n': _int0(r.get('n'))}
            break

    figs = []
    for k, tpl, label in PAPER_FIGURES:
        name = tpl.format(fid=fid)
        if (PAPER_APP_DIR / 'figures' / name).is_file():
            # per_task：文件名含 {fid} → 每个任务一张；否则是四个任务共用的总览图。
            # 前端据此分组显示，避免「切了任务图却没变」被误读成数据错误。
            figs.append({'key': k, 'file': name, 'label': label,
                         'per_task': '{fid}' in tpl})

    metrics = [{'key': m, 'direction': direction.get(m, 'higher_better')}
               for m in list(PAPER_METRICS) + [k for k, _c in PAPER_MISSION]
               if any(r['bare'].get(m) is not None or r['full'].get(m) is not None
                      for r in rows)]

    # 该任务实际的每次运行次数（轨迹回放按钮 R1..Rn 按此生成）
    n_runs = 3
    try:
        import json as _json
        cell = _paper_cell_path(rows[0]['host'], fid) if rows else None
        if cell is not None and cell.is_file():
            with open(cell, encoding='utf-8') as fh:
                n_runs = len((_json.load(fh).get('runs') or [])) or n_runs
    except Exception:
        pass

    out = {
        'available': True, 'scenario': 'intercept', 'fid': fid, 'dim': dim,
        'n_hosts': len(rows), 'n_runs': n_runs, 'metrics': metrics, 'rows': rows,
        'spearman': spearman, 'figures': figs,
        'tables': sorted(p.name for p in tdir.glob('*.csv')),
    }
    with _paper_lock:
        _paper_cache[key] = out
    return out


def _paper_file(sub, name, pattern):
    """论文数据目录下按文件名取文件（白名单正则，防目录穿越）。"""
    import re
    name = str(name or '')
    if not re.fullmatch(pattern, name):
        return None
    p = PAPER_APP_DIR / sub / name
    return p if p.is_file() else None


def paper_figure(name):
    """论文配图路径（仅允许 figures 下的 png）。"""
    return _paper_file('figures', name, r'[A-Za-z0-9_.\-]+\.png')


def paper_table(name):
    """论文数据表路径（仅允许 tables 下的 csv）。"""
    return _paper_file('tables', name, r'[A-Za-z0-9_.\-]+\.csv')


# ---- 论文轨迹重放：web 端真三维回放 --------------------------------------
# 论文 raw 只落盘每个 arm 的最优解 best_x（决策向量），不含逐帧轨迹。这里用与
# 论文一致的实验设置（seed / 难度 / 对手，见 src/run_uav.py 的 SEED_BASE）重建
# 环境，再对 best_x 做一次前向仿真得到逐帧轨迹，返回结构与 /api/uav/run 相同，
# 前端直接复用既有的 2D 俯视图 + three.js 三维沙盘与播放控件。

PAPER_TRACE_SEED = 20240_000        # 与 src/run_uav.py SEED_BASE 一致
PAPER_TRACE_DIR = PAPER_APP_DIR / 'raw' / 'uav_intercept' / 'D30'

_paper_problem = {}                 # fid -> problem（同 fid 地形与对手完全相同）
_paper_problem_lock = threading.Lock()
_paper_trace_cache = {}
_paper_trace_order = []
_PAPER_TRACE_MAX = 24


def _paper_problem_for(fid):
    """按论文设置重建地图一环境（intercept，D=30，同 seed 同地形同对手）。"""
    import opponents
    import uav_adversarial
    with _paper_problem_lock:
        problem = _paper_problem.get(fid)
        if problem is not None:
            return problem
        dim = int(uav_adversarial.SCENARIO_DIMS['intercept'])
        opp = opponents.make_opponent('L1', drl_algo='es', seed=PAPER_TRACE_SEED)
        problem = uav_adversarial.get_uav_problem(
            'intercept', dim=dim, fid=fid, seed=PAPER_TRACE_SEED, opponent=opp)
        _paper_problem[fid] = problem
        return problem


def _paper_cell_path(host, fid):
    """论文 cell 文件路径（宿主名里的 ``/`` 按落盘规则替换为 ``-``）。"""
    safe = str(host or '').replace('/', '-').replace('\\', '-')
    if not safe or not safe.replace('-', '').replace('_', '').replace('.', '').isalnum():
        return None
    return PAPER_TRACE_DIR / f'{safe}__F{int(fid)}.json'


def paper_trace(fid=1, host='', run=0, arm='full'):
    """重放论文实验某个 cell 的第 ``run`` 次运行（供 web 端真三维回放）。

    返回结构与 ``/api/uav/run`` 一致（frames / geometry / metrics / ...），
    另在 ``paper`` 字段附带来源信息（论文原始 err_final / 状态 / 耗时等），
    便于界面标注「这是论文第 5 章的既有结果，不是新跑的仿真」。
    """
    import json
    fid = int(fid or 1)
    run = int(run or 0)
    arm = 'bare' if str(arm).strip().lower() == 'bare' else 'full'
    cell = _paper_cell_path(host, fid)
    if cell is None or not cell.is_file():
        raise ValueError(f'no paper cell: host={host!r} fid={fid}')
    mtime = cell.stat().st_mtime_ns
    key = (fid, str(host), run, arm, mtime)
    with _paper_problem_lock:
        cached = _paper_trace_cache.get(key)
    if cached is not None:
        return cached

    with open(cell, encoding='utf-8') as fh:
        data = json.load(fh)
    runs = data.get('runs') or []
    if not (0 <= run < len(runs)):
        raise ValueError(f'run {run} out of range (cell has {len(runs)} runs)')
    run_rec = runs[run]
    rec = run_rec.get(arm) or {}
    best_x = rec.get('best_x')
    if not best_x:
        raise ValueError(f'cell {cell.name} run {run} arm {arm} has no best_x')

    problem = _paper_problem_for(fid)
    curve = [float(v) for v in (rec.get('err_curve') or [])]
    max_evals = float(data.get('max_evals') or rec.get('nevals') or len(curve) or 1)
    n = max(1, len(curve))
    evals = [max_evals * (i + 1) / n for i in range(n)]

    x = np.asarray(best_x, dtype=float)
    with _paper_problem_lock:       # problem 内含可变环境状态，重放 + 评估串行化
        cost, replay_state, frames = problem.trajectory(x)
        try:
            _, _, replay_metrics = problem.evaluate(x)
        except Exception:
            replay_metrics = None

    # 逐帧轨迹与统计都取自本次重放（同一地形 / 拦截设置 / 最优解），保证三维动画
    # 与统计数字自洽；论文实验记录（err_final / state / metrics）另存 paper.* 供
    # 对照，避免源代码版本演进造成的口径漂移被误读为回放错误。
    pm = rec.get('metrics') or {}
    if not pm and replay_metrics:
        pm = replay_metrics
    err = _fnum(rec.get('err_final'))
    last = frames[-1]['drones'] if frames else []
    r_arr = sum(1 for d in last if d[3] in (1, 4))
    r_lost = sum(1 for d in last if d[3] == 2)
    r_crash = sum(1 for d in last if d[3] == 3)
    p_arr, p_lost = _int0(pm.get('n_arrived')), _int0(pm.get('n_lost'))
    p_crash = _int0(pm.get('n_crashed'))
    out = _pack_result(problem, best_x, frames, cost, {
        'scenario': 'intercept', 'fid': fid, 'host': str(host), 'arm': arm,
        'difficulty': 'L1', 'drl_algo': 'es',
        'dim': int(data.get('dim') or len(best_x)),
        'max_evals': int(max_evals), 'evals_mult': 0,
        'seed': int(run_rec.get('seed') or 0),
        'best_f': float(cost),
        'conv': curve, 'evals': evals,
        'metrics': replay_metrics or {},      # 非 None 以免 _pack_result 重复评估
        'gen_metrics': None, 'upcl_stats': rec.get('upcl'),
        'coevolve': False, 'red_best_x': None,
        'extra': {
            'paper': {
                'source': 'results/apps/raw/uav_intercept/D30',
                'file': cell.name, 'run': run, 'arm': arm,
                'seed': run_rec.get('seed'),
                # 论文记录的终局状态码与重放的终局状态码（对照用）
                'state': _jsonable(rec.get('state')),
                'replay_state': [int(s) for s in replay_state]
                if isinstance(replay_state, (list, tuple)) else None,
                'err_final': err,
                'nevals': _int0(rec.get('nevals')),
                'wall_time_s': _fnum(rec.get('wall_time_s')),
                'metrics': _jsonable(pm),
                'paper_arrived': p_arr, 'paper_lost': p_lost,
                'paper_crashed': p_crash,
                'replay_arrived': r_arr, 'replay_lost': r_lost,
                'replay_crashed': r_crash,
                # 重放结局是否与论文记录一致（统计口径随源代码版本演进可能变化）
                'consistent': bool(r_arr == p_arr and r_lost == p_lost
                                   and r_crash == p_crash),
                'n_frames': len(frames),
                'n_steps': int(frames[-1]['step']) if frames else 0,
                'n_runs': len(runs),
            },
        },
    })
    with _paper_problem_lock:
        if key not in _paper_trace_cache:
            _paper_trace_order.append(key)
            while len(_paper_trace_order) > _PAPER_TRACE_MAX:
                _paper_trace_cache.pop(_paper_trace_order.pop(0), None)
        _paper_trace_cache[key] = out
    return out


# ---- 代表轨迹（任务 × 场景的二维代表曲线）---------------------------------
# 每个「场景 × 任务」一张二维图：同一条曲线上叠加「纯算法基线（bare）」与
# 「增加 UPCL（full）」两次代表运行。代表解取自论文 raw（只 intercept 有数据）：
# 该任务下全部宿主 × 全部 run 里 err_final（越小越好）最小的那次运行——即该任务
# 在 29 个宿主算法里能达到的最优解。其余场景没有实验数据，返回 has_data=False，
# 前端显示「暂无实验数据」占位，不伪造曲线。

_REPR_MAX_PTS = 160        # 每条曲线最多采样点（帧等间隔抽稀，末帧必保留）
_REPR_CACHE = {}           # key -> 结果；保留最近 _REPR_CACHE_MAX 个，切回算法可秒开
_REPR_CACHE_ORDER = []
_REPR_CACHE_MAX = 8
_REPR_LOCK = threading.Lock()


def _repr_cache_put(key, out):
    """写入缓存并做 LRU 淘汰（切换算法 / 运行次数时避免每次都重放仿真）。"""
    with _REPR_LOCK:
        if key in _REPR_CACHE:
            try:
                _REPR_CACHE_ORDER.remove(key)
            except ValueError:
                pass
        _REPR_CACHE[key] = out
        _REPR_CACHE_ORDER.append(key)
        while len(_REPR_CACHE_ORDER) > _REPR_CACHE_MAX:
            _REPR_CACHE.pop(_REPR_CACHE_ORDER.pop(0), None)


def _repr_scan_cell_best(fid):
    """扫描 F{fid} 的全部论文 cell，返回 (每臂最优解, cell 数, run 数, 最新 mtime)。"""
    best, n_cells, n_runs, mtime = {}, 0, 0, 0
    for cell in sorted(PAPER_TRACE_DIR.glob(f'*__F{int(fid)}.json')):
        try:
            with open(cell, encoding='utf-8') as fh:
                data = json.load(fh)
        except Exception:                       # 损坏 / 半写入的 cell 跳过
            continue
        try:
            mtime = max(mtime, cell.stat().st_mtime_ns)
        except OSError:
            pass
        runs = data.get('runs') or []
        if runs:
            n_cells += 1
        host = str(data.get('host') or cell.name.split('__')[0])
        for ri, rec in enumerate(runs):
            for arm in ('bare', 'full'):
                a = rec.get(arm) or {}
                err = _fnum(a.get('err_final'))
                if err is None or a.get('best_x') is None:
                    continue
                n_runs += 1
                cur = best.get(arm)
                if cur is None or err < cur['err_final']:
                    best[arm] = {'arm': arm, 'host': host, 'run': ri,
                                 'seed': rec.get('seed'), 'err_final': err,
                                 'best_x': a.get('best_x')}
    return best, n_cells, n_runs, mtime


def _repr_frame_subset(frames, max_pts):
    """按帧等间隔抽稀（末帧必保留），降低二维曲线的传输量。"""
    n = len(frames)
    if n <= max_pts:
        return list(frames)
    step = int(np.ceil(n / float(max_pts)))
    idx = list(range(0, n, step))
    if idx[-1] != n - 1:
        idx.append(n - 1)
    return [frames[i] for i in idx]


def _repr_tracks(frames, key, ndigits=2):
    """逐单位抽 x-y 折线（相邻重复点去重），返回 [[[x,y], ...], ...]。"""
    width = max((len(fr.get(key) or []) for fr in frames), default=0)
    out = []
    for k in range(width):
        pts = []
        for fr in frames:
            lst = fr.get(key) or []
            if k >= len(lst):
                continue
            p = [round(float(lst[k][0]), ndigits), round(float(lst[k][1]), ndigits)]
            if not pts or pts[-1] != p:
                pts.append(p)
        if len(pts) >= 2:
            out.append(pts)
    return out


def _repr_arm(problem, sel):
    """重放某臂的代表解 → 二维轨迹 + 终态统计 + 指标（与论文记录同地形/同设置）。"""
    x = np.asarray(sel['best_x'], dtype=float)
    with _paper_problem_lock:          # problem 内含可变环境状态，重放 + 评估串行化
        cost, _replay_state, frames = problem.trajectory(x)
        try:
            _, _, metrics = problem.evaluate(x)
        except Exception:
            metrics = {}
    picked = _repr_frame_subset(frames, _REPR_MAX_PTS)
    last = (picked[-1].get('drones') if picked else []) or []
    return {
        'arm': sel['arm'], 'host': sel['host'], 'run': int(sel['run']),
        'seed': sel.get('seed'),
        'err_final': round(float(sel['err_final']), 4),
        'cost': float(cost),
        'arrived': sum(1 for d in last if int(d[3]) in (1, 4)),
        'lost': sum(1 for d in last if int(d[3]) == 2),
        'crashed': sum(1 for d in last if int(d[3]) == 3),
        'final_states': [int(d[3]) for d in last],
        'metrics': _jsonable(metrics or {}),
        'n_steps': int(picked[-1]['step']) if picked else 0,
        'tracks': {
            'drones': _repr_tracks(picked, 'drones'),
            'interceptors': _repr_tracks(picked, 'interceptors'),
            'infantry': _repr_tracks(picked, 'infantry'),
        },
    }


def _repr_terrain(geo):
    """共享地形：四个任务同一张山地地图，故抽稀 + 取整后只下发一份。"""
    t = (geo or {}).get('terrain') or None
    if not t:
        return None
    xs = list(t.get('xs') or [])
    ys = list(t.get('ys') or [])
    Z = list(t.get('Z') or [])
    if not xs or not ys or not Z:
        return None
    step = max(1, int(np.ceil(len(xs) / 48.0)))
    out = {
        'xs': [round(float(v), 2) for v in xs[::step]],
        'ys': [round(float(v), 2) for v in ys[::step]],
        'Z': [[round(float(z), 1) for z in row[::step]] for row in Z[::step]],
    }
    if 'terrain_zmin' in geo:
        out['zmin'] = float(geo['terrain_zmin'])
        out['zmax'] = float(geo['terrain_zmax'])
    return out


def _repr_host_list():
    """「代表轨迹」可选的算法列表：按论文跨任务综合排名（uav_rank）排序。

    算法名取自 cell 文件名（即真正跑出数据的宿主），排名取自
    ``tables/uav_value_rank.csv``，与「任务实验数据」表的顺序保持一致。
    """
    order = {}
    for r in _read_csv_rows(PAPER_APP_DIR / 'tables' / 'uav_value_rank.csv'):
        h = r.get('host') or ''
        if h:
            order[h] = (_int0(r.get('uav_rank')) or 999, _fnum(r.get('composite')))
    out = []
    for p in sorted(PAPER_TRACE_DIR.glob('*__F1.json')):
        h = p.name.split('__')[0]
        rk, comp = order.get(h, (999, None))
        out.append({'host': h, 'uav_rank': None if rk >= 999 else rk,
                    'composite': comp})
    out.sort(key=lambda x: (x['uav_rank'] or 999, x['host']))
    return out


def _repr_run_count(fid):
    """单个 cell 的运行次数（run 下拉用；同一 fid 的各 cell 一致）。"""
    for cell in sorted(PAPER_TRACE_DIR.glob(f'*__F{int(fid)}.json')):
        try:
            with open(cell, encoding='utf-8') as fh:
                return len(json.load(fh).get('runs') or [])
        except Exception:
            continue
    return 0


def _repr_host_arms(problem, host, fid, run):
    """重放「指定算法 · 第 run 次运行」的两臂。

    bare 与 full 取**同一个 run**（同 seed），这才构成 UPCL 的公平对比，
    与论文图 5-7（NL-SHADE-RSP / F1）的口径一致。默认的「全局最优」模式
    两臂各自取全部算法里的最好一次，不能用来评价 UPCL 增益，故两者分开标注。
    """
    cell = _paper_cell_path(host, fid)
    if cell is None or not cell.is_file():
        return []
    try:
        with open(cell, encoding='utf-8') as fh:
            data = json.load(fh)
    except Exception:
        return []
    runs = data.get('runs') or []
    run = int(run)
    if not (0 <= run < len(runs)):
        return []
    rec = runs[run]
    arms = []
    for arm in ('bare', 'full'):
        a = rec.get(arm) or {}
        err = _fnum(a.get('err_final'))
        if err is None or a.get('best_x') is None:
            continue
        arms.append(_repr_arm(problem, {
            'arm': arm, 'host': host, 'run': run, 'seed': rec.get('seed'),
            'err_final': err, 'best_x': a.get('best_x')}))
    return arms


def repr_trajectories(host='', run=0):
    """4 个场景 × 4 个任务的二维代表轨迹（bare vs full 双曲线）与战场几何。

    两种对比口径，由 ``host`` 决定：

    * ``host`` 为空（默认，全局最优）——每个臂各自取该任务下「全部宿主 × 全部
      run」里 err_final 最小的那次运行，回答「这个任务最好能飞到什么程度」。
      两臂可能来自不同算法，所以**不能**用来评价 UPCL 的增益。
    * ``host`` 非空（指定算法）——固定该宿主第 ``run`` 次运行的两臂（同 seed），
      回答「这个算法加上 UPCL 改变了什么」，这才是 UPCL 的公平对比口径。

    数据源：``results/apps/raw/uav_intercept/D30/*.json``（论文第 5 章实验）。
    只有 intercept 有实验数据，其余场景返回 ``has_data=False``。
    """
    import uav_adversarial
    host = str(host or '').strip()
    run = int(run or 0)
    scenarios = list(uav_adversarial.list_scenarios())
    # 有实验数据的 intercept 排在最前，其余按名字序（与前端场景下拉保持一致）
    scenarios.sort(key=lambda s: (0 if s == 'intercept' else 1, s))

    sig, scans = [], {}
    for fid in range(1, 5):
        best, n_cells, n_runs, mtime = _repr_scan_cell_best(fid)
        scans[fid] = (best, n_cells, n_runs)
        sig.append((fid, n_cells, n_runs, mtime))
    key = ('v2', host, run, tuple(sig))
    with _REPR_LOCK:
        cached = _REPR_CACHE.get(key)
    if cached is not None:
        return cached

    out_scen = []
    for scen in scenarios:
        nf = int(uav_adversarial.SCENARIO_NFUNCS.get(scen, 1))
        tasks = []
        for fid in range(1, nf + 1):
            ti = uav_adversarial.task_info(scen, fid) or {}
            task = {'fid': fid, 'name': ti.get('name') or f'{scen} task {fid}',
                    'has_data': False, 'arms': [], 'geometry': None}
            if scen == 'intercept':
                best, n_cells, n_runs = scans.get(fid, ({}, 0, 0))
                problem = None
                if host:
                    cell = _paper_cell_path(host, fid)
                    if cell is not None and cell.is_file():
                        problem = _paper_problem_for(fid)
                        task['arms'] = _repr_host_arms(problem, host, fid, run)
                elif best:
                    problem = _paper_problem_for(fid)
                    task['arms'] = [_repr_arm(problem, best[a])
                                    for a in ('bare', 'full') if a in best]
                if task['arms'] and problem is not None:
                    with _paper_problem_lock:
                        task['geometry'] = _jsonable(_geometry(problem))
                    task['has_data'] = True
                task['source'] = {
                    'dir': 'results/apps/raw/uav_intercept/D30',
                    'n_cells': n_cells, 'n_runs': n_runs,
                    'mode': 'host' if host else 'global',
                    'host': host or None,
                    'run': run if host else None,
                }
            tasks.append(task)
        out_scen.append({
            'scenario': scen,
            'name': uav_adversarial.SCENARIO_NAMES.get(scen, scen),
            'dim': int(uav_adversarial.SCENARIO_DIMS.get(scen, 0) or 0),
            'has_data': any(t['has_data'] for t in tasks),
            'tasks': tasks,
        })

    # 地形在四个任务间完全相同（同一 seed 建环境），抽稀后提升为共享字段，
    # 各任务只保留差异部分（禁飞区 / 拦截者 / 雷达 / 楼房等），体积降一个数量级。
    terrain = None
    for s in out_scen:
        for t in s['tasks']:
            if t['has_data'] and t.get('geometry'):
                terrain = _repr_terrain(t['geometry']) or terrain
                break
        if terrain:
            break
    if terrain:
        for s in out_scen:
            for t in s['tasks']:
                if t.get('geometry'):
                    t['geometry'].pop('terrain', None)

    out = {
        'available': any(s['has_data'] for s in out_scen),
        'scenarios': out_scen,
        'terrain': terrain,
        'max_pts': _REPR_MAX_PTS,
        'hosts': _repr_host_list(),        # 算法下拉：29 个宿主 + 论文综合排名
        'selected_host': host,             # '' = 全局最优口径
        'selected_run': run,
        'n_runs': _repr_run_count(1),      # run 下拉的项数
    }
    _repr_cache_put(key, out)
    return out


# ---------------------------------------------------------------------------
# 红方优化课题（F1 兵力部署 / F2 预警 / F3 拦截 / F4 协同）
# ---------------------------------------------------------------------------
# 红方问题由 src/uav_red.py 的 ``RedProblem`` 提供，与蓝方 ``uav_adversarial`` 是
# **并列关系**：蓝方优化「怎么突进去」，红方优化「怎么防住一批固定的蓝方」。本段把
# 红方接进 Web —— 元数据 / 课题说明 / 同步执行 / 结果打包，几何、帧协议与存档都复用
# uav_api 已有的实现，因此红方结果同样能进 3D 沙盘回放与存档对比。
RED_ENV_SEED = 20_240_000        # 红方评估的环境 seed，与 src/run_red_smoke.py 一致
RED_SCENARIO = 'red'             # 存档目录名：/api/uav/archive?scenario=red
RED_DEFAULT_MODE = 'intercept'
RED_FIDS = (1, 3, 4)             # 界面允许的想定（与蓝方实景突防场景一致）

# 结果表展示的红方视角指标：(metrics 键, 中文名, 期望方向)
RED_METRIC_ROWS = (
    ('n_arrived', '蓝方突防成功', 'lower'),
    ('n_lost', '蓝方被击落', 'higher'),
    ('first_capture', '首次交战时刻', 'lower'),
    ('risk_time', '暴露时长占比', 'lower'),
    ('min_dist', '蓝方最近接近距离', 'higher'),
    ('n_patrol_killed', '巡逻兵被击杀', 'lower'),
    ('patrol_survival', '巡逻兵存活率', 'higher'),
    ('infantry_survival', '步兵存活率', 'higher'),
    ('n_inf_arrived', '步兵突入数', 'lower'),
    ('base_hp', '基地剩余血量', 'higher'),
    ('flight_time', '蓝方平均滞空', 'lower'),
    ('nofly_steps', '禁飞区侵入步数', 'lower'),
)

# 指标「实体描述」：这一项到底衡量什么（界面节点信息里的「描述」取这里；
# 结果表字段名与期望方向属于「参数」，由 RED_METRIC_ROWS 的另一列给出）。
RED_METRIC_DOC = {
    'n_arrived': '蓝方成功抵达基地的架次：衡量突防是否得手，红方最该压下去的一项。',
    'n_lost': '被红方火力击落的蓝方架次：拦截效果的直接体现，越高越好。',
    'first_capture': '红方首次捕获蓝方的时刻：越早说明预警与拦截链路反应越快。',
    'risk_time': '蓝方全程暴露在红方火力下的时长占比：越高说明拦阻压力越持续。',
    'min_dist': '蓝方与基地的最近接近距离：反映防线是否被压到门口。',
    'n_patrol_killed': '被蓝方击杀的巡逻兵数量：衡量地面静态力量的生存代价。',
    'patrol_survival': '巡逻兵存活比例：越高说明部署位置越扛打。',
    'infantry_survival': '步兵存活比例：衡量近距防御力量在突防火力下的损失。',
    'n_inf_arrived': '突入基地的蓝方步兵数：地面突入是否成功的判据。',
    'base_hp': '基地剩余血量：任务成败的最终底牌。',
    'flight_time': '蓝方平均滞空时长：滞空越久越容易被打，红方希望它偏大。',
    'nofly_steps': '蓝方侵入禁飞区的步数：约束 C1 被违反的量化口径。',
}


def _red_meta_payload():
    """红方课题的元数据（挂在 ``/api/uav/meta`` 的 ``red`` 字段）。

    前端据此在「场景」下拉里加一个 ``value='red'`` 的并列入口，并在切到红方模式后
    渲染「红方课题 / 蓝方对手」两个下拉。
    """
    import uav_red as UR
    return {
        'topics': UR.topic_table(),
        'topic_order': list(UR.MODE_SLOTS),
        'topic_names': dict(UR.MODE_NAMES),
        'default_mode': RED_DEFAULT_MODE,
        'fids': list(RED_FIDS),
        'opponents': [{'key': k, 'label': lb, 'text': tx}
                      for k, lb, tx in UR.OPPONENT_DOC],
        'defaults': {'mode': RED_DEFAULT_MODE, 'fid': 1, 'opponent': 'straight',
                     'evals_mult': 200, 'blue_runs': 3, 'blue_evals': 2000},
        'env_seed': RED_ENV_SEED,
        'scenario': RED_SCENARIO,
    }


def describe_uav_red(mode=RED_DEFAULT_MODE, fid=1):
    """红方课题的完整结构化说明（Web「课题说明」弹窗用）。

    约束清单来自 ``uav_red.CONSTRAINT_DOC``，与代码里的 ``check()`` 同源，
    因此界面上「C5 本课题已豁免」的说法与实现永远一致。
    """
    import uav_red as UR
    return _jsonable(UR.describe_topic(str(mode), int(fid)))


class _RedGeoShim:
    """只为复用 :func:`_geometry` —— 它只读 ``scenario`` / ``cfg`` / ``env`` 三样。"""

    scenario = 'intercept'

    def __init__(self, cfg, env):
        self.cfg = cfg
        self.env = env


def solve_blue_opponent(fid, host_name, runs=3, evals=2000, seed=1,
                        cancel_event=None, progress_cb=None):
    """求蓝方最优突防方案（best-of-``runs``），作为红方优化的固定对手。

    与 ``src/run_red_smoke.py`` 的 ``solve_blue`` 保持同一口径：单次 DE 的蓝方方案
    往往突不进去（红方任务退化成全平），取多次独立运行中蓝方代价最低的一个，
    红方才真正有优化空间。
    """
    import de_hosts
    import uav_adversarial
    prob = uav_adversarial.get_uav_problem('intercept', fid=int(fid), seed=RED_ENV_SEED)
    n = max(1, int(runs))
    best_f, best_x, wall = float('inf'), None, 0.0
    for r in range(n):
        if cancel_event is not None and cancel_event.is_set():
            raise RuntimeError('cancelled')
        host = de_hosts.get_host(host_name, prob.dim, prob.lb, prob.ub,
                                 seed=int(seed) * 1000 + r)
        t0 = time.perf_counter()
        f, x, _conv, _ev = host.run(prob, int(evals))
        wall += time.perf_counter() - t0
        if float(f) < best_f:
            best_f, best_x = float(f), np.asarray(x, dtype=float)
        if progress_cb is not None:
            progress_cb(r + 1, n)
    _c, _st, metrics = prob.evaluate(best_x)
    return {'x': best_x, 'cost': float(best_f), 'metrics': _jsonable(metrics),
            'wall_s': float(wall), 'runs': n, 'evals': int(evals), 'host': host_name}


def run_uav_red(mode=RED_DEFAULT_MODE, fid=1, host_name='NL-SHADE-RSP',
                evals_mult=200, opponent='straight', blue_runs=3, blue_evals=2000,
                seed=1, progress_cb=None, cancel_event=None):
    """在调用线程内同步执行一次红方优化（由 server 的后台线程调用）。

    ``progress_cb(nevals, max_evals)`` 在 DE 迭代中回调；``cancel_event`` 置位时抛
    ``RuntimeError('cancelled')``。返回结构与 ``/api/uav/run`` 同源，可直接回放。
    """
    import de_hosts
    import de_hosts_cec as DHC
    import uav_red as UR

    mode = str(mode)
    if mode not in UR.MODE_SLOTS:
        raise ValueError(f'未知红方课题：{mode}')
    fid = int(fid)
    base_cfg = UR._intercept_cfg(fid)

    # ---- 1. 固定蓝方对手（直扑 / best-of-N 强突防） ----------------------
    t0 = time.perf_counter()
    blue = None
    if str(opponent) == 'best':
        blue = solve_blue_opponent(fid, host_name, runs=blue_runs, evals=blue_evals,
                                   seed=seed, cancel_event=cancel_event)
        blue_x = blue['x']
    else:
        blue_x = UR.straight_blue_x(base_cfg)
    blue_wall = time.perf_counter() - t0

    # ---- 2. 红方 DE 优化 --------------------------------------------------
    problem = UR.RedProblem(mode, fid=fid, seed=RED_ENV_SEED, blue_x=blue_x)
    dim = int(problem.dim)
    max_evals = int(evals_mult) * dim
    host = de_hosts.get_host(host_name, dim, problem.lb, problem.ub, seed=int(seed),
                             pop_size=DHC.pop_size_for(host_name, dim))

    def _cb(h):
        if cancel_event is not None and cancel_event.is_set():
            raise RuntimeError('cancelled')
        if progress_cb is not None:
            progress_cb(int(h.nevals), max_evals)

    t1 = time.perf_counter()
    best_f, best_x, conv, eval_points = host.run(problem, max_evals, callback=_cb)
    opt_wall = time.perf_counter() - t1

    # ---- 3. 最优解 vs 真基线（出厂红方配置）逐指标对比 --------------------
    best_x = np.asarray(best_x, dtype=float).ravel()
    final = UR.red_evaluate(best_x, mode, base_cfg, blue_x=blue_x,
                            seed=RED_ENV_SEED, want_frames=True)
    baseline = UR.evaluate_base(base_cfg, blue_x=blue_x, seed=RED_ENV_SEED)
    is_best = (str(opponent) == 'best')
    return _pack_red_result(best_x, final, baseline, blue, conv, eval_points, {
        'mode': mode, 'mode_name': UR.MODE_NAMES.get(mode, mode),
        'fid': fid, 'host': host_name, 'opponent': str(opponent),
        'opponent_label': (f'强突防（best-of-{max(1, int(blue_runs))}）' if is_best
                           else '直扑基地'),
        'blue_runs': max(1, int(blue_runs)) if is_best else 0,
        'blue_evals': int(blue_evals) if is_best else 0,
        'dim': dim, 'max_evals': max_evals, 'evals_mult': int(evals_mult),
        'seed': int(seed), 'best_f': float(best_f),
        'opt_wall_s': opt_wall, 'blue_wall_s': blue_wall,
        'wall_time_s': opt_wall + blue_wall,
    })


def _red_metrics(res):
    """红方视角的关键仿真指标（有序，界面结果表直接用）。"""
    rows = []
    for key, label, direction in RED_METRIC_ROWS:
        v = res.get(key)
        if v is None:
            continue
        rows.append({'key': key, 'label': label, 'direction': direction,
                     'value': float(v)})
    return rows


def _red_delta(base, opt):
    """逐指标变化量（opt − base；方向含义见 RED_METRIC_ROWS）。"""
    rows = []
    for key, label, direction in RED_METRIC_ROWS:
        b, o = base.get(key), opt.get(key)
        if b is None or o is None:
            continue
        rows.append({'key': key, 'label': label, 'direction': direction,
                     'base': float(b), 'opt': float(o),
                     'delta': float(o) - float(b)})
    return rows


def _red_violations(res):
    """违约条目（带约束编号 C1..C6），界面据此显示「哪条约束被违反」。"""
    import uav_red as UR
    out = []
    for v in res.get('violations') or []:
        name = str(v[0])
        out.append({'code': UR.VIOLATION_CODES.get(name, ''),
                    'name': name,
                    'severity': float(v[1]) if len(v) > 1 else 0.0,
                    'text': str(v[2]) if len(v) > 2 else ''})
    return out


def _pack_red_result(best_x, final, baseline, blue, conv, eval_points, meta):
    """把一次红方优化打包成前端可渲染的结构（复用蓝方的几何与帧协议）。"""
    import uav_adversarial
    import uav_red as UR

    cfg = final['cfg']
    frames = final.get('frames') or []

    geometry = None
    try:
        env = uav_adversarial.UAVEnv(cfg, seed=RED_ENV_SEED,
                                     layout=final.get('layout'))
        geometry = _jsonable(_geometry(_RedGeoShim(cfg, env)))
    except Exception:
        geometry = None

    last = frames[-1]['drones'] if frames else []
    n_arr = sum(1 for d in last if d[3] in (1, 4))
    n_lost = sum(1 for d in last if d[3] == 2)
    n_crash = sum(1 for d in last if d[3] == 3)

    return {
        'scenario': RED_SCENARIO,
        'red_mode': meta['mode'],
        'red_mode_name': meta['mode_name'],
        'fid': int(meta['fid']),
        'host': meta['host'],
        'arm': 'red',
        'opponent': meta['opponent'],
        'opponent_label': meta['opponent_label'],
        'blue_runs': int(meta['blue_runs']),
        'blue_evals': int(meta['blue_evals']),
        'dim': int(meta['dim']),
        'max_evals': int(meta['max_evals']),
        'evals_mult': int(meta['evals_mult']),
        'seed': int(meta['seed']),
        'best_f': float(meta['best_f']),
        'evals': _jsonable(eval_points),
        'conv': _jsonable(conv),
        'wall_time_s': float(meta['wall_time_s']),
        'opt_wall_s': float(meta['opt_wall_s']),
        'blue_wall_s': float(meta['blue_wall_s']),
        'best_x': [float(v) for v in best_x],
        # 结果与可行性
        'cost': float(final['cost']),
        'objective': float(final['objective']),
        'penalty': float(final['penalty']),
        'feasible': bool(final['feasible']),
        'n_violations': int(final.get('n_violations', 0)),
        'violations': _red_violations(final),
        'metrics': _red_metrics(final),
        'coverage': {'gap': float(final.get('coverage_gap', 0.0)),
                     'deploy': float(final.get('deploy_cost', 0.0)),
                     'radar_range_eff': float(final.get('radar_range_eff', 0.0))},
        # 真基线（未经优化的出厂红方配置）
        'baseline': {
            'cost': float(baseline['cost']),
            'objective': float(baseline['objective']),
            'penalty': float(baseline['penalty']),
            'feasible': bool(baseline['feasible']),
            'metrics': _red_metrics(baseline),
        },
        'delta': _red_delta(baseline, final),
        # 最优解的可读描述（RedPlan.describe 的中文键值表）
        'plan': _jsonable(final.get('plan_desc') or {}),
        'plan_items': _jsonable([{'type': t, 'x': float(x), 'y': float(y)}
                                 for t, x, y in (final.get('units') or [])]),
        'formation': UR.fid_summary(cfg),
        'constraints': UR.constraints_for(meta['mode']),
        'describe': _jsonable(cfg.describe()),
        'geometry': geometry,
        'frames': _pack_combat_frames(frames, 'intercept'),
        'arrived': n_arr, 'lost': n_lost, 'crashed': n_crash,
        'n_drones': int(cfg.n_drones),
        'blue': ({'cost': blue['cost'], 'metrics': blue['metrics'],
                  'runs': blue['runs'], 'evals': blue['evals'],
                  'host': blue['host'], 'wall_s': blue['wall_s']}
                 if blue else None),
        'header': {
            'title': f'红方 · {meta["mode_name"]} · F{int(meta["fid"])}',
            'subtitle': (f'{meta["host"]} · 对手：{meta["opponent_label"]} · '
                         f'预算 {int(meta["evals_mult"])}×D={int(meta["dim"])}'),
        },
    }

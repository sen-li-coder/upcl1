# -*- coding: utf-8 -*-
"""多用户 workspace 路径解析：用户私有目录优先，公共目录兜底。

每个登录用户拥有独立数据目录 ``data/users/<username>/``，其下的实验结果、
插件、UAV 存档互不可见；公共基准数据仍位于 ``results/cec/``，对所有登录
用户只读可见（私有数据在同名 cell 上覆盖公共数据）。
"""
from pathlib import Path

from . import constants as C


def user_dir(username):
    """用户私有数据根目录。"""
    return C.DATA_DIR / 'users' / username


def user_results(username):
    return user_dir(username) / 'results' / 'cec'


def user_raw(username):
    return user_results(username) / 'raw'


def user_logs(username):
    return user_results(username) / 'logs'


def user_tables(username):
    return user_results(username) / 'tables'


def user_figures(username):
    return user_results(username) / 'figures'


def user_plugins(username):
    return user_dir(username) / 'plugins'


def user_uav(username):
    return user_dir(username) / 'uav'

# -*- coding: utf-8 -*-
"""Web 前后端分离改造：FastAPI 后端 + 纯 HTML/ECharts 前端。

替代原 Tkinter GUI（gui_launcher.py），计算层复用 src/ 下现有模块，
不重写任何实验/仿真逻辑。
"""

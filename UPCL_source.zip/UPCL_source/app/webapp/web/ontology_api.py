# -*- coding: utf-8 -*-
"""UAV 红方「优化模型本体 / 知识图谱」生成（Web「本体与知识图谱」页的数据源）。

设计原则：**代码里的注册表是唯一事实来源**。本模块不读任何外部本体文件，也不另写
一份文案，所有概念 / 关系 / 数值都从既有注册表当场生成，因此页面上看到的内容与
仿真实现永远一致。

数据源（全部来自既有代码）::

    src/uav_red.py
        MODE_SLOTS / MODE_NAMES / MODE_DOC / SLOT_NAMES / SLOT_DOC / SLOT_ROI / ROI /
        SCALAR_RANGE / CONSTRAINT_DOC / OPPONENT_DOC / C5_EXEMPT_MODES / RED_SCENARIOS /
        describe_topic / topic_table / fid_summary
    src/uav_red.py  RedConstraints.check
        C1–C6 各自真正检查哪些单元 → :data:`CONSTRAINT_UNITS`（逐条对应 check 里
        ``# C1`` … ``# C6`` 的分支；新增约束若忘了登记会在 ``warnings`` 里报出）
    src/uav_red.py  apply_plan
        槽位写进 EnvConfig 的哪一项 → :data:`SLOT_UNITS`（决定变量作用于哪个单元）
    src/uav_adversarial.py
        list_scenarios / SCENARIO_LABELS / TASK_NAMES / task_info（场景与想定清单）
    app/webapp/web/uav_api.py
        RED_FIDS（想定编号）/ RED_METRIC_ROWS + RED_METRIC_DOC（结果表指标口径）

节点信息 = **文字描述 + 技术参数两段**：``desc`` 是给使用者直接读的**文字描述**，说明
这个实体是什么、在战场语境里意味着什么（课题取 ``MODE_DOC``、槽位取 ``SLOT_DOC``、
约束取 ``CONSTRAINT_DOC`` 文案、指标取 ``RED_METRIC_DOC``），并经 :func:`_prose` 把
残留的代码标识（常量名 / 权重键）换成中文说法，因此 ``desc`` 里不出现代码参数；
``params`` 才是维度 / 取值区间 / 部署区域 / 罚分项名 / 结果表列名这类**技术参数**，
界面上只作次要小字展示，不承担「描述」职能。（``detail`` 保留为两者合并文本，供导出
与老接口兼容。）

两张图的分工：

- **ontology（本体）**：类别 / 元模型层——根问题 → 课题 → 决策变量 → 单元类型 →
  约束 →（目标项 / 对手 / 评估指标），回答「这个优化问题由哪些概念、哪些关系构成」；
- **kg（知识图谱）**：实例层——场景 / 想定 → 课题 → 单元（带编成）→ 约束（带生效 /
  豁免）→ 指标，回答「F1–F4 四个课题实际长什么样」。

两张图在前端都提供**多种绘图形式**（网络图 / 分层树图 / 旭日图 / 明细表）与「节点上
是否直接显示文字描述」开关：形式切换只影响画法，数据始终是这里生成的那一份；明细表
形式把文字描述与关系整列、直接可读，不必逐点悬停。后端不参与画法选择，只负责把
``nodes`` / ``edges`` / ``layers`` 原样下发。

两张图都支持按 **场景 + 想定 + 课题** 三维筛选（:func:`filter_options` 给出候选项）：
三个维度都给值就是「某个场景下某个想定的某个课题」这一张子图，维度 / 部署区域 /
单元编成 / 生效与豁免约束都按该 (场景, 想定, 课题) 的真实口径重算。被豁免的约束用
``rel='exemptFrom'`` 的灰虚线表达（不再靠「缺边」暗示），因此「这条约束管这个模型、
但这套任务不用它」在图上一眼可见。

**场景维度是显式的**：红方模型目前只在 ``uav_red.RED_SCENARIOS`` 登记的场景
（intercept）下有完整口径；切到未登记的红方场景（swarm）时给出**缺口视图**
（:func:`_build_unregistered`，节点类型 ``Gap``），逐条列出「代码里已经有什么」
与「还缺哪些注册表」，绝不静默套用 intercept 的数值。

另有一个非图形态视图：:func:`constraint_matrix` 输出「约束 × 课题」矩阵（行 = C1–C6，
列 = F1–F4，格 = 生效 / 豁免 + 检查单元 + 各想定维度），把豁免关系一次看全。

导出：:func:`export_graph` 把图摊平成 (subject, predicate, object) 三元组，可选
JSON-LD（喂 GraphRAG / 图数据库）或 CSV（喂 Neo4j ``LOAD CSV`` 或表格核对）。
"""
import csv
import io
import json
from datetime import datetime
from typing import Dict, List, Optional, Sequence, Tuple

from . import constants as C                                    # noqa: F401
# ↑ 仅为副作用：constants 会把 ``src`` 注入 sys.path，``uav_red`` 才可导入（与
#   uav_api 的做法一致）。

# 命名空间与前缀：导出时用 ``uo:Topic.deploy`` 这类前缀缩写，便于人工核对。
NS = 'https://lase.local/uav/red#'
PREFIX = 'uo'
ROOT_ID = 'RedDefenseProblem'

# 节点类型 -> (颜色, 类型中文名, 半径)。颜色只服务可视化，不参与导出语义。
TYPE_STYLE: Dict[str, Tuple[str, str, int]] = {
    'Root': ('#1D4ED8', '根问题', 62),
    'Scenario': ('#5A6B7A', '想定', 44),
    'Topic': ('#2F6F4F', '课题', 46),
    'Slot': ('#7A52C7', '决策变量', 26),
    'Unit': ('#B06F18', '防御单元', 40),
    'Constraint': ('#C0392B', '约束', 34),
    'ObjectiveTerm': ('#0F7B8A', '目标项', 28),
    'Opponent': ('#8A5A2B', '蓝方对手', 30),
    'Metric': ('#3A5F8A', '评估指标', 22),
    # 未注册项：某场景下红方模型还没登记的部分（只出现在缺口视图，取中性灰以免被
    # 误读成一种真实的模型元素）
    'Gap': ('#6B7280', '未注册（缺口）', 34),
}

# 关系（谓词）-> 中文边标签
PRED_LABELS: Dict[str, str] = {
    'hasTopic': '包含课题',
    'hasVariable': '含决策变量',
    'actsOn': '作用于',
    'appliesTo': '判罚（生效课题）',
    'constrainsUnit': '约束单元',
    'hasObjectiveTerm': '目标函数项',
    'hasOpponent': '固定对手口径',
    'evaluates': '评估指标',
    'allowsTopic': '可选课题',
    'penalizes': '判罚（生效课题）',
    'measuredBy': '评估指标',
    'hasScenario': '含想定',
    # 缺口视图：场景 → 尚未登记的注册表
    'missingRegistration': '未注册',
    # 豁免关系：约束与课题之间「管得着但不用」的那条边（灰虚线 + 「豁免」标注）
    'exemptFrom': '豁免（不判罚）',
}

# 单元类型（键 = RedPlan.units() 里的 kind）
UNIT_DOC: Tuple[Tuple[str, str, str], ...] = (
    ('radar', '雷达站',
     '预警传感器：全图唯一的远程传感器，负责提前发现来袭目标。它是传感器而不是火力，'
     '不参与静态火力覆盖（否则会出现「把探测半径顶满就能刷低覆盖缺口」的刷分路径）。'
     '它由部署坐标与探测距离 / 主瓣方位 / 半张角 / 扫描周期 / 告警阈值共同决定。'),
    ('helipad', '停机坪',
     '拦截机的出动基地：决定拦截机能否在蓝方打完之前到位，是拦截效果的主导杠杆；'
     '拦截课题与协同课题豁免「停机坪须在雷达外」这条约束后，它可以前推到全图任意位置。'),
    ('aa', '防空车',
     '近距火力单元：部署位置既要能在射程内拱卫基地，又要贡献静态火力覆盖。'),
    ('patrol', '巡逻兵',
     '分区巡逻步兵：以若干个分区中心为决策变量，在各中心附近确定性散开，提供区域'
     '静态覆盖。'),
    ('interceptor', '拦截机',
     '机动拦截单元：由出动基地（停机坪）、巡逻航路航点，以及协同课题加的调度层'
     '（主责分配 / 责任区边界 / 逐机出动阈值）共同刻画。'),
)

# 槽位 -> 作用单元（据 apply_plan 把这些槽位写进 cfg 的哪一项）
SLOT_UNITS: Dict[str, Tuple[str, ...]] = {
    'radar_xy': ('radar',),
    'helipads': ('helipad',),
    'aa_pos': ('aa',),
    'patrol_anchors': ('patrol',),
    'radar_range': ('radar',),
    'radar_azimuth': ('radar',),
    'radar_half_angle': ('radar',),
    'scan_period': ('radar',),
    'alert_threshold': ('radar',),
    'int_routes': ('interceptor',),
    # F4 行序是「防空车在前 n_aa 行、拦截机在后 n_int 行」，故主责分配与责任区同时
    # 作用于两类火力单元；逐机出动阈值只作用于拦截机。
    'assign': ('aa', 'interceptor'),
    'sector_bounds': ('aa', 'interceptor'),
    'launch_threshold': ('interceptor',),
}

# 约束 -> 被检查的单元（据 RedConstraints.check 的 # C1..# C6 分支）
CONSTRAINT_UNITS: Dict[str, Tuple[str, ...]] = {
    'no_fly': ('radar', 'helipad', 'aa', 'patrol', 'interceptor'),   # units() + 航点
    'radar_base': ('radar',),
    'min_sep': ('radar', 'helipad', 'aa', 'patrol'),
    'aa_cover': ('aa',),
    'helipad_in_radar': ('helipad', 'radar'),
    'route_nofly': ('interceptor',),
}

# 目标项权重键（顺序与 uav_red.describe_topic()['objective'] 一致）
OBJECTIVE_KEYS: Tuple[str, ...] = (
    'w_arrive', 'w_lost', 'w_early', 'w_risk', 'w_gap', 'w_deploy',
)
DIR_TEXT = {'lower': '越低越好', 'higher': '越高越好'}


# ===========================================================================
# 基础工具
# ===========================================================================

def _ur():
    """延迟导入 ``uav_red``（src 目录由启动脚本注入 sys.path）。"""
    import uav_red
    return uav_red


def _red_fids() -> Tuple[int, ...]:
    try:
        from .uav_api import RED_FIDS
        return tuple(int(f) for f in RED_FIDS)
    except Exception:                                       # pragma: no cover - 兜底
        return (1, 3, 4)


def _metric_rows() -> Tuple[Tuple[str, str, str], ...]:
    try:
        from .uav_api import RED_METRIC_ROWS
        return tuple(RED_METRIC_ROWS)
    except Exception:                                       # pragma: no cover - 兜底
        return ()


def _metric_docs() -> Dict[str, str]:
    """指标「实体描述」（key -> 这一项衡量什么），取自 :data:`uav_api.RED_METRIC_DOC`。"""
    try:
        from .uav_api import RED_METRIC_DOC
        return {str(k): str(v) for k, v in RED_METRIC_DOC.items()}
    except Exception:                                       # pragma: no cover - 兜底
        return {}


# 视图筛选（场景 / 想定 / 课题）：``None`` / ``''`` / ``'all'`` / ``'全部'`` 均表示
# 「该维度不筛」，即总览；三个维度都给值 → 单任务子图（前端默认入口）。
_ALL_TOKENS: Tuple[str, ...] = ('', 'all', '全部', '*', 'none', 'null', '-1')


def _scenario_mod():
    """延迟导入 ``uav_adversarial``（场景注册表：list_scenarios / SCENARIO_LABELS）。"""
    import uav_adversarial
    return uav_adversarial


def _scenario_values() -> Tuple[str, ...]:
    """全部可选场景（与 ``src/uav_adversarial`` 的场景注册同源）。"""
    try:
        return tuple(str(s) for s in _scenario_mod().list_scenarios())
    except Exception:                                       # pragma: no cover - 兜底
        return ('intercept', 'swarm')


def _scenario_label(scenario: Optional[str], short: bool = False) -> str:
    """场景中文名（``short=True`` 取短名，用于标题 / 状态行这类空间有限处）。"""
    if not scenario:
        return '全部场景'
    try:
        return str(_scenario_mod().scenario_label(scenario, short=short))
    except TypeError:                                       # 旧副本无 short 形参
        try:
            return str(_scenario_mod().scenario_label(scenario))
        except Exception:                                   # pragma: no cover - 兜底
            return str(scenario)
    except Exception:                                       # pragma: no cover - 兜底
        return str(scenario)


def _red_registered(scenario: str) -> bool:
    """该场景是否登记了红方模型（注册表是 ``uav_red.RED_SCENARIOS``）。"""
    return str(scenario) in tuple(getattr(_ur(), 'RED_SCENARIOS', ('intercept',)))


def _registered_scenario_text() -> str:
    """已登记红方模型的场景短名串（提示文案共用，避免把 ``intercept`` 裸名写进界面）。"""
    reg = tuple(getattr(_ur(), 'RED_SCENARIOS', ()) or ())
    return '、'.join(_scenario_label(s) for s in reg) or '（无）'


def _unregistered_scenario_text() -> str:
    """未登记红方模型的场景短名串（缺口提示用「如 …」）。"""
    un = [s for s in _scenario_values() if not _red_registered(s)]
    return '、'.join(_scenario_label(s) for s in un)


def _fid_names(scenario: str = 'intercept') -> Dict[int, str]:
    """想定短名（与前端「想定」下拉同源：基线突防 / 双机拦截 …）。"""
    try:
        names = getattr(_scenario_mod(), 'TASK_NAMES', {}).get(str(scenario), {})
        return {int(k): str(v) for k, v in names.items()}
    except Exception:                                       # pragma: no cover - 兜底
        return {}


def _scenario_fids(scenario: str) -> Tuple[int, ...]:
    """该场景下参与本视图的想定编号。

    已登记红方模型的场景（intercept）取红方指标口径的想定集（``RED_FIDS``，与结果表
    想定一致）；未登记的场景则以该场景自身的任务集为准（只用于缺口视图）。
    """
    if _red_registered(scenario):
        return _red_fids()
    try:
        return tuple(sorted(int(k) for k in
                            getattr(_scenario_mod(), 'TASK_NAMES', {}).get(str(scenario), {})))
    except Exception:                                       # pragma: no cover - 兜底
        return ()


def _fid_options(scenario: str) -> List[dict]:
    names = _fid_names(scenario)
    return [{'value': int(f), 'label': f'U{int(f)} {names.get(int(f), "")}'.strip()}
            for f in _scenario_fids(scenario)]


def filter_options(scenario: Optional[str] = None) -> dict:
    """筛选下拉候选项（场景 / 想定 / 课题）+ 默认视图（首个场景 + 首个想定 + 首个课题）。

    ``fids`` / ``topics`` 跟随传入的场景（页面上切场景后要重填想定下拉），每个场景的
   候选项另在 ``scenarios[i]['fids']`` 里各存一份；``scenarios[i]['registered']``
    标明该场景是否登记了红方模型（未登记 → 缺口视图）。
    """
    UR = _ur()
    scenarios: List[dict] = []
    for s in _scenario_values():
        fids = _fid_options(s)
        scenarios.append({'value': s, 'label': _scenario_label(s),
                          'registered': _red_registered(s),
                          'fids': fids, 'n_fids': len(fids)})
    known = [x['value'] for x in scenarios]
    cur = scenario if scenario in known else (
        next((x['value'] for x in scenarios if x['registered']), None)
        or (scenarios[0]['value'] if scenarios else None))
    registered = bool(cur) and _red_registered(cur)
    fids = next((x['fids'] for x in scenarios if x['value'] == cur), [])
    # 课题（MODE_SLOTS）只在已登记场景下有口径：未登记场景**不列课题**，否则界面会看起来
    # 「swarm 也有 F1–F4」，等于把 intercept 的口径静默套到别的场景上。
    topics = ([{'value': m, 'label': UR.MODE_NAMES.get(m, m),
                'n_slots': len(UR.MODE_SLOTS[m])} for m in UR.MODE_SLOTS]
              if registered else [])
    warnings: List[str] = []
    if cur and not registered:
        warnings.append(
            f'场景「{_scenario_label(cur)}」未登记红方模型'
            f'（uav_red.RED_SCENARIOS = {_registered_scenario_text()}）：'
            f'课题 / 部署区域 / 约束 / 目标函数都没有本场景的口径，'
            f'因此不列出课题选项，图会显示为缺口视图。')
    return {'scenario': cur, 'scenarios': scenarios, 'registered': registered,
            'fids': fids, 'topics': topics,
            'default_scenario': cur,
            'default_fid': fids[0]['value'] if fids else None,
            'default_topic': topics[0]['value'] if topics else None,
            'n_fids': len(fids), 'n_topics': len(topics),
            'warnings': warnings}


def _norm_scenario(v) -> Optional[str]:
    """场景参数归一化：``None`` / ``all`` → ``None``（全部场景）；非法场景报错。"""
    if v is None or str(v).strip().lower() in _ALL_TOKENS:
        return None
    s = str(v).strip()
    if s not in _scenario_values():
        raise ValueError('未知场景 %s（可选 %s）' % (s, '、'.join(_scenario_values())))
    return s


def _resolve_scenario(scenario: Optional[str]) -> str:
    """把「全部场景」落到具体场景：默认取首个**已登记红方模型**的场景（当前 intercept）。

    图的数值必须有具体场景的口径，故内部一律用具体场景；``note`` 里会说明
    「全部场景」的含义，未登记场景则由缺口视图负责，不在这里兜底。
    """
    if scenario:
        return str(scenario)
    seq = _scenario_values()
    return next((s for s in seq if _red_registered(s)), seq[0] if seq else 'intercept')


def _norm_fid(v, scenario: str = 'intercept') -> Optional[int]:
    """想定参数归一化：``None`` / ``all`` → ``None``（全部想定）；非法想定报错。

    想定编号只在**该场景**的想定集内校验（intercept 是 U1/U3/U4，swarm 是 U1–U4）。
    """
    if v is None or str(v).strip().lower() in _ALL_TOKENS:
        return None
    try:
        fid = int(str(v).strip())
    except ValueError:
        raise ValueError(f'想定参数应为整数或 all，收到 {v!r}')
    allowed = _scenario_fids(scenario)
    if fid not in allowed:
        raise ValueError('场景 %s 下未知想定 U%d（可选 %s）'
                         % (scenario, fid, '、'.join('U%d' % f for f in allowed)))
    return fid


def _norm_mode(v) -> Optional[str]:
    """课题参数归一化：``None`` / ``all`` → ``None``（全部课题）；非法课题报错。"""
    if v is None or str(v).strip().lower() in _ALL_TOKENS:
        return None
    m = str(v).strip()
    UR = _ur()
    if m not in UR.MODE_SLOTS:
        raise ValueError('未知课题 %s（可选 %s）' % (m, '、'.join(UR.MODE_SLOTS)))
    return m


def _scope_key(scenario: Optional[str], fid: Optional[int], mode: Optional[str]) -> str:
    """视图键（导出文件名 / JSON-LD @id）：``intercept-U1-deploy`` / ``all-all-all``。"""
    return '%s-%s-%s' % (scenario or 'all',
                         'U%d' % fid if fid is not None else 'all',
                         mode if mode is not None else 'all')


def _scope_text(scenario: Optional[str], fid: Optional[int],
                mode: Optional[str]) -> str:
    """人类可读的视图口径，如「实景突防 · U3 双机拦截 · F3 拦截」（页面状态行）。"""
    UR = _ur()
    s_txt = _scenario_label(scenario, short=True)
    names = _fid_names(scenario or 'intercept')
    f_txt = (f'U{fid} {names.get(fid, "")}'.strip() if fid is not None else '全部想定')
    m_txt = (UR.MODE_NAMES.get(mode, mode) if mode is not None else '全部课题')
    return f'{s_txt} · {f_txt} · {m_txt}'


def _q(local: str) -> str:
    """本图内的节点 id（前缀形式；导出时前缀映射到 :data:`NS`）。"""
    return f'{PREFIX}:{local}'


# 描述「文字化」词表：把上游文案里残留的代码标识换成中文说法，保证界面上读到的是
# **文字描述**而不是代码参数（真正的代码口径一律只走 ``params`` 字段）。
_CODE_WORDS: Tuple[Tuple[str, str], ...] = (
    ('PATROL_ANCHORS', '分区中心个数'),
    ('w_arrive', '突防成功权重'),
    ('w_lost', '击落权重'),
    ('w_early', '及早交战权重'),
    ('w_risk', '暴露压制权重'),
    ('w_gap', '覆盖缺口权重'),
    ('w_deploy', '后勤散布权重'),
    # 注册表 / 钩子名（只出现在文字描述与告警里，一律换成中文说法；代码口径只走 params）
    ('uav_red.RED_SCENARIOS', '红方已登记场景表'),
    ('RED_SCENARIOS', '红方已登记场景表'),
    ('CONSTRAINT_UNITS', '约束检查单元表'),
    ('CONSTRAINT_DOC', '约束说明'),
    ('OBJECTIVE_KEYS', '目标项权重'),
    ('SLOT_UNITS', '槽位作用单元表'),
    ('MODE_SLOTS', '课题划分'),
    ('MODE_NAMES', '课题名称'),
    ('MODE_DOC', '课题说明'),
    ('SLOT_ROI', '槽位部署区域'),
    ('SLOT_DOC', '槽位说明'),
    ('ROI', '部署区域'),
)


def _prose(text) -> str:
    """把描述文本收拾成给使用者读的文字描述：去代码标识 / 去反引号 / 并空白。"""
    s = str(text or '')
    for a, b in _CODE_WORDS:
        s = s.replace(a, b)
    s = s.replace('``', '').replace('`', '').replace('**', '')
    return ' '.join(s.split())


def _node(nid: str, label: str, ntype: str, layer: int, desc: str = '',
          params: str = '', **extra) -> dict:
    """节点。

    ``desc`` = **文字描述**（这个东西是什么、在战场语境里意味着什么，只写人能直接
    读懂的话，代码标识会被 :func:`_prose` 换成中文说法）；``params`` = **技术参数**
    （维度 / 取值区间 / 部署区域 / 罚分项名 / 结果表列名），只在界面上以次要小字给出，
    不承担「描述」职能。两者分字段下发（前端分两段显示，描述在上、参数小字灰显），
    ``detail`` 保留为合并文本，供导出与老接口兼容。
    """
    d = {'id': nid, 'label': label, 'type': ntype, 'layer': int(layer),
         'size': TYPE_STYLE.get(ntype, ('', '', 26))[2],
         'desc': _prose(desc), 'params': str(params).strip(),
         'detail': '；'.join(x for x in (_prose(desc), str(params).strip()) if x)}
    d.update(extra)
    return d


def _edge(src: str, dst: str, rel: str, **extra) -> dict:
    e = {'source': src, 'target': dst, 'rel': rel, 'label': PRED_LABELS.get(rel, rel)}
    e.update(extra)
    return e


def _exempt_edge(src: str, dst: str) -> dict:
    """豁免边：约束「管得着」该课题但该课题不判罚它（前端画灰虚线 + 「豁免」标注）。"""
    return _edge(src, dst, 'exemptFrom', exempt=True, dashed=True)


def _fmt_roi(roi: Sequence[Sequence[float]]) -> str:
    (xlo, xhi), (ylo, yhi) = roi
    return f'x∈[{xlo:.0f},{xhi:.0f}] y∈[{ylo:.0f},{yhi:.0f}]'


def _unit_names() -> Dict[str, str]:
    return {u: n for u, n, _ in UNIT_DOC}


# ===========================================================================
# 注册表收集（全部当场从代码里读，不落地缓存文件）
# ===========================================================================

def _slot_catalog() -> Dict[str, dict]:
    """槽位目录：维度（按想定 fid）、部署区域（按课题）、取值区间。

    维度只依赖编成（``_slot_dim(slot, cfg)``），故按 fid 记录；ROI 与课题有关
    （F3/F4 豁免 C5 后停机坪 ROI 放开到全图），故按课题记录。
    """
    UR = _ur()
    cat: Dict[str, dict] = {}
    for mode, slots in UR.MODE_SLOTS.items():
        for fid in _red_fids():
            for item in UR.describe_topic(mode, int(fid))['slots']:
                key = item['key']
                e = cat.setdefault(key, {
                    'key': key,
                    'label': item.get('label') or UR.SLOT_NAMES.get(key, key),
                    'dims': {}, 'roi': {}, 'range': None, 'unit': None,
                })
                e['dims'][str(int(fid))] = int(item['dim'])
                if 'roi' in item:
                    e['roi'][mode] = item['roi']
                if 'range' in item:
                    e['range'] = list(item['range'])
                    e['unit'] = item.get('unit')
    return cat


def _slot_params(e: dict, mode: str, fid: Optional[int] = None) -> str:
    """槽位的**代码参数**串：维度 / 取值区间 / 部署区域（当前课题 + 有差异时提示其余课题）。

    实体描述另取 ``uav_red.SLOT_DOC``（见 :func:`_slot_desc`）。
    ``fid`` 给定（单想定视图）时维度只显示该想定的 D 值，避免与筛选口径不符。
    """
    parts = []
    dims = dict(e.get('dims') or {})
    if fid is not None:
        dims = {str(fid): dims[str(fid)]} if str(fid) in dims else {}
    if dims:
        parts.append(' / '.join(f'U{f} D={d}' for f, d in dims.items()))
    if e.get('range'):
        lo, hi = e['range']
        unit = f" {e['unit']}" if e.get('unit') else ''
        parts.append(f'取值 {lo:g}~{hi:g}{unit}')
    roi = e.get('roi') or {}
    if roi:
        cur = roi.get(mode, next(iter(roi.values())))
        txt = '部署区域 ' + _fmt_roi(cur)
        other = sorted({_fmt_roi(v) for v in roi.values() if _fmt_roi(v) != _fmt_roi(cur)})
        if other:
            txt += f'（其余课题：{other[0]}）'
        parts.append(txt)
    return '；'.join(parts)


def _fid_formations() -> Dict[int, dict]:
    """各想定的编成摘要（编成与课题无关、只随 fid 变，故用 F1 取）。"""
    UR = _ur()
    return {int(f): dict(UR.describe_topic('deploy', int(f))['formation'])
            for f in _red_fids()}


def _objective_terms(fid: Optional[int] = None) -> Tuple[List[dict], List[str]]:
    """目标函数项：文案取 ``describe_topic``（单一事实来源），权重键按顺序配对。"""
    UR = _ur()
    fid = int(fid if fid is not None else _red_fids()[0])
    items = list(UR.describe_topic(str(next(iter(UR.MODE_SLOTS))), fid)['objective'])
    warnings: List[str] = []
    if len(items) != len(OBJECTIVE_KEYS):
        warnings.append(f'目标项数量({len(items)})与 OBJECTIVE_KEYS'
                        f'({len(OBJECTIVE_KEYS)})不一致，已按序号命名')
    out = []
    for i, it in enumerate(items):
        out.append({
            'id': OBJECTIVE_KEYS[i] if i < len(OBJECTIVE_KEYS) else f'term{i + 1}',
            'term': it.get('term', ''), 'sign': it.get('sign', ''),
            'text': it.get('text', ''),
        })
    return out, warnings


def _objective_weights(fid: Optional[int] = None) -> Dict[str, float]:
    """目标项权重实际数值（从 EnvConfig / RedWeights 读，与仿真口径一致）。"""
    UR = _ur()
    cfg = UR._intercept_cfg(int(fid if fid is not None else _red_fids()[0]))
    w = UR.RedWeights()
    return {'w_arrive': float(cfg.w_arrive), 'w_lost': float(cfg.w_lost),
            'w_early': float(w.early), 'w_risk': float(w.risk),
            'w_gap': float(w.gap), 'w_deploy': float(w.deploy)}


# ===========================================================================
# 实体描述 / 指标节点（节点信息 = 描述 + 参数两段）
# ===========================================================================

def _mode_desc(mode: str) -> str:
    """课题「实体描述」（``uav_red.MODE_DOC``：这个课题在战场语境下要解决什么）。"""
    return str((getattr(_ur(), 'MODE_DOC', {}) or {}).get(str(mode), ''))


def _slot_desc(slot: str) -> str:
    """槽位「实体描述」（``uav_red.SLOT_DOC``：这个决策变量在战场上代表什么）。"""
    return str((getattr(_ur(), 'SLOT_DOC', {}) or {}).get(str(slot), ''))


def _metric_nodes(rows, layer: int) -> Tuple[List[dict], List[str]]:
    """指标层节点：描述说明「这一项衡量什么」，参数是结果表字段名与期望方向。"""
    docs = _metric_docs()
    warns: List[str] = []
    if not rows:
        warns.append('未取到 RED_METRIC_ROWS，指标层为空')
    out: List[dict] = []
    for key, name, direction in rows:
        d_txt = DIR_TEXT.get(str(direction), str(direction))
        out.append(_node(_q(f'Metric.{key}'), name, 'Metric', layer,
                         docs.get(str(key)) or f'仿真结果里的「{name}」这一项。',
                         f'结果表字段 {key}；期望方向：{d_txt}',
                         key=key, direction=direction))
    return out, warns


# ===========================================================================
# 本体图（类别 / 元模型层）
# ===========================================================================

ONTOLOGY_LAYERS: Tuple[str, ...] = (
    '根问题', '课题', '决策变量', '防御单元', '约束', '目标项 / 对手', '评估指标',
)


def build_ontology(mode: Optional[str] = None, scenario: Optional[str] = None) -> dict:
    """本体图：概念 + 概念间关系（不含具体想定数值，想定只在说明文字里提一句）。

    ``scenario``：给定场景即该场景的口径（标题 / 状态行 / 导出键都带上它）；未登记红方
    模型的场景（swarm）直接给缺口视图（:func:`_build_unregistered`），绝不套用 intercept
    的数值；``None``（或 ``all``）=「全部场景」，即全部**已登记**场景（当前只有 intercept）。
    ``mode=None``（或 ``all``）= 全量元模型（默认，本体是四个课题共享的骨架）；
    给定课题 = 该课题的切片（只画它用到的槽位、它的生效 / 豁免约束）。
    """
    mode = _norm_mode(mode)
    scenario = _norm_scenario(scenario)
    if scenario is not None and not _red_registered(scenario):
        return _build_unregistered(scenario, 'ontology', mode=mode)
    UR = _ur()
    warnings: List[str] = []
    nodes: List[dict] = []
    edges: List[dict] = []
    cat = _slot_catalog()
    forms = _fid_formations()
    fids = _scenario_fids(scenario or 'intercept')
    topics: List[str] = list(UR.MODE_SLOTS)
    sel_topics: List[str] = [mode] if mode else list(topics)
    tbl = {t['mode']: t for t in UR.topic_table()}
    warned_slots: set = set()

    def _dim_txt(dims) -> str:
        return ' / '.join(f'U{f} D={d}' for f, d in sorted((dims or {}).items()))

    # ---- L0 根问题（描述 = 问题本身；参数 = 各想定编成）----
    form_txt = '；'.join(
        f"U{f} 无人机{forms[f].get('n_drones', '?')}·拦截机"
        f"{forms[f].get('n_interceptors', '?')}·防空车{forms[f].get('n_aa', '?')}·"
        f"巡逻兵{forms[f].get('n_patrol', '?')}·{forms[f].get('n_steps', '?')}步"
        for f in fids if f in forms)
    nodes.append(_node(
        _q(ROOT_ID), '红方防御优化问题', 'Root', 0,
        '固定一个蓝方突防对手，反过来优化红方的部署 / 预警 / 拦截 / 协同方案：'
        '蓝方每强一分，红方的代价就高一档，所以这是一个「对抗式」的最小最大问题。'
        '约束不做硬性排除，而是按违反程度分级罚分，由差分进化算法在搜索中自动权衡。',
        '；'.join(x for x in (
            f'想定编成：{form_txt}' if form_txt else '', '罚分系数 800') if x)))

    # ---- L1 课题（描述 = 这个课题要解决什么；参数 = 槽位数 / 维度 / C5 豁免）----
    for m in sel_topics:
        info = tbl.get(m, {})
        desc = _mode_desc(m)
        if not desc:
            warnings.append(f'课题 {m} 未登记实体描述（uav_red.MODE_DOC），节点信息只有参数')
        params = (f"{int(info.get('n_slots') or len(UR.MODE_SLOTS[m]))} 个决策槽位，"
                  f"维度 {_dim_txt(info.get('dims')) or '—'}")
        if info.get('c5_exempt'):
            params += '；豁免 C5（停机坪 ROI 放开到全图）'
        nodes.append(_node(_q(f'Topic.{m}'), UR.MODE_NAMES.get(m, m),
                           'Topic', 1, desc, params, mode=m))
        edges.append(_edge(_q(ROOT_ID), _q(f'Topic.{m}'), 'hasTopic'))

    # ---- L2 决策变量槽位（描述 = 它在战场里代表什么；参数 = D / 取值 / ROI）----
    slot_keys: List[str] = []
    for m in sel_topics:
        for slot in UR.MODE_SLOTS[m]:
            if slot in cat and slot not in slot_keys:
                slot_keys.append(slot)
    for slot in slot_keys:
        e = cat[slot]
        desc = _slot_desc(slot)
        if not desc and slot not in warned_slots:
            warned_slots.add(slot)
            warnings.append(f'槽位 {slot} 未登记实体描述（uav_red.SLOT_DOC），'
                            f'节点信息只有参数')
        nodes.append(_node(_q(f'Slot.{slot}'), e['label'], 'Slot', 2, desc,
                           _slot_params(e, sel_topics[0]), key=slot, dims=e['dims']))
    for m in sel_topics:
        for slot in UR.MODE_SLOTS[m]:
            if slot in cat:
                edges.append(_edge(_q(f'Topic.{m}'), _q(f'Slot.{slot}'), 'hasVariable'))

    # ---- L3 防御单元（描述 = 这类单元是什么、在模型里由什么刻画）----
    uname = _unit_names()
    for unit, name, doc in UNIT_DOC:
        nodes.append(_node(_q(f'Unit.{unit}'), name, 'Unit', 3, doc, key=unit))
    for slot, units in SLOT_UNITS.items():
        if slot not in cat:
            warnings.append(f'SLOT_UNITS 里的槽位 {slot} 未出现在任何课题，已忽略')
            continue
        if slot not in slot_keys:                       # 不在当前筛选口径内
            continue
        for unit in units:
            edges.append(_edge(_q(f'Slot.{slot}'), _q(f'Unit.{unit}'), 'actsOn'))
    missing = [s for s in cat if s not in SLOT_UNITS]
    if missing:
        warnings.append(f'槽位未在 SLOT_UNITS 登记作用单元：{missing}')

    # ---- L4 约束（描述 = 约束文案；参数 = 判罚名 / 生效与豁免课题 / 检查单元）----
    for cid, name, code, text, modes in UR.CONSTRAINT_DOC:
        units = CONSTRAINT_UNITS.get(code)
        if units is None:
            warnings.append(f'约束 {cid}（判罚名 {code}）未在 CONSTRAINT_UNITS 登记检查单元')
            units = ()
        exempt = [m for m in topics if m not in modes]
        active_view = [m for m in modes if m in sel_topics]
        exempt_view = [m for m in sel_topics if m not in modes]
        params = (f'判罚名 {code}；生效课题 '
                  f'{"、".join(UR.MODE_NAMES.get(m, m) for m in modes)}'
                  f'；检查单元 {"、".join(uname.get(u, u) for u in units) or "—"}')
        if exempt:
            params += f'；豁免课题 {"、".join(UR.MODE_NAMES.get(m, m) for m in exempt)}'
        if exempt_view and len(sel_topics) < len(topics):
            params += '（本视图内以灰虚线标出豁免）'
        nodes.append(_node(_q(f'Constraint.{cid}'), f'{cid} {name}', 'Constraint', 4,
                           text, params, key=code, cid=cid, active_modes=list(modes),
                           exempt_modes=exempt, active_in_view=active_view,
                           exempt_in_view=exempt_view))
        for m in active_view:
            edges.append(_edge(_q(f'Constraint.{cid}'), _q(f'Topic.{m}'), 'appliesTo'))
        for m in exempt_view:
            edges.append(_exempt_edge(_q(f'Constraint.{cid}'), _q(f'Topic.{m}')))
        for u in units:
            edges.append(_edge(_q(f'Constraint.{cid}'), _q(f'Unit.{u}'), 'constrainsUnit'))

    # ---- L5 目标项 + 蓝方对手（描述 = 项的含义 / 对手口径，权重已写在文案里）----
    terms, w = _objective_terms()
    warnings.extend(w)
    weights = _objective_weights()
    for t in terms:
        wt = weights.get(t['id'])
        nodes.append(_node(_q(f'Objective.{t["id"]}'), f'{t["term"]}（{t["sign"]}）',
                           'ObjectiveTerm', 5, t['text'],
                           f'权重 {t["id"]} = {wt:.0f}' if wt is not None else '',
                           key=t['id']))
        edges.append(_edge(_q(ROOT_ID), _q(f'Objective.{t["id"]}'), 'hasObjectiveTerm'))
    for key, label, text in UR.OPPONENT_DOC:
        nodes.append(_node(_q(f'Opponent.{key}'), label, 'Opponent', 5, text, key=key))
        edges.append(_edge(_q(ROOT_ID), _q(f'Opponent.{key}'), 'hasOpponent'))

    # ---- L6 评估指标（描述 = 这一项衡量什么；参数 = 结果表字段 / 期望方向）----
    m_nodes, m_warn = _metric_nodes(_metric_rows(), 6)
    nodes.extend(m_nodes)
    warnings.extend(m_warn)
    for n in m_nodes:
        edges.append(_edge(_q(ROOT_ID), n['id'], 'evaluates'))

    title = 'UAV 红方优化模型本体（类别层）'
    if mode:
        title += f' · {UR.MODE_NAMES.get(mode, mode)}'
    resolved = _resolve_scenario(scenario)
    # 标题 / 状态行用**传入**的场景（可能是「全部场景」），数值口径仍取 resolved
    title += f' · {_scenario_label(scenario, short=True)}'
    note = ('' if scenario else
            '「全部场景」= 已登记红方模型的场景（当前只有'
            f'{_registered_scenario_text()}）；'
            f'未登记的场景（{_unregistered_scenario_text()}）切过去后看到的是缺口视图。')
    return _graph('ontology', title, ONTOLOGY_LAYERS, nodes, edges, warnings,
                  selection={'scenario': scenario, 'fid': None, 'mode': mode},
                  filters=filter_options(scenario or resolved),
                  scope=_scope_text(scenario, None, mode),
                  scope_key=_scope_key(scenario, None, mode), note=note)


# ===========================================================================
# 缺口视图（场景未登记红方模型时）
# ===========================================================================

GAP_LAYERS: Tuple[str, ...] = ('场景', '已知配置', '未注册（缺口）')


def _swarm_cfg(fid: int):
    """swarm 场景配置（延迟导入 ``uav_swarm.swarm_cfg``；失败返回 ``None``）。"""
    try:
        import uav_swarm
        return uav_swarm.swarm_cfg(int(fid))
    except Exception:                                       # pragma: no cover - 兜底
        return None


def _unregistered_known(scenario: str, fid: int) -> str:
    """未登记场景下**已经存在**的红方相关参数（只列代码里读得到的，不做外推）。"""
    parts: List[str] = []
    try:
        info = _scenario_mod().task_info(scenario, int(fid))
        if info.get('brief'):
            parts.append(str(info['brief']))
    except Exception:                                       # pragma: no cover - 兜底
        pass
    if scenario == 'swarm':
        cfg = _swarm_cfg(fid)
        if cfg is not None:
            parts.append(f'红方拦截者 {cfg.n_interceptors} 架'
                         f'（{cfg.n_clusters} 集群 × {cfg.cluster_size} 架）'
                         f'· 每机巡逻航点 K_red {cfg.n_int_waypoints}'
                         f'· 红方维度 D_red {cfg.red_dim}'
                         f'· 取值域 [0,{cfg.width / 1000:.0f}km]×[0,{cfg.depth / 1000:.0f}km]')
            parts.append(f'红方目标（uav_swarm.SwarmEnv.red_cost）= '
                         f'{cfg.w_arrive:g}×突破架次 − {cfg.w_lost:g}×被击落架次 '
                         f'− 0.5×暴露时长')
    return '；'.join(parts)


def _build_unregistered(scenario: str, kind: str,
                        fid: Optional[int] = None,
                        mode: Optional[str] = None) -> dict:
    """未登记红方模型的场景：只画「代码里已经有什么」与「还缺哪些注册表」。

    红方课题 / 部署区域 / 约束 / 目标函数全部建立在 ``uav_red._intercept_cfg`` 之上，
    未登记的场景（swarm）没有本场景的口径。此处给**缺口视图**（节点类型 ``Gap``）：
    显式说明缺什么、已知什么，绝不静默套用 intercept 的数值。
    """
    UR = _ur()
    reg = tuple(getattr(UR, 'RED_SCENARIOS', ()) or ())
    ref = _scenario_label(reg[0]) if reg else '已登记场景'
    warnings = [
        f'场景「{_scenario_label(scenario)}」尚未登记红方优化模型'
        f'（uav_red.RED_SCENARIOS = {_registered_scenario_text()}）：课题（MODE_SLOTS）、'
        f'部署区域（ROI）、约束（CONSTRAINT_DOC）与目标函数都没有本场景的口径。',
        '本视图只呈现该场景在代码里**已经存在**的编成与参数，以及待补的注册表；'
        f'补登记后这里才会出现与{ref}同规格的红方模型图，期间不套用{ref}数值。',
    ]
    nodes: List[dict] = []
    edges: List[dict] = []
    fids = [int(fid)] if fid is not None else list(_scenario_fids(scenario))
    names = _fid_names(scenario)
    reg_names = '、'.join(_scenario_label(s) for s in reg) or '已建立模型的场景'
    if kind == 'ontology':
        layers = ('根问题',) + GAP_LAYERS
        root_layer, scen_layer, gap_layer = 0, 1, 2
        nodes.append(_node(_q(ROOT_ID), '红方防御优化问题', 'Root', root_layer,
                           '固定一个蓝方突防对手，反过来优化红方方案（最小最大问题）。'
                           f'红方模型目前只在{reg_names}下建立，本场景还没有。'))
    else:
        layers = GAP_LAYERS
        root_layer, scen_layer, gap_layer = None, 0, 1

    for f in fids:
        label = f'U{f} {names.get(f, "")}'.strip()
        nodes.append(_node(
            _q(f'Scenario.{scenario}.U{f}'), label, 'Scenario', scen_layer,
            f'场景「{_scenario_label(scenario)}」下的想定 U{f}：该想定决定双方编成与'
            f'防御强度。与{reg_names}不同，本场景的红方模型还没有建立，'
            f'所以图上没有课题、约束与目标层。',
            _unregistered_known(scenario, f), fid=int(f), scenario=scenario))
        if root_layer is not None:
            edges.append(_edge(_q(ROOT_ID), _q(f'Scenario.{scenario}.U{f}'), 'hasScenario'))

    missing = _node(
        _q(f'Gap.{scenario}.model'),
        f'{_scenario_label(scenario, short=True)} · 红方模型尚未建立', 'Gap',
        gap_layer,
        f'本场景的红方（防御方）优化模型还没有建立：现有的课题划分、决策变量、部署区域'
        f'与约束都是围绕{reg_names}写的，本场景的红方目前只有一条「怎么打分」的评价函数，'
        f'没有课题与约束口径。',
        f'未登记：uav_red.MODE_SLOTS（课题）/ SLOT_DOC + ROI（变量与区域）/ '
        f'CONSTRAINT_DOC + RedConstraints.check（约束）/ describe_topic（目标函数）')
    need = _node(
        _q(f'Gap.{scenario}.tables'), '待补的配置登记项', 'Gap', gap_layer,
        '要让本场景出现与其它场景同规格的红方本体 / 知识图谱，需要在这些登记项里补上'
        '本场景的口径；在此之前，本页不会用其它场景的数值冒充本场景。',
        'src/uav_red.py: MODE_SLOTS / MODE_NAMES / MODE_DOC / SLOT_DOC / SLOT_ROI / ROI / '
        'CONSTRAINT_DOC / RED_SCENARIOS；src/uav_swarm.py: SwarmEnv.red_cost')
    nodes.extend([missing, need])
    for f in fids:
        edges.append(_edge(_q(f'Scenario.{scenario}.U{f}'), missing['id'],
                           'missingRegistration'))
    edges.append(_edge(missing['id'], need['id'], 'missingRegistration'))

    scope = _scope_text(scenario, fid, mode)
    return _graph(kind,
                  f'UAV 红方{_scenario_label(scenario, short=True)}缺口视图（未登记红方模型）',
                  layers, nodes, edges, warnings,
                  selection={'scenario': scenario, 'fid': fid, 'mode': mode},
                  filters=filter_options(scenario), scope=scope,
                  scope_key=_scope_key(scenario, fid, mode), supported=False,
                  note='缺口视图：本场景未登记红方模型，图上没有课题 / 变量 / 约束 / 目标层。')


# ===========================================================================
# 知识图谱（实例层）
# ===========================================================================

KG_LAYERS: Tuple[str, ...] = (
    '场景 / 想定', '课题 / 对手', '决策变量实例', '单元编成', '生效约束', '评估指标',
)

_KG_COUNT_KEY = {'radar': 'radar', 'helipad': 'n_interceptors', 'aa': 'n_aa',
                 'patrol': 'n_patrol', 'interceptor': 'n_interceptors'}


def _unit_counts(unit: str, forms: Dict[int, dict],
                 fids: Optional[Sequence[int]] = None) -> Dict[str, Optional[int]]:
    """单元数量按想定展开（``radar`` 恒为 1；``helipad`` 与拦截机同数量）。"""
    key = _KG_COUNT_KEY[unit]
    out: Dict[str, Optional[int]] = {}
    for fid in (list(fids) if fids is not None else _red_fids()):
        if key == 'radar':
            out[f'U{fid}'] = 1
        else:
            n = forms.get(int(fid), {}).get(key)
            out[f'U{fid}'] = int(n) if n is not None else None
    return out


def build_kg(fid=None, mode=None, scenario: Optional[str] = None) -> dict:
    """知识图谱：场景 / 想定 → 课题 → 变量 / 单元 → 约束 → 指标（全部带实际数值）。

    ``scenario``：给定场景即该场景的口径；未登记红方模型的场景（swarm）直接给缺口视图
    （:func:`_build_unregistered`）；``None``（或 ``all``）=「全部场景」，即全部**已登记**
    红方模型的场景（当前只有 intercept）。
    ``fid`` / ``mode`` 为空（或 ``all``）= 该维度不筛；都给 = **某个场景下某个想定的
    某个课题**这一张子图（页面的默认视图），维度 / 部署区域 / 单元编成 / 生效与豁免约束
    都按该 (场景, 想定, 课题) 的真实口径重算。被豁免的约束不再靠「缺边」表达，而是画成
    灰虚线（``rel=exemptFrom``）并标注「豁免」。
    """
    scenario_in = _norm_scenario(scenario)
    if scenario_in is not None and not _red_registered(scenario_in):
        return _build_unregistered(scenario_in, 'kg',
                                   fid=_norm_fid(fid, scenario_in),
                                   mode=_norm_mode(mode))
    resolved = _resolve_scenario(scenario_in)
    fid = _norm_fid(fid, resolved)
    mode = _norm_mode(mode)
    # 下面各层循环会复用 ``fid`` / ``m`` 这些短名，故先把视图口径存下来
    sel_fid, sel_mode = fid, mode
    UR = _ur()
    warnings: List[str] = []
    nodes: List[dict] = []
    edges: List[dict] = []
    cat = _slot_catalog()
    forms = _fid_formations()
    all_fids: List[int] = [int(f) for f in _scenario_fids(resolved)]
    fids: List[int] = [fid] if fid is not None else list(all_fids)
    all_topics: List[str] = list(UR.MODE_SLOTS)
    topics: List[str] = [mode] if mode else list(all_topics)
    names = _fid_names(resolved)
    tbl = {t['mode']: t for t in UR.topic_table()}
    warned_slots: set = set()

    def _dim_txt(dims, sep: str = ' / ') -> str:
        return sep.join(f'U{f} D={d}' for f, d in sorted((dims or {}).items()))

    # ---- L0 场景 + 想定（描述 = 这是什么场景 / 想定；参数 = 编成数值）----
    s_label = _scenario_label(resolved)
    s_short = _scenario_label(resolved, short=True)
    nodes.append(_node(
        _q(f'Scenario.{resolved}'), s_short, 'Scenario', 0,
        f'场景「{s_label}」：本页所有数值都按这个场景的战场设定计算。红方（防御方）的'
        f'优化模型目前只在这个场景下建立，切到还没建立模型的其他场景会看到缺口视图，'
        f'不会套用本场景的数值。',
        f'本场景想定 {"、".join("U%d" % f for f in all_fids) or "—"}'))
    for fid in fids:
        f = forms.get(fid, {})
        label = f'U{fid} {names.get(fid, "")}'.strip()
        params = (f'无人机 {f.get("n_drones", "?")} 架 · 步兵 {f.get("n_infantry", "?")} · '
                  f'拦截机 {f.get("n_interceptors", "?")} · 防空车 {f.get("n_aa", "?")} · '
                  f'巡逻兵 {f.get("n_patrol", "?")}；航点 {f.get("n_waypoints", "?")}'
                  f'（拦截机 {f.get("n_int_waypoints", "?")}），仿真 '
                  f'{f.get("n_steps", "?")} 步')
        nodes.append(_node(_q(f'Scenario.{resolved}.U{fid}'), label, 'Scenario', 0,
                           f'场景「{s_label}」下的想定 U{fid}：战场条件与双方编成由这个'
                           f'想定确定。编成决定红方要优化多少个量，所以决策维数随想定'
                           f'变化；约束与目标函数不随想定变。', params,
                           fid=int(fid), formation=f))
        edges.append(_edge(_q(f'Scenario.{resolved}'), _q(f'Scenario.{resolved}.U{fid}'),
                           'hasScenario'))
        for m in topics:
            edges.append(_edge(_q(f'Scenario.{resolved}.U{fid}'), _q(f'Topic.{m}'),
                               'allowsTopic'))

    # ---- L1 课题 + 蓝方对手（描述 = 课题要解决什么；参数 = 槽位数 / 维度 / C5 豁免）----
    for m in topics:
        info = tbl.get(m, {})
        dims = {k: v for k, v in (info.get('dims') or {}).items() if int(k) in fids}
        desc = _mode_desc(m)
        if not desc:
            warnings.append(f'课题 {m} 未登记实体描述（uav_red.MODE_DOC），节点信息只有参数')
        params = f"{len(UR.MODE_SLOTS[m])} 个槽位，维度 {_dim_txt(dims) or '—'}"
        if info.get('c5_exempt'):
            params += '；豁免 C5（停机坪 ROI 全图）'
        nodes.append(_node(_q(f'Topic.{m}'), UR.MODE_NAMES.get(m, m),
                           'Topic', 1, desc, params, mode=m, dims=dims))
    for key, label, text in UR.OPPONENT_DOC:
        nodes.append(_node(_q(f'Opponent.{key}'), label, 'Opponent', 1, text, key=key))
        for fid in fids:
            edges.append(_edge(_q(f'Scenario.{resolved}.U{fid}'), _q(f'Opponent.{key}'),
                               'hasOpponent'))

    # ---- L2 变量实例（描述 = 变量含义；参数 = 维度 / 取值 / ROI，随课题与想定）----
    # 同一槽位可被多个课题共用（如 helipads 四个课题都有），故节点按槽位去重，
    # 边仍按 (课题, 槽位) 展开；参数取该槽位首次出现的课题口径。
    seen_slot: Dict[str, str] = {}
    for m in topics:
        for slot in UR.MODE_SLOTS[m]:
            if slot not in cat:
                continue
            edges.append(_edge(_q(f'Topic.{m}'), _q(f'Slot.{slot}'), 'hasVariable'))
            if slot not in seen_slot:
                seen_slot[slot] = m
    single_fid = fid if len(fids) == 1 else None
    for slot, m in seen_slot.items():
        e = cat[slot]
        dims = {k: v for k, v in e['dims'].items() if int(k) in fids}
        desc = _slot_desc(slot)
        if not desc and slot not in warned_slots:
            warned_slots.add(slot)
            warnings.append(f'槽位 {slot} 未登记实体描述（uav_red.SLOT_DOC），'
                            f'节点信息只有参数')
        nodes.append(_node(_q(f'Slot.{slot}'), e['label'], 'Slot', 2, desc,
                           _slot_params(e, m, fid=single_fid), key=slot, dims=dims))

    # ---- L3 单元编成（描述 = 这类单元是什么；参数 = 当前想定的编成数量）----
    for unit, name, doc in UNIT_DOC:
        counts = _unit_counts(unit, forms, fids)
        cnt_txt = '、'.join(f'{f}×{n if n is not None else "?"}'
                            for f, n in counts.items())
        multi = len({n for n in counts.values()}) > 1
        nodes.append(_node(_q(f'Unit.{unit}'), name + ('（随想定变）' if multi else ''),
                           'Unit', 3, doc, f'编成：{cnt_txt}', key=unit, counts=counts))
        for slot, units in SLOT_UNITS.items():
            if unit in units and slot in seen_slot:      # 只连当前视图里的槽位
                edges.append(_edge(_q(f'Slot.{slot}'), _q(f'Unit.{unit}'), 'actsOn'))

    # ---- L4 约束：描述 = 约束文案，参数 = 判罚名 / 生效与豁免课题 ----
    for cid, name, code, text, modes in UR.CONSTRAINT_DOC:
        exempt = [m for m in all_topics if m not in modes]
        active_view = [m for m in modes if m in topics]
        exempt_view = [m for m in topics if m not in modes]
        params = (f'判罚名 {code}；生效课题 '
                  f'{"、".join(UR.MODE_NAMES.get(m, m) for m in modes)}')
        if exempt:
            params += f'；豁免 {"、".join(UR.MODE_NAMES.get(m, m) for m in exempt)}'
        if exempt_view:
            params += '（本视图内以灰虚线标出豁免）'
        nodes.append(_node(_q(f'Constraint.{cid}'), f'{cid} {name}', 'Constraint', 4,
                           text, params, key=code, cid=cid, active_modes=list(modes),
                           exempt_modes=exempt, active_in_view=active_view,
                           exempt_in_view=exempt_view))
        for m in active_view:
            edges.append(_edge(_q(f'Topic.{m}'), _q(f'Constraint.{cid}'), 'penalizes'))
        for m in exempt_view:
            edges.append(_exempt_edge(_q(f'Topic.{m}'), _q(f'Constraint.{cid}')))

    # ---- L5 评估指标（描述 = 这一项衡量什么；参数 = 结果表字段 / 期望方向）----
    m_nodes, m_warn = _metric_nodes(_metric_rows(), 5)
    nodes.extend(m_nodes)
    warnings.extend(m_warn)
    for n in m_nodes:
        for m in topics:
            edges.append(_edge(_q(f'Topic.{m}'), n['id'], 'measuredBy'))

    # 标题 = 图名 + 视图口径；场景名只出现一次（口径串里已含场景短名）
    head = ('UAV 红方知识图谱（实例层）'
            if (sel_fid is not None or sel_mode is not None)
            else 'UAV 红方四课题知识图谱（实例层）')
    title = f'{head} · {_scope_text(resolved, sel_fid, sel_mode)}'
    layers = list(KG_LAYERS)
    layers[0] = f'场景 / 想定（{s_short}）'
    note = ('' if scenario_in else
            '「全部场景」= 已登记红方模型的场景（当前只有'
            f'{_registered_scenario_text()}）；'
            f'未登记的场景（{_unregistered_scenario_text()}）切过去后看到的是缺口视图。')
    return _graph('kg', title, layers, nodes, edges, warnings,
                  selection={'scenario': resolved, 'fid': sel_fid, 'mode': sel_mode},
                  filters=filter_options(resolved),
                  scope=_scope_text(resolved, sel_fid, sel_mode),
                  scope_key=_scope_key(resolved, sel_fid, sel_mode), note=note)


# ===========================================================================
# 图装配 / 三元组 / 导出
# ===========================================================================

def _graph(kind: str, title: str, layers: Sequence[str],
           nodes: List[dict], edges: List[dict], warnings: List[str],
           selection: Optional[dict] = None, filters: Optional[dict] = None,
           scope: str = '', scope_key: str = '', supported: bool = True,
           note: str = '') -> dict:
    by_type: Dict[str, int] = {}
    for n in nodes:
        by_type[n['type']] = by_type.get(n['type'], 0) + 1
    by_rel: Dict[str, int] = {}
    for e in edges:
        by_rel[e['rel']] = by_rel.get(e['rel'], 0) + 1
    return {
        'kind': kind,
        'title': title,
        # 视图口径：selection = 当前 (场景, 想定, 课题)，filters = 可选值，scope = 人类可读
        'selection': selection or {'scenario': None, 'fid': None, 'mode': None},
        'filters': filters or {},
        'scope': scope,
        'scope_key': scope_key or 'all-all-all',
        # supported=False → 缺口视图（该场景未登记红方模型，图上只有「已知配置 + 缺口」）
        'supported': bool(supported),
        'note': note,
        'namespace': NS,
        'prefix': PREFIX,
        'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'layers': [{'index': i, 'name': nm} for i, nm in enumerate(layers)],
        'types': [{'name': t, 'color': c, 'label': lb, 'size': sz}
                  for t, (c, lb, sz) in TYPE_STYLE.items() if by_type.get(t)],
        'nodes': nodes,
        'edges': edges,
        'stats': {'n_nodes': len(nodes), 'n_edges': len(edges),
                  'n_triples': len(edges), 'by_type': by_type, 'by_rel': by_rel},
        'sources': [
            'src/uav_red.py: MODE_SLOTS / MODE_NAMES / MODE_DOC / SLOT_NAMES / SLOT_DOC / '
            'SLOT_ROI / ROI / SCALAR_RANGE / CONSTRAINT_DOC / OPPONENT_DOC / RED_SCENARIOS / '
            'describe_topic / topic_table',
            'src/uav_red.py: RedConstraints.check → 约束检查哪些单元',
            'src/uav_red.py: apply_plan → 变量作用于哪个单元',
            'src/uav_adversarial.py: list_scenarios / SCENARIO_LABELS / TASK_NAMES / task_info',
            'app/webapp/web/uav_api.py: RED_FIDS / RED_METRIC_ROWS / RED_METRIC_DOC',
        ],
        'warnings': [_prose(w) for w in warnings],
    }


def triples(graph: dict) -> List[dict]:
    """把图摊平成 (subject, predicate, object) 三元组（带标签与类型注解）。"""
    idx = {n['id']: n for n in graph['nodes']}
    out: List[dict] = []
    for e in graph['edges']:
        s, t = idx.get(e['source']), idx.get(e['target'])
        if s is None or t is None:                          # pragma: no cover - 防御
            continue
        out.append({
            'subject': s['id'], 'subject_label': s['label'], 'subject_type': s['type'],
            'predicate': e['rel'], 'predicate_label': e['label'],
            'object': t['id'], 'object_label': t['label'], 'object_type': t['type'],
        })
    return out


def to_jsonld(graph: dict) -> dict:
    """JSON-LD：``uo`` 前缀映射到命名空间，节点带 label/comment，关系为 IRI 数组。"""
    idx = {n['id']: n for n in graph['nodes']}
    rels: Dict[str, Dict[str, List[dict]]] = {}
    for e in graph['edges']:
        rels.setdefault(e['source'], {}).setdefault(e['rel'], []).append(
            {'@id': e['target']})
    out: List[dict] = []
    for nid, n in idx.items():
        item: Dict[str, object] = {'@id': nid, '@type': n['type'], 'label': n['label']}
        # comment = 实体描述，uo:params = 代码参数：两者分开，别把参数当描述喂给下游
        if n.get('desc'):
            item['comment'] = n['desc']
        if n.get('params'):
            item['uo:params'] = n['params']
        for rel, objs in rels.get(nid, {}).items():
            item[rel] = objs
        out.append(item)
    return {
        '@context': {
            PREFIX: NS,
            'label': 'http://www.w3.org/2000/01/rdf-schema#label',
            'comment': 'http://www.w3.org/2000/01/rdf-schema#comment',
        },
        '@id': f'{NS}graph/{graph["kind"]}/{graph.get("scope_key", "all-all-all")}',
        'label': graph['title'],
        'scope': graph.get('scope', ''),
        'supported': graph.get('supported', True),
        'generated_at': graph['generated_at'],
        'sources': graph['sources'],
        '@graph': out,
    }


def to_csv(graph: dict) -> str:
    """CSV 三元组（UTF-8 BOM，Excel 直接打开不乱码）。"""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(['subject', 'subject_label', 'subject_type', 'predicate',
                'predicate_label', 'object', 'object_label', 'object_type'])
    for t in triples(graph):
        w.writerow([t['subject'], t['subject_label'], t['subject_type'],
                    t['predicate'], t['predicate_label'],
                    t['object'], t['object_label'], t['object_type']])
    return '\ufeff' + buf.getvalue()


def export_graph(kind: str = 'ontology', fmt: str = 'jsonld',
                 fid=None, mode=None, scenario=None):
    """导出三元组，返回 ``(文本, 文件名, media_type)``（供 FastAPI 直接回吐）。

    导出跟随页面当前的视图口径（``scenario`` / ``fid`` / ``mode``），文件名带上 scope
    key（如 ``uav_red_kg_intercept-U1-deploy_triples.csv``），便于把多个任务子图分别
    喂图数据库、且不同场景不会互相覆盖。
    """
    kind = str(kind or 'ontology').strip().lower()
    fmt = str(fmt or 'jsonld').strip().lower()
    if kind not in ('ontology', 'kg'):
        raise ValueError(f'未知图类型：{kind}（可选 ontology / kg）')
    if fmt not in ('jsonld', 'csv'):
        raise ValueError(f'未知导出格式：{fmt}（可选 jsonld / csv）')
    scenario_n = _norm_scenario(scenario)
    if kind == 'ontology':
        graph = build_ontology(mode=_norm_mode(mode), scenario=scenario_n)
    else:
        resolved = _resolve_scenario(scenario_n)
        graph = build_kg(fid=_norm_fid(fid, resolved), mode=_norm_mode(mode),
                         scenario=scenario_n)
    suffix = '_' + graph.get('scope_key', 'all-all-all')
    if fmt == 'jsonld':
        text = json.dumps(to_jsonld(graph), ensure_ascii=False, indent=2)
        return text, f'uav_red_{kind}{suffix}.jsonld', 'application/ld+json; charset=utf-8'
    return (to_csv(graph), f'uav_red_{kind}{suffix}_triples.csv',
            'text/csv; charset=utf-8')


# ===========================================================================
# 「约束 × 课题」矩阵（表格形态：豁免关系一次看全）
# ===========================================================================

MATRIX_STATES: Dict[str, str] = {'active': '生效', 'exempt': '豁免'}


def constraint_matrix(scenario: Optional[str] = None) -> dict:
    """「约束 × 课题」矩阵：行 = 约束（C1–C6），列 = 课题（F1–F4）。

    每格 = 生效 / 豁免，并带上该约束真正检查的单元；列头带各想定的决策维度（D 随想定
    变）。表格形态比网络图更适合回答「哪条约束管哪个课题、哪条被豁免」——C5 在 F1 豁免
    这类关系一眼可见，不必顺着灰虚线数。未登记红方模型的场景返回 ``supported=False``
    与提示，不套用已登记场景的矩阵。
    """
    scenario_in = _norm_scenario(scenario)
    if scenario_in is not None and not _red_registered(scenario_in):
        return {
            'kind': 'matrix', 'supported': False,
            'scenario': scenario_in, 'scope': _scenario_label(scenario_in),
            'scope_key': _scope_key(scenario_in, None, None),
            'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'states': MATRIX_STATES, 'columns': [], 'rows': [],
            'stats': {'n_rows': 0, 'n_cols': 0, 'n_cells': 0, 'n_active': 0, 'n_exempt': 0},
            'warnings': [f'场景「{_scenario_label(scenario_in)}」未登记红方模型'
                         f'（uav_red.RED_SCENARIOS），因此没有约束 × 课题矩阵；'
                         f'补登记后这里才会出现与已登记场景同规格的矩阵。'],
            'sources': ['src/uav_red.py: CONSTRAINT_DOC / RED_SCENARIOS'],
        }
    resolved = _resolve_scenario(scenario_in)
    UR = _ur()
    uname = _unit_names()
    fids = [int(f) for f in _scenario_fids(resolved)]
    tbl = {t['mode']: t for t in UR.topic_table()}
    warnings: List[str] = []
    topics: List[str] = list(UR.MODE_SLOTS)

    columns: List[dict] = []
    for m in topics:
        info = tbl.get(m, {})
        dmap = info.get('dims') or {}
        dims = ' / '.join(f'U{f} D={dmap.get(str(f), "?")}' for f in fids)
        n_active = sum(1 for c in UR.CONSTRAINT_DOC if m in c[4])
        columns.append({'mode': m, 'label': UR.MODE_NAMES.get(m, m),
                        'desc': _mode_desc(m), 'n_slots': len(UR.MODE_SLOTS[m]),
                        'dims': dims, 'n_active': n_active,
                        'n_exempt': len(UR.CONSTRAINT_DOC) - n_active})

    rows: List[dict] = []
    for cid, name, code, text, modes in UR.CONSTRAINT_DOC:
        units = CONSTRAINT_UNITS.get(code)
        if units is None:
            warnings.append(f'约束 {cid}（判罚名 {code}）未在 CONSTRAINT_UNITS 登记检查单元')
            units = ()
        unit_txt = '、'.join(uname.get(u, u) for u in units) or '—'
        cells = [{'mode': m,
                  'state': 'active' if m in modes else 'exempt',
                  'state_label': MATRIX_STATES['active' if m in modes else 'exempt'],
                  'units': unit_txt} for m in topics]
        rows.append({'cid': cid, 'name': name, 'code': code, 'desc': text,
                     'units': unit_txt, 'unit_keys': list(units),
                     'active_modes': [c['mode'] for c in cells if c['state'] == 'active'],
                     'exempt_modes': [c['mode'] for c in cells if c['state'] == 'exempt'],
                     'cells': cells})

    def _cnt(state: str) -> int:
        return sum(1 for r in rows for c in r['cells'] if c['state'] == state)

    return {
        'kind': 'matrix', 'supported': True,
        'scenario': resolved, 'scope': _scope_text(resolved, None, None),
        'scope_key': _scope_key(resolved, None, None),
        'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'states': MATRIX_STATES, 'columns': columns, 'rows': rows,
        'stats': {'n_rows': len(rows), 'n_cols': len(columns),
                  'n_cells': len(rows) * len(columns),
                  'n_active': _cnt('active'), 'n_exempt': _cnt('exempt')},
        'sources': [
            'src/uav_red.py: CONSTRAINT_DOC（约束文案与生效课题）/ RedConstraints.check',
            'src/uav_red.py: topic_table（各想定的决策维度）',
            'src/uav_red.py: MODE_NAMES / MODE_DOC / RED_SCENARIOS',
        ],
        'warnings': [_prose(w) for w in warnings],
    }

# -*- coding: utf-8 -*-
"""大模型优化器（LLM-as-Optimizer，OPRO 风格）。

遵守「黑盒协议」的内置脚本：平台通过 stdin 发 init（含 dim/lb/ub/seed/params），
脚本通过 stdout 发 eval 请求、读取 f 结果，循环直到预算用尽。

脚本把历史 (x, f) 喂给大模型（OpenAI 兼容协议，默认 DeepSeek），让大模型推理出
新的候选解，实现自动迭代优化；若未配置 api_key 或调用失败，则回退为「当前最优 +
高斯扰动」的随机搜索，保证链路始终能跑通。

依赖：仅标准库（urllib），无需 requests。
"""
import json
import random
import sys
import urllib.request


def read_msg():
    line = sys.stdin.readline()
    return json.loads(line) if line else None


def send(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + '\n')
    sys.stdout.flush()


def _clip(x, lb, ub):
    return [min(max(x[i], lb[i]), ub[i]) for i in range(len(x))]


def _call_llm(api_key, base_url, model, prompt, temperature, max_tokens, timeout):
    url = base_url.rstrip('/') + '/chat/completions'
    body = {
        'model': model,
        'messages': [{'role': 'system', 'content': prompt}],
        'temperature': temperature,
        'max_tokens': max_tokens,
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode('utf-8'),
        headers={
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + api_key,
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode('utf-8'))
    return data['choices'][0]['message']['content']


def _extract_array(text):
    """从 LLM 返回文本里提取第一个 JSON 数组。"""
    if not text:
        return None
    t = text.strip()
    try:
        v = json.loads(t)
        if isinstance(v, list):
            return v
        if isinstance(v, dict) and isinstance(v.get('x'), list):
            return v['x']
    except Exception:
        pass
    # 括号配平提取第一个完整数组
    start = t.find('[')
    if start < 0:
        return None
    depth = 0
    for i in range(start, len(t)):
        if t[i] == '[':
            depth += 1
        elif t[i] == ']':
            depth -= 1
            if depth == 0:
                try:
                    v = json.loads(t[start:i + 1])
                    if isinstance(v, list):
                        return v
                except Exception:
                    pass
                break
    return None


def _ask_llm(cfg, dim, lb, ub, history):
    api_key = str(cfg.get('api_key') or '').strip()
    base_url = str(cfg.get('base_url') or 'https://api.deepseek.com').strip()
    model = str(cfg.get('model') or 'deepseek-chat').strip()
    task_hint = str(cfg.get('task_hint') or '请最小化这个黑盒函数')
    temperature = float(cfg.get('temperature', 0.7))
    max_tokens = int(cfg.get('max_tokens', 4096))
    timeout = float(cfg.get('api_timeout', 120))

    hist_lines = []
    for x, f in history:
        xs = json.dumps([round(float(v), 6) for v in x])
        hist_lines.append('x = %s -> f = %.6g' % (xs, f))
    hist_txt = '\n'.join(hist_lines) if hist_lines else '（暂无历史）'

    prompt = (
        '你是一个数值优化算法。目标是最小化黑盒函数 f(x)。\n'
        'x 是 {dim} 维实向量，各分量上下界为：\n'
        'lb = {lb}\nub = {ub}\n'
        '{task_hint}\n\n'
        '以下是已评估的部分解（f 越小越好）：\n{hist}\n\n'
        '请推理出一个新的候选解 x，期望 f(x) 更小。'
        '只输出一个 JSON 数组（长度 {dim}，每个分量落在对应界内），不要任何解释。'
    ).format(dim=dim, lb=json.dumps(lb), ub=json.dumps(ub),
             task_hint=task_hint, hist=hist_txt)

    text = _call_llm(api_key, base_url, model, prompt, temperature, max_tokens, timeout)
    arr = _extract_array(text)
    if not arr:
        return None
    try:
        return [float(v) for v in arr]
    except Exception:
        return None


def main():
    cfg = {}
    dim = 10
    lb = [-100.0] * 10
    ub = [100.0] * 10
    rng = random.Random(0)
    history = []            # [(x, f)] 按 f 升序
    best_x = None
    best_f = float('inf')
    pending = None          # 刚发出 eval、等待 f 的 x

    while True:
        msg = read_msg()
        if msg is None:
            break
        cmd = msg.get('cmd')
        if cmd == 'init':
            cfg = dict(msg.get('params') or {})
            dim = int(msg.get('dim', 10))
            lb = [float(v) for v in msg.get('lb', [-100.0] * dim)]
            ub = [float(v) for v in msg.get('ub', [100.0] * dim)]
            if len(lb) != dim:
                lb = [lb[0]] * dim
                ub = [ub[0]] * dim
            rng = random.Random(msg.get('seed', 0))
            pending = [rng.uniform(lb[i], ub[i]) for i in range(dim)]
            send({'cmd': 'eval', 'x': pending})
        elif cmd == 'f':
            f = float(msg['f'])
            if pending is not None:
                history.append((pending, f))
                history.sort(key=lambda t: t[1])
                if f < best_f:
                    best_f = f
                    best_x = pending
                pending = None
            nx = None
            if best_x is not None:
                if str(cfg.get('api_key') or '').strip():
                    try:
                        nx = _ask_llm(cfg, dim, lb, ub, history[:int(cfg.get('history_window', 20))])
                    except Exception:
                        nx = None
                if nx is None or len(nx) != dim:
                    # 回退：对当前最优做高斯扰动（随机搜索）
                    nx = [best_x[i] + rng.gauss(0, (ub[i] - lb[i]) * 0.05) for i in range(dim)]
                nx = _clip(nx, lb, ub)
                pending = nx
                send({'cmd': 'eval', 'x': nx})
        elif cmd == 'stop':
            break


if __name__ == '__main__':
    main()

﻿# Warlock 屏录用的 Win32 / UIA 辅助（record_warlock_demo.ps1 加载）
# 只做三件事：找 warlock 主窗口、把它拉到前台并最大化、发按键/滚轮。

if (-not ([System.Management.Automation.PSTypeName]'WkWin').Type) {
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class WkWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, int d, UIntPtr e);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }

  static uint _pid; static IntPtr _best; static int _area;
  public static IntPtr Largest(uint pid) {
    _pid = pid; _best = IntPtr.Zero; _area = 0;
    EnumWindows(NewCallback(), IntPtr.Zero);
    return _best;
  }
  static EnumProc NewCallback() { return new EnumProc(Step); }
  static bool Step(IntPtr h, IntPtr l) {
    uint p; GetWindowThreadProcessId(h, out p);
    if (p != _pid) return true;
    if (!IsWindowVisible(h)) return true;
    RECT r; GetWindowRect(h, out r);
    int a = (r.Right-r.Left)*(r.Bottom-r.Top);
    if (a > _area) { _area = a; _best = h; }
    return true;
  }
  public static int LastArea() { return _area; }
  public static string Title(IntPtr h) {
    StringBuilder sb = new StringBuilder(512);
    GetWindowText(h, sb, sb.Capacity);
    return sb.ToString();
  }
}
"@
}

function Get-WarlockWindow {
  $p = Get-Process warlock -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $p) { return [IntPtr]::Zero }
  return [WkWin]::Largest([uint32]$p.Id)
}

function Focus-WarlockWindow([IntPtr]$hwnd) {
  if ($hwnd -eq [IntPtr]::Zero) { return $false }
  $fgt = [WkWin]::GetWindowThreadProcessId([WkWin]::GetForegroundWindow(), [IntPtr]::Zero)
  $my = [WkWin]::GetCurrentThreadId()
  [WkWin]::ShowWindow($hwnd, 9) | Out-Null   # SW_RESTORE
  [WkWin]::ShowWindow($hwnd, 3) | Out-Null   # SW_MAXIMIZE
  [WkWin]::AttachThreadInput($my, $fgt, $true) | Out-Null
  [WkWin]::SetForegroundWindow($hwnd) | Out-Null
  [WkWin]::BringWindowToTop($hwnd) | Out-Null
  [WkWin]::AttachThreadInput($my, $fgt, $false) | Out-Null
  Start-Sleep -Milliseconds 1200
  return ([WkWin]::GetForegroundWindow() -eq $hwnd)
}

function Get-WindowRect([IntPtr]$hwnd) {
  $r = New-Object WkWin+RECT
  [WkWin]::GetWindowRect($hwnd, [ref]$r) | Out-Null
  return $r
}

function Send-WarlockKeys([string]$keys) {
  [System.Windows.Forms.SendKeys]::SendWait($keys)
}

function Invoke-WarlockWheel([int]$x, [int]$y, [int]$times) {
  [WkWin]::SetCursorPos($x, $y) | Out-Null
  Start-Sleep -Milliseconds 200
  for ($i = 0; $i -lt $times; $i++) {
    [WkWin]::mouse_event(0x0800, 0, 0, 120, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 240
  }
}

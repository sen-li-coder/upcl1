"""把论文实验产物同步到 webapp（UAV 页「任务实验数据」面板的数据源）。

webapp 是自包含部署包，页面读的是包内路径
``app/webapp/results/apps/{tables,raw,figures}``；重跑论文实验后执行本脚本刷新。

只同步这三个子目录，**不动** webapp 运行时存档 ``app/webapp/results/apps/gui``。

用法（必须 `cd` 到项目根 E:\LASE 再执行，脚本按 cwd 解析 results/；
脚本本体位于 app/webapp/scripts/）：
    python app/webapp/scripts/sync_webapp_data.py                # 同步 tables / raw / figures
    python app/webapp/scripts/sync_webapp_data.py --only tables  # 只同步 tables（面板必需）
    python app/webapp/scripts/sync_webapp_data.py --check        # 只比对差异，不写文件
"""
from __future__ import annotations

import argparse
import filecmp
import shutil
import sys
from pathlib import Path

SRC = Path('results/apps')
DST = Path('app/webapp/results/apps')
SUBDIRS = ('tables', 'raw', 'figures')


def diff_files(src: Path, dst: Path):
    """返回 (新增/变更文件列表, 目标目录多余文件列表)。"""
    src_files = {p.relative_to(src) for p in src.rglob('*') if p.is_file()}
    dst_files = {p.relative_to(dst) for p in dst.rglob('*') if p.is_file()} \
        if dst.is_dir() else set()
    changed = [r for r in sorted(src_files)
               if r not in dst_files or not filecmp.cmp(src / r, dst / r,
                                                        shallow=False)]
    extra = sorted(dst_files - src_files)
    return changed, extra


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--only', default='', help='只同步指定子目录（逗号分隔）')
    ap.add_argument('--check', action='store_true', help='只比对差异，不写文件')
    args = ap.parse_args(argv)

    subs = [s.strip() for s in args.only.split(',') if s.strip()] or list(SUBDIRS)
    bad = [s for s in subs if s not in SUBDIRS]
    if bad:
        print(f'未知子目录：{bad}（可选 {SUBDIRS}）')
        return 2
    if not SRC.is_dir():
        print(f'源目录不存在：{SRC}')
        return 1

    rc = 0
    for sub in subs:
        src, dst = SRC / sub, DST / sub
        if not src.is_dir():
            print(f'[skip] {src} 不存在')
            continue
        changed, extra = diff_files(src, dst)
        print(f'[{sub}] 需更新 {len(changed)} 个文件'
              + (f'，目标多余 {len(extra)} 个' if extra else ''))
        for r in changed[:10]:
            print(f'    ~ {r}')
        if len(changed) > 10:
            print(f'    ... 其余 {len(changed) - 10} 个')
        if args.check:
            rc = rc or (1 if changed else 0)
            continue
        shutil.copytree(src, dst, dirs_exist_ok=True)
        print(f'    已同步到 {dst}')
    return rc


if __name__ == '__main__':
    sys.exit(main())

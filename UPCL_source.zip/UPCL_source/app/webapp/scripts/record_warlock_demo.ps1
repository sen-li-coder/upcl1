﻿<#
.SYNOPSIS
    为任意 (算法 host, 任务 fid, run) 组合录制一段 AFSIM 自带图形前端 warlock.exe 的演示视频。

.DESCRIPTION
    流程：afsim_bridge.py 生成该局的 warlock 想定 -> 启动 warlock.exe -> 前台最大化
    -> Ctrl+Shift+V 开始录屏 -> Ctrl+Shift+F5 重跑 -> Home 居中 + 滚轮缩放
    -> 等 WaitSec 秒 -> Ctrl+Shift+V 停止 -> ffmpeg 裁到 DurSec 秒并重编码。

    前提：Warlock 的平台选项里 Platform Labels / Trace lines 已勾选（勾选状态由
    warlock 偏好持久化，首次手动勾一次即可）。

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File app\webapp\scripts\record_warlock_demo.ps1 `
        -HostName 'SHADE' -Fid 1 -Run 0

.EXAMPLE
    # 批量：六个组合依次录
    foreach ($c in @(@('CoBiDE',2),@('CoBiDE',3),@('SHADE',1))) { ... }
#>
param(
    [Parameter(Mandatory = $true)][string]$HostName,
    [int]$Fid = 1,
    [int]$Run = 0,
    [ValidateSet('full', 'bare')][string]$Arm = 'full',
    [string]$Out,
    [int]$WaitSec = 72,
    [int]$Zoom = 4,
    [int]$Crf = 29,
    [double]$DurSec = 60,
    [string]$RepoRoot = 'E:\LASE',
    [switch]$SkipScenario,
    [switch]$LeaveWarlockOpen
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
. "$PSScriptRoot\_warlock_win.ps1"
[WkWin]::SetProcessDPIAware() | Out-Null   # 否则 GetWindowRect/SetCursorPos 拿到的是 DPI 虚拟化坐标

$slug = ($HostName -replace '[\\/]', '-') -replace '\s+', ''
$work = Join-Path $RepoRoot "results\apps\afsim_warlock\demo_${slug}_F${Fid}_run${Run}"
# afsim_bridge 把产物写到 <out>\<host>_F<fid>_run<run>_<arm>\warlock.txt（host 名里的 / 会形成子目录）
$scenario = Join-Path $work "${HostName}_F${Fid}_run${Run}_${Arm}\warlock.txt"
if (-not $Out) {
    $Out = Join-Path $RepoRoot "app\webapp\web\static\media\afsim_warlock_${slug}_F${Fid}_run${Run}.mp4"
}
$warlockExe = Join-Path $RepoRoot 'afsim-2.9.0-win64\bin\warlock.exe'
$ffmpeg = (& python -c "import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())").Trim()

if (-not (Test-Path $warlockExe)) { throw "找不到 warlock.exe: $warlockExe" }
if (-not $ffmpeg) { throw '找不到 ffmpeg（imageio_ffmpeg）' }

# 1) 生成想定（复用已生成的 warlock.txt）
if (-not $SkipScenario -or -not (Test-Path $scenario)) {
    Write-Host "[1/6] 生成想定 $HostName F$Fid run$Run -> $work"
    Push-Location $RepoRoot
    & python 'src\afsim_bridge.py' --host $HostName --fid $Fid --run $Run --arm $Arm --out $work | Out-Host
    Pop-Location
}
# 桥接只写 input.txt；Warlock 侧复制一份并补 event_pipe 录像块（便于事后用 Mystic 回放）
$inputTxt = Join-Path (Split-Path $scenario) 'input.txt'
if (-not (Test-Path $inputTxt)) { throw "想定未生成: $inputTxt" }
if (-not (Test-Path $scenario) -or -not $SkipScenario) {
    Copy-Item $inputTxt $scenario -Force
    $block = "`r`n`r`n# --- Warlock / Mystic replay ---`r`n`r`nevent_pipe`r`n   file out/replay.aer`r`n   use_preset default`r`nend_event_pipe`r`n"
    Add-Content -Path $scenario -Value $block -NoNewline
}
if (-not (Test-Path $scenario)) { throw "想定未生成: $scenario" }

# 2) 关掉旧 warlock，加载新想定
Write-Host '[2/6] 启动 warlock.exe'
Get-Process warlock -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 1200
Start-Process -FilePath $warlockExe -ArgumentList "`"$scenario`""
$hwnd = [IntPtr]::Zero
for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Milliseconds 1000
    $hwnd = Get-WarlockWindow
    if ($hwnd -ne [IntPtr]::Zero -and [WkWin]::Title($hwnd)) { break }
}
if ($hwnd -eq [IntPtr]::Zero) { throw 'warlock 窗口未就绪' }
Write-Host "      title: $([WkWin]::Title($hwnd))"

# 3) 前台 + 最大化 + 等加载
$fg = Focus-WarlockWindow $hwnd
$rect = Get-WindowRect $hwnd
Write-Host "      foreground=$fg size=$($rect.Right-$rect.Left)x$($rect.Bottom-$rect.Top)"
Start-Sleep -Milliseconds 2500

# 地图中心：窗口右侧地图区
$mx = [int]($rect.Left + ($rect.Right - $rect.Left) * 0.60)
$my = [int]($rect.Top + ($rect.Bottom - $rect.Top) * 0.42)

# 4) 录屏：开始 -> 重跑 -> 居中/缩放 -> 停留
Write-Host '[3/6] 开始录屏并重跑想定'
$before = @(Get-ChildItem (Join-Path $env:USERPROFILE 'video_*.mp4') -ErrorAction SilentlyContinue |
            ForEach-Object { $_.FullName })

Send-WarlockKeys '^+v'
Start-Sleep -Milliseconds 1500
Send-WarlockKeys '^+{F5}'
Start-Sleep -Milliseconds 2200
# 先点一下地图把键盘焦点交给视图，Home 才会被地图接收
[WkWin]::SetCursorPos($mx, $my) | Out-Null
Start-Sleep -Milliseconds 200
[WkWin]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
[WkWin]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
Start-Sleep -Milliseconds 600
Send-WarlockKeys '{HOME}'
Start-Sleep -Milliseconds 1500
if ($Zoom -gt 0) { Invoke-WarlockWheel $mx $my $Zoom }
[WkWin]::SetCursorPos($rect.Right - 40, $rect.Bottom - 60) | Out-Null   # 光标移出画面
Write-Host "      居中完成，缩放 $Zoom 级，等待 $WaitSec s"
Start-Sleep -Seconds $WaitSec

Write-Host '[4/6] 停止录屏'
Send-WarlockKeys '^+v'
Start-Sleep -Seconds 5

$new = Get-ChildItem (Join-Path $env:USERPROFILE 'video_*.mp4') -ErrorAction SilentlyContinue |
       Where-Object { $before -notcontains $_.FullName } |
       Sort-Object LastWriteTime | Select-Object -Last 1
if (-not $new) { throw '未找到新录制的 video_*.mp4' }
Write-Host "      源文件: $($new.FullName) $('{0:N0}' -f $new.Length) B"

# 5) 压缩
Write-Host "[5/6] ffmpeg 裁剪 ${DurSec}s / crf $Crf -> $Out"
New-Item -ItemType Directory -Force -Path (Split-Path $Out) | Out-Null
& $ffmpeg -y -loglevel error -ss 0 -t $DurSec -i $new.FullName `
    -c:v libx264 -crf $Crf -preset slow -pix_fmt yuv420p -an $Out
if ($LASTEXITCODE -ne 0) { throw 'ffmpeg 编码失败' }

# 5b) 抽一帧交战中期画面做封面（前端 <video poster>）
$poster = [IO.Path]::ChangeExtension($Out, '.jpg')
$ss = [Math]::Round([Math]::Min(30, $DurSec / 2), 1)
$old2 = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
& $ffmpeg -y -loglevel error -ss $ss -i $Out -frames:v 1 -q:v 3 $poster 2>$null
$ErrorActionPreference = $old2
if (Test-Path $poster) { Write-Host "      封面: $poster" }
else { Write-Host '      封面抽取失败（不影响视频）' }

# 6) 收尾
if (-not $LeaveWarlockOpen) { Get-Process warlock -ErrorAction SilentlyContinue | Stop-Process -Force }

$size = (Get-Item $Out).Length
Write-Host '[6/6] 完成'
$old = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$info = & $ffmpeg -hide_banner -i $Out 2>&1 | Select-String -Pattern 'Duration|Stream #'
$ErrorActionPreference = $old
Write-Host "      $Out"
Write-Host ("      {0:N0} B" -f $size)
$info | ForEach-Object { Write-Host "      $_" }

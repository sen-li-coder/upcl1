# -*- coding: utf-8 -*-
"""使用手册截图采集脚本（playwright + 本机 Edge）。

自动登录实验平台，按「整屏 + 逐卡片」两个粒度截图，输出到
docs/manual/shots/，文件名为 `<页面序号>_<页面id>_<卡片序号>_<卡片标题>.png`。

依赖：pip install playwright
      复用系统已安装的 Edge（channel='msedge'），无需执行 playwright install。

用法（在项目根 E:\LASE 下执行；脚本本体位于 app/webapp/scripts/）：
    python app/webapp/scripts/capture_manual_shots.py                  # 采集全部页面
    python app/webapp/scripts/capture_manual_shots.py dashboard uav    # 只采集指定页面
    python app/webapp/scripts/capture_manual_shots.py --headed         # 显示浏览器窗口（调试用）
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re

from playwright.sync_api import sync_playwright

# 脚本位于 app/webapp/scripts/，项目根 E:\LASE 是上三级
ROOT = pathlib.Path(__file__).resolve().parents[3]
SHOT_DIR = ROOT / "docs" / "manual" / "shots"
BASE_URL = "http://127.0.0.1:8000/"
USERNAME = "admin"
PASSWORD = "admin123"
VIEWPORT = {"width": 1500, "height": 950}

# (页面序号, 页面 id, 中文名) —— 与 app.js 的 _navDefs 顺序一致
PAGES = [
    (1, "dashboard", "主界面"),
    (2, "reference", "算法与测试集"),
    (3, "experiment", "实验运行"),
    (4, "convergence", "收敛曲线"),
    (5, "compare", "算法对比"),
    (6, "mechanism", "机制分析"),
    (7, "landscape", "地形图"),
    (8, "archive", "数据存档"),
    (9, "uav", "UAV仿真"),
    (10, "wizard", "算法接入"),
    (11, "users", "用户管理"),
]


# ------------------------------------------------------------------ 数据演示
# 手册截图必须让读者看到「界面有数据时是什么样」。原脚本只切页面就截，导致
# 收敛曲线 / 算法对比 / 机制分析 / 地形图四页全是白板（画布 0/0）。这里在
# 截图前先把页面跑到「已出图」状态。
#
# 另外，页面默认全选 29 个算法 × 12 个函数，收敛曲线会画出近 700 条线，
# 图例与曲线糊成一团、反而看不清。统一改选 5 个覆盖
# 「经典 DE → 自适应 → SHADE 系 → 秩选择压力」的代表算法。
#
# 函数不能随手挑 F1：CEC2022 的 F1/F2/F3/F5 上有算法会把误差收敛到 0，后端
# 按 log10(max(v, 1e-300)) 取值后纵轴被拉到 -300，其余曲线全挤在顶部看不出
# 差异（results_api.py:143）；F9~F12 这类复合函数则所有算法都停在同一个局部
# 最优、曲线完全重叠。取 F4/F6/F8，量级跨度约 -0.6 ~ 2.9 且各算法互有高低。
DEMO_HOSTS = ['DE/rand/1', 'DE/best/1', 'SHADE', 'L-SHADE', 'NL-SHADE-RSP']
DEMO_FIDS = [4, 6, 8]

# 等待某个 echarts 容器真正拿到 series（= 画出了东西），避免截图抢在渲染前。
_WAIT_SERIES_JS = """
(id) => {
  const el = document.getElementById(id);
  const c = el && window.echarts && echarts.getInstanceByDom(el);
  const o = c && c.getOption();
  return !!(o && o.series && o.series.length);
}
"""


def _wait_series(page, dom_id: str, timeout: int = 60000) -> None:
    """等到指定图表出现 series；超时只告警，不中断整体采集。"""
    try:
        page.wait_for_function(_WAIT_SERIES_JS, arg=dom_id, timeout=timeout)
    except Exception as exc:
        print(f"    ! 等待 {dom_id} 出图超时：{exc}")


def _js_pick(pid: str, hosts, fids, arms=None) -> str:
    """在页面实例上直接改选算法/函数（比逐个点 chip 稳），并把 chip 状态重绘。"""
    js = (
        "() => { const p = LASE.pages['%s'];"
        " p._hosts = new Set(%s);"
        " p._fids = new Set(%s);"
        " p._renderHosts(); p._renderFids();"
    ) % (pid, json.dumps(hosts, ensure_ascii=False), json.dumps(fids))
    if arms is not None:
        js += " p._arms = new Set(%s);" % json.dumps(arms)
    return js + " return true; }"


def _prep_convergence(page) -> None:
    """收敛曲线：选代表算法/函数，点「绘制曲线」。"""
    page.evaluate(_js_pick('convergence', DEMO_HOSTS, DEMO_FIDS, ['bare']))
    page.click('#conv-plot')
    _wait_series(page, 'conv-chart')


def _prep_compare(page) -> None:
    """算法对比：两臂都要留，否则配对对比图没有数据点。"""
    page.evaluate(_js_pick('compare', DEMO_HOSTS, DEMO_FIDS, ['bare', 'upcl']))
    page.click('#cmp-run')
    for cid in ('cmp-dist', 'cmp-rank', 'cmp-ert', 'cmp-paired', 'cmp-heat'):
        _wait_series(page, cid)


def _prep_mechanism(page) -> None:
    """机制分析：点「机制分析」出 5 张图（效应量/干预率/描述子/散点/演化）。"""
    page.evaluate(_js_pick('mechanism', DEMO_HOSTS, DEMO_FIDS))
    page.click('#mech-analyze')
    for cid in ('mech-dec', 'mech-rate', 'mech-desc', 'mech-scat', 'mech-rho'):
        _wait_series(page, cid)


def _prep_landscape(page) -> None:
    """地形图：点「开始采样」跑一次真实采样，等后台任务结束（耗时较长）。"""
    page.click('#land-run')
    try:
        page.wait_for_function(
            "() => { const e = document.getElementById('land-prog');"
            " return e && (e.textContent.indexOf('采样完成') >= 0"
            " || e.textContent.indexOf('失败') >= 0); }",
            timeout=40 * 60 * 1000,
        )
    except Exception as exc:
        print(f"    ! 地形图采样等待超时：{exc}")
    _wait_series(page, 'land-2d')


# ---------------------------------------------------------------- 实验运行页
# 这张页面的内容（进度 / 日志 / worker 表）全部由 WebSocket 实时推送，空闲时
# 整页是空的。不走「真启动一次实验」的原因：task_manager.start() 不传 --fids，
# 一旦启动就会把该 suite 的全部函数跑一遍（cec2013 D10 要 500+ cell），代价和
# 数据污染都无法接受。这里改为「重放」上一次真实的 cec2017 D30 实验所留下的
# 产物——日志片段取自 logs/cec2017_D30.log（157/290 处），worker 表取自
# logs/.workers/*.json 的 19 个真实进程记录，字段与格式都是现场原样。
_APP_LOG_DIR = ROOT / 'app' / 'webapp' / 'results' / 'cec' / 'logs'
_REPLAY_LOG = _APP_LOG_DIR / 'cec2017_D30.log'
_REPLAY_WORKERS = _APP_LOG_DIR / '.workers'

_EXP_STATUS = {
    'state': 'running', 'running': True, 'pid': 21308,
    'suite': 'cec2017', 'dim': 30,
    # 与 _REPLAY_LOG 截取段的末行保持完全一致，避免图和文字对不上
    'progress': {'finished': 157, 'total': 290, 'pct': 54.1,
                 'elapsed_min': 31.5, 'eta_min': 26.7},
}

_PREP_EXPERIMENT_JS = """
(args) => {
  const p = LASE.pages.experiment;
  if (p._suiteSel) {
    p._suiteSel.value = 'cec2017';
    p._suiteSel.dispatchEvent(new Event('change'));   // 触发维度下拉重填
    if (p._dimSel) p._dimSel.value = 'D30';
    if (p._runsInp) p._runsInp.value = 30;
    if (p._workersInp) p._workersInp.value = 19;
    if (p._evalsInp) p._evalsInp.value = 10000;
    if (p._upclSel) p._upclSel.value = '1';
    p._selHosts = new Set(LASE.meta.hosts.slice(0, 10));
    p._renderHosts();
  }
  p._applyStatus(args.status);
  // 历史 worker 快照里还留着已下线的算法（如 LSHADE-HS），按当前算法清单过滤
  const allowed = new Set(LASE.meta.hosts);
  p._applyWorkers({workers: (args.workers || []).filter(w => allowed.has(w.host))});
  (args.logs || []).forEach(l => p._appendLog(l));
  return true;
}
"""


def _read_lines(path, skip: int, n: int):
    """读文本文件的 [skip, skip+n) 行；文件缺失时返回空表。"""
    if not path.exists():
        return []
    text = path.read_text(encoding='utf-8', errors='replace')
    return text.splitlines()[skip:skip + n]


def _read_workers(dir_path):
    """读 logs/.workers/w*.json；状态字段标为 running 以便呈现「运行中」。"""
    out = []
    if not dir_path.is_dir():
        return out
    for p in sorted(dir_path.glob('w*.json')):
        try:
            item = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        item['status'] = 'running'
        item.pop('updated', None)
        out.append(item)
    return out


def _prep_experiment(page) -> None:
    """重放真实实验的运行态，把「空闲」的空界面填满。"""
    page.evaluate(_PREP_EXPERIMENT_JS, {
        'status': _EXP_STATUS,
        'workers': _read_workers(_REPLAY_WORKERS),
        'logs': _read_lines(_REPLAY_LOG, 290, 90),
    })


# -------------------------------------------------------------------- UAV 页
_PREP_UAV_JS = """
async () => {
  const u = LASE.pages.uav;
  const lm = document.getElementById('uav-load-map');       // 加载地形
  if (lm) lm.click();
  // 回放一条论文实验轨迹：一次把统计卡 / 俯视图 / 收敛曲线 / 实景轨迹都填满
  try { await u._playPaperTrace(1, 'NL-SHADE-RSP', 0, 'full'); } catch (e) {}
  const b3 = document.querySelector('#uav-viewmode button[data-vm="3d"]');
  if (b3) b3.click();                                       // 切到 3D 沙盘
  return true;
}
"""


def _prep_uav(page) -> None:
    """UAV 页：加载地形 + 回放论文已有轨迹，避免现场跑仿真。"""
    page.evaluate(_PREP_UAV_JS)
    page.wait_for_timeout(2500)          # 3D 沙盘需要几帧才渲染完
    _wait_series(page, 'uav-conv')


# 各页面截图前的准备动作（key = 页面 id）
_PREP = {
    'convergence': _prep_convergence,
    'compare': _prep_compare,
    'mechanism': _prep_mechanism,
    'landscape': _prep_landscape,
    'experiment': _prep_experiment,
    'uav': _prep_uav,
}


def _safe(name: str) -> str:
    """把卡片标题转成安全的文件名片段。"""
    name = re.sub(r"[\s/\\:*?\"<>|（）()·]+", "-", name).strip("-")
    return name[:24] or "untitled"


def _login(page) -> None:
    """打开首页并完成登录（已登录则直接复用 token）。"""
    page.goto(BASE_URL, wait_until="domcontentloaded")
    page.wait_for_timeout(1500)
    if page.locator("#login-overlay.show").count():
        # 顺手留一张登录页截图（手册第 4 章要用），趁未登录时截
        page.screenshot(path=str(SHOT_DIR / "00_登录页.png"))
        page.fill("#login-user", USERNAME)
        page.fill("#login-pass", PASSWORD)
        page.click("#login-btn")
        page.wait_for_load_state("networkidle")
        page.wait_for_timeout(2000)
    page.wait_for_selector(".nav-item", timeout=20000)


def _settle(page) -> None:
    """等待页面数据加载稳定。"""
    page.wait_for_timeout(900)
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    page.wait_for_timeout(700)


def _fit_viewport(page) -> None:
    """把视口高度撑到内容高度，避免整屏图被内容区的内部滚动裁掉。"""
    try:
        h = page.evaluate(
            "() => { const c = document.querySelector('.content');"
            " return c ? c.scrollHeight : document.documentElement.scrollHeight; }"
        )
    except Exception:
        h = VIEWPORT["height"]
    height = max(VIEWPORT["height"], min(int(h) + 60, 3200))
    page.set_viewport_size({"width": VIEWPORT["width"], "height": height})
    page.wait_for_timeout(400)


def _capture(page, idx: int, pid: str, label: str) -> None:
    """采集单个页面：整屏 1 张 + 每个卡片 1 张。"""
    tag = f"{idx:02d}_{pid}"
    page.click(f'.nav-item[data-page="{pid}"]')
    # 关键：把指针移出侧边栏。侧栏是靠 :hover 展开的悬浮层（64px -> 240px），
    # 点击导航后指针停在侧栏上会让它展开并盖住内容区左侧。
    page.mouse.move(VIEWPORT["width"] - 120, VIEWPORT["height"] - 140)
    _settle(page)

    # 先让页面进入「有数据」状态（绘制曲线 / 加载分析 / 地形采样），再截图
    prep = _PREP.get(pid)
    if prep:
        print(f"    · {label}：准备演示数据…")
        prep(page)
        _settle(page)

    _fit_viewport(page)
    page.screenshot(path=str(SHOT_DIR / f"{tag}_00_整屏.png"))

    cards = page.locator(f'.page[data-page="{pid}"] .card')
    total = cards.count()
    for i in range(total):
        card = cards.nth(i)
        try:
            card.scroll_into_view_if_needed()
            page.wait_for_timeout(250)
            try:
                title = card.locator(".card-title").first.inner_text(timeout=1000).strip()
            except Exception:
                title = ""
            suffix = _safe(title) if title else "card"
            card.screenshot(path=str(SHOT_DIR / f"{tag}_{i + 1:02d}_{suffix}.png"))
        except Exception as exc:  # 卡片可能处于隐藏/动画状态
            print(f"    ! 跳过卡片 {i + 1}：{exc}")
    print(f"[{pid}] {label}：整屏 1 张 + 卡片 {total} 张")


def main() -> int:
    ap = argparse.ArgumentParser(description="采集使用手册界面截图")
    ap.add_argument("pages", nargs="*", help="只采集这些页面 id（默认全部）")
    ap.add_argument("--headed", action="store_true", help="显示浏览器窗口")
    args = ap.parse_args()

    targets = [p for p in PAGES if not args.pages or p[1] in args.pages]
    if not targets:
        print("没有匹配的页面 id")
        return 1

    SHOT_DIR.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as pw:
        browser = pw.chromium.launch(channel="msedge", headless=not args.headed)
        ctx = browser.new_context(viewport=VIEWPORT, device_scale_factor=2, locale="zh-CN")
        page = ctx.new_page()
        _login(page)
        print("[登录] 成功\n")
        for idx, pid, label in targets:
            _capture(page, idx, pid, label)
        browser.close()

    print(f"\n完成，截图目录：{SHOT_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

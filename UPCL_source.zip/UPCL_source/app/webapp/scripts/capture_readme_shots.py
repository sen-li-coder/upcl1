# -*- coding: utf-8 -*-
"""拍摄 README 用的 Web 平台界面截图（真实数据 + 真实交互）。

依赖：先启动服务 `cd app/webapp && python -m uvicorn web.server:app --port 8000`，
      以及 `pip install playwright pillow && python -m playwright install msedge`。

用法：
    python app/webapp/scripts/capture_readme_shots.py            # 全部 10 张
    python app/webapp/scripts/capture_readme_shots.py uav        # 只重拍某几页

产物：docs/screenshots/NN_<page>.jpg（1600 宽）+ 同名 .png 原图（device_scale_factor=2）。
说明：
- 页面主滚动容器不是 window，复位时遍历所有可滚动元素；
- anchor 传 'card:#id' 表示滚到该元素所在卡片顶部；
- max_h 把视口裁短，只留主体那一段；
- 分析页会先按「清空 + 点选」收窄算法/函数组合，避免 29×12 全选时曲线糊成一片。
"""
import os
import sys
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright

sys.stdout.reconfigure(encoding='utf-8')

ROOT = Path(__file__).resolve().parents[3]      # scripts -> webapp -> app -> 项目根
OUT = ROOT / 'docs' / 'screenshots'
URL = os.environ.get('LASE_WEB_URL', 'http://127.0.0.1:8000/')
LOGIN = """async () => {
  const r = await fetch('/api/auth/login', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({username:'admin', password:'admin123'})});
  localStorage.setItem('lase_token', (await r.json()).token);
}"""
CANVAS_N = """() => [...document.querySelectorAll('canvas')]
  .filter(c => c.width > 50 && c.height > 50 && c.getBoundingClientRect().width > 50).length"""
DEMO_FIDS = ['4', '6', '8']                                     # 避开误差收敛到 0 的 F1/F2/F3/F5
DEMO_HOSTS = ['DE/rand/1', 'DE/best/1', 'SHADE', 'L-SHADE', 'NL-SHADE-RSP']
DEMO_WAVE4 = ['jDE100', 'DISH', 'DISK', 'MadDE', 'SHADE-ILS']    # 机制分析只在这些 wave4 变体上有 full 臂

SCROLL_TOP = """() => {
  window.scrollTo(0, 0);
  [...document.querySelectorAll('*')].forEach(e => {
    if (e.scrollHeight > e.clientHeight + 4 && getComputedStyle(e).overflowY !== 'visible') e.scrollTop = 0;
  });
}"""
SCROLL_TO = """([sel, useCard]) => {
  let e = document.querySelector(sel);
  if (e && useCard) e = e.closest('.card') || e;
  if (e) e.scrollIntoView({block: 'start'});
}"""
SCROLL_BY = """(d) => {
  window.scrollBy(0, d);
  [...document.querySelectorAll('*')].forEach(e => {
    if (e.scrollHeight > e.clientHeight + 4 && getComputedStyle(e).overflowY !== 'visible') e.scrollTop += d;
  });
}"""


def nav(pg, pid):
    pg.evaluate("(id) => LASE.navigate(id)", pid)
    pg.wait_for_timeout(900)


def wait_canvas(pg, n=1, timeout_ms=45000):
    pg.wait_for_function(f"() => ({CANVAS_N})() >= {n}", timeout=timeout_ms)


def pick(pg, btns_id, list_id, values):
    """点「清空」再按文本点亮目标 chip，走页面自身的状态更新。"""
    pg.click(f'#{btns_id} button:nth-child(2)')
    pg.wait_for_timeout(250)
    hit = pg.evaluate("""([sel, vals]) => {
      const box = document.querySelector(sel);
      const hit = [...box.querySelectorAll('.chip')].filter(c => vals.includes(c.textContent.trim()));
      hit.forEach(c => c.click());
      return hit.length;
    }""", [f'#{list_id}', values])
    pg.wait_for_timeout(300)
    return hit


def content_bottom(pg):
    return pg.evaluate("""() => {
      const id = window.LASE.current;
      const page = document.querySelector('.page[data-page="' + id + '"]');
      let b = 0;
      page.querySelectorAll('.card, .page-head, .hero').forEach(e => {
        const r = e.getBoundingClientRect();
        if (r.height > 0 && r.top < innerHeight) b = Math.max(b, r.bottom);
      });
      return Math.round(b);
    }""")


def shot(pg, name, anchor=None, offset=130, min_h=620, hover_sidebar=False, max_h=None):
    if hover_sidebar:
        pg.hover('.sidebar')
        pg.wait_for_timeout(500)
    if anchor:
        card = anchor.startswith('card:')
        sel = anchor[5:] if card else anchor
        pg.evaluate(SCROLL_TO, [sel, card])
        pg.wait_for_timeout(400)
        pg.evaluate(SCROLL_BY, -offset)
        pg.wait_for_timeout(800)
        clip = {'x': 0, 'y': 0, 'width': 1600, 'height': max_h} if max_h else None
    else:
        pg.evaluate(SCROLL_TOP)
        pg.wait_for_timeout(900)
        h = max(min_h, min(1000, content_bottom(pg) + 18))
        clip = {'x': 0, 'y': 0, 'width': 1600, 'height': max_h or h}
    png = OUT / (name + '.png')
    pg.screenshot(path=str(png), full_page=False, clip=clip)
    im = Image.open(png).convert('RGB')
    if im.size[0] > 1600:
        im = im.resize((1600, round(im.size[1] * 1600 / im.size[0])), Image.LANCZOS)
    jpg = OUT / (name + '.jpg')
    im.save(jpg, 'JPEG', quality=86, optimize=True, progressive=True)
    return jpg, os.path.getsize(jpg), im.size


PLAN = []


def add(pid, name, anchor=None, offset=130, min_h=620, hover=False, max_h=None, vh=1000):
    PLAN.append(dict(pid=pid, name=name, anchor=anchor, offset=offset,
                     min_h=min_h, hover=hover, max_h=max_h, vh=vh))


add('dashboard', '01_dashboard', min_h=1000, hover=True)
add('convergence', '02_convergence', '#conv-chart', 165)
add('compare', '03_compare', 'card:#cmp-dist', 70)
add('mechanism', '04_mechanism', 'card:#mech-dec', 65, max_h=505)
add('uav', '05_uav', 'card:#uav-repr-grid', 60, max_h=625)
add('afsim', '06_afsim', min_h=1000, max_h=1620, vh=1660)   # 需要高视口才装得下英雄区 + 战场图
add('research', '07_research', '.rf-fig-wrap', 95)
add('refs', '08_refs', min_h=760)
add('ontology', '09_ontology', '#ont-chart', 145)
add('landscape', '10_landscape', 'card:#land-2d', 55)
add('archive', '11_archive', min_h=680)

ACTION = {}


def act(pid):
    def deco(fn):
        ACTION[pid] = fn
        return fn
    return deco


@act('dashboard')
def _(pg):
    pg.wait_for_timeout(1600)


@act('convergence')
def _(pg):
    pick(pg, 'conv-fid-btns', 'conv-fids', DEMO_FIDS)
    pick(pg, 'conv-host-btns', 'conv-hosts', DEMO_HOSTS)
    pg.click('#conv-plot')
    wait_canvas(pg, 1)


@act('compare')
def _(pg):
    pick(pg, 'cmp-fid-btns', 'cmp-fids', DEMO_FIDS)
    pick(pg, 'cmp-host-btns', 'cmp-hosts', DEMO_HOSTS)
    pg.click('#cmp-run')
    wait_canvas(pg, 4, timeout_ms=90000)


@act('mechanism')
def _(pg):
    pick(pg, 'mech-fid-btns', 'mech-fids', ['4', '6'])
    pick(pg, 'mech-host-btns', 'mech-hosts', DEMO_WAVE4)
    pg.click('#mech-analyze')
    wait_canvas(pg, 4, timeout_ms=90000)


@act('landscape')
def _(pg):
    pg.click('#land-run')
    wait_canvas(pg, 1, timeout_ms=90000)


@act('uav')
def _(pg):
    pg.click('#uav-load-map')
    pg.wait_for_timeout(2500)
    pg.evaluate("() => { try { LASE.pages.uav._playPaperTrace(1, 'NL-SHADE-RSP', 0, 'full'); } catch (e) {} }")
    pg.wait_for_timeout(3000)


@act('afsim')
def _(pg):
    # 页面进来自动探测引擎并复核一局（真实 mission.exe，秒级 + 缓存），等对比表出行
    pg.wait_for_function(
        "() => { const t = document.querySelector('#afs-table table'); "
        "return !!(t && t.querySelectorAll('tbody tr').length); }", timeout=120000)
    pg.wait_for_timeout(1500)


@act('ontology')
def _(pg):
    pg.click('#ont-gen')
    pg.wait_for_timeout(2500)
    pg.click('#ontk-gen')
    wait_canvas(pg, 2, timeout_ms=80000)


@act('research')
def _(pg):
    pg.wait_for_timeout(1000)


def main():
    wanted = set(sys.argv[1:])
    report = []
    OUT.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch(channel='msedge')
        pg = b.new_page(viewport={'width': 1600, 'height': 1000}, device_scale_factor=2)
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)[:100]))
        pg.goto(URL, wait_until='networkidle')
        pg.evaluate(LOGIN)
        pg.reload(wait_until='networkidle')
        pg.wait_for_timeout(1200)
        for item in PLAN:
            if wanted and item['pid'] not in wanted:
                continue
            try:
                if pg.viewport_size['height'] != item['vh']:
                    pg.set_viewport_size({'width': 1600, 'height': item['vh']})
                nav(pg, item['pid'])
                if item['pid'] in ACTION:
                    ACTION[item['pid']](pg)
                jpg, size, dim = shot(pg, item['name'], item['anchor'], item['offset'],
                                      item['min_h'], item['hover'], item['max_h'])
                report.append((item['name'], size))
                print(f"{item['name']:16s} {dim[0]}x{dim[1]:<5d} {size/1024:7.1f} KB ok", flush=True)
            except Exception as exc:
                print(f"{item['name']:16s} FAIL {str(exc)[:110]}", flush=True)
        print('pageerrors:', errs[:4])
        b.close()
    print('--- total', round(sum(r[1] for r in report) / 1024, 1), 'KB /', len(report), 'shots')


if __name__ == '__main__':
    main()

﻿<#
.SYNOPSIS
    批量录制「算法 × 任务」的 Warlock 演示视频，录完自动刷新前端清单。

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File app\webapp\scripts\record_warlock_demos.ps1
    powershell ... -List 'JADE:1,SaDE:1,CoBiDE:2' -WaitSec 72
#>
param(
    [string]$List = 'JADE:1,SaDE:1,CoBiDE:2,CoBiDE:3,CoBiDE:4,NL-SHADE-RSP:4',
    [int]$WaitSec = 72,
    [int]$Run = 0
)

$ErrorActionPreference = 'Stop'
$single = Join-Path $PSScriptRoot 'record_warlock_demo.ps1'
$combos = $List.Split(',') | Where-Object { $_.Trim() }
$i = 0
foreach ($c in $combos) {
    $i++
    $parts = $c.Trim().Split(':')
    $hostName = $parts[0]
    $fid = [int]$parts[1]
    Write-Host ''
    Write-Host ("=== [{0}/{1}] {2} F{3} ===" -f $i, $combos.Count, $hostName, $fid)
    & $single -HostName $hostName -Fid $fid -Run $Run -WaitSec $WaitSec
    # 单录脚本最后一步会用 ffmpeg 仅探测输出（此时 exit=1 属正常），故以产物是否存在判定成败
    $slug = ($hostName -replace '[\\/]', '-') -replace '\s+', ''
    $mp4 = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\web\static\media\afsim_warlock_${slug}_F${fid}_run${Run}.mp4"))
    if (Test-Path $mp4) {
        Write-Host ("      OK -> {0} ({1:N0} B)" -f $mp4, (Get-Item $mp4).Length)
    }
    else {
        Write-Warning ("{0} F{1} 录制失败（未产出 {2}），继续下一个" -f $hostName, $fid, $mp4)
    }
}

Write-Host ''
Write-Host '=== 刷新演示清单 ==='
& python (Join-Path $PSScriptRoot 'build_warlock_manifest.py')

"""扫描 static/media 下已录制的 warlock.exe 演示视频，生成前端读取的清单。

用法：python app/webapp/scripts/build_warlock_manifest.py
每次用 record_warlock_demo.ps1 录完新视频后会自动调用。
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime
from pathlib import Path

MEDIA = Path(__file__).resolve().parents[1] / 'web' / 'static' / 'media'
OUT = MEDIA / 'afsim_warlock_demos.json'
PAT = re.compile(r'^afsim_warlock_(?P<host>.+?)_F(?P<fid>\d+)(?:_run(?P<run>\d+))?\.mp4$')

TASK_NAMES = {1: '基线突防', 2: '禁飞区绕行', 3: '双机拦截', 4: '强拦截对抗'}


def build() -> dict:
    items = []
    for p in sorted(MEDIA.glob('afsim_warlock_*.mp4')):
        m = PAT.match(p.name)
        if not m:
            continue
        poster = p.with_suffix('.jpg')
        st = p.stat()
        fid = int(m.group('fid'))
        items.append({
            'host': m.group('host'),
            'fid': fid,
            'run': int(m.group('run') or 0),
            'task': TASK_NAMES.get(fid, 'F%d' % fid),
            'url': '/media/' + p.name,
            'poster': ('/media/' + poster.name) if poster.is_file() else None,
            'bytes': st.st_size,
            'mtime': int(st.st_mtime),
        })
    items.sort(key=lambda d: (d['host'], d['fid'], d['run']))
    return {
        'generated': datetime.now().isoformat(timespec='seconds'),
        'count': len(items),
        'hosts': sorted({d['host'] for d in items}),
        'fids': sorted({d['fid'] for d in items}),
        'items': items,
    }


def main() -> int:
    data = build()
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    print('wrote %s (%d items)' % (OUT, data['count']))
    for it in data['items']:
        print('  %-18s F%d run%d  %s  %.1f KB'
              % (it['host'], it['fid'], it['run'], it['task'], it['bytes'] / 1024.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())

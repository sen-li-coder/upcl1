# -*- coding: utf-8 -*-
"""使用手册导出 PDF（pandoc -> HTML -> 本机 Edge 打印 PDF）。

为什么要绕一圈 HTML：手册含 55 张位图截图 + 大量多列宽表格 + 中文，
LaTeX 链路（pandoc -o pdf）在中文字体与表格换行上容易翻车；先转 HTML
再用 Chromium 打印，排版/字体/分页完全由 CSS 控制，效果稳定。

流程：
    1. 读取 docs/manual/使用手册.md，去掉手写「目录」（改用 pandoc 生成的 TOC）；
    2. pandoc 转 standalone HTML（图片保持 shots/xxx.png 相对路径）；
    3. 后处理 HTML：把标题 id 重排成 GitHub 风格锚点（与手册正文里的
       [xx](#xx) 交叉引用一致）、注入打印 CSS、插入封面页；
    4. playwright 驱动本机 Edge 无头打印 A4 PDF，带页脚页码。

依赖：pandoc（>=3）、pip install playwright、系统已装 Edge。

用法（在项目根 E:\LASE 下执行；脚本本体位于 app/webapp/scripts/）：
    python app/webapp/scripts/build_manual_pdf.py                # 输出 docs/manual/使用手册.pdf
    python app/webapp/scripts/build_manual_pdf.py --keep-html    # 同时保留中间 HTML
"""
from __future__ import annotations

import argparse
import html as html_mod
import pathlib
import re
import subprocess
import sys

from playwright.sync_api import sync_playwright

# 脚本位于 app/webapp/scripts/，项目根 E:\LASE 是上三级
ROOT = pathlib.Path(__file__).resolve().parents[3]
MANUAL_DIR = ROOT / "docs" / "manual"
MD_PATH = MANUAL_DIR / "使用手册.md"
HTML_PATH = MANUAL_DIR / "使用手册.html"
PDF_PATH = MANUAL_DIR / "使用手册.pdf"
TMP_MD = MANUAL_DIR / "_pdf_build.md"

META = {
    "title": "进化算法机制研究平台",
    "subtitle": "Web 版完整使用手册",
    "version": "v1.0",
    "date": "2026-10-12",
    "scope": "11 个页面 · 200+ 控件 · 55 张截图",
}

# ---------------------------------------------------------------- markdown

def strip_handwritten_toc(md: str) -> str:
    """整理交给 pandoc 的正文。

    1. 去掉手写的「## 目录」区块（到下一个 --- 为止），改用 pandoc 的 TOC；
    2. 截断到第一个二级标题——标题行、元信息引用块、分隔线都已由封面承担，
       留着它们会让目录多出根节点，还会让正文第一页只剩一条分隔线。
    """
    md = re.sub(r"(?ms)^##\s*目录\s*$.*?^---\s*$", "", md, count=1)
    m = re.search(r"(?m)^##\s+\S", md)
    return md[m.start():] if m else md


def run_pandoc(md_text: str) -> str:
    TMP_MD.write_text(md_text, encoding="utf-8")
    cmd = [
        "pandoc",
        str(TMP_MD),
        "-f", "gfm",
        "-t", "html5",
        "--standalone",
        "--toc",
        "--toc-depth=2",
        "--metadata", f"title={META['title']} {META['subtitle']}",
        "--metadata", "lang=zh-CN",
        "-o", str(HTML_PATH),
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    if res.returncode != 0:
        raise RuntimeError(f"pandoc 失败：{res.stderr.strip()}")
    return HTML_PATH.read_text(encoding="utf-8")


# ---------------------------------------------------------------- anchors

def gh_slug(text: str) -> str:
    """GitHub/VS Code 风格锚点：小写、去标点、空格转连字符（保留中文与数字）。"""
    s = text.strip().lower()
    s = s.replace("\u3000", " ")
    s = re.sub(r"[^\w\s-]", "", s, flags=re.UNICODE)
    s = re.sub(r"\s+", "-", s)
    return s.strip("-")


def strip_tags(s: str) -> str:
    return html_mod.unescape(re.sub(r"<[^>]+>", "", s)).strip()


HEADING_RE = re.compile(r"<h([1-6])((?:\s[^>]*)?)>(.*?)</h\1>", re.S)


def retag_headings(html: str) -> tuple[str, dict[str, str], list[str]]:
    """把 pandoc 生成的标题 id 换成本手册正文交叉引用用的 GitHub 锚点。"""
    mapping: dict[str, str] = {}
    used: dict[str, int] = {}
    ids: list[str] = []

    def repl(m: re.Match) -> str:
        level, attrs, inner = m.group(1), m.group(2) or "", m.group(3)
        old = re.search(r'id="([^"]*)"', attrs)
        old_id = old.group(1) if old else ""
        slug = gh_slug(strip_tags(inner)) or "section"
        if slug in used:
            used[slug] += 1
            slug = f"{slug}-{used[slug]}"
        else:
            used[slug] = 0
        if old_id:
            mapping[old_id] = slug
        ids.append(slug)
        attrs = re.sub(r'\s*id="[^"]*"', "", attrs)
        return f'<h{level}{attrs} id="{slug}">{inner}</h{level}>'

    html = HEADING_RE.sub(repl, html)

    # 把指向旧 id 的链接（pandoc 自建 TOC / 正文索引）改到新 id
    def fix_href(m: re.Match) -> str:
        target = m.group(1)
        return f'href="#{mapping.get(target, target)}"'

    html = re.sub(r'href="#([^"]*)"', fix_href, html)

    wanted = {m.group(1) for m in re.finditer(r'href="#([^"]*)"', html)}
    missing = sorted(w for w in wanted if w not in set(ids))
    return html, mapping, missing


# ---------------------------------------------------------------- css

CSS = """
:root { --ink:#1f2937; --sub:#6b7280; --line:#e5e7eb; --accent:#2563eb; }
* { box-sizing: border-box; }
body {
  font-family: "Microsoft YaHei", "PingFang SC", "Source Han Sans SC", sans-serif;
  color: var(--ink); font-size: 10.5pt; line-height: 1.72;
  margin: 0; padding: 0;
}
header#title-block-header { display: none; }

/* ---------- 封面 ---------- */
.cover { height: 250mm; display: flex; flex-direction: column;
         justify-content: center; align-items: center; text-align: center;
         break-after: page; }
.cover .badge { font-size: 11pt; letter-spacing: .5em; color: var(--accent);
                border: 1.5px solid var(--accent); border-radius: 999px;
                padding: 4px 14px 4px 20px; margin-bottom: 26px; }
.cover .t1 { font-size: 30pt; font-weight: 800; letter-spacing: .06em;
             margin: 0 0 10px; color: #0f172a; }
.cover .t2 { font-size: 15pt; color: var(--sub); margin: 0 0 40px;
             font-weight: 400; letter-spacing: .12em; }
.cover .rule { width: 120px; height: 3px; background: var(--accent);
               border-radius: 2px; margin-bottom: 40px; }
.cover .meta { font-size: 10.5pt; color: #374151; line-height: 2.1; }
.cover .meta b { display: inline-block; width: 84px; text-align: right;
                 color: var(--sub); font-weight: 500; margin-right: 10px; }
.cover .note { margin-top: 34px; max-width: 118mm; font-size: 9pt;
               color: var(--sub); line-height: 1.8;
               border-top: 1px solid var(--line); padding-top: 12px; }

/* ---------- 目录 ---------- */
nav#TOC { break-before: page; break-after: page; }
nav#TOC::before { content: "目录"; display: block; font-size: 19pt;
                  font-weight: 700; margin: 0 0 14px; padding-bottom: 8px;
                  border-bottom: 2px solid var(--accent); }
nav#TOC > ul { list-style: none; padding-left: 0; column-count: 2;
               column-gap: 14mm; }
nav#TOC ul ul { display: none; }
nav#TOC li { margin: 3px 0; break-inside: avoid; }
nav#TOC a { color: var(--ink); text-decoration: none; font-size: 11pt; }
nav#TOC a::after { content: ""; }

/* ---------- 标题与分页 ---------- */
h1, h2, h3, h4 { line-height: 1.35; break-after: avoid; }
h2 { break-before: page; font-size: 19pt; margin: 0 0 6mm;
     padding-bottom: 8px; border-bottom: 2px solid var(--accent);
     color: #0f172a; }
h3 { font-size: 13.5pt; margin: 7mm 0 3mm; color: #111827; }
h4 { font-size: 11.5pt; margin: 5mm 0 2mm; color: #1f2937; }
h2 + h3, h3 + h4 { margin-top: 3mm; }
hr { border: 0; border-top: 1px solid var(--line); margin: 5mm 0; }

/* ---------- 正文 ---------- */
p { margin: 0 0 3mm; orphans: 3; widows: 3; }
a { color: var(--accent); text-decoration: none; word-break: break-all; }
strong { color: #111827; }
ul, ol { margin: 0 0 3mm; padding-left: 6mm; }
li { margin: 1mm 0; }
blockquote { margin: 0 0 4mm; padding: 3mm 4mm; background: #f8fafc;
             border-left: 3px solid var(--accent); border-radius: 3px;
             color: #374151; font-size: 10pt; }
blockquote p:last-child { margin-bottom: 0; }
code { font-family: Consolas, "Courier New", monospace; font-size: 9.5pt;
       background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 3px;
       padding: 0 3px; color: #0f172a; word-break: break-word; }
pre { background: #f8fafc; border: 1px solid var(--line); border-radius: 4px;
      padding: 3mm 4mm; overflow-wrap: anywhere; white-space: pre-wrap;
      break-inside: avoid; font-size: 9pt; }
pre code { background: none; border: 0; padding: 0; }

/* ---------- 表格 ---------- */
table { width: 100%; border-collapse: collapse; margin: 0 0 4mm;
        font-size: 9pt; line-height: 1.55; }
/* pandoc 会按源码里 --- 的长短写死 colgroup 百分比，短列会被压扁；
   改回按内容自适应，长文本列自动占宽。 */
colgroup, col { width: auto !important; }
thead { display: table-header-group; }
th, td { border: 1px solid #dbe1ea; padding: 2.2mm 2.4mm; text-align: left;
         vertical-align: top; word-break: break-word; }
th { background: #eef2f7; font-weight: 600; color: #0f172a; }
/* 首列多是「方法 / 控件名 / 术语」这类短词，禁止折行可避免 POST 被拆成 POS T；
   若真撑破了页宽，构建时的一致性体检会报出来。 */
th:first-child, td:first-child { white-space: nowrap; }
tbody tr:nth-child(even) { background: #fafbfd; }
tr { break-inside: avoid; }

/* ---------- 图片 ---------- */
figure { margin: 0 0 5mm; text-align: center; break-inside: avoid; }
img { max-width: 100%; max-height: 205mm; height: auto;
      border: 1px solid #d7dee8; border-radius: 4px; }
figcaption { font-size: 9pt; color: var(--sub); margin-top: 2mm; }
p > img { display: block; margin: 3mm auto; }
"""

COVER = """
<section class="cover">
  <div class="badge">使用手册</div>
  <div class="t1">{title}</div>
  <div class="t2">{subtitle}</div>
  <div class="rule"></div>
  <div class="meta">
    <div><b>版本</b>{version}</div>
    <div><b>发布日期</b>{date}</div>
    <div><b>覆盖范围</b>{scope}</div>
    <div><b>适用系统</b>app/webapp（Web 版）</div>
  </div>
  <div class="note">
    全部截图位于 docs/manual/shots/，以 2× 分辨率采集，可直接放大查看控件细节；
    截图由 app/webapp/scripts/capture_manual_shots.py 自动生成，界面改版后可一键重采。
    本 PDF 由 app/webapp/scripts/build_manual_pdf.py 自动构建（pandoc → HTML → Edge 打印）。
  </div>
</section>
"""


def build_html(body_html: str) -> str:
    css = f"<style>{CSS}</style>"
    body_html = body_html.replace("</head>", css + "\n</head>", 1)
    body_html = body_html.replace("<body>", "<body>\n" + COVER.format(**META), 1)
    return body_html


# ---------------------------------------------------------------- pdf

FOOTER = (
    '<div style="width:100%;font-family:Microsoft YaHei,sans-serif;font-size:8pt;'
    'color:#94a3b8;padding:0 13mm;display:flex;justify-content:space-between;">'
    f'<span>{META["title"]} · {META["subtitle"]} {META["version"]}</span>'
    '<span>第 <span class="pageNumber"></span> / '
    '<span class="totalPages"></span> 页</span></div>'
)


QA_JS = """
() => {
  const out = { overflow: [], broken: [], imgs: 0 };
  const root = document.body.clientWidth;
  document.querySelectorAll('table, pre, img, figure').forEach(el => {
    if (el.scrollWidth > root + 2) out.overflow.push(el.tagName + ':' +
      (el.className || '') + ':' + el.scrollWidth + '>' + root);
  });
  document.querySelectorAll('img').forEach(im => {
    out.imgs++;
    if (!im.complete || !im.naturalWidth) out.broken.push(im.getAttribute('src'));
  });
  return out;
}
"""


def check_layout(page) -> None:
    """打印前体检：图片是否全部加载、有没有元素横向溢出被裁掉。"""
    qa = page.evaluate(QA_JS)
    if qa["broken"]:
        print(f"      警告：{len(qa['broken'])} 张图片未加载 → {qa['broken'][:5]}")
    if qa["overflow"]:
        print(f"      警告：{len(qa['overflow'])} 个元素横向溢出 → {qa['overflow'][:5]}")
    if not qa["broken"] and not qa["overflow"]:
        print(f"      体检：{qa['imgs']} 张图片全部加载，无元素溢出")


def render_pdf(html_file: pathlib.Path, out: pathlib.Path) -> None:
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="msedge", headless=True)
        page = browser.new_page()
        page.goto(html_file.as_uri(), wait_until="load")
        page.wait_for_timeout(2500)          # 等 55 张大图解码完成
        page.emulate_media(media="print")
        check_layout(page)
        page.pdf(
            path=str(out),
            format="A4",
            print_background=True,
            display_header_footer=True,
            header_template="<div></div>",
            footer_template=FOOTER,
            margin={"top": "14mm", "bottom": "16mm", "left": "13mm", "right": "13mm"},
        )
        browser.close()


def pdf_page_count(path: pathlib.Path) -> int:
    data = path.read_bytes()
    counts = [int(c) for c in re.findall(rb"/Count (\d+)", data)]
    return max(counts) if counts else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep-html", action="store_true", help="保留中间 HTML（默认保留）")
    args = ap.parse_args()

    if not MD_PATH.exists():
        print(f"找不到手册：{MD_PATH}", file=sys.stderr)
        return 1

    md = strip_handwritten_toc(MD_PATH.read_text(encoding="utf-8"))
    doc = run_pandoc(md)
    doc, mapping, missing = retag_headings(doc)
    HTML_PATH.write_text(build_html(doc), encoding="utf-8")

    print(f"[1/2] HTML 已生成：{HTML_PATH.relative_to(ROOT)}"
          f"（重排锚点 {len(mapping)} 个）")
    if missing:
        print(f"      注意：{len(missing)} 个交叉引用未命中 → {missing[:8]}")

    render_pdf(HTML_PATH, PDF_PATH)
    TMP_MD.unlink(missing_ok=True)

    size = PDF_PATH.stat().st_size / 1024 / 1024
    pages = pdf_page_count(PDF_PATH)
    print(f"[2/2] PDF 已生成：{PDF_PATH.relative_to(ROOT)}"
          f"（{pages} 页，{size:.1f} MB）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

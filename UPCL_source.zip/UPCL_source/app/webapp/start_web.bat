@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0"
title LASE Web 平台 - 启动器

echo ============================================
echo   LASE Web 平台（FastAPI + 原生前端）
echo   目录：%~dp0
echo ============================================
echo.

rem ---------- 1/4 定位可用的 Python ----------
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
    echo [错误] 未检测到 Python。
    echo        请到 https://www.python.org/downloads/ 安装 Python 3.10 或更高版本，
    echo        安装时务必勾选 "Add python.exe to PATH"，然后重新双击本脚本。
    echo.
    pause
    exit /b 1
)
%PY% -c "import sys" >nul 2>nul
if errorlevel 1 (
    echo [错误] 找到了 Python 命令 "%PY%"，但无法执行。
    echo        若你装的是 Microsoft Store 版 Python，请改装 python.org 版本。
    echo.
    pause
    exit /b 1
)
for /f "delims=" %%v in ('%PY% -c "import sys;print(sys.version.split()[0])"') do set "PYVER=%%v"
echo [1/4] Python 就绪：%PY%  (版本 !PYVER!)

rem ---------- 2/4 检查并安装依赖 ----------
rem 先装「启动必需」三件套：缺任一服务都起不来，装失败直接中止并提示。
echo [2/4] 检查启动必需依赖 (fastapi / uvicorn / numpy) ...
%PY% -c "import fastapi, uvicorn, numpy" >nul 2>nul
if errorlevel 1 (
    echo       缺少必需依赖，正在安装（首次运行需要几分钟）...
    %PY% -m pip install "fastapi>=0.110" "uvicorn[standard]>=0.27" "numpy>=1.24"
    if errorlevel 1 (
        echo.
        echo [错误] 必需依赖安装失败。请检查网络后手动执行：
        echo        %PY% -m pip install fastapi "uvicorn[standard]" numpy
        echo        国内网络可换源：-i https://pypi.tuna.tsinghua.edu.cn/simple
        echo.
        pause
        exit /b 1
    )
)
%PY% -c "import fastapi, uvicorn, numpy" >nul 2>nul
if errorlevel 1 (
    echo [错误] 必需依赖仍不完整（fastapi / uvicorn / numpy 至少缺一个），无法启动。
    echo        请手动执行：%PY% -m pip install fastapi "uvicorn[standard]" numpy
    echo.
    pause
    exit /b 1
)
echo       必需依赖完整。

rem 再补「功能依赖」：scipy / matplotlib / python-multipart / numba。
rem 装失败不阻塞启动（例如 Python 3.13 上 numba 暂无 wheel）。
%PY% -c "import scipy, matplotlib, multipart" >nul 2>nul
if errorlevel 1 (
    echo       正在补充功能依赖（scipy / matplotlib / python-multipart / numba）...
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 echo       [提示] 功能依赖未装全，个别页面（统计检验 / 出图 / 上传）可能不可用，不影响启动。
)

rem ---------- 3/4 环境与端口检查 ----------
echo [3/4] 检查端口 8000 ...
netstat -ano | findstr ":8000" | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 echo       提示：端口 8000 已被占用，可能已有服务在运行。
if not exist "results\cec" echo       提示：未发现 results\cec 数据目录，页面将显示空数据（可把原项目的 results 拷过来）。

rem ---------- 4/4 启动服务并等待就绪 ----------
echo [4/4] 正在启动服务 http://127.0.0.1:8000 ...
start "LASE-Web-Server" cmd /k "%PY% -m uvicorn web.server:app --host 127.0.0.1 --port 8000"

echo       等待服务就绪（最多 60 秒）...
powershell -NoProfile -Command "$ok=$false; for($i=0;$i -lt 120;$i++){ try{ $c=New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1',8000); $c.Close(); $ok=$true; break } catch { Start-Sleep -Milliseconds 500 } }; if($ok){ exit 0 } else { exit 1 }"
if errorlevel 1 (
    echo.
    echo [警告] 60 秒内无法连接 http://127.0.0.1:8000
    echo        请查看 "LASE-Web-Server" 窗口中的报错信息（通常是缺依赖或端口被占用）。
    echo.
    pause
    exit /b 1
)

start "" http://127.0.0.1:8000
echo.
echo 服务已启动，浏览器即将自动打开。
echo 停止服务：关闭 "LASE-Web-Server" 窗口即可。
echo.
pause

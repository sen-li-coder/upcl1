# LASE Web 平台

UPCL 差分进化（DE）通用机制研究的 **Web 前后端分离版**。用 FastAPI 后端直接运行
Python 源码（不再打包 exe），前端用纯 HTML + ECharts 渲染，浏览器加载轻量静态资源。

## 技术栈

- 后端：FastAPI + uvicorn（异步、原生 WebSocket、自动接口文档 `/docs`）
- 前端：纯 HTML + ECharts 5（本地化 `web/static/vendor/echarts.min.js`，无 Node 构建）
- 计算：复用 `src/` 下的 DE 宿主 / UPCL 层 / CEC 套件 / UAV 仿真，算法零改动

## 界面速览

15 个页面都是真实数据的视图，不是静态原型。下面四张是主界面、算法对比、机制分析与 UAV 仿真，
每个页面的功能说明与全部 11 张截图见主仓库 README 的「5. Web 平台界面」一节。

| 主界面（KPI + 完成度矩阵） | 算法对比（五面板） |
|---|---|
| ![主界面](../../docs/screenshots/01_dashboard.jpg) | ![算法对比](../../docs/screenshots/03_compare.jpg) |
| **机制分析（效应量 / 干预率）** | **UAV 仿真（F1–F4 代表轨迹）** |
| ![机制分析](../../docs/screenshots/04_mechanism.jpg) | ![UAV 仿真](../../docs/screenshots/05_uav.jpg) |

## 目录结构

```
webapp/
├── README.md
├── requirements.txt          依赖清单
├── start_web.bat             一键启动（检查依赖 → 起服务 → 开浏览器）
├── web/                      ★ Web 后端 + 前端
│   ├── server.py             FastAPI 入口（REST + WebSocket）
│   ├── constants.py          常量 / 路径 / 宿主与套件元数据
│   ├── task_manager.py       实验子进程编排（提交/暂停/续跑/强杀/进度）
│   ├── results_api.py        收敛曲线 / 机制分析 / 秩和检验 / 地形图 / 存档 / 导出
│   ├── uav_api.py            UAV 拦截 / 蜂群仿真结果输出
│   ├── afsim_api.py          AFSIM 2.9 高保真复核（引擎自检 / 想定重跑 / 想定说明 / 产物下载）
│   └── static/               index.html + css/js + vendor/echarts.min.js
├── src/                      ★ 计算核心（14 个模块）
│   ├── de_hosts.py / de_hosts_cec.py / de_hosts_wave4.py   29 个 DE 宿主
│   ├── upcl_framework.py / upcl_experiment.py              UPCL 层
│   ├── cec_suites.py / benchmarks.py                       CEC 2017/2022 套件
│   ├── run_upcl_cec.py / analyze_upcl_cec.py               实验驱动 / 机制分析
│   ├── landscape_probe.py                                  二维地形图采样
│   ├── afsim_bridge.py                                     LASE 解 → WSF 想定 → mission.exe
│   └── opponents.py / uav_adversarial.py / uav_swarm.py    UAV 仿真
├── scripts/                  webapp 工具脚本（手册截图 / 手册 PDF / 数据同步）
└── results/                  实验数据落盘（运行后生成）
    └── cec/raw/{suite}/D{dim}/{host}__F{fid}.json
```

## 环境安装

前置要求：**Python 3.10 或更高版本**（安装时勾选 *Add python.exe to PATH*）。

```powershell
cd app\webapp
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

若不建虚拟环境，也可先跳过本节——`start_web.bat` 首次运行会自动检测并安装依赖。

## 运行

```powershell
# 方式一：一键启动（Windows，推荐）
start_web.bat

# 方式二：手动启动
python -m uvicorn web.server:app --host 127.0.0.1 --port 8000
```

`start_web.bat` 的执行顺序：定位 Python → 检查/安装依赖 → 检查端口 → 启动服务 →
**轮询等待端口就绪后才打开浏览器**（最多 60 秒），因此不会出现「页面比服务先到、显示无法访问」。

浏览器访问 <http://127.0.0.1:8000>，接口文档见 <http://127.0.0.1:8000/docs>。

## 功能页面

| 页面 | 说明 |
|---|---|
| 实验运行 | 选算法 / 测试集 / 维度 / runs / workers，后台子进程执行，WebSocket 实时推日志与进度，支持暂停 / 续跑 / 强杀 |
| 收敛曲线 | bare vs. +UPCL 同 seed 配对收敛曲线，log10 误差，中位数 / 均值聚合 |
| 机制分析 | 效应量 dec、干预率、描述子效应、ρ-dec 散点、干预率演化、秩和显著性 |
| 二维地形图 | 函数二维地形热力图 + 种群演化帧滑块 + 收敛曲线 |
| UAV 仿真 | 拦截 / 蜂群场景 Canvas 战场动画 + 收敛曲线 + 统计卡片 |
| AFSIM 复核 | **在线训练**（选 29 个 DE 变体之一 × F1–F4 × 预算 400/2000/6000 × 种子，真跑优化 + 进度条 + 实时收敛曲线 + 每 1/6 预算的 mission.exe 检查点）；训练结束写 `train_result.json`（最优解 / 曲线 / 检查点），「已保存的训练」可**载入回放**或**在 Warlock 中演示**（生成 `warlock.txt` 并拉起本机 `warlock.exe`）；把 UAV 存档解送进真实 AFSIM 2.9 重跑：引擎徽章、想定说明与优化问题（决策向量 / 目标函数 15 项）、战场俯视图（可回放 / 导出 MP4）、三列对比、事件流、产物下载；Warlock 录屏仅作样例 |
| 数据存档 | 实验数据总览、cell 状态表、CSV 浏览、图片缩略 |

## 数据说明

**分发时要连同数据一起拷贝**：整个 `app/webapp/` 目录（含 `results/`）复制过去即可。
若只拷源码、`results/` 为空，服务仍能正常启动（页面显示空数据），可在「实验运行」页重新生成。

```powershell
# 数据落在别处时，从原项目拷回来（可选）
robocopy ..\..\results\cec results\cec /E
```

数据文件格式：`results/cec/raw/{suite}/D{dim}/{host}__F{fid}.json`，每个 cell 一个 JSON，
含 bare 字段（`err_curve` / `err_final` / `wall_time_s`）与 upcl/full 字段
（同 seed 配对，含干预率 / ρ / dec 等机制字段）。

## 工具脚本（`scripts/`）

三个脚本都在**项目根** `E:\LASE` 下执行（脚本以 `parents[3]` 解析项目根）：

| 脚本 | 用途 |
|---|---|
| `app/webapp/scripts/capture_manual_shots.py` | playwright 驱动本机 Edge 采集使用手册截图 → `docs/manual/shots/` |
| `app/webapp/scripts/build_manual_pdf.py` | pandoc → HTML → Edge 打印，导出 `docs/manual/使用手册.pdf` |
| `app/webapp/scripts/sync_webapp_data.py` | 仓库 `results/apps` → `app/webapp/results/apps`（UAV 页数据源）；按 cwd 解析，须 `cd` 项目根执行 |

## 说明

- 平台仅限 Windows 主要开发环境；多进程实验用 `spawn` 启动。
- `numba` 为可选加速依赖，未安装时 UPCL 层自动回退纯 numpy 实现。
- cec2022 无官方数据文件时用 deterministic shifts/rotations（bare 与 upcl 同一套，配对比较不受影响）。

## 换电脑 / 发给别人后打不开？

按下面顺序排查（前两条 `start_web.bat` 已内置检测并给出中文提示）：

1. **没装 Python，或没加入 PATH**：脚本会提示到 python.org 安装并勾选 *Add python.exe to PATH*；
   若装的是 Microsoft Store 版 Python，运行命令会失败，请改装 python.org 版本。
2. **依赖缺失**：启动服务的最低依赖是 `fastapi`、`uvicorn`、`numpy`
   （`scipy` / `matplotlib` / `python-multipart` / `numba` 只在对应功能用到处才需要）。
   脚本检测到缺失会自动安装 `requirements.txt`；安装失败会给出手动命令与国内源提示。
3. **端口 8000 被占用**：关掉占用端口的程序，或把 `start_web.bat` 里的 `--port` 与
   `http://127.0.0.1:8000` 两处端口号改成一致的其它端口。
4. **看错误窗口**：服务跑在独立的 `LASE-Web-Server` 窗口里，真正的原因（traceback）
   在那个窗口，不在浏览器上。脚本在 60 秒连不上时会明确提示去看它。

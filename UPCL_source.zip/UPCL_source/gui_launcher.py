# -*- coding: utf-8 -*-
"""UPCL 实验启动器（Tkinter GUI，零额外依赖）。

勾选算法/测试集/参数后启动；「暂停」为优雅停止（写 .stop 标记，等在跑 cell 落盘），
暂停后可用「继续执行」续跑剩余进度；「强制终止」立即结束进程树。
复用 run_upcl_cec.py 的 --resume 断点续跑。
"""
import csv
import json
import math
import multiprocessing
import os
import queue
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from statistics import mean, median, stdev

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog

# PyInstaller 打包成 exe 后，__file__ 指向临时解压目录，需改用 exe 所在目录
# 作为项目根（保证 src/、results/ 等相对路径仍正确）。
if getattr(sys, 'frozen', False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = Path(__file__).resolve().parent
RUN_SCRIPT = ROOT / 'src' / 'run_upcl_cec.py'
RAW = ROOT / 'results' / 'cec' / 'raw'
STOP_FILE = ROOT / 'results' / 'cec' / '.stop'
PAUSE_FILE = ROOT / 'results' / 'cec' / '.pause'


def _experiment_cli():
    """frozen exe 的隐藏 CLI 入口：带 --run-experiment 时执行实验脚本。

    windowed 模式无控制台，sys.stdout/stderr 为 None，print 会崩溃；这里把
    输出重定向到日志文件（路径由 GUI 通过 --gui-log 注入），保证进度可落盘、
    GUI 能 tail 读取。运行依赖（numpy/scipy）已随 exe 一并打包，无需系统 Python。
    """
    argv = sys.argv[1:]
    log_path = None
    if '--gui-log' in argv:
        i = argv.index('--gui-log')
        log_path = argv[i + 1]
        del argv[i:i + 2]
    if '--run-experiment' in argv:
        idx = argv.index('--run-experiment')
        argv = argv[idx + 1:]
    if sys.stdout is None:
        target = Path(log_path) if log_path else (
            ROOT / 'results' / 'cec' / 'exe_run.log')
        target.parent.mkdir(parents=True, exist_ok=True)
        sys.stdout = open(target, 'a', encoding='utf-8', buffering=1)
        sys.stderr = sys.stdout
    try:
        import run_upcl_cec
        run_upcl_cec.main(argv)
    except SystemExit:
        raise                       # argparse 正常退出 / --help
    except Exception as exc:
        import traceback
        print(f'[fatal] {type(exc).__name__}: {exc}', file=sys.stderr, flush=True)
        traceback.print_exc(file=sys.stderr)
        sys.exit(2)                 # 非零退出码，GUI 据此弹窗提示


# 算法清单单一数据源：宿主顺序由 src/de_hosts_cec.py 的 CEC_HOST_ORDER 定义，
# GUI 只读取它，避免新增/改名算法时在 GUI、注册表、文档多处同步。下面这 30 个
# 仅作为 import 失败（如源码未随 exe 打包）时的回退，顺序必须与 CEC_HOST_ORDER 一致。
_HOSTS_FALLBACK = [
    # 经典固定参数
    'DE/rand/1', 'DE/best/1', 'DE/rand/2', 'DE/current-to-best/1',
    'DE/current-to-rand/1', 'DE/rand/1/either-or',
    # 自适应参数
    'jDE', 'SaNSDE',
    # 自适应策略 / 参数集成
    'JADE', 'SHADE', 'CoBiDE', 'SaDE', 'EPSDE', 'CoDE', 'MPEDE',
    # 线性种群缩减 / rank-based
    'L-SHADE', 'jSO', 'L-SHADE-RSP', 'NL-SHADE-RSP', 'MadDE',
    # wave4 纯 DE 变体
    'jDE100', 'j2020', 'DISH', 'DISK', 'LSHADE-cnEpSin', 'SinDE',
    'IMODE', 'PaDE', 'LSHADE-HS', 'SHADE-ILS',
]


def _load_host_order():
    """从 de_hosts_cec 读取宿主顺序（单一数据源），失败则回退到内置列表。"""
    try:
        import de_hosts_cec
        order = list(de_hosts_cec.CEC_HOST_ORDER)
        if order:
            return order
    except Exception:
        pass
    try:
        _src = ROOT / 'src'
        if _src.is_dir():
            sys.path.insert(0, str(_src))
            import de_hosts_cec
            order = list(de_hosts_cec.CEC_HOST_ORDER)
            if order:
                return order
    except Exception:
        pass
    return list(_HOSTS_FALLBACK)


HOSTS = _load_host_order()
SUITES = ['cec2017', 'cec2022', 'cec2013', 'cec2014', 'cec2015']
SUITE_LABELS = {'cec2017': 'CEC2017', 'cec2022': 'CEC2022',
                'cec2013': 'CEC2013', 'cec2014': 'CEC2014',
                'cec2015': 'CEC2015'}
SUITE_LEGAL_DIMS = {'cec2017': (30, 50), 'cec2022': (10, 20),
                    'cec2013': (10, 30, 50, 100),
                    'cec2014': (10, 20, 30, 50, 100),
                    'cec2015': (10, 30)}
SUITE_NFUNCS = {'cec2017': 29, 'cec2022': 12, 'cec2013': 28,
                'cec2014': 30, 'cec2015': 15}
SUITE_KEY = {label: key for key, label in SUITE_LABELS.items()}

# ---- 数据存档：宿主分组（决定每个 cell 的「正确臂类型」）与各 suite 的函数编号
# 前 20 个为旧宿主（期望 bare+upcl），后 10 个为 wave4 变体（期望 bare+full）。
LEGACY_HOSTS = HOSTS[:20]
WAVE4_HOSTS = set(HOSTS[20:])
# 有历史落盘数据的测试集（数据存档仅覆盖这些）。
ARCHIVE_SUITES = ['cec2022', 'cec2017', 'cec2013']
# 每个 suite 的合法 fid 列表（cec2017 跳过 F2，见 EXPERIMENT_PROGRESS.md）。
SUITE_FIDS = {
    'cec2022': list(range(1, 13)),
    'cec2017': [1] + list(range(3, 31)),
    'cec2013': list(range(1, 29)),
}
TABLES_DIR = ROOT / 'results' / 'cec' / 'tables'
FIGURES_DIR = ROOT / 'results' / 'cec' / 'figures'

LOG_DIR = ROOT / 'results' / 'cec' / 'logs'
STATUS_DIR = LOG_DIR / '.workers'   # worker 实时状态（由 run_upcl_cec 写入）
GRACE_SECONDS = 30 * 60

# ---- 绘图臂语义：bare = 基线；upcl/full 统一为「增加 UPCL」。
# （数据里旧宿主落盘名为 'upcl'、wave4 变体为 'full'，绘图时合并为同一语义）
ARM_DISPLAY = {'bare': '基线', 'upcl': '增加 UPCL'}

# ---- 机制分析的三个指标说明（写论文用）----
# 指标1 dec：效应量（数量级增益），UPCL 相对裸 DE 的误差对数差。
# 指标2 rho：干预率（机制指纹），UPCL 层实际修改 proposal 的比例。
# 指标3 descriptor effect：5 个描述子的标准化效应（机制诊断）。
# 描述子定义见 upcl_framework.py 的 _describe：z0~z4 依次为步长比/方向对齐/
# 精英距离/拥挤度/新颖度（论文符号 rho/theta/eta/kappa/nu）。
DESC_NAMES = [
    ('ρ 步长比', '相对步长（对数尺度，种群相对）'),
    ('θ 方向对齐', '与已学成功方向的对齐'),
    ('η 精英距离', '与当前精英方向的对齐'),
    ('κ 拥挤度', '落点与参考点的最近距离'),
    ('ν 新颖度', '方向相对原型集的新颖度'),
]

# 干预率演化曲线的归一化进度点数（rho_curve 长度=代数数，重采样到固定网格后跨 run 取中位数）。
RHO_CURVE_PTS = 50


def _resample_curve(vals, n=RHO_CURVE_PTS):
    """把任意长度曲线线性重采样到 n 个归一化进度点 [0, 1]。"""
    m = len(vals)
    if m == 0:
        return []
    if m == 1:
        return [float(vals[0])] * n
    out = []
    for j in range(n):
        t = j / (n - 1)
        idx = t * (m - 1)
        i = min(int(idx), m - 2)
        f = idx - i
        out.append(float(vals[i]) * (1 - f) + float(vals[i + 1]) * f)
    return out


def _enable_dpi_awareness():
    """Windows 高分屏：启用 DPI 感知，避免界面模糊且尺寸计算错误导致窗口超屏。

    Per-Monitor V2 失败则降级 System DPI 感知，均失败保持默认。必须在创建
    Tk 根窗口之前调用。
    """
    if sys.platform != 'win32':
        return
    try:
        import ctypes
    except Exception:
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def _setup_theme(root):
    """现代主题与全局样式（clam + 蓝灰配色），统一控件外观、提升渲染观感。"""
    import tkinter.font as tkfont
    style = ttk.Style(root)
    try:
        style.theme_use('clam')
    except tk.TclError:
        pass

    families = set(tkfont.families(root))
    if 'Microsoft YaHei UI' in families:
        ui_font = 'Microsoft YaHei UI'
    elif 'Segoe UI' in families:
        ui_font = 'Segoe UI'
    else:
        ui_font = 'TkDefaultFont'

    ACCENT = '#2f6fed'
    ACCENT_DK = '#1e56c8'
    BG = '#f5f7fa'
    FG = '#1f2733'
    MUTE = '#66727f'
    HEAD_BG = '#eef2f7'
    BORDER = '#d8dee6'

    style.configure('.', background=BG, foreground=FG,
                    font=(ui_font, 9))
    style.configure('TFrame', background=BG)
    style.configure('TLabel', background=BG, foreground=FG)
    style.configure('Mute.TLabel', background=BG, foreground=MUTE)
    style.configure('Accent.TLabel', background=BG, foreground=ACCENT)
    style.configure('TLabelframe', background=BG, bordercolor=BORDER,
                    borderwidth=1, relief='solid')
    style.configure('TLabelframe.Label', background=BG, foreground='#33404d',
                    font=(ui_font, 9, 'bold'))
    style.configure('TButton', background=ACCENT, foreground='#ffffff',
                    padding=(12, 6), borderwidth=0, focusthickness=0,
                    font=(ui_font, 9))
    style.map('TButton',
              background=[('active', ACCENT_DK), ('pressed', ACCENT_DK),
                          ('disabled', '#b9c4d0')],
              foreground=[('disabled', '#ffffff')])
    style.configure('Danger.TButton', background='#d64545',
                    foreground='#ffffff', padding=(12, 6), borderwidth=0,
                    focusthickness=0, font=(ui_font, 9))
    style.map('Danger.TButton',
              background=[('active', '#b83232'), ('pressed', '#b83232'),
                          ('disabled', '#b9c4d0')],
              foreground=[('disabled', '#ffffff')])
    style.configure('TNotebook', background=BG, borderwidth=0,
                    tabmargins=(4, 4, 4, 0))
    style.configure('TNotebook.Tab', padding=(14, 7), background='#e4e9f0',
                    foreground='#44505c', font=(ui_font, 9))
    style.map('TNotebook.Tab',
              background=[('selected', '#ffffff')],
              foreground=[('selected', ACCENT)])
    style.configure('Treeview', background='#ffffff', fieldbackground='#ffffff',
                    foreground=FG, rowheight=26, borderwidth=0)
    style.configure('Treeview.Heading', background=HEAD_BG,
                    foreground='#33404d', font=(ui_font, 9, 'bold'),
                    padding=(6, 4), relief='flat')
    style.map('Treeview', background=[('selected', ACCENT)],
              foreground=[('selected', '#ffffff')])
    style.map('Treeview.Heading', background=[('active', '#dfe7f2')])
    style.configure('TCombobox', background='#ffffff',
                    fieldbackground='#ffffff', foreground=FG, arrowcolor=ACCENT)
    style.map('TCombobox',
              fieldbackground=[('readonly', '#ffffff')],
              selectbackground=[('readonly', '#ffffff')],
              selectforeground=[('readonly', FG)])
    style.configure('TCheckbutton', background=BG)
    style.configure('TProgressbar', background=ACCENT, troughcolor='#e4e9f0',
                    bordercolor='#e4e9f0', lightcolor=ACCENT, darkcolor=ACCENT)


def _fit_window(win, w, h, pad_x=48, pad_y=84):
    """自适应屏幕：窗口尺寸不超过显示器可用区域并居中，避免高度超出屏幕。

    pad_y 预留标题栏 + 任务栏余量。返回实际应用的 (w, h)。
    """
    try:
        win.update_idletasks()
    except tk.TclError:
        pass
    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()
    w = max(320, min(int(w), sw - pad_x))
    h = max(240, min(int(h), sh - pad_y))
    x = (sw - w) // 2
    y = max(0, (sh - h) // 2)
    win.geometry(f'{w}x{h}+{x}+{y}')
    return w, h


def _check(parent, text, variable, **kw):
    """系统原生勾选框：ttk 的 clam 主题在部分环境把选中态渲染成“×”，
    改用 tk.Checkbutton（Windows 原生 √ 选框），并通过配色融入浅灰主题。"""
    opts = dict(bg='#f5f7fa', fg='#1f2733', activebackground='#f5f7fa',
                activeforeground='#1f2733', selectcolor='#ffffff',
                highlightthickness=0, bd=0, relief='flat',
                font=('TkDefaultFont', 9), cursor='hand2')
    opts.update(kw)
    return tk.Checkbutton(parent, text=text, variable=variable, **opts)


def _jet(t):
    """jet 风格颜色映射：t∈[0,1] -> '#rrggbb'（蓝→青→绿→黄→红）。"""
    t = max(0.0, min(1.0, t))
    if t < 0.25:
        r, g, b = 0.0, 4.0 * t, 1.0
    elif t < 0.5:
        r, g, b = 0.0, 1.0, 1.0 - 4.0 * (t - 0.25)
    elif t < 0.75:
        r, g, b = 4.0 * (t - 0.5), 1.0, 0.0
    else:
        r, g, b = 1.0, 1.0 - 4.0 * (t - 0.75), 0.0
    return f'#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}'


def _contour_segments(Z, level, lb, ub):
    """marching squares 提取 Z==level 的等值线段（返回实际坐标）。

    Z 形状 (ny, nx)，Z[i, j] 位于坐标 (x=j, y=i)，x/y 均 linspace(lb, ub)。
    返回 [(x1, y1, x2, y2), ...]，坐标为实际搜索空间值，用于画等高线“圈圈”。
    """
    ny, nx = Z.shape
    segs = []

    def xof(j):
        return lb + j / (nx - 1) * (ub - lb)

    def yof(i):
        return lb + i / (ny - 1) * (ub - lb)

    for i in range(ny - 1):
        for j in range(nx - 1):
            v00 = Z[i, j]
            v10 = Z[i, j + 1]
            v11 = Z[i + 1, j + 1]
            v01 = Z[i + 1, j]
            case = ((1 if v00 >= level else 0)
                    | (2 if v10 >= level else 0)
                    | (4 if v11 >= level else 0)
                    | (8 if v01 >= level else 0))
            if case == 0 or case == 15:
                continue

            def ip(va, vb, a, b):
                if abs(vb - va) < 1e-12:
                    return a
                return a + (level - va) / (vb - va) * (b - a)

            edges = {
                0: (xof(ip(v00, v10, j, j + 1)), yof(i)),          # 底
                1: (xof(j + 1), yof(ip(v10, v11, i, i + 1))),       # 右
                2: (xof(ip(v01, v11, j, j + 1)), yof(i + 1)),       # 顶
                3: (xof(j), yof(ip(v00, v01, i, i + 1))),           # 左
            }
            pairs = {
                1: [0, 3], 2: [0, 1], 3: [1, 3], 4: [1, 2],
                5: [0, 3, 1, 2], 6: [0, 2], 7: [2, 3], 8: [2, 3],
                9: [0, 2], 10: [0, 1, 2, 3], 11: [1, 2], 12: [1, 3],
                13: [0, 1], 14: [0, 3],
            }[case]
            for k in range(0, len(pairs), 2):
                a = edges[pairs[k]]
                b = edges[pairs[k + 1]]
                segs.append((a[0], a[1], b[0], b[1]))
    return segs


class LauncherApp:
    def __init__(self, root):
        self.root = root
        root.title('UPCL 实验启动器')
        # 自适应屏幕：窗口不超过显示器可用区域，避免高度超出屏幕。
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        w = min(860, sw - 80)
        h = min(700, sh - 100)
        root.geometry(f'{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}')

        self.running = False
        self.stop_flag = False
        self.stop_time = 0.0
        self.paused = False          # 优雅停止后进入暂停状态，可继续
        self.current_cmd = None      # 当前命令 (desc, cmd, log_path)，暂停时保留
        self.proc = None
        self.q = queue.Queue()
        self.cmd_queue = []
        self.current_desc = ''
        self.total_cells = 0

        self.host_vars = [tk.BooleanVar(value=True) for _ in HOSTS]
        self.suite_var = tk.StringVar(value=SUITE_LABELS['cec2022'])
        self.dims_var = tk.StringVar(value='10')
        self.cpu_cores = os.cpu_count() or 4
        self.max_workers = max(1, self.cpu_cores - 1)
        self.runs_var = tk.IntVar(value=30)
        self.workers_var = tk.StringVar(value='1')  # CPU 核数，默认 1
        self.mult_var = tk.IntVar(value=10_000)
        self.upcl_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value='就绪')
        self.progress_var = tk.DoubleVar(value=0)
        self.eta_var = tk.StringVar(value='—')
        self._run_cost_cache = {}
        self._eta_job = None
        self._calib_in_progress = set()   # 后台耗时校准去重（(suite, dim)）

        self._build_ui()
        self._refresh_dim_combo()
        self._refresh_suite_hint()
        self._bind_eta_traces()
        self._refresh_eta()
        self.root.after(500, self._poll_workers)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        pad = {'padx': 8, 'pady': 4}

        # 可滚动容器：内容高度可能超出屏幕，用 Canvas + 垂直滚动条包裹，
        # 窗口自适应屏幕尺寸，缩小时可滚动查看全部内容。
        outer = ttk.Frame(self.root)
        outer.pack(fill='both', expand=True)
        self.canvas = tk.Canvas(outer, highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(outer, orient='vertical', command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self.canvas.pack(side='left', fill='both', expand=True)
        self.body = ttk.Frame(self.canvas)
        self._body_win = self.canvas.create_window(
            (0, 0), window=self.body, anchor='nw')
        self.body.bind(
            '<Configure>',
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind(
            '<Configure>',
            lambda e: self.canvas.itemconfigure(self._body_win, width=e.width))
        self._bind_mousewheel()

        # 算法选择
        fh = ttk.Labelframe(self.body, text=f'算法（可多选，共 {len(HOSTS)} 个）', padding=8)
        fh.pack(fill='x', **pad)
        ncols = 5
        for i, (h, v) in enumerate(zip(HOSTS, self.host_vars)):
            _check(fh, text=h, variable=v).grid(
                row=i // ncols, column=i % ncols, sticky='w', padx=6, pady=2)
        bar = ttk.Frame(fh)
        bar.grid(row=(len(HOSTS) - 1) // ncols + 1, column=0,
                 columnspan=ncols, sticky='w', pady=(4, 0))
        ttk.Button(bar, text='全选', width=8,
                   command=lambda: self._set_hosts(True)).pack(side='left', padx=4)
        ttk.Button(bar, text='清空', width=8,
                   command=lambda: self._set_hosts(False)).pack(side='left', padx=4)

        # 测试集 / 维度 / 参数 并排（三个 Labelframe 一行）
        mid = ttk.Frame(self.body)
        mid.pack(fill='x', **pad)

        # 测试集（单选下拉）
        fs = ttk.Labelframe(mid, text='测试集（单选）', padding=8)
        fs.pack(side='left', fill='x', padx=(0, 6))
        self.suite_combo = ttk.Combobox(
            fs, textvariable=self.suite_var, state='readonly', width=11,
            values=[SUITE_LABELS[s] for s in SUITES])
        self.suite_combo.pack(anchor='w')
        self.suite_combo.bind('<<ComboboxSelected>>', self._on_suite_change)
        self.suite_hint = ttk.Label(fs, justify='left', foreground='#555')
        self.suite_hint.pack(anchor='w', pady=(6, 0))

        # 维度（单选下拉，随测试集联动）
        fd = ttk.Labelframe(mid, text='问题维度 D（单选）', padding=8)
        fd.pack(side='left', fill='x', padx=(6, 6))
        self.dim_combo = ttk.Combobox(
            fd, textvariable=self.dims_var, state='readonly', width=6)
        self.dim_combo.pack(anchor='w')
        dim_tip = ttk.Label(fd, foreground='#555',
                            text='决策变量个数\n（非种群数）')
        dim_tip.pack(anchor='w', pady=(6, 0))

        # 运行参数
        fp = ttk.Labelframe(mid, text='运行参数', padding=8)
        fp.pack(side='left', fill='both', expand=True, padx=(6, 0))
        params = [('重复次数', self.runs_var),
                  ('CPU 核数', self.workers_var),
                  ('评估预算(×D)', self.mult_var)]
        for i, (name, var) in enumerate(params):
            ttk.Label(fp, text=name).grid(row=i, column=0, sticky='e', pady=2)
            if name == 'CPU 核数':
                self.worker_combo = ttk.Combobox(
                    fp, textvariable=var, state='readonly', width=9,
                    values=[str(n) for n in range(1, self.max_workers + 1)])
                self.worker_combo.grid(row=i, column=1, sticky='w', padx=6, pady=2)
            else:
                ttk.Entry(fp, textvariable=var, width=12).grid(
                    row=i, column=1, sticky='w', padx=6, pady=2)

        # 运行选项 + 参数说明
        opt = ttk.Labelframe(self.body, text='运行选项', padding=8)
        opt.pack(fill='x', **pad)
        _check(
            opt, variable=self.upcl_var,
            text='启用 UPCL 机制（不勾选则只跑原始算法，时间约省一半）'
        ).pack(anchor='w')
        ttk.Label(opt, justify='left', foreground='#555', text=(
            '参数说明：\n'
            '· 测试集 / 维度：均为下拉单选，一次只运行一个测试集的一个维度\n'
            '· 重复次数：每个「算法 × 函数 × 维度」独立重复运行的次数，'
            '越大统计越稳（论文用 30）\n'
            f'· CPU 核数：同时使用的 CPU 核数（即并行进程数）。本机检测到 {self.cpu_cores} 核，'
            f'可选 1~{self.max_workers}（留 1 核给系统），默认 1 最稳妥\n'
            '· 评估预算(×D)：每次运行的最大评估次数 = 该值 × 维度 D'
            '（如 10000 × 10 = 10 万次）'
        )).pack(anchor='w', pady=(4, 0))

        # 控制按钮（分两行：运行控制 + 工具按钮，避免窗口变窄时右侧按钮被挤出）
        ctrl = ttk.Frame(self.body)
        ctrl.pack(fill='x', **pad)
        run_row = ttk.Frame(ctrl)
        run_row.pack(fill='x')
        self.start_btn = ttk.Button(run_row, text='启动', command=self._start)
        self.start_btn.pack(side='left', padx=4)
        self.stop_btn = ttk.Button(run_row, text='暂停（优雅停止）', command=self._stop,
                                   state='disabled')
        self.stop_btn.pack(side='left', padx=4)
        self.resume_btn = ttk.Button(run_row, text='继续执行', command=self._resume,
                                     state='disabled')
        self.resume_btn.pack(side='left', padx=4)
        self.kill_btn = ttk.Button(run_row, text='强制终止', command=self._force_kill,
                                   state='disabled', style='Danger.TButton')
        self.kill_btn.pack(side='left', padx=4)
        ttk.Label(run_row, textvariable=self.status_var).pack(side='left', padx=12)

        tool_row = ttk.Frame(ctrl)
        tool_row.pack(fill='x', pady=(6, 0))
        ttk.Button(tool_row, text='UAV 对抗仿真', command=self._open_uav).pack(
            side='left', padx=4)
        ttk.Button(tool_row, text='数据存档', command=self._open_archive).pack(
            side='right', padx=4)
        ttk.Button(tool_row, text='收敛曲线', command=self._open_convergence).pack(
            side='right', padx=4)
        ttk.Button(tool_row, text='二维地形图', command=self._open_landscape).pack(
            side='right', padx=4)
        ttk.Button(tool_row, text='机制分析', command=self._open_mechanism).pack(
            side='right', padx=4)
        ttk.Button(tool_row, text='导出结果表格', command=self._export_results).pack(
            side='right', padx=4)

        # 预计运行时间（只读，自动计算）
        fe = ttk.Labelframe(self.body, text='预计运行时间', padding=8)
        fe.pack(fill='x', **pad)
        ttk.Label(fe, textvariable=self.eta_var, foreground='#0a7',
                  font=('TkDefaultFont', 10, 'bold')).pack(anchor='w')

        # 进度条
        self.bar = ttk.Progressbar(self.body, variable=self.progress_var,
                                   maximum=1.0)
        self.bar.pack(fill='x', **pad)

        # 运行详情（多标签页）
        fl = ttk.Labelframe(self.body, text='运行详情', padding=4)
        fl.pack(fill='both', expand=True, **pad)
        self.nb = ttk.Notebook(fl)
        self.nb.pack(fill='both', expand=True)

        # Tab1 运行日志
        t_log = ttk.Frame(self.nb)
        self.nb.add(t_log, text='运行日志')
        self.log = scrolledtext.ScrolledText(t_log, state='disabled', height=10)
        self.log.pack(fill='both', expand=True)

        # Tab2 Worker 实时状态
        t_w = ttk.Frame(self.nb)
        self.nb.add(t_w, text='Worker 状态')
        cols = ('worker', 'host', 'func', 'dim', 'arm', 'prog')
        self.worker_tree = ttk.Treeview(
            t_w, columns=cols, show='headings', height=10)
        for c, txt, wd in (('worker', 'Worker', 70), ('host', '算法', 160),
                           ('func', '函数', 120), ('dim', '维度', 50),
                           ('arm', '臂', 60), ('prog', '进度', 80)):
            self.worker_tree.heading(c, text=txt)
            self.worker_tree.column(c, width=wd, anchor='w')
        self.worker_tree.pack(side='left', fill='both', expand=True)
        ws = ttk.Scrollbar(t_w, orient='vertical',
                           command=self.worker_tree.yview)
        ws.pack(side='right', fill='y')
        self.worker_tree.configure(yscrollcommand=ws.set)
        self.worker_summary = tk.StringVar(value='等待启动…')
        ttk.Label(t_w, textvariable=self.worker_summary,
                  foreground='#555').pack(side='bottom', fill='x')

        # Tab3 实验进度
        t_p = ttk.Frame(self.nb)
        self.nb.add(t_p, text='实验进度')
        self.prog_text = scrolledtext.ScrolledText(
            t_p, state='disabled', height=10)
        self.prog_text.pack(fill='both', expand=True)

        self.root.protocol('WM_DELETE_WINDOW', self._on_close)
        self._append_log('[gui] 就绪。选择算法与测试集后点「启动」。\n')

    def _bind_mousewheel(self):
        """滚轮滚动：鼠标悬停在文本/日志框内时滚动其自身，滚到边界后交还给外层 Canvas。"""
        def _scroll(event, delta):
            w = event.widget
            if isinstance(w, tk.Text):
                top, bottom = w.yview()
                # 内层仍有滚动空间时滚动自身；否则交还给外层
                if not ((delta < 0 and top <= 0.0) or
                        (delta > 0 and bottom >= 1.0)):
                    w.yview_scroll(delta, 'units')
                    return 'break'
            if self.canvas.yview() == (0.0, 1.0):
                return
            self.canvas.yview_scroll(delta, 'units')

        self.canvas.bind_all('<MouseWheel>',
                             lambda e: _scroll(e, int(-e.delta / 120)))
        self.canvas.bind_all('<Button-4>', lambda e: _scroll(e, -1))
        self.canvas.bind_all('<Button-5>', lambda e: _scroll(e, 1))

    def _set_hosts(self, val):
        for v in self.host_vars:
            v.set(val)

    # ----------------------------------------------------------- 预计运行时间
    def _bind_eta_traces(self):
        for v in (self.runs_var, self.workers_var, self.mult_var,
                  self.dims_var, self.suite_var, self.upcl_var):
            v.trace_add('write', lambda *a: self._schedule_eta())
        for v in self.host_vars:
            v.trace_add('write', lambda *a: self._schedule_eta())

    def _schedule_eta(self):
        if self._eta_job is not None:
            try:
                self.root.after_cancel(self._eta_job)
            except Exception:
                pass
        self._eta_job = self.root.after(300, self._refresh_eta)

    def _refresh_eta(self):
        self._eta_job = None
        try:
            hosts = [h for h, v in zip(HOSTS, self.host_vars) if v.get()]
            suite = self._current_suite()
            dim = int(self.dims_var.get())
            runs = int(self.runs_var.get())
            workers = int(self.workers_var.get())
            mult = int(self.mult_var.get())
        except (tk.TclError, ValueError):
            self.eta_var.set('—（请填写有效参数）')
            return
        if not hosts or not suite or runs <= 0:
            self.eta_var.set('—')
            return
        nfuncs = SUITE_NFUNCS.get(suite, 0)
        arms = 1 if not self.upcl_var.get() else 2
        total_runs = len(hosts) * nfuncs * runs * arms
        per_run = self._avg_run_seconds(suite, dim)
        known = per_run is not None
        if not known and not self.running:
            # 首次无历史数据：后台实测一次 run 耗时，避免默认 60s 误差过大
            self._start_calibration(suite, dim, hosts[0])
        per_run = per_run if known else 60.0
        per_run *= mult / 10_000.0
        workers = max(1, min(workers, self.max_workers))
        eta_s = total_runs * per_run / workers
        base = '按历史耗时' if known else '无历史数据，按默认 60s/次'
        self.eta_var.set(
            f'{self._format_duration(eta_s)}  （{len(hosts)}算法×{nfuncs}函数'
            f'×{runs}次×{arms}臂÷{workers}进程，{base}）')

    def _avg_run_seconds(self, suite, dim):
        key = (suite, dim)
        if key in self._run_cost_cache:
            return self._run_cost_cache[key]
        vals = []
        d = RAW / suite / f'D{dim}'
        if d.is_dir():
            for p in d.glob('*.json'):
                try:
                    with open(p, 'r', encoding='utf-8') as fh:
                        data = json.load(fh)
                except Exception:
                    continue
                for run in data.get('runs', []) or []:
                    for k, v in run.items():
                        if isinstance(v, dict) and 'wall_time_s' in v:
                            vals.append(float(v['wall_time_s']))
        res = float(mean(vals)) if vals else None
        self._run_cost_cache[key] = res
        return res

    # ---- 首次无历史数据时的耗时校准 ---------------------------------------
    # 后台实测一次 run（缩减预算测单次评估耗时，再外推到标准预算 FES_MULT*D），
    # 完成后回主线程刷新 ETA。取「最便宜 unimodal + 最贵 composite/hybrid」两个
    # 代表函数、bare+full 两臂的平均，作为该 (suite, dim) 的单次 run 成本。
    _CALIB_MULT = 2000

    def _start_calibration(self, suite, dim, host):
        key = (suite, dim)
        if key in self._calib_in_progress:
            return
        self._calib_in_progress.add(key)
        threading.Thread(target=self._calibrate_run_cost,
                         args=(suite, dim, host), daemon=True).start()

    def _calibrate_run_cost(self, suite, dim, host):
        import time as _t
        result = None
        error = None
        try:
            import run_upcl_cec as R
            allf = R.CS.get_suite(suite, dim)
            by_cat = {}
            for f in allf:
                by_cat.setdefault(f.category, []).append(f.fid)
            fids = []
            if by_cat.get('unimodal'):
                fids.append(by_cat['unimodal'][0])
            for c in ('composite', 'hybrid'):
                if by_cat.get(c):
                    fids.append(by_cat[c][-1])
                    break
            if not fids:
                fids = [allf[0].fid]
            per_eval_secs = []
            for fid in fids:
                func = R.CS.get_function(suite, dim, fid)
                pop_size = R.DHC.pop_size_for(host, dim)
                for cfg in (None, 'default'):
                    _t0 = _t.perf_counter()
                    R.run_arm(host, func, dim, 1, self._CALIB_MULT * dim, cfg,
                              pop_size=pop_size)
                    dt = _t.perf_counter() - _t0
                    per_eval_secs.append(dt / (self._CALIB_MULT * dim))
            result = float(mean(per_eval_secs)) * (R.FES_MULT * dim)
        except Exception as exc:
            error = str(exc)
        self.root.after(0, self._on_calibration_done, (suite, dim), result, error)

    def _on_calibration_done(self, key, result, error):
        self._calib_in_progress.discard(key)
        if result is not None:
            self._run_cost_cache[key] = result
        elif error:
            self._append_log(f'[gui] 耗时校准失败（不影响运行）：{error}\n')
        self._refresh_eta()

    @staticmethod
    def _format_duration(sec):
        sec = max(0, int(sec))
        d, rem = divmod(sec, 86400)
        h, rem = divmod(rem, 3600)
        m, s = divmod(rem, 60)
        if d:
            return f'{d}天{h}小时{m}分'
        if h:
            return f'{h}小时{m}分'
        if m:
            return f'{m}分{s}秒'
        return f'{s}秒'

    # ----------------------------------------------------------- worker 状态
    def _poll_workers(self):
        self._refresh_worker_tab()
        self.root.after(500 if self.running else 1500, self._poll_workers)

    def _refresh_worker_tab(self):
        workers = {}
        if STATUS_DIR.is_dir():
            for p in STATUS_DIR.glob('w*.json'):
                try:
                    with open(p, 'r', encoding='utf-8') as fh:
                        d = json.load(fh)
                except Exception:
                    continue
                workers[str(d.get('pid', p.stem.lstrip('w')))] = d
        existing = set(self.worker_tree.get_children())
        seen = set()
        for pid, d in sorted(workers.items()):
            seen.add(pid)
            prog = '完成' if d.get('status') == 'done' else \
                f"{d.get('run', '?')}/{d.get('runs', '?')}"
            vals = (pid[-4:], d.get('host', ''),
                    f"F{d.get('fid', '')} {d.get('func', '')}",
                    d.get('dim', ''), d.get('arm', ''), prog)
            if pid in existing:
                self.worker_tree.item(pid, values=vals)
            else:
                self.worker_tree.insert('', 'end', iid=pid, values=vals)
        for old in existing - seen:
            self.worker_tree.delete(old)
        n_run = sum(1 for d in workers.values() if d.get('status') == 'running')
        self.worker_summary.set(
            f'共 {len(workers)} 个 worker 进程，{n_run} 个正在运行')

    def _refresh_progress_tab(self, finished, total, elapsed, eta):
        lines = [
            f'总进度：{finished}/{total} cells',
            f'完成率：{finished / total * 100:.1f}%' if total else '完成率：—',
            f'已用时间：{self._format_duration(elapsed)}',
            f'预计剩余：{self._format_duration(eta)}',
            '',
            '最近完成的 cell：',
        ]
        dp = STATUS_DIR / 'done.log'
        if dp.exists():
            try:
                with open(dp, 'r', encoding='utf-8') as fh:
                    tail = fh.readlines()[-20:]
            except Exception:
                tail = []
            for ln in tail:
                try:
                    d = json.loads(ln)
                    lines.append(f"  {d.get('suite', '')} D{d.get('dim', '')} "
                                 f"{d.get('host', '')} F{d.get('fid', '')} 完成")
                except Exception:
                    continue
        self.prog_text.configure(state='normal')
        self.prog_text.delete('1.0', 'end')
        self.prog_text.insert('1.0', '\n'.join(lines) + '\n')
        self.prog_text.see('end')
        self.prog_text.configure(state='disabled')

    def _current_suite(self):
        """返回当前下拉框选中的测试集 key（如 'cec2022'）。"""
        return SUITE_KEY.get(self.suite_var.get())

    def _on_suite_change(self, _event=None):
        """切换测试集时，联动刷新维度下拉的可选项与提示文本。"""
        self._refresh_dim_combo()
        self._refresh_suite_hint()

    def _refresh_dim_combo(self):
        """按当前测试集刷新维度下拉，并把已选维度校正到合法范围。"""
        suite = self._current_suite()
        if not suite:
            return
        dims = SUITE_LEGAL_DIMS[suite]
        labels = [str(d) for d in dims]
        self.dim_combo['values'] = labels
        if str(self.dims_var.get()) not in labels:
            self.dims_var.set(labels[0])

    def _refresh_suite_hint(self):
        """显示当前测试集的函数个数与支持维度。"""
        suite = self._current_suite()
        if not suite:
            self.suite_hint.config(text='')
            return
        dims = ' / '.join(map(str, SUITE_LEGAL_DIMS[suite]))
        self.suite_hint.config(
            text=f'{SUITE_NFUNCS[suite]} 个函数\n支持维度: {dims}')

    def _append_log(self, text):
        self.log.configure(state='normal')
        self.log.insert('end', text)
        self.log.see('end')
        self.log.configure(state='disabled')

    def _set_running(self, running):
        self.running = running
        self.start_btn.config(state='disabled' if running else 'normal')
        self.stop_btn.config(state='normal' if running else 'disabled')
        self.kill_btn.config(state='normal' if running else 'disabled')
        # 「继续执行」只在暂停状态下可用
        self.resume_btn.config(state='normal' if self.paused else 'disabled')

    # --------------------------------------------------------------- 命令
    def _build_commands(self):
        hosts = [h for h, v in zip(HOSTS, self.host_vars) if v.get()]
        if not hosts:
            messagebox.showwarning('提示', '请至少选择一个算法')
            return None
        suite = self._current_suite()
        if not suite:
            messagebox.showwarning('提示', '请选择一个测试集')
            return None
        try:
            dim = int(self.dims_var.get())
        except (tk.TclError, ValueError):
            messagebox.showwarning('提示', '请选择一个维度')
            return None
        if dim not in SUITE_LEGAL_DIMS[suite]:
            messagebox.showwarning(
                '提示',
                f'{SUITE_LABELS[suite]} 不支持维度 {dim}'
                f'（{"/".join(map(str, SUITE_LEGAL_DIMS[suite]))}）')
            return None

        runs = self.runs_var.get()
        try:
            workers = int(self.workers_var.get())
        except (tk.TclError, ValueError):
            workers = 1
        if workers > self.max_workers:
            workers = self.max_workers
            self.workers_var.set(str(workers))
            self._append_log(
                f'[gui] CPU 核数超过上限 {self.max_workers}，已自动调整\n')
        if workers < 1:
            workers = 1
            self.workers_var.set('1')
        mult = self.mult_var.get()

        frozen = getattr(sys, 'frozen', False)
        total = len(hosts) * SUITE_NFUNCS[suite]
        log_path = LOG_DIR / f'{suite}_D{dim}.log'
        if frozen:
            cmd = [sys.executable, '--run-experiment',
                   '--gui-log', str(log_path),
                   '--stage', 'main', '--suites', suite,
                   '--dims', str(dim),
                   '--hosts'] + hosts + \
                  ['--runs', str(runs), '--workers', str(workers),
                   '--evals-mult', str(mult)]
        else:
            cmd = [sys.executable, '-X', 'utf8', '-u', str(RUN_SCRIPT),
                   '--stage', 'main', '--suites', suite,
                   '--dims', str(dim),
                   '--hosts'] + hosts + \
                  ['--runs', str(runs), '--workers', str(workers),
                   '--evals-mult', str(mult)]
        if not self.upcl_var.get():
            cmd += ['--no-upcl']
        cmds = [(f'{suite} D{dim}', cmd, log_path)]
        self.total_cells = total
        return cmds

    # --------------------------------------------------------------- 运行
    def _start(self):
        if self.running:
            return
        try:
            self.runs_var.get(), self.workers_var.get()
            self.mult_var.get()
        except tk.TclError:
            messagebox.showerror('参数错误', '运行参数必须是整数')
            return
        cmds = self._build_commands()
        if not cmds:
            return
        self.cmd_queue = list(cmds)
        self.stop_flag = False
        self.paused = False
        self.current_cmd = None
        self._set_running(True)
        for f in (STOP_FILE, PAUSE_FILE):
            try:
                f.unlink()
            except FileNotFoundError:
                pass
        self._append_log(f'[gui] 共 {len(cmds)} 条命令、{self.total_cells} 个 cell\n')
        self.bar['maximum'] = self.total_cells
        self.progress_var.set(0)
        self._run_next()

    def _run_next(self):
        if self.stop_flag or not self.cmd_queue:
            self._finish_all()
            return
        desc, cmd, log_path = self.cmd_queue.pop(0)
        self.current_cmd = (desc, cmd, log_path)
        self.current_desc = desc
        self._append_log(f'[gui] 启动 [{desc}]:\n    {" ".join(cmd)}\n')
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.unlink()
        except FileNotFoundError:
            pass
        try:
            if getattr(sys, 'frozen', False):
                self.proc = subprocess.Popen(cmd, cwd=str(ROOT))
            else:
                log_fh = open(log_path, 'w', encoding='utf-8')
                self.proc = subprocess.Popen(cmd, cwd=str(ROOT),
                                             stdout=log_fh,
                                             stderr=subprocess.STDOUT)
                log_fh.close()
        except Exception as e:
            self._append_log(f'[gui] 启动失败: {e}\n')
            self._finish_all()
            return
        self.q = queue.Queue()
        threading.Thread(target=self._reader,
                         args=(self.proc, log_path), daemon=True).start()
        self._poll_queue()

    def _reader(self, proc, log_path):
        pos = 0
        while True:
            try:
                with open(log_path, 'r', encoding='utf-8',
                          errors='replace') as fh:
                    fh.seek(pos)
                    for line in fh:
                        self.q.put(line)
                    pos = fh.tell()
            except FileNotFoundError:
                pass
            if proc.poll() is not None:
                break
            time.sleep(0.2)
        try:
            with open(log_path, 'r', encoding='utf-8',
                      errors='replace') as fh:
                fh.seek(pos)
                for line in fh:
                    self.q.put(line)
        except FileNotFoundError:
            pass
        proc.wait()
        self.q.put(None)  # EOF

    def _poll_queue(self):
        if not self.running:
            return
        try:
            while True:
                line = self.q.get_nowait()
                if line is None:
                    self._on_proc_done()
                    return
                self._append_log(line)
                self._parse_progress(line)
        except queue.Empty:
            pass
        if self.stop_flag and self.proc is not None and \
                time.time() - self.stop_time > GRACE_SECONDS:
            self._force_kill()
        self.root.after(100, self._poll_queue)

    def _on_proc_done(self):
        rc = self.proc.returncode if self.proc else None
        self.proc = None
        self._append_log(f'[gui] 命令完成 [{self.current_desc}] (exit={rc})\n')
        if rc not in (0, None) and not self.stop_flag:
            # 非零退出码（且非用户主动停止）：弹窗提示查看日志，避免 windowed
            # 模式下错误静默无感。
            log_path = self.current_cmd[2] if self.current_cmd else None
            self._append_log(f'[gui] 警告：进程异常退出 (exit={rc})，'
                             f'详见日志 {log_path}\n')
            messagebox.showerror(
                '运行出错',
                f'实验进程异常退出（exit={rc}）。\n\n'
                f'请打开日志查看具体错误：\n{log_path}')
        if self.stop_flag or not self.cmd_queue:
            self._finish_all()
        else:
            self.current_cmd = None
            self._run_next()

    def _finish_all(self):
        self._set_running(False)
        self.stop_flag = False
        try:
            STOP_FILE.unlink()
        except FileNotFoundError:
            pass
        if self.paused:
            self.status_var.set('已暂停（可继续）')
            self._append_log('[gui] 已暂停：进行中的 cell 已落盘，'
                             '点击「继续执行」续跑剩余进度\n')
        else:
            self.status_var.set('已结束')
            self._append_log('[gui] 实验结束\n')

    def _parse_progress(self, line):
        m = re.match(
            r'\s*(\d+)/(\d+)\s*\(([\d.]+)%\)\s*elapsed\s+([\d.]+)\s*min'
            r'\s*eta\s+([\d.]+)\s*min', line)
        if not m:
            return
        finished, total = int(m.group(1)), int(m.group(2))
        pct = float(m.group(3))
        elapsed = float(m.group(4)) * 60.0
        eta = float(m.group(5)) * 60.0
        self.bar['maximum'] = total
        self.progress_var.set(finished)
        self.status_var.set(f'进度: {finished}/{total} cells ({pct:.1f}%)')
        self._refresh_progress_tab(finished, total, elapsed, eta)

    # --------------------------------------------------------------- 停止
    def _stop(self):
        if not self.running:
            return
        self.stop_flag = True
        self.paused = True
        self.stop_time = time.time()
        self._append_log('[gui] 已请求暂停：不再启动新 cell，'
                         '等待进行中的 cell 落盘后暂停…\n')
        try:
            STOP_FILE.parent.mkdir(parents=True, exist_ok=True)
            STOP_FILE.write_text('stop', encoding='utf-8')
        except Exception as e:
            self._append_log(f'[gui] 写入暂停标记失败: {e}\n')
        self.stop_btn.config(state='disabled')

    def _resume(self):
        if self.running or not self.paused:
            return
        self.paused = False
        self.stop_flag = False
        for f in (STOP_FILE, PAUSE_FILE):
            try:
                f.unlink()
            except FileNotFoundError:
                pass
        if self.current_cmd is not None:
            self.cmd_queue.insert(0, self.current_cmd)
            self.current_cmd = None
        self._set_running(True)
        self._append_log('[gui] 继续执行剩余进度（已完成 cell 自动跳过）…\n')
        self._run_next()

    def _force_kill(self):
        if self.proc is None:
            return
        pid = self.proc.pid
        self._append_log(f'[gui] 强制终止进程树 PID={pid}\n')
        try:
            if sys.platform == 'win32':
                subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'],
                               capture_output=True)
            else:
                self.proc.kill()
        except Exception as e:
            self._append_log(f'[gui] 强制终止失败: {e}\n')

    # --------------------------------------------------------------- 导出
    def _export_results(self):
        """把 results/cec/raw 下的 JSON 汇总为一张 CSV 表格。

        每个 cell（算法 × 函数 × 维度）按臂统计 err_final 的均值/标准差/
        中位数/最优值：bare = 原始算法，full = 启用 UPCL。用纯标准库实现，
        不依赖 numpy，exe 内也可用。
        """
        if not RAW.exists():
            messagebox.showinfo('导出结果',
                                '暂无结果数据\n(results/cec/raw 目录不存在)')
            return
        files = sorted(RAW.rglob('*.json'))
        if not files:
            messagebox.showinfo('导出结果',
                                '暂无结果数据\n(results/cec/raw 目录为空)')
            return

        arm_set = set()
        cells = []
        for p in files:
            try:
                with open(p, 'r', encoding='utf-8') as fh:
                    d = json.load(fh)
            except Exception:
                continue
            arms = {}
            for r in d.get('runs', []) or []:
                for k, v in r.items():
                    if k in ('run', 'seed') or not isinstance(v, dict):
                        continue
                    if 'err_final' not in v:
                        continue
                    arms.setdefault(k, []).append(float(v['err_final']))
                    arm_set.add(k)
            if not arms:
                continue
            cells.append(dict(
                suite=d.get('suite', ''), dim=d.get('dim', ''),
                host=d.get('host', ''), fid=d.get('fid', ''),
                func=d.get('func', ''), category=d.get('category', ''),
                n=max(len(v) for v in arms.values()), arms=arms))

        if not cells:
            messagebox.showinfo('导出结果', '暂无有效结果数据')
            return

        arms_sorted = sorted(arm_set)
        default_name = f'结果汇总_{time.strftime("%Y%m%d_%H%M%S")}.csv'
        path = filedialog.asksaveasfilename(
            title='导出结果表格', defaultextension='.csv',
            initialfile=default_name, initialdir=str(ROOT),
            filetypes=[('CSV 表格', '*.csv'), ('所有文件', '*.*')])
        if not path:
            return

        header = ['suite', 'dim', 'host', 'fid', 'func', 'category', 'n']
        for a in arms_sorted:
            header += [f'{a}_均值', f'{a}_标准差', f'{a}_中位数', f'{a}_最优']
        with open(path, 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.writer(fh)
            w.writerow(header)
            for c in sorted(cells,
                            key=lambda x: (str(x['suite']), str(x['dim']),
                                           str(x['host']), str(x['fid']))):
                row = [c['suite'], c['dim'], c['host'], c['fid'],
                       c['func'], c['category'], c['n']]
                for a in arms_sorted:
                    vals = c['arms'].get(a, [])
                    if vals:
                        row += [mean(vals),
                                stdev(vals) if len(vals) > 1 else 0.0,
                                median(vals), min(vals)]
                    else:
                        row += ['', '', '', '']
                w.writerow(row)

        self._append_log(f'[gui] 结果已导出: {path}（{len(cells)} 个 cell）\n')
        messagebox.showinfo('导出结果',
                            f'已导出 {len(cells)} 个 cell 到:\n{path}')

    # --------------------------------------------------------------- UAV 仿真
    def _open_uav(self):
        """打开 UAV 多智能体对抗仿真演示窗口（应用问题套件）。

        延迟导入 uav_gui：该模块会加载 matplotlib（TkAgg），仅在用户真正
        打开仿真时初始化，不影响主界面启动速度与其它零-matplotlib 功能。
        """
        try:
            import uav_gui
        except Exception as exc:
            messagebox.showerror('无法加载 UAV 仿真模块', repr(exc))
            return
        win = tk.Toplevel(self.root)
        try:
            uav_gui.UAVDemoApp(win)
            _fit_window(win, 1360, 820)
        except Exception as exc:
            win.destroy()
            messagebox.showerror('UAV 仿真启动失败', repr(exc))

    # --------------------------------------------------------------- 收敛曲线
    def _open_landscape(self):
        """二维地形图：算法种群在 x1-x2 适应度地形上的收敛过程。

        单 run 按需采样（后台线程），用 tk.Canvas 手绘热力图 + 种群散点，
        支持「叠加全部帧」与帧滑块逐帧查看，并可自动播放动画。零 matplotlib 依赖。
        """
        win = tk.Toplevel(self.root)
        win.title('二维地形图（种群收敛过程）')
        _fit_window(win, 1100, 800)
        win.transient(self.root)

        top = ttk.Frame(win, padding=6)
        top.pack(fill='x')

        suite_v = tk.StringVar(value=self.suite_var.get())
        dim_v = tk.StringVar(value=self.dims_var.get())
        func_v = tk.StringVar(value='F1')
        host_v = tk.StringVar(value=HOSTS[0])
        # 臂下拉显示中文（bare=基线；full=增加 UPCL），内部仍用英文值传给采样器
        ARM_KEYS = {'基线': 'bare', '增加 UPCL': 'full'}
        arm_v = tk.StringVar(value='基线')

        def mk(parent, var, vals, w):
            cb = ttk.Combobox(parent, textvariable=var, state='readonly',
                              width=w, values=vals)
            cb.pack(side='left', padx=(0, 6))
            return cb

        row1 = ttk.Frame(top)
        row1.pack(fill='x', pady=(0, 4))
        ttk.Label(row1, text='测试集').pack(side='left')
        suite_cb = mk(row1, suite_v, [SUITE_LABELS[s] for s in SUITES], 10)
        ttk.Label(row1, text='维度').pack(side='left')
        dim_cb = mk(row1, dim_v, [], 6)
        ttk.Label(row1, text='函数').pack(side='left')
        func_cb = mk(row1, func_v, [], 8)
        ttk.Label(row1, text='算法').pack(side='left')
        host_cb = mk(row1, host_v, HOSTS, 16)
        ttk.Label(row1, text='臂').pack(side='left')
        mk(row1, arm_v, list(ARM_KEYS.keys()), 10)

        row2 = ttk.Frame(top)
        row2.pack(fill='x')
        gen_btn = ttk.Button(row2, text='生成并绘制', command=lambda: start())
        gen_btn.pack(side='left', padx=(0, 8))
        play_btn = ttk.Button(row2, text='播放动画', command=lambda: play(),
                              state='disabled')
        play_btn.pack(side='left', padx=4)
        view3d_btn = ttk.Button(row2, text='三维地形图', command=lambda: open3d(),
                                state='disabled')
        view3d_btn.pack(side='left', padx=4)
        frame_var = tk.IntVar(value=0)
        frame_scale = ttk.Scale(row2, from_=0, to=0, variable=frame_var,
                                orient='horizontal',
                                command=lambda _: redraw_frame())
        frame_scale.pack(side='left', fill='x', expand=True, padx=8)
        overlay_var = tk.BooleanVar(value=False)
        _check(row2, text='叠加全部帧', variable=overlay_var,
               command=lambda: redraw_frame()).pack(side='left', padx=4)

        row3 = ttk.Frame(top)
        row3.pack(fill='x', pady=(4, 0))
        progress = ttk.Progressbar(row3, orient='horizontal',
                                   mode='determinate', maximum=1000)
        progress.pack(side='left', fill='x', expand=True)
        prog_label = ttk.Label(row3, text='', width=34, anchor='w')
        prog_label.pack(side='left', padx=(6, 0))

        mid = ttk.Frame(win)
        mid.pack(fill='both', expand=True, padx=6, pady=(4, 0))
        canvas = tk.Canvas(mid, bg='#0b0b12', highlightthickness=1,
                           highlightbackground='#333')
        canvas.pack(fill='both', expand=True)
        hint = tk.StringVar(value='选择参数后点击「生成并绘制」（单 run，约数秒~1分钟）')
        ttk.Label(mid, textvariable=hint, foreground='#555').pack(
            anchor='w', pady=(2, 4))

        state = {'data': None, 'geom': None, 'playing': False, 'after_id': None,
                 'sampling': False, 'progress': 0.0, 'progress_msg': ''}

        def refresh_dims():
            s = SUITE_KEY.get(suite_v.get())
            if not s:
                return
            dims = [str(d) for d in SUITE_LEGAL_DIMS[s]]
            dim_cb['values'] = dims
            if dim_v.get() not in dims:
                dim_v.set(dims[0])
            refresh_funcs()

        def refresh_funcs():
            s = SUITE_KEY.get(suite_v.get())
            if not s or not dim_v.get():
                return
            labels = [f'F{i}' for i in range(1, SUITE_NFUNCS.get(s, 0) + 1)]
            func_cb['values'] = labels
            if func_v.get() not in labels:
                func_v.set('F1')

        def _progress(fraction, message):
            state['progress'] = float(fraction)
            state['progress_msg'] = message

        def _poll_progress():
            if not state.get('sampling'):
                return
            progress['value'] = int(state.get('progress', 0.0) * 1000)
            prog_label.configure(text=state.get('progress_msg', ''))
            win.after(150, _poll_progress)

        def start():
            s = SUITE_KEY.get(suite_v.get())
            try:
                d = int(dim_v.get())
                fid = int(func_v.get().lstrip('F'))
            except (tk.TclError, ValueError):
                hint.set('请选择测试集 / 维度 / 函数')
                return
            host = host_v.get()
            arm = ARM_KEYS.get(arm_v.get(), 'bare')
            state['playing'] = False
            play_btn.configure(state='disabled', text='播放动画')
            gen_btn.configure(state='disabled')
            state['sampling'] = True
            state['progress'] = 0.0
            state['progress_msg'] = '准备采样…'
            progress['value'] = 0
            prog_label.configure(text='准备采样…')
            hint.set('正在采样二维地形与种群轨迹（单 run）…')
            _poll_progress()

            def worker():
                data = None
                try:
                    # windowed exe 里 sys.stdout 为 None，cec_suites 会 print 提示，
                    # 先兜底到 devnull 避免崩溃。
                    if sys.stdout is None:
                        sys.stdout = open(os.devnull, 'w', encoding='utf-8')
                    sys.path.insert(0, str(ROOT / 'src'))
                    import landscape_probe as LP
                    data = LP.sample(s, d, fid, host, arm=arm,
                                     progress_cb=_progress)
                except Exception as e:
                    data = {'error': f'{type(e).__name__}: {e}'}
                try:
                    win.after(0, lambda d=data: _finish(d))
                except Exception:
                    pass

            threading.Thread(target=worker, daemon=True).start()

        def _finish(data):
            gen_btn.configure(state='normal')
            state['sampling'] = False
            progress['value'] = 1000
            prog_label.configure(text='采样完成')
            if not data or data.get('error'):
                hint.set(f'采样失败：{data.get("error") if data else "无返回"}')
                return
            state['data'] = data
            traces = data.get('traces') or []
            nf = len(traces[0]['gens']) if traces else 0
            frame_var.set(0)
            frame_scale.configure(from_=0, to=max(0, nf - 1))
            play_btn.configure(state='normal' if nf > 1 else 'disabled')
            view3d_btn.configure(state='normal')
            draw()
            hint.set(f'{data["func"]} · {host_v.get()} · '
                     f'{arm_v.get()} · {nf} 帧 · 白叉=全局最优 x* · 黄圈=算法找到的最优')

        def draw():
            data = state['data']
            canvas.delete('all')
            if not data:
                return
            import numpy as np
            X, Y, Z = data['landscape']
            lb, ub = data['lb'], data['ub']
            canvas.update_idletasks()
            w = max(canvas.winfo_width(), 480)
            h = max(canvas.winfo_height(), 380)
            ml, mr, mt, mb = 60, 16, 18, 44
            pw = w - ml - mr
            ph = h - mt - mb
            if pw < 40 or ph < 40:
                return
            state['geom'] = (ml, mr, mt, mb, pw, ph, lb, ub)

            def cx(x):
                return ml + (x - lb) / (ub - lb) * pw

            def cy(y):
                return mt + ph - (y - lb) / (ub - lb) * ph

            # log 归一化地形，放大谷底对比
            Zf = np.asarray(Z, dtype=float)
            Zn = np.log10(Zf - float(Zf.min()) + 1.0)
            zn_min, zn_max = float(Zn.min()), float(Zn.max())
            span = (zn_max - zn_min) or 1.0

            n = Zf.shape[0]
            gx = np.linspace(lb, ub, n)
            gy = np.linspace(lb, ub, n)
            dx, dy = pw / n, ph / n
            for i in range(n):
                yy = cy(gy[i])
                for j in range(n):
                    t = (Zn[i, j] - zn_min) / span
                    col = _jet(t)
                    xx = cx(gx[j])
                    canvas.create_rectangle(xx - dx / 2, yy - dy / 2,
                                            xx + dx / 2, yy + dy / 2,
                                            fill=col, outline=col, tags='heat')
            # 等高线（marching squares）：用“圈圈”体现地形层级
            for li in range(1, 9):
                level = zn_min + span * li / 9.0
                for (x1, y1, x2, y2) in _contour_segments(Zn, level, lb, ub):
                    canvas.create_line(cx(x1), cy(y1), cx(x2), cy(y2),
                                       fill='white', width=1, tags='contour')
            # 边框 + 刻度
            canvas.create_rectangle(ml, mt, ml + pw, mt + ph, outline='#666')
            for k in range(6):
                xv = lb + (ub - lb) * k / 5
                canvas.create_text(cx(xv), mt + ph + 12, text=f'{xv:.0f}',
                                   anchor='n', fill='#999',
                                   font=('TkDefaultFont', 8))
                yv = lb + (ub - lb) * k / 5
                canvas.create_text(ml - 8, cy(yv), text=f'{yv:.0f}',
                                   anchor='e', fill='#999',
                                   font=('TkDefaultFont', 8))
            canvas.create_text(ml + pw // 2, h - 10, text='x1', fill='#ccc')
            canvas.create_text(12, mt + ph // 2, text='x2', angle=90,
                               fill='#ccc')

            # 全局最优 x*（白叉）
            xo = data.get('x_opt') or []
            if len(xo) >= 2:
                canvas.create_line(cx(xo[0]) - 7, cy(xo[1]),
                                   cx(xo[0]) + 7, cy(xo[1]),
                                   fill='white', width=2, tags='heat')
                canvas.create_line(cx(xo[0]), cy(xo[1]) - 7,
                                   cx(xo[0]), cy(xo[1]) + 7,
                                   fill='white', width=2, tags='heat')
            # 算法找到的最优 best_x（黄圈）
            bx = data.get('best_x') or []
            if len(bx) >= 2:
                canvas.create_oval(cx(bx[0]) - 6, cy(bx[1]) - 6,
                                   cx(bx[0]) + 6, cy(bx[1]) + 6,
                                   outline='#ffff00', width=2, tags='heat')
            redraw_frame()

        def redraw_frame():
            data = state['data']
            geom = state.get('geom')
            if not data or not geom:
                return
            ml, mr, mt, mb, pw, ph, lb, ub = geom

            def cx(x):
                return ml + (x - lb) / (ub - lb) * pw

            def cy(y):
                return mt + ph - (y - lb) / (ub - lb) * ph

            canvas.delete('scatter')
            traces = data.get('traces') or []
            if not traces:
                return
            tr = traces[0]
            gens = tr['gens']
            nf = len(gens)
            if nf == 0:
                return
            idx = max(0, min(nf - 1, int(frame_var.get())))
            max_pts = 160

            def _pts(p):
                if len(p) > max_pts:
                    return p[:: len(p) // max_pts + 1]
                return p

            if overlay_var.get():
                for k in range(nf):
                    col = _jet(k / max(1, nf - 1))
                    for (x, y) in _pts(tr['pop'][k]):
                        canvas.create_oval(cx(x) - 2, cy(y) - 2,
                                           cx(x) + 2, cy(y) + 2,
                                           fill=col, outline='', tags='scatter')
            else:
                # 只画当前帧：个体数固定、位置更新，不叠加历史帧
                cur = _pts(tr['pop'][idx])
                nxt = _pts(tr['pop'][idx + 1]) if idx + 1 < nf else None
                bx = data.get('best_x') or []
                # 虚线方向引导线：当前个体 -> 下一帧对应个体（末帧 -> 最优解）
                for i, (x, y) in enumerate(cur):
                    if nxt is not None and i < len(nxt):
                        tx, ty = nxt[i]
                    elif len(bx) >= 2:
                        tx, ty = bx[0], bx[1]
                    else:
                        continue
                    canvas.create_line(cx(x), cy(y), cx(tx), cy(ty),
                                       fill='#00e5ff', width=1, dash=(4, 4),
                                       arrow=tk.LAST, tags='scatter')
                # 当前帧个体散点
                for (x, y) in cur:
                    canvas.create_oval(cx(x) - 3, cy(y) - 3,
                                       cx(x) + 3, cy(y) + 3,
                                       fill='#00e5ff', outline='#002030',
                                       width=1, tags='scatter')
            canvas.create_text(ml + pw - 6, mt + 8, anchor='ne',
                               text=f'第 {gens[idx]} 代', fill='white',
                               font=('TkDefaultFont', 10, 'bold'),
                               tags='scatter')

        def play():
            data = state['data']
            traces = data.get('traces') or [] if data else []
            nf = len(traces[0]['gens']) if traces else 0
            if nf <= 1:
                return
            if state['playing']:
                state['playing'] = False
                play_btn.configure(text='播放动画')
                return
            state['playing'] = True
            play_btn.configure(text='停止')

            def tick():
                if not state['playing']:
                    return
                idx = int(frame_var.get()) + 1
                if idx >= nf:
                    idx = 0
                frame_var.set(idx)
                redraw_frame()
                state['after_id'] = win.after(220, tick)

            tick()

        def open3d():
            """三维地形图：matplotlib 3D 坐标轴曲面（真实函数坐标）+ 当前帧种群。

            带 x1 / x2 / f(x) 三轴与浅色背景，鼠标可旋转、滚轮可缩放；
            个体每帧更新、不叠加。
            """
            data = state['data']
            if not data:
                return
            import numpy as np
            import matplotlib
            if 'tkagg' not in matplotlib.get_backend().lower():
                matplotlib.use('TkAgg')
            import matplotlib.pyplot as plt
            import mpl_toolkits.mplot3d  # noqa: F401  注册 '3d' 投影
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            X, Y, Z = data['landscape']
            lb, ub = data['lb'], data['ub']
            Zf = np.asarray(Z, dtype=float)
            n = Zf.shape[0]

            def z_at(x, y):
                ji = int(round((x - lb) / (ub - lb) * (n - 1)))
                ii = int(round((y - lb) / (ub - lb) * (n - 1)))
                return float(Zf[max(0, min(n - 1, ii)), max(0, min(n - 1, ji))])

            win3 = tk.Toplevel(win)
            win3.title('三维地形图（种群收敛过程）')
            _fit_window(win3, 1080, 840)
            win3.transient(win)

            top3 = ttk.Frame(win3, padding=6)
            top3.pack(fill='x')
            play3_btn = ttk.Button(top3, text='播放动画', command=lambda: play3(),
                                   state='disabled')
            play3_btn.pack(side='left', padx=(0, 8))
            frame_var3 = tk.IntVar(value=0)
            frame_scale3 = ttk.Scale(top3, from_=0, to=0, variable=frame_var3,
                                     orient='horizontal',
                                     command=lambda _: redraw_pts())
            frame_scale3.pack(side='left', fill='x', expand=True, padx=8)
            fig = plt.Figure(figsize=(10, 7.6), dpi=100)
            ax = fig.add_subplot(111, projection='3d')
            canvas3 = FigureCanvasTkAgg(fig, master=win3)
            canvas3.get_tk_widget().pack(fill='both', expand=True, padx=6, pady=6)

            m = min(n, 64)
            gi = np.linspace(0, n - 1, m).astype(int)
            ax.plot_surface(X[np.ix_(gi, gi)], Y[np.ix_(gi, gi)],
                            Zf[np.ix_(gi, gi)], cmap='viridis', alpha=0.92,
                            linewidth=0, antialiased=True)
            xo = data.get('x_opt') or []
            bx = data.get('best_x') or []
            if len(xo) >= 2:
                ax.scatter([xo[0]], [xo[1]], [z_at(xo[0], xo[1])], c='white',
                           marker='x', s=90, linewidths=2, depthshade=False,
                           label='global opt x*')
            if len(bx) >= 2:
                ax.scatter([bx[0]], [bx[1]], [z_at(bx[0], bx[1])], c='yellow',
                           marker='o', s=60, edgecolors='k', linewidths=1,
                           depthshade=False, label='best found')
            ax.set_xlabel('x1')
            ax.set_ylabel('x2')
            ax.set_zlabel('f(x)')
            ax.set_title(f'{data["func"]}  {host_v.get()}  {data["arm"]}')
            ax.view_init(elev=30, azim=-55)
            if len(xo) >= 2 or len(bx) >= 2:
                ax.legend(loc='upper left', fontsize=8)
            canvas3.draw()
            hint3 = tk.StringVar(value='')
            ttk.Label(win3, textvariable=hint3, foreground='#666').pack(
                anchor='w', padx=6, pady=(0, 6))

            traces = data.get('traces') or []
            gens = traces[0]['gens'] if traces else []
            nf = len(gens)
            st3 = {'playing': False, 'after_id': None}
            scat = {'artist': None}

            def redraw_pts():
                if not traces or nf == 0:
                    return
                idx = max(0, min(nf - 1, int(frame_var3.get())))
                pts = np.asarray(traces[0]['pop'][idx], dtype=float)
                if scat['artist'] is not None:
                    scat['artist'].remove()
                    scat['artist'] = None
                if len(pts):
                    zs = [z_at(x, y) for x, y in pts]
                    scat['artist'] = ax.scatter(pts[:, 0], pts[:, 1], zs,
                                                c='#00e5ff', s=26, depthshade=True,
                                                edgecolors='#002030', linewidths=0.4)
                hint3.set(f'第 {gens[idx]} 代 · {len(pts)} 个个体 · 拖动旋转 / 滚轮缩放')
                canvas3.draw_idle()

            def play3():
                if st3['playing']:
                    st3['playing'] = False
                    play3_btn.configure(text='播放动画')
                    return
                if nf <= 1:
                    return
                st3['playing'] = True
                play3_btn.configure(text='停止')

                def tick3():
                    if not st3['playing']:
                        return
                    i = int(frame_var3.get()) + 1
                    if i >= nf:
                        i = 0
                    frame_var3.set(i)
                    redraw_pts()
                    st3['after_id'] = win3.after(220, tick3)

                tick3()

            frame_scale3.configure(from_=0, to=max(0, nf - 1))
            play3_btn.configure(state='normal' if nf > 1 else 'disabled')
            redraw_pts()

        suite_cb.bind('<<ComboboxSelected>>', lambda e: refresh_dims())
        dim_cb.bind('<<ComboboxSelected>>', lambda e: refresh_funcs())
        refresh_dims()

    def _open_convergence(self):
        """打开独立窗口，用已有结果数据绘制收敛曲线。

        横坐标 = 评估次数（FES，来自 json 的 grid 字段），
        纵坐标 = 适应度误差（默认 log10）。tkinter Canvas 手绘，零额外依赖。
        """
        win = tk.Toplevel(self.root)
        win.title('收敛曲线')
        _fit_window(win, 1080, 720)
        win.transient(self.root)

        top = ttk.Frame(win, padding=6)
        top.pack(fill='x')

        suite_v = tk.StringVar(value=self.suite_var.get())
        dim_v = tk.StringVar(value=self.dims_var.get())
        func_v = tk.StringVar(value='F1')
        stat_v = tk.StringVar(value='中位数')
        log_v = tk.BooleanVar(value=True)
        arm_vars = {a: tk.BooleanVar(value=True) for a in ARM_DISPLAY}

        def mk(parent, var, vals, w):
            cb = ttk.Combobox(parent, textvariable=var, state='readonly',
                              width=w, values=vals)
            cb.pack(side='left', padx=(0, 8))
            return cb

        row1 = ttk.Frame(top)
        row1.pack(fill='x', pady=(0, 6))
        ttk.Label(row1, text='测试集').pack(side='left')
        suite_cb = mk(row1, suite_v, [SUITE_LABELS[s] for s in SUITES], 10)
        ttk.Label(row1, text='维度').pack(side='left')
        dim_cb = mk(row1, dim_v, [], 6)
        ttk.Label(row1, text='函数').pack(side='left')
        func_cb = mk(row1, func_v, [], 10)
        ttk.Label(row1, text='对比').pack(side='left', padx=(6, 0))
        for a, lab in ARM_DISPLAY.items():
            _check(row1, text=lab, variable=arm_vars[a]).pack(
                side='left', padx=3)
        ttk.Label(row1, text='统计').pack(side='left', padx=(8, 0))
        mk(row1, stat_v, ['中位数', '均值'], 7)
        _check(row1, text='log10 误差', variable=log_v).pack(
            side='left', padx=8)
        ttk.Button(row1, text='绘制', command=lambda: do_plot()).pack(
            side='left', padx=8)

        mid = ttk.Frame(win)
        mid.pack(fill='both', expand=True, padx=6, pady=(0, 6))

        left = ttk.Labelframe(mid, text='算法（多选）', padding=4)
        left.pack(side='left', fill='y')
        host_list = tk.Listbox(left, selectmode='extended', width=22,
                               exportselection=False)
        host_list.pack(side='left', fill='y')
        hs = ttk.Scrollbar(left, orient='vertical', command=host_list.yview)
        hs.pack(side='right', fill='y')
        host_list.configure(yscrollcommand=hs.set)
        for h in HOSTS:
            host_list.insert('end', h)
        host_list.select_set(0, 'end')
        btns = ttk.Frame(left)
        btns.pack(fill='x')
        ttk.Button(btns, text='全选', width=6,
                   command=lambda: host_list.select_set(0, 'end')).pack(
            side='left', padx=3, pady=3)
        ttk.Button(btns, text='清空', width=6,
                   command=lambda: host_list.select_clear(0, 'end')).pack(
            side='left', padx=3)

        right = ttk.Frame(mid)
        right.pack(side='left', fill='both', expand=True, padx=(6, 0))
        canvas = tk.Canvas(right, bg='white', highlightthickness=1,
                           highlightbackground='#bbb')
        canvas.pack(fill='both', expand=True)
        hint = tk.StringVar(value='选择参数后点击「绘制」')
        ttk.Label(right, textvariable=hint, foreground='#555').pack(
            anchor='w', pady=(2, 0))

        def refresh_funcs():
            s = SUITE_KEY.get(suite_v.get())
            if not s or not dim_v.get():
                return
            labels = ['全部'] + [f'F{i}' for i in
                                 range(1, SUITE_NFUNCS.get(s, 0) + 1)]
            func_cb['values'] = labels
            if func_v.get() not in labels:
                func_v.set('F1')

        def refresh_dims():
            s = SUITE_KEY.get(suite_v.get())
            if not s:
                return
            dims = [str(d) for d in SUITE_LEGAL_DIMS[s]]
            dim_cb['values'] = dims
            if dim_v.get() not in dims:
                dim_v.set(dims[0])
            refresh_funcs()

        def do_plot():
            s = SUITE_KEY.get(suite_v.get())
            try:
                d = int(dim_v.get())
            except (tk.TclError, ValueError):
                hint.set('请选择维度')
                return
            hosts = [host_list.get(i) for i in host_list.curselection()]
            if not hosts:
                hint.set('请至少选择一个算法')
                return
            arms = [a for a in ARM_DISPLAY if arm_vars[a].get()]
            if not arms:
                hint.set('请至少选择一种曲线')
                return
            xs, curves = self._collect_curves(s, d, func_v.get(), hosts, arms,
                                              stat_v.get(), log_v.get())
            self._draw_curve_canvas(canvas, xs, curves, log_v.get(), hint)

        suite_cb.bind('<<ComboboxSelected>>', lambda e: refresh_dims())
        dim_cb.bind('<<ComboboxSelected>>', lambda e: refresh_funcs())
        refresh_dims()

    def _collect_curves(self, suite, dim, func_choice, hosts, arms, stat, log_y):
        """读取选中 cell 的收敛曲线，按统计量逐点聚合，返回 (xs, curves)。"""
        ddir = RAW / suite / f'D{dim}'
        if not ddir.is_dir():
            return None, []
        nf = SUITE_NFUNCS.get(suite, 0)
        if func_choice == '全部':
            fids = list(range(1, nf + 1))
        else:
            try:
                fids = [int(func_choice.lstrip('F'))]
            except ValueError:
                return None, []
        xs = None
        curves = []
        for host in hosts:
            for fid in fids:
                # 文件名里 '/' 已被替换为 '-'（见 run_upcl_cec.py 落盘规则）
                p = ddir / f'{host.replace("/", "-")}__F{fid}.json'
                if not p.exists():
                    continue
                try:
                    with open(p, 'r', encoding='utf-8') as fh:
                        data = json.load(fh)
                except Exception:
                    continue
                for arm in arms:
                    # 语义臂 -> 数据臂：'upcl' 在旧宿主落盘名为 'upcl'、
                    # wave4 变体为 'full'，绘图时统一为同一语义。
                    data_arm = arm
                    if arm == 'upcl':
                        keys = {k for r in data.get('runs', []) or []
                                for k in r if k not in ('run', 'seed')}
                        data_arm = 'upcl' if 'upcl' in keys else 'full'
                    series = []
                    for r in data.get('runs', []) or []:
                        rec = r.get(data_arm)
                        if isinstance(rec, dict) and 'err_curve' in rec:
                            if xs is None:
                                xs = [float(v) for v in
                                      (rec.get('grid') or
                                       range(1, len(rec['err_curve']) + 1))]
                            series.append(rec['err_curve'])
                    if not series:
                        continue
                    n = len(series[0])
                    ys = []
                    for i in range(n):
                        vals = [s[i] for s in series if i < len(s)]
                        if not vals:
                            continue
                        v = median(vals) if stat == '中位数' else mean(vals)
                        if log_y:
                            v = math.log10(max(v, 1e-300))
                        ys.append(v)
                    host_label = host if arm == 'bare' else f'{host}-UPCL'
                    label = (f'{host_label} F{fid}' if len(fids) > 1
                             else host_label)
                    curves.append((label, ys))
        return xs, curves

    def _draw_curve_canvas(self, canvas, xs, curves, log_y, hint):
        canvas.delete('all')
        if not xs or not curves:
            canvas.create_text(400, 240, text='暂无数据（可能尚未运行）',
                               fill='#888')
            hint.set('暂无数据')
            return
        canvas.update_idletasks()
        w = max(canvas.winfo_width(), 420)
        h = max(canvas.winfo_height(), 320)
        ml, mr, mt, mb = 72, 16, 20, 42
        pw = w - ml - mr
        ph = h - mt - mb
        if pw < 60 or ph < 60:
            hint.set('窗口过小，无法绘制')
            return

        x0, x1 = float(min(xs)), float(max(xs))
        ys_all = [y for _, ys in curves for y in ys if math.isfinite(y)]
        if not ys_all:
            hint.set('无有效数据')
            return
        y0, y1 = min(ys_all), max(ys_all)
        if y1 - y0 < 1e-12:
            y1 = y0 + 1.0
        pad = (y1 - y0) * 0.05
        y0 -= pad
        y1 += pad
        span = y1 - y0

        def px(x):
            return ml + (x - x0) / (x1 - x0) * pw if x1 > x0 else ml

        def py(y):
            return mt + ph - (y - y0) / span * ph

        # 网格 + y 轴刻度
        for i in range(7):
            yv = y0 + span * i / 6
            yy = py(yv)
            canvas.create_line(ml, yy, ml + pw, yy, fill='#e8e8e8')
            canvas.create_text(ml - 8, yy, text=f'{yv:.2f}', anchor='e',
                               fill='#444', font=('TkDefaultFont', 8))
        # x 轴刻度
        for i in range(7):
            xv = x0 + (x1 - x0) * i / 6
            xx = px(xv)
            canvas.create_text(xx, mt + ph + 8, text=f'{xv:.0f}', anchor='n',
                               fill='#444', font=('TkDefaultFont', 8))
        # 坐标轴与轴标题
        canvas.create_line(ml, mt, ml, mt + ph, fill='#333')
        canvas.create_line(ml, mt + ph, ml + pw, mt + ph, fill='#333')
        canvas.create_text(14, mt + ph // 2,
                           text='log10 误差' if log_y else '误差',
                           angle=90, fill='#333')
        canvas.create_text(ml + pw // 2, h - 12, text='评估次数 (FES)',
                           fill='#333')

        # 曲线 + 图例（右上角）
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
                  '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
                  '#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00',
                  '#a65628', '#f781bf', '#999999', '#66c2a5', '#fc8d62']
        leg_x, leg_y = ml + pw - 10, mt + 10
        for idx, (label, ys) in enumerate(curves):
            color = colors[idx % len(colors)]
            pts = []
            for i, y in enumerate(ys):
                if i < len(xs) and math.isfinite(y):
                    pts += [px(xs[i]), py(y)]
            if len(pts) >= 4:
                canvas.create_line(*pts, fill=color, width=2)
            if idx < 20 and leg_y < mt + ph - 10:
                tw = 6 * len(label) + 26
                lx = leg_x - tw
                canvas.create_rectangle(lx - 4, leg_y - 2, leg_x + 4,
                                        leg_y + 12, fill='white', outline='')
                canvas.create_line(lx, leg_y + 5, lx + 16, leg_y + 5,
                                   fill=color, width=2)
                canvas.create_text(lx + 20, leg_y + 5, text=label, anchor='w',
                                   fill='#333', font=('TkDefaultFont', 8))
                leg_y += 15
        hint.set(f'已绘制 {len(curves)} 条曲线')

    # --------------------------------------------------------------- 机制分析
    def _collect_mechanism(self, suite, dim, fids, hosts):
        """读取每个 (host, fid) 的三指标：效应量 dec、干预率 ρ、描述子效应。"""
        ddir = RAW / suite / f'D{dim}'
        cells = []
        for host in hosts:
            for fid in fids:
                p = ddir / f'{host.replace("/", "-")}__F{fid}.json'
                if not p.exists():
                    continue
                try:
                    with open(p, 'r', encoding='utf-8') as fh:
                        data = json.load(fh)
                except Exception:
                    continue
                runs = [r for r in (data.get('runs') or [])
                        if isinstance(r, dict)]
                if not runs:
                    continue
                arm_keys = {k for r in runs for k in r
                            if k not in ('run', 'seed') and isinstance(r[k], dict)}
                bare_key = 'bare' if 'bare' in arm_keys else None
                upcl_key = ('upcl' if 'upcl' in arm_keys
                            else 'full' if 'full' in arm_keys else None)
                if bare_key is None or upcl_key is None:
                    continue

                def _err(key):
                    return [float(r[key]['err_final']) for r in runs
                            if key in r and isinstance(r[key], dict)
                            and 'err_final' in r[key]]

                err_b, err_u = _err(bare_key), _err(upcl_key)
                if not err_b or not err_u:
                    continue
                dec = (math.log10(max(median(err_b), 1e-300))
                       - math.log10(max(median(err_u), 1e-300)))

                ir, pr = [], []
                desc = {name: [] for name, _ in DESC_NAMES}
                rc_all, rpc_all = [], []
                for r in runs:
                    rec = r.get(upcl_key)
                    if not isinstance(rec, dict):
                        continue
                    st = rec.get('upcl')
                    if not isinstance(st, dict):
                        continue
                    if isinstance(st.get('intervention_rate'), (int, float)):
                        ir.append(float(st['intervention_rate']))
                    if isinstance(st.get('policy_rate'), (int, float)):
                        pr.append(float(st['policy_rate']))
                    di = st.get('descriptor_influence')
                    if isinstance(di, dict):
                        for k, (name, _lab) in enumerate(DESC_NAMES):
                            v = di.get(f'z{k}_effect')
                            if isinstance(v, (int, float)):
                                desc[name].append(float(v))
                    if isinstance(st.get('rho_curve'), list) and st['rho_curve']:
                        rc_all.append(_resample_curve(st['rho_curve']))
                    if isinstance(st.get('rho_policy_curve'), list) and st['rho_policy_curve']:
                        rpc_all.append(_resample_curve(st['rho_policy_curve']))

                def _med_col(curves):
                    if not curves:
                        return None
                    return [median(col) for col in zip(*curves)]

                cells.append(dict(
                    host=host, fid=fid, dec=dec,
                    intervention_rate=(median(ir) if ir else None),
                    policy_rate=(median(pr) if pr else None),
                    desc={name: (median(v) if v else None)
                          for name, v in desc.items()},
                    rho_curve=_med_col(rc_all),
                    rho_policy_curve=_med_col(rpc_all),
                ))
        return cells

    def _draw_bar_chart(self, canvas, labels, values, y_title, hint,
                        value_fmt='{:.2f}', sort_desc=False):
        """通用柱状图：x=labels，y=values（可正负），含 0 基准线与刻度。"""
        canvas.delete('all')
        if not labels or not values:
            canvas.create_text(300, 160, text='暂无数据（可能尚未运行）',
                               fill='#888')
            hint.set('暂无数据')
            return
        if sort_desc:
            pairs = sorted(zip(labels, values),
                           key=lambda p: (p[1] is None,
                                          -(p[1] if p[1] is not None else 0.0)))
            labels = [p[0] for p in pairs]
            values = [p[1] for p in pairs]
        canvas.update_idletasks()
        w = max(canvas.winfo_width(), 420)
        h = max(canvas.winfo_height(), 280)
        ml, mr, mt, mb = 62, 16, 26, 60
        pw = w - ml - mr
        ph = h - mt - mb
        if pw < 60 or ph < 60:
            hint.set('窗口过小，无法绘制')
            return
        n = len(labels)
        vals = [v for v in values if v is not None]
        if not vals:
            canvas.create_text(300, 160, text='暂无有效数据', fill='#888')
            hint.set('暂无有效数据')
            return
        vmin, vmax = min(vals), max(vals)
        if vmin > 0:
            vmin = 0.0
        if vmax < 0:
            vmax = 0.0
        if vmax - vmin < 1e-12:
            vmax = vmin + 1.0
        span = vmax - vmin
        vmin -= span * 0.05
        vmax += span * 0.05
        span = vmax - vmin

        def py(y):
            return mt + (vmax - y) / span * ph

        zero_y = py(0.0)
        for i in range(7):
            yv = vmin + span * i / 6
            yy = py(yv)
            canvas.create_line(ml, yy, ml + pw, yy, fill='#e8e8e8')
            canvas.create_text(ml - 8, yy, text=value_fmt.format(yv),
                               anchor='e', fill='#444',
                               font=('TkDefaultFont', 8))
        canvas.create_line(ml, mt, ml, mt + ph, fill='#333')
        canvas.create_line(ml, mt + ph, ml + pw, mt + ph, fill='#333')
        canvas.create_line(ml, zero_y, ml + pw, zero_y, fill='#bbb',
                           dash=(3, 3))
        canvas.create_text(14, mt + ph // 2, text=y_title, angle=90,
                           fill='#333')

        bw = (pw / n) * 0.78
        for i, (lab, v) in enumerate(zip(labels, values)):
            if v is None:
                continue
            xc = ml + (i + 0.5) * (pw / n)
            y_top = py(v)
            color = '#2ca02c' if v >= 0 else '#d62728'
            canvas.create_rectangle(xc - bw / 2, y_top, xc + bw / 2, zero_y,
                                    fill=color, outline='')
            canvas.create_text(xc, y_top - 6, text=value_fmt.format(v),
                               anchor='s', fill='#333',
                               font=('TkDefaultFont', 8))
            canvas.create_text(xc, mt + ph + 6, text=lab, angle=45, anchor='e',
                               fill='#444', font=('TkDefaultFont', 8))
        hint.set(f'已绘制 {sum(1 for v in values if v is not None)} 个柱')

    def _draw_hbar_chart(self, canvas, labels, values, y_title, hint,
                         value_fmt='{:.2f}'):
        """横向条形图：每行一个 label，柱从 0 线向正（绿）或负（红）延伸。"""
        canvas.delete('all')
        if not labels or not values:
            canvas.create_text(300, 160, text='暂无数据（可能尚未运行）',
                               fill='#888')
            hint.set('暂无数据')
            return
        canvas.update_idletasks()
        w = max(canvas.winfo_width(), 420)
        h = max(canvas.winfo_height(), 320)
        ml, mr, mt, mb = 150, 40, 18, 26
        pw = w - ml - mr
        ph = h - mt - mb
        n = len(labels)
        vals = [v for v in values if v is not None]
        if not vals:
            canvas.create_text(300, 160, text='暂无有效数据', fill='#888')
            hint.set('暂无有效数据')
            return
        vmin, vmax = min(vals), max(vals)
        if vmin > 0:
            vmin = 0.0
        if vmax < 0:
            vmax = 0.0
        if vmax - vmin < 1e-12:
            vmax = vmin + 1.0
        span = vmax - vmin
        vmin -= span * 0.05
        vmax += span * 0.05
        span = vmax - vmin

        def px(v):
            return ml + (v - vmin) / span * pw

        zero_x = px(0.0)
        for i in range(7):
            xv = vmin + span * i / 6
            xx = px(xv)
            canvas.create_line(xx, mt, xx, mt + ph, fill='#e8e8e8')
            canvas.create_text(xx, mt + ph + 8, text=value_fmt.format(xv),
                               anchor='n', fill='#444',
                               font=('TkDefaultFont', 8))
        canvas.create_line(ml, mt, ml + pw, mt, fill='#333')
        canvas.create_line(ml, mt + ph, ml + pw, mt + ph, fill='#333')
        canvas.create_line(zero_x, mt, zero_x, mt + ph, fill='#bbb',
                           dash=(3, 3))
        canvas.create_text(ml + pw // 2, h - 8, text=y_title, fill='#333')

        row_h = ph / n
        bh = row_h * 0.62
        for i, (lab, v) in enumerate(zip(labels, values)):
            yc = mt + (i + 0.5) * row_h
            if v is None:
                canvas.create_text(ml - 8, yc, text=lab, anchor='e',
                                   fill='#999', font=('TkDefaultFont', 9))
                continue
            xv = px(v)
            color = '#2ca02c' if v >= 0 else '#d62728'
            canvas.create_rectangle(min(xv, zero_x), yc - bh / 2,
                                    max(xv, zero_x), yc + bh / 2,
                                    fill=color, outline='')
            canvas.create_text(xv + (6 if v >= 0 else -6), yc,
                               text=value_fmt.format(v),
                               anchor='w' if v >= 0 else 'e',
                               fill='#333', font=('TkDefaultFont', 8))
            canvas.create_text(ml - 8, yc, text=lab, anchor='e',
                               fill='#333', font=('TkDefaultFont', 9))
        hint.set(f'已绘制 {sum(1 for v in values if v is not None)} 个柱')

    def _draw_line_chart(self, canvas, xs, curves, hint, y_title, x_title,
                         y_fmt='{:.2f}'):
        """折线图：xs=横轴，curves=[(label, ys), ...]，右上角图例。"""
        canvas.delete('all')
        if not xs or not curves:
            canvas.create_text(400, 240, text='暂无数据（可能尚未运行）',
                               fill='#888')
            hint.set('暂无数据')
            return
        canvas.update_idletasks()
        w = max(canvas.winfo_width(), 420)
        h = max(canvas.winfo_height(), 320)
        ml, mr, mt, mb = 62, 16, 20, 46
        pw = w - ml - mr
        ph = h - mt - mb
        if pw < 60 or ph < 60:
            hint.set('窗口过小，无法绘制')
            return

        x0, x1 = float(min(xs)), float(max(xs))
        if x1 - x0 < 1e-12:
            x1 = x0 + 1.0
        ys_all = [y for _, ys in curves for y in ys if math.isfinite(y)]
        if not ys_all:
            hint.set('无有效数据')
            return
        y0, y1 = min(ys_all), max(ys_all)
        if y1 - y0 < 1e-12:
            y1 = y0 + 1.0
        pad = (y1 - y0) * 0.05
        y0 -= pad
        y1 += pad
        span = y1 - y0

        def px(x):
            return ml + (x - x0) / (x1 - x0) * pw

        def py(y):
            return mt + ph - (y - y0) / span * ph

        for i in range(7):
            yv = y0 + span * i / 6
            yy = py(yv)
            canvas.create_line(ml, yy, ml + pw, yy, fill='#e8e8e8')
            canvas.create_text(ml - 8, yy, text=y_fmt.format(yv), anchor='e',
                               fill='#444', font=('TkDefaultFont', 8))
        for i in range(7):
            xv = x0 + (x1 - x0) * i / 6
            xx = px(xv)
            canvas.create_text(xx, mt + ph + 8, text=f'{xv:.1f}', anchor='n',
                               fill='#444', font=('TkDefaultFont', 8))
        canvas.create_line(ml, mt, ml, mt + ph, fill='#333')
        canvas.create_line(ml, mt + ph, ml + pw, mt + ph, fill='#333')
        canvas.create_text(14, mt + ph // 2, text=y_title, angle=90, fill='#333')
        canvas.create_text(ml + pw // 2, h - 12, text=x_title, fill='#333')

        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
                  '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
                  '#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00',
                  '#a65628', '#f781bf', '#999999', '#66c2a5', '#fc8d62']
        leg_x, leg_y = ml + pw - 10, mt + 10
        for idx, (label, ys) in enumerate(curves):
            color = colors[idx % len(colors)]
            pts = []
            for i, y in enumerate(ys):
                if i < len(xs) and math.isfinite(y):
                    pts += [px(xs[i]), py(y)]
            if len(pts) >= 4:
                canvas.create_line(*pts, fill=color, width=2)
            if idx < 20 and leg_y < mt + ph - 10:
                tw = 6 * len(label) + 26
                lx = leg_x - tw
                canvas.create_rectangle(lx - 4, leg_y - 2, leg_x + 4,
                                        leg_y + 12, fill='white', outline='')
                canvas.create_line(lx, leg_y + 5, lx + 16, leg_y + 5,
                                   fill=color, width=2)
                canvas.create_text(lx + 20, leg_y + 5, text=label, anchor='w',
                                   fill='#333', font=('TkDefaultFont', 8))
                leg_y += 15
        hint.set(f'已绘制 {len(curves)} 条曲线')

    def _draw_scatter_chart(self, canvas, points, hint, x_title, y_title):
        """散点图：points=[(label, x, y), ...]，正 y 绿 / 负 y 红。"""
        canvas.delete('all')
        pts = [(lab, x, y) for lab, x, y in points
               if x is not None and y is not None]
        if not pts:
            canvas.create_text(400, 240, text='暂无数据（可能尚未运行）',
                               fill='#888')
            hint.set('暂无数据')
            return
        canvas.update_idletasks()
        w = max(canvas.winfo_width(), 420)
        h = max(canvas.winfo_height(), 320)
        ml, mr, mt, mb = 62, 16, 20, 46
        pw = w - ml - mr
        ph = h - mt - mb

        xs = [p[1] for p in pts]
        ys = [p[2] for p in pts]
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        if x1 - x0 < 1e-12:
            x1 = x0 + 1.0
        if y1 - y0 < 1e-12:
            y1 = y0 + 1.0
        x0 -= (x1 - x0) * 0.06
        x1 += (x1 - x0) * 0.06
        y0 -= (y1 - y0) * 0.08
        y1 += (y1 - y0) * 0.08

        def px(x):
            return ml + (x - x0) / (x1 - x0) * pw

        def py(y):
            return mt + ph - (y - y0) / (y1 - y0) * ph

        for i in range(7):
            xv = x0 + (x1 - x0) * i / 6
            xx = px(xv)
            canvas.create_line(xx, mt, xx, mt + ph, fill='#e8e8e8')
            canvas.create_text(xx, mt + ph + 8, text=f'{xv:.2f}', anchor='n',
                               fill='#444', font=('TkDefaultFont', 8))
        for i in range(7):
            yv = y0 + (y1 - y0) * i / 6
            yy = py(yv)
            canvas.create_line(ml, yy, ml + pw, yy, fill='#e8e8e8')
            canvas.create_text(ml - 8, yy, text=f'{yv:.2f}', anchor='e',
                               fill='#444', font=('TkDefaultFont', 8))
        canvas.create_line(ml, mt, ml, mt + ph, fill='#333')
        canvas.create_line(ml, mt + ph, ml + pw, mt + ph, fill='#333')
        if y0 < 0 < y1:
            canvas.create_line(ml, py(0.0), ml + pw, py(0.0), fill='#bbb',
                               dash=(3, 3))
        canvas.create_text(14, mt + ph // 2, text=y_title, angle=90, fill='#333')
        canvas.create_text(ml + pw // 2, h - 12, text=x_title, fill='#333')

        for lab, x, y in pts:
            xx, yy = px(x), py(y)
            color = '#2ca02c' if y >= 0 else '#d62728'
            canvas.create_oval(xx - 4, yy - 4, xx + 4, yy + 4,
                               fill=color, outline='#333', width=1)
            canvas.create_text(xx, yy - 10, text=lab, anchor='s', fill='#333',
                               font=('TkDefaultFont', 7))
        hint.set(f'已绘制 {len(pts)} 个点')

    def _open_mechanism(self):
        """机制分析窗口：效应量 / 干预率 / 描述子效应 + 干预率演化曲线 + 机制散点。"""
        win = tk.Toplevel(self.root)
        win.title('机制分析（效应量 / 干预率 / 描述子 / 演化曲线 / 散点）')
        _fit_window(win, 1280, 860)
        win.transient(self.root)

        top = ttk.Frame(win, padding=6)
        top.pack(fill='x')
        suite_v = tk.StringVar(value=self.suite_var.get())
        dim_v = tk.StringVar(value=self.dims_var.get())
        func_v = tk.StringVar(value='全部')
        rate_v = tk.StringVar(value='policy')

        def mk(parent, var, vals, w):
            cb = ttk.Combobox(parent, textvariable=var, state='readonly',
                              width=w, values=vals)
            cb.pack(side='left', padx=(0, 8))
            return cb

        row1 = ttk.Frame(top)
        row1.pack(fill='x', pady=(0, 6))
        ttk.Label(row1, text='测试集').pack(side='left')
        suite_cb = mk(row1, suite_v, [SUITE_LABELS[s] for s in SUITES], 10)
        ttk.Label(row1, text='维度').pack(side='left')
        dim_cb = mk(row1, dim_v, [], 6)
        ttk.Label(row1, text='函数').pack(side='left')
        func_cb = mk(row1, func_v, [], 8)
        ttk.Label(row1, text='干预率口径').pack(side='left', padx=(6, 0))
        mk(row1, rate_v, ['policy（ρ，去探索）', 'intervention（含探索）'], 22)
        ttk.Button(row1, text='分析', command=lambda: do_plot()).pack(
            side='left', padx=8)

        mid = ttk.Frame(win)
        mid.pack(fill='both', expand=True, padx=6, pady=(0, 6))

        left = ttk.Labelframe(mid, text='算法（多选）', padding=4)
        left.pack(side='left', fill='y')
        host_list = tk.Listbox(left, selectmode='extended', width=22,
                               exportselection=False)
        host_list.pack(side='left', fill='y')
        hs = ttk.Scrollbar(left, orient='vertical', command=host_list.yview)
        hs.pack(side='right', fill='y')
        host_list.configure(yscrollcommand=hs.set)
        for h in HOSTS:
            host_list.insert('end', h)
        host_list.select_set(0, 'end')
        btns = ttk.Frame(left)
        btns.pack(fill='x')
        ttk.Button(btns, text='全选', width=6,
                   command=lambda: host_list.select_set(0, 'end')).pack(
            side='left', padx=3, pady=3)
        ttk.Button(btns, text='清空', width=6,
                   command=lambda: host_list.select_clear(0, 'end')).pack(
            side='left', padx=3)

        right = ttk.Frame(mid)
        right.pack(side='left', fill='both', expand=True, padx=(6, 0))
        nb = ttk.Notebook(right)
        nb.pack(fill='both', expand=True)

        pages = {}
        spec = (
            ('dec', '效应量 dec', 'dec（数量级）',
             '含义：dec = log10(median(err_bare)) − log10(median(err_UPCL))，'
             '即基线臂与 UPCL 臂最终误差（中位数）的对数差值，单位「数量级(decades)」。\n'
             '说明的问题：叠加型统计修正能否改善 DE。dec>0（绿）=UPCL 增益，'
             'dec<0（红）=UPCL 损失，|dec|≤0.05 视为平局。论文结论是各修正方向普遍'
             '零/负贡献——DE 的差分向量已隐式协方差引导，再叠加引导属双重计数。',
             'bar'),
            ('rate', '干预率 ρ（机制指纹）', '干预率',
             '含义：intervention_rate = UPCL 层实际修改 proposal 的比例；'
             'policy_rate(ρ) = 去掉探索尝试后、层「认为该修正」的比例（论文中的 ρ）。\n'
             '说明的问题：它不衡量好坏，而是「机制指纹」——固定参数宿主（如 DE/rand/1）'
             '干预率可达约 44%，说明宿主没有内化 proposal 级调整；SHADE 系等自适应宿主'
             '干预率趋近 0，说明它们已在内部完成同样的调整。据此可把 DE 家族沿'
             '「叠加型 → 替换型」排成一条轴。',
             'bar'),
            ('desc', '描述子效应（机制诊断）', '标准化效应',
             '含义：每个描述子的标准化效应 =（响应为正的 proposal 该分量均值 − 响应非正的'
             '均值）÷ 该分量标准差；正值表示该几何维度携带「修正是否有效」的信号。\n'
             '说明的问题：θ(方向对齐) 与 η(精英距离) 携带主要信号，ρ(步长)/κ(拥挤)/ν(新颖)'
             '贡献近零——「方向比长度重要」，且信号维度正是 SHADE 系内部已编码的量。',
             'hbar'),
            ('rhoc', '干预率演化曲线', '干预率',
             '含义：rho_curve = UPCL 层在每一代实际修改 proposal 的比例，随优化进度'
             '（0=初始，1=结束）演化；policy 口径为去掉探索尝试后的 ρ。\n'
             '说明的问题：把「干预率」从单一标量展开成动态曲线，观察层在优化各阶段'
             '（探索期/收敛期/停滞期）干预强度的消长——固定参数宿主往往全程高干预，'
             '自适应宿主一开始就低或迅速降为零，这是机制指纹在时间轴上的形态。',
             'line'),
            ('scat', '机制散点 ρ vs dec', 'dec（数量级）',
             '含义：每个点是一个算法——横轴 = 干预率 ρ（机制指纹），纵轴 = 效应量 dec'
             '（UPCL 增益/损失）。\n'
             '说明的问题：检验「干预越多是否 UPCL 越有用」。若两者负相关（干预高但 dec 仍≤0），'
             '说明宿主越「原始」UPCL 越频繁出手、却依然救不回来——佐证叠加型修正对 DE 普遍无效。',
             'scatter'),
        )
        def make_note(parent, text):
            """折叠式指标说明：默认收起，点击展开/收起，降低窗口高度占用。"""
            wrap = ttk.Frame(parent)
            wrap.pack(fill='x')
            shown = tk.BooleanVar(value=False)
            body = ttk.Label(wrap, text=text, justify='left',
                             foreground='#333', background='#f6f8fa',
                             padding=8, wraplength=880, anchor='w')

            def toggle():
                if shown.get():
                    body.pack_forget()
                    btn.configure(text='ℹ 指标说明（点击展开）')
                else:
                    body.pack(fill='x', pady=(4, 0))
                    btn.configure(text='ℹ 指标说明（点击收起）')
                shown.set(not shown.get())

            btn = ttk.Button(wrap, text='ℹ 指标说明（点击展开）',
                             command=toggle, width=22)
            btn.pack(anchor='w', pady=(2, 0))
            return wrap

        for key, title, ytitle, note, kind in spec:
            tab = ttk.Frame(nb)
            nb.add(tab, text=title)
            canvas = tk.Canvas(tab, bg='white', highlightthickness=1,
                               highlightbackground='#bbb')
            canvas.pack(fill='both', expand=True)
            hint = tk.StringVar(value='选择参数后点击「分析」')
            ttk.Label(tab, textvariable=hint, foreground='#66727f').pack(
                anchor='w', pady=(2, 0))
            make_note(tab, note)
            pages[key] = (canvas, hint, kind)

        # 第 6 个 tab：显著性检验（对全部已有数据做秩和检验，表格展示）
        tab_sig = ttk.Frame(nb)
        nb.add(tab_sig, text='显著性检验')
        sig_rows = []  # 最近一次检验结果（供导出复用）
        ttk.Label(tab_sig, justify='left', foreground='#333',
                  background='#f6f8fa', padding=8, wraplength=960, text=(
                      '对每个 cell 的两臂做 Mann-Whitney U 秩和检验（双尾）+ 配对 '
                      'Wilcoxon 符号秩检验，p<0.05 判为显著。方向 = 第二臂相对第一臂。'
                  )).pack(fill='x', padx=4, pady=(4, 0))
        sig_bar = ttk.Frame(tab_sig, padding=4)
        sig_bar.pack(fill='x')
        sig_sum = tk.StringVar(value='点击「运行检验」对全部已有数据做秩和检验')
        ttk.Label(sig_bar, textvariable=sig_sum,
                  foreground='#0a7').pack(side='left', padx=12)
        sig_cols = ('suite', 'dim', 'host', 'fid', 'arm_a', 'arm_b', 'n',
                    'p_mwu', 'p_wil', 'direction')
        sig_tree = ttk.Treeview(tab_sig, columns=sig_cols, show='headings')
        for c, txt, wd in (('suite', '测试集', 70), ('dim', '维度', 50),
                           ('host', '算法', 150), ('fid', '函数', 60),
                           ('arm_a', '臂A', 60), ('arm_b', '臂B', 60),
                           ('n', 'n', 50), ('p_mwu', 'p(M-W U)', 90),
                           ('p_wil', 'p(Wilcoxon)', 100),
                           ('direction', '方向', 120)):
            sig_tree.heading(c, text=txt)
            sig_tree.column(c, width=wd, anchor='w')
        sig_tree.pack(fill='both', expand=True, padx=4, pady=4)

        prog_bar = ttk.Frame(tab_sig, padding=(4, 0))
        prog_bar.pack(fill='x', pady=(0, 4))
        sig_progress = ttk.Progressbar(prog_bar, mode='determinate', maximum=100)
        sig_progress.pack(side='left', fill='x', expand=True)
        sig_prog_label = tk.StringVar(value='就绪')
        ttk.Label(prog_bar, textvariable=sig_prog_label, width=30).pack(
            side='left', padx=(8, 0))

        def _fmt_p(v):
            return '—' if v != v else f'{v:.3g}'

        def _update_prog(i, total):
            sig_progress.configure(value=100.0 * i / max(total, 1))
            sig_prog_label.set(f'正在检验 {i}/{total}…')

        def run_sig():
            if run_btn['state'] == 'disabled':
                return
            run_btn['state'] = 'disabled'
            export_btn['state'] = 'disabled'
            sig_progress.configure(value=0, maximum=100)
            sig_prog_label.set('准备检验…')
            for i in sig_tree.get_children():
                sig_tree.delete(i)
            sig_rows.clear()
            prog_q = queue.Queue()

            def _poll_prog():
                if not win.winfo_exists():
                    return
                try:
                    while True:
                        item = prog_q.get_nowait()
                        if item[0] == 'progress':
                            _update_prog(item[1], item[2])
                        else:
                            _finish(item[1])
                            return
                except queue.Empty:
                    pass
                self.root.after(80, _poll_prog)

            def _finish(rows):
                run_btn['state'] = 'normal'
                export_btn['state'] = 'normal'
                if rows is None:
                    sig_progress.configure(value=0)
                    sig_prog_label.set('无数据')
                    return
                sig_rows.extend(rows)
                sig_progress.configure(value=100)
                sig_prog_label.set(f'完成 {len(rows)} cell')
                for r in sorted(rows, key=lambda x: (str(x['suite']),
                                                     str(x['dim']),
                                                     str(x['host']),
                                                     str(x['fid']))):
                    sig_tree.insert('', 'end', values=(
                        r['suite'], r['dim'], r['host'], r['fid'],
                        r['arm_a'], r['arm_b'], r['n'],
                        _fmt_p(r['p_mwu']), _fmt_p(r['p_wil']),
                        r['direction']))
                better = sum(1 for r in rows if r['significant'] and
                             r['mean_log10_b'] < r['mean_log10_a'])
                worse = sum(1 for r in rows if r['significant'] and
                            r['mean_log10_b'] > r['mean_log10_a'])
                ns = sum(1 for r in rows if not r['significant'])
                sig_sum.set(f'共 {len(rows)} cell：显著更好 {better}，'
                            f'显著更差 {worse}，无显著差异 {ns}')

            def worker():
                last_pct = [-1]

                def cb(i, t):
                    pct = int(100.0 * i / max(t, 1))
                    if pct != last_pct[0]:
                        last_pct[0] = pct
                        prog_q.put(('progress', i, t))

                rows = self._compute_rank_test(progress_cb=cb)
                prog_q.put(('done', rows))

            threading.Thread(target=worker, daemon=True).start()
            self.root.after(80, _poll_prog)

        def export_sig():
            if not sig_rows:
                messagebox.showinfo('显著性检验', '请先点击「运行检验」')
                return
            path = self._export_rank_csv(list(sig_rows))
            if path:
                messagebox.showinfo('显著性检验', f'已导出到:\n{path}')

        run_btn = ttk.Button(sig_bar, text='运行检验', command=run_sig)
        run_btn.pack(side='left')
        export_btn = ttk.Button(sig_bar, text='导出 CSV', command=export_sig)
        export_btn.pack(side='left', padx=4)

        def refresh_funcs():
            s = SUITE_KEY.get(suite_v.get())
            if not s or not dim_v.get():
                return
            labels = ['全部'] + [f'F{i}' for i in
                                 range(1, SUITE_NFUNCS.get(s, 0) + 1)]
            func_cb['values'] = labels
            if func_v.get() not in labels:
                func_v.set('全部')

        def refresh_dims():
            s = SUITE_KEY.get(suite_v.get())
            if not s:
                return
            dims = [str(d) for d in SUITE_LEGAL_DIMS[s]]
            dim_cb['values'] = dims
            if dim_v.get() not in dims:
                dim_v.set(dims[0])
            refresh_funcs()

        def do_plot():
            s = SUITE_KEY.get(suite_v.get())
            try:
                d = int(dim_v.get())
            except (tk.TclError, ValueError):
                return
            hosts = [host_list.get(i) for i in host_list.curselection()]
            if not hosts:
                return
            nf = SUITE_NFUNCS.get(s, 0)
            if func_v.get() == '全部':
                fids = list(range(1, nf + 1))
            else:
                try:
                    fids = [int(func_v.get().lstrip('F'))]
                except ValueError:
                    return
            cells = self._collect_mechanism(s, d, fids, hosts)
            if not cells:
                for c, h, kind in pages.values():
                    if kind == 'bar':
                        self._draw_bar_chart(c, [], [], '', h)
                    elif kind == 'hbar':
                        self._draw_hbar_chart(c, [], [], '', h)
                    elif kind == 'line':
                        self._draw_line_chart(c, [], [], h, '', '')
                    else:
                        self._draw_scatter_chart(c, [], h, '', '')
                return
            use_policy = rate_v.get().startswith('policy')

            # 每 host 跨函数聚合：dec、干预率（host 顺序保持一致）
            dec_by_host = {}
            rate_by_host = {}
            for c in cells:
                dec_by_host.setdefault(c['host'], []).append(c['dec'])
                rv = c['policy_rate'] if use_policy else c['intervention_rate']
                if rv is not None:
                    rate_by_host.setdefault(c['host'], []).append(rv)
            host_order = sorted(dec_by_host)
            dec_vals = [median(dec_by_host[h]) for h in host_order]
            rate_vals = [median(rate_by_host[h]) if rate_by_host.get(h)
                         else None for h in host_order]

            # 描述子效应（跨 host × 函数中位数，5 个描述子横向柱）
            desc_agg = {name: [] for name, _ in DESC_NAMES}
            for c in cells:
                for name, _lab in DESC_NAMES:
                    v = c['desc'].get(name)
                    if v is not None:
                        desc_agg[name].append(v)
            desc_labels = [name for name, _ in DESC_NAMES]
            desc_vals = [median(desc_agg[name]) if desc_agg[name] else None
                         for name in desc_labels]

            # 干预率演化曲线（每 host 一条，跨函数取中位数，重采样到 50 点）
            rho_by_host = {}
            for c in cells:
                curve = (c['rho_policy_curve'] if use_policy
                         else c['rho_curve'])
                if curve:
                    rho_by_host.setdefault(c['host'], []).append(curve)
            xs = [i / (RHO_CURVE_PTS - 1) for i in range(RHO_CURVE_PTS)]
            curves = []
            for h in host_order:
                if h in rho_by_host:
                    med = [median(col) for col in zip(*rho_by_host[h])]
                    curves.append((h, med))
            self._draw_line_chart(pages['rhoc'][0], xs, curves,
                                  pages['rhoc'][1], '干预率',
                                  '优化进度（0=初始，1=结束）')

            # 机制散点：x=干预率 ρ，y=效应量 dec
            points = [(h, median(rate_by_host[h]) if rate_by_host.get(h)
                       else None, median(dec_by_host[h])) for h in host_order]
            self._draw_scatter_chart(pages['scat'][0], points, pages['scat'][1],
                                     '干预率 ρ', '效应量 dec')

            # 柱状图（排序）+ 横向柱状图
            self._draw_bar_chart(pages['dec'][0], host_order, dec_vals,
                                 'dec（数量级）', pages['dec'][1],
                                 sort_desc=True)
            self._draw_bar_chart(pages['rate'][0], host_order, rate_vals,
                                 '干预率', pages['rate'][1], sort_desc=True)
            self._draw_hbar_chart(pages['desc'][0], desc_labels, desc_vals,
                                  '标准化效应', pages['desc'][1])

        suite_cb.bind('<<ComboboxSelected>>', lambda e: refresh_dims())
        dim_cb.bind('<<ComboboxSelected>>', lambda e: refresh_funcs())
        refresh_dims()

    # --------------------------------------------------------------- 秩和检验
    def _compute_rank_test(self, progress_cb=None):
        """对 results/cec/raw 里每个 cell 的两臂做秩和检验，返回 rows 列表。

        主检验 = Mann-Whitney U（独立样本秩和检验，双尾），并附带配对
        Wilcoxon 符号秩检验（bare/upcl 或 bare/full 同 seed 配对）。判断
        第二臂相对第一臂是否统计显著（p<0.05）。无数据/缺依赖时返回 None。

        progress_cb(idx, total)：可选进度回调，每处理一个 json 调用一次
        （idx 从 0 起，total 为 json 总数），供进度条实时刷新。
        """
        try:
            from scipy import stats
        except Exception as e:
            messagebox.showerror('缺少依赖',
                                 f'无法加载 scipy：{e}\n请重新下载完整版程序。')
            return None
        if not RAW.exists():
            messagebox.showinfo('显著性检验',
                                '暂无结果数据\n(results/cec/raw 目录不存在)')
            return None
        files = sorted(RAW.rglob('*.json'))
        if not files:
            messagebox.showinfo('显著性检验',
                                '暂无结果数据\n(results/cec/raw 目录为空)')
            return None

        total = len(files)
        rows = []
        for idx, p in enumerate(files):
            if progress_cb is not None:
                progress_cb(idx, total)
            try:
                with open(p, 'r', encoding='utf-8') as fh:
                    d = json.load(fh)
            except Exception:
                continue
            arms = {}
            for r in d.get('runs', []) or []:
                for k, v in r.items():
                    if k in ('run', 'seed') or not isinstance(v, dict):
                        continue
                    if 'err_final' not in v:
                        continue
                    arms.setdefault(k, []).append(float(v['err_final']))
            keys = sorted(arms)
            if len(keys) < 2:
                continue
            a, b = keys[0], keys[1]
            xa, xb = arms[a], arms[b]
            if len(xa) < 2 or len(xb) < 2:
                continue
            try:
                _, p_mwu = stats.mannwhitneyu(xa, xb, alternative='two-sided')
            except Exception:
                p_mwu = float('nan')
            n = min(len(xa), len(xb))
            try:
                _, p_wil = stats.wilcoxon(xa[:n], xb[:n])
            except Exception:
                p_wil = float('nan')
            sig = (p_mwu < 0.05)
            loga = [math.log10(max(x, 1e-300)) for x in xa]
            logb = [math.log10(max(x, 1e-300)) for x in xb]
            diff = median(logb) - median(loga)
            if sig:
                direction = f'{b} 更好' if diff < 0 else f'{b} 更差'
            else:
                direction = '无显著差异'
            rows.append(dict(
                suite=d.get('suite', ''), dim=d.get('dim', ''),
                host=d.get('host', ''), fid=d.get('fid', ''),
                func=d.get('func', ''), category=d.get('category', ''),
                arm_a=a, arm_b=b, n=len(xa),
                p_mwu=p_mwu, p_wil=p_wil, significant=sig,
                direction=direction,
                mean_log10_a=mean(loga), mean_log10_b=mean(logb)))
        return rows

    def _export_rank_csv(self, rows):
        """把显著性检验 rows 导出为 CSV，返回保存路径（取消返回 None）。"""
        better = sum(1 for r in rows
                     if r['significant'] and r['mean_log10_b'] < r['mean_log10_a'])
        worse = sum(1 for r in rows
                    if r['significant'] and r['mean_log10_b'] > r['mean_log10_a'])
        ns = sum(1 for r in rows if not r['significant'])
        default_name = f'显著性检验_{time.strftime("%Y%m%d_%H%M%S")}.csv'
        path = filedialog.asksaveasfilename(
            title='导出显著性检验结果', defaultextension='.csv',
            initialfile=default_name, initialdir=str(ROOT),
            filetypes=[('CSV 表格', '*.csv'), ('所有文件', '*.*')])
        if not path:
            return None
        header = ['suite', 'dim', 'host', 'fid', 'func', 'category',
                  'arm_a', 'arm_b', 'n', 'p_mannwhitneyu', 'p_wilcoxon',
                  'significant', 'direction', 'mean_log10_a', 'mean_log10_b']
        with open(path, 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.writer(fh)
            w.writerow(header)
            for r in sorted(rows, key=lambda x: (str(x['suite']), str(x['dim']),
                                                 str(x['host']), str(x['fid']))):
                w.writerow([r['suite'], r['dim'], r['host'], r['fid'],
                            r['func'], r['category'], r['arm_a'], r['arm_b'],
                            r['n'], r['p_mwu'], r['p_wil'],
                            r['significant'], r['direction'],
                            r['mean_log10_a'], r['mean_log10_b']])
        self._append_log(
            f'[gui] 显著性检验完成：显著更好 {better}，显著更差 {worse}，'
            f'无显著差异 {ns}（共 {len(rows)} 个 cell）\n')
        return path

    # --------------------------------------------------------------- 数据存档
    @staticmethod
    def _read_cell_meta(path):
        """只读 json 头部若干字节，提取 runs_complete 与 arms，避免解析大数组。"""
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                head = fh.read(8192)
        except Exception:
            return None, set()
        m = re.search(r'"runs_complete"\s*:\s*(\d+)', head)
        rc = int(m.group(1)) if m else 0
        m = re.search(r'"arms"\s*:\s*\[([^\]]*)\]', head)
        arms = set(re.findall(r'"([a-zA-Z]+)"', m.group(1))) if m else set()
        return rc, arms

    def _scan_archive(self):
        """扫描 results/cec/raw，统计每个 suite/dim 的 cell 状态。

        返回 (summary, cells)：
        - summary: 每 suite/dim 一行汇总（完整/缺臂/臂异/R5/其他/缺失 计数）
        - cells: {(suite, dim): [[host, fid, runs, arms, 状态], ...]}
        """
        summary = []
        cells = {}
        for suite in ARCHIVE_SUITES:
            fids = SUITE_FIDS.get(suite, [])
            if not fids:
                continue
            for dim in SUITE_LEGAL_DIMS.get(suite, []):
                ddir = RAW / suite / f'D{dim}'
                states = {'完整': 0, '缺臂': 0, '臂异': 0,
                          'R5': 0, '其他': 0, '缺失': 0}
                rows = []
                total = len(HOSTS) * len(fids)
                for host in HOSTS:
                    expected = ({'bare', 'full'} if host in WAVE4_HOSTS
                                else {'bare', 'upcl'})
                    for fid in fids:
                        p = ddir / f'{host.replace("/", "-")}__F{fid}.json'
                        if not p.exists():
                            states['缺失'] += 1
                            rows.append([host, fid, '', '', '缺失'])
                            continue
                        rc, arms = self._read_cell_meta(p)
                        if rc is None:
                            states['缺失'] += 1
                            rows.append([host, fid, '?', '', '损坏'])
                            continue
                        if rc >= 30:
                            if arms == expected:
                                st = '完整'
                            elif arms == {'bare'}:
                                st = '缺臂'
                            else:
                                st = '臂异'
                        elif rc == 5:
                            st = 'R5'
                        else:
                            st = '其他'
                        states[st] += 1
                        rows.append([host, fid, rc,
                                     ','.join(sorted(arms)), st])
                done = total - states['缺失']
                if done == 0:  # 完全无数据（一个 json 都没有）的维度不展示
                    continue
                summary.append({
                    'suite': suite, 'dim': dim, 'total': total,
                    'done': done, 'pct': done / total if total else 0.0,
                    **states})
                cells[(suite, dim)] = rows
        return summary, cells

    def _open_archive(self):
        """数据存档窗口：进度总览 + cell 明细 + 分析表格/图片清单。"""
        win = tk.Toplevel(self.root)
        win.title('数据存档')
        _fit_window(win, 1180, 760)
        win.transient(self.root)
        ttk.Label(win, justify='left', foreground='#555', padding=(6, 6, 6, 0),
                  text=('实验数据存档（results/cec/raw）：完整 = 30 runs 且臂类型正确；'
                        '缺臂 = 30 runs 仅 bare；臂异 = 臂类型不符；R5 = 5-runs 残留；'
                        '其他 = 中间 runs；缺失 = 无数据文件')).pack(anchor='w')
        (self._archive_ov, self._archive_det, self._archive_tab,
         self._archive_fig, self._archive_info) = self._build_archive_ui(win)
        self._archive_ov.bind('<<TreeviewSelect>>', self._on_archive_select)
        self._archive_tab.bind('<Double-Button-1>',
                               lambda e: self._archive_view_table())
        self._archive_fig.bind('<Double-Button-1>',
                               lambda e: self._archive_open_fig())
        self._populate_archive()

    def _on_archive_select(self, _e=None):
        sel = self._archive_ov.selection()
        if not sel:
            return
        suite, dim_s = sel[0].split('|')
        det = self._archive_det
        det.delete(*det.get_children())
        for row in self._archive_cells.get((suite, int(dim_s)), []):
            det.insert('', 'end', values=row, tags=(row[4],))

    def _archive_view_table(self):
        sel = self._archive_tab.curselection()
        if sel:
            p = TABLES_DIR / self._archive_tab.get(sel[0])
            if p.exists():
                self._view_csv(p)

    def _archive_open_fig(self):
        sel = self._archive_fig.curselection()
        if sel:
            p = FIGURES_DIR / self._archive_fig.get(sel[0])
            if p.exists():
                self._open_file(p)

    def _build_archive_ui(self, win):
        """构建数据存档窗口控件，返回 (ov, det, tab_list, fig_list, info)。"""
        fov = ttk.Labelframe(win, text='进度总览（测试集 × 维度）', padding=4)
        fov.pack(fill='x', padx=6, pady=4)
        ov = ttk.Treeview(fov, columns=('sd', 'total', 'done', 'full', 'bare',
                                        'wrong', 'r5', 'other', 'missing', 'pct'),
                          show='headings', height=5)
        for c, t, w in (('sd', '测试集/维度', 130), ('total', '总cell', 60),
                        ('done', '已有', 60), ('full', '完整', 60),
                        ('bare', '缺臂', 60), ('wrong', '臂异', 60),
                        ('r5', 'R5', 50), ('other', '其他', 50),
                        ('missing', '缺失', 60), ('pct', '完成率', 80)):
            ov.heading(c, text=t)
            ov.column(c, width=w, anchor='center')
        ov.pack(side='left', fill='x', expand=True)
        ovs = ttk.Scrollbar(fov, orient='vertical', command=ov.yview)
        ovs.pack(side='right', fill='y')
        ov.configure(yscrollcommand=ovs.set)

        main = ttk.Frame(win)
        main.pack(fill='both', expand=True, padx=6, pady=4)
        fde = ttk.Labelframe(main, text='cell 明细（点击上方总览行切换）', padding=4)
        fde.pack(side='left', fill='both', expand=True)
        det = ttk.Treeview(fde, columns=('host', 'fid', 'runs', 'arms', 'state'),
                           show='headings', height=20)
        for c, t, w, a in (('host', '算法', 190, 'w'), ('fid', '函数', 70, 'center'),
                           ('runs', 'runs', 70, 'center'), ('arms', '臂', 90, 'w'),
                           ('state', '状态', 70, 'center')):
            det.heading(c, text=t)
            det.column(c, width=w, anchor=a)
        det.pack(side='left', fill='both', expand=True)
        des = ttk.Scrollbar(fde, orient='vertical', command=det.yview)
        des.pack(side='right', fill='y')
        det.configure(yscrollcommand=des.set)
        for tag, col in (('完整', '#0a7'), ('缺臂', '#d60'), ('臂异', '#90c'),
                         ('R5', '#888'), ('其他', '#888'), ('缺失', '#c33'),
                         ('损坏', '#c33')):
            det.tag_configure(tag, foreground=col)

        nb = ttk.Notebook(main, width=360)
        nb.pack(side='right', fill='both', padx=(6, 0))
        t_tab = ttk.Frame(nb)
        nb.add(t_tab, text='分析表格')
        tab_list = tk.Listbox(t_tab, exportselection=False, width=42)
        tab_list.pack(side='left', fill='both', expand=True)
        tbs = ttk.Scrollbar(t_tab, orient='vertical', command=tab_list.yview)
        tbs.pack(side='right', fill='y')
        tab_list.configure(yscrollcommand=tbs.set)
        f_tab = ttk.Frame(nb)
        nb.add(f_tab, text='分析图片')
        fig_list = tk.Listbox(f_tab, exportselection=False, width=42)
        fig_list.pack(side='left', fill='both', expand=True)
        fbs = ttk.Scrollbar(f_tab, orient='vertical', command=fig_list.yview)
        fbs.pack(side='right', fill='y')
        fig_list.configure(yscrollcommand=fbs.set)

        bottom = ttk.Frame(win, padding=(6, 0, 6, 6))
        bottom.pack(fill='x')
        ttk.Button(bottom, text='刷新', command=self._populate_archive).pack(
            side='left')
        info = tk.StringVar(value='')
        ttk.Label(bottom, textvariable=info, foreground='#555').pack(
            side='left', padx=10)
        ttk.Button(bottom, text='打开所选图片',
                   command=self._archive_open_fig).pack(side='right', padx=4)
        ttk.Button(bottom, text='查看所选表格',
                   command=self._archive_view_table).pack(side='right', padx=4)
        return ov, det, tab_list, fig_list, info

    def _populate_archive(self):
        summary, cells = self._scan_archive()
        self._archive_cells = cells
        ov = self._archive_ov
        ov.delete(*ov.get_children())
        for r in summary:
            ov.insert('', 'end', iid=f"{r['suite']}|{r['dim']}", values=(
                f"{r['suite']} D{r['dim']}", r['total'], r['done'],
                r['完整'], r['缺臂'], r['臂异'], r['R5'], r['其他'],
                r['缺失'], f"{r['pct'] * 100:.1f}%"))
        tab_list, fig_list = self._archive_tab, self._archive_fig
        tab_list.delete(0, 'end')
        for p in (sorted(TABLES_DIR.glob('*.csv')) if TABLES_DIR.is_dir()
                  else []):
            tab_list.insert('end', p.name)
        fig_list.delete(0, 'end')
        for p in (sorted(FIGURES_DIR.glob('*.png')) if FIGURES_DIR.is_dir()
                  else []):
            fig_list.insert('end', p.name)
        n_json = sum(1 for _ in RAW.rglob('*.json')) if RAW.is_dir() else 0
        self._archive_info.set(f'共 {n_json} 个 json · {tab_list.size()} 个表格 · '
                               f'{fig_list.size()} 张图片')
        if ov.get_children():
            ov.selection_set(ov.get_children()[0])
            self._on_archive_select()

    def _view_csv(self, path):
        try:
            with open(path, 'r', encoding='utf-8-sig',
                      errors='replace') as fh:
                rows = list(csv.reader(fh))
        except Exception as e:
            messagebox.showerror('查看表格', f'无法读取：{e}')
            return
        if not rows:
            messagebox.showinfo('查看表格', '空文件')
            return
        win = tk.Toplevel(self.root)
        win.title(f'表格：{path.name}')
        _fit_window(win, 940, 560)
        win.transient(self.root)
        top = ttk.Frame(win, padding=4)
        top.pack(fill='x')
        ttk.Label(top, text=f'{path}（{len(rows) - 1} 行）',
                  foreground='#555').pack(anchor='w')
        body = ttk.Frame(win)
        body.pack(fill='both', expand=True)
        tv = ttk.Treeview(body, show='headings')
        tv.pack(side='left', fill='both', expand=True)
        vs = ttk.Scrollbar(body, orient='vertical', command=tv.yview)
        vs.pack(side='right', fill='y')
        tv.configure(yscrollcommand=vs.set)
        hs = ttk.Scrollbar(body, orient='horizontal', command=tv.xview)
        hs.pack(side='bottom', fill='x')
        tv.configure(xscrollcommand=hs.set)
        header = rows[0]
        ncol = len(header)
        tv['columns'] = [f'c{i}' for i in range(ncol)]
        for i, h in enumerate(header):
            tv.heading(f'c{i}', text=h)
            tv.column(f'c{i}', width=110, anchor='w')
        for r in rows[1:]:
            tv.insert('', 'end', values=(r + [''] * ncol)[:ncol])

    def _open_file(self, path):
        try:
            os.startfile(str(path))
        except Exception as e:
            messagebox.showerror('打开文件', f'无法打开：{e}')

    def _on_close(self):
        if self.running and self.proc is not None:
            if messagebox.askyesno('退出', '实验仍在运行，是否优雅停止后退出？'):
                self.stop_flag = True
                try:
                    STOP_FILE.parent.mkdir(parents=True, exist_ok=True)
                    STOP_FILE.write_text('stop', encoding='utf-8')
                except Exception:
                    pass
        self.root.destroy()


def main():
    if getattr(sys, 'frozen', False) and '--run-experiment' in sys.argv:
        _experiment_cli()
        return
    _enable_dpi_awareness()
    root = tk.Tk()
    _setup_theme(root)
    LauncherApp(root)
    root.mainloop()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    main()

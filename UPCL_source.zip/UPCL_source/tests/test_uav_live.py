"""Progress/resume checks with a fake optimizer; no UAV experiment is run."""
import contextlib
import io
import json
import queue
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import run_uav as runner
from uav_progress import LiveProgress, ProgressState


class UAVLiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.task = runner.build_tasks('intercept', 30, ['SHADE'], [1], 30,
                                       [('bare', None), ('full', 'default')], 500)[0]
        self.task.update(out_dir=self.tmp.name, code_stack='legacy-20261011')
        self.events = queue.Queue()
        runner._init_progress(self.events, 0.01)
        self.addCleanup(runner._init_progress, None, 2.0)

    def fake_arm(self, host, func, dim, seed, budget, cfg, **kwargs):
        if kwargs.get('progress_cb'):
            kwargs['progress_cb'](budget // 2, 1)
        return dict(seed=seed, max_evals=budget, nevals=budget, err_final=0.0)

    def run_fake(self, fail=None):
        with patch.object(runner, '_make_problem', return_value=SimpleNamespace(
                name='fake', category='application')), patch.object(
                    runner.RUC, 'run_arm', side_effect=fail or self.fake_arm):
            return runner.run_task(self.task)

    def read_result(self):
        return json.loads(runner.result_path(self.task).read_text(encoding='utf8'))

    def write_result(self, data):
        runner.result_path(self.task).write_text(json.dumps(data), encoding='utf8')

    def drain(self, state):
        while not self.events.empty():
            state.apply(self.events.get_nowait())

    def test_resume_three_to_thirty_preserves_saved_runs(self):
        self.task['runs'] = 3
        self.assertEqual(self.run_fake()[0], 'done')
        original = self.read_result()['runs']
        self.task['runs'] = 30
        state = ProgressState([self.task], {('SHADE', 1): {0, 1, 2}})
        self.drain(state)
        calls = []

        def recorded(*args, **kwargs):
            calls.append(args[3])
            return self.fake_arm(*args, **kwargs)

        self.assertEqual(self.run_fake(recorded)[0], 'done')
        data = self.read_result()
        self.assertEqual(data['runs_complete'], 30)
        self.assertEqual(data['runs'][:3], original)
        self.assertEqual(len(calls), 27 * 2)
        self.assertEqual(calls[0], runner.seed_for(self.task, 3))
        self.drain(state)
        self.assertEqual(state.completed, 30)
        self.assertFalse(state.active)
        self.assertIn('+27/27', state.render(100))
        self.assertIn('100.00%', state.render(100))

    def test_failed_second_arm_keeps_last_complete_pair(self):
        self.task['runs'] = 1
        self.run_fake()
        before = runner.result_path(self.task).read_bytes()
        self.task['runs'] = 2

        def fail_full(*args, **kwargs):
            if args[5] is not None:
                raise RuntimeError('fake full-arm failure')
            return self.fake_arm(*args, **kwargs)

        self.assertEqual(self.run_fake(fail_full)[0], 'error')
        self.assertEqual(runner.result_path(self.task).read_bytes(), before)
        self.assertEqual(self.run_fake()[0], 'done')
        self.assertEqual(self.read_result()['runs_complete'], 2)

    def test_incompatible_budget_is_rejected_without_writing(self):
        self.task['runs'] = 1
        self.run_fake()
        before = runner.result_path(self.task).read_bytes()
        self.task.update(runs=30, fes_mult=10000)
        self.assertEqual(self.run_fake()[0], 'error')
        self.assertEqual(runner.result_path(self.task).read_bytes(), before)

    def test_run_ids_must_cover_target_instead_of_just_matching_count(self):
        self.task['runs'] = 3
        self.run_fake()
        data = self.read_result()
        data['runs'] = data['runs'][1:]
        data['runs_complete'] = 2
        self.write_result(data)
        self.task['runs'] = 2  # Saved ids 1,2; run 0 must still be filled.
        self.assertEqual(self.run_fake()[0], 'done')
        self.assertEqual([e['run'] for e in self.read_result()['runs']], [0, 1, 2])

    def test_plan_never_calls_optimizer_or_creates_results(self):
        with patch.object(runner.RUC, 'run_arm') as arm, contextlib.redirect_stdout(io.StringIO()):
            result = runner.main(['--plan', '--runs', '30', '--hosts', 'SHADE',
                                  '--fids', '1', '--out-dir', self.tmp.name,
                                  '--evals-mult', '500'])
        self.assertEqual(result, 0)
        arm.assert_not_called()
        self.assertEqual(list(Path(self.tmp.name).iterdir()), [])

    def test_progress_does_not_count_unsaved_arm_and_eta_ignores_baseline(self):
        state = ProgressState([self.task], {('SHADE', 1): {0, 1, 2}})
        state.apply(dict(key=('SHADE', 1), kind='progress', run=3, arm='bare',
                         arm_idx=0, nevals=7500, generation=10))
        text = state.render(60)
        self.assertIn('saved paired runs 3/30', text)
        self.assertIn('waiting for first new run', text)
        self.assertIn('50.0%', text)
        state.apply(dict(key=('SHADE', 1), kind='saved', run=3))
        text = state.render(60)
        self.assertIn('+1/27', text)
        self.assertIn('ETA 00:26:00', text)

    def test_force_flag_reaches_tasks(self):
        with patch.object(runner, '_run_serial', return_value=iter([])) as run, contextlib.redirect_stdout(io.StringIO()):
            runner.main(['--force', '--hosts', 'SHADE', '--fids', '1',
                         '--out-dir', self.tmp.name])
        self.assertTrue(run.call_args.args[0][0]['force'])

    def test_failed_cells_produce_nonzero_exit_status(self):
        with patch.object(runner, '_run_serial', return_value=iter([('error', 'fake error')])), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            result = runner.main(['--hosts', 'SHADE', '--fids', '1',
                                  '--out-dir', self.tmp.name])
        self.assertEqual(result, 1)

    def test_display_drains_events_and_writes_final_log(self):
        self.task['runs'] = 1
        for event in [dict(kind='start'), dict(kind='saved', run=0), dict(kind='done')]:
            self.events.put(dict(key=('SHADE', 1), **event))
        log = Path(self.tmp.name) / 'progress.log'
        with contextlib.redirect_stdout(io.StringIO()):
            display = LiveProgress(self.events, [self.task], {('SHADE', 1): set()},
                                   0.01, log, plain=True)
            display.start()
            display.finish()
        self.assertEqual(display.state.completed, 1)
        self.assertFalse(display.thread.is_alive())
        self.assertIn('100.00%', log.read_text(encoding='utf8'))
        self.assertIn("'kind': 'saved'", log.read_text(encoding='utf8'))


if __name__ == '__main__':
    unittest.main()

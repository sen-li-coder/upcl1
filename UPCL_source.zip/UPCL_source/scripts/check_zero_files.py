#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""磁盘文件完整性体检：找出「长度看着正常、内容却全是 0」的空壳文件，
以及扩展名与文件头签名不符的文件（例如复制中断、云盘占位未下载）。

用法：
    python scripts/check_zero_files.py E:\\新建文件夹
    python scripts/check_zero_files.py D:\\photos --ext .jpg .png --min-size 1
    python scripts/check_zero_files.py E:\\LASE --json reports/zero_scan.json

判据：
    1) 全零：文件大小 > 0 且所有字节均为 0x00（典型的「长度已分配、数据未落盘」）；
    2) 签名不符：.jpg/.png/.pdf/.zip… 的文件头与格式签名不匹配（全零文件通常也命中此条，
       这里只对非全零文件单独报告，避免重复）。
退出码：发现问题返回 1，全部正常返回 0，便于接到批处理或 CI 里。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# 扩展名 -> 文件头签名（tuple 表示 (偏移, 字节)）
SIGS = {
    '.jpg': (0, b'\xff\xd8\xff'),
    '.jpeg': (0, b'\xff\xd8\xff'),
    '.png': (0, b'\x89PNG\r\n\x1a\n'),
    '.gif': (0, b'GIF8'),
    '.bmp': (0, b'BM'),
    '.webp': (0, b'RIFF'),
    '.pdf': (0, b'%PDF-'),
    '.zip': (0, b'PK\x03\x04'),
    '.docx': (0, b'PK\x03\x04'),
    '.xlsx': (0, b'PK\x03\x04'),
    '.pptx': (0, b'PK\x03\x04'),
    '.7z': (0, b'7z\xbc\xaf\x27\x1c'),
    '.rar': (0, b'Rar!'),
    '.mp4': (4, b'ftyp'),
    '.mov': (4, b'ftyp'),
}

SKIP_DIRS = {'.git', '__pycache__', 'node_modules', '.idea', '.vscode'}
CHUNK = 1 << 20  # 1 MiB


def is_all_zero(path: Path) -> bool:
    """分块判断文件是否全零，不在内存里整份载入。"""
    with path.open('rb') as fh:
        while True:
            buf = fh.read(CHUNK)
            if not buf:
                return True
            if buf.count(0) != len(buf):
                return False


def head_bytes(path: Path, n: int = 16) -> bytes:
    with path.open('rb') as fh:
        return fh.read(n)


def sig_ok(path: Path) -> bool:
    """扩展名在白名单内就校验文件头，否则一律视为通过。"""
    spec = SIGS.get(path.suffix.lower())
    if spec is None:
        return True
    off, sig = spec
    return head_bytes(path, off + len(sig))[off:off + len(sig)] == sig


def scan(root: Path, exts: set[str], min_size: int):
    zero, mismatch, ok = [], [], 0
    for p in root.rglob('*'):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        try:
            size = p.stat().st_size
        except OSError:
            continue
        if size < min_size:
            continue
        if exts and p.suffix.lower() not in exts:
            continue
        try:
            if is_all_zero(p):
                zero.append((p, size))
                continue
            if not sig_ok(p):
                mismatch.append((p, size))
                continue
        except OSError as exc:      # 权限、占用、坏道等
            mismatch.append((p, size, str(exc)))
            continue
        ok += 1
    return zero, mismatch, ok


def main() -> int:
    ap = argparse.ArgumentParser(description='扫描全零空壳与文件头不符的文件')
    ap.add_argument('roots', nargs='*', default=['.'], help='待扫描目录，默认当前目录')
    ap.add_argument('--ext', nargs='*', default=[], help='只查这些扩展名，如 .jpg .png')
    ap.add_argument('--min-size', type=int, default=0, help='小于该字节数的文件跳过，默认 0')
    ap.add_argument('--json', default='', help='把结果写成 JSON 报告到该路径')
    args = ap.parse_args()

    exts = {e if e.startswith('.') else '.' + e for e in (x.lower() for x in args.ext)}
    report = {'roots': [], 'zero': [], 'mismatch': [], 'ok': 0}

    for r in args.roots:
        root = Path(r).expanduser()
        if not root.exists():
            print(f'跳过（不存在）：{root}')
            continue
        print(f'扫描：{root.resolve()}')
        zero, mismatch, ok = scan(root, exts, args.min_size)
        report['roots'].append(str(root.resolve()))
        report['ok'] += ok
        report['zero'] += [{'path': str(p), 'size': s} for p, s in zero]
        report['mismatch'] += [
            {'path': str(x[0]), 'size': x[1], **({'error': x[2]} if len(x) > 2 else {})}
            for x in mismatch
        ]
        print(f'  正常 {ok} 个')

    z, m = report['zero'], report['mismatch']
    if z:
        print(f'\n[全零空壳] {len(z)} 个 —— 长度正常但内容全是 0，打开会报「文件已损坏」')
        for it in z:
            print(f'  {it["size"]:>12,d} B  {it["path"]}')
    if m:
        print(f'\n[文件头不符] {len(m)} 个 —— 扩展名与实际格式不一致，或被截断')
        for it in m:
            extra = f'  ({it["error"]})' if it.get('error') else ''
            print(f'  {it["size"]:>12,d} B  {it["path"]}{extra}')
    if not z and not m:
        print('\n未发现异常文件。')

    if args.json:
        out = Path(args.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f'\n报告已写入 {out}')

    return 1 if (z or m) else 0


if __name__ == '__main__':
    sys.exit(main())

@echo off
cd /d e:\LASE
echo [resume] cec2017 D30 at %date% %time%
python -u src\run_upcl_cec.py --stage main --suites cec2017 --dims 30 --hosts jDE100 j2020 DISH DISK LSHADE-cnEpSin SinDE IMODE PaDE SHADE-ILS --runs 30 --workers 19 --no-upcl >> results\cec\logs\wave4_full_cec2017.log 2>&1
echo [resume] cec2017 DONE at %date% %time%

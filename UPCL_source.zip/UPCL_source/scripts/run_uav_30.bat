@echo off
setlocal
pushd "%~dp0.."
python -u src\run_uav_live.py %*
set "uav_exit_code=%errorlevel%"
popd
exit /b %uav_exit_code%

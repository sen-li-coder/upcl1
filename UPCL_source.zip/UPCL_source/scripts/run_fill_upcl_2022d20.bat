@echo off
cd /d e:\LASE
echo [fill] start cec2022 D20 upcl-arm fill at %date% %time%
python -u src\fill_upcl_arm.py --workers 19 > results\cec\logs\fill_upcl_2022d20.log 2>&1
echo [fill] ALL DONE at %date% %time%

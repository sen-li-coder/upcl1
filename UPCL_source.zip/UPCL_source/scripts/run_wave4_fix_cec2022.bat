@echo off
cd /d e:\LASE
echo [fix] resume cec2022 missing cells at %date% %time%
python -u src\run_upcl_cec.py --stage main --suites cec2022 --dims 10 20 --hosts jDE100 j2020 DISH DISK LSHADE-cnEpSin SinDE IMODE PaDE SHADE-ILS --runs 30 --workers 19 > results\cec\logs\wave4_full_cec2022_fix.log 2>&1
echo [fix] cec2022 DONE at %date% %time%

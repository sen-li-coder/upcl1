"""P0-only, reproducible revision of the supplied PDF; never alters raw results.

The source PDF uses one positioned BT/ET text object per word. Removing objects
by their text-matrix origin avoids redaction's incorrect Cambria glyph bounds.
All replacements and their page coordinates are recorded for review.
"""
from pathlib import Path
import collections
import csv
import hashlib
import html
import json
import os
import re
import statistics

import numpy as np
import pymupdf as fitz
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(os.environ.get('P0_PDF', str(ROOT / 'docs/UPCL_paper.pdf')))
if not SOURCE.exists():
    fallback=ROOT/'docs/UPCL_paper.pdf'
    previous=ROOT/'output/pdf/UPCL_paper_P0_audit.json'
    if not previous.exists() or hashlib.sha256(fallback.read_bytes()).hexdigest()!=json.loads(previous.read_text(encoding='utf-8'))['source_sha256']:
        raise FileNotFoundError('Input missing and no byte-identical verified workspace copy exists.')
    SOURCE=fallback
IMAGE_DIR = Path(os.environ['P0_IMAGE_DIR'])
OUT = ROOT / 'output/pdf'
WORK = ROOT / 'tmp/pdfs/p0'
OUT.mkdir(parents=True, exist_ok=True)
WORK.mkdir(parents=True, exist_ok=True)
PDF = OUT / 'UPCL_paper_P0.pdf'
doc = fitz.open(SOURCE)
original = fitz.open(SOURCE)
operations = collections.defaultdict(list)
edits = []
font = Path('C:/Windows/Fonts/times.ttf')
fontbold = Path('C:/Windows/Fonts/timesbd.ttf')


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(page, kind, detail):
    edits.append(dict(page=page, kind=kind, detail=detail))


def paragraph(page, prefix, new, size=9.95, indent=True, caption=False):
    """Replace one original paragraph, keeping its existing vertical allocation."""
    pg = original[page-1]
    found = []
    for b in pg.get_text('dict')['blocks']:
        if 'lines' not in b:
            continue
        text = ''.join(s['text'] for l in b['lines'] for s in l['spans'])
        if text.startswith(prefix):
            found.append(b)
    if len(found) != 1:
        raise ValueError((page, prefix, len(found)))
    b = found[0]
    spans = [s for l in b['lines'] for s in l['spans']]
    ys = [s['origin'][1] for s in spans]
    # Ascender boxes in the source math font are unreliable; use baselines.
    x0 = 62.4 if not caption else min(s['bbox'][0] for s in spans)
    x1 = 533.2 if not caption else max(s['bbox'][2] for s in spans)
    region(page, (x0-0.3, min(ys)-0.6, x1+0.3, max(ys)+0.6),
           (x0, min(ys)-size*0.96, x1, max(ys)+size*0.38),
           new, size, indent, caption)
    record(page, 'paragraph', prefix + ' -> ' + new)


def region(page, origins, box, text, size=9.95, indent=False, caption=False):
    operations[page].append(dict(kind='text', origins=list(origins), box=list(box),
                                 text=text, size=size, indent=indent, caption=caption))


def number(page, rect, baseline, text, size=6.5):
    r = fitz.Rect(rect)
    operations[page].append(dict(kind='number', origins=[r.x0-0.15, baseline-0.4,
                                                        r.x1+0.15, baseline+0.4],
                                 rect=list(r), baseline=baseline, text=text, size=size))


def find_replace(page, old, new, choose=None):
    matches = original[page-1].search_for(old)
    if choose:
        matches = [r for r in matches if choose(r)]
    if len(matches) != 1:
        raise ValueError(('search', page, old, len(matches)))
    r = matches[0]
    traces = original[page-1].get_texttrace()
    candidates = [t for t in traces if any(r.contains(fitz.Point(c[2])) for c in t['chars'])]
    # For a substring with a descender-free rectangle, use the matching bbox.
    if not candidates:
        candidates = [t for t in traces if fitz.Rect(t['bbox']).intersects(r)]
    t = min(candidates, key=lambda t: abs(t['bbox'][0]-r.x0))
    y = t['chars'][0][2][1]
    number(page, r, y, new, t['size'])
    record(page, 'text correction', old + ' -> ' + new)


def replace_trace(page, text, new, y_near):
    matches=[t for t in original[page-1].get_texttrace()
             if ''.join(chr(c[0]) for c in t['chars'])==text
             and abs(t['chars'][0][2][1]-y_near)<1]
    assert len(matches)==1,(page,text,len(matches))
    t=matches[0]
    number(page,t['bbox'],t['chars'][0][2][1],new,t['size'])
    record(page,'text correction',text+' -> '+new)


def figure(page, xref, path, rect=None):
    operations[page].append(dict(kind='image', xref=xref, path=str(path), rect=rect))
    record(page, 'figure', str(path))


# Audit raw FE counts and buffer lineage rather than assuming current defaults
# generated historical records. No counterfactual outcomes are fabricated.
raw_audit = []
buffer_styles = collections.Counter()
missing_configs = 0
total_pairs = mismatched_pairs = oversized_pairs = 0
max_pair_gap = 0
for f in sorted((ROOT/'results/cec/raw').rglob('*.json')):
    if 'cec2013' in f.parts:
        continue
    d = json.loads(f.read_text(encoding='utf-8'))
    bad = []
    for run in d['runs']:
        arm = 'upcl' if 'upcl' in run else 'full'
        a, b = run['bare'], run[arm]
        total_pairs += 1
        diff = int(b['nevals'])-int(a['nevals'])
        if diff:
            mismatched_pairs += 1
            max_pair_gap = max(max_pair_gap, abs(diff))
            bad.append(dict(run=run['run'], bare=a['nevals'], upcl=b['nevals'], delta=diff))
        if max(a['nevals'], b['nevals']) > d['max_evals']:
            oversized_pairs += 1
        if not any(k in b for k in ('config', 'upcl_config', 'resolved_config')):
            missing_configs += 1
        mc = b.get('upcl', {}).get('memory_counts', {})
        if mc:
            style = 'count_over_51' if max(mc.values()) > 51 else 'count_at_most_51'
            buffer_styles[style] += 1
    if bad:
        raw_audit.append(dict(file=str(f.relative_to(ROOT)), pairs=bad))
assert total_pairs == 2378*30, total_pairs

cells = read_csv(ROOT/'results/cec/tables/exp1_cells.csv')
acc = {}
for r in cells:
    if r['suite']=='cec2017' and r['dim']=='30':
        acc.setdefault(r['host'], []).append(np.log10(max(float(r['bare_median']),1e-8)))
scores = {h:float(np.median(v)) for h,v in acc.items()}
rank = {h:i+1 for i,h in enumerate(sorted(scores,key=lambda h:(scores[h],h)))}
assert len(rank)==29
uav = read_csv(ROOT/'results/apps/tables/uav_value_rank.csv')
tasks = read_csv(ROOT/'results/apps/tables/uav_task_rank.csv')
uavrank = {r['host']:int(r['uav_rank']) for r in uav}
hosts = sorted(rank)
pooled = spearmanr([rank[h] for h in hosts],[uavrank[h] for h in hosts])
task_corr = {}
for fid in range(1,5):
    tr = {r['host']:int(r['task_rank']) for r in tasks if int(r['fid'])==fid}
    sp = spearmanr([rank[h] for h in hosts],[tr[h] for h in hosts])
    task_corr[fid] = dict(rho=float(sp.statistic),p=float(sp.pvalue))
delta = {h:uavrank[h]-rank[h] for h in hosts}
overhead = read_csv(ROOT/'results/cec/tables/exp6_overhead.csv')
median_overhead=statistics.median(float(r['overhead_pct']) for r in overhead)
audit = dict(source_pdf=str(SOURCE), source_sha256=sha(SOURCE),
             raw_cells=2378, paired_runs=total_pairs, mismatched_cells=len(raw_audit),
             mismatched_pairs=mismatched_pairs,max_absolute_fe_gap=max_pair_gap,
             pairs_with_budget_overshoot=oversized_pairs,
             missing_resolved_config_records=missing_configs,
             buffer_count_patterns=dict(buffer_styles), fe_details=raw_audit,
             canonical_rank=rank, pooled_correlation=dict(rho=float(pooled.statistic),p=float(pooled.pvalue)),
             task_correlations=task_corr,median_overhead_pct=median_overhead,
             input_hashes={str(p.relative_to(ROOT)):sha(p) for p in [
                 ROOT/'results/cec/tables/exp1_cells.csv',ROOT/'results/cec/tables/attr_d6_regression.csv',
                 ROOT/'results/cec/tables/attr_d6_rf_importance.csv',ROOT/'results/apps/tables/uav_value_rank.csv',
                 ROOT/'results/apps/tables/uav_task_rank.csv']})
(WORK/'audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
print('AUDIT', {k:audit[k] for k in ['paired_runs','mismatched_cells','mismatched_pairs','max_absolute_fe_gap',
                                     'missing_resolved_config_records','buffer_count_patterns','pooled_correlation']},flush=True)

# User-supplied artwork: preserve every pixel and aspect ratio.
for page,xref,name in [(2,27,'f1.png'),(10,45,'f2.png'),(29,101,'f8.png')]:
    figure(page,xref,IMAGE_DIR/name)
region(2,(62,591,533,629),(62.4,583,533,631),
       'Fig. 1. Conceptual history of six DE mechanism dimensions and selected algorithm milestones. '
       'The composition levels describe ingredients, not guaranteed performance. Arrows are schematic '
       'references and do not establish direct algorithm ancestry. No experimental values are plotted.',9,False,True)
record(2,'caption','Fig. 1 caption updated to match supplied artwork.')
region(10,(62,621,534,654),(62.4,615,533,658),
       'Fig. 2. Conceptual overview of four development eras and six mechanism dimensions. '
       'The shares in panels F and G are illustrative artwork, not counts computed from the 106-variant '
       'taxonomic set or measurements from the 29-host experiment.',9,False,True)
record(10,'caption','Fig. 2 illustrative percentages explicitly distinguished from empirical measurements.')
region(29,(62,338,534,365),(62.4,328,533,366),
       'Fig. 8. Conceptual positioning of intervention mechanisms by host-interface requirements and '
       'additional objective evaluations. Artwork labels are illustrative: the five formal descriptors '
       'are defined in Section 3.2. The check marks are design intentions, not empirical guarantees.',9,False,True)
record(29,'caption','Fig. 8 artwork descriptor names and check marks qualified; no image content altered.')

# Figure 21 uses the exact same six rows as Table 44, without refitting P3 models.
reg = {r['term']:r for r in read_csv(ROOT/'results/cec/tables/attr_d6_regression.csv')}
rf = {r['term']:r for r in read_csv(ROOT/'results/cec/tables/attr_d6_rf_importance.csv')}
terms = ['mutation_class','strategy','param_class','pop','other_flag','archive']
labels = ['Mutation','Operator selection','Parameter rule','Population size','Extra mechanisms','External archive']
colors = ['#2764a0','#e15b45','#2f9a83','#8b6fba','#d09b22','#888888']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8})
fig,(ax,bx)=plt.subplots(1,2,figsize=(10.6,3.68),gridspec_kw={'width_ratios':[1.15,1]})
for i,(t,c) in enumerate(zip(terms,colors)):
    r=reg[t]; v=float(r['beta']);lo=float(r['lo']);hi=float(r['hi'])
    ax.errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='o',color=c,capsize=2,lw=1.3)
    ax.text(1.57,i,f'{v:+.2f}',va='center',fontsize=8)
    q=rf[t];m=float(q['importance']);sd=float(q['std'])
    bx.barh(i,m,color=c,height=.5)
    bx.errorbar(m,i,xerr=sd,color='#444444',capsize=2,lw=1)
    bx.text(.57,i,f'{m:.3f}',va='center',fontsize=8)
ax.set_yticks(range(6),labels);ax.set_ylim(5.6,-.6);ax.set_xlim(-1.1,1.9)
ax.axvline(0,color='#aaa',ls='--',lw=.7);ax.set_xlabel('Standardized coefficient (95% CI)')
ax.set_title('(a) Regression: values from Table 44',loc='left',fontsize=9)
bx.set_yticks(range(6),[]);bx.set_ylim(5.6,-.6);bx.set_xlim(0,.68)
bx.set_xlabel('Permutation importance (SD)');bx.set_title('(b) Random forest: values from Table 44',loc='left',fontsize=9)
for a in [ax,bx]:
    a.spines[['top','right']].set_visible(False)
fig.tight_layout();fig.savefig(WORK/'fig21.png',dpi=240);plt.close(fig)
figure(65,191,WORK/'fig21.png')
region(65,(62,699,534,759),(62.4,690,533,762),
       'Fig. 21. Numerical attribution results from the same CSV rows as Table 44. '
       '(a) Standardized regression coefficients and 95% intervals. '
       '(b) Random-forest permutation importance with permutation standard deviations. '
       'Both panels use the table row order. The estimation procedures and input observations are unchanged.',9,False,True)

# Other empirical artwork was also stale in docs/figures. Use the already
# generated current analysis images, retaining the existing estimation methods.
for page,name in [(36,'fig_dim_effect.png'),(65,'attr_d2_eta2_dot.png'),
                  (66,'attr_d8_near_matrix.png'),(56,'conv_cec2017_D50_p01_all.png'),
                  (57,'conv_cec2017_D50_p02_all.png'),(58,'conv_cec2017_D50_p03_all.png')]:
    ims=original[page-1].get_image_info(xrefs=True)
    im=ims[0]
    path=ROOT/'results/cec/figures'/name
    figure(page,im['xref'],path)
    audit['input_hashes'][str(path.relative_to(ROOT))]=sha(path)

# Canonical ranking: Section 4 block_ranks (median of per-function log errors).
fig,axes=plt.subplots(2,2,figsize=(9.8,9.62))
for fid,ax in enumerate(axes.flat,1):
    tr={r['host']:int(r['task_rank']) for r in tasks if int(r['fid'])==fid}
    for h in hosts:
        ax.scatter(rank[h],tr[h],s=24,color='#2764a0',alpha=.85)
        ax.annotate(h,(rank[h],tr[h]),xytext=(2,3),textcoords='offset points',fontsize=5.4)
    q=task_corr[fid]
    ax.plot([1,29],[1,29],'--',color='#999',lw=.9)
    ax.set(xlim=(0,31),ylim=(0,31),xlabel='CEC2017 D30 rank (Section 4 definition)',ylabel=f'F{fid} scenario rank')
    ax.set_title(f'F{fid}: Spearman r = {q["rho"]:.3f}, p = {q["p"]:.4f}',fontsize=10)
    ax.grid(alpha=.15)
fig.tight_layout();fig.savefig(WORK/'fig27.png',dpi=260);plt.close(fig)
figure(78,229,WORK/'fig27.png')

# Update CEC rank and rank migration cells, keeping UAV outcomes unchanged.
for page,first,last in [(73,1,2),(74,3,29)]:
    blocks=original[page-1].get_text('dict')['blocks']
    for row in uav:
        pos=int(row['uav_rank'])
        if not first<=pos<=last:continue
        h=row['host']
        # Each table row is a block with the host as its second line.
        matches=[]
        for b in blocks:
            if 'lines' not in b:continue
            lines=[''.join(s['text'] for s in l['spans']).strip() for l in b['lines']]
            if len(lines)>=4 and lines[0]==str(pos) and lines[1]==h:
                matches.append(b)
        assert len(matches)==1,(page,h,len(matches))
        b=matches[0]
        for line_index,text in [(2,str(rank[h])),(3,f'{delta[h]:+d}')]:
            ss=b['lines'][line_index]['spans'];s=ss[0]
            number(page,s['bbox'],s['origin'][1],text,s['size'])
record(73,'ranking','Table 51 CEC ranks and delta cells use the Section 4 canonical definition.')
record(74,'ranking','Table 51 continued; UAV order, scores and outcomes unchanged.')

# Same correction in Tables 55-58: locate narrow CEC-rank cells by column.
for page,selected in [(78,['L-SHADE-RSP','LSHADE-cnEpSin','DE/rand/2']),
                      (79,['SHADE','jDE','DE/rand/1']),
                      (80,['LSHADE-cnEpSin','MadDE','DE/current-to-rand/1']),
                      (81,['DISK','jDE100','DE/rand/2'])]:
    blocks=original[page-1].get_text('dict')['blocks']
    for h in selected:
        matches=[]
        for b in blocks:
            if 'lines' not in b:continue
            ss=[s for l in b['lines'] for s in l['spans']]
            if any(s['text'].strip()==h and 90<s['origin'][0]<200 for s in ss):
                candidates=[s for s in ss if 210<s['origin'][0]<225 and s['text'].strip().isdigit()]
                if len(candidates)==1:matches.append(candidates[0])
        assert len(matches)==1,(page,h,len(matches))
        s=matches[0];number(page,s['bbox'],s['origin'][1],str(rank[h]),s['size'])
    record(page,'ranking','CEC rank cells in task table use Section 4 definition.')

region(73,(62,675,534,721),(62.4,665,533,722),
       'Table 51 Behaviour on the interception scenario, ordered by the unchanged UAV composite score '
       '(larger is better). CEC rank uses exactly the Section 4 definition: rank of the median across '
       'functions of floored per-function median log10 error in CEC2017 D30. Delta is UAV rank minus '
       'CEC rank. Both rankings are descriptive.',9,False,True)
better=sum(v<0 for v in delta.values());worse=sum(v>0 for v in delta.values());same=sum(v==0 for v in delta.values())
largest=min(delta,key=delta.get)
paragraph(74,'Table 51 also places',
          f'Table 51 uses one CEC ranking definition throughout Sections 4 and 5. Of the 29 variants, '
          f'{better} rank better on the scenario, {worse} rank worse and {same} keep the same position; '
          f'the median absolute displacement is {np.median([abs(v) for v in delta.values()]):g} ranks. '
          f'The Spearman correlation is {pooled.statistic:.3f} (p = {pooled.pvalue:.4f}, n = 29). '
          f'The CEC2017 D30 leader is MadDE (scenario rank {uavrank["MadDE"]}); DISK, the scenario leader, '
          f'has CEC rank {rank["DISK"]}. The largest upward migration is {largest} ({delta[largest]:+d}). '
          'Using a mean of raw log errors instead produces a different ordering and correlation. '
          'The median-based benchmark definition is used consistently here; aggregation sensitivity '
          'must be distinguished from changes in the underlying scenario outcomes.')
paragraph(77,'Read task by task,',
          'The four task comparisons now use the same CEC2017 D30 rank as Table 8. '
          + '; '.join(f'F{k}: Spearman r = {v["rho"]:.3f}, p = {v["p"]:.4f}' for k,v in task_corr.items())
          + '. All four comparisons contain 29 hosts. The task leaders remain L-SHADE-RSP on F1 '
          f'(CEC rank {rank["L-SHADE-RSP"]}), SHADE on F2 ({rank["SHADE"]}), '
          f'LSHADE-cnEpSin on F3 ({rank["LSHADE-cnEpSin"]}) and DISK on F4 ({rank["DISK"]}). '
          'Figure 27 and Tables 55-58 use this identical benchmark ranking. The task rankings '
          'are descriptive summaries of three runs per cell.')
task_examples={1:('L-SHADE-RSP','LSHADE-cnEpSin','DE/rand/2'),
               2:('SHADE','jDE','DE/rand/1'),3:('LSHADE-cnEpSin','MadDE','DE/current-to-rand/1'),
               4:('DISK','jDE100','DE/rand/2')}
for page,fid in [(78,1),(79,2),(80,3),(80,4)]:
    a,b,c=task_examples[fid];q=task_corr[fid]
    paragraph(page,f'Task F{fid} re-orders',
              f'Task F{fid} has {a} in first place, {b} in the median position and {c} in last place. '
              f'Their CEC2017 D30 ranks under the Section 4 definition are {rank[a]}, {rank[b]} and {rank[c]}, '
              f'respectively. Across all 29 hosts, Spearman r = {q["rho"]:.3f} (p = {q["p"]:.4f}). '
              'These rank summaries use the same benchmark aggregation as Table 8; the UAV '
              'task scores, ordering and underlying trajectories have not been changed.')

# Correct formal metric directions without changing measured results.
region(27,(178,676,316,688),(179,668.5,315,689.5),
       'dec = log10(median bare error) - log10(median UPCL error); ri: Eq. (29)',6.7)
region(27,(316,676,391,690),(317,667,391,690),
       'dec: log10 decades; ri: [-1,1]; positive means improvement',6.8)
record(27,'metric','Table 5: positive dec/ri consistently means improvement.')

# Reference implementation parameters. Historical provenance cannot be inferred
# from unversioned result files, so the manuscript must disclose that limitation.
replace_trace(23,'=0.5,','= 0.7,',178.85)
replace_trace(23,'=1.6,','= 1.4,',191.09)
find_replace(23,'fixed constant 0.5, 0.6 or 2.','fixed constant 0.3, 0.4 or 2.')
# Inline cost equalities have individual positioned numeric objects.
replace_trace(23,'=0.5','= 0.3',505.73)
replace_trace(23,'1=0.6','1 = 0.4',505.73)

# Draw a code-native scientific schematic (no alteration of supplied images).
fig=plt.figure(figsize=(12,7.5))
axes=[fig.add_axes([.025+i*.195,.48,.17,.43]) for i in range(5)]
q=np.array([.8,.6]);s=np.array([-.1,.995]);p=(q+s)/np.linalg.norm(q+s)
vectors=[q,.7*q,1.4*q,-q,p]
names=['Identity I','Contraction C','Expansion E','Reflection R','Projection P']
forms=['d','0.7 d','1.4 d','-d','norm(d) normalize(0.5 q + 0.5 s)']
for i,ax in enumerate(axes):
    ax.annotate('',xy=q,xytext=(0,0),arrowprops=dict(arrowstyle='->',color='#999',ls='--',lw=1.7))
    ax.annotate('',xy=vectors[i],xytext=(0,0),arrowprops=dict(arrowstyle='->',color='#1682a5',lw=2.4))
    if i==4:ax.annotate('',xy=s,xytext=(0,0),arrowprops=dict(arrowstyle='->',color='#69a83b',ls=':',lw=1.5))
    ax.axhline(0,color='#ddd',lw=.5);ax.axvline(0,color='#ddd',lw=.5)
    ax.set(xlim=(-1.1,1.4),ylim=(-1,1.5),aspect='equal',xticks=[],yticks=[])
    ax.set_title(names[i],fontsize=13,pad=12);ax.set_xlabel(forms[i] if i<4 else 'Turn toward recent success',fontsize=10)
    for sp in ax.spines.values():sp.set_visible(False)
for x,title,body in [(.035,'Reference implementation','Compute the five descriptors.\nQuery the action memory.\nChoose one action.'),
                      (.36,'Feasibility handling','Keep I unchanged. Otherwise shrink\nthe step along its direction. If the\nshrink factor is below 0.5, return u.'),
                      (.685,'Single objective evaluation','Evaluate the returned candidate.\nDo not evaluate all five actions.\nArchive provenance: see Table 61.')]:
    fig.text(x,.36,title,weight='bold',fontsize=13)
    fig.text(x,.29,body,fontsize=11,va='top',linespacing=1.6)
fig.text(.5,.055,'Grey: original displacement     Blue: executed displacement     Green: recent success direction',
         ha='center',fontsize=10,color='#555')
fig.savefig(WORK/'fig7.png',dpi=220);plt.close(fig)
figure(26,92,WORK/'fig7.png')
region(26,(62,418,534,421),(62.4,411,533,423),
       'Action maps: Eq. (19). Feasibility shrink and fallback: Eq. (24).',8.0)
region(26,(62,364,534,411),(62.4,356,533,411),
       'Fig. 7. Five action maps and feasibility fallback in the current reference implementation: '
       'contraction 0.7, expansion 1.4 and projection mix 0.5. These constants agree with Eq. (19) '
       'in this revision. Archived runs do not store complete resolved configurations; see Table 61 '
       'and the reproducibility note. Original result values are retained.',9,False,True)
paragraph(22,'The memory ℳ',
          'The current reference memory splits nominal capacity 256 into five action-specific buffers '
          'of 51 triples (255 total). Equation (17) averages the queried action. Historical records '
          'also contain larger counts; their complete configurations were not recorded (Table 61).',indent=False)
paragraph(22,'One property of that record',
          'The current action-specific buffers retain the latest entries for each action, not the latest '
          '256 proposals globally. Rare-action observations can therefore be older than identity observations. '
          'The response surface may drift during a run even after normalization; bounded buffer capacity '
          'alone does not ensure a fixed time window. Archived memory-count patterns differ from the '
          'current allocation, which limits exact reconstruction of the historical response model.')
paragraph(88,'The coefficients of Table 61',
          'Table 61 specifies the current reference implementation. The archived paired results do not '
          'store complete resolved controller configurations or per-run source identifiers. They therefore '
          'cannot establish that every historical run used these same action constants and buffer allocation. '
          'The reported results are retained as archived observations; exact reproduction requires '
          'recovering the generating code/configuration or conducting a separately versioned rerun.')
region(89,(62,77,534,93),(62.4,69,533,94),
       'Table 61 Current reference specification. It is not a retrospectively verified configuration '
       'manifest for all archived experiments; complete historical configurations were not recorded.',9,False,True)
# Replace the entire reference-parameter table in its existing space.
region(89,(62,105,534,267),(64,97,531,267),
       '<TABLE61>',8.0)

# FE accounting: distinguish replacement-interface design from actual archives.
paragraph(27,'Property 2 (Zero evaluation overhead).',
          'Property 2 (No additional objective call by the layer). At the one-target-one-trial interface, '
          'UPCL replaces the trial rather than evaluating a second one. This is an interface property, '
          'not proof that all complete host runs stop at an identical count. The archive audit found '
          f'{mismatched_pairs} unequal pairs in {len(raw_audit)} SHADE-ILS cells; each gap is at most '
          f'{max_pair_gap} evaluations. All comparisons use the same nominal budget.')
paragraph(29,'Each observation pairs',
          'Each observation pairs one benchmark function, one dimension and one host. Bare and UPCL '
          'configurations share the seed schedule and nominal budget B = 10000 D evaluations. '
          'The intervention replaces the candidate sent to evaluation. Actual counts are stored as nevals; '
          'host batch termination can overshoot the nominal limit. The audit identifies 79 SHADE-ILS '
          'cells with unequal arm counts (1591 run pairs, maximum difference 3 evaluations). '
          'Thus the archive is nominal-budget matched, not universally bit-for-bit count matched.')
paragraph(30,'The protocol follows',
          'The primary resource is the nominal objective-evaluation budget B = 10000 D. Actual counts '
          'and terminal overshoots are retained in the raw records. Per-cell differences are tested with '
          'a two-sided paired Wilcoxon test; Holm correction controls multiple comparisons within each '
          'benchmark block, and effect sizes accompany the verdicts. Seed pairing controls the starting '
          'conditions but does not imply identical future populations or random-number consumption. '
          'The 79 SHADE-ILS count exceptions must be considered separately from the layer interface. '
          'The current reference code is documented independently of the incompletely versioned '
          'historical controller configurations. All figures and revised ranks use the stated input CSVs.')
paragraph(31,'Attaching the layer changes',
          'At the candidate interface, the layer either returns the host trial or replaces it before '
          'evaluation. If every call returns the identical candidate and the random streams and host '
          'updates are otherwise unchanged, the host trajectory is unchanged. Actual archive counts '
          'are subject to the SHADE-ILS stopping exceptions described in Section 4.1. The method '
          'does not itself evaluate additional action alternatives.')
paragraph(24,'Exploration changes where',
          'Exploration selects which single trial is evaluated at the candidate interface; it does not '
          'evaluate an extra alternative. Actual total evaluation counts also depend on host termination. '
          'The archive-level exceptions to equal counts are disclosed in Section 4.1.')
# Rewrite only the FE part of introduction; leave P1 safety and causal claims for
# the user's next approval stage.
for prefix in ['Three properties of this construction','The first two properties']:
    b=next(b for b in original[3].get_text('blocks') if b[6]==0 and b[4].startswith(prefix))
    t=' '.join(b[4].split())
    t=t.replace('the evaluation accounting of the wrapped variant coincides with that of the bare variant and a paired comparison of the two at equal budget needs no convention.',
                'the layer adds no objective call at this interface; actual terminal-count exceptions in SHADE-ILS are disclosed in Section 4.1.')
    t=t.replace('leaves the wrapped variant with the same evaluation accounting as the bare variant, so a difference between the two cannot come from extra function evaluations.',
                'adds no objective call at the interface. Comparisons share a nominal budget; small terminal-count exceptions are reported in Section 4.1.')
    paragraph(4,prefix,t)
paragraph(28,'Two points about this accounting',
          'Operation counts and objective-evaluation counts are different resources. The layer makes '
          'no objective call, but feature computation, memory queries and host interaction add runtime. '
          f'Across the 2378 cells in the archived overhead table, the median relative runtime increase '
          f'is {median_overhead:.1f}%. Its practical cost depends on the host and objective, so it is '
          'not generally negligible. Actual terminal counts are nominal-budget matched with the '
          'SHADE-ILS exceptions reported in Section 4.1. Historical records and the current reference '
          'implementation are distinguished in Table 61; operation-count arguments do not establish '
          'the provenance of archived runs.')
paragraph(28,'which with',
          'For the current reference allocation, five buffers of 51 triples with five descriptor '
          'coordinates require 1275 coordinate comparisons per complete memory scan, before '
          'kernel and bookkeeping operations. Equation (27) is a conservative upper bound if M '
          'bounds each action buffer. Memory also stores direction prototypes, reference points '
          'and running directions. Historical buffer allocations are not fully versioned. '
          'Neither this operation count nor bounded storage implies negligible runtime.')
paragraph(88,'The layer is attached to a variant',
          'The reference interface uses three callbacks: generation initialization, candidate '
          'correction, and observation of the evaluated result. Raw JSON files retain seeds, '
          'nominal and actual evaluation counts, final errors, convergence traces and intervention '
          'statistics. The host and layer use separate random generators. Seeds specify random '
          'initialization but are not, alone, a complete reproduction manifest: historical resolved '
          'configurations and source identifiers were not stored. The figure and rank summaries '
          'are reproducible from the recorded CSV inputs without modifying the archived outcomes.')
paragraph(87,'The candidate turns out',
          'The candidate is a common observable of the DE interfaces considered here. A layer that '
          'receives the parent, candidate and scalar response can operate without direct access to '
          'the host parameter memories or archive. It replaces the candidate at a one-trial interface '
          'and makes no objective call itself. This design does not establish exact total-count '
          'identity for every archived run: comparisons share nominal budgets, with small SHADE-ILS '
          'termination differences reported in Section 4.1. Historical configuration provenance '
          'remains incomplete, as stated in Table 61. These limitations qualify what can be '
          'reproduced and inferred from the paired observations.')

# Replace brief table entries by source-position origins.
region(30,(170,549,533,553),(172,541,530,557),
       'Archived operating-point labels; full resolved configurations were not stored (Table 61).',7.2)
region(30,(170,483,533,488),(172,474,530,489),
       'Same seed schedule and nominal budget; independent layer RNG; actual-count exceptions in text.',7.1)
record(30,'protocol','Table 6 configuration and pairing rows no longer assert unverified exact identity.')
paragraph(36,'Section 4.2 already pairs',
          'Section 4.2 reports the paired comparisons by host. Table 12 and Tables 13-36 cover all '
          'four blocks: CEC2017 D30 and D50 each contain 29 functions x 29 hosts, whereas CEC2022 '
          'D10 and D20 each contain 12 functions x 29 hosts. There are 2378 cells in total, with '
          '30 paired runs per cell. The matrices retain the archived final errors.')
paragraph(57,'All four levels are present',
          'All four composition levels are present in this D50 panel, with the full set of 29 hosts '
          'distributed across them. The subplots cover CEC2017 functions F14-F25 at a nominal '
          'budget of 500000 evaluations. Solid and dashed curves use the same host membership '
          'and summarize the bare and wrapped arms, respectively. A level summary is descriptive '
          'and must not be interpreted as a controlled effect of adding one mechanism.')
paragraph(58,'The second suite has ten functions',
          'This final CEC2017 D50 panel contains the five remaining functions F26-F30; unused '
          'subplot positions are left empty rather than filled with a different problem. The '
          'horizontal axis is objective evaluations up to the nominal limit of 500000. Each '
          'colored curve summarizes a composition level, with the bare arm solid and the UPCL '
          'arm dashed, using the full 29-host pool and 30 runs per cell. The shaded bands are '
          'descriptive interquartile ranges. Comparisons should be made between the two arms '
          'at the same evaluation count within a subplot. Per-function final errors are retained '
          'in the numerical matrices; the level-level curves do not identify the causal '
          'contribution of an individual mechanism.')
paragraph(35,'Crossing the left and right halves',
          'On both CEC2022 blocks, the random-base variants have high intervention rates and '
          'negative mean dec. This is a tendency, not an exact matching of the three largest rates '
          'to the three largest losses: on D20, DE/current-to-rand/1 has dec = -0.105, below the '
          '-0.038 of SinDE, while DE/rand/2 has dec = -0.200. The numerical entries in Tables 9 '
          'and 10 are the basis for this comparison.')

# Existing fingerprint tables use pooled raw-log summaries, not the canonical
# block median rank: label that difference explicitly rather than silently
# replacing their numerical data with a different statistic.
region(62,(62,606,534,631),(62.4,600,533,629),
       'Table 42 Pooled fingerprint, ordered by mean raw median log10 error (not the block rank '
       'of Table 8). IR counts all interventions; positive dec means improvement. '
       'Theta and eta denote recorded descriptor contrasts.',8.0,False,True)
record(62,'definition','Fingerprint ordering explicitly separated from benchmark block ranks.')

# User steering: experimental figures must remain completely unchanged. Keep
# only the three explicitly requested image replacements. Do not silently
# change rank tables while retaining a scatter plot based on another ranking.
for page in list(operations):
    operations[page]=[o for o in operations[page]
                      if o['kind']!='image' or page in (2,10,29)]
    if page in (23,26,56,57,58,65,66,73,74,77,78,79,80,81):
        operations[page]=[]
    if not operations[page]:del operations[page]
edits=[e for e in edits if e['page'] in operations
       and not (e['kind']=='figure' and e['page'] not in (2,10,29))]
audit['experimental_figures_preserved']=True
audit['canonical_rank_diagnostic_not_applied']=True

# Keep Eq. (19) and Fig. 7's existing 0.5/1.6 example. Explicitly distinguish
# that example from current defaults instead of asserting a false provenance.
paragraph(23,'implementation is a few dozen lines',
          'The response model uses vector operations over stored observations. Equation (19) '
          'and Fig. 7 retain the illustrated action multipliers 0.5 and 1.6. The current '
          'reference code instead defaults to contraction 0.7 and expansion 1.4 (Table 61), '
          'with the same projection mix 0.5. Complete per-run historical configurations '
          'were not archived, so neither specification can be assigned retrospectively '
          'to every reported run. This version distinction must be resolved before '
          'claiming exact reproduction of the archived experiments.')

# Preserve the original Section 5 ranking and every experimental scatter.
# The two statistical summaries are now named explicitly, not conflated.
region(73,(62,675,534,721),(62.4,665,533,722),
       'Table 51 Behaviour on the interception scenario, ordered by composite score '
       '(larger is better). Throughout Section 5, CEC rank is based on the mean across '
       'CEC2017 D30 functions of raw per-function median log10 error. This differs from '
       'the median-based block rank in Section 4. Delta is scenario rank minus this CEC rank.',9,False,True)
record(73,'ranking definition','Preserved existing numbers; explicitly distinguished Section 5 mean-raw rank from Section 4 median rank.')
region(78,(62,452,534,489),(62.4,463,533,499),
       'Fig. 27. Rank comparison for F1-F4. The retained scatter uses the Section 5 mean-raw-error '
       'CEC2017 D30 rank, not the median-based rank in Section 4. Experimental points, '
       'correlations and scenario rankings are unchanged; the diagonal denotes equal ranks.',9,False,True)
record(78,'ranking definition','Fig. 27 pixels and statistics preserved; caption names original ranking aggregation.')
region(36,(62,353,534,412),(62.4,365,533,413),
       'Fig. 9. Retained earlier dimension-comparison visualization. This artwork contains '
       '20 hosts and reports a gain-rank correlation of 0.79; it is not the complete 29-host '
       'summary discussed in the adjacent text. Tables 8 and 11 contain the full family. '
       'The earlier figure is preserved without altering experimental points; its data-version '
       'difference remains to be resolved.',9,False,True)
record(36,'figure provenance','Fig. 9 preserved; 20-host plot explicitly distinguished from 29-host tables.')
region(65,(62,699,534,759),(62.4,690,533,762),
       'Fig. 21. Retained earlier attribution visualization. Its displayed mutation coefficient '
       '(about 0.76) and permutation importance (about 0.555) differ from Table 44 '
       '(0.69 and 0.33). No plotted value is changed here. Table 44 follows the current '
       'archived coefficient CSVs; this figure is not a visualization of those exact rows. '
       'The figure/table version discrepancy remains unresolved.',9,False,True)
record(65,'figure provenance','Fig. 21 experimental pixels preserved; discrepancy with Table 44 explicitly disclosed.')

# Apply edits to original BT/ET objects by origin, then add new content. The
# graphics and formula objects outside edited origins remain byte-for-byte.
bt_re=re.compile(rb'\bBT\b.*?\bET\b',re.S)
tm_re=re.compile(rb'([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+Tm\b')
fit_stats=[]
for page,ops in sorted(operations.items()):
    pg=doc[page-1]
    text_ops=[o for o in ops if o['kind'] in ('text','number')]
    rects=[fitz.Rect(o['origins']) for o in text_ops]
    removed=[0]
    for xref in pg.get_contents():
        data=doc.xref_stream(xref)
        def remove(m):
            q=tm_re.search(m.group())
            if q:
                pt=fitz.Point(float(q[5]),float(q[6]))
                if any(r.contains(pt) for r in rects):
                    removed[0]+=1
                    return b''
            return m.group()
        new=bt_re.sub(remove,data)
        if new!=data:doc.update_stream(xref,new)
    pg=doc.reload_page(pg)
    for o in ops:
        if o['kind']=='image':
            old=next(im for im in original[page-1].get_image_info(xrefs=True) if im['xref']==o['xref'])
            rect=fitz.Rect(o['rect'] or old['bbox'])
            pg.delete_image(o['xref'])
            pg.insert_image(rect,filename=o['path'],keep_proportion=True)
        elif o['kind']=='number':
            pg.insert_font(fontname='P0Times',fontfile=str(font))
            r=fitz.Rect(o['rect']);w=fitz.Font(fontfile=str(font)).text_length(o['text'],fontsize=o['size'])
            x=(r.x0+r.x1-w)/2
            pg.insert_text((x,o['baseline']),o['text'],fontname='P0Times',fontsize=o['size'])
        else:
            if o['text']=='<TABLE61>':
                rows=[('alpha','Contraction multiplier','0.7'),('beta','Expansion multiplier','1.4'),
                      ('m','Projection mixture','0.5'),('lambda','Cost weight','0.9'),
                      ('mu0 / mu1','Identity margin / adaptation','0.20 / 0.60'),
                      ('kappa_u','Uncertainty penalty','0.35'),('epsilon','Exploration schedule','0.15 to 0 over 60 generations'),
                      ('M','Nominal memory capacity','256; five buffers of 51'),
                      ('B','Nominal CEC budget','10000 D; actual counts recorded')]
                body='<table><tr><th>Symbol</th><th>Meaning</th><th>Current reference value</th></tr>'
                body+=''.join('<tr>'+''.join('<td>'+html.escape(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</table>'
            else:
                body='<p>'+html.escape(o['text'])+'</p>'
            css=f'''@font-face {{font-family:P0Times;src:url(times.ttf);}}
            @font-face {{font-family:P0Times;src:url(timesbd.ttf);font-weight:bold;}}
            *{{font-family:P0Times;font-size:{o['size']}pt;}}
            p{{margin:0;text-align:{'center' if o['caption'] else 'justify'};line-height:1.28;
            text-indent:{'20pt' if o['indent'] else '0'};}}
            table{{border-collapse:collapse;width:100%;}}td,th{{padding:2pt 4pt;border-bottom:.35pt solid #ccc;text-align:left;}}
            th{{border-top:1pt solid black;border-bottom:1pt solid black;}}'''
            # Source equations can contain outline paths as well as text. Clear
            # only the allocated replacement area; captions stay below images.
            clear=fitz.Rect(o['box'])
            if o['text']=='<TABLE61>':clear=fitz.Rect(62.2,96.5,533.4,267.5)
            pg.draw_rect(clear,color=None,fill=(1,1,1))
            result=pg.insert_htmlbox(fitz.Rect(o['box']),body,css=css,
                                     archive=fitz.Archive('C:/Windows/Fonts'),scale_low=.86)
            fit_stats.append(dict(page=page,scale=result[1],spare_height=result[0],text=o['text'][:70]))
            if result[0]<0:raise RuntimeError(('text did not fit',page,o['box'],o['text'][:80]))
    print('PATCHED',page,'text objects removed',removed[0],flush=True)

metadata=doc.metadata
metadata['title']='UPCL manuscript P0 consistency revision'
metadata['subject']='P0 numerical and provenance corrections; P1 not applied'
doc.set_metadata(metadata)
doc.subset_fonts()
doc.save(PDF,garbage=4,deflate=True)
doc.close()
check=fitz.open(PDF)
assert len(check)==len(original)
assert 'negative is a gain' not in check[26].get_text()
assert '0.7' in check[22].get_text() and '1.4' in check[22].get_text()
for page in sorted(operations):
    check[page-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(WORK/f'page-{page:03d}.png')
audit['output_sha256']=sha(PDF)
audit['fit_stats']=fit_stats
audit['changed_pages']=sorted(operations)
audit['edits']=edits
(OUT/'UPCL_paper_P0_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
report='''# UPCL 论文 P0 修改清单

本轮仅实施 P0，并替换用户提供的 Fig. 1、Fig. 2、Fig. 8。P1 理论安全性、因果归因和普遍性结论尚未修改，等待用户确认。

## 已实施

- 保留原 PDF，生成独立的 97 页 P0 修订版；原始实验 JSON、CSV 和算法代码均未修改。
- 三张新图原样嵌入，保持比例；同步修改图注，明确 Fig. 2 百分比为示意数据、Fig. 8 图中文字不取代正式描述子定义。
- Fig. 21 按与 Table 44 相同的现有 CSV 重绘；同步更换旧版 Fig. 9、Fig. 20、Fig. 22 和三张 D50 收敛图，未重新拟合 P3 模型。
- Table 5 统一 dec 和 ri 为正表示改善，修正定义与符号。
- 第五章 CEC 排名统一到第四章 Table 8 的口径；重算 Table 51 的排名迁移与相关性、Tables 55-58 的 CEC 名次、Fig. 27 及相关正文。无人机分数与任务排名不变。
- Table 42 的原始误差均值排序作为另一种描述性汇总保留，明确区别于区块排名，避免混称同一统计量。
- Eq. (19)、动作成本数字、Fig. 7、Table 61 统一为当前参考代码的收缩 0.7、扩张 1.4、投影混合 0.5。
- 更正 CEC2022 问题数量，区分名义预算与实际评估次数，并披露 SHADE-ILS 的终止差异。
- 用实测运行时间开销替换第 28 页“可忽略”的概括。

## 不能凭空消除的历史复现缺口

现有归档没有逐次保存完整解析配置、生成代码版本；部分 memory_counts 超过当前每动作 51 条上限。因此无法证明历史所有实验都使用当前参数和缓冲结构。修订稿已将 Table 61 改为“当前参考实现”，撤回“全部历史实验配置已一致验证”的声明，并在第 22、88 页明确披露。

这解决的是论文陈述与现有证据的一致性，**不是补造历史配置或证明旧结果可被当前代码精确复现**。要彻底闭合复现链，仍需找回生成代码及配置，或单独版本化重跑。没有用当前默认值追认旧数据。

## 审核数字

'''
report+=f'- 主实验：2378 格、{total_pairs} 对运行。\n- 两臂计数不等：{len(raw_audit)} 格、{mismatched_pairs} 对，均为 SHADE-ILS，最多相差 {max_pair_gap} 次。\n'
report+=f'- 运行时间增加比例的逐格中位数：{median_overhead:.2f}%。\n'
report+=f'- 统一排名后的总体 Spearman r={pooled.statistic:.4f}，p={pooled.pvalue:.6f}。\n'
report+='- 分任务：'+ '；'.join(f'F{k} r={v["rho"]:.4f}, p={v["p"]:.6f}' for k,v in task_corr.items())+'。\n\n'
report+='## 修改位置\n\n'
for page in sorted(operations):
    report+=f'- 第 {page} 页：'+ '；'.join(e['kind'] for e in edits if e['page']==page)+'。\n'
report+='\n复现脚本：scripts/revise_paper_p0.py。机器审计记录：UPCL_paper_P0_audit.json。\n'
report='''# UPCL P0 修订及待核对清单

## 本轮范围

按照用户最新要求，所有实验数据图保持原样；仅将用户提供的 f1.png、f2.png、f8.png 分别替换 Fig. 1、Fig. 2、Fig. 8。原始数据、实验统计 CSV、算法代码和原论文均未改写。P1 尚未实施。

## 已落实的修改

- 三张指定图片原样嵌入并保持比例，更新图注；Fig. 2 的百分比明确为示意数据，Fig. 8 的示意标签不替代正式描述子定义。
- Table 5 的 dec/ri 方向统一为正表示改善。
- 第四章中位数排名与第五章原始对数误差均值排名明确区分。第五章表格数字、Fig. 27 的点与相关系数均保留，未悄悄重算替换。
- 区分算法接口“不额外调用目标函数”与整个宿主运行“实际评估次数完全相等”，披露 SHADE-ILS 的终止差异。
- 纠正 CEC2022 每区块只有 12 个测试函数的规模说明。
- 明确 Eq. (19)/Fig. 7 的旧示例系数为 0.5/1.6，当前参考代码默认为 0.7/1.4；Table 61 改为当前参考实现，撤回全部旧实验均使用当前参数的未经验证声明。
- 说明当前名义容量 256 实际分为五个 51 条动作缓冲；历史记录存在不同记忆计数模式，不能追认同一实现。
- 补充实测时间开销并删除第 28 页“可忽略”的概括；明确种子不等于完整复现清单。

## 尚未闭合的 P0 问题

1. 历史运行没有保存完整解析配置和生成代码版本。不能仅凭当前代码确定旧实验到底采用哪个动作参数和记忆结构。需找回生成版本，或另行版本化重跑。本轮没有伪造配置、没有重跑实验。
2. Fig. 9 保留的是早期 20 宿主图，邻近正文和 Tables 8/11 是 29 宿主统计；已在图注明确版本差异，未改图。
3. Fig. 21 的变异系数约 0.76、重要性约 0.555，与 Table 44 的 0.69、0.33 不一致；已披露，未为迎合旧图而改写当前数据表。
4. 其他实验图（包括 Fig. 20、Fig. 22、D50 收敛图和全部 UAV 数据图）原样保留。旧图与当前分析快照是否一致仍需核对，不能将本轮说成已全面消除所有图表差异。
5. 排名已统一命名和说明，但没有强行统一成同一个聚合统计量；若要统一数值口径，会影响 Fig. 27 的实验点与统计量，需要遵守用户对数据图的后续决定。

因此，本版是 P0 的可审阅修订稿，不能宣称历史复现链和所有图表差异已全部解决。本轮停在 P0，不进入 P1。

## 核对结果

'''
report+=f'- 主实验 2378 格，共 {total_pairs} 对运行。\n'
report+=f'- 实际评估次数不等：{len(raw_audit)} 格、{mismatched_pairs} 对，均为 SHADE-ILS，最多相差 {max_pair_gap} 次。\n'
report+=f'- 运行时间增加比例的逐格中位数为 {median_overhead:.2f}%。\n'
report+='- 输出仍为 97 页；原始 PDF 与原始实验文件保留。\n\n'
report+='## 修改页码\n\n'+', '.join(map(str,sorted(operations)))+'。\n'
report+='\n复现脚本：scripts/revise_paper_p0.py。审计记录：UPCL_paper_P0_audit.json。\n'
(OUT/'UPCL_paper_P0_changes.md').write_text(report,encoding='utf-8')
print('OUTPUT',PDF,'PAGES',len(check),'CHANGED',sorted(operations),flush=True)
print('MIN TEXT SCALE',min(x['scale'] for x in fit_stats),flush=True)

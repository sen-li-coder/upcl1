# -*- coding: utf-8 -*-
"""Route-1 minimal controller: stagnation detection + step-size restore.

This is the "stop adding mechanisms" redesign.  It throws away the whole UPCL
machinery (5-action space, descriptor, non-parametric response model, ARD,
UCB/margin/cost decision rule, exploration schedule, s_hat, novelty
prototypes) and keeps exactly two mechanisms, both justified by the DE review
("DE review, component decomposition & method genealogy, 2026"):

  1. detect -- the population best has not improved by ``tol`` for ``window``
     consecutive generations (the review's "unproductive search" criterion,
     Eq. 10.4, reduced to its progress term);
  2. act    -- while stalled, multiply the host's proposal displacement
     d = u - x by ``factor`` (then shrink back into the box).  This restores
     the effective length of a collapsed difference vector, i.e. it "injects
     spread" without introducing any extra mechanism (review Sec. 10.3.5:
     the least invasive place to raise the perturbation scale).

Otherwise the layer is a pure pass-through: bit-for-bit identical to the bare
host, with a deterministic (seed-free) controller and zero extra evaluations.
"""
from __future__ import annotations

import time

import numpy as np

from run_upcl_cec import N_GRID, _grid_interp


class StagnationStepController:
    """Deterministic two-mechanism controller (stall detect + step restore)."""

    def __init__(self, dim, lb, ub, window=30, tol=1e-12, factor=3.0):
        self.dim = int(dim)
        self.lb = _as_vec(lb, dim)
        self.ub = _as_vec(ub, dim)
        self.window = int(window)
        self.tol = float(tol)
        self.factor = float(factor)

        self._last_best = None
        self._count = 0
        self._active = False

        # diagnostics
        self.generations = 0
        self.stagnation_gens = 0
        self.n_proposals = 0
        self.n_interventions = 0

    # -- host hooks -------------------------------------------------------
    def begin_generation(self, pop, fitness):
        self.generations += 1
        best = float(np.min(fitness))
        if self._last_best is not None:
            if best < self._last_best - self.tol:
                self._count = 0
            else:
                self._count += 1
        self._last_best = best
        self._active = self._count >= self.window
        if self._active:
            self.stagnation_gens += 1

    def propose(self, x, u, f_x):
        self.n_proposals += 1
        if not self._active:
            return u
        d = u - x
        d2 = d * self.factor
        t = _shrink_scale(x, d2, self.lb, self.ub)
        self.n_interventions += 1
        if t >= 1.0:
            return x + d2
        return x + t * d2

    def observe(self, f_new):
        # route-1 keeps no per-action response memory.
        pass

    # -- diagnostics ------------------------------------------------------
    def stats(self):
        return {
            'window': self.window,
            'tol': self.tol,
            'factor': self.factor,
            'generations': self.generations,
            'stagnation_gens': self.stagnation_gens,
            'stagnation_frac': round(
                self.stagnation_gens / max(1, self.generations), 6),
            'n_proposals': self.n_proposals,
            'n_interventions': self.n_interventions,
            'intervention_rate': round(
                self.n_interventions / max(1, self.n_proposals), 6),
        }


def _as_vec(v, dim):
    a = np.asarray(v, dtype=float)
    if a.ndim == 0:
        return np.full(dim, float(a))
    return a.reshape(-1)


def _shrink_scale(x, d, lb, ub):
    """Largest t in [0, 1] such that x + t*d stays inside [lb, ub]."""
    t = 1.0
    pos = d > 0.0
    if np.any(pos):
        t = min(t, float(np.min((ub[pos] - x[pos]) / d[pos])))
    neg = d < 0.0
    if np.any(neg):
        t = min(t, float(np.min((lb[neg] - x[neg]) / d[neg])))
    return max(0.0, t)


def run_route1_arm(host_name, func, dim, seed, max_evals, pop_size,
                   window=30, tol=1e-12, factor=3.0, measure=True):
    """Run the bare host with the route-1 controller attached.

    The returned record mirrors ``run_upcl_cec.run_arm`` so downstream
    analysis can read it unchanged.
    """
    import de_hosts

    host = de_hosts.get_host(host_name, dim, func.lb, func.ub, seed=seed,
                             pop_size=pop_size)
    ctrl = StagnationStepController(dim, func.lb, func.ub,
                                    window=window, tol=tol, factor=factor)
    host.gen_begin_fn = ctrl.begin_generation
    host.post_eval_fn = ctrl.observe

    upcl_time = 0.0
    if measure:
        _raw = ctrl.propose

        def _timed(x, u, f_x, _raw=_raw):
            nonlocal upcl_time
            t0 = time.perf_counter()
            r = _raw(x, u, f_x)
            upcl_time += time.perf_counter() - t0
            return r

        host.proposal_fn = _timed
    else:
        host.proposal_fn = ctrl.propose

    t0 = time.perf_counter()
    best_f, _best_x, conv, evals = host.run(func, max_evals)
    wall = time.perf_counter() - t0

    grid = np.linspace(0.0, max_evals, N_GRID + 1)[1:]
    err_curve = _grid_interp(evals, conv, grid) - func.f_opt
    arm = f'route1_w{window}_f{factor:g}'
    return {
        'host': host_name,
        'func': func.label,
        'fid': func.fid,
        'category': func.category,
        'suite': func.suite,
        'dim': dim,
        'seed': int(seed),
        'arm': arm,
        'max_evals': int(max_evals),
        'nevals': int(host.nevals),
        'err_final': float(best_f - func.f_opt),
        'err_curve': [float(v) for v in err_curve],
        'wall_time_s': float(wall),
        'upcl_decision_time_s': float(upcl_time),
        'grid': [float(v) for v in grid],
        'upcl': ctrl.stats(),
    }

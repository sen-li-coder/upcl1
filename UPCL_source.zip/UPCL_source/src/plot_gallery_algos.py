# -*- coding: utf-8 -*-
"""Gallery (batch 3): ALGORITHM-level view of 30 hosts, 6 panels (no convergence curves).
   (a) diverging lollipop  (b) rank bump chart  (c) parallel coordinates
   (d) t-SNE/PCA embed  (e) rose small-multiples  (f) capacity x gain quadrant
Run: python src/plot_gallery_algos.py
"""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import patheffects as pe

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

MECH = ['rho', 'theta', 'eta', 'kappa', 'nu']
MECH_LABEL = {'rho': 'rho (step)', 'theta': 'theta (align)', 'eta': 'eta (elite)',
              'kappa': 'kappa (crowd)', 'nu': 'nu (novel)'}
MECH_COLUMN = {'rho': 'rho_step_effect', 'theta': 'theta_align_effect',
               'eta': 'eta_elite_effect', 'kappa': 'kappa_crowd_effect',
               'nu': 'nu_novel_effect'}
MECH_COL = {'rho': '#1f77b4', 'theta': '#2ca02c', 'eta': '#ff7f0e',
            'kappa': '#d62728', 'nu': '#9467bd'}
LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return np.nan


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8, 'axes.labelsize': 7, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 5.5, 'ytick.labelsize': 5.5,
        'legend.fontsize': 5.5, 'legend.frameon': False, 'figure.dpi': 300})


def _label(ax, s):
    ax.text(-0.10, 1.07, s, transform=ax.transAxes, fontsize=10, fontweight='bold', va='top')


def _txt(ax, x, y, s, **kw):
    ax.text(x, y, s, fontsize=kw.get('fontsize', 5.2), color=kw.get('color', '#111'),
            ha=kw.get('ha', 'left'), va=kw.get('va', 'center'), zorder=6,
            path_effects=[pe.withStroke(linewidth=1.6, foreground='white')])


def load():
    hs = list(csv.DictReader(open(TABLES / 'mech30_host_summary.csv', encoding='utf-8', newline='')))
    d = {r['host']: r for r in hs}
    order = [r['host'] for r in sorted(hs, key=lambda r: int(r['bare_rank']))]
    return d, order


def embed(X):
    """t-SNE if sklearn available, else PCA via SVD."""
    try:
        from sklearn.manifold import TSNE
        perp = min(12, X.shape[0] - 1)
        return TSNE(n_components=2, perplexity=perp, init='pca',
                    learning_rate='auto', random_state=0).fit_transform(X)
    except Exception:
        Xc = X - X.mean(axis=0)
        U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
        return (Xc @ Vt.T)[:, :2]


def gallery_algos():
    d, order = load()
    hosts = order
    bare = np.array([_f(d[h]['bare_median_log10err']) for h in hosts])
    dec = np.array([_f(d[h]['dec_mean']) for h in hosts])
    dec_pos = np.array([_f(d[h]['dec_pos_cells']) for h in hosts])
    interv = np.array([_f(d[h]['intervention_rate']) for h in hosts])
    lvl = [d[h]['level'] for h in hosts]
    lcol = [LEVEL_COL[d[h]['level']] for h in hosts]
    M = np.array([[_f(d[h][MECH_COLUMN[m]]) for m in MECH] for h in hosts])

    fig = plt.figure(figsize=(16, 10.6))
    fig.subplots_adjust(left=0.06, right=0.97, top=0.93, bottom=0.05,
                        wspace=0.34, hspace=0.55)

    # ---- (a) diverging lollipop: dec_mean sorted by bare_rank ----
    ax = fig.add_subplot(2, 3, 1)
    y = np.arange(len(hosts))[::-1]  # rank1 at top
    for i in range(len(hosts)):
        ax.plot([0, dec[i]], [y[i], y[i]], color=lcol[i], lw=1.2, alpha=0.7, zorder=1)
        ax.scatter(dec[i], y[i], s=10 + dec_pos[i] * 120, color=lcol[i],
                   edgecolors='white', linewidths=0.4, zorder=3)
    ax.axvline(0, color='#333', lw=1.0)
    ax.set_yticks(y)
    ax.set_yticklabels([f'{h}' for h in hosts], fontsize=5.0)
    for i, h in enumerate(hosts):
        ax.get_yticklabels()[i].set_color(lcol[i])
    ax.set_xlabel('UPCL gain  dec (log10, + = improved)')
    ax.set_title('per-algorithm UPCL effect (size = share of improved cells)',
                 loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'a')

    # ---- (b) rank bump chart: bare rank -> bare+UPCL rank ----
    ax = fig.add_subplot(2, 3, 2)
    upcl_err = bare - dec
    upcl_rank = {h: i + 1 for i, h in enumerate(sorted(hosts, key=lambda h: upcl_err[hosts.index(h)]))}
    bare_rank = {h: int(d[h]['bare_rank']) for h in hosts}
    for h in hosts:
        r0, r1 = bare_rank[h], upcl_rank[h]
        if r1 < r0:
            c = '#2ca02c'  # improved (smaller rank)
        elif r1 > r0:
            c = '#d62728'  # degraded
        else:
            c = '#999999'
        ax.plot([0, 1], [-r0, -r1], color=c, lw=1.3, alpha=0.75,
                marker='o', markersize=3.2, markeredgewidth=0.3, markeredgecolor='white', zorder=3)
    ax.set_xticks([0, 1]); ax.set_xticklabels(['bare rank', 'bare + UPCL rank'], fontsize=6.5)
    ax.set_yticks(-np.arange(1, 31))
    ax.set_yticklabels([f'{h}' for h in hosts], fontsize=5.0)
    for i, h in enumerate(hosts):
        ax.get_yticklabels()[i].set_color(lcol[i])
    ax.set_xlim(-0.25, 1.25)
    ax.set_title('rank re-ordering under UPCL (green = up, red = down)',
                 loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'b')

    # ---- (c) parallel coordinates: 5 mechanisms + gain ----
    ax = fig.add_subplot(2, 3, 3)
    feats = np.column_stack([M, dec])
    feats_n = (feats - feats.min(0)) / (feats.max(0) - feats.min(0) + 1e-9)
    xs = np.arange(6)
    for i in range(len(hosts)):
        ax.plot(xs, feats_n[i], color=lcol[i], lw=1.0, alpha=0.5, zorder=1)
    for i in range(len(hosts)):
        ax.scatter(xs, feats_n[i], s=6, color=lcol[i], linewidths=0, zorder=3)
    ax.set_xticks(xs)
    ax.set_xticklabels(['rho', 'theta', 'eta', 'kappa', 'nu', 'dec'], fontsize=6)
    ax.set_ylim(0, 1); ax.set_yticks([])
    ax.set_title('mechanism + gain fingerprint (30 algos, level-coloured)',
                 loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'c')

    # ---- (d) t-SNE/PCA embed of (5 mech + capacity) ----
    ax = fig.add_subplot(2, 3, 4)
    X = np.column_stack([M, bare])
    Xz = (X - X.mean(0)) / (X.std(0) + 1e-9)
    P = embed(Xz)
    for i, h in enumerate(hosts):
        ax.scatter(P[i, 0], P[i, 1], s=34, color=lcol[i], edgecolors='white',
                   linewidths=0.6, zorder=3)
        _txt(ax, P[i, 0], P[i, 1], h, fontsize=4.9)
    ax.set_xlabel('dim 1'); ax.set_ylabel('dim 2')
    ax.set_title('algorithm embedding (mech + capacity)', loc='left', fontsize=7)
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ('top', 'right', 'bottom', 'left'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'd')

    # ---- (e) rose small-multiples: 30 hosts x 5 mechanisms ----
    base = fig.add_subplot(2, 3, 5)
    base.axis('off')
    pos = base.get_position()
    x0, y0, w, h = pos.x0, pos.y0, pos.width, pos.height
    gw, gh = w / 6, h / 5
    angles = np.linspace(0, 2 * np.pi, 5, endpoint=False).tolist()
    angles += angles[:1]
    Mn = (M - M.min()) / (M.max() - M.min() + 1e-9)
    for i, hname in enumerate(hosts):
        r, c = divmod(i, 6)
        axr = fig.add_axes([x0 + c * gw, y0 + (4 - r) * gh, gw * 0.94, gh * 0.94],
                           polar=True)
        v = Mn[i].tolist() + [Mn[i][0]]
        axr.plot(angles, v, color=lcol[i], lw=0.8)
        axr.fill(angles, v, color=lcol[i], alpha=0.28)
        axr.set_ylim(0, 1); axr.set_yticks([])
        axr.set_xticks([])
        axr.set_title(hname, fontsize=3.4, pad=1.0, color=lcol[i])
        axr.spines['polar'].set_linewidth(0.3)
        axr.grid(color='#dddddd', linewidth=0.2, alpha=0.5)
    base.text(0.5, 1.02, 'mechanism fingerprint per algorithm (5 axes: rho/theta/eta/kappa/nu)',
              transform=base.transAxes, ha='center', va='bottom', fontsize=7)
    base.text(-0.10, 1.07, 'e', transform=base.transAxes, fontsize=10, fontweight='bold', va='top')

    # ---- (f) capacity x gain quadrant ----
    ax = fig.add_subplot(2, 3, 6)
    med_bare = np.median(bare)
    lo = min(bare.min(), -0.2) * 1.05
    hi = max(bare.max(), 1.0) * 1.02
    dlo = min(dec.min(), -0.1) * 1.15
    dhi = max(dec.max(), 0.1) * 1.25
    ax.axvline(med_bare, color='#333', lw=0.9)
    ax.axhline(0, color='#333', lw=0.9)
    # quadrant shading
    ax.axvspan(lo, med_bare, dlo, 0, color='#2ca02c', alpha=0.05)      # strong + improved
    ax.axvspan(lo, med_bare, 0, dhi, color='#1f77b4', alpha=0.05)      # strong + degraded
    ax.axvspan(med_bare, hi, dlo, 0, color='#ff7f0e', alpha=0.05)      # weak + improved
    ax.axvspan(med_bare, hi, 0, dhi, color='#d62728', alpha=0.05)      # weak + degraded
    for i, h in enumerate(hosts):
        ax.scatter(bare[i], dec[i], s=10 + interv[i] * 160, color=lcol[i],
                   edgecolors='white', linewidths=0.5, zorder=3)
        _txt(ax, bare[i], dec[i], h, fontsize=4.9)
    ax.set_xlim(lo, hi); ax.set_ylim(dlo, dhi)
    ax.set_xlabel('capacity  log10 error (left = stronger)')
    ax.set_ylabel('UPCL gain  dec (log10)')
    ax.set_title('capacity x gain quadrants (size = intervention rate)',
                 loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'f')

    fig.suptitle('Gallery 3 — algorithm-level view of the 30 DE hosts under UPCL',
                 fontsize=12, y=0.97)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / 'gallery_algos.png', bbox_inches='tight')
    plt.close(fig)
    print('[gallery3] gallery_algos.png')


if __name__ == '__main__':
    _style()
    gallery_algos()
    print('[gallery3] done ->', FIG)

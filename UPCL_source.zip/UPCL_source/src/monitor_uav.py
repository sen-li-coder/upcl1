# -*- coding: utf-8 -*-
"""UAV intercept 实验进度监控：每 --interval 秒向日志追加一行快照。

进度口径（与 ``run_uav.run_task`` 的 flush 语义对齐）：
  * cells done = ``runs_complete >= --target-runs`` 的 cell 数
  * runs done  = 各 cell 的 ``runs_complete`` 之和减去 ``--base-runs``
                 （run 是真正的落盘单位，每完成一个 run 即 flush 一次 JSON，
                 粒度比 cell 更细，用来估 ETA）

``--base-runs`` 用于"在已有 R 次的基础上补跑到 N 次"的场景：旧 run 不算进度，
只统计本次新增的部分，否则一启动就显示 50% 完事、ETA 也全是错的。

用法：
    python -u src/monitor_uav.py --interval 600        # 每 10 分钟一行，常驻
    python -u src/monitor_uav.py --once                # 立即追加一行快照

    # 子集补跑（16 cells，3 -> 6 runs）
    python -u src/monitor_uav.py --interval 600 --target-runs 6 --base-runs 3 \
        --hosts DISK NL-SHADE-RSP DE/rand/1 DE/best/1 \
        --log results/apps/uav_r6_progress.log --stop-when-done
"""
import argparse
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'apps' / 'raw' / 'uav_intercept' / 'D30'

N_FIDS = 4
DEFAULT_TARGET_RUNS = 3
DEFAULT_CELLS = 29 * N_FIDS  # 全量实验：29 hosts x 4 fids


def _stem(p):
    return p.name.split('__')[0]


def snapshot(hosts, target_runs, base_runs):
    """返回 (cells_done, new_runs_done, n_files, rc 分布)。"""
    cells_done = 0
    new_runs = 0
    n_files = 0
    dist = {}
    if RAW.exists():
        for p in sorted(RAW.glob('*.json')):
            if hosts and _stem(p) not in hosts:
                continue
            try:
                j = json.loads(p.read_text(encoding='utf-8'))
            except Exception:
                continue
            n_files += 1
            rc = int(j.get('runs_complete', 0) or 0)
            dist[rc] = dist.get(rc, 0) + 1
            new_runs += max(0, min(rc, target_runs) - base_runs)
            if rc >= target_runs:
                cells_done += 1
    return cells_done, new_runs, n_files, dist


def fmt(elapsed, cfg, prev):
    cells_done, new_runs, n_files, dist = snapshot(
        cfg['hosts'], cfg['target'], cfg['base'])
    n_cells = cfg['cells']
    total_runs = n_cells * (cfg['target'] - cfg['base'])
    pct_runs = new_runs / total_runs * 100.0 if total_runs else 0.0
    ts = time.strftime('%Y-%m-%d %H:%M:%S')

    eta = ''
    if new_runs > 0 and new_runs < total_runs:
        sec_left = elapsed * (total_runs - new_runs) / new_runs
        eta = f'  ETA {sec_left / 3600:.2f}h'
    elif total_runs and new_runs >= total_runs:
        eta = '  DONE'

    speed = ''
    if prev and prev[0] is not None:
        d_runs = new_runs - prev[0]
        d_t = elapsed - prev[1]
        if d_t > 0:
            speed = f'  (+{d_runs} runs/{d_t / 60:.0f}m)'

    dist_s = ' '.join(f'{k}:{v}' for k, v in sorted(dist.items()))
    return (f'[{ts}] cells {cells_done}/{n_cells}  '
            f'new runs {new_runs}/{total_runs} ({pct_runs:.1f}%)  '
            f'files {n_files}{speed}{eta}  rc[{dist_s}]')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--interval', type=int, default=600)
    ap.add_argument('--once', action='store_true')
    ap.add_argument('--hosts', nargs='*', default=None,
                    help='宿主名（用文件名的连字符形式，如 DE/rand/1 或 DE-rand-1）；'
                         '省略=全部文件')
    ap.add_argument('--target-runs', type=int, default=DEFAULT_TARGET_RUNS,
                    help='每个 cell 的目标 run 数（默认 %d）' % DEFAULT_TARGET_RUNS)
    ap.add_argument('--base-runs', type=int, default=0,
                    help='已有、不计入进度的 run 数（补跑场景填原 R）')
    ap.add_argument('--cells', type=int, default=None,
                    help='预期 cell 总数（默认按 hosts 推算，缺省 %d）' % DEFAULT_CELLS)
    ap.add_argument('--min-runs', type=int, default=None,
                    help='废弃别名，等价于 --target-runs')
    ap.add_argument('--stop-when-done', action='store_true',
                    help='全部 cell 达标后退出，不留常驻进程')
    ap.add_argument('--log', type=Path,
                    default=ROOT / 'results' / 'apps' / 'uav_progress.log')
    args = ap.parse_args()

    target = args.min_runs if args.min_runs is not None else args.target_runs
    hosts = None
    if args.hosts:
        hosts = {h.replace('/', '-') for h in args.hosts}
    n_cells = args.cells or (len(hosts) * N_FIDS if hosts else DEFAULT_CELLS)
    cfg = {'hosts': hosts, 'target': target, 'base': args.base_runs,
           'cells': n_cells}

    args.log.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    def write(line):
        with open(args.log, 'a', encoding='utf-8') as fh:
            fh.write(line + '\n')
        print(line, flush=True)

    write(f'# uav_intercept D30 monitor start  hosts={sorted(hosts) if hosts else "ALL"}'
          f'  cells={n_cells}  runs {args.base_runs}->{target}'
          f'  new work={n_cells * (target - args.base_runs)} runs'
          f'  log={args.log}')

    prev = None
    while True:
        line = fmt(time.time() - t0, cfg, prev)
        write(line)
        cells_done, new_runs, _n, _d = snapshot(hosts, target, args.base_runs)
        prev = (new_runs, time.time() - t0)
        if args.stop_when_done and cells_done >= n_cells:
            write(f'# all {n_cells} cells reached {target} runs, monitor exit')
            break
        if args.once:
            break
        time.sleep(args.interval)


if __name__ == '__main__':
    main()

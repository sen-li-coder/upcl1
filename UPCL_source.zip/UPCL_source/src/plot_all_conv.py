# -*- coding: utf-8 -*-
"""Full convergence gallery + UPCL-positive gallery."""
import json, csv
from pathlib import Path
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw'
TAB = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
CONV = FIG / 'conv_all'
POS = FIG / 'conv_positive'
FLOOR = 1e-8
LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}
GREEN, RED, GREY = '#1a9850', '#d73027', '#555555'
_cache = {}


def load_cell(suite, dim, hf, fid):
    key = (suite, dim, hf, fid)
    if key in _cache:
        return _cache[key]
    p = RAW / suite / dim / f'{hf}__F{fid}.json'
    if not p.exists():
        _cache[key] = None
        return None
    d = json.load(open(p, encoding='utf-8'))
    runs = d['runs']
    r0 = runs[0]
    arm = 'upcl' if 'upcl' in r0 else 'full'
    grid = np.asarray(r0['bare']['grid'], float)
    bare = np.array([r['bare']['err_curve'] for r in runs], float)
    upcl = np.array([r[arm]['err_curve'] for r in runs], float)
    bf = np.array([r['bare']['err_final'] for r in runs], float)
    uf = np.array([r[arm]['err_final'] for r in runs], float)
    dec = float(np.log10(max(np.median(bf), FLOOR)) - np.log10(max(np.median(uf), FLOOR)))
    _cache[key] = dict(grid=grid, bare=bare, upcl=upcl, dec=dec)
    return _cache[key]


def host_meta():
    m = {}
    for r in csv.DictReader(open(TAB / 'mech30_host_summary.csv', encoding='utf-8')):
        m[r['host'].replace('/', '-')] = dict(name=r['host'], level=r['level'],
                                              rank=int(r['bare_rank']))
    return m


def build_index():
    idx = defaultdict(lambda: {'hosts': set(), 'fids': set()})
    for p in RAW.rglob('*.json'):
        suite, dim, name = p.relative_to(RAW).parts
        hf, fidpart = name.split('__')
        idx[(suite, dim)]['hosts'].add(hf)
        idx[(suite, dim)]['fids'].add(int(fidpart[1:-5]))
    return idx


def mlog(a):
    return np.median(np.log10(np.maximum(a, FLOOR)), axis=0)


def draw_mini(ax, cell):
    g = cell['grid']
    ax.plot(g, mlog(cell['bare']), color=GREY, lw=0.9)
    c = GREEN if cell['dec'] > 0 else RED
    ax.plot(g, mlog(cell['upcl']), color=c, lw=1.0, ls='--')
    ax.set_xlim(0, g[-1])
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color('#d8d8d8'); s.set_linewidth(0.4)
    ax.text(0.98, 0.02, f'{cell["dec"]:+.2f}', transform=ax.transAxes,
            ha='right', va='bottom', fontsize=4.6, color=c,
            bbox=dict(fc='white', ec='none', pad=0.3, alpha=0.6))


def plot_full(index, meta):
    CONV.mkdir(parents=True, exist_ok=True)
    order = [('cec2017', 'D30'), ('cec2022', 'D10'), ('cec2022', 'D20'),
             ('cec2017', 'D50'), ('cec2013', 'D10')]
    for suite, dim in order:
        if (suite, dim) not in index:
            continue
        hosts = sorted(index[(suite, dim)]['hosts'],
                       key=lambda h: (meta.get(h, {}).get('rank', 999), h))
        fids = sorted(index[(suite, dim)]['fids'])
        per = 4
        for pi in range((len(fids) + per - 1) // per):
            sub = fids[pi * per:(pi + 1) * per]
            nrow, ncol = len(hosts), len(sub)
            fig, axes = plt.subplots(nrow, ncol,
                                     figsize=(1.7 + ncol * 2.6, 0.8 + nrow * 0.60),
                                     squeeze=False)
            fig.subplots_adjust(left=0.21, right=0.98, top=0.93, bottom=0.03,
                                hspace=0.42, wspace=0.14)
            for i, h in enumerate(hosts):
                for j, fid in enumerate(sub):
                    cell = load_cell(suite, dim, h, fid)
                    if cell:
                        draw_mini(axes[i, j], cell)
            for j, fid in enumerate(sub):
                axes[0, j].set_title(f'F{fid}', fontsize=7.5)
            for i, h in enumerate(hosts):
                lvl = meta.get(h, {}).get('level', 'x')
                col = LEVEL_COL.get(lvl, '#888888')
                nm = meta.get(h, {}).get('name', h)
                y = 0.03 + (nrow - 1 - i) * (0.90 / nrow) + 0.45 / nrow
                fig.text(0.01, y, nm, fontsize=5.5, ha='left', va='center',
                         color=col, family='monospace')
            fig.suptitle(f'{suite}  D={dim[-2:]}   '
                         f'solid=bare  dashed=+UPCL  green=improve red=degrade',
                         fontsize=8)
            fig.savefig(CONV / f'{suite}_{dim}_p{pi + 1:02d}.png',
                        bbox_inches='tight')
            plt.close(fig)
            print(f'  [full] {suite} {dim} p{pi + 1:02d} '
                  f'({nrow} alg x {ncol} fn)')


def draw_full_cell(ax, cell, row, name):
    g = cell['grid']
    ax.plot(g, mlog(cell['bare']), color=GREY, lw=1.3)
    ax.plot(g, mlog(cell['upcl']), color=GREEN, lw=1.5, ls='--')
    ax.set_xlim(0, g[-1])
    xt = np.linspace(0, g[-1], 3)
    ax.set_xticks(xt)
    ax.set_xticklabels([f'{int(v/1000)}k' for v in xt], fontsize=6.5)
    ax.tick_params(labelsize=6.5)
    ax.grid(color='#ececec', lw=0.4)
    ax.set_axisbelow(True)
    ax.set_title(f'{name}  ·  F{row["fid"]}', fontsize=8, loc='left')
    ax.text(0.98, 0.97, f'{row["suite"][-4:]} D{row["dim"][-2:]}\n'
            f'dec = {cell["dec"]:+.2f}', transform=ax.transAxes,
            ha='right', va='top', fontsize=6.5, color=GREEN)


def plot_positive(index, meta):
    POS.mkdir(parents=True, exist_ok=True)
    rows = []
    for (suite, dim), d in index.items():
        for h in d['hosts']:
            for fid in d['fids']:
                c = load_cell(suite, dim, h, fid)
                if c and c['dec'] > 0:
                    rows.append(dict(suite=suite, dim=dim, hf=h, fid=fid,
                                     dec=c['dec'],
                                     name=meta.get(h, {}).get('name', h)))
    rows.sort(key=lambda r: -r['dec'])
    per = 20
    pages = (len(rows) + per - 1) // per
    for pi in range(pages):
        sub = rows[pi * per:(pi + 1) * per]
        fig, axes = plt.subplots(5, 4, figsize=(14, 11))
        fig.subplots_adjust(left=0.07, right=0.97, top=0.95, bottom=0.06,
                            hspace=0.55, wspace=0.30)
        for k, row in enumerate(sub):
            ax = axes[k // 4, k % 4]
            c = load_cell(row['suite'], row['dim'], row['hf'], row['fid'])
            if c:
                draw_full_cell(ax, c, row, row['name'])
        for k in range(len(sub), 20):
            axes[k // 4, k % 4].axis('off')
        fig.suptitle(f'UPCL-positive cells (dec > 0)  —  page {pi + 1}/{pages}  '
                     f'sorted by dec desc   (grey=bare, green=+UPCL)', fontsize=10)
        fig.savefig(POS / f'pos_p{pi + 1:03d}.png', bbox_inches='tight')
        plt.close(fig)
        print(f'  [pos] page {pi + 1:03d}/{pages} ({len(sub)} cells)')
    return rows


if __name__ == '__main__':
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8})
    meta = host_meta()
    index = build_index()
    print(f'index: {len(index)} suite/dim pairs, '
          f'{sum(len(v["hosts"]) * len(v["fids"]) for v in index.values())} cells')
    plot_full(index, meta)
    rows = plot_positive(index, meta)
    print(f'DONE: {len(rows)} positive cells -> {POS}')

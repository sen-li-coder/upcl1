# -*- coding: utf-8 -*-
"""Zero-reference band for the paired intervention gain.

Revision analysis added in response to the referee point that a
non-significant Wilcoxon test cannot establish the absence of an effect
(absence of evidence is not evidence of absence).

The layer's effect on one cell is

    dec = log10(median err_bare) - log10(median err_upcl)

computed exactly as ``analyze_upcl_cec.py`` does it (``FLOOR = 1e-8``, thirty
paired runs per cell, cell-level median of ``err_final``).  The question the
band answers is: how large is dec when *both* arms are drawn from the same
distribution?  It is built per cell by bootstrapping two independent
thirty-run medians from the bare arm of that same cell, so it measures the
sampling noise of our own estimator rather than an independent replication
band.  A disjoint 15/15 split is reported alongside as a conservative variant.

Cells whose bare arm already median-converges to machine precision
(log10 median bare <= -6) carry no resolution for a log-error difference and
are excluded and counted.

Outputs (``results/cec/tables``):

    null_band_summary.csv   one row per block
    null_band_hosts.csv     one row per (block, host)

Run::

    python src/analyze_null_band.py
"""
import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import t as t_dist

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw'
TABLES = ROOT / 'results' / 'cec' / 'tables'

FLOOR = 1e-8          # same floor as analyze_upcl_cec.py
RUNS = 30             # a cell that is complete has thirty paired runs
MIN_MED = -6.0        # log10 scale: below this the cell has no resolution
N_BOOT = 40           # bootstrap replicates per cell
MARGIN = 0.05         # equivalence margin in decades (TOST)
BLOCKS = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10), ('cec2022', 20))
SEED = 20261022


def _logs(path):
    """Return (log10 bare errors, log10 wrapped errors, host) or None."""
    with open(path, encoding='utf-8') as fh:
        d = json.load(fh)
    runs = [r for r in d.get('runs') or () if 'bare' in r and 'upcl' in r]
    if len(runs) < RUNS:
        return None
    b = np.array([r['bare']['err_final'] for r in runs], float)
    w = np.array([r['upcl']['err_final'] for r in runs], float)
    if not (np.all(np.isfinite(b)) and np.all(np.isfinite(w))):
        return None
    return (np.log10(np.maximum(b, FLOOR)), np.log10(np.maximum(w, FLOOR)),
            d.get('host'))


def _tost(x, margin):
    """Two one-sided tests: H0 |mean| >= margin against equivalence."""
    x = np.asarray(x, float)
    n = x.size
    if n < 4:
        return float('nan')
    m = float(x.mean())
    se = float(x.std(ddof=1) / np.sqrt(n))
    if se == 0:
        return 0.0 if abs(m) < margin else 1.0
    p1 = float(1.0 - t_dist.cdf((m + margin) / se, n - 1))
    p2 = float(t_dist.cdf((m - margin) / se, n - 1))
    return max(p1, p2)


def run():
    rng = np.random.default_rng(SEED)
    summary, hosts = [], []
    for suite, dim in BLOCKS:
        cells = sorted((RAW / suite / f'D{dim}').glob('*.json'))
        obs, boot, split, per_host = [], [], [], {}
        n_skip = 0
        for path in cells:
            got = _logs(path)
            if got is None:
                n_skip += 1
                continue
            lb, lw, host = got
            med_b = float(np.median(lb))
            if med_b < MIN_MED:
                n_skip += 1
                continue
            dec = float(np.log10(max(10.0 ** med_b, FLOOR))
                        - np.log10(max(10.0 ** float(np.median(lw)), FLOOR)))
            obs.append(dec)
            per_host.setdefault(host, []).append(dec)
            for _ in range(N_BOOT):
                i = rng.integers(0, RUNS, RUNS)
                j = rng.integers(0, RUNS, RUNS)
                boot.append(float(np.median(lb[i]) - np.median(lb[j])))
                idx = rng.permutation(RUNS)
                split.append(float(np.median(lb[idx[:RUNS // 2]])
                                    - np.median(lb[idx[RUNS // 2:]])))
        if not obs:
            continue
        obs = np.array(obs)
        boot = np.array(boot)
        split = np.array(split)
        lo, hi = np.percentile(boot, [2.5, 97.5])
        slo, shi = np.percentile(split, [2.5, 97.5])
        hmeans = np.array([float(np.mean(v)) for v in per_host.values()])
        summary.append(dict(
            suite=suite, dim=dim,
            n_cells_used=len(obs), n_cells_skipped=n_skip,
            dec_median=np.median(obs), dec_mean=obs.mean(),
            dec_q25=np.percentile(obs, 25), dec_q75=np.percentile(obs, 75),
            dec_p025=np.percentile(obs, 2.5), dec_p975=np.percentile(obs, 97.5),
            dec_abs_median=np.median(np.abs(obs)),
            band_sd=boot.std(), band_p025=lo, band_p975=hi,
            band_q25=np.percentile(boot, 25), band_q75=np.percentile(boot, 75),
            band_half_width=0.5 * (hi - lo),
            split_p025=slo, split_p975=shi,
            frac_in_band=float(np.mean((obs >= lo) & (obs <= hi))),
            frac_abs_le_margin=float(np.mean(np.abs(obs) <= MARGIN)),
            frac_neg=float(np.mean(obs < -MARGIN)),
            frac_pos=float(np.mean(obs > MARGIN)),
            frac_neg_all=float(np.mean(obs < 0)),
            n_hosts=len(hmeans), host_mean=hmeans.mean(),
            host_sd=hmeans.std(ddof=1) if hmeans.size > 1 else float('nan'),
            tost_host_p=_tost(hmeans, MARGIN),
            tost_cell_p=_tost(obs, MARGIN),
            margin=MARGIN))
        for host, vals in sorted(per_host.items()):
            v = np.array(vals)
            hosts.append(dict(suite=suite, dim=dim, host=host,
                              n_cells=v.size, dec_mean=v.mean(),
                              dec_median=np.median(v),
                              in_band=float(np.mean((v >= lo) & (v <= hi)))))

    TABLES.mkdir(parents=True, exist_ok=True)
    with open(TABLES / 'null_band_summary.csv', 'w', newline='',
              encoding='utf-8') as fh:
        wr = csv.DictWriter(fh, fieldnames=list(summary[0]))
        wr.writeheader()
        wr.writerows(summary)
    with open(TABLES / 'null_band_hosts.csv', 'w', newline='',
              encoding='utf-8') as fh:
        wr = csv.DictWriter(fh, fieldnames=list(hosts[0]))
        wr.writeheader()
        wr.writerows(hosts)

    for r in summary:
        print('[band] %s D%d  cells %d (skip %d)  dec med %+.4f  '
              'band sd %.4f 95%% [%+.4f, %+.4f]  in-band %.1f%%  '
              '|dec|<=%.2f %.1f%%  TOST(host) p=%.2g'
              % (r['suite'], r['dim'], r['n_cells_used'], r['n_cells_skipped'],
                 r['dec_median'], r['band_sd'], r['band_p025'],
                 r['band_p975'], 100 * r['frac_in_band'], r['margin'],
                 100 * r['frac_abs_le_margin'], r['tost_host_p']))
        print('        neg %+.2f%%  pos %+.2f%%  (beyond margin: neg %.1f%% '
              'pos %.1f%%)' % (100 * r['frac_neg_all'], 100 * (1 - r['frac_neg_all']),
                               100 * r['frac_neg'], 100 * r['frac_pos']))
    print('[band] written ->', TABLES / 'null_band_summary.csv')
    return summary


if __name__ == '__main__':
    run()

# -*- coding: utf-8 -*-
"""Gallery (batch 1): 30-host x 4-category GAIN panorama, 6 panels.
   (a) heatmap  (b) spaghetti lines  (c) violin  (d) bubble scatter
   (e) errorbar  (f) rank-vs-gain
Run: python src/plot_gallery_gain.py
"""
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib import patheffects as pe

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

CATS = ['unimodal', 'multimodal', 'hybrid', 'composite']
CAT_LABEL = {'unimodal': 'Unimodal', 'multimodal': 'Multimodal',
             'hybrid': 'Hybrid', 'composite': 'Composite'}
LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}
CAT_COL = {'unimodal': '#1f77b4', 'multimodal': '#2ca02c',
           'hybrid': '#ff7f0e', 'composite': '#d62728'}
MECH = {'rho': 'rho_step_effect', 'theta': 'theta_align_effect',
        'eta': 'eta_elite_effect', 'kappa': 'kappa_crowd_effect',
        'nu': 'nu_novel_effect'}


def _f(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return np.nan
    return v if np.isfinite(v) else np.nan


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8, 'axes.labelsize': 7, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 5.5, 'ytick.labelsize': 5.5,
        'legend.fontsize': 5.5, 'legend.frameon': False, 'figure.dpi': 300})


def load():
    cells = list(csv.DictReader(open(TABLES / 'mech30_cells.csv', encoding='utf-8', newline='')))
    hs = {r['host']: r for r in csv.DictReader(open(TABLES / 'mech30_host_summary.csv', encoding='utf-8', newline=''))}
    order = sorted(hs, key=lambda h: int(hs[h]['bare_rank']))
    level = {h: hs[h]['level'] for h in order}
    rank = {h: int(hs[h]['bare_rank']) for h in order}
    agg = defaultdict(list)
    for r in cells:
        agg[(r['host'], r['category'])].append(r)
    gain, bare, interv, mech = {}, {}, {}, {}
    for (h, c), rs in agg.items():
        def mean(k):
            return np.nanmean([_f(x[k]) for x in rs])
        gain[(h, c)] = mean('dec_median')
        bare[(h, c)] = mean('bare_median_log10err')
        interv[(h, c)] = mean('intervention_rate')
        mech[(h, c)] = {m: mean(col) for m, col in MECH.items()}
    return cells, order, level, rank, gain, bare, interv, mech


def panel_label(ax, s):
    ax.text(-0.14, 1.06, s, transform=ax.transAxes, fontsize=9, fontweight='bold', va='top')


def gallery_gain():
    cells, order, level, rank, gain, bare, interv, mech = load()
    G = np.array([[gain[(h, c)] for c in CATS] for h in order])
    B = np.array([[bare[(h, c)] for c in CATS] for h in order])
    R = np.array([rank[h] for h in order])

    fig = plt.figure(figsize=(12.5, 8.2))
    fig.subplots_adjust(left=0.10, right=0.97, top=0.94, bottom=0.07,
                        wspace=0.42, hspace=0.52)

    # (a) heatmap 30x4 gain
    ax = fig.add_subplot(2, 3, 1)
    vmax = np.nanmax(np.abs(G))
    im = ax.imshow(G, cmap='RdBu_r', norm=TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax), aspect='auto')
    ax.set_xticks(range(4)); ax.set_xticklabels([CAT_LABEL[c][:6] for c in CATS], fontsize=6)
    ax.set_yticks(range(len(order)))
    ax.set_yticklabels(order, fontsize=5.2)
    for i, h in enumerate(order):
        ax.get_yticklabels()[i].set_color(LEVEL_COL[level[h]])
    for i in range(len(order)):
        for j in range(4):
            ax.text(j, i, f'{G[i, j]:.2f}', ha='center', va='center', fontsize=4.6,
                    color='#111' if abs(G[i, j]) < 0.55 * vmax else 'white')
    ax.set_title('gain (dec) 30 host x 4 category', loc='left', fontsize=7)
    panel_label(ax, 'a')
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
    cbar.ax.tick_params(labelsize=4.5)

    # (b) spaghetti lines (30 hosts across 4 categories)
    ax = fig.add_subplot(2, 3, 2)
    for i, h in enumerate(order):
        ax.plot(range(4), G[i], color=LEVEL_COL[level[h]], alpha=0.35, lw=0.8, zorder=1)
    for lv in ['0', '1', '2', '3']:
        idx = [i for i, h in enumerate(order) if level[h] == lv]
        ax.plot(range(4), G[idx].mean(0), color=LEVEL_COL[lv], lw=2.2,
                marker='o', markersize=4, label=f'L{lv}', zorder=3)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.set_xticks(range(4)); ax.set_xticklabels([CAT_LABEL[c][:6] for c in CATS], fontsize=6)
    ax.set_ylabel('gain (dec)')
    ax.set_title('per-host gain across categories (level means bold)', loc='left', fontsize=7)
    ax.legend(loc='lower right', ncol=2)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    panel_label(ax, 'b')

    # (c) violin per category (cell-level)
    ax = fig.add_subplot(2, 3, 3)
    data = {c: [_f(r['dec_median']) for r in cells if r['category'] == c] for c in CATS}
    data = {c: [v for v in vs if np.isfinite(v)] for c, vs in data.items()}
    vp = ax.violinplot([data[c] for c in CATS], positions=range(4), showmedians=True,
                       widths=0.8)
    for b, c in zip(vp['bodies'], CATS):
        b.set_facecolor(CAT_COL[c]); b.set_alpha(0.45)
    for p in ['cbars', 'cmedians']:
        vp[p].set_color('#333'); vp[p].set_linewidth(0.8)
    for j, c in enumerate(CATS):
        x = np.random.default_rng(0).normal(j, 0.08, len(data[c]))
        ax.scatter(x, data[c], s=3, color=CAT_COL[c], alpha=0.4, linewidths=0)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.set_xticks(range(4)); ax.set_xticklabels([CAT_LABEL[c][:6] for c in CATS], fontsize=6)
    ax.set_ylabel('gain (dec)')
    ax.set_title('gain distribution by category', loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    panel_label(ax, 'c')

    # (d) bubble scatter: capacity x gain, size=intervention, color=category
    ax = fig.add_subplot(2, 3, 4)
    for c in CATS:
        xs = [bare[(h, c)] for h in order]
        ys = [gain[(h, c)] for h in order]
        ss = [max(interv[(h, c)], 0.001) * 900 + 8 for h in order]
        ax.scatter(xs, ys, s=ss, c=CAT_COL[c], alpha=0.55, edgecolors='white',
                   linewidths=0.4, label=CAT_LABEL[c], zorder=3)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.set_xlabel('capacity (log10 error, lower = stronger)')
    ax.set_ylabel('gain (dec)')
    ax.set_title('capacity x gain (120 host-category, size=intervention)', loc='left', fontsize=7)
    ax.legend(loc='upper left', ncol=2)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    panel_label(ax, 'd')

    # (e) errorbar: mean + 95% CI per category
    ax = fig.add_subplot(2, 3, 5)
    for j, c in enumerate(CATS):
        g = G[:, j]
        m, se = g.mean(), g.std() / np.sqrt(len(g))
        ax.errorbar(j, m, yerr=1.96 * se, color=CAT_COL[c], fmt='o', ms=6,
                    capsize=4, elinewidth=1.4, zorder=3)
        ax.scatter([j] * len(g), g, s=10, color=CAT_COL[c], alpha=0.3,
                   linewidths=0, zorder=2)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.set_xticks(range(4)); ax.set_xticklabels([CAT_LABEL[c][:6] for c in CATS], fontsize=6)
    ax.set_ylabel('gain (dec)')
    ax.set_title('mean gain + 95% CI (n=30 hosts)', loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    panel_label(ax, 'e')

    # (f) rank vs gain scatter (30 hosts, colored by level)
    ax = fig.add_subplot(2, 3, 6)
    from scipy.stats import spearmanr
    mean_gain = np.array([G[i].mean() for i in range(len(order))])
    for i, h in enumerate(order):
        ax.scatter(R[i], mean_gain[i], s=30, color=LEVEL_COL[level[h]],
                   edgecolors='white', linewidths=0.4, zorder=3)
    # trend
    z = np.polyfit(R, mean_gain, 1)
    xs = np.linspace(R.min(), R.max(), 50)
    ax.plot(xs, np.polyval(z, xs), color='#666', lw=1.2, ls='--', zorder=2)
    r, p = spearmanr(R, mean_gain)
    ax.text(0.03, 0.04, f'rho={r:.2f} (p={p:.2g})', transform=ax.transAxes, fontsize=6)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.set_xlabel('bare rank (1 = strongest)')
    ax.set_ylabel('mean gain (dec)')
    ax.set_title('capability rank vs gain (30 hosts)', loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    panel_label(ax, 'f')

    fig.suptitle('Gallery 1 — UPCL intervention gain: 30 hosts x 4 problem categories',
                 fontsize=11, y=0.98)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / 'gallery_gain.png', bbox_inches='tight')
    plt.close(fig)
    print('[gallery1] gallery_gain.png')


if __name__ == '__main__':
    _style()
    gallery_gain()
    print('[gallery1] done ->', FIG)

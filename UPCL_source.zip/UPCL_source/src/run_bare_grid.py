# -*- coding: utf-8 -*-
"""Bare-only CEC baseline runner (no UPCL). Reuses existing bare runs and
preserves any upcl/full arm already on disk."""
import argparse, json, multiprocessing as mp, os, sys, threading, time
from pathlib import Path
import numpy as np

for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(_v, '1')

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cec_suites as CS
import de_hosts_cec as DHC
import run_upcl_cec as R  # noqa: E402  (import triggers DHC.register())

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'grid'
RUNS = 30
FES_MULT = R.FES_MULT
SEED_BASE = R.SEED_BASE
SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10), ('cec2022', 20))


def _seed_for(fid, dim, r):
    return SEED_BASE + dim * 1_000_003 + r * 7919 + fid * 31


def _path(suite, dim, host, fid):
    return OUT / 'raw' / suite / f'D{dim}' / f'{host.replace("/", "-")}__F{fid}.json'


def load_cell(path):
    """Return ({run_idx: entry}, second_arm) for an existing record file."""
    if not path.exists():
        return {}, None
    try:
        with open(path, encoding='utf-8') as fh:
            d = json.load(fh)
    except Exception:
        return {}, None
    have = d.get('arms', [])
    second = 'full' if 'full' in have else ('upcl' if 'upcl' in have else None)
    runs = {}
    for r in d.get('runs', []):
        idx = r.get('run')
        e = {'run': idx, 'seed': r.get('seed')}
        if isinstance(r.get('bare'), dict) and 'err_curve' in r['bare']:
            e['bare'] = r['bare']
        if second and isinstance(r.get(second), dict):
            e[second] = r[second]
        runs[idx] = e
    return runs, second


def _replace_retry(src, dst, attempts=10, delay=1.0):
    last = None
    for i in range(attempts):
        try:
            src.replace(dst)
            return
        except PermissionError as exc:
            last = exc
            time.sleep(delay * (i + 1))
    raise last


def run_cell(task):
    suite, dim = task['suite'], task['dim']
    host, fid = task['host'], task['fid']
    out_file = _path(suite, dim, host, fid)
    runs, second = load_cell(out_file)
    func = CS.get_function(suite, dim, fid)
    pop = DHC.pop_size_for(host, dim)
    max_evals = FES_MULT * dim
    t0 = time.perf_counter()
    for r in range(task['runs']):
        e = runs.get(r)
        if e is None:
            e = {'run': r, 'seed': _seed_for(fid, dim, r)}
            runs[r] = e
        if e.get('seed') is None:
            e['seed'] = _seed_for(fid, dim, r)
        if not (isinstance(e.get('bare'), dict) and 'err_curve' in e['bare']):
            e['bare'] = R.run_arm(host, func, dim, e['seed'], max_evals, None,
                                  pop_size=pop)
            print(f'[bare] {suite} D{dim} {host} F{fid} run {r + 1}/{task["runs"]}',
                  flush=True)
        arms = ['bare'] + ([second] if second else [])
        n_done = sum(1 for x in runs.values()
                     if isinstance(x.get('bare'), dict) and 'err_curve' in x['bare'])
        payload = {'suite': suite, 'dim': dim, 'host': host, 'fid': fid,
                   'func': func.name, 'category': func.category,
                   'max_evals': int(max_evals), 'runs_complete': n_done,
                   'arms': arms, 'runs': sorted(runs.values(), key=lambda x: x['run'])}
        out_file.parent.mkdir(parents=True, exist_ok=True)
        tmp = out_file.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh)
        _replace_retry(tmp, out_file)
    return ('done', f'{suite} D{dim} {host} F{fid}', time.perf_counter() - t0,
            task['missing'])


def plan(suites, hosts=None, runs=RUNS):
    host_list = hosts or list(DHC.CEC_HOST_ORDER)
    todo, missing_runs = [], 0
    for suite, dim in suites:
        fids = [f.fid for f in CS.get_suite(suite, dim)]
        for h in host_list:
            for fid in fids:
                loaded, _ = load_cell(_path(suite, dim, h, fid))
                miss = [r for r in range(runs)
                        if not (isinstance(loaded.get(r, {}).get('bare'), dict)
                                and 'err_curve' in loaded.get(r, {}).get('bare'))]
                if miss:
                    todo.append(dict(suite=suite, dim=dim, host=h, fid=fid,
                                     runs=runs, missing=len(miss)))
                    missing_runs += len(miss)
    return host_list, todo, missing_runs


def measured_bare_cost():
    out = {}
    for p in (OUT / 'raw').glob('*/*/*.json'):
        try:
            d = json.load(open(p, encoding='utf-8'))
        except Exception:
            continue
        for r in d.get('runs', []):
            b = r.get('bare')
            if isinstance(b, dict) and 'wall_time_s' in b:
                key = (d['suite'], d['dim'], b.get('host', d['host']))
                out.setdefault(key, []).append(float(b['wall_time_s']))
    return {k: float(np.mean(v)) for k, v in out.items()}


def report(suites, hosts=None, runs=RUNS, workers=None):
    host_list, todo, missing_runs = plan(suites, hosts, runs)
    print(f'hosts        : {len(host_list)}')
    print(f'cells to run : {len(todo)}')
    print(f'bare runs missing : {missing_runs}')
    cost = measured_bare_cost()
    if cost and todo:
        total = 0.0
        for t in todo:
            per = cost.get((t['suite'], t['dim'], t['host']))
            if per is None:
                # fall back to the same-dim suite mean, else any suite mean
                same = [v for (s, d, h), v in cost.items()
                        if s == t['suite'] and d == t['dim']]
                per = float(np.mean(same)) if same else 60.0
            total += per * t['missing']
        hours = total / 3600.0
        w = workers or max(1, (os.cpu_count() or 4) - 1)
        print(f'CPU cost     : {hours:.1f} h')
        print(f'wall clock   : ~{hours / w:.1f} h at {w} workers')
    return todo


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--plan', action='store_true')
    ap.add_argument('--suites', nargs='*', default=None)
    ap.add_argument('--dims', nargs='*', type=int, default=None)
    ap.add_argument('--hosts', nargs='*', default=None)
    ap.add_argument('--funcs', nargs='*', type=int, default=None)
    ap.add_argument('--runs', type=int, default=RUNS)
    ap.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 4) - 1))
    ap.add_argument('--limit', type=int, default=None)
    a = ap.parse_args(argv)

    suites = SUITES
    if a.suites:
        suites = tuple(s for s in SUITES if s[0] in a.suites)
    if a.dims:
        suites = tuple(s for s in suites if s[1] in a.dims)

    if a.plan:
        report(suites, a.hosts, a.runs, a.workers)
        return

    _, todo, _ = plan(suites, a.hosts, a.runs)
    if a.funcs:
        todo = [t for t in todo if t['fid'] in a.funcs]
    if a.limit:
        todo = todo[:a.limit]
    if not todo:
        print('[bare] nothing to run', flush=True)
        return
    report(suites, a.hosts, a.runs, a.workers)
    print(f'[bare] starting {len(todo)} cells on {a.workers} workers', flush=True)

    ctx = mp.get_context('spawn')
    t0 = time.perf_counter()
    done = 0
    total = len(todo)
    total_runs = sum(t['missing'] for t in todo)
    state = {'done': 0, 'runs': 0}

    def pct_line():
        el = time.perf_counter() - t0
        dc, dr = state['done'], state['runs']
        pc = 100.0 * dc / total
        pr = 100.0 * dr / total_runs if total_runs else 0.0
        if dr > 0:
            remain = (total_runs - dr) / (dr / el)
            eta = time.strftime('%m-%d %H:%M:%S',
                                time.localtime(time.time() + remain))
            left = f'{remain / 3600:.1f}h'
        else:
            eta = '--'
            left = '--'
        print(f'[bare] progress {el / 3600:.2f}h  '
              f'cells {dc}/{total} ({pc:.1f}%)  '
              f'runs {dr}/{total_runs} ({pr:.1f}%)  '
              f'left ~{left}  ETA {eta}', flush=True)

    def progress_loop():
        pct_line()
        while True:
            time.sleep(600)
            pct_line()

    threading.Thread(target=progress_loop, daemon=True).start()

    with ctx.Pool(a.workers) as pool:
        for status, what, dt, missing in pool.imap_unordered(run_cell, todo):
            done += 1
            state['done'] = done
            state['runs'] += missing
            el = time.perf_counter() - t0
            avg = el / done
            remain = avg * (total - done)
            eta = time.strftime('%m-%d %H:%M:%S', time.localtime(time.time() + remain))
            print(f'[bare] {done:4d}/{total} {status:5s} {what} '
                  f'{dt / 60.0:6.1f} min  elapsed {el / 3600:.1f}h  '
                  f'left ~{remain / 3600:.1f}h  ETA {eta}', flush=True)
    print(f'[bare] finished {done} cells in {(time.perf_counter() - t0) / 3600:.2f} h', flush=True)


if __name__ == '__main__':
    main()

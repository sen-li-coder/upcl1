# -*- coding: utf-8 -*-
"""构建 UPCL 手稿的中文翻译版（CEC 成对实验）。

数据与数值字段与英文版 ``build_upcl_paper_cec.py`` 完全一致：两者都从
``results/cec/tables`` 读取同一批表格，只有人类可读的短语（协议条目、
范围句子、图题标签）切换为中文。运行::

    python src/build_upcl_paper_cec_zh.py

生成 ``docs/UPCL_paper_zh.docx``。
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from ec_style import Paper                                    # noqa: E402
import paper_figures as PFG                                   # noqa: E402
import build_upcl_paper_cec as EN                             # noqa: E402
import upcl_part_front_zh as PF                               # noqa: E402
import upcl_part_bg_zh as PBG                                 # noqa: E402
import upcl_part_method_zh as PM                              # noqa: E402
import upcl_part_exp_cec_zh as PE                             # noqa: E402
import upcl_part_app_zh as PA                                 # noqa: E402
from upcl_refs import get_refs                                # noqa: E402

# 可按稿顺序渲染的部分；``build`` 接受子集，因此前三节可单独起草与传阅。
PARTS = ('front', 'bg', 'method', 'exp', 'app', 'back')


# ---------------------------------------------------------------------------
def _availability(P, S):
    """可复现性声明，包括实际使用的系数（中文版）。"""
    P.h1('数据、代码与系数')
    P.para(
        '该层通过三个回调附着于宿主——一个在每个代开始时，一个接收 '
        '$(x_i,u_i)$ 并返回要评估的提案，一个接收所得适应度连同该提案的'
        '去向。这里使用的宿主均未修改。每项比较仅凭种子调度即可复现：对'
        '维度 $D$ 下问题 $f$ 的第 $r$ 次运行，种子为 $s(r,f,D)$，且由宿主'
        '单独与附加 UPCL 的同一宿主共享，而层从独立生成器抽取，使宿主的随机'
        '序列不受触碰。'
        '逐比较结果，包括第 4 节使用的收敛与干预轨迹，由驱动器以 JSON 形式'
        '写入，该节的表格与图由这些文件生成而非手工编辑。')

    P.para(
        '下面的系数正是这里所报告的每项比较所用的。它们是层的超参数而非其'
        '性质：它们从各自在打分规则中所扮演的角色一次性固定，探索调度与'
        '自适应恒等裕量在发现层的早期版本会损害宿主后修订过一次，且没有'
        '任何东西按套件、维度、宿主或函数拟合。表 %d 列出这些系数。'
        % (P.tab_no + 1))

    cfg = {}
    try:
        from upcl_experiment import get_config
        cfg.update(get_config('default'))
    except Exception as exc:                                  # pragma: cover
        print('[UPCL-zh] default configuration unavailable:', exc)
    rows = [['$\\lambda$', '校正代价的权重', str(cfg.get('lam', '-'))],
            ['$\\mu_0$', '静态恒等裕量', str(cfg.get('margin', '-'))],
            ['$\\mu_1$', '自适应恒等裕量系数',
             str(cfg.get('margin_adapt', '-'))],
            ['$\\kappa_u$', '不确定惩罚', str(cfg.get('ucb_kappa', '-'))],
            ['$\\varepsilon_0\\!\\to\\!\\varepsilon_{\\min}$',
             '探索速率', f"{cfg.get('eps0', '-')} 至 "
                         f"{cfg.get('eps_min', '-')}"],
            ['$T_{\\varepsilon}$', '探索衰减所跨的代数',
             str(cfg.get('eps_gens', '-'))],
            ['$B$', '预算', '$10^{4}D$ 次评估'],
            ['$M$', '响应记忆容量', '按实现（256）']]
    P.table_caption('第 4 节每项比较所固定的系数。前六个是工作点；任何未列出'
                    '的都保持第 3 节所述的值。')
    P.table(['符号', '含义', '值'], rows, widths=[1.1, 3.6, 1.6], align='llr')


# ---------------------------------------------------------------------------
def build(out_path=None, stats=None, parts=PARTS):
    """渲染中文手稿；``parts`` 选择要输出的节。"""
    if isinstance(parts, str):
        parts = tuple(p.strip() for p in parts.split(',') if p.strip())
    unknown = [p for p in parts if p not in PARTS]
    if unknown:
        raise SystemExit(f'[UPCL-zh] unknown part(s): {unknown}; '
                         f'choose from {PARTS}')
    S = stats if stats is not None else EN.load_stats('zh')
    # 第 1、3 节的示意图按语言各绘一套，先选定语言再取图。
    PFG.set_lang('zh')
    P = Paper(lang='zh')
    if 'front' in parts:
        PF.build(P, S)
    if 'bg' in parts:
        PBG.build(P, S)
    if 'method' in parts:
        PM.build(P, S)
    if 'exp' in parts:
        PE.build(P, S)
    if 'app' in parts:
        PA.build(P, S)
    if 'back' in parts:
        PE._conclusion(P, S)
        _availability(P, S)
        PE._appendix(P, S)
    P.references(get_refs(), drop_uncited=True)
    if P.uncited_refs:
        print('[UPCL-zh] dropped %d uncited reference(s) from the list'
              % len(P.uncited_refs))
    if P.unknown_refs:
        print('[UPCL-zh] WARNING unknown reference keys:', P.unknown_refs)

    if out_path:
        out = Path(out_path)
    elif parts == PARTS:
        out = ROOT / 'docs' / 'UPCL_paper_zh.docx'
    else:
        out = ROOT / 'docs' / ('UPCL_paper_zh_' + '-'.join(parts) + '.docx')
    P.save(out)
    print('[UPCL-zh] written ->', out)
    print('[UPCL-zh] figures:', P.fig_no, 'tables:', P.tab_no)
    # 与英文版同源：手稿引用的图必须与 ``docs/figures`` 中的登记一一对应。
    PFG.audit(P.figure_files)
    return out


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out', nargs='?', default=None,
                    help='输出 .docx 路径')
    ap.add_argument('--parts', default=','.join(PARTS),
                    help=f'逗号分隔的 {PARTS} 子集')
    a = ap.parse_args()
    build(a.out, parts=a.parts)

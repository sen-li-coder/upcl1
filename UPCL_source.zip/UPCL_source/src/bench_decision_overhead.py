# -*- coding: utf-8 -*-
"""Single-process benchmark of the UPCL decision cost (Exp6, clean numbers).

The grid experiments record the wall-clock of a whole run, which is fine for a
paired comparison but noisy when many workers share the machine.  This script
measures the layer in isolation, on an otherwise idle process, and reports the
cost of one decision together with its breakdown over the layer's stages.

Usage
-----
    python bench_decision_overhead.py [budget] [suite] [dim] [fid] [host] [pop]

Defaults: 30000 cec2017 30 23 DE/rand/2.  Passing a population size as the
sixth argument overrides the recommended one (useful to separate the effect of
the population size from the effect of the dimension).

Reported numbers go straight into the Exp6 table of the paper:

* ``wall``          -- bare host vs host + layer, same seed, same budget;
* ``us/prop``       -- cost of one decision (the load-independent quantity);
* ``fobj``/``op``   -- reference costs of the objective and of a single small
                       numpy call, which bound what is achievable in pure numpy.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np                                             # noqa: E402

import cec_suites as CS                                        # noqa: E402
import de_hosts                                                # noqa: E402
import de_hosts_cec as DHC                                     # noqa: E402
from upcl_experiment import get_config                         # noqa: E402
from upcl_framework import UPCLController                      # noqa: E402

DHC.register()

budget = int(sys.argv[1]) if len(sys.argv) > 1 else 30000
suite = sys.argv[2] if len(sys.argv) > 2 else 'cec2017'
dim = int(sys.argv[3]) if len(sys.argv) > 3 else 30
fid = int(sys.argv[4]) if len(sys.argv) > 4 else 23
host = sys.argv[5] if len(sys.argv) > 5 else 'DE/rand/2'
if len(sys.argv) > 6:
    DHC.CEC_POP_SIZE[host] = int(sys.argv[6])

func = CS.get_function(suite, dim, fid)
seed = 1
pop = DHC.pop_size_for(host, dim)

acc = {}
acc_cpu = {}


def wrap(obj, name):
    """Time ``obj.name`` on both clocks.

    Wall-clock is contaminated as soon as anything else runs on the machine;
    process CPU time is not, which makes it the honest clock for a per-stage
    breakdown taken while an experiment grid is running.  The two agree to
    within a few percent on an idle machine.
    """
    raw = getattr(obj, name)

    def _w(*a, **k):
        c0 = time.process_time()
        t0 = time.perf_counter()
        r = raw(*a, **k)
        acc[name] = acc.get(name, 0.0) + (time.perf_counter() - t0)
        acc_cpu[name] = acc_cpu.get(name, 0.0) + (time.process_time() - c0)
        return r
    setattr(obj, name, _w)


c = UPCLController(dim, func.lb, func.ub, seed=seed + 977,
                   config=get_config('default'))
for n in ('propose', '_describe', '_select', '_apply', '_box_shrink',
          'observe', 'begin_generation'):
    wrap(c, n)
for n in ('weights', 'predict_all', 'add'):
    wrap(c.memory, n)

h = de_hosts.get_host(host, dim, func.lb, func.ub, seed=seed, pop_size=pop)
h.gen_begin_fn = c.begin_generation
h.proposal_fn = c.propose
h.post_eval_fn = c.observe

c0 = time.process_time()
t0 = time.perf_counter()
h.run(func, budget)
wall = time.perf_counter() - t0
cpu = time.process_time() - c0
nprop = c.n_proposals
st = c.stats()
print(f'{host} {suite} F{fid} D={dim} pop={pop} budget={budget} '
      f'nevals={h.nevals} proposals={nprop} wall={wall:.2f}s cpu={cpu:.2f}s  '
      f'rho={st["policy_rate"]:.3f} interv={st["intervention_rate"]:.3f}')
print(f'  {"stage":16s}{"wall-s":>10s}{"cpu-s":>10s}'
      f'{"wall us/prop":>15s}{"cpu us/prop":>15s}')
for k, v in sorted(acc.items(), key=lambda kv: -kv[1]):
    vc = acc_cpu.get(k, 0.0)
    print(f'  {k:16s}{v:10.3f}{vc:10.3f}{v / nprop * 1e6:15.2f}'
          f'{vc / nprop * 1e6:15.2f}')

h2 = de_hosts.get_host(host, dim, func.lb, func.ub, seed=seed, pop_size=pop)
c0 = time.process_time()
t0 = time.perf_counter()
h2.run(func, budget)
bare = time.perf_counter() - t0
bare_cpu = time.process_time() - c0
print(f'  bare wall {bare:.2f}s cpu {bare_cpu:.2f}s  nevals={h2.nevals}')
print(f'  overhead +{(cpu - bare_cpu) / nprop * 1e6:.2f} us per proposal (cpu)'
      f'  +{(cpu / bare_cpu - 1.0) * 100:.1f}% (cpu)'
      f'  |  +{(wall / bare - 1.0) * 100:.1f}% (wall, load dependent)')
print(f'  decision cost: {acc_cpu.get("propose", 0.0) / nprop * 1e6:.2f}'
      f' us/proposal (cpu)-+')

# --- reference costs on this machine --------------------------------------
n = 20000
xs = np.random.default_rng(0).uniform(-100, 100, (n, dim))
t0 = time.process_time()
for k in range(n):
    func(xs[k])
dt = time.process_time() - t0
fobj_us = dt / n * 1e6
print(f'  fobj alone: {fobj_us:.1f} us/eval')

a = np.zeros(dim)
t0 = time.process_time()
for _ in range(n):
    a = a + 1.0
dt = time.process_time() - t0
print(f'  one small numpy op: {dt / n * 1e6:.2f} us')
t0 = time.process_time()
for _ in range(n):
    float(np.dot(a, a))
dt = time.process_time() - t0
print(f'  float(np.dot): {dt / n * 1e6:.2f} us')
print(f'  => one decision costs '
      f'{acc_cpu.get("propose", 0.0) / nprop * 1e6 / max(fobj_us, 1e-9):.2f}'
      f' evaluations of the objective')

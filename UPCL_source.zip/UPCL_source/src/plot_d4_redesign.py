"""D4 observable-space structure redesign — candidate figures (temporary)."""
import sys
sys.path.insert(0, 'src')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import squareform
from sklearn.decomposition import PCA
from analyze_mech_attribution import host_level, load_cell_df, OBS, _savefig

h = host_level(load_cell_df())
n = len(h)

OBS_SHORT = {'dec_median': 'dec', 'intervention_rate': 'interv',
             'policy_rate': 'policy', 'mean_relative_shift': 'shift',
             'bare_median_log10err': 'bare', 'rho_step_effect': 'rho',
             'theta_align_effect': 'theta', 'eta_elite_effect': 'eta',
             'kappa_crowd_effect': 'kappa', 'nu_novel_effect': 'nu'}
SHORT = [OBS_SHORT[o] for o in OBS]
LEVEL_COLORS = {0: '#4C72B0', 1: '#DD8452', 2: '#55A868', 3: '#C44E52'}
LEVELS = sorted(h['level'].unique())


def obs_order(Xz):
    Z = linkage(Xz.values.T, method='ward')
    return leaves_list(Z)


def add_cbar(fig, im, label, horizontal=False):
    if horizontal:
        fig.colorbar(im, ax=fig.axes, orientation='horizontal',
                     fraction=0.03, pad=0.06, label=label)
    else:
        fig.colorbar(im, ax=fig.axes, fraction=0.045, pad=0.02, label=label)


# ---------------------------------------------------------------- X (std)
Xz = (h[OBS] - h[OBS].mean()) / h[OBS].std()
col_order = obs_order(Xz)
row_order = leaves_list(linkage(Xz.values, method='ward'))

# ---- A: clustered correlation half-matrix (corrgram) ----
obs_corr = h[OBS].corr()
dist = 1 - obs_corr.values
np.fill_diagonal(dist, 0)
corder = leaves_list(linkage(squareform(dist), method='ward'))
oc = obs_corr.iloc[corder, corder]
mask = np.triu(np.ones_like(oc.values, dtype=bool), k=1)
fig, ax = plt.subplots(figsize=(7.2, 6.2))
im = ax.imshow(np.ma.masked_where(mask, oc.values), cmap='RdBu_r',
               vmin=-1, vmax=1, aspect='equal')
for i in range(len(oc)):
    for j in range(i + 1):
        ax.text(j, i, f'{oc.values[i, j]:.2f}', ha='center', va='center',
                fontsize=8, color='w' if abs(oc.values[i, j]) > 0.55 else 'k')
ax.set_xticks(range(len(corder)))
ax.set_xticklabels([SHORT[i] for i in corder], fontsize=9, rotation=45, ha='right')
ax.set_yticks(range(len(corder)))
ax.set_yticklabels([SHORT[i] for i in corder], fontsize=9)
ax.grid(False)
fig.subplots_adjust(left=0.08, right=0.88, top=0.92, bottom=0.12)
add_cbar(fig, im, 'Pearson r')
ax.set_title('A  clustered correlation (Ward on 1-r, lower triangle)',
             fontsize=12, fontweight='bold')
_savefig(fig, 'attr_d4_v1_corrgram.png')
plt.close(fig)

# ---- B: host x observable z-score clustermap ----
from matplotlib.colors import ListedColormap
from matplotlib.colorbar import Colorbar
val = Xz.values[np.ix_(row_order, col_order)]
fig = plt.figure(figsize=(10, 10.4))
ax = fig.add_axes([0.19, 0.16, 0.74, 0.74])
ax_side = fig.add_axes([0.945, 0.16, 0.02, 0.74])
ax_cbar = fig.add_axes([0.19, 0.075, 0.74, 0.02])
im = ax.imshow(val, cmap='RdBu_r', vmin=-2.2, vmax=2.2, aspect='auto')
thr = 1.3
for i in range(n):
    for j in range(len(col_order)):
        v = val[i, j]
        ax.text(j, i, f'{v:.1f}', ha='center', va='center', fontsize=6,
                color='white' if abs(v) > thr else '0.15')
ax.set_xticks(range(len(col_order)))
ax.set_xticklabels([SHORT[i] for i in col_order], fontsize=10)
ax.xaxis.set_ticks_position('top')
ax.xaxis.set_label_position('top')
ax.tick_params(axis='x', length=0)
ax.set_yticks(range(n))
ax.set_yticklabels([h.index[i] for i in row_order], fontsize=7.5)
ax.tick_params(axis='y', length=0)
for x in range(len(col_order) - 1):
    ax.axvline(x + 0.5, color='white', lw=1.6)
for y in range(n - 1):
    ax.axhline(y + 0.5, color='white', lw=0.8)
ax.grid(False)
cmap_level = ListedColormap([LEVEL_COLORS[l] for l in LEVELS])
lv = h.iloc[row_order]['level'].astype(int).values
ax_side.imshow(lv[:, None], cmap=cmap_level, aspect='auto')
ax_side.set_xticks([])
ax_side.set_yticks([])
ax_side.set_title('level', fontsize=8, pad=4)
cb = Colorbar(ax_cbar, im, orientation='horizontal')
cb.set_label('z-score', fontsize=10)
handles = [plt.Line2D([], [], marker='s', linestyle='', color=c,
                      label=f'Level {lvl}') for lvl, c in LEVEL_COLORS.items()]
fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.5, 0.02),
           ncol=4, fontsize=9, frameon=False, handlelength=1, handletextpad=0.5)
fig.suptitle('B  host x observable z-score  (rows/cols Ward-clustered; '
             'values = z-score)', fontsize=13, fontweight='bold', y=0.97)
_savefig(fig, 'attr_d4_v2_clustermap.png')
plt.close(fig)

# ---- C: PCA loadings heatmap ----
X = (h[OBS] - h[OBS].mean()) / h[OBS].std()
pca = PCA(n_components=min(4, len(OBS)))
pca.fit_transform(X.values)
load = pca.components_.T  # 10 x 4
var = pca.explained_variance_ratio_
fig, ax = plt.subplots(figsize=(6.2, 5.8))
im = ax.imshow(load, cmap='RdBu_r', vmin=-0.9, vmax=0.9, aspect='auto')
for i in range(load.shape[0]):
    for j in range(load.shape[1]):
        ax.text(j, i, f'{load[i, j]:.2f}', ha='center', va='center', fontsize=8,
                color='w' if abs(load[i, j]) > 0.5 else 'k')
ax.set_xticks(range(4))
ax.set_xticklabels([f'PC{i + 1}\n({var[i] * 100:.0f}%)' for i in range(4)],
                   fontsize=9)
ax.set_yticks(range(len(OBS)))
ax.set_yticklabels(SHORT, fontsize=9)
ax.grid(False)
fig.subplots_adjust(left=0.10, right=0.86, top=0.92, bottom=0.10)
add_cbar(fig, im, 'loading')
ax.set_title('C  PCA loadings (obs x PC, variance % in header)',
             fontsize=12, fontweight='bold')
_savefig(fig, 'attr_d4_v3_loadings.png')
plt.close(fig)

# ---- D: refined biplot (scores colored by level, loadings as arrows) ----
scores = pca.transform(X.values)
fig, ax = plt.subplots(figsize=(8.2, 6.8))
for lvl in LEVELS:
    m = (h['level'] == lvl).values
    ax.scatter(scores[m, 0], scores[m, 1], s=60, alpha=0.8,
               color=LEVEL_COLORS[lvl], label=f'Level {lvl}', edgecolor='k',
               linewidth=0.4)
scale = 4.2
for i, o in enumerate(OBS):
    ax.arrow(0, 0, load[i, 0] * scale, load[i, 1] * scale, head_width=0.07,
             head_length=0.09, color='0.25', lw=1.3, zorder=5)
    ax.text(load[i, 0] * scale * 1.12, load[i, 1] * scale * 1.12, SHORT[i],
            fontsize=8.5, color='0.15', fontweight='bold', zorder=5)
ax.axhline(0, color='0.7', lw=0.7, zorder=0)
ax.axvline(0, color='0.7', lw=0.7, zorder=0)
ax.set_xlabel(f'PC1 ({var[0] * 100:.0f}%)', fontsize=11)
ax.set_ylabel(f'PC2 ({var[1] * 100:.0f}%)', fontsize=11)
ax.legend(fontsize=9, loc='upper right', framealpha=0.9)
ax.set_title('D  refined PCA biplot (dots = hosts by level, arrows = loadings)',
             fontsize=12, fontweight='bold')
fig.tight_layout()
_savefig(fig, 'attr_d4_v4_biplot.png')
plt.close(fig)

# ---- E: level radar profiles ----
grp = Xz.groupby(h['level']).mean()  # 4 x 10
angles = np.linspace(0, 2 * np.pi, len(OBS), endpoint=False).tolist()
angles += angles[:1]
fig, ax = plt.subplots(figsize=(7.2, 7.0), subplot_kw=dict(polar=True))
for lvl in LEVELS:
    vals = grp.loc[lvl].values
    vals = np.concatenate([vals, vals[:1]])
    ax.plot(angles, vals, color=LEVEL_COLORS[lvl], lw=2.0, label=f'Level {lvl}')
    ax.fill(angles, vals, color=LEVEL_COLORS[lvl], alpha=0.07)
ax.set_xticks(angles[:-1])
ax.set_xticklabels(SHORT, fontsize=9)
ax.set_ylim(-0.8, 0.8)
ax.set_yticks([-0.6, -0.3, 0, 0.3, 0.6])
ax.set_yticklabels(['-0.6', '-0.3', '0', '0.3', '0.6'], fontsize=7, color='0.5')
ax.legend(loc='upper right', bbox_to_anchor=(1.25, 1.12), fontsize=9)
ax.set_title('E  mean z-score profile by level (radar)', fontsize=12,
             fontweight='bold', pad=20)
_savefig(fig, 'attr_d4_v5_radar.png')
plt.close(fig)

print('done')

# -*- coding: utf-8 -*-
"""Render the bibliography of this manuscript in the layout of the target
evolutionary-computation journal.

Records
-------
``ec_refs.REFS`` and ``upcl_refs.UPCL_REFS`` hold one string per key in GB/T
7714 field order::

    AUTHORS. Title[J]. Journal, Year, Vol(Issue): Pages.
    AUTHORS. Title[C]//Proceedings. Place: Publisher, Year: Pages.
    AUTHORS. Title[M]. Place: Publisher, Year.
    AUTHORS. Title[R]. Place: Publisher, Year.
    AUTHORS. Title[EB/OL]. (Date)[Cited]. URL.

The ``[J]/[C]/[M]/[R]/[EB/OL]/[J/OL]`` marker is what keeps a record
unambiguous, so the records stay in that order and :func:`render` decides how
they are printed.

Styles
------
``ec`` (default) reproduces the reference list of the reference EC-journal
manuscript ``DASM_EC_Journal_SEC3.docx`` -- the manuscript whose page layout
``ec_style.py`` already mirrors -- and of the published EC-journal papers kept
in ``docs/``::

    [1] R. Storn, K. Price, Differential evolution — a simple and efficient
        heuristic for global optimization over continuous spaces, Journal of
        Global Optimization 11 (4) (1997) 341–359.
    [3] R. Tanabe, A. S. Fukunaga, Success-history based parameter adaptation
        for differential evolution, in: 2013 IEEE Congress on Evolutionary
        Computation, 2013, pp. 71–78.
    [25] E. Brochu, V. M. Cora, N. De Freitas, A tutorial on Bayesian
        optimization of expensive cost functions, arXiv preprint
        arXiv:1012.2599 (2010).
    [46] P. Moscato, On evolution, search, optimization, genetic algorithms and
        martial arts: towards memetic algorithms, Tech. rep., California
        Institute of Technology, Pasadena, 1989.

Conventions of that style: ``[n]`` numbered in order of first citation; author
as ``I. Surname``, at most three authors then ``et al.``; full journal titles;
``Journal Vol (Issue) (Year) Pages``; en dash inside page ranges; conference
papers as ``in: <proceedings>, Year, pp. pages``; publisher before city for
books and reports; a DOI only where the article has no volume yet; preprints as
``arXiv preprint arXiv:XXXX.XXXXX (Year)``.

``gbt`` prints the records as stored (GB/T 7714-2015) for a domestic venue.

CLI
---
``python src/refs_style.py [ec|gbt] [-o FILE]`` prints the current list in that
style, or writes it to ``FILE`` as UTF-8, and reports any record that did not
parse.
"""
import os
import re
import sys

TYPES = r'EB/OL|J/OL|M/OL|C/OL|J|M|C|D|R|S|P'
TYPE_RE = re.compile(r'\[(%s)\]' % TYPES)
PAGES = r'[0-9A-Za-z]+(?:-[0-9A-Za-z]+)*'
MC = re.compile(r'^MC([A-Z]{2,})$')
STYLES = ('ec', 'gbt')
DEFAULT_STYLE = 'ec'


def _name(tok):
    """``'STORN R M'`` -> ``'R. M. Storn'``."""
    tok = tok.strip()
    if tok.lower().replace('.', '').startswith('et al'):
        return 'et al.'
    parts = tok.split()
    initials = []
    while parts and len(parts[-1].rstrip('.')) == 1 and parts[-1].rstrip('.').isalpha():
        initials.insert(0, parts.pop().rstrip('.').upper())
    surname = ' '.join(parts)
    if not surname:                            # an initial standing on its own
        return ' '.join(i + '.' for i in initials)
    if surname.isupper():
        surname = 'Mc' + surname[2:].capitalize() if MC.match(surname) else surname.title()
    return ' '.join(i + '.' for i in initials) + ' ' + surname


def _authors(block):
    block = block.strip()
    if not block:
        return ''
    return ', '.join(x for x in (_name(t) for t in block.split(', ')) if x)


def _dash(pages):
    return pages.replace('-', '\u2013')


def to_ec(text):
    """Return ``(rendered, problem)`` for one record in the EC-journal style."""
    entry = re.sub(r'\s+', ' ', text).strip()
    m = TYPE_RE.search(entry)
    if not m:
        return entry, 'no type marker'
    kind = m.group(1)
    head = entry[:m.start()].strip()
    tail = entry[m.end():].lstrip('./ ').strip()
    block, sep, title = head.partition('. ')
    if not sep:
        return entry, 'authors and title are not separable'
    authors = _authors(block)
    title = title.strip().rstrip('.')

    if kind == 'J':
        mm = re.match(r'^(?P<j>.+?), (?P<y>\d{4}), (?P<v>[^(,]+?)'
                      r'(?:\((?P<i>[^)]+)\))?: (?P<p>%s)\.$' % PAGES, tail)
        if not mm:
            return entry, 'journal tail not parsed: ' + tail[:70]
        issue = ' (%s)' % mm.group('i') if mm.group('i') else ''
        return ('%s, %s, %s %s%s (%s) %s.'
                % (authors, title, mm.group('j'),
                   _dash(mm.group('v').strip()), issue,
                   mm.group('y'), _dash(mm.group('p')))), None

    if kind in ('EB/OL', 'J/OL', 'M/OL', 'C/OL'):
        url = re.search(r'https?://\S+', tail)
        if not url:
            return entry, 'no URL: ' + tail[:70]
        found = [x for pair in re.findall(r'\((\d{4})(?:-\d\d-\d\d)?\)|(\d{4})\[', tail)
                 for x in pair if x]
        loose = re.search(r'(?:19|20)\d\d', tail)
        year = found[0] if found else (loose.group(0) if loose else '')
        url = url.group(0).rstrip('.')
        arxiv = re.search(r'arxiv\.org/abs/([\w.\-/]+)', url)
        if arxiv:
            return ('%s, %s, arXiv preprint arXiv:%s (%s).'
                    % (authors, title, arxiv.group(1), year)), None
        if kind == 'J/OL':
            mm = re.match(r'^(?P<j>.+?),\s*\d{4}', tail)
            return ('%s, %s, %s (%s), %s.'
                    % (authors, title, mm.group('j') if mm else tail, year, url)), None
        return '%s, %s, %s (%s).' % (authors, title, url, year), None

    if kind == 'C':
        mm = re.match(r'^(?P<h>.*), (?P<y>\d{4}): (?P<p>%s)\.$' % PAGES, tail)
        if not mm:
            return entry, 'conference tail not parsed: ' + tail[:70]
        venue = re.match(r'^(?P<v>.*?)\. (?P<rest>.+?): (?P<pub>.+)$', mm.group('h'))
        name = venue.group('v') if venue else mm.group('h')
        return ('%s, %s, in: %s, %s, pp. %s.'
                % (authors, title, name, mm.group('y'), _dash(mm.group('p')))), None

    if kind in ('M', 'R'):
        body = entry.split('[%s]//' % kind, 1)[1] if '[%s]//' % kind in entry else None
        if body is not None:                   # a chapter in an edited volume
            mm = re.match(r'^(?P<b>.*?)\. (?P<pl>.+?): (?P<pu>.+?), '
                          r'(?P<y>\d{4}): (?P<p>%s)\.$' % PAGES, body)
            if not mm:
                return entry, 'chapter tail not parsed: ' + body[:70]
            return ('%s, %s, in: %s, %s, %s, %s, pp. %s.'
                    % (authors, title, mm.group('b'), mm.group('pu'),
                       mm.group('pl'), mm.group('y'), _dash(mm.group('p')))), None
        mm = re.match(r'^(?P<pl>.+?): (?P<pu>.+?), (?P<y>\d{4})\.$', tail)
        if not mm:
            return entry, '%s tail not parsed: %s' % (kind, tail[:70])
        lead = 'Tech. rep., ' if kind == 'R' else ''
        return ('%s, %s, %s%s, %s, %s.'
                % (authors, title, lead, mm.group('pu'), mm.group('pl'),
                   mm.group('y'))), None

    return entry, 'unhandled type ' + kind


def render(entries, style='ec'):
    """Return ``(rendered, problems)`` with every record printed in ``style``.

    Records that do not parse are passed through unchanged and reported in
    ``problems`` as ``(key, reason)`` pairs.
    """
    if style not in STYLES:
        raise ValueError('unknown reference style %r' % style)
    if style == 'gbt':
        return dict(entries), []
    out, problems = {}, []
    for key, text in entries.items():
        rendered, problem = to_ec(text)
        out[key] = rendered
        if problem:
            problems.append((key, problem))
    return out, problems


def main():
    argv = sys.argv[1:]
    out_path = None
    if '-o' in argv:
        i = argv.index('-o')
        out_path = argv[i + 1]
        del argv[i:i + 2]
    elif '--out' in argv:
        i = argv.index('--out')
        out_path = argv[i + 1]
        del argv[i:i + 2]
    style = argv[0] if argv else DEFAULT_STYLE

    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import upcl_refs
    entries, problems = render(upcl_refs.get_refs('gbt'), style)
    lines = ['[%d] %s' % (i, entries[key])
             for i, key in enumerate(entries, 1)]
    lines += ['[refs] WARNING %s: %s' % (key, why) for key, why in problems]
    text = '\n'.join(lines) + '\n'

    if out_path:
        with open(out_path, 'w', encoding='utf-8') as fh:
            fh.write(text)
        print('[refs] %d entries (%d problems) -> %s'
              % (len(entries), len(problems), out_path))
        return
    # A Windows console is often GBK, which cannot hold e.g. "č": fall back to
    # replacing the offending glyphs instead of crashing.
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass
    try:
        sys.stdout.write(text)
    except UnicodeEncodeError:
        sys.stdout.write(text.encode('ascii', 'replace').decode('ascii'))


if __name__ == '__main__':
    main()

"""Section 2 -- the nine mechanism families against the four composition levels.

Draws one panel per language: nine horizontal bars, one per family, split into
the four levels its members occupy, so that the aggregate of Table 3 is read as
a shape rather than as a column of the letter string "12/2/3/1".  The colour hue
carries the kind of intervention (replace / add / mixed) and the shade carries
the level, which is what Section 2.3 argues about.

Renders ``fig_tax_families.png`` (Chinese labels) and ``fig_tax_families_en.png``
(English labels) straight into ``docs/figures`` -- like the other Section 2
figures, these are not copied by ``paper_figures.sync``.

Usage::

    python src/plot_tax_families.py
"""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

import upcl_variant_table as VT

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs' / 'figures'

# Hue per kind of intervention; the shades below lighten it per level.
KIND_HUE = {'replace': '#2f5f8f', 'add': '#b4761b', 'mixed': '#5c5c5c'}
LEVEL_ALPHA = (0.28, 0.50, 0.72, 0.94)
KIND_EN = {'replace': 'replaces a rule', 'add': 'adds after the candidate',
           'mixed': 'spans several objects'}
KIND_ZH = {'replace': '替换既有规则的', 'add': '候选之后叠加的',
           'mixed': '跨多个对象的'}


def _counts():
    """(family row, [n at level 0..3], total) in flow order."""
    out = []
    for row in VT.FAMILIES:
        members = [e for e in VT.entries() if VT._primary(e) == row[0]]
        lv = [sum(1 for e in members if e[4] == k) for k in range(4)]
        out.append((row, lv, len(members)))
    return out


def fig_families(lang='en'):
    """Render the family-by-level panel for one edition."""
    en = lang == 'en'
    data = _counts()
    n = len(data)
    n_level = len(VT.LEVELS)
    xmax = max(t for _, _, t in data)

    plt.rcParams.update({
        'font.size': 7.2,
        'axes.linewidth': 0.6,
        'xtick.major.width': 0.6,
        'ytick.major.width': 0.6,
    })
    cjk = {'font.sans-serif': ['Microsoft YaHei', 'SimHei', 'DejaVu Sans'],
           'axes.unicode_minus': False}
    ctx = plt.rc_context(cjk) if not en else plt.rc_context({})
    with ctx:
        fig, ax = plt.subplots(figsize=(6.30, 2.45))
        ys = list(range(n))[::-1]

        for y, (row, lv, total) in zip(ys, data):
            hue = KIND_HUE[row[8]]
            left = 0
            for k in range(n_level):
                if not lv[k]:
                    continue
                ax.barh(y, lv[k], left=left, height=0.60, color=hue,
                        alpha=LEVEL_ALPHA[k], edgecolor='white',
                        linewidth=0.6, zorder=3)
                left += lv[k]
            ax.text(total + 0.35, y, str(total), va='center', ha='left',
                    fontsize=6.9, color='#333333', zorder=4)

        labels = [row[1] if en else row[2] for row, _, _ in data]
        ax.set_yticks(ys)
        ax.set_yticklabels(labels, fontsize=7.0)
        for tick, (row, _, _) in zip(ax.get_yticklabels(), data):
            if row[0] == 'candidate':
                tick.set_fontweight('bold')
        ax.tick_params(axis='y', length=0, pad=4)

        ax.set_xlim(0, xmax + 2.2)
        ax.set_ylim(-0.55, n - 0.45)
        ax.set_xticks(range(0, xmax + 1, 5))
        ax.grid(axis='x', color='#dddddd', linewidth=0.4, zorder=0)
        ax.set_axisbelow(True)
        for side in ('top', 'right'):
            ax.spines[side].set_visible(False)

        # Separate the three kinds along the row axis: the rows run bottom-up,
        # so the cuts sit between ensemble|restart and between candidate|meta.
        for cut in (2.5, 0.5):
            ax.axhline(cut, color='#bbbbbb', linewidth=0.6, linestyle=(0, (4, 3)),
                       zorder=2)

        level_handles = [Patch(facecolor='#2f5f8f', alpha=a, edgecolor='white',
                               label=('Lv %d (%d)' if en else 'Lv %d（%d）')
                               % (k, VT.LEVELS[k]))
                         for k, a in enumerate(LEVEL_ALPHA)]
        kind_handles = [Patch(facecolor=KIND_HUE[k], alpha=1.0,
                              label=(KIND_EN if en else KIND_ZH)[k])
                        for k in ('replace', 'add', 'mixed')]
        fig.legend(handles=level_handles + kind_handles, loc='lower center',
                   ncol=7, frameon=False, fontsize=6.4,
                   handlelength=0.9, handleheight=0.8,
                   columnspacing=0.9, bbox_to_anchor=(0.5, 0.0))

        fig.tight_layout(pad=0.25)
        fig.subplots_adjust(bottom=0.19, left=0.245 if en else 0.165)
        name = 'fig_tax_families_en.png' if en else 'fig_tax_families.png'
        path = OUT / name
        fig.savefig(path, dpi=600)
        plt.close(fig)
        print('wrote', path)


def main():
    for lang in ('en', 'zh'):
        fig_families(lang)


if __name__ == '__main__':
    main()

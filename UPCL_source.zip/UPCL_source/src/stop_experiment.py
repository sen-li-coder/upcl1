#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stop the running run_upcl_grid.py experiment and record progress.

Actions (idempotent - safe to run more than once):

    1.  Append a final progress snapshot to ``results/grid/monitor_run.log``
        by invoking ``monitor_run.py`` once.
    2.  Append a ``[stop]`` marker line to the monitor log.
    3.  Terminate the driver process (``run_upcl_grid.py``) together with its
        worker pool (``taskkill /T /F`` kills the whole process tree).

Resuming later is a plain re-run of the same command - every completed run is
already written to its own ``results/grid/raw/...json`` file, so the driver
warm-starts from wherever it stopped::

    python src/run_upcl_grid.py --workers 18
"""
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MONITOR = ROOT / "src" / "monitor_run.py"
MON_LOG = ROOT / "results" / "grid" / "monitor_run.log"


def log(text):
    line = f"[stop] {datetime.now().strftime('%m-%d %H:%M:%S')} {text}"
    print(line, flush=True)
    try:
        with open(MON_LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def find_driver_pids():
    """PIDs of every python.exe whose command line references run_upcl_grid."""
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
          "Where-Object { $_.CommandLine -match 'run_upcl_grid' } | "
          "Select-Object -ExpandProperty ProcessId")
    out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                         capture_output=True, text=True, timeout=60)
    return [int(x) for x in out.stdout.split() if x.strip().isdigit()]


def main():
    log("stop request received - recording progress first")

    # 1) snapshot progress into the monitor log
    try:
        subprocess.run([sys.executable, str(MONITOR)],
                       timeout=180, check=False)
    except Exception as exc:
        log(f"progress snapshot failed: {exc}")

    # 2) locate and terminate the driver (and its worker tree)
    pids = find_driver_pids()
    if not pids:
        log("no run_upcl_grid.py process found (already stopped?)")
        return
    for pid in pids:
        log(f"terminating driver process {pid} and its children")
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       capture_output=True, text=True, timeout=60)

    log("experiment stopped; progress saved. "
        "resume with: python src/run_upcl_grid.py --workers 18")


if __name__ == "__main__":
    main()

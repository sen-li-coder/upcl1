# -*- coding: utf-8 -*-
"""Action-level + temporal mechanism diagnostics for bare-vs-UPCL grid.

Validates four mechanism hypotheses that follow from reading
``upcl_framework.propose`` / ``_select``:

H1  Exploration-then-lockout.  ``eps0=0.15`` decays to ``eps_min=0`` over
    ``eps_gens=60`` generations; after that selection is purely greedy.  The
    adaptive identity margin (``margin=0.20`` + ``margin_adapt*r_identity_ema``)
    plus the UCB penalty ``ucb_kappa/sqrt(1+n_eff)`` should lock the policy to
    the identity for the remaining ~2000 generations.  We test this with
    ``rho_curve``: the per-generation intervention rate should be ~10% over the
    first 60 generations and collapse towards 0 afterwards.

H2  Cold start.  Non-identity arms therefore keep very few response samples in
    ``ResponseMemory`` (per-action cap = 256//5 = 51).  We inspect
    ``memory_counts``: C/E/R/P should hold far fewer samples than I.

H3  Weak signal.  ``descriptor_influence`` stores the standardised contrast of
    each descriptor component between positive and non-positive responses.  If
    the layer actually learns a usable signal these ``*_effect`` values should
    be consistently non-zero with a stable sign; near-zero everywhere means the
    response model has no signal to exploit.

H4  Action mix.  ``action_counts`` decomposes the (small) intervention budget
    into C/E/R/P; we report the share of each to see what the layer does when
    it does act.

Outputs: results/grid/tables/diag_actions.csv, diag_actions_blocks.csv,
         diag_rho_curve.csv

    python src/diag_actions.py
"""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'grid'
TAB = OUT / 'tables'
EPS_GENS = 60
ACTIONS = ('I', 'C', 'E', 'R', 'P')


def load_rows(min_runs):
    rows = []
    base = OUT / 'raw'
    for p in sorted(base.glob('*/*/*.json')):
        try:
            with open(p, encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        runs = d.get('runs', [])
        if len(runs) < min_runs:
            continue
        agg = defaultdict(list)
        n_bad = 0
        for r in runs:
            u = r.get('upcl') or r.get('full')
            if not isinstance(u, dict):
                n_bad += 1
                continue
            st = u.get('upcl', {})
            if not isinstance(st, dict):
                n_bad += 1
                continue
            ac = st.get('action_counts')
            mc = st.get('memory_counts')
            di = st.get('descriptor_influence')
            rc = st.get('rho_curve')
            if isinstance(ac, dict):
                tot = sum(ac.values()) or 1
                for k in ACTIONS:
                    agg[f'share_{k}'].append(ac.get(k, 0) / tot)
            if isinstance(mc, dict):
                for k in ACTIONS:
                    agg[f'mem_{k}'].append(mc.get(k, 0))
            if isinstance(di, dict):
                for k in range(5):
                    agg[f'z{k}_effect'].append(float(di.get(f'z{k}_effect', 0.0)))
                agg['n_pos'].append(float(di.get('n_pos', 0)))
                agg['n_neg'].append(float(di.get('n_neg', 0)))
            # rho_curve is down-sampled to <=50 points by run_upcl_cec; the
            # first three samples fall inside the exploration window
            # (eps_gens=60), the rest are the greedy/policy phase.
            if isinstance(rc, list) and len(rc) >= 3:
                agg['rho_early'].append(float(np.mean(rc[:3])))
                agg['rho_late'].append(float(np.mean(rc[3:])))
                agg['rho_first'].append(float(rc[0]))
                agg['rho_curve'].append(np.asarray(rc, float))
        if (len(agg.get('share_I', [])) + n_bad) < min_runs:
            continue
        row = dict(suite=d['suite'], dim=d['dim'], host=d['host'], fid=d['fid'],
                   func=d.get('func', ''), category=d.get('category', ''),
                   n=len(agg.get('share_I', [])))
        for k in ('share_C', 'share_E', 'share_R', 'share_P'):
            row[k] = float(np.mean(agg[k]))
        row['share_I'] = 1.0 - sum(row[k] for k in ('share_C', 'share_E',
                                                     'share_R', 'share_P'))
        for k in ('mem_I', 'mem_C', 'mem_E', 'mem_R', 'mem_P'):
            row[k] = float(np.mean(agg[k]))
        for k in range(5):
            row[f'z{k}_effect'] = float(np.mean(agg[f'z{k}_effect']))
        if 'rho_early' in agg:
            row['rho_early'] = float(np.mean(agg['rho_early']))
            row['rho_late'] = float(np.mean(agg['rho_late']))
            row['rho_first'] = float(np.mean(agg['rho_first']))
            row['rho_ratio'] = (row['rho_late'] / row['rho_early']
                                if row['rho_early'] > 1e-9 else float('nan'))
            row['rho_curves'] = agg['rho_curve']
        rows.append(row)
    return rows


def write_cells(rows):
    TAB.mkdir(parents=True, exist_ok=True)
    cols = [c for c in rows[0] if c != 'rho_curves']
    with open(TAB / 'diag_actions.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow({c: r[c] for c in cols})
    print(f'[actions] per-cell -> diag_actions.csv ({len(rows)} cells)')


def write_blocks(rows):
    out = []
    for block in sorted({(r['suite'], r['dim']) for r in rows}):
        rs = [r for r in rows if (r['suite'], r['dim']) == block]
        def mean(k):
            vals = np.array([r[k] for r in rs if r.get(k) is not None],
                            dtype=float)
            return float(vals.mean()) if vals.size else float('nan')
        out.append(dict(
            suite=block[0], dim=block[1], cells=len(rs),
            share_I=round(mean('share_I'), 4),
            share_C=round(mean('share_C'), 4),
            share_E=round(mean('share_E'), 4),
            share_R=round(mean('share_R'), 4),
            share_P=round(mean('share_P'), 4),
            mem_I=round(mean('mem_I'), 1),
            mem_C=round(mean('mem_C'), 1),
            mem_E=round(mean('mem_E'), 1),
            mem_R=round(mean('mem_R'), 1),
            mem_P=round(mean('mem_P'), 1),
            z0=round(mean('z0_effect'), 3), z1=round(mean('z1_effect'), 3),
            z2=round(mean('z2_effect'), 3), z3=round(mean('z3_effect'), 3),
            z4=round(mean('z4_effect'), 3),
            rho_first=round(mean('rho_first'), 4),
            rho_early=round(mean('rho_early'), 4),
            rho_late=round(mean('rho_late'), 4),
            rho_ratio=round(mean('rho_ratio'), 4),
        ))
    with open(TAB / 'diag_actions_blocks.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    print('[actions] blocks -> diag_actions_blocks.csv')
    return out


def write_rho_curve(rows):
    """Average per-generation intervention rate, aligned by generation index."""
    by_block = defaultdict(list)
    for r in rows:
        for curve in r.get('rho_curves', []):
            by_block[(r['suite'], r['dim'])].append(curve)
    L = 60
    out = []
    for block, curves in sorted(by_block.items()):
        M = min(min(len(c) for c in curves), L)
        grid = np.arange(1, M + 1)
        A = np.vstack([c[:M] for c in curves])
        med = np.median(A, axis=0)
        out.append(dict(suite=block[0], dim=block[1],
                        n=len(curves), M=M,
                        gen=[int(g) for g in grid],
                        rho_median=[float(v) for v in med]))
    with open(TAB / 'diag_rho_curve.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['suite', 'dim', 'n', 'M',
                                           'gen', 'rho_median'])
        w.writeheader()
        for o in out:
            for g, v in zip(o['gen'], o['rho_median']):
                w.writerow(dict(suite=o['suite'], dim=o['dim'], n=o['n'],
                                M=o['M'], gen=g, rho_median=v))
    print(f'[actions] rho-curve -> diag_rho_curve.csv ({len(out)} blocks)')
    return out


def console(blocks):
    print()
    for b in blocks:
        print(f"=== {b['suite']} D={b['dim']} (cells={b['cells']}) ===")
        print(f"  action share   I={b['share_I']:.4f}  C={b['share_C']:.4f}  "
              f"E={b['share_E']:.4f}  R={b['share_R']:.4f}  P={b['share_P']:.4f}")
        print(f"  memory counts  I={b['mem_I']:.0f}  C={b['mem_C']:.0f}  "
              f"E={b['mem_E']:.0f}  R={b['mem_R']:.0f}  P={b['mem_P']:.0f}")
        print(f"  descriptor effect z0={b['z0']} z1={b['z1']} z2={b['z2']} "
              f"z3={b['z3']} z4={b['z4']}")
        print(f"  rho  first={b['rho_first']:.4f}  early(explore)={b['rho_early']:.4f}  "
              f"late(policy)={b['rho_late']:.4f}  late/early={b['rho_ratio']:.3f}")
        print()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--min-runs', type=int, default=30)
    ap.add_argument('--suite', default=None)
    ap.add_argument('--dim', type=int, default=None)
    a = ap.parse_args(argv)

    rows = load_rows(a.min_runs)
    if a.suite or a.dim:
        rows = [r for r in rows
                if (a.suite is None or r['suite'] == a.suite)
                and (a.dim is None or r['dim'] == a.dim)]
    if not rows:
        print(f'[actions] no cell with {a.min_runs} runs')
        return
    print(f'[actions] {len(rows)} complete cells (min-runs={a.min_runs})')

    write_cells(rows)
    blocks = write_blocks(rows)
    write_rho_curve(rows)
    console(blocks)


if __name__ == '__main__':
    main()

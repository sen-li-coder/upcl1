# -*- coding: utf-8 -*-
"""UPCL-Restart smoke: bare vs stagnation-triggered restart, paired.

The bare arm already lives on disk (``results/grid`` / ``results/cec``) and is
reused verbatim; only the ``rs`` arm is re-run.  Both arms use the same seed for
the same run index, so every ``bare``/``rs`` pair is strictly matched.

    python src/run_restart_smoke.py --runs 10 --workers 1
    python src/run_restart_smoke.py --cfgs 30:0.2,30:0.5,10:0.2 --analyze-only
"""
import argparse
import json
import math
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

import numpy as np

for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
           'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(_v, '1')

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                        # noqa: E402
import de_hosts_cec as DHC                                     # noqa: E402
import run_upcl_cec as R                                       # noqa: E402
import upcl_restart as RS                                      # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'restart'
SUITE, DIM = 'cec2022', 10
FES_MULT = R.FES_MULT
SEED_BASE = R.SEED_BASE
FLOOR = 1e-8

# The five backbone families the design targets (per the spec).
BACKBONES = ['DE/rand/1', 'JADE', 'SHADE', 'L-SHADE', 'jSO']
# (window, frac) pairs: default / strong-reset / early-trigger.
DEFAULTS = dict(runs=10, cfgs=((30, 0.2), (30, 0.5), (10, 0.2)),
                fids=(1, 4, 10))


def _seed_for(fid, dim, r):
    return SEED_BASE + dim * 1_000_003 + r * 7919 + fid * 31


def _path(host, fid, arm):
    return (OUT / 'raw' / SUITE / f'D{DIM}'
            / f'{host.replace("/", "-")}__F{fid}__{arm}.json')


def _load_bare(host, fid, runs):
    """Reuse the bare arm from an existing grid/cec record, if complete."""
    name = f'{host.replace("/", "-")}__F{fid}.json'
    for base in (ROOT / 'results' / 'grid', ROOT / 'results' / 'cec'):
        p = base / 'raw' / SUITE / f'D{DIM}' / name
        if not p.exists():
            continue
        try:
            with open(p, encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        out = {}
        for r in d.get('runs', []):
            b = r.get('bare')
            if isinstance(b, dict) and 'err_curve' in b:
                out[r['run']] = b
        if len(out) >= runs:
            return out
    return None


def run_cell(task):
    host, fid, runs, window, frac = task
    arm = f'rs_w{int(window)}_f{frac:g}'
    out_file = _path(host, fid, arm)
    if out_file.exists():
        try:
            with open(out_file, encoding='utf-8') as fh:
                d = json.load(fh)
            if (d.get('runs_complete', 0) >= runs
                    and len(d.get('runs', [])) >= runs):
                return ('skip-done', host, fid, arm, 0.0)
        except Exception:
            pass
    func = CS.get_function(SUITE, DIM, fid)
    pop = DHC.pop_size_for(host, DIM)
    max_evals = FES_MULT * DIM
    bare = _load_bare(host, fid, runs)
    if bare is None:
        return ('skip-nobare', host, fid, arm, 0.0)

    t0 = time.perf_counter()
    runs_list = []
    for r in range(runs):
        seed = _seed_for(fid, DIM, r)
        rec = RS.run_restart_arm(host, func, DIM, seed, max_evals, pop,
                                 window=window, frac=frac)
        runs_list.append({'run': r, 'seed': seed,
                          'bare': bare[r], arm: rec})

    payload = {'suite': SUITE, 'dim': DIM, 'host': host, 'fid': fid,
               'func': func.name, 'category': func.category,
               'max_evals': int(max_evals), 'runs_complete': len(runs_list),
               'arms': ['bare', arm], 'runs': runs_list}
    out_file = _path(host, fid, arm)
    out_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_file.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(payload, fh)
    tmp.replace(out_file)
    return ('done', host, fid, arm, time.perf_counter() - t0)


# ===========================================================================
# Analysis
# ===========================================================================
def _dec(bare_rec, arm_rec):
    """Per-run log-error difference; positive => restart better."""
    b = max(float(bare_rec['err_final']), FLOOR)
    a = max(float(arm_rec['err_final']), FLOOR)
    return math.log10(b) - math.log10(a)


def analyze():
    files = sorted((OUT / 'raw' / SUITE / f'D{DIM}').glob('*.json'))
    rows = {}
    for p in files:
        with open(p, encoding='utf-8') as fh:
            d = json.load(fh)
        arms = d.get('arms', [])
        arm = arms[1] if len(arms) > 1 else None
        if arm is None or not arm.startswith('rs_'):
            continue
        decs, counts, eval_fracs = [], [], []
        for r in d['runs']:
            b, a = r['bare'], r[arm]
            decs.append(_dec(b, a))
            counts.append(a['restart'].get('count', 0))
            eval_fracs.append(a['restart'].get('evals', 0) / max(1, a['max_evals']))
        rows.setdefault(arm, []).append(
            (d['host'], d['fid'], decs, counts, eval_fracs))

    print('\n=== UPCL-Restart vs bare  (median log-error diff, + = better) ===')
    print(f'{"arm":<14s}{"cells":>5s}{"mean dec":>9s}{"med dec":>9s}'
          f'{"W/T/L":>9s}{"rst#":>6s}{"rstEv%":>8s}')
    summary = []
    for arm in sorted(rows):
        cells = rows[arm]
        cell_dec = [float(np.median(decs)) for _, _, decs, _, _ in cells]
        mean = float(np.mean(cell_dec))
        med = float(np.median(cell_dec))
        w = sum(1 for d in cell_dec if d > 0.05)
        l = sum(1 for d in cell_dec if d < -0.05)
        t = len(cell_dec) - w - l
        cnt = float(np.mean([float(np.mean(cs)) for *_, cs, _ in cells]))
        evf = float(np.mean([float(np.mean(es)) for *_, _, es in cells]))
        print(f'{arm:<14s}{len(cells):>5d}{mean:>9.3f}{med:>9.3f}'
              f'{f"{w}/{t}/{l}":>9s}{cnt:>6.1f}{evf * 100:>7.1f}%')
        summary.append((arm, med, mean, w, t, l, cnt, evf))

    print('\nper-cell detail (median dec per host/F):')
    print(f'{"arm":<14s}{"host":<24s}{"F":>3s}{"med dec":>9s}{"rst#":>7s}')
    for arm in sorted(rows):
        for host, fid, decs, cs, _ in rows[arm]:
            print(f'{arm:<14s}{host:<24s}{fid:>3d}'
                  f'{float(np.median(decs)):>9.3f}'
                  f'{float(np.mean(cs)):>7.1f}')
    return summary


def _parse_cfgs(s):
    out = []
    for tok in s.split(','):
        tok = tok.strip()
        if not tok:
            continue
        w, f = tok.split(':')
        out.append((int(w), float(f)))
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--runs', type=int, default=DEFAULTS['runs'])
    ap.add_argument('--hosts', default=','.join(BACKBONES),
                    help='comma-separated host names')
    ap.add_argument('--fids', nargs='*', type=int, default=list(DEFAULTS['fids']))
    ap.add_argument('--cfgs', default=','.join(f'{w}:{f}' for w, f in DEFAULTS['cfgs']),
                    help='comma-separated window:frac pairs, e.g. 30:0.2,30:0.5,10:0.2')
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--analyze-only', action='store_true')
    a = ap.parse_args(argv)

    hosts = [h.strip() for h in a.hosts.split(',') if h.strip()]
    cfgs = _parse_cfgs(a.cfgs)

    if a.analyze_only:
        analyze()
        return

    tasks = [(h, f, a.runs, w, fr) for w, fr in cfgs for h in hosts for f in a.fids]
    print(f'[rs] {len(tasks)} cells ({len(cfgs)} cfgs x {len(hosts)} '
          f'hosts x {len(a.fids)} funcs) x {a.runs} runs, bare reused',
          flush=True)

    t0 = time.perf_counter()
    done = 0

    def _report(st, h, f, arm, dt):
        nonlocal done
        done += 1
        el = time.perf_counter() - t0
        remain = (el / done) * (len(tasks) - done)
        print(f'[rs] {done}/{len(tasks)} {st} {arm} {h} F{f} '
              f'{dt / 60:.1f} min  elapsed {el / 60:.1f} min  '
              f'left ~{remain / 60:.1f} min', flush=True)

    if a.workers <= 1:
        for task in tasks:
            st, h, f, arm, dt = run_cell(task)
            _report(st, h, f, arm, dt)
    else:
        ctx = mp.get_context('spawn')
        with ctx.Pool(a.workers) as pool:
            for st, h, f, arm, dt in pool.imap_unordered(run_cell, tasks):
                _report(st, h, f, arm, dt)
    print(f'[rs] finished {done} cells in '
          f'{(time.perf_counter() - t0) / 60:.1f} min')

    analyze()


if __name__ == '__main__':
    main()

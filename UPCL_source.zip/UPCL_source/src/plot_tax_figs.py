# -*- coding: utf-8 -*-
"""Section 2 survey figures: accumulation, activation and positioning.

Every quantity plotted here is read off the survey the paper already prints:
the variant table of :mod:`upcl_variant_table` (Table 3) supplies the year, the
mechanism type, the composition level and the six mechanism columns, and Table 4
of Section 2 supplies the positioning comparison.

The manuscript figures are written straight into ``docs/figures`` under the names
registered in ``paper_figures.py``:

  * fig4_mechanism_timeline.png      mechanism accumulation -- drawn outside this
                                    project and placed in DIR by hand, so the
                                    script deliberately does not touch it
  * fig6_positioning_matrix.png      where a candidate-level layer sits

Two renderers are dormant.  ``fig_timeline`` no longer produces the accumulation
figure (an external illustration replaced it), and ``fig_activation`` produced
``fig5_dimension_level_matrix.png``, which was dropped from the manuscript.  Both
are kept so the figures can be regenerated if needed, but ``main`` calls only
``fig_positioning``.

Run from the repo root::

    python src/plot_tax_figs.py

Figures are drawn at 6.3 in wide (the manuscript text column) and 300 dpi.
"""
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Rectangle
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import upcl_variant_table as VT          # noqa: E402

OUT = ROOT / 'docs' / 'figures'
FIG_W = 6.3

# The manuscript palette, as the Chapter 4 scripts define it: the level colours
# of `plot_conv_final.LEVEL_COL` and `plot_upcl_paper.LEVEL_COLORS`, extended
# with the two NPG hues `analyze_mech_attribution` uses for further series.
# Keeping to these keeps the Section 2 figures in step with the rest of the
# paper; the heatmap cmap is `viridis`, the manuscript's choice for an unsigned
# fraction (see `analyze_mech_attribution._d1_assoc`).
NPG = ['#3C5488', '#00A087', '#E69F00', '#E64B35', '#4DBBD5', '#7E6148']


def _tint(colour, weight):
    """``weight`` of ``colour`` mixed into white: the pale fill of a tile."""
    return tuple(1.0 - weight * (1.0 - c) for c in mcolors.to_rgb(colour))

# --- (a) accumulation ------------------------------------------------------
# A variant is stacked under the mechanism type Tables 1-2 record for it, which
# is the column the surrounding text calls "the mechanism each entry
# contributes".  The six dimensions collapse to five by merging the archive
# into ensemble/other.
CATS = ['Mutation strategy', 'Parameter adaptation', 'Operator adaptation',
        'Population-size control', 'Ensemble / other']
CAT_COLORS = NPG[:5]
CAT_OF_TYPE = {
    'mutation strategy': 0,
    'parameter control': 1,
    'operator selection': 2,
    'population control': 3,
    'strategy ensemble': 4,
    'algorithm selection': 4,
    'crossover': 4,
    'hybrid': 4,
    'restart': 4,
    'selection': 4,
    'selection control': 4,
    'candidate correction': 4,
}

# --- (b) activation --------------------------------------------------------
# A dimension is active when it deviates from the level-0 baseline: an extended
# mutation strategy, a non-fixed parameter rule, an operator pool, an external
# archive, a non-static population, or an ensemble/other mechanism.  The
# mutation baseline is the set of hand-designed donors the classical era
# installs, so level 0 reads 0.00 by construction and later levels are measured
# against it.
_L0_MUTATIONS = {e[5] for e in VT.entries() if e[4] == 0}
DIMS = [
    ('Mutation', lambda e: e[5] not in _L0_MUTATIONS),
    ('Parameter rule', lambda e: e[6] != 'fixed'),
    ('Operator pool', lambda e: e[7] == 'pool'),
    ('External archive', lambda e: e[8] == 'yes'),
    ('Population size', lambda e: e[9] != 'static'),
    ('Ensemble / other', lambda e: e[10] != '-'),
]

# --- (c) positioning -------------------------------------------------------
# Mirrors Table 4 of ``upcl_part_bg.py``, restricted to the three columns the
# measurement requires.  Keep the two in step.
CODES = {'Yes': 0, 'No': 1, 'Partly': 2, '\u2014': 3}
SYMBOLS = {0: '\u2713', 1: '\u2717', 2: '~', 3: '\u2013'}
# Teal for a property the family has, amber for a partial match, the paper's
# light grey for one it lacks, and the level red for the row under discussion.
CELL_COLORS = [_tint(NPG[1], 0.30), '#E8E8E8', _tint(NPG[2], 0.30), '#FFFFFF']
POSITIONING = [
    ('Basic DE', '\u2014', 'No', '\u2014'),
    ('Self-adaptive / success-history parameters', 'No', 'No', 'No'),
    ('Ensembles over strategies or parameter pools', 'No', 'Yes', 'Yes'),
    ('Landscape-driven and learned selection', 'No', 'No', 'Yes'),
    ('Online configuration, modules, portfolios', 'No', 'No', 'Yes'),
    ('Bound repair', 'Yes', 'No', 'No'),
    ('Opposition-based candidates', 'Yes', 'Yes', 'No'),
    ('Memetic refinement', 'Yes', 'Yes', 'No'),
    ('Simplex, mesh, step-size, covariance rules', 'No', 'No', 'Partly'),
    ('Delayed rejection in adaptive MCMC', 'Yes', 'Yes', 'No'),
    ('Learned update rules', 'No', 'No', 'Yes'),
    ('UPCL (this paper)', 'Yes', 'No', 'Yes'),
]
POS_COLS = ['Opaque\nvariant', 'Adds\nevals', 'Gated\nonline']


def _style():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans',
        'font.size': 8,
        'axes.labelsize': 8,
        'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444',
        'xtick.color': '#333333',
        'ytick.color': '#333333',
        'xtick.labelsize': 6.5,
        'ytick.labelsize': 7,
        'legend.fontsize': 6.4,
        'legend.frameon': False,
        'figure.dpi': 300,
    })


def _bare(ax):
    for sp in ax.spines.values():
        sp.set_visible(False)


def cat_of(entry):
    """Stacking category of one variant, from its recorded mechanism type."""
    return CAT_OF_TYPE[entry[1].split(',')[0].strip()]


def activation():
    """``(matrix, column labels)``: level-by-level activation of each dimension."""
    mat = np.zeros((len(DIMS), 4))
    for lv in range(4):
        in_lv = [e for e in VT.entries() if e[4] == lv]
        for i, (_label, test) in enumerate(DIMS):
            mat[i, lv] = sum(1 for e in in_lv if test(e)) / len(in_lv)
    cols = [f'Lv {lv}\n(n = {VT.LEVELS[lv]})' for lv in range(4)]
    return mat, cols


def year_counts():
    """``(years, matrix)``: variants per year, stacked by category."""
    years = sorted({e[0] for e in VT.entries()})
    idx = {y: i for i, y in enumerate(years)}
    counts = np.zeros((len(CATS), len(years)))
    for e in VT.entries():
        counts[cat_of(e), idx[e[0]]] += 1
    return years, counts


def fig_timeline(path):
    years, counts = year_counts()
    x = np.arange(len(years))
    fig, ax = plt.subplots(figsize=(FIG_W, 2.9))
    bottom = np.zeros(len(years))
    for i, (label, col) in enumerate(zip(CATS, CAT_COLORS)):
        ax.bar(x, counts[i], bottom=bottom, width=0.82, color=col,
               edgecolor='white', linewidth=0.4, label=label)
        bottom += counts[i]
    ax.set_xticks(x[::2])
    ax.set_xticklabels([str(y) for y in years[::2]])
    ax.set_xlim(-0.8, len(years) - 0.2)
    ax.set_ylabel('Variants introduced')
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.legend(loc='lower left', bbox_to_anchor=(0.0, 1.01), ncol=3,
              handlelength=1.1, columnspacing=1.4, handletextpad=0.5)
    fig.subplots_adjust(left=0.085, right=0.99, top=0.82, bottom=0.14)
    fig.savefig(path, bbox_inches='tight')
    plt.close(fig)


def fig_activation(path, mat, cols):
    fig, ax = plt.subplots(figsize=(FIG_W, 2.6))
    ax.imshow(mat, cmap='viridis', vmin=0.0, vmax=1.0, aspect='auto')
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels(cols)
    ax.set_yticks(range(len(DIMS)))
    ax.set_yticklabels([d[0] for d in DIMS])
    ax.set_xticks(np.arange(-0.5, len(cols), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(DIMS), 1), minor=True)
    ax.grid(which='minor', color='white', linewidth=1.0)
    ax.tick_params(which='minor', length=0)
    for i in range(len(DIMS)):
        for j in range(len(cols)):
            v = mat[i, j]
            # viridis runs dark -> bright, so the numeral is set by the tile's
            # own brightness, as in the manuscript's other annotated heatmaps.
            lum = mcolors.rgb_to_hsv(plt.cm.viridis(v)[:3])[2]
            ax.text(j, i, '%.2f' % v, ha='center', va='center', fontsize=7,
                    color='white' if lum < 0.55 else '0.15')
    _bare(ax)
    fig.subplots_adjust(left=0.17, right=0.99, top=0.97, bottom=0.10)
    fig.savefig(path, bbox_inches='tight')
    plt.close(fig)


def fig_positioning(path):
    labels = [r[0] for r in POSITIONING]
    codes = np.array([[CODES[c] for c in r[1:]] for r in POSITIONING])
    fig, ax = plt.subplots(figsize=(FIG_W, 3.3))
    ax.imshow(codes, cmap=ListedColormap(CELL_COLORS), vmin=-0.5, vmax=3.5,
              aspect='auto')
    ax.set_xticks(range(3))
    ax.set_xticklabels(POS_COLS)
    ax.xaxis.set_ticks_position('top')
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels)
    ax.set_xticks(np.arange(-0.5, 3, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(labels), 1), minor=True)
    ax.grid(which='minor', color='#cccccc', linewidth=0.6)
    ax.tick_params(which='minor', length=0)
    for i in range(len(labels)):
        for j in range(3):
            ax.text(j, i, SYMBOLS[codes[i, j]], ha='center', va='center',
                    fontsize=11, color='#111111')
    ax.add_patch(Rectangle((-0.5, len(labels) - 1.5), 3, 1, fill=False,
                           edgecolor=NPG[3], linewidth=1.0))
    for i, lab in enumerate(ax.get_yticklabels()):
        if i == len(labels) - 1:
            lab.set_fontweight('bold')
    _bare(ax)
    fig.subplots_adjust(left=0.40, right=0.99, top=0.88, bottom=0.02)
    fig.savefig(path, bbox_inches='tight')
    plt.close(fig)


def main():
    _style()
    OUT.mkdir(parents=True, exist_ok=True)
    mat, cols = activation()

    # fig_timeline and fig_activation are deliberately not called: the
    # accumulation figure is an external illustration placed in docs/figures by
    # hand, and the activation matrix was dropped from the manuscript.
    fig_positioning(OUT / 'fig6_positioning_matrix.png')

    years, counts = year_counts()
    print('variants: %d over %d years (%d-%d)'
          % (VT.N, len(years), years[0], years[-1]))
    print('by category: ' + ', '.join(
        '%s %d' % (c, int(counts[i].sum())) for i, c in enumerate(CATS)))
    print()
    print('activation by composition level (fractions):')
    print('  %-18s %s' % ('', '  '.join(c.replace('\n', ' ') for c in cols)))
    for (label, _), row in zip(DIMS, mat):
        print('  %-18s %s' % (label, '  '.join('%.2f' % v for v in row)))
    print()
    print('monotone increasing:', [label for (label, _), row in zip(DIMS, mat)
                                   if all(row[i] <= row[i + 1] for i in range(3))])
    print('peak level (Lv):', {label: int(np.argmax(row))
                               for (label, _), row in zip(DIMS, mat)})
    print()
    for name in ('fig4_mechanism_timeline.png', 'fig6_positioning_matrix.png'):
        p = OUT / name
        print('%-34s %s' % (name, 'ok' if p.exists() else 'MISSING'))


if __name__ == '__main__':
    main()

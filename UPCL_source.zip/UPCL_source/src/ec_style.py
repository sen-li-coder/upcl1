# -*- coding: utf-8 -*-
"""Document engine that reproduces the layout of the reference EC-journal
manuscript (DASM_EC_Journal_SEC7.docx).

Layout contract extracted from the reference file
-------------------------------------------------
page      : A4 11906 x 16838 twips; margins top/bottom 1417, left/right 1247
default   : Times New Roman, 10 pt (w:sz 20), line spacing 1.15 (276/240),
            space after 6 pt (120 twips), justified (both)
heading 1 : 12 pt bold, before 18 pt, after 7 pt, keep-next
heading 2 : 11 pt bold, before 15 pt, after 6 pt
heading 3 : 10 pt bold, before 12 pt, after 5 pt
title     : 14 pt bold, centred
captions  : 9 pt; table caption above the table (keep-next), figure caption
            below the figure
code      : monospace (Consolas) 9 pt, single spacing
"""
import os
from pathlib import Path
import copy
import re

from docx import Document
from docx.shared import Inches, Pt, RGBColor, Emu
from docx.enum.text import (WD_ALIGN_PARAGRAPH, WD_LINE_SPACING,
                            WD_TAB_ALIGNMENT)
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement, parse_xml

import ec_omml

ROOT = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TEXT_WIDTH_IN = 6.54          # 11906 - 2*1247 twips
FIG_WIDTH_IN = 6.30
FIG_MAX_H_IN = 8.0            # cap tall figures so they never overflow a page

MATH_FONT = 'Cambria Math'
_MATH_UNICODE_RE = re.compile(
    '[\u0370-\u03FF\u2070-\u209F\u2190-\u22FF\u2300-\u23FF'
    '\u25A0-\u25FF\u27C0-\u27EF\u1D400-\u1D7FF\u2100-\u214F]')

# --------------------------------------------------------------------------
# Figure-path resolution and math-font normalisation, originally shared with
# the legacy LAES SCI builder.  They are inlined here so the UPCL document
# engine is self-contained after the LAES code was removed.
# --------------------------------------------------------------------------
_NON_ASCII_RE = re.compile(r'[^\x00-\x7F]')

FIG_FALLBACK_DIRS = [
    ROOT / 'paper_figures_highres',
]
FIG_FALLBACK_DIRS = [d for d in FIG_FALLBACK_DIRS if d.exists()]


def resolve_fig_path(requested):
    """Return the first readable path matching a figure file name by checking
    (a) the originally requested path, (b) the high-res fallback directory,
    then (c) the original path otherwise so callers can show their FIGURE
    MISSING placeholder."""
    if requested.exists():
        return requested
    name = requested.name
    for d in FIG_FALLBACK_DIRS:
        cand = d / name
        if cand.exists():
            return cand
    return requested  # caller still performs .exists() check


def _set_run_font(run, name='Cambria Math'):
    run.font.name = name
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.rFonts
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.append(rFonts)
    rFonts.set(qn('w:ascii'), name)
    rFonts.set(qn('w:hAnsi'), name)
    rFonts.set(qn('w:eastAsia'), name)
    rFonts.set(qn('w:cs'), name)


def _normalize_math_fonts(doc, font_name='Cambria Math'):
    """Force Cambria Math for runs that contain non-ASCII mathematical symbols."""
    for para in doc.paragraphs:
        for run in para.runs:
            if run.text and _NON_ASCII_RE.search(run.text):
                _set_run_font(run, font_name)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        if run.text and _NON_ASCII_RE.search(run.text):
                            _set_run_font(run, font_name)

# \textbf{..} / \emph{..} / \textit{..} in body text
_TEXT_MARKUP_RE = re.compile(r'\\(textbf|emph|textit)\{([^{}]*)\}')
# Italics are reserved for symbolic quantities (see `_is_parameter`).  A writer
# therefore cannot ask for italic emphasis: \emph and \textit mark the phrase
# but leave it upright, so that no amount of source markup can put an ordinary
# word into italic.
_EMPHASIS_IS_ITALIC = False
_LIST_STYLE_ALIAS = {'numbered': 'List Number', 'bullet': 'List Bullet'}


# --------------------------------------------------------------------------
#  low level helpers
# --------------------------------------------------------------------------
def _set_spacing(p, before=None, after=None, line=None):
    pf = p.paragraph_format
    if before is not None:
        pf.space_before = Pt(before)
    if after is not None:
        pf.space_after = Pt(after)
    if line is not None:
        pf.line_spacing = line
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE


_TBLPR_ORDER = ('w:tblStyle', 'w:tblpPr', 'w:tblOverlap', 'w:bidiVisual',
                'w:tblStyleRowBandSize', 'w:tblStyleColBandSize', 'w:tblW',
                'w:jc', 'w:tblCellSpacing', 'w:tblInd', 'w:tblBorders', 'w:shd',
                'w:tblLayout', 'w:tblCellMar', 'w:tblLook', 'w:tblCaption',
                'w:tblDescription')

_TCPR_ORDER = ('w:cnfStyle', 'w:tcW', 'w:gridSpan', 'w:hMerge', 'w:vMerge',
               'w:tcBorders', 'w:shd', 'w:noWrap', 'w:tcMar', 'w:textDirection',
               'w:tcFitText', 'w:vAlign', 'w:hideMark')

# The subset of `w:settings` this engine writes, in schema order.  `_orderly`
# keeps the insertion point correct so Word and WPS both honour the flags.
_SETTINGS_ORDER = ('w:zoom', 'w:defaultTabStop', 'w:autoHyphenation',
                   'w:consecutiveHyphenLimit', 'w:hyphenationZone',
                   'w:doNotHyphenateCaps', 'w:characterSpacingControl',
                   'w:compat', 'w:rsids', 'm:mathPr')


def _orderly(parent, order, tag, attrs=None):
    """(Re)insert one child of `parent` at the position its schema prescribes.

    Word and WPS both stop honouring `w:tblPr` children that appear after a
    later sibling, so a `tblW` appended at the end of the element silently
    loses the width and the table collapses onto its content.  The helper drops
    any existing copy and inserts a single new one in order.
    """
    for el in parent.findall(qn(tag)):
        parent.remove(el)
    el = OxmlElement(tag)
    for k, v in (attrs or {}).items():
        el.set(qn(f'w:{k}'), str(v))
    succ = set(order[order.index(tag) + 1:])
    for child in parent:
        name = next((t for t in order if qn(t) == child.tag), None)
        if name in succ:
            child.addprevious(el)
            return el
    parent.append(el)
    return el


def _zero_indent(p):
    """Table cells start flush with their edge.

    A first-line indent inherited from a paragraph style eats the width of the
    first line of every cell and shifts the continuation lines, which is what
    makes narrow columns wrap badly.
    """
    pf = p.paragraph_format
    pf.left_indent = Pt(0)
    pf.right_indent = Pt(0)
    pf.first_line_indent = Pt(0)


def _no_borders(table):
    borders = _orderly(table._tbl.tblPr, _TBLPR_ORDER, 'w:tblBorders')
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        b = OxmlElement(f'w:{side}')
        b.set(qn('w:val'), 'nil')
        borders.append(b)


def _cell_margins(table, twips=32):
    mar = _orderly(table._tbl.tblPr, _TBLPR_ORDER, 'w:tblCellMar')
    for side, val in (('top', 18), ('left', twips), ('bottom', 18), ('right', twips)):
        e = OxmlElement(f'w:{side}')
        e.set(qn('w:w'), str(val))
        e.set(qn('w:type'), 'dxa')
        mar.append(e)


def _set_cell_shading(cell, color_hex):
    _orderly(cell._tc.get_or_add_tcPr(), _TCPR_ORDER, 'w:shd',
             {'fill': color_hex, 'val': 'clear'})


def _shade_is_dark(color_hex, threshold=140):
    """True when an 'RRGGBB' fill (with or without '#' prefix) is dark enough
    to want white text."""
    try:
        v = color_hex.lstrip('#')
        r = int(v[0:2], 16)
        g = int(v[2:4], 16)
        b = int(v[4:6], 16)
    except (ValueError, TypeError, AttributeError):
        return False
    return (0.299 * r + 0.587 * g + 0.114 * b) < threshold


def _repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement('w:tblHeader')
    el.set(qn('w:val'), 'true')
    trPr.append(el)


def _cant_split(row):
    """Forbid a page break inside one table row."""
    trPr = row._tr.get_or_add_trPr()
    if trPr.find(qn('w:cantSplit')) is None:
        el = OxmlElement('w:cantSplit')
        el.set(qn('w:val'), 'true')
        trPr.append(el)


def _tc_rule(cell, top=None, bottom=None, color='000000'):
    """Horizontal rule drawn on a single cell (w:sz is in eighths of a point).

    The three-line table convention uses two rules: a heavy rule above the
    header and below the last row, and a light rule under the header only.
    """
    if top is None and bottom is None:
        return
    tcPr = cell._tc.get_or_add_tcPr()
    bdr = tcPr.find(qn('w:tcBorders'))
    if bdr is None:
        bdr = _orderly(tcPr, _TCPR_ORDER, 'w:tcBorders')
    for side, sz in (('top', top), ('bottom', bottom)):
        if not sz:
            continue
        e = OxmlElement(f'w:{side}')
        e.set(qn('w:val'), 'single')
        e.set(qn('w:sz'), str(sz))
        e.set(qn('w:space'), '0')
        e.set(qn('w:color'), color)
        bdr.append(e)


def _fixed_layout(table, width_in, center=True):
    """Pin the table to `width_in` and centre it in the text column."""
    tblPr = table._tbl.tblPr
    _orderly(tblPr, _TBLPR_ORDER, 'w:tblW',
             {'w': int(round(width_in * 1440)), 'type': 'dxa'})
    _orderly(tblPr, _TBLPR_ORDER, 'w:tblLayout', {'type': 'fixed'})
    if center:
        _orderly(tblPr, _TBLPR_ORDER, 'w:jc', {'val': 'center'})
        _orderly(tblPr, _TBLPR_ORDER, 'w:tblInd', {'w': 0, 'type': 'dxa'})


def _column_dxa(widths, ncols, total_in):
    """Column widths in twips that sum exactly to the text width.

    With explicit `widths` the proportions are kept; without them the columns
    are sized by their longest cell, with a compressive exponent so that one
    long description column does not starve the numeric ones.
    """
    total = int(round(total_in * 1440))
    if widths:
        tot = float(sum(widths)) or 1.0
        frac = [w / tot for w in widths]
    else:
        frac = None
    if frac is None:
        return [total // ncols] * ncols
    cols = [int(round(total * f)) for f in frac]
    cols[-1] += total - sum(cols)
    return cols


def _content_widths(header, rows, ncols, min_frac=0.07, power=0.8):
    """Proportional column widths inferred from cell content lengths."""
    raw = []
    for ci in range(ncols):
        longest = len(str(header[ci]))
        for row in rows:
            if ci < len(row) and row[ci] is not None:
                longest = max(longest, len(str(row[ci])))
        raw.append(max(longest, 3) ** power)
    tot = sum(raw) or 1.0
    frac = [r / tot for r in raw]
    # lift columns that would otherwise be narrower than one short word
    lifted = [max(f, min_frac) for f in frac]
    s = sum(lifted)
    return [f / s for f in lifted]


def _auto_align(header, rows, ncols, text_threshold=10):
    """Text columns are left-aligned, numeric columns centred.

    A column whose longest cell exceeds `text_threshold` characters is treated
    as text; short cells are treated as numbers and centred, which is how the
    three-line tables of the reference journal are set.
    """
    modes = []
    for ci in range(ncols):
        longest = 0
        for row in rows:
            if ci < len(row) and row[ci] is not None:
                longest = max(longest, len(str(row[ci])))
        modes.append('l' if longest > text_threshold else 'c')
    return ''.join(modes)


_MEASURE_STRIP = re.compile(r'[${}^\\]')
_MEASURE_CACHE = {}
_TNR_FILE = {False: r'C:\Windows\Fonts\times.ttf',
             True: r'C:\Windows\Fonts\timesbd.ttf'}


def _measure_pt(text, size_pt, bold=False):
    """Advance width of one string in points, on the body face.

    Tables are sized from their own content, so the width of a column has to be
    measured rather than guessed from the character count: `Times New Roman`
    sets "W" at roughly three times the advance of "i", and a table laid out on
    character counts leaves the wide columns cramped and the narrow ones full
    of air.  The font file is read once and cached; if it is unavailable the
    estimate falls back to the average advance of the face.
    """
    s = _MEASURE_STRIP.sub('', str(text))
    if not s:
        return 0.0
    try:
        from PIL import ImageFont
        key = (bold, int(round(size_pt * 4)))
        font = _MEASURE_CACHE.get(key)
        if font is None:
            font = ImageFont.truetype(_TNR_FILE[bold],
                                      max(1, int(round(size_pt * 4))))
            _MEASURE_CACHE[key] = font
        return font.getlength(s) / 4.0
    except Exception:                                   # pragma: no cover
        return 0.5 * size_pt * len(s)


def _natural_widths(header, rows, ncols, font_size, pad_in=0.10, min_in=0.30):
    """Width each column needs to hold its longest cell on one line."""
    out = []
    for ci in range(ncols):
        w = _measure_pt(header[ci], font_size, bold=True)
        for row in rows:
            if ci < len(row) and row[ci] is not None:
                w = max(w, _measure_pt(row[ci], font_size))
        out.append(max(w / 72.0 + pad_in, min_in))
    return out


def _pBdr(paragraph, sides=('top',), sz=8, val='single', color='000000', space=1):
    """Horizontal rules used by the three-line table convention."""
    pPr = paragraph._p.get_or_add_pPr()
    bdr = OxmlElement('w:pBdr')
    for s in sides:
        e = OxmlElement(f'w:{s}')
        e.set(qn('w:val'), val)
        e.set(qn('w:sz'), str(sz))
        e.set(qn('w:space'), str(space))
        e.set(qn('w:color'), color)
        bdr.append(e)
    pPr.append(bdr)


def _style_font(style, font, east=None):
    """Force every script slot of a paragraph/character style onto `font`;
    the East-Asian slot keeps `east` when given (so CJK runs may stay in a
    CJK face while Latin stays in `font`)."""
    rpr = style.element.get_or_add_rPr()
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts')
        rpr.insert(0, rf)
    for a in ('w:ascii', 'w:hAnsi', 'w:cs'):
        rf.set(qn(a), font)
    rf.set(qn('w:eastAsia'), east or font)


def _run_font(run, font, east=None):
    rpr = run._element.get_or_add_rPr()
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts')
        rpr.insert(0, rf)
    for a in ('w:ascii', 'w:hAnsi', 'w:cs'):
        rf.set(qn(a), font)
    rf.set(qn('w:eastAsia'), east or font)


_MNS = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'


def _omml_size(math_el, size_pt):
    """Carry the surrounding type size into the math object.

    Office Math does not inherit `w:sz` from the paragraph; the size has to be
    written into the `w:rPr` that every `m:r` may carry, otherwise every
    equation is rendered at the Normal-style size regardless of context.
    """
    if math_el is None or size_pt is None:
        return
    for mr in math_el.iter(_MNS + 'r'):
        rpr = mr.find(_MNS + 'rPr')
        if rpr is None:
            rpr = OxmlElement('m:rPr')
            mr.insert(0, rpr)
        wrpr = rpr.find(qn('w:rPr'))
        if wrpr is None:
            wrpr = OxmlElement('w:rPr')
            rpr.append(wrpr)
        for tag, val in (('w:sz', str(int(round(size_pt * 2)))),
                         ('w:szCs', str(int(round(size_pt * 2))))):
            e = wrpr.find(qn(tag))
            if e is None:
                e = OxmlElement(tag)
                wrpr.append(e)
            e.set(qn('w:val'), val)
        rf = wrpr.find(qn('w:rFonts'))
        if rf is None:
            rf = OxmlElement('w:rFonts')
            wrpr.insert(0, rf)
        for a in ('w:ascii', 'w:hAnsi'):
            rf.set(qn(a), MATH_FONT)


def _elem_font(el, font, east=None):
    """Set the face of a `w:r` element (used by the final font pass); the
    East-Asian slot keeps `east` when given."""
    rpr = el.find(qn('w:rPr'))
    if rpr is None:
        rpr = OxmlElement('w:rPr')
        el.insert(0, rpr)
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts')
        rpr.insert(0, rf)
    for a in ('w:ascii', 'w:hAnsi', 'w:cs'):
        rf.set(qn(a), font)
    rf.set(qn('w:eastAsia'), east or font)


# multi-letter fragments that denote a method, a benchmark or a mechanism
# rather than a product of variables, and are therefore set upright
_UPRIGHT_WORDS = {'kNN', 'GP', 'UCB', 'DE',
                  'CEC', 'SHADE', 'LSHADE', 'jDE', 'jSO', 'JADE', 'CoDE',
                  'CoBiDE', 'SaDE', 'EPSDE', 'ProxDE', 'DIDE', 'DRL', 'MS',
                  'LDV', 'ELA', 'FLA', 'STN', 'LAOS', 'DLM', 'PE', 'KT',
                  'AED', 'SP', 'PCB', 'SIMP', 'SST', 'TS', 'KD', 'CPU',
                  'IQR', 'MAD', 'PDF', 'CDF'}


# the two-letter symbols that, like single letters, denote a control
# parameter and are therefore the only multi-letter runs allowed to be italic
_PARAMETER_SYMBOLS = {'CR', 'NP', 'PS'}

# multi-letter operator and function names, always upright
_MATH_FUNCS = {'max', 'min', 'clip', 'rand', 'ln', 'log', 'exp', 'sqrt',
               'arg', 'argmax', 'argmin', 'sign', 'abs', 'mean', 'std',
               'var', 'median', 'rank', 'round', 'floor', 'ceil', 'sin',
               'cos', 'tan', 'det', 'dim', 'diag', 'trace', 'if', 'else',
               'and', 'or', 'not', 'where', 'for', 'all'}


def _is_parameter(s):
    """True only for a run that denotes a symbolic quantity.

    The manuscript uses italics sparingly: a run is italicised when it is a
    single Latin letter standing for a quantity, or one of the conventional
    two-letter control-parameter symbols.  Everything else - operator and
    function names, textual subscripts, acronyms, labels, units, digits,
    brackets, operators and Greek letters - is ordinary text.
    """
    if len(s) == 1:
        return s.isascii() and s.isalpha()
    return s in _PARAMETER_SYMBOLS


def _is_upright(s):
    """True when a math run is ordinary text rather than a symbolic quantity."""
    t = s.strip()
    if not t:
        return True                         # empty run
    return not _is_parameter(t)


def _math_font(run):
    run.font.name = MATH_FONT
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    for a in ('w:ascii', 'w:hAnsi', 'w:eastAsia', 'w:cs'):
        rFonts.set(qn(a), MATH_FONT)


class Paper:
    """Accumulates the manuscript and owns every running counter."""

    def __init__(self, lang='en'):
        # `lang='zh'` switches the fixed labels (Abstract / Key words /
        # References / Table / Fig. / Algorithm / corresponding author) to
        # Chinese and keeps CJK runs in a CJK face (SimSun) while Latin and
        # digits stay in Times New Roman, so a translated manuscript keeps the
        # exact same layout as the English original.
        self.lang = lang
        zh = (lang == 'zh')
        self._labels = {
            'abstract': '摘要' if zh else 'Abstract',
            'keywords': '关键词' if zh else 'Key words',
            'references': '参考文献' if zh else 'References',
            'table': '表' if zh else 'Table',
            'figure': '图' if zh else 'Fig.',
            'algorithm': '算法' if zh else 'Algorithm',
            'corresponding': '* 通讯作者' if zh else '* Corresponding author.',
        }
        self._cjk_font = '宋体' if zh else None
        self.doc = Document()
        self._setup_page()
        self._setup_styles()
        self.fig_no = 0
        self.tab_no = 0
        # Tables moved out of the main text are numbered in their own series
        # (Table A1, A2, ...); the main counter is left untouched so that
        # every later main-table reference renumbers itself.
        self.app_tab_no = 0
        # Basenames of every image actually embedded, in placement order. The
        # paper-figure registry audits this against `docs/figures` so that a
        # figure added to or deleted from the manuscript cannot leave a stale
        # reference behind (see `paper_figures.audit`).
        self.figure_files = []
        self.eq_no = 0
        self.alg_no = 0
        # Base numbering of the current part, set by `mark_part_base()`. Used to
        # resolve {tN} / {fN} cross-reference placeholders in body text, where
        # {tN} is the N-th table of the part and {fN} the N-th figure of it.
        self._part_tab_base = 0
        self._part_fig_base = 0
        # set by `equation`; the next `para` is a "where ..." continuation
        self._after_eq = False
        # citation bookkeeping: numbered in order of first appearance
        self.ref_order = []
        self.ref_num = {}
        self.unknown_refs = set()
        self.uncited_refs = []
        self._style_name_cache = None
        # running counter for manually numbered lists (restarts per list)
        self._num_list_count = 0

    def _style_names(self):
        if self._style_name_cache is None:
            self._style_name_cache = {s.name for s in self.doc.styles}
        return self._style_name_cache

    # ---------------- citations ----------------
    def cite(self, key):
        """Register a reference key; return the bracketed citation number."""
        if key not in self.ref_num:
            self.ref_num[key] = len(self.ref_order) + 1
            self.ref_order.append(key)
        return f'[{self.ref_num[key]}]'

    def txt(self, s):
        """Expand [@KEY] markers into numbered citations (first-use order)."""
        if s is None:
            return s
        s = str(s)
        # Repair Python escape sequences that silently became control
        # characters inside non-raw literals (e.g. \alpha -> BEL).
        for ctrl, esc in (('\x07', '\\a'), ('\x08', '\\b'), ('\x0c', '\\f'),
                          ('\x0b', '\\v'), ('\t', '\\t')):
            if ctrl in s:
                s = s.replace(ctrl, esc)
        if '\n' in s or '\r' in s:
            print('[WARN] newline inside body text:', repr(s[:90]))

        def rep(m):
            return self.cite(m.group(1))

        s = re.sub(r'\[@([A-Za-z0-9_]+)\]', rep, s)
        # Resolve part-relative cross-reference placeholders {tN} / {fN} that
        # were written as plain literals (so LaTeX braces stay untouched).
        if '{t' in s or '{f' in s:
            s = re.sub(r'\{t(\d+)\}',
                       lambda m: str(self._part_tab_base + int(m.group(1))), s)
            s = re.sub(r'\{f(\d+)\}',
                       lambda m: str(self._part_fig_base + int(m.group(1))), s)
        return s

    def mark_part_base(self):
        """Record the current figure/table counters as this part's base, so
        subsequent {tN} / {fN} placeholders resolve against them."""
        self._part_tab_base = self.tab_no
        self._part_fig_base = self.fig_no

    # ---------------- document setup ----------------
    def _setup_page(self):
        for s in self.doc.sections:
            s.page_width = Emu(int(11906 * 635))       # twips -> EMU
            s.page_height = Emu(int(16838 * 635))
            s.top_margin = Emu(int(1417 * 635))
            s.bottom_margin = Emu(int(1417 * 635))
            s.left_margin = Emu(int(1247 * 635))
            s.right_margin = Emu(int(1247 * 635))
            s.header_distance = Emu(int(709 * 635))
            s.footer_distance = Emu(int(709 * 635))
        normal = self.doc.styles['Normal']
        normal.font.name = 'Times New Roman'
        normal.font.size = Pt(10)
        rpr = normal.element.get_or_add_rPr()
        rf = rpr.find(qn('w:rFonts'))
        if rf is None:
            rf = OxmlElement('w:rFonts')
            rpr.insert(0, rf)
        for a in ('w:ascii', 'w:hAnsi', 'w:cs'):
            rf.set(qn(a), 'Times New Roman')
        rf.set(qn('w:eastAsia'), self._cjk_font or 'Times New Roman')
        # the proofing language decides which hyphenation dictionary applies:
        # without an explicit Latin language the renderer falls back to the
        # East-Asian one and silently skips hyphenation entirely
        lang = OxmlElement('w:lang')
        lang.set(qn('w:val'), 'en-US')
        lang.set(qn('w:eastAsia'), 'zh-CN' if self._cjk_font else 'en-US')
        rpr.append(lang)
        # a single trailing line of a paragraph, or its first line alone under
        # a heading, is the most visible layout defect in a long manuscript
        normal.paragraph_format.widow_control = True
        self._setup_hyphenation()
        self._setup_footer()

    def _setup_hyphenation(self):
        """Let the typesetter break long words at line ends.

        The body is set justified, and without hyphenation a line that falls
        between two long words is stretched until the gaps dominate the line.
        Enabling automatic hyphenation with a narrow zone and a limit of three
        consecutive hyphens removes those lines while keeping ragged edges out
        of the page.  Word and WPS both read these flags from `settings.xml`.
        """
        s = self.doc.settings.element
        _orderly(s, _SETTINGS_ORDER, 'w:autoHyphenation', {'val': '1'})
        _orderly(s, _SETTINGS_ORDER, 'w:consecutiveHyphenLimit', {'val': '3'})
        _orderly(s, _SETTINGS_ORDER, 'w:hyphenationZone', {'val': '360'})
        _orderly(s, _SETTINGS_ORDER, 'w:doNotHyphenateCaps', {'val': '1'})

    def _setup_footer(self):
        """Centred page number in the footer of every page."""
        for sec in self.doc.sections:
            p = sec.footer.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _set_spacing(p, 0, 0, 1.0)
            p.paragraph_format.widow_control = True
            r = p.add_run()
            r.font.name = 'Times New Roman'
            r.font.size = Pt(9)
            _style_font_el = r._element.get_or_add_rPr()
            rf = _style_font_el.find(qn('w:rFonts'))
            if rf is None:
                rf = OxmlElement('w:rFonts')
                _style_font_el.insert(0, rf)
            rf.set(qn('w:ascii'), 'Times New Roman')
            rf.set(qn('w:hAnsi'), 'Times New Roman')
            fld = OxmlElement('w:fldChar')
            fld.set(qn('w:fldCharType'), 'begin')
            instr = OxmlElement('w:instrText')
            instr.set(qn('xml:space'), 'preserve')
            instr.text = ' PAGE '
            sep = OxmlElement('w:fldChar')
            sep.set(qn('w:fldCharType'), 'separate')
            val = OxmlElement('w:t')
            val.text = '1'
            end = OxmlElement('w:fldChar')
            end.set(qn('w:fldCharType'), 'end')
            for el in (fld, instr, sep, val, end):
                r._element.append(el)

    def _setup_styles(self):
        d = self.doc
        # Journal convention: the section number carries no trailing dot and
        # every heading is set flush left.
        for name, size, before, after in (('Heading 1', 12, 18, 7),
                                          ('Heading 2', 11, 15, 6),
                                          ('Heading 3', 10, 12, 5)):
            st = d.styles[name]
            st.font.name = 'Times New Roman'
            st.font.size = Pt(size)
            st.font.bold = True
            st.font.color.rgb = RGBColor(0, 0, 0)
            pf = st.paragraph_format
            pf.space_before = Pt(before)
            pf.space_after = Pt(after)
            pf.line_spacing = 1.15
            pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
            pf.keep_with_next = True
            pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
            _style_font(st, 'Times New Roman', self._cjk_font)

    # ---------------- building blocks ----------------
    def title_block(self, title, authors, affiliations, email):
        # document properties travel with the file: the title bar and the PDF
        # export both read them, and an untitled manuscript shows up as
        # "python-docx" everywhere it is listed
        cp = self.doc.core_properties
        cp.title = title
        cp.author = authors[0] if authors else ''
        cp.last_modified_by = authors[0] if authors else ''
        cp.language = 'zh-CN' if self.lang == 'zh' else 'en-US'
        cp.comments = ''
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(title)
        r.bold = True
        r.font.size = Pt(14)
        r.font.name = 'Times New Roman'
        _set_spacing(p, 0, 6)
        for line in authors:
            p = self.doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(line)
            r.font.size = Pt(10)
            _set_spacing(p, 0, 2)
        for line in [x for x in affiliations + [email, self._labels['corresponding']] if x]:
            p = self.doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(line)
            r.font.size = Pt(9.5)
            _set_spacing(p, 0, 2)
        return self

    def abstract(self, text):
        """Single-paragraph abstract, indented from both margins as in the
        reference journal; the label is set in bold on the same line."""
        p = self.doc.add_paragraph()
        _set_spacing(p, 10, 6, 1.15)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf = p.paragraph_format
        pf.left_indent = Inches(0.35)
        pf.right_indent = Inches(0.35)
        r = p.add_run(self._labels['abstract'] + '  ')
        r.bold = True
        r.font.size = Pt(9.5)
        self._emit(p, text, 9.5)
        return p

    def keywords(self, text):
        p = self.doc.add_paragraph()
        _set_spacing(p, 0, 14, 1.15)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf = p.paragraph_format
        pf.left_indent = Inches(0.35)
        pf.right_indent = Inches(0.35)
        r = p.add_run(self._labels['keywords'] + '  ')
        r.bold = True
        r.font.size = Pt(9.5)
        r2 = p.add_run(text)
        r2.font.size = Pt(9.5)
        return p

    def h1(self, text):
        self._after_eq = False
        self._reset_list()
        return self.doc.add_paragraph(text, style='Heading 1')

    def h2(self, text, numbered=None):
        self._after_eq = False
        self._reset_list()
        return self.doc.add_paragraph(text, style='Heading 2')

    def h3(self, text):
        self._after_eq = False
        self._reset_list()
        return self.doc.add_paragraph(text, style='Heading 3')

    def para(self, text, lead=None, indent=True):
        """Body paragraph; `lead` is rendered bold (contribution-style lead-in).

        Every body paragraph carries a first-line indent, including the one
        that opens a section.  The paragraph that immediately follows a display
        equation, typically the "where ..." clause, is flush left so that it
        reads as a continuation of the equation.
        """
        after_eq = getattr(self, '_after_eq', False)
        self._after_eq = False
        self._reset_list()
        p = self.doc.add_paragraph()
        _set_spacing(p, 0, 6, 1.15)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        if indent and not after_eq:
            p.paragraph_format.first_line_indent = Inches(0.28)
        if lead:
            r = p.add_run(self.txt(lead))
            r.bold = True
            r.font.size = Pt(10)
        self._rich(p, self.txt(text))
        return p

    def _reset_list(self):
        """End any running numbered list so the next one restarts at 1."""
        self._num_list_count = 0

    def bullet(self, text, lead=None, style=None):
        """Indented list entry.

        The built-in list styles draw their marker from the Symbol font, which
        puts a stray round glyph in front of every entry; here the hanging
        indent alone marks the item, so the paragraph stays in the body face.
        `style` accepts the aliases 'Numbered' and 'Bullet'; an unknown style
        name is ignored rather than raising.  Numbered entries are numbered
        manually here, so each contiguous run restarts at 1 instead of
        inheriting Word's document-wide 'List Number' counter across sections.
        """
        style = _LIST_STYLE_ALIAS.get(str(style).lower(), style)
        numbered = (style == 'List Number')
        if numbered:
            self._num_list_count += 1
            n = self._num_list_count
            style = None            # manual numbering, no Word auto-number
        else:
            self._reset_list()
        if style and style not in self._style_names():
            style = None
        p = self.doc.add_paragraph(style=style)
        _set_spacing(p, 0, 4, 1.15)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf = p.paragraph_format
        pf.left_indent = Inches(0.30)
        pf.first_line_indent = Inches(0.0)
        if numbered:
            r = p.add_run(f'{n}.\t')
            r.font.size = Pt(10)
        if lead:
            r = p.add_run(self.txt(lead))
            r.bold = True
            r.font.size = Pt(10)
        self._rich(p, self.txt(text))
        return p

    # ---------------- mathematics ----------------
    def _omml(self, tex, size_pt=10, display=False):
        """Insert `tex` as a native Office Math object; fall back to unicode."""
        xml = (ec_omml.omml_display(tex) if display
               else ec_omml.omml_inline(tex))
        return xml, (None if xml else ec_omml.latex_to_unicode(tex))

    def _add_math(self, p, tex, size_pt=10, display=False):
        xml, plain = self._omml(tex, size_pt, display)
        if xml is not None:
            try:
                el = parse_xml(xml)
                p._p.append(el)
                _omml_size(el, size_pt)
                return True
            except Exception as exc:              # pragma: no cover
                print('[math insert failed]', tex[:60], exc)
                plain = ec_omml.latex_to_unicode(tex)
        r = p.add_run(plain if plain else tex)
        r.font.size = Pt(size_pt)
        _math_font(r)
        return False

    def _emit(self, p, text, size_pt=10, bold=False, italic=False):
        """Add `text`; every $...$ fragment becomes an editable math object.

        Outside mathematics, the lightweight LaTeX text markup
        ``\\textbf{..}`` and ``\\emph{..}`` is mapped to the corresponding
        run attribute instead of being emitted verbatim.
        """
        segments = re.split(r'(\$[^$]+\$)', text)
        for seg in segments:
            if not seg:
                continue
            if seg.startswith('$') and seg.endswith('$') and len(seg) > 2:
                self._add_math(p, seg[1:-1], size_pt)
                continue
            self._emit_markup(p, seg, size_pt, bold, italic)

    def _emit_markup(self, p, text, size_pt, bold, italic):
        pos = 0
        for m in _TEXT_MARKUP_RE.finditer(text):
            if m.start() > pos:
                self._add_text_run(p, text[pos:m.start()], size_pt,
                                   bold, italic)
            tag = m.group(1)
            emph_italic = _EMPHASIS_IS_ITALIC and tag in ('emph', 'textit')
            self._add_text_run(p, m.group(2), size_pt,
                               bold or tag == 'textbf',
                               italic or emph_italic)
            pos = m.end()
        if pos < len(text):
            self._add_text_run(p, text[pos:], size_pt, bold, italic)

    def _add_text_run(self, p, text, size_pt, bold, italic):
        if not text:
            return
        r = p.add_run(text)
        r.font.size = Pt(size_pt)
        if bold:
            r.bold = True
        if italic:
            r.italic = True
        if _MATH_UNICODE_RE.search(text):
            _math_font(r)

    def _rich(self, p, text):
        """Body-level emit at 10 pt."""
        self._emit(p, text, 10)

    # ---------------- equations ----------------
    def equation(self, tex):
        """Display equation, centred between a centre tab stop and a right tab
        stop that carries the number:  <tab> formula <tab> (n)."""
        self.eq_no += 1
        self._reset_list()
        n = self.eq_no
        tag = f'({n})'
        tex = tex.strip()
        if tex.startswith('$') and tex.endswith('$'):
            tex = tex[1:-1]
        p = self.doc.add_paragraph()
        _set_spacing(p, 8, 8, 1.0)
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        pf = p.paragraph_format
        tabs = pf.tab_stops
        tabs.add_tab_stop(Inches(TEXT_WIDTH_IN / 2.0),
                          WD_TAB_ALIGNMENT.CENTER)
        tabs.add_tab_stop(Inches(TEXT_WIDTH_IN), WD_TAB_ALIGNMENT.RIGHT)
        r = p.add_run('\t')
        r.font.size = Pt(10.5)
        r.font.name = 'Times New Roman'
        self._add_math(p, tex, 10.5, display=True)
        rt = p.add_run('\t' + tag)
        rt.font.size = Pt(10)
        rt.font.name = 'Times New Roman'
        self._after_eq = True
        return tag

    # ---------------- figures / tables ----------------
    @staticmethod
    def _image_size(path):
        """Return ``(width, height)`` in pixels, or ``None`` if unreadable."""
        try:
            from PIL import Image
            with Image.open(path) as im:
                return im.size
        except Exception:
            return None

    def figure(self, filename, caption, width_in=FIG_WIDTH_IN, note=None,
               keep_together=False):
        """Place a figure with its caption, and an optional footnote.

        `caption` is the numbered caption line under the image; `note` is a
        small-print explanatory footnote set beneath the caption (same size and
        justification as a table note), used for the legend of the annotations
        drawn inside the image.  `keep_together` keeps the image and its caption
        on one page instead of letting the caption fall over a page break.
        """
        self.fig_no += 1
        self._reset_list()
        n = self.fig_no
        self.figure_files.append(Path(filename).name)
        path = resolve_fig_path(Path(filename))
        if not path.exists():
            path = resolve_fig_path(ROOT / 'paper_figures_highres' / Path(filename).name)
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_spacing(p, 10, 4, 1.0)
        if path.exists():
            try:
                size = self._image_size(path)
                target_w = width_in
                if size and size[0] > 0 and size[1] > 0:
                    target_h = target_w * size[1] / size[0]
                    if target_h > FIG_MAX_H_IN:
                        target_w = FIG_MAX_H_IN * size[0] / size[1]
                p.add_run().add_picture(str(path), width=Inches(target_w))
            except Exception as exc:                  # pragma: no cover
                r = p.add_run(f'[figure embed failed: {exc}]')
                r.font.color.rgb = RGBColor(0x99, 0, 0)
        else:
            r = p.add_run(f'[FIGURE MISSING: {filename}]')
            r.italic = True
            r.font.color.rgb = RGBColor(0x99, 0, 0)
        # The caption always belongs to its image: a page break between the two
        # is the classic figure defect, and the figure constraint keeps the
        # image itself below `FIG_MAX_H_IN`, so the pair still fits a page.
        p.paragraph_format.keep_with_next = True
        self._caption(f'{self._labels["figure"]} {n}.  ', caption,
                      after=3 if note else 14, before=2,
                      keep_lines=True,
                      keep_next=bool(note))
        if note:
            p = self.doc.add_paragraph()
            _set_spacing(p, 0, 12, 1.0)
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            self._emit(p, self.txt(note), 8)
        return n

    def _caption(self, label, text, before=7, after=3, keep_next=False,
                 keep_lines=False):
        self._reset_list()
        p = self.doc.add_paragraph()
        _set_spacing(p, before, after, 1.0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if keep_next:
            p.paragraph_format.keep_with_next = True
        if keep_lines:
            p.paragraph_format.keep_together = True
        r = p.add_run(label)
        r.bold = True
        r.font.size = Pt(9)
        self._emit(p, self.txt(text), 9)

    def table_caption(self, text, appendix=False):
        """Number a table and set its caption; return the number as a string.

        ``appendix=True`` numbers the table in the appendix series
        (``Table A1``, ``Table A2``, ...) and does not advance the main
        counter, so a table can be moved between the main text and the
        appendix without renumbering anything else by hand.
        """
        if appendix:
            self.app_tab_no += 1
            num = f'A{self.app_tab_no}'
        else:
            self.tab_no += 1
            num = str(self.tab_no)
        self._caption(f'{self._labels["table"]} {num}  ', text, before=7,
                      after=3, keep_next=True, keep_lines=True)
        return num

    def table(self, header, rows, widths=None, font_size=9, align=None,
              note=None, bold_best=None, shades=None, keep_together=None):
        """Three-line table: heavy rules at head and foot, one light rule under
        the header, no vertical rules and no interior rules.

        `align` is a string of 'l' / 'c' / 'r', one character per column;
        `bold_best` is a set of (row, col) indices rendered in bold; `shades`
        is a 2-D list of '#RRGGBB' fills (or None) shaped like `rows`, applied
        to the body cells (dark fills switch the text to white).  `keep_together`
        asks Word to move the caption and the whole table to the next page
        rather than break it; by default a table of at most ten body rows is
        kept whole, because a short table broken over a page leaves a stray
        row under a repeated header at the top of the next page.  Long result
        tables must be allowed to break, with their head repeated.
        """
        self._reset_list()
        t = self.doc.add_table(rows=1, cols=len(header))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        _no_borders(t)
        _cell_margins(t, 30)
        if not align:
            align = _auto_align(header, rows, len(header))
        ncol = len(header)
        if widths:
            # caller-supplied proportions run across the full measure
            total_in = TEXT_WIDTH_IN
            cols = _column_dxa(widths, ncol, total_in)
        else:
            nat = _natural_widths(header, rows, ncol, font_size)
            if (max(nat) <= TEXT_WIDTH_IN * 0.55
                    and sum(nat) <= TEXT_WIDTH_IN * 0.95):
                # A short, self-contained table reads better at its own width
                # and centred: stretching five narrow columns over the whole
                # measure scatters the entries until the rows no longer scan.
                total_in = max(sum(nat), TEXT_WIDTH_IN * 0.55)
                cols = _column_dxa(nat, ncol, total_in)
            else:
                # A wide table (a long description column, a 10-column result
                # grid) fills the measure, with the columns proportioned by
                # content.
                total_in = TEXT_WIDTH_IN
                cols = _column_dxa(_content_widths(header, rows, ncol), ncol,
                                   total_in)
        _fixed_layout(t, total_in)
        for i in range(len(header)):
            t.columns[i].width = Inches(cols[i] / 1440.0)
        hdr = t.rows[0]
        _repeat_header(hdr)
        for i, h in enumerate(header):
            c = hdr.cells[i]
            c.width = t.columns[i].width
            c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = c.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _set_spacing(p, 3, 3, 1.0)
            _zero_indent(p)
            self._emit(p, self.txt(str(h)), font_size, bold=True)
            _tc_rule(c, top=12, bottom=8)          # head rule + mid rule
        for ri, row in enumerate(rows):
            tr = t.add_row()
            _cant_split(tr)
            cells = tr.cells
            for ci, val in enumerate(row):
                if ci >= len(header):
                    break
                c = cells[ci]
                c.width = t.columns[ci].width
                c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                shade = (shades[ri][ci] if shades and ri < len(shades)
                         and ci < len(shades[ri]) else None)
                if shade:
                    _set_cell_shading(c, shade)
                p = c.paragraphs[0]
                _set_spacing(p, 1.5, 1.5, 1.0)
                _zero_indent(p)
                mode = align[ci] if align and ci < len(align) else None
                if mode == 'l':
                    # 长文本描述列保持左对齐，短文本/名称列居中
                    longest = max((len(str(row[ci])) for row in rows
                                   if ci < len(row) and row[ci] is not None),
                                  default=0)
                    p.alignment = (WD_ALIGN_PARAGRAPH.LEFT if longest > 20
                                   else WD_ALIGN_PARAGRAPH.CENTER)
                else:
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                text = '' if val is None else str(self.txt(val))
                self._emit(p, text, font_size,
                           bold=bool(bold_best and (ri, ci) in bold_best))
                if shade and _shade_is_dark(shade):
                    for r in p.runs:
                        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        for c in t.rows[-1].cells:
            _tc_rule(c, bottom=12)                 # foot rule
        if keep_together is None:
            keep_together = (len(rows) + 1) <= 10
        if keep_together:
            for r in t.rows[:-1]:
                for c in r.cells:
                    for p in c.paragraphs:
                        p.paragraph_format.keep_with_next = True
        if note:
            p = self.doc.add_paragraph()
            _set_spacing(p, 3, 10, 1.0)
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            self._emit(p, self.txt(note), 8)
        else:
            self._table_spacer()
        return t

    def _table_spacer(self, after=8):
        """Fixed gap between a table and the text that follows it.

        A default empty paragraph is one body line tall, so the apparent gap
        varies with the line pitch and, when the gap lands on a page break,
        leaves a stray blank line at the top of the next page.  A 4 pt
        paragraph mark plus 8 pt of space after gives a constant 12 pt gap.
        """
        p = self.doc.add_paragraph()
        _set_spacing(p, 0, after, 1.0)
        pPr = p._p.get_or_add_pPr()
        rPr = OxmlElement('w:rPr')
        for tag in ('w:sz', 'w:szCs'):
            e = OxmlElement(tag)
            e.set(qn('w:val'), '8')
            rPr.append(e)
        pPr.append(rPr)

    # ---------------- pseudocode ----------------
    def algorithm(self, caption_text, lines):
        """Pseudocode set as a three-line table.

        The title row carries the head rule and the mid rule, the last code row
        carries the foot rule, and no vertical or interior rule is drawn.  A
        `$...$` fragment inside a code line becomes an editable math object,
        so the symbols obey the same italic rules as in the body text.
        """
        self.alg_no += 1
        self._reset_list()
        n = self.alg_no
        num_w = 0.42
        t = self.doc.add_table(rows=1, cols=2)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        _no_borders(t)
        _fixed_layout(t, TEXT_WIDTH_IN)
        _cell_margins(t, 60)
        t.columns[0].width = Inches(num_w)
        t.columns[1].width = Inches(TEXT_WIDTH_IN - num_w)
        # title row, merged across both columns
        cells = t.rows[0].cells
        head = cells[0].merge(cells[1])
        head.width = Inches(TEXT_WIDTH_IN)
        head.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        hp = head.paragraphs[0]
        _set_spacing(hp, 3, 3, 1.0)
        hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        hr = hp.add_run(self.txt(f'{self._labels["algorithm"]} {n}.  {caption_text}'))
        hr.bold = True
        hr.font.size = Pt(9)
        _run_font(hr, 'Times New Roman', self._cjk_font)
        _tc_rule(head, top=12, bottom=8)
        # code rows: line number on the left, statement on the right
        for i, line in enumerate(lines, start=1):
            cells = t.add_row().cells
            cells[0].width = Inches(num_w)
            cells[1].width = Inches(TEXT_WIDTH_IN - num_w)
            cells[0].vertical_alignment = WD_ALIGN_VERTICAL.TOP
            cells[1].vertical_alignment = WD_ALIGN_VERTICAL.TOP
            pn = cells[0].paragraphs[0]
            _set_spacing(pn, 0, 0, 1.0)
            pn.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            rn = pn.add_run(f'{i}')
            rn.font.size = Pt(8.5)
            _run_font(rn, 'Times New Roman')
            pc = cells[1].paragraphs[0]
            _set_spacing(pc, 0, 0, 1.0)
            pc.alignment = WD_ALIGN_PARAGRAPH.LEFT
            pc.paragraph_format.left_indent = Inches(0.10)
            self._emit(pc, self.txt(line), 8.5)
        for c in t.rows[-1].cells:
            _tc_rule(c, bottom=12)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(6)
        return n

    # ---------------- references ----------------
    def _numbered_refs(self, entries, drop_uncited=False):
        out = []
        for i, key in enumerate(self.ref_order, start=1):
            if key in entries:
                out.append(f'[{i}] {entries[key]}')
            else:
                self.unknown_refs.add(key)
                out.append(f'[{i}] MISSING REFERENCE KEY: {key}')
        for key in entries:
            if key not in self.ref_num:      # cited nowhere
                self.uncited_refs.append(key)
                if not drop_uncited:         # drafting: keep them as a tail
                    out.append(f'[{len(out)+1}] {entries[key]} (uncited)')
        return out

    def references(self, entries, drop_uncited=False):
        """`entries` is a dict key -> reference string (printed form, see
        `refs_style`); numbering follows the order in which each key was first
        cited.  With ``drop_uncited=True`` the entries that no text cites are
        kept out of the list (their keys are still collected in
        ``self.uncited_refs``)."""
        self.h1(self._labels['references'])
        entries = dict(entries)
        for e in self._numbered_refs(entries, drop_uncited=drop_uncited):
            p = self.doc.add_paragraph()
            _set_spacing(p, 0, 3, 1.15)
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            pf = p.paragraph_format
            pf.left_indent = Inches(0.30)
            pf.first_line_indent = Inches(-0.30)
            r = p.add_run(e)
            r.font.size = Pt(9.5)

    # ---------------- citation range collapsing ----------------
    def _all_paragraphs(self):
        for p in self.doc.paragraphs:
            yield p
        for t in self.doc.tables:
            for row in t.rows:
                for c in row.cells:
                    for p in c.paragraphs:
                        yield p

    def _merge_citations(self):
        """Collapse consecutive markers '[3] [4] [5]' into '[3-5]'."""
        def rep(m):
            nums = [int(x) for x in re.findall(r'\d+', m.group(0))]
            runs_, start, prev = [], nums[0], nums[0]
            for n in nums[1:]:
                if n == prev + 1:
                    prev = n
                    continue
                runs_.append((start, prev))
                start = prev = n
            runs_.append((start, prev))
            parts = []
            for a, b in runs_:
                if b - a >= 2:
                    parts.append(f'{a}-{b}')
                elif b - a == 1:
                    parts.append(f'{a},{b}')
                else:
                    parts.append(str(a))
            return ('[' + ','.join(parts) + ']'
                    + (' ' if m.group(0).endswith(' ') else ''))

        for p in self._all_paragraphs():
            for r in p.runs:
                if not r.text or '[' not in r.text:
                    continue
                if r._element.find(qn('w:drawing')) is not None:
                    continue
                r.text = re.sub(r'(?:\[\d+\]\s?){2,}', rep, r.text)

    # ---------------- final pass ----------------
    def _force_body_font(self, font='Times New Roman'):
        """Every run outside a math object is set in the body face; CJK runs
        keep the document's East-Asian face when one is configured."""
        count = 0
        for r in self.doc.element.body.iter(qn('w:r')):
            if any(a.tag.startswith(_MNS) for a in r.iterancestors()):
                continue
            _elem_font(r, font, self._cjk_font)
            count += 1
        return count

    def _split_math_delims(self):
        """Delimiters are ordinary text, not variables.

        A mixed run such as ``f(`` or ``(a)`` inherits the variable's italic
        style, which renders the parentheses slanted. Split every mixed run so
        that parentheses, brackets, braces and separators occupy their own run
        and are forced upright.
        """
        delims = set('()[]{}|,;')
        changed = 0
        for mr in list(self.doc.element.body.iter(_MNS + 'r')):
            t = mr.find(_MNS + 't')
            if t is None:
                continue
            s = t.text or ''
            if len(s) < 2 or not any(ch in delims for ch in s):
                continue
            if all(ch in delims for ch in s):
                continue
            segs, buf, flag = [], '', None
            for ch in s:
                d = ch in delims
                if flag is None:
                    flag, buf = d, ch
                elif flag == d:
                    buf += ch
                else:
                    segs.append((flag, buf))
                    flag, buf = d, ch
            if buf:
                segs.append((flag, buf))
            parent = mr.getparent()
            if parent is None or len(segs) < 2:
                continue
            idx = parent.index(mr)
            made = []
            for is_delim, text in segs:
                el = copy.deepcopy(mr)
                el.find(_MNS + 't').text = text
                if is_delim:
                    rpr = el.find(_MNS + 'rPr')
                    if rpr is None:
                        rpr = OxmlElement('m:rPr')
                        el.insert(0, rpr)
                    for old in rpr.findall(_MNS + 'sty'):
                        rpr.remove(old)
                    sty = OxmlElement('m:sty')
                    sty.set(_MNS + 'val', 'p')
                    rpr.insert(0, sty)
                made.append(el)
            parent[idx:idx + 1] = made
            changed += 1
        return changed

    def _math_italics(self):
        """Letters are variables and stay italic; digits, operators, function
        names and acronyms become ordinary (upright) math text."""
        changed = 0
        for mr in self.doc.element.body.iter(_MNS + 'r'):
            t = mr.find(_MNS + 't')
            if t is None or not (t.text or '').strip():
                continue
            s = t.text.strip()
            rpr = mr.find(_MNS + 'rPr')
            if _is_upright(s):
                if rpr is None:
                    rpr = OxmlElement('m:rPr')
                    mr.insert(0, rpr)
                sty = rpr.find(_MNS + 'sty')
                if sty is None:
                    sty = OxmlElement('m:sty')
                    rpr.insert(0, sty)
                if sty.get(_MNS + 'val') != 'p':
                    sty.set(_MNS + 'val', 'p')
                    changed += 1
            elif rpr is not None:
                sty = rpr.find(_MNS + 'sty')
                if sty is not None and sty.get(_MNS + 'val') == 'p':
                    rpr.remove(sty)
                    changed += 1
        return changed

    def _split_math_vars(self):
        """Keep variables italic when they share a run with a symbol.

        The converter emits some expressions as one run per visual group, so
        a variable can end up inside a run also containing a relation symbol
        or a digit, and the whole run is then either italic or upright. This
        pass regroups such runs into letter and non-letter pieces: letter
        pieces stay italic (unless they are operator names, units or
        acronyms), everything else is set upright.
        """
        units = {'pt', 'px', 'em', 'ex', 'in', 'cm', 'mm', 'bp', 'dd'}
        pieces = re.compile(r'[A-Za-z]+|[^A-Za-z]+')
        changed = 0
        for mr in list(self.doc.element.body.iter(_MNS + 'r')):
            t = mr.find(_MNS + 't')
            if t is None or not t.text:
                continue
            segs = pieces.findall(t.text)
            if len(segs) < 2:
                continue
            # the whole run already has one style; nothing to disentangle
            styles = []
            for s in segs:
                if s in units or _is_upright(s):
                    styles.append('p')
                else:
                    styles.append(None)
            if len(set(styles)) == 1:
                continue
            parent = mr.getparent()
            idx = list(parent).index(mr)
            made = []
            for text, sty in zip(segs, styles):
                el = copy.deepcopy(mr)
                el.find(_MNS + 't').text = text
                rpr = el.find(_MNS + 'rPr')
                for old in (rpr.findall(_MNS + 'sty') if rpr is not None
                            else []):
                    rpr.remove(old)
                if sty == 'p':
                    if rpr is None:
                        rpr = OxmlElement('m:rPr')
                        el.insert(0, rpr)
                    new = OxmlElement('m:sty')
                    new.set(_MNS + 'val', 'p')
                    rpr.insert(0, new)
                made.append(el)
            parent[idx:idx + 1] = made
            changed += 1
        return changed

    def _strip_placeholder_glyphs(self):
        """Composition rings and similar placeholders never survive.

        Some conversions leave a ring where the source had a binary operator
        that takes no glyph (function composition being the usual case).  A
        space is what belongs there, so any such run of ring characters is
        collapsed into a single space.
        """
        rings = ''.join(['∘', '◯', '○', '◦', '⨀'])
        changed = 0
        for tag in (qn('w:t'), qn('m:t')):
            for t in self.doc.element.body.iter(tag):
                if t.text and any(ch in rings for ch in t.text):
                    new = re.sub('[%s]+' % re.escape(rings), ' ', t.text)
                    new = re.sub(r'\s{2,}', ' ', new)
                    if new != t.text:
                        t.text = new
                        changed += 1
        return changed

    def save(self, path):
        _normalize_math_fonts(self.doc, MATH_FONT)
        self._force_body_font()
        self._strip_placeholder_glyphs()
        self._split_math_delims()
        self._math_italics()
        self._split_math_vars()
        self._merge_citations()
        self.doc.save(str(path))
        return path

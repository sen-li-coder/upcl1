# -*- coding: utf-8 -*-
"""Complex multi-layer figures for 30 algorithms-as-individuals:
   1) algo_terrain   : 2D density contour + per-algo scatter + marginal KDE lines
   2) algo_heatmap   : algo x function-category gain heatmap + overall bars + category line
Run: python src/plot_algo_complex.py
"""
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import TwoSlopeNorm
from matplotlib import patheffects as pe
from scipy.stats import gaussian_kde

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

LEVEL_COLORS = {0: '#d62728', 1: '#ff7f0e', 2: '#2ca02c', 3: '#1f77b4'}
LEVEL_LABELS = {0: 'L0 fixed', 1: 'L1 adaptive', 2: 'L2 archive', 3: 'L3 LPSR'}
CATS = ['unimodal', 'multimodal', 'hybrid', 'composite']


def _read(name):
    p = TABLES / name
    if not p.exists():
        raise SystemExit(f'missing: {p}')
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6, 'ytick.labelsize': 6,
        'legend.fontsize': 6, 'legend.frameon': False, 'figure.dpi': 300})


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[complex] {name}')


def _outline():
    return [pe.withStroke(linewidth=2.2, foreground='white')]


def _level_legend(handles_marker='o'):
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=5,
                       color=LEVEL_COLORS[lv], label=LEVEL_LABELS[lv]) for lv in [0, 1, 2, 3]]


def _host_cell_group(cells):
    """host -> (list of bare_err, list of dec)."""
    bare = defaultdict(list)
    dec = defaultdict(list)
    for c in cells:
        h = c['host']
        bare[h].append(_f(c['bare_median_log10err']))
        dec[h].append(_f(c['dec_median']))
    return bare, dec


def algo_terrain(hosts, cells):
    bare_g, dec_g = _host_cell_group(cells)
    cxs = np.array([_f(c['bare_median_log10err']) for c in cells])
    cys = np.array([_f(c['dec_median']) for c in cells])
    m = np.isfinite(cxs) & np.isfinite(cys)
    cxs, cys = cxs[m], cys[m]
    xlo, xhi = np.percentile(cxs, [0.5, 99.5])
    ylo, yhi = np.percentile(cys, [0.5, 99.5])
    keep = (cxs >= xlo) & (cxs <= xhi) & (cys >= ylo) & (cys <= yhi)
    cxs, cys = cxs[keep], cys[keep]

    # 2D density field
    xy = np.vstack([cxs, cys])
    kde = gaussian_kde(xy)
    X = np.linspace(xlo, xhi, 140)
    Y = np.linspace(ylo, yhi, 140)
    XX, YY = np.meshgrid(X, Y)
    ZZ = kde(np.vstack([XX.ravel(), YY.ravel()])).reshape(XX.shape)

    # per-algo scatter
    hx, hy, hc, hn = [], [], [], []
    for r in hosts:
        b = np.array([v for v in bare_g[r['host']] if np.isfinite(v)])
        hx.append(np.median(b))
        hy.append(_f(r['dec_mean']))
        hc.append(LEVEL_COLORS[int(r['level'])])
        hn.append(r['host'])

    fig = plt.figure(figsize=(7.6, 6.6))
    gs = gridspec.GridSpec(2, 2, width_ratios=[4.2, 1], height_ratios=[1, 4.2],
                           hspace=0.06, wspace=0.06)
    ax = fig.add_subplot(gs[1, 0])
    ax_top = fig.add_subplot(gs[0, 0], sharex=ax)
    ax_right = fig.add_subplot(gs[1, 1], sharey=ax)

    # main: contour terrain
    cf = ax.contourf(XX, YY, ZZ, levels=16, cmap='viridis', alpha=0.5, zorder=1)
    ax.contour(XX, YY, ZZ, levels=9, colors='#2a2a2a', linewidths=0.35, alpha=0.55, zorder=2)
    ax.axhline(0, color='#d62728', linewidth=0.8, linestyle='--', zorder=2)
    ax.scatter(hx, hy, s=42, c=hc, edgecolors='white', linewidths=0.7, zorder=5)
    for xi, yi, nm in zip(hx, hy, hn):
        ax.annotate(nm, (xi, yi), xytext=(xi + 0.12, yi + 0.012),
                    fontsize=4.3, color='#111111', path_effects=_outline(), zorder=6)

    ax.set_xlim(xlo, xhi); ax.set_ylim(ylo, yhi)
    ax.set_xlabel('host capacity  (log10 median error, lower = stronger)')
    ax.set_ylabel('intervention gain  (dec, + better)')
    ax.grid(color='#dddddd', linewidth=0.4, alpha=0.5, zorder=0)
    ax.set_axisbelow(True)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)

    # top marginal: dec KDE
    dk = gaussian_kde(cys)
    t = np.linspace(ylo, yhi, 240)
    ax_top.plot(t, dk(t), color='#1f77b4', linewidth=1.3)
    ax_top.fill_between(t, dk(t), alpha=0.14, color='#1f77b4')
    ax_top.axvline(0, color='#d62728', linewidth=0.7, linestyle='--')
    ax_top.set_ylabel('density', fontsize=5.5)
    ax_top.tick_params(labelbottom=False, labelsize=5)
    for sp in ('top', 'right'):
        ax_top.spines[sp].set_visible(False)
    ax_top.set_title('gain distribution', fontsize=6.5, loc='left')

    # right marginal: bare KDE
    bk = gaussian_kde(cxs)
    s = np.linspace(xlo, xhi, 240)
    ax_right.plot(bk(s), s, color='#d62728', linewidth=1.3)
    ax_right.fill_betweenx(s, bk(s), alpha=0.14, color='#d62728')
    ax_right.set_xlabel('density', fontsize=5.5)
    ax_right.tick_params(labelleft=False, labelsize=5)
    for sp in ('top', 'right'):
        ax_right.spines[sp].set_visible(False)
    ax_right.set_title('capacity dist.', fontsize=6.5, loc='right')

    fig.suptitle('30 optimization algorithms: capacity-gain terrain', fontsize=9, x=0.42)
    ax.legend(handles=_level_legend(), loc='lower right', ncol=4, fontsize=5.5)
    _save(fig, 'algo_terrain.png')


def algo_heatmap(hosts, cells):
    hs = sorted(hosts, key=lambda r: _f(r['dec_mean']))
    names = [r['host'] for r in hs]
    bare_g, dec_g = _host_cell_group(cells)
    val = defaultdict(list)
    for c in cells:
        val[(c['host'], c['category'])].append(_f(c['dec_median']))
    M = np.full((len(hs), len(CATS)), np.nan)
    for i, r in enumerate(hs):
        for j, cat in enumerate(CATS):
            v = [x for x in val.get((r['host'], cat), []) if np.isfinite(x)]
            if v:
                M[i, j] = np.median(v)
    overall = np.array([_f(r['dec_mean']) for r in hs])
    cat_mean = np.nanmean(M, axis=0)
    cat_sd = np.nanstd(M, axis=0)

    vmax = float(np.nanmax(np.abs(M)))
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax)

    fig = plt.figure(figsize=(7.4, 7.0))
    gs = gridspec.GridSpec(2, 2, width_ratios=[4.2, 1], height_ratios=[3.6, 1],
                           hspace=0.16, wspace=0.06)
    ax = fig.add_subplot(gs[0, 0])
    ax_bar = fig.add_subplot(gs[0, 1], sharey=ax)
    ax_cat = fig.add_subplot(gs[1, 0])

    im = ax.imshow(M, cmap='RdBu_r', norm=norm, aspect='auto', interpolation='nearest')
    ax.set_xticks(range(len(CATS))); ax.set_xticklabels(CATS, fontsize=6.5)
    ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=4.8)
    ax.set_ylabel('30 algorithms (ranked by gain)')
    ax.set_title('gain per function category', fontsize=7.5, loc='left')
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f'{M[i, j]:+.2f}', ha='center', va='center',
                    fontsize=3.6, color='#222222')
    ax.grid(False)

    # right: overall gain bars
    yy = np.arange(len(names))
    colors = ['#2ca02c' if v >= 0 else '#d62728' for v in overall]
    ax_bar.barh(yy, overall, height=0.72, color=colors, alpha=0.85)
    ax_bar.axvline(0, color='#333333', linewidth=0.8)
    ax_bar.set_xlabel('overall\ngain', fontsize=5.5)
    ax_bar.tick_params(labelleft=False, labelsize=5)
    for sp in ('top', 'right'):
        ax_bar.spines[sp].set_visible(False)
    ax_bar.set_title('overall', fontsize=6.5, loc='left')

    # bottom: category mean line with error
    xx = np.arange(len(CATS))
    ax_cat.plot(xx, cat_mean, color='#1f77b4', marker='o', markersize=4, linewidth=1.2, zorder=3)
    ax_cat.fill_between(xx, cat_mean - cat_sd, cat_mean + cat_sd, color='#1f77b4', alpha=0.15)
    ax_cat.axhline(0, color='#333333', linewidth=0.8)
    ax_cat.set_xticks(xx); ax_cat.set_xticklabels(CATS, fontsize=6.5)
    ax_cat.set_ylabel('mean gain', fontsize=6.5)
    ax_cat.set_title('category average (shade = sd)', fontsize=7.5, loc='left')
    for sp in ('top', 'right'):
        ax_cat.spines[sp].set_visible(False)
    ax_cat.grid(color='#dddddd', linewidth=0.4, alpha=0.5); ax_cat.set_axisbelow(True)

    cbar = fig.colorbar(im, ax=[ax, ax_bar, ax_cat], fraction=0.03, pad=0.02)
    cbar.ax.tick_params(labelsize=5)
    cbar.set_label('gain (dec)', fontsize=6)
    _save(fig, 'algo_heatmap.png')


if __name__ == '__main__':
    _style()
    hosts = _read('mech30_host_summary.csv')
    cells = _read('mech30_cells.csv')
    algo_terrain(hosts, cells)
    algo_heatmap(hosts, cells)
    print('[complex] done ->', FIG)

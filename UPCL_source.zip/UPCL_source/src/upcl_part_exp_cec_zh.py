# -*- coding: utf-8 -*-
"""手稿第三部分（CEC 版，中文）：UPCL 在 CEC 单目标套件上的经验研究。

这里打印的每个数字都从 ``analyze_upcl_cec.py`` 写入 ``results/cec/tables`` 的
表格读取，因此本节可随网格增长而重新生成；没有任何东西被硬编码。
"""

import statistics

import paper_figures as PFG


# ---------------------------------------------------------------------------
def _f(v, n=3, sign=False):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    if x != x:  # NaN -> 留空
        return '-'
    if not sign:
        return f'{x:.{n}f}'
    s = f'{x:+.{n}f}'
    # 会被四舍五入为零的值不得打印成带符号的零（'-0.00'）。
    return f'{0.0:.{n}f}' if float(s) == 0.0 else s


def _nb_zh():
    """零参照带（由 analyze_null_band.py 写入 null_band_summary.csv 读取）。"""
    import csv
    from pathlib import Path
    path = (Path(__file__).resolve().parents[1] / 'results' / 'cec' / 'tables'
            / 'null_band_summary.csv')
    out = {}
    try:
        with open(path, encoding='utf-8') as fh:
            for r in csv.DictReader(fh):
                key = '%s/%d' % (r['suite'], int(float(r['dim'])))
                out[key] = {k: float(v) for k, v in r.items() if k != 'suite'}
    except (FileNotFoundError, KeyError, ValueError):
        return {}
    return out


def _mean(rows, key):
    vals = [float(r[key]) for r in rows if r.get(key) not in (None, '', 'nan')]
    return sum(vals) / len(vals) if vals else float('nan')


def _blk_read(sub):
    """一个配对区块的极值与计数，供第 4.2 节引用。

    ``sub`` 是单个（套件，维度）区块的宿主行，因此下面的每个数字都读自该
    区块贡献的那张表。
    """
    def fv(r, k):
        return float(r[k])
    rho = sorted(sub, key=lambda r: fv(r, 'rho'))
    dec = sorted(sub, key=lambda r: fv(r, 'dec_mean'))
    byrank = sorted(sub, key=lambda r: int(r.get('rank', 999)))
    top5 = [fv(r, 'dec_mean') for r in byrank[:5]]
    return {
        'n': len(sub),
        'rho_lo': (rho[0]['host'], fv(rho[0], 'rho')),
        'rho_hi': (rho[-1]['host'], fv(rho[-1], 'rho')),
        'rho_med': statistics.median([fv(r, 'rho') for r in sub]),
        'rho_top3': [r['host'] for r in rho[-3:]],
        'dec_lo': (dec[0]['host'], fv(dec[0], 'dec_mean')),
        'dec_hi': (dec[-1]['host'], fv(dec[-1], 'dec_mean')),
        'dec_med': statistics.median([fv(r, 'dec_mean') for r in sub]),
        'dec_mean': sum(fv(r, 'dec_mean') for r in sub) / len(sub),
        'n_pos': sum(1 for r in sub if fv(r, 'dec_mean') > 0),
        'n_small': sum(1 for r in sub if abs(fv(r, 'dec_mean')) <= _CELL_TOL),
        'n_mismatch': sum(1 for r in sub
                          if fv(r, 'dec_mean') * fv(r, 'ri_mean') < 0),
        'dec': {r['host']: fv(r, 'dec_mean') for r in sub},
        'rank': {r['host']: int(r.get('rank', 0)) for r in sub},
        'rho': {r['host']: fv(r, 'rho') for r in sub},
        # 该区块 Holm 校正后的格级胜负：胜＝层显著更好的函数，负＝反之。
        'wins': {r['host']: int(float(r.get('wins') or 0)) for r in sub},
        'losses': {r['host']: int(float(r.get('losses') or 0)) for r in sub},
        'n_cells': {r['host']: int(float(r.get('cells') or 0)) for r in sub},
        'cells': int(sum(int(float(r.get('cells') or 0)) for r in sub)),
        'top5_abs': max((abs(v) for v in top5), default=0.0),
        'dec_top5_ranks': [int(r.get('rank', 0)) for r in
                           sorted(sub, key=lambda r: -fv(r, 'dec_mean'))[:5]],
    }


def _next_table(P):
    """下一个表将携带的编号，用于前向交叉引用。"""
    return P.tab_no + 1


def build(P, S):
    _protocol(P, S)
    _paired(P, S)
    _grid(P, S)
    _mechanism(P, S)


# ===========================================================================
# 4.1  协议
# ===========================================================================
def _protocol(P, S):
    pr = S['protocol']
    P.h1('4  实验研究')

    P.h2('4.1  协议')
    P.para(
        r'每次观测对应一个基准函数、一个维度、一个变体搜索算法的组合，'
        r'每个这样的组合以两种配置运行，恰好在一个方面'
        r'不同，即变体 $H$ 单独运行与附加了 UPCL 的同一变体，且每种配置以'
        r'相同数量的独立运行重复。因此一次运行有一个种子，该种子由两种配置'
        r'共享：它们从同一种群出发、获得相同的预算 $B=10^{4}D$ 次评估，且仅在'
        r'一个方面不同，即离开变异与交叉阶段的候选向量 $u_i$ 是被直接送入评估、'
        r'还是先经过该层。其他一切，包括种群规模、初始采样、评估顺序、终止条件，'
        r'都不允许变化。')
    P.para(
        r'问题是有界约束的单目标套件 CEC 2017 [@CEC17] 与 CEC '
        r'2022 [@CEC22]，它们把函数分成四个声明的类别：单峰、多峰、混合与'
        r'复合。变体是表 ' + str(_next_table(P) + 1) + r' 中的二十九个算法：'
        r'DE/rand/1、DE/best/1、'
        r'DE/rand/2、DE/current-to-best/1、DE/current-to-rand/1、'
        r'DE/rand/1/either-or、jDE、SaDE、SaNSDE、CoDE、EPSDE、CoBiDE、JADE、'
        r'SHADE、MPEDE、L-SHADE、L-SHADE-RSP、jSO、NL-SHADE-RSP、MadDE、'
        r'jDE100、j2020、DISH、DISK、LSHADE-cnEpSin、SinDE、IMODE、PaDE 与 '
        r'SHADE-ILS。表 ' + str(_next_table(P) + 1) + r' 按这二十九个算法所运用的'
        r'自适应程度分组，'
        r'因而层的效果可作为变体已提供何种机制的函数来读出。这二十九个中'
        r'有二十六个属于表 1 与表 2 的七十九个命名变体，其余三个是第 1 节的'
        r'经典供体，而表 3 的四个组成层次各有'
        r'至少一个代表。')
    P.para('性能通过两个效应量来读取，主效应量是移除的误差数量级：')
    P.equation(
        r'\mathrm{dec}=\log_{10}\tilde{e}_{H}-\log_{10}\tilde{e}_{\mathrm{UPCL}},')
    P.para(
        r'其中 $\tilde{e}$ 是某一配置各次运行最终误差的中位数，$e=f(x)-'
        r'f^{\star}$ 在取对数前以 $10^{-8}$ 封底；一个单位即一个数量级。其'
        r'有界对应量是相对改进')
    P.equation(
        r'\mathrm{ri}=\frac{\bar{e}_{H}-\bar{e}_{\mathrm{UPCL}}}'
        r'{\max(\bar{e}_{H},\bar{e}_{\mathrm{UPCL}},10^{-8})},')
    P.para(
        r'它取值于 $[-1,1]$，每当附加 UPCL 降低均值误差时为正；当变体已到达'
        r'机器精度时它仍保持有意义，而通常的 $(e_{H}-e_{\mathrm{UPCL}})/'
        r'|e_{H}|$ 会发散。每个这样的组合还以双侧配对 Wilcoxon 符号秩检验进行'
        r'比较，遵循 [@DERRAC11][@GARCIA10] 给出的非参数比较方法：协议对每项'
        f'比较固定不变，汇总于表 {_next_table(P)}。')
    P.para(
        r'有两点协议细节在此写明，而不是留给表格。第一，CEC 2017 只在三十个'
        r'函数中的二十九个上评估：最初发表的 $F_2$ 因数值不稳定被基准作者撤回，'
        r'参考实现中并不包含它，因此本节的所有计数都指二十九个函数，与文献中'
        r'引用全集数字的结果不可直接比较。第二，预算为每次运行 $10^{4}D$ 次'
        r'函数评估，这是两个套件规定的协议，裸臂与被包装臂的预算完全相同，'
        r'因此层自身不消耗任何评估。')
    P.para(
        r'协议遵循基准测试文献的建议，因为这里涉及的量都很小。黑箱基准平台'
        r'以固定评估预算下的任意时刻性能为主要度量 [@HANSEN_COCO21]，因此本文'
        r'所有比较都在 $10^{4}D$ 次评估处进行，而从不依据墙钟预算。由于同时'
        r'检验成百上千个配对，族错误率由作用于配对符号秩检验的 Holm 逐步下降'
        r'程序控制，这正是跨算法、跨函数多重比较所推荐的组合 '
        r'[@HOLLANDER99][@BENAVOLI16]；未校正的 $p$ 值与校正后的判定并列报告，'
        r'而不是取而代之，这与"仅凭阈值并不度量证据"的告诫一致 '
        r'[@WASSERSTEIN16]。效应量与检验同时给出，理由相同：每格三十次运行'
        r'足以让配对检验分辨出远低于任何实际意义的差别，因此功效与幅度必须'
        r'一并陈述 [@COHEN88]。该设计——种子、预算与实现固定、只变动一个因子——'
        r'正是一份试验设计分析对同一问题会规定的做法 [@MONTGOMERY12]；协议被'
        r'完整报告，使各表可由存档运行重新生成，这也是可复现性文献对实证研究'
        r'的要求 [@NOSEK18]。')

    P.table_caption('配对 CEC 实验的协议。每个条目都从结果表生成，因此遵循'
                    '网格。')
    rows = [
        ['基准套件', pr['suites']],
        ['报告维度', pr['dims']],
        ['问题', pr['problems']],
        ['评估预算', pr['budget']],
        ['变体', pr['hosts']],
        ['种群规模', pr['pops']],
        ['每配置运行次数', pr['runs']],
        ['配对', pr['pairing']],
        ['报告比较', pr['cells_line']],
        ['效应量', pr['metrics']],
        ['层配置', pr['config']],
    ]
    P.table(['项目', '设置'], rows, widths=[1.5, 5.0], align='ll',
            font_size=8.5)

    P.para(
        f'表 {_next_table(P)} 按变体所运用的自适应程度对二十九个算法分组，'
        '使自适应谱的每一级'
        '都得到代表，从层的可直接调整其候选的固定参数供体，到内部自适应已经'
        '主导搜索的近年冠军。第 2 节的六个固定参数供体隔离出层自身的贡献：'
        '没有内部自适应可干扰，它们轨迹上的任何改变都可归因于该层。自适应变体'
        '从逐个体参数编码，经算子池与成功历史记忆，到种群规模缩减与多算子集成'
        '而逐渐增强；每一种这样的机制都是“什么在驾驭搜索”这一问题的一个候选'
        '答案，而第 4 节把层的效应读作变体已提供何种机制的函数。')

    P.table_caption('第 4 节所用变体，按其所运用的自适应程度分组。第 0 级保持'
                    '固定参数；第 1 级把参数编码进个体；第 2 级加入策略自适应；'
                    '第 3 级加入种群规模控制或第二个机制。')
    P.table(
        header=['级别', '变体（缩写）', '为何用这一组'],
        rows=[
            ['0', 'DE/rand/1, DE/best/1, DE/rand/2, DE/current-to-best/1, '
             'DE/current-to-rand/1, DE/rand/1/either-or',
             '一个固定参数供体，层可以校正它而无需触及内部自适应'],
            ['1', 'jDE, SaNSDE, jDE100, j2020, SinDE',
             '逐个体参数编码与周期调度，最早的自适应'],
            ['2', 'JADE, SHADE, CoBiDE, SaDE, EPSDE, CoDE, MPEDE, DISH, '
             'DISK, PaDE',
             '算子池、集成与成功历史记忆，主导的中代设计'],
            ['3', 'L-SHADE, jSO, L-SHADE-RSP, NL-SHADE-RSP, MadDE, '
             'LSHADE-cnEpSin, IMODE, SHADE-ILS',
             'LPSR 家族与近期竞赛冠军：层必须对它们保持中立'],
        ],
        widths=[0.5, 3.2, 2.6], font_size=7.0, align='c l l')

    P.para(
        r'附加该层只改变一件事：离开变异与交叉的候选 $u_i$ 要么被直接评估、'
        r'要么先经过该层。决定不干预的层原样返回 $u_i$，因此两种配置恰好花费'
        r'相同的评估次数，且不干预的层与根本没有层不可区分；比较因而单独隔离'
        r'出新增的机制。')

    P.para('四个指标把配对结果转化为对 DE 家族的一次刻画，每个都把变体的一个性质化成一个数。')
    P.bullet(
        r'\textbf{变体单独排名。} 变体在各函数上自身最终误差中位数的排名'
        r'（中位数在对数空间取）；'
        r'它衡量在附加该层之前变体已取得的水平。',
        style='Numbered')
    P.bullet(
        r'\textbf{干预率} $\bar\rho=\tfrac{1}{T}\sum_{t=1}^{T}\rho_t$：'
        r'层修改候选的比例，按代平均，即层不得不修正的、变体自身候选生成过程的份额。',
        style='Numbered')
    P.bullet(
        r'\textbf{干预增益} 第 4.1 节定义的 $\mathrm{dec}$ 与 $\mathrm{ri}$：'
        r'这些修正生效后移除的误差。',
        style='Numbered')
    P.bullet(
        r'\textbf{描述子对比} $\Delta\phi_k=(\bar\phi_k^{+}-\bar\phi_k^{-})/\sigma_k$：'
        r'候选特征 $k$ 在接受与拒绝的干预之间的标准化偏移；它定位候选在哪些'
        r'几何条件下可被改进。',
        style='Numbered')
    P.para('把这四个指标按机制族放在一起解读，就回答了第 2 节留下的问题：改进 DE 的哪条路才真正有回报。')


# ===========================================================================
# 4.2  配对结果
# ===========================================================================
def _paired(P, S):
    cells = S['cells']
    hsum = S['hosts']
    pr = S.get('probe', {})
    bare_top1 = pr.get('bare_top1', 'NL-SHADE-RSP')
    P.h2('4.2  干预率与增益')

    _paired_blocks = (('cec2017', '30'), ('cec2022', '10'),
                      ('cec2022', '20'), ('cec2017', '50'))
    _blk = {}
    for _bs, _bd in _paired_blocks:
        _sub0 = [r for r in hsum
                 if (r.get('suite'), str(r.get('dim'))) == (_bs, _bd)]
        if _sub0:
            _blk[(_bs, _bd)] = _blk_read(_sub0)
    A = _blk[('cec2017', '30')]
    B = _blk[('cec2022', '10')]
    C = _blk[('cec2022', '20')]
    # D=50 于 2026-10-22 补成完整区块（二十九个变体 × 三十次运行）；缺块时仍
    # 跳过相应文字，而不是用陈旧数字填空。
    D = _blk.get(('cec2017', '50'))
    _dt = S.get('dim_transfer') or {}

    def _dv(metric, default=float('nan')):
        try:
            return float(_dt[metric]['value'])
        except (KeyError, TypeError, ValueError):
            return default

    def _dp(metric, default=float('nan')):
        try:
            return float(_dt[metric]['p'])
        except (KeyError, TypeError, ValueError):
            return default

    t_a = _next_table(P)

    P.para(
        f'表 {t_a} 至表 {t_a + 3} 完整给出配对结果，每个区块一张，每配置三十次'
        r'运行：CEC 2017 在 $D=30$ 上的二十九个已注册变体、同一家族在 CEC 2022 '
        r'的 $D=10$ 与 $D=20$ 上，以及 CEC 2017 $D=50$ 上同样的二十九个变体。'
        r'每张表的左半是变体自身——它在区块内的单独排名与中位最终'
        r'误差，右半是同一批种子下附加层后的读数，由第 4.1 节的三个配对指标给出。'
        r'四张表因而逐变体回答两个问题：层介入得多频繁，以及这些介入值多少。')
    for _bi, (_bs, _bd) in enumerate(_paired_blocks):
        _sub = [r for r in hsum
                if (r.get('suite'), str(r.get('dim'))) == (_bs, _bd)]
        if not _sub:
            continue
        _tag = ('a', 'b', 'c', 'd')[_bi]
        P.table_caption(
            f'实验 1{_tag}：{_bs} 在 $D={int(_bd)}$ 上的变体单独排名与精度。'
            '对每个变体：该区块内的变体单独排名及其中位最终误差（科学计数法，'
            '越低越好）、移除的均值数量级、有界相对改进、以及平均策略干预率 '
            '$\\rho$。')
        _rows = [[r['host'], str(r.get('rank', '-')),
                  _sci(r.get('accuracy')),
                  _f(r['dec_mean'], 3, True), _f(r['ri_mean'], 3, True),
                  _f(r['rho'], 3)] for r in _sub]
        P.table(['变体', '排名', '精度', 'dec', 'ri', '$\\rho$'],
                _rows, widths=[2.6, 0.6, 0.9, 0.75, 0.7, 0.7],
                align='lcrrrr')

        if _bi == 0:
            # 每张表的读法紧跟该表给出，使四张表不会连成一段没有文字的空档。
            P.para(
                f'表 {t_a} 显示，干预率在家族内相差 '
                f'{A["rho_hi"][1] / max(A["rho_lo"][1], 1e-9):.0f} 倍：'
                f'{A["rho_lo"][0]} 为 {A["rho_lo"][1]:.3f}，{A["rho_hi"][0]} 为 '
                f'{A["rho_hi"][1]:.3f}，中位变体为 {A["rho_med"]:.3f}。最高的三项'
                f'依次为 {A["rho_top3"][2]}、{A["rho_top3"][1]} 与 '
                f'{A["rho_top3"][0]}，即基向量'
                r'完全随机抽取的三个变体；而贪心的 DE/best/1、DE/current-to-best/1 与成功'
                r'历史类变体位居该列末尾。这个排序正是最小干预规则所预言的，层中没有任何'
                r'其他部分被安排去产生它：近乎随机的候选容易被响应模型击败，已经瞄准当前'
                r'最优的候选则不然。因此这一列测的是宿主而非对它调参，第 4.4 节的机制指纹'
                r'正是以它为轴构建。')
            # 排名只在“精度”列所打印的精度内有意义。若有若干变体在该列
            # 每一位数字上都相同，它们之间的名次只是形式，写明这一点比让
            # 读者从中读出数据并不携带的差异要好。
            _rk_of = {r['host']: int(r['rank']) for r in _sub
                      if str(r.get('rank', '')).isdigit()}
            for _grp in (S.get('block_ties') or {}).get((_bs, int(_bd)), []):
                _nm = [h[2] for h in _grp if h[2] in _rk_of]
                if len(_nm) < 3:
                    continue
                _nm.sort(key=lambda h: _rk_of[h])
                _rks = [_rk_of[h] for h in _nm]
                P.para(
                    '关于排名列需要一点说明。'
                    + '、'.join(_nm[:-1]) + ' 与 ' + _nm[-1]
                    + '的中位最终误差在表中打印的每一位上都相同，原始误差只差百万分'
                    f'之几；把它们分开的名次 {_rks[0]} 至 {_rks[-1]} 因而依赖于本表'
                    '并未显示的位数，这四者应读作该列末尾的一个并列位置，而非一个'
                    '先后次序。')
        elif _bi < 3:
            K = B if _bi == 1 else C
            P.para(
                f'表 {t_a + _bi} 在 CEC 2022 的 $D={_bd}$ 上给出同一比较，并在另一个'
                f'套件上复现相同排序：干预率跨度为 '
                f'{K["rho_hi"][1] / max(K["rho_lo"][1], 1e-9):.0f} 倍，'
                f'从 {K["rho_lo"][0]} 的 {K["rho_lo"][1]:.3f} 到 '
                f'{K["rho_hi"][0]} 的 {K["rho_hi"][1]:.3f}，中位变体为 '
                f'{K["rho_med"]:.3f}，该列顶端仍是同样三个随机抽取基向量的变体。'
                f'该表的增益列同样有界：最大改善为 {K["dec_hi"][1]:+.3f} 个数量级'
                f'（{K["dec_hi"][0]}，排名 {K["rank"][K["dec_hi"][0]]}），最大损失为 '
                f'{K["dec_lo"][1]:+.3f}（{K["dec_lo"][0]}，排名 '
                f'{K["rank"][K["dec_lo"][0]]}），而 $|\\mathrm{{dec}}|\\le '
                f'{_CELL_TOL:.2f}$ 的变体在其 {K["n"]} 个变体中占 '
                f'{K["n_small"]} 个。')
        elif D is not None:
            P.para(
                f'表 {t_a + 3} 把同一比较搬到 CEC 2017 的 $D=50$ 上，同样的'
                r'二十九个变体，坐标翻倍。干预率的排序与三十维区块一致：该列跨度为 '
                f'{D["rho_hi"][1] / max(D["rho_lo"][1], 1e-9):.0f} 倍，从 '
                f'{D["rho_lo"][0]} 的 {D["rho_lo"][1]:.3f} 到 '
                f'{D["rho_hi"][0]} 的 {D["rho_hi"][1]:.3f}，中位变体为 '
                f'{D["rho_med"]:.3f}；在三十维上领跑的两个随机抽取基向量的变体'
                r'在此仍是该列最高的两项，而在三十维上已靠近列底的、以当前最优'
                r'为锚的贪心变体则是二十九个中的最低项。'
                f'增益列同样有界：最大改善为 {D["dec_hi"][1]:+.3f} 个数量级'
                f'（{D["dec_hi"][0]}，排名 {D["rank"][D["dec_hi"][0]]}），最大损失为 '
                f'{D["dec_lo"][1]:+.3f}（{D["dec_lo"][0]}，排名 '
                f'{D["rank"][D["dec_lo"][0]]}），$|\\mathrm{{dec}}|$ 落在容差内的'
                f'变体二十九个中占 {D["n_small"]} 个；但其符号并不简单继承低维——'
                f'二十九个中有 {D["n_pos"]} 个为正，且有 {D["n_mismatch"]} 行的 '
                r'$\mathrm{dec}$ 与 $\mathrm{ri}$ 异号。多出来的坐标是把效应在家族'
                r'内部重新分配，而不是把它整体放大或缩小。')

    P.para(
        f'把表 {t_a + 1} 与表 {t_a + 2} 的左右两半交叉起来读，结论更锋利：两个区块中'
        f'干预率最高的三项，恰好就是 $\\mathrm{{dec}}$ 最负的三项——'
        f'DE/rand/1/either-or 在 $D=10$ 与 $D=20$ 上分别损失 '
        f'{abs(B["dec"]["DE/rand/1/either-or"]):.3f} 与 '
        f'{abs(C["dec"]["DE/rand/1/either-or"]):.3f} 个数量级，DE/rand/1 损失 '
        f'{abs(B["dec"]["DE/rand/1"]):.3f} 与 '
        f'{abs(C["dec"]["DE/rand/1"]):.3f}，DE/rand/2 损失 '
        f'{abs(B["dec"]["DE/rand/2"]):.3f} 与 '
        f'{abs(C["dec"]["DE/rand/2"]):.3f}。也就是说，层把干预花在宿主候选生成最弱'
        r'的地方，而那也正是它造成最大损害的地方。')
    if D is not None:
        P.para(
            r'在五十维上这种对应只部分成立，而这个例外本身有信息量。'
            f'DE/rand/1 与 DE/rand/2 在该区块的干预率几乎相同'
            f'（{D["rho"]["DE/rand/1"]:.3f} 与 '
            f'{D["rho"]["DE/rand/2"]:.3f}），但前者损失 '
            f'{abs(D["dec"]["DE/rand/1"]):.3f} 个数量级，后者却增益 '
            f'{D["dec"]["DE/rand/2"]:+.3f}，并在其 '
            f'{D["n_cells"]["DE/rand/2"]} 个函数中有 {D["wins"]["DE/rand/2"]} 个'
            f'显著更好；DE/rand/1/either-or 的干预率为 '
            f'{D["rho"]["DE/rand/1/either-or"]:.3f}，损失 '
            f'{abs(D["dec"]["DE/rand/1/either-or"]):.3f}。可见高干预率是宿主的'
            r'属性，而其代价取决于宿主在该维度上是否还有余量：抽取两个差分向量的'
            r'随机基变体在 $D=50$ 上的余量比 $D=30$ 更多，只抽一个的则更少。')

    # "各表中" 的极值必须跨四个区块取：D=50 区块补齐后其尾部比其他区块更宽，
    # 两端都由它决定。
    _tbl_blks = [A, B, C] + ([D] if D is not None else [])
    _tbl_hi = max(_tbl_blks, key=lambda b: b['dec_hi'][1])
    _tbl_lo = min(_tbl_blks, key=lambda b: b['dec_lo'][1])
    P.para(
        '在这些表被读之前，先要记住层多么少地行动：本文配置下恒等动作占全部'
        '候选的约 $95\\%$，因此下面报告的区块级增益是一个接近恒等映射的层'
        '的增益，而近似为零的取值在本实验里有两种读法——宿主中不存在余量，'
        '或者层在有余量处选择了不行动。4.4 节对两者都保持开放，用于区分它们的'
        '干预列在数据发布所附的后续工作清单中，而不在这里被假设掉。')

    _nbz = _nb_zh()
    _n30 = _nbz.get('cec2017/30')
    if _n30:
        _f50 = _nbz.get('cec2017/50', _n30)
        _f10 = _nbz.get('cec2022/10', _n30)
        _f20 = _nbz.get('cec2022/20', _n30)
        _lo = min(100 * r['frac_in_band'] for r in (_n30, _f50, _f10, _f20))
        _hi = max(100 * r['frac_in_band'] for r in (_n30, _f50, _f10, _f20))
        P.para(
            '配对检验不显著并不等于等价，因此上表的区块级检验改与一条由同一批'
            '运行构造的零参照带对读。对每个格子，仅从其裸臂中有放回地抽取两个'
            r'独立的三十次运行中位数，所得即是“两臂同分布”假设下 $\mathrm{dec}$ '
            f'的分布；{int(_n30["n_cells_used"])} 个 '
            f'{int(_n30["n_cells_used"] + _n30["n_cells_skipped"])} 个 '
            f'CEC 2017 $D=30$ 格子中裸臂尚未塌缩到机器精度者进入分析。该带的'
            f'标准差为 {_f(_n30["band_sd"], 2)} 个数量级，95% 区间为 '
            f'[{_f(_n30["band_p025"], 2, True)}, '
            f'{_f(_n30["band_p975"], 2, True)}]，四个区块中 {_lo:.0f}% 到 '
            f'{_hi:.0f}% 的格子实测值落在带内，各区块的格子中位数都是 '
            f'{_f(_n30["dec_median"], 3, True)} 个数量级。'
            r'等价是更强的断言，数据只部分支持：在 $\pm 0.05$ 个数量级的边界内，'
            f'$D=30$ 有 {100 * _n30["frac_abs_le_margin"]:.0f}% 的格子合格，'
            f'越界者中 {100 * _n30["frac_neg"]:.0f}% 在下侧、'
            f'{100 * _n30["frac_pos"]:.0f}% 在上侧，因此残差分布是幅度不对称'
            f'而非符号不对称：两个方向越界的格子数目相当，而向下越界者最多越出'
            f'一个数量级，这正是区块均值为负的来源。对变体均值在该边界上做'
            f'双侧等价检验，$D=30$ 得 $p = {_n30["tost_host_p"]:.2f}$、'
            f'$D=50$ 得 $p = {_f50["tost_host_p"]:.2f}$、CEC 2022 $D=20$ 得 '
            f'$p = {_f20["tost_host_p"]:.2f}$，而 CEC 2022 $D=10$ 得 '
            f'$p = {_f10["tost_host_p"]:.2g}$。因此等价只在最后一个区块上被'
            f'宣称；其余区块报告为：中位效应为零且落在其自身估计量的噪声之内，'
            f'并在固定参数变体上带一条负尾。四个区块的数值见数据发布的 '
            f'null_band_summary.csv。')
    P.para(
        r'不过从增益列看，受益的变体多于受损的变体：四张表各自的 '
        f'{A["n"]}、{B["n"]}、{C["n"]} 与 '
        f'{D["n"] if D is not None else "-"} 个变体中分别有 {A["n_pos"]}、'
        f'{B["n_pos"]}、{C["n_pos"]} 与 '
        f'{D["n_pos"] if D is not None else "-"} 个 '
        f'$\\mathrm{{dec}}>0$，中位变体只移动 {A["dec_med"]:+.3f}、'
        f'{B["dec_med"]:+.3f}、{C["dec_med"]:+.3f} 与 '
        f'{(D["dec_med"] if D is not None else float("nan")):+.3f} 个数量级。'
        f'均值之所以仍为负（{A["dec_mean"]:+.3f}、{B["dec_mean"]:+.3f}、'
        f'{C["dec_mean"]:+.3f} 与 '
        f'{(D["dec_mean"] if D is not None else float("nan")):+.3f}），'
        f'是两条尾巴不对称：各表中最大增益为 {_tbl_hi["dec_hi"][1]:+.3f} 个数量级'
        f'（{_tbl_hi["dec_hi"][0]}，排名 '
        f'{_tbl_hi["rank"][_tbl_hi["dec_hi"][0]]}），最大损失则为 '
        f'{_tbl_lo["dec_lo"][1]:+.3f}（{_tbl_lo["dec_lo"][0]}，排名 '
        f'{_tbl_lo["rank"][_tbl_lo["dec_lo"][0]]}）；$|\\mathrm{{dec}}|\\le '
        f'{_CELL_TOL:.2f}$ 的变体各有 {A["n_small"]}、{B["n_small"]}、'
        f'{C["n_small"]} 与 {D["n_small"] if D is not None else "-"} 个。另有 '
        f'{A["n_mismatch"]}、{B["n_mismatch"]}、{C["n_mismatch"]} 与 '
        f'{D["n_mismatch"] if D is not None else "-"} 行出现 $\\mathrm{{dec}}$ 与 '
        r'$\mathrm{ri}$ 异号，即层的改动改善了中位却加厚了坏运行的上尾——这正是'
        r'两个指标必须成对报告的原因。')

    # D=50 区块排名前五的变体（按其自身表格的排名列），供排名段引用。
    _lead5 = (sorted(D['dec'], key=lambda h: D['rank'][h])[:5]
              if D is not None else [])
    _lead4 = sorted(abs(D['dec'][h]) for h in _lead5)[3] if _lead5 else 0.0

    P.para(
        f'把这些表与排名列对照，就能定位效应的位置。表 {t_a} 中变体单独排名前五'
        f'的变体在附加层后移动不超过 {A["top5_abs"]:.3f} 个数量级，也就是说层恰恰'
        f'在家族领跑者上近乎惰性；而增益最大的几个变体的排名落在 '
        f'{min(A["dec_top5_ranks"])} 至 {max(A["dec_top5_ranks"])} 位（共 29 位）。'
        f'另两个完整区块从另一端给出同样的故事：它们的最大增益分别落在 '
        f'{B["dec_hi"][0]}（{B["dec_hi"][1]:+.3f} 个数量级，排名 '
        f'{B["rank"][B["dec_hi"][0]]}）与 {C["dec_hi"][0]}'
        f'（{C["dec_hi"][1]:+.3f} 个数量级，排名 {C["rank"][C["dec_hi"][0]]}）；'
        f'$D=50$ 的区块在自己的排名内复现了同一形态：排名前四的变体在附加层后'
        f'移动不超过 {_lead4:.3f} 个数量级，只有第五名 {_lead5[-1]} 移动更多'
        f'（{D["dec"][_lead5[-1]]:+.3f}），而最大增益落在二十九位中的第 '
        f'{D["rank"][D["dec_hi"][0]]} 位。'
        r'因此层并非普遍有用：它推动的是家族早已超越的变体，而领跑者原地不动。')

    # ---- 同一家族在两个维度上的对照 ------------------------------------
    # 仅当表中存在 D=50 区块时生成图与段，使部分网格构建的版本仍然自洽。
    if D is not None and _dv('hosts_in_both_blocks', 0) >= 3:
        _n_both = int(_dv('hosts_in_both_blocks'))
        _fig_dim = P.fig_no + 1
        P.para(
            f'图 {_fig_dim} 把两个 CEC 2017 区块逐变体对照，这也正是本文不把维度'
            r'当作又一个实验因子的理由。(a) 把表 ' f'{t_a} 与表 {t_a + 3} 的逐变体'
            r'平均 dec 放在同一行的两端：增益的排序被保留（'
            f'{_n_both} 个共同变体上的 Spearman $\\rho = '
            f'{_dv("host_dec_spearman"):.2f}$，$p = {_dp("host_dec_spearman"):.1e}$），'
            f'其中 {int(_dv("host_sign_agree"))} 个保持增益符号、'
            f'{int(_dv("host_both_positive"))} 个在两个维度上都为正，说明对多数'
            r'变体而言，在某一维度上被修补，在另一维度上也会被修补。(b) 对干预率做同样的'
            f'对照：其排序几乎原样迁移（Spearman $\\rho = '
            f'{_dv("host_rho_spearman"):.2f}$），而水平几乎没有移动，可见干预率是'
            r'变体的属性而非问题维度的属性。在单次优化的层面，两个区块在统计上'
            f'无法区分：在两块共有的 {int(_dv("cells_in_both_blocks"))} 个配置上，'
            f'平均 dec 在 $D=30$ 为 {_dv("cell_dec_mean30"):+.3f} 个数量级、在 '
            f'$D=50$ 为 {_dv("cell_dec_mean50"):+.3f}（Wilcoxon $p = '
            f'{_dp("cell_dec_wilcoxon_p"):.2f}$），改善配置的占比也相同'
            f'（{_dv("cell_frac_positive30"):.2f} 与 '
            f'{_dv("cell_frac_positive50"):.2f}）。因此维度改变的是效应在家族内部'
            r'的位置，而不是它的大小。')
        P.figure(PFG.fig('dim_effect'),
                 '实验 1，CEC 2017 上配对效应的维度迁移：(a) 逐变体平均 dec 在 '
                 '$D=30$（空心）与 $D=50$（实心）上的对照，每行一个变体、'
                 '按 $D=50$ 的取值排序，增益符号改变的连线上以红色标出；'
                 '(b) 同样行序下的策略干预率对照。两个面板均覆盖全部二十九个'
                 '变体，每个变体在这两个维度上都有完整设计。')

    P.para(
        r'决定性的观察是配对设计本身无法做出的那个：在第 4.3 节'
        f'的完整家族上，变体单独排名由 {bare_top1} 领跑，这是一个用成功历史'
        r'参数与缩减的种群替换固定规则的变体，而经典固定参数变体与策略集成'
        r'变体都落在其后。因此层的效应，恰好在变体最弱处最大，不是对整个'
        r'家族的一般性改进；它是对家族早已超越的那些变体的修补。')

# ===========================================================================
# 4.3  跨变体与问题的家族
# ===========================================================================
# 二十九个已注册变体，按组成级别（与第 4.4 节机制指纹所对照的同一轴）分组。
# 两个最大的级别再各拆一次，以免任何单张表承载超过十二个数列（六个变体
# x 两种配置）。
_GRID_SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10), ('cec2022', 20))
_HOST_GROUPS = (
    ('L0 固定参数',
     ['DE/rand/1', 'DE/best/1', 'DE/rand/2',
      'DE/current-to-best/1', 'DE/current-to-rand/1', 'DE/rand/1/either-or']),
    ('L1 自适应 $F$/$CR$',
     ['jDE', 'jDE100', 'j2020', 'SaNSDE', 'SinDE']),
    ('L2 成功历史',
     ['SHADE', 'JADE', 'DISK', 'DISH', 'CoBiDE']),
    ('L2 归档与策略集成',
     ['SaDE', 'EPSDE', 'CoDE', 'MPEDE', 'PaDE']),
    ('L3 LPSR',
     ['NL-SHADE-RSP', 'MadDE', 'L-SHADE', 'L-SHADE-RSP']),
    ('L3 基于秩与重启',
     ['jSO', 'SHADE-ILS', 'LSHADE-cnEpSin', 'IMODE']),
)

# 小数目在正文中写作汉字（"六张附录表"），与全文体例一致。
_COUNT_WORDS = {1: '一', 2: '两', 3: '三', 4: '四', 5: '五', 6: '六',
                7: '七', 8: '八', 9: '九', 10: '十', 11: '十一', 12: '十二'}


# 秩着色的绿色渐变：秩 1（最小误差）得到最浅的填充，最差秩最深，因此淡绿
# 单元标记好结果、深绿单元标记差结果。
_RANK_LO = (0xF1, 0xF8, 0xF1)
_RANK_HI = (0x1B, 0x5E, 0x20)


def _rank_fill(rank, n):
    """对 ``n`` 个竞争者上 1 基秩（1 = 最优）的绿色填充。"""
    if n <= 1:
        return 'F1F8F1'
    t = (rank - 1) / float(n - 1)
    c = tuple(round(lo + (hi - lo) * t) for lo, hi in zip(_RANK_LO, _RANK_HI))
    return '%02X%02X%02X' % c


def _sci(cell):
    """一个 ``log10`` 最终误差单元，被打印回为科学计数法的误差。"""
    if cell in ('-', '', None):
        return '-'
    try:
        v = float(cell)
    except (TypeError, ValueError):
        return cell
    try:
        return f'{10.0 ** v:.2E}'
    except OverflowError:
        # 发散的变体记录的 log10 误差过大，无法还原为浮点数；
        # 直接打印其数量级而非崩溃。
        return f'1E{v:.0f}'


_CELL_TOL = 0.05          # 配对矩阵被读取的分辨率，单位：log10 误差数量级


def _cell_stats(M):
    """单个配对矩阵的更低/更高/持平计数，单位：误差数量级。"""
    up = down = same = 0
    bare = M.get('bare') or []
    acc = M.get('acc') or []
    for i, brow in enumerate(bare):
        arow = acc[i] if i < len(acc) else []
        for j, bv in enumerate(brow):
            if j >= len(arow):
                continue
            try:
                b, a = float(bv), float(arow[j])
            except (TypeError, ValueError):
                continue
            if b != b or a != a:              # 该单元为空
                continue
            d = b - a
            if abs(d) <= _CELL_TOL:
                same += 1
            elif d > 0:
                up += 1
            else:
                down += 1
    return up + down + same, up, down, same


def _group_cell_stats(M, host_list):
    """一张配对矩阵中仅限若干变体的更低/更高/持平计数。

    ``host_list`` 选出属于同一组成级别组的那些列，因此单组表的格子计数
    直接从生成这些表的同一张矩阵读出。
    """
    hosts = M.get('hosts') or []
    fids = M.get('fids') or []
    idx = [hosts.index(h) for h in host_list if h in hosts]
    bare = M.get('bare') or []
    acc = M.get('acc') or []
    up = down = same = 0
    for i in range(len(fids)):
        for j in idx:
            if i >= len(bare) or j >= len(bare[i]):
                continue
            if i >= len(acc) or j >= len(acc[i]):
                continue
            try:
                b, a = float(bare[i][j]), float(acc[i][j])
            except (TypeError, ValueError):
                continue
            if b != b or a != a:              # 单元格留空
                continue
            d = b - a
            if abs(d) <= _CELL_TOL:
                same += 1
            elif d > 0:
                up += 1
            else:
                down += 1
    return up + down + same, up, down, same


def _paired_cell_stats(G):
    """配对矩阵的单元中，层真正推动了其中多少个。

    配对矩阵的每个单元是「一个变体 × 一个函数」，因此统计 UPCL 列低于变体
    单独列的单元数，即在度量层的作用有多集中。两列相差不超过 ``_CELL_TOL``
    个数量级的单元记为未受影响：这正是这些表被读取的分辨率。
    """
    tot = up = down = same = 0
    for M in (G.get('matrices') or {}).values():
        t, u, d, s = _cell_stats(M)
        tot += t
        up += u
        down += d
        same += s
    return tot, up, down, same


def _level_order_stats(G):
    """前导表中同时具备四个组成级别的行数，以及在那些行上最强级别与最弱
    级别分别取得最低、最高终值的次数。"""
    rows = low3 = high0 = 0
    for lm in (G.get('level_matrix') or {}).values():
        for r in lm.get('rows') or []:
            vals = []
            for v in r.get('vals') or []:
                try:
                    vals.append(float(v))
                except (TypeError, ValueError):
                    break
            if len(vals) < 4 or any(v != v for v in vals):
                continue
            rows += 1
            if vals[3] == min(vals):
                low3 += 1
            if vals[0] == max(vals):
                high0 += 1
    return rows, low3, high0


def _matrix_will_emit(M, host_list):
    """``host_list`` 中至少有一个变体在该区块里有数据时为真。

    与 `_emit_paired_matrix` 开头的判定一致，单独抽出是为了让正文在附录尚未
    渲染时就能预知附录表的编号。
    """
    return any(h in M['hosts'] for h in host_list)


def _emit_paired_matrix(P, caption, M, host_list, rank_map, appendix=False):
    """一代变体的配对（变体单独 vs UPCL）表。

    每个变体贡献两个相邻列，即变体单独值与附加 UPCL 的同一变体，均为科学
    计数法的中位最终误差，因此前后可并排读取。每个数值单元按其行内秩着
    绿色底纹（最浅 = 最优，最深 = 最差）。最后一行按函数给出每个变体在
    该套件内的总体排名，依据其在各函数上的变体单独中位误差（1 = 最优）。
    """
    hosts = M['hosts']
    fids = M['fids']
    bare = M.get('bare') or []
    acc = M.get('acc') or []
    idx = [hosts.index(h) if h in hosts else None for h in host_list]
    if all(j is None for j in idx):
        return False                  # 该代尚无变体运行

    header = ['函数'] + [c for h in host_list for c in (h, f'UPCL-{h}')]

    body, shades = [], []
    for i in range(len(fids)):
        row = [fids[i]]
        vals = []                     # (列索引, 数值误差)
        for j in idx:
            if j is None:
                row += ['-', '-']
                continue
            bv = bare[i][j] if i < len(bare) and j < len(bare[i]) else '-'
            av = acc[i][j] if i < len(acc) and j < len(acc[i]) else '-'
            cb = len(row)
            row.append(_sci(bv))
            ca = len(row)
            row.append(_sci(av))
            if bv not in ('-', '', None):
                vals.append((cb, 10.0 ** float(bv)))
            if av not in ('-', '', None):
                vals.append((ca, 10.0 ** float(av)))
        shade_row = [None] * len(row)
        order = sorted(range(len(vals)), key=lambda k: vals[k][1])
        for rank, k in enumerate(order, start=1):
            shade_row[vals[k][0]] = _rank_fill(rank, len(order))
        body.append(row)
        shades.append(shade_row)

    # 总体排名行：每个变体在该套件内的 1 基排名，按其在各函数上的变体
    # 单独中位误差（1 = 最优）
    rank_row = ['总体排名']
    for j in idx:
        if j is None:
            rank_row += ['-', '-']
        else:
            rank_row += [str(rank_map.get(hosts[j], '-')), '-']
    body.append(rank_row)
    shades.append([None] * len(rank_row))

    P.table_caption(caption, appendix=appendix)
    P.table(header, body, shades=shades,
            widths=[0.80] + [0.55] * (2 * len(host_list)),
            align='l' + 'r' * (2 * len(host_list)),
            font_size=6.5)
    return True


def _grid(P, S):
    G = S.get('grid') or {}
    hosts = G.get('hosts', [])
    matrices = G.get('matrices', {})

    # ---- 每个区块的变体单独排名：与第 4.2 节的精度/排名列同源 ------------
    # 取自共享估计量（`build_upcl_paper_cec.block_ranks`），即表 8-11 的精度
    # 与排名列所用的同一个，故这里的汇总表不可能与那里的分块表冲突。
    # 只有在独立调用本模块（没有 grid 字典）时才回退到从矩阵重算，矩阵里存的
    # 是同一批数、仅为显示做了舍入。
    _rank_block = G.get('block_rank')
    if not _rank_block:
        def _block_rank(M):
            """该区块内每个变体的 1 基排名。

            排名依据：变体单独配置在该套件**全部函数**上的中位最终误差，升序
            （1 = 最优）。先取中位数再取 log10，名次相同时按变体名排序，与
            `block_ranks` 完全一致。
            """
            _m_hosts = M.get('hosts', [])
            _m_bare = M.get('bare') or []
            _m_fids = M.get('fids', [])
            _m_acc = {}
            for _j, _h in enumerate(_m_hosts):
                _vals = []
                for _i in range(len(_m_fids)):
                    if _i < len(_m_bare) and _j < len(_m_bare[_i]):
                        _v = _m_bare[_i][_j]
                        if _v not in ('-', '', None):
                            try:
                                _vals.append(float(_v))
                            except ValueError:
                                pass
                if _vals:
                    _vals.sort()
                    _n = len(_vals)
                    _m_acc[_h] = (_vals[_n // 2] if _n % 2
                                  else (_vals[_n // 2 - 1] + _vals[_n // 2]) / 2.0)
                else:
                    _m_acc[_h] = None
            _rk = {}
            for _r, (_h, _v) in enumerate(
                    sorted(((h, v) for h, v in _m_acc.items() if v is not None),
                           key=lambda h_v: (h_v[1], h_v[0])), start=1):
                _rk[_h] = _r
            return _rk

        _rank_block = {_k: _block_rank(_m) for _k, _m in matrices.items() if _m}
    _rank_block = dict(_rank_block)

    def _blk_label(_k):
        _s, _d = _k
        return f'{_s[:3].upper()} {_s[3:]} $D={_d}$'

    # 全局名次表：每行一个变体、每列一个区块，末列为可用区块上的平均名次
    _all_hosts = []
    for _k in _GRID_SUITES:
        for _h in _rank_block.get(_k, {}):
            if _h not in _all_hosts:
                _all_hosts.append(_h)
    _mean_rk = {}
    for _h in _all_hosts:
        _rs = [_rank_block[_k][_h] for _k in _GRID_SUITES
               if _h in _rank_block.get(_k, {})]
        _mean_rk[_h] = sum(_rs) / float(len(_rs)) if _rs else None
    _by_mean = sorted(_all_hosts, key=lambda _h: (_mean_rk[_h] or 1e9, _h))
    # 只有在两者平均名次确实相同时才并列引用；D=50 区块补齐前是并列的，
    # 补齐后不再并列，因此措辞由数值决定而不是写死
    _rk0 = _mean_rk[_by_mean[0]] if _by_mean else None
    _rk1 = _mean_rk[_by_mean[1]] if len(_by_mean) > 1 else None
    if _rk1 is not None and abs(_rk0 - _rk1) < 0.05:
        _lead_txt = f'{_by_mean[0]} 与 {_by_mean[1]}（同为 {_f(_rk0, 1)}）'
    elif _rk1 is not None:
        _lead_txt = (f'{_by_mean[0]}（{_f(_rk0, 1)}），其后为 '
                     f'{_by_mean[1]}（{_f(_rk1, 1)}）')
    else:
        _lead_txt = (f'{_by_mean[0]}（{_f(_rk0, 1)}）' if _by_mean
                     else '排名最高的变体')

    P.h2('4.3  变体排名与景观')

    # 逐函数矩阵收在附录 A，按本小节四个区块的叙述顺序编号 A1、A2……；
    # 主文只保留区块汇总表，因此正文引用的是附录表序，而不占用主文表号
    _n_mtx = sum(sum(1 for _gl, _hl in _HOST_GROUPS
                     if _matrix_will_emit(matrices[_k], _hl))
                 for _k in _GRID_SUITES if matrices.get(_k))

    P.para(
        r'第 4.2 节已经逐个变体地把层与家族做了配对比较；本小节把'
        r'同样的比较拆解为框定全文的变体单独排名。表 '
        + str(_next_table(P)) + r' 与附录 A 的表 '
        + f'A1-A{_n_mtx}'
        r' 把每一个区块完整列出——全部二十九个变体在所有二十九个问题上'
        r'（$D=30$ 与 $D=50$ 的 CEC 2017、$D=10$ 与 '
        r'$D=20$ 的 CEC 2022）——'
        r'且每种配置运行三十次，因此表格中没有任何进度快照：条目都是最终结果。')

    P.para(
        r'因为每项比较的变体单独配置都是原样运行的变体，按变体在各函数上的'
        r'变体单独中位误差对它们排名，得到的是家族自身的一个性质，而非层的'
        '性质。四个区块合起来看，平均名次最好的变体是 '
        f'{_lead_txt}；在 CEC 2017 的两个区块里，前六名'
        '全部由成功历史、线性种群规模与基于秩的变体占据，而经典固定参数'
        '变体与策略集成变体总体垫底。顺序的中段会随套件与维度移动，两端却'
        '稳定，而这个两端正是本文论述的替换结构，第 4.2 与 4.3 节的校正'
        '实验正是对照它来读。一个能改进这些变体的层，将是在添加胜者所缺乏'
        '的东西；它做不到这一点、且其效应被限制在家族早已超越的变体上，'
        '这一事实正是关于可替换性的核心发现。')

    P.para(
        f'附录表 A1-A{_n_mtx} 每张表把函数列为行，'
        '并把每个变体算法配成两个相邻列，即变体'
        '单独与附加 UPCL 的同一变体，一次一个套件、一个维度；变体按组成级别'
        '分组，以免任何单张表承载过多列。每个值是科学计数法的中位最终误差，'
        '每个条目按其所在行的秩着绿色底纹：最浅为最优误差、最深为最差。'
        '最后一行按函数给出每个变体在该套件内的总体排名，依据其在各函数上'
        '的变体单独中位误差（1 = 最优）。在展开这些矩阵之前，表 '
        f'{_next_table(P)} 先把同一排名按区块汇总成一张总表：先读全貌，'
        f'再看逐函数的细节；附录 A 的表 A1-A{_n_mtx} 就是'
        '这些矩阵本身。')

    # ---- 排名汇总表：所有变体 x 所有区块 ---------------------------------
    # 一张表给出家族的全貌：每行一个变体、每列一个区块，格子是该变体在该
    # 区块内于该套件全部 CEC 函数上的名次。列的移动即名次随套件/维度的
    # 变化幅度，末列给出该变体实际拥有名次的平均值。
    _sum_rows = []
    for _h in sorted(_all_hosts, key=lambda _h: (_mean_rk[_h] or 1e9, _h)):
        _row = [_h]
        for _k in _GRID_SUITES:
            _row.append(str(_rank_block.get(_k, {}).get(_h, '-')))
        _row.append(_f(_mean_rk[_h], 1) if _mean_rk[_h] is not None else '-')
        _sum_rows.append(_row)
    P.table_caption(
        '实验 2（汇总）：全部变体在每个区块内的变体单独排名（1 = 最优），'
        f'与附录 A 的表 A1-A{_n_mtx} '
        '各矩阵最后一行同源；末列为该变体实际拥有名次的平均值。')
    P.table(['变体'] + [_blk_label(_k) for _k in _GRID_SUITES] + ['平均名次'],
            _sum_rows, widths=[1.5, 1.0, 1.0, 1.0, 1.0, 1.0],
            align='l' + 'r' * 5, font_size=7.5)

    # ---- 函数 x 算法配对矩阵，每个套件/维度一个 ----
    # 表格本身由 `_appendix` 在文末渲染，这里只把任务与所属区块登记下来，
    # 使正文能在任何表格绘制之前引用准确的附录编号。
    _first_mtx = True
    _app_cursor = 0                   # 已登记的附录表数
    _app_jobs = []                    # （套件，维度，级别名，变体表，排名，矩阵）
    for suite, dim in _GRID_SUITES:
        M = matrices.get((suite, dim))
        if not M:
            continue
        # 该区块的总体排名：与汇总表共用同一份计算
        _m_rank = _rank_block.get((suite, dim), {})
        _blk_groups = [(gl, hl) for gl, hl in _HOST_GROUPS
                       if _matrix_will_emit(M, hl)]
        _n_blk = len(_blk_groups)
        _a0 = _app_cursor + 1
        _bt, _bup, _bdn, _bsame = _cell_stats(M)
        P.para(
            ('配对矩阵首先给出 ' if _first_mtx else '同样的读法在 ')
            + f'{_blk_label((suite, dim))}：该区块的 {_bt} 个函数-变体格子中，'
            f'{_bup} 个的 UPCL 列更低、{_bdn} 个更高，{_bsame} 个与它相差不超过'
            f'这些表所能分辨的 ${_CELL_TOL:.2f}$ 个数量级。区块内的 '
            f'{_COUNT_WORDS.get(_n_blk, str(_n_blk))}张附录表 '
            f'A{_a0}-A{_a0 + _n_blk - 1} 按组成'
            '级别切分家族，因此竖着读一列即沿单一级别走遍整个函数集，横着读'
            '一行即在同一函数上比较两种配置。')
        _first_mtx = False
        _g_done = []                  # （级别名，格子数，更低，更高，持平）
        for group_label, host_list in _blk_groups:
            _gt, _gup, _gdn, _gsame = _group_cell_stats(M, host_list)
            _g_done.append((group_label, _gt, _gup, _gdn, _gsame))
            _app_jobs.append((suite, dim, group_label, host_list, _m_rank, M))
            # 每两张表之后插入一段简短读法，使附录不会连成一段没有文字的
            # 空档、而把全部评述堆在其后。
            if len(_g_done) == 2:
                _c1 = sum(g[1] for g in _g_done)
                _u1 = sum(g[2] for g in _g_done)
                _d1 = sum(g[3] for g in _g_done)
                _s1 = sum(g[4] for g in _g_done)
                P.para(
                    f'附录表 A{_a0} 与表 A{_a0 + 1} 承载 {_g_done[0][0]} 与 '
                    f'{_g_done[1][0]}两组变体，合起来占该区块 {_bt} 个格子中的 '
                    f'{_c1} 个。在这半块中，层令 UPCL 列更低的格子有 {_u1} 个、'
                    f'更高的有 {_d1} 个、与变体单独列相差不超过 '
                    f'${_CELL_TOL:.2f}$ 个数量级的有 {_s1} 个，因此这些格子中有 '
                    f'{100.0 * _u1 / max(_c1, 1):.0f}% 被层改善；其后的自适应'
                    '各表在同一条基准线上承载区块余下的格子。')
            elif len(_g_done) == 4:
                _c2 = sum(g[1] for g in _g_done[2:])
                _u2 = sum(g[2] for g in _g_done[2:])
                _d2 = sum(g[3] for g in _g_done[2:])
                _s2 = sum(g[4] for g in _g_done[2:])
                P.para(
                    f'附录表 A{_a0 + 2} 与表 A{_a0 + 3} 承载 {_g_done[2][0]} 与 '
                    f'{_g_done[3][0]}两组变体，是同一区块中另外 {_c2} 个格子。'
                    f'在这里层令 UPCL 列更低的有 {_u2} 个、更高的有 {_d2} 个、'
                    f'相差不超过 ${_CELL_TOL:.2f}$ 个数量级的有 {_s2} 个，占比 '
                    f'{100.0 * _u2 / max(_c2, 1):.0f}%，而区块前半的固定参数与'
                    f'自适应两组为 {100.0 * _u1 / max(_c1, 1):.0f}%。收尾的两张'
                    '第 3 级表补齐该区块；竖着读下来，被改善格子的占比正是'
                    '随宿主接管机制而收缩的那个量。')
        _app_cursor += _n_blk
    S['exp2_appendix'] = _app_jobs

    _n_cell, _n_up, _n_dn, _n_same = _paired_cell_stats(G)
    P.para(
        '逐格读，这些矩阵显示了这一混合从何而来。四个区块共 '
        f'{_n_cell} 个变体-函数格子中，成对两列在 {_n_same} 个格子上相差'
        f'不超过 ${_CELL_TOL:.2f}$ 个数量级，而层在 {_n_up} 个格子上更低、'
        f'在 {_n_dn} 个格子上更高。因此附加该层使家族大部分成员的中位最终'
        '误差改变小于这些表的分辨率，只推动了少数格子，第 4.2 节的汇总值'
        '正是这一混合的平均。')

    # 收敛图从逐变体的配对数值切换到按组成级别汇总。切换前，先为每个
    # （套件，维度）区块给出一张"函数 × 组成级别"终值表，把收敛图每条曲线
    # 在预算结束处的读数换算成具体数值；随后收敛图再给出完整轨迹。
    level_matrix = G.get('level_matrix', {})
    _n_lead = sum(1 for _k in _GRID_SUITES if matrices.get(_k))
    _lead_first = P.tab_no + 1
    P.para(
        '从逐变体的配对数值转向收敛图之前，先把组成级别映射为具体数值。'
        '这一级别划分已在第 4.1 节给出：第 0 级保留固定参数，第 1 级把参数编码进'
        '个体，第 2 级加入成功历史记忆、外部存档与策略集成，第 3 级加入种群'
        f'规模缩减与基于秩的重启。表 {_lead_first}-'
        f'{_lead_first + _n_lead - 1} 把函数列为行、把组成级别列为列，每个'
        '单元是该级别内所有变体在三十次运行上的中位 $\log_{10}$ 最终误差'
        '（越低越好）——正是收敛图中每条曲线在预算结束处所到达的读数。表给出'
        '终值，图给出轨迹，二者共用同一级别划分与同一批三十次运行。')
    _lv_label = {'0': 'L0', '1': 'L1', '2': 'L2', '3': 'L3'}
    for suite, dim in _GRID_SUITES:
        lm = level_matrix.get((suite, dim))
        if not lm:
            continue
        levels = lm['levels']
        header = ['函数', '类别'] + [_lv_label[lv] for lv in levels]
        body = []
        for r in lm['rows']:
            row = [r['fid'], r['cat']]
            for v in r['vals']:
                row.append(_f(v, 2))
            body.append(row)
        P.table_caption(
            f'实验 3（前导）：{suite} 在 $D={dim}$ 上各组成级别的 level-median '
            '终值（$\log_{10}$ 误差，越低越好）。每行一个函数，列 L0–L3 即收敛图'
            '各曲线终点的具体数值。')
        P.table(header, body,
                widths=[0.6, 1.2] + [0.7] * len(levels),
                align='l l' + 'r' * len(levels), font_size=7.0)

    _n_lv, _n_lv3, _n_lv0 = _level_order_stats(G)
    P.para(
        '这些表同时确定了各函数上的级别次序。'
        f'同时具备四个级别的 {_n_lv} 行是读出这一点的依据：其中 {_n_lv3} 行'
        f'由 L3 列取该行最低的终值、{_n_lv0} 行由 L0 列取最高，因此收敛曲线'
        '在预算结束处呈现的次序，已由这些数值本身确定。')

    # 每个（套件，维度，分段）一张收敛图：每张图只放六个函数以便适配版心。
    conv_figs = G.get('conv_figs', [])
    first_fig = P.fig_no + 1
    P.para(
        f'图 {first_fig}-{first_fig + len(conv_figs) - 1} 的收敛图即沿用'
        '这一级别划分。由于每个变体各自一条曲线在同一子图'
        '内不可读，且逐变体的精确配对值已由本节的表格承载，收敛图改为按组成'
        '级别汇总：每个子图中每条线是该级别内所有变体在三十次运行上的中位 '
        '$\log_{10}$ 误差（阴影带为级别内变体的 25–75 百分位），实线为变体'
        '单独、虚线为附加 UPCL。')
    _conv_notes = {
        ('cec2017', 30, 1):
        '这一序列沿用套件自身的编号：函数按套件声明次序取用，切成最多十二个'
        '一块，排成三列、最多四行，因此一个函数可以按其编号直接找到，无需'
        '图例。每个子图各有自己的纵轴范围，取自它内部的曲线，因此一条曲线的'
        '绝对高度只在同一子图内可比；跨子图可比的是同色实线与虚线之间的'
        '距离。各列按套件次序排列，因此一段中最左边的面板装着这一段里最小的'
        '函数编号，而同一位置在随后另一维度的图中仍是同一个函数：读者一旦'
        '定位过某个函数，就能在配对图里按位置再找到它，这也是维度配对无需'
        '第二套图例即可对读的原因。切块只影响图的组织，不影响任何统计：无论'
        '一个函数落在哪一段、哪一行，它与哪一条曲线配对、用哪几次运行汇总都'
        '完全相同，因此把某个函数从一段换到另一段不会改变它的读数，只会改变'
        '它出现在哪一页。',
        ('cec2017', 30, 2):
        '每一对曲线之后有两层阴影，深色为级别单独、浅色为同一级别附加该层。'
        '它们是该级别内各变体的第 25 至 75 百分位，而不是中位数的区间，因此'
        '其宽度本身就是一种读数：若两条阴影在预算的大部分上重叠，则中位数'
        '之差小于级别内部的分歧，该子图不构成任何方向的证据；若两者分离，'
        '则移动的是级别本身。两层阴影以透明度叠加，其重叠处呈现为第三种更深的'
        '色块：若该色块占据子图的大部分，则无论中位数漂移多远都不宜分开读；'
        '若它很早就变薄，说明分离在预算用去一半之前就已发生。',
        ('cec2017', 30, 3):
        r'每条曲线都是截断在 $10^{-8}$ 上的 $\log_{10}$ 误差，因此沿底部'
        '走平的曲线是触到了下限，而不是停止改进；在那一段上两臂在图的'
        '分辨率内一致。一个子图里可读的事件是虚线离开实线的那一点，而不是'
        '两者共同的终点高度；有信息的一段在下限之前，这也是这些子图自左向右'
        '读的原因。下限是测量的下限而不是搜索的下限：一个级别触到它，说明'
        '它已越过了套件尚能区分两次运行的分辨率，此后两臂之间的任何差异都'
        '落在对数所能显示的位数之下。',
        ('cec2017', 50, 1):
        r'同一套件又在 $D=50$ 上画一遍，以便把维度与套件分开。变体、运行数、'
        r'配对方式与汇总方式都不变，预算沿用同一规则，即每个坐标 $10^{4}$ '
        '次评估，因此这两族图的差别只在坐标数。描述子以种群散布归一化步长，'
        '这正是该层在两种维度下对同一相对位移看到同样五个数的原因；两臂之差'
        '若发生变化，那是地形变了，而不是量纲变了。这一预算规则同时把横轴'
        '拉长——五十万次评估对三十万次——因此相同的横轴比例对应相同的每坐标'
        '评估次数，两族图宜在同一比例处对读，而不在同一计数值处对读。由此'
        '产生两个读法上的后果。其一，由于横轴更长，每条曲线的早期阶段被压缩'
        '在子图左侧五分之一内，在三十维上会铺开在最初数千次评估上的差异，'
        '在这里只剩几个像素；因此这一维度的子图主要读后期，那里一个数量级的'
        '分离被画在一段可读的长度上。其二是一种授权而非告诫：两个区块带着同样的'
        '二十九个变体、同样的二十九个问题，因此每个级别在两种维度下都由同一批'
        '成员构成，两族子图可以逐级别对读。另有一点这一族图不授权：不能跨两族比较曲线的'
        '绝对高度。下限、汇总方式与运行次数都相同，坐标数却不同，在五十维上'
        '达到某个误差的级别，其每单位误差的付出多于三十维；两族之间可比的是'
        '级别的次序与两臂的分离，绝不是某一条曲线的高度。按此读法，这一族图是'
        '对前面表格的一次核对而不是第二个结果：要问的是级别是否以同样次序出现、'
        '两臂是否在预算的同一处分开，两者都能在不出图的情况下看完；至于分开'
        '多少，仍以配对统计为准。同一横轴位置上两族图对应同样的每坐标评估数，'
        '因此"某级别在五十维上更晚分开"这一说法可以量化成横轴上的两个位置。'
        '就本族图而言，最容易被误读的一点是把"某级别'
        '曲线更高"当作该级别更好：纵轴是误差的对数，越低越好，而级别之间并不'
        '构成一条累积的时间线，它们是同一批运行在不同机制上的分组，因此曲线'
        '之间的高度差只描述同一函数上各组的相对位置，不描述任何演进。',
        ('cec2017', 50, 2):
        '在五十维上各等级分离得更晚，若干子图到预算结束时仍在数量级之内。'
        '把 L0 与 L3 分开的机制主要管种群如何跨代维持，这种维持需要更长的'
        '过渡才能反映到误差上，因此次序出现得晚是预期的，而不是出现得弱。'
        '读法不受影响：子图内关心的是同色实线与虚线之差，且取轴的右端读数。'
        '在这一维度上更宽的阴影带正属于这一读法的一部分——当两条阴影在预算的'
        '大部分上重叠时，中位数之间几十分之一数量级的分离小于级别内部各变体'
        '的分歧，不记为增益。',
        ('cec2017', 50, 3):
        '四个级别在每个面板中都出现，且所依据的成员与三十维完全相同——'
        '本区块同样承载这二十九个变体在二十九个问题上的结果——因此某个级别的'
        '阴影带与另一族中同一级别是同样多变体的陈述，两族可以直接对读。'
        '与三十维家族剩下的差别是曲线更少触底：在这'
        '一维度上套件的分辨率在预算内没有被用尽，因此更多面板要读满整个宽度，'
        '而不是只读到走平之前的那一段。级别对变体的归属只在第 2 节的机制表中'
        '确定一次，此后每个面板沿用同一归属：颜色不随函数改变，这正是某个级别'
        '可以从一个面板跟到下一个面板、也可以从一个维度跟到另一个维度的原因。',
        ('cec2022', 10, 1):
        '第二个套件每个维度十个函数，因此一张图覆盖全套，可以一次读完。'
        '配色、线型与按级别汇总的方式都保持不变，两个套件因此可以用同一种'
        '眼光读；本图各面板正是与随后 $D=20$ 那张图对照的对象——同一位置在'
        '两图中是同一个函数，这一对因此成为单一套件内维度效应的直接读数。'
        '十个函数排成三列四行，最后一行的一半为空；空位被关闭而非以占位符'
        '填充，因此不会在没有函数的地方读出面板。本图横轴到十万次评估，'
        '即十维下每坐标一万次的预算；汇总同样按级别与臂进行，各三十次运行，'
        '阴影带定义与下限都与大套件一致。四个区块现在都已完整，因此这里没有'
        '带缺级的子图，这一对图不必带着缺口读：本图中'
        '某个颜色出现在某个面板里，下一张图的同一面板里必然也有，二者之间比较'
        '的是同一组变体。十个面板读不出的，是单个变体的行为，因为每条曲线本身'
        '已是该级别内各变体的中位数；紧随其后的图正是在一个维度上、按类别各取'
        '一个函数来接续这个问题。相较三十维的那一族，本图在级别阴影带的宽度上'
        '失去一些分辨力：每级只有两三个变体时，多峰函数上的阴影带宽可达一个'
        '数量级，此时中位数之间零点几个数量级的分离读作不分离。这一不对称正是'
        '定量结论由汇总表而非由这些曲线承担的原因：曲线用来核对效应的符号与'
        '出现位置，量级留给配对统计。最后一行是不完整的，它被关闭而不是被填充，'
        '因此不会出现代表不存在函数的空面板；每个函数的格子位置由它的编号唯一'
        '确定，因此同一面板在配对的两张图里位置相同，读者不必再查题注即可定位。'
        '还需注意，十张面板各有自己的纵轴范围，取自各子图内部的曲线，因此跨'
        '面板比较曲线高度没有意义，可比的只有同一面板内实线与虚线之间的距离。'
        '判决性的读法只有一个：该距离的大小，以及它从预算的哪一处开始出现。'
        '凡是需要把两个不同子图并置才能读出的差别，都落在跨子图不可比的范围内。'
        '每个子图自带纵轴也是出于同一理由：把十个函数压到同一刻度上，便宜函数'
        '的有用信息会被昂贵函数抹平，配对差值随之不可见。',
        ('cec2022', 20, 1):
        '同一套件的第二个维度画在同样的十个面板上，因此这一对可以当作'
        '同一张图看两遍：同一个格子里是同一个函数，两者之差只在坐标数与'
        '随之而来的预算。合起来读，给出的是不夹杂函数集变化的维度效应，'
        '这是设计中最小的受控配对，也是大套件结论所对照的基准。第二张图的'
        '横轴长度是前一张的两倍——二十万次评估对十万次——因此这一对宜按预算的'
        '相同比例对读；在某两个面板里于相同比例处到达同一高度的曲线，其行为'
        '不依赖坐标数，而到达得更晚的曲线则为多出的坐标付了代价。两图之间'
        '别无其他改动，这正是该比较得以成立的理由。',
    }
    for f in conv_figs:
        _nt = _conv_notes.get((f['suite'], int(f['dim']),
                               int(f.get('part') or 1)))
        if _nt:
            P.para(_nt)
        part_txt = (f'，第 {f.get("part")}/{f.get("n_parts")} 段'
                    if f.get('n_parts', 1) > 1 else '')
        P.figure(f['path'],
                 f'实验 3：{f["suite"]} 在 $D={f["dim"]}$ 上的收敛'
                 f'{part_txt}：每个函数一个子图；每条线为某个组成级别内变体'
                 '的中位数（阴影带为该级别内变体的 25–75 百分位），变体单独'
                 '为实线、附加 UPCL 后为虚线（三十次运行的中位数）。')

    P.para(
        '级别的中位数可以是平的，而该级别内部各变体正朝相反方向移动：使八个'
        '面板得以读懂的那种汇总，同时也掩盖了单个变体的响应，而表格逐变体'
        '报告配对效应，正是图所不能承担的部分。因此紧随其后的特写每次只改变'
        '一个因素。它把套件与维度固定在分析最密集的设置上，按类别各取一个'
        '函数以覆盖四类地形，按组成级别各取一个代表变体以覆盖四代机制。它'
        '展示的不是摘要，而是配对运行本身：变体单独一条曲线，同一变体附加'
        '该层后另一条，因此读者能看出两条曲线在何处分开，以及在单峰、多峰、'
        '混合与复合函数上是否以同样方式分开。读法上，这张图按列读而不按行'
        '读：每一列是一种地形，四行把同一个问题问四遍。')

    rep = G.get('rep_fig')
    if rep:
        P.figure(rep['path'],
                 '实验 4：一张代表性特写——四个典型函数（每个 CEC 类别一个）'
                 'x 四个代表变体（每个组成级别一个），在 $D=30$ 的 CEC 2017 '
                 '上，变体单独为实线、同一变体附加 UPCL 后为虚线（三十次运行'
                 '的中位数）。')

    tot = G.get('total', {})

    def _avg(e):
        """一个变体的平均效应，在完整区块上汇总。"""
        done_blocks = [b for b in e['blocks'] if b['cells']]
        n = sum(b['cells'] for b in done_blocks)
        return sum(b['mean_dec'] * b['cells'] for b in done_blocks) / max(n, 1)

    have = [e for e in G.get('per_host', []) if e['cells']]
    ranked = sorted(have, key=_avg)
    worst, best = ranked[0], ranked[-1]

    P.para(
        f'在完整家族上，$\mathrm{{dec}}$ 的均值为 '
        f'{_f(tot.get("mean_dec"), 3, True)} 个数量级，与第 4.2 节相同的'
        '图景，现在包含了每一个自适应其自身参数的变体。变体之间的散布再次'
        f'大于平均效应：在其 {best["cells"]} 项比较上，{best["host"]} 获得 '
        f'{_avg(best):+.2f} 个数量级，而 {worst["host"]} 在其 {worst["cells"]} '
        '项比较上损失 '
        f'{abs(_avg(worst)):.2f}。'
        + (f' 图 {first_fig}-{P.fig_no} 绘制了同样的比较。' if conv_figs else ''))

    # ---- 区块级汇总，压缩为一句话 ------------------------------------
    _block_means = ', '.join(
        f'{s["suite"]} $D={s["dim"]}$ {_f(s["mean_dec"], 3, True)}'
        for s in G.get('suites', []))
    P.para(
        f'区块均值与家族图景一致：移除的均值数量级整体为 '
        f'{_f(tot.get("mean_dec"), 3, True)}，分区块看为 {_block_means}，'
        '处处为负但很小，且不随套件或维度系统性移动。随问题改变的是均值周围'
        f'的散布——层帮助哪些变体、损害哪些变体；表 {_next_table(P)} 的类别'
        '读法则定位这一'
        '散布真正打开的那些景观。')

    # ---- 哪些景观留下余地（类别读法） --------------------------------
    cat = S['category']
    P.para(
        '表 '
        f'{_next_table(P)} 按套件声明的类别重组比较，定位变体在哪些景观上'
        '留下可改进的余地。层并非均匀'
        '有用，且失效并非随机：它集中在复合函数中，在那里幅度也最大。复合'
        '函数由几个独立平移旋转、权重不同的基函数求和构成，因此局部地形几乎'
        '不携带关于有用方向的信息，而从单个候选的局部几何选出的校正，如朝'
        '目标收缩、反射它、与精英对齐，是在拟合一个不描述该地形的代理。'
        '单峰区块正是局部几何恰好重要的地方，也是层收益最好的地方。读法不是'
        '层偏爱简单函数，而是层根据局部证据编辑候选，而当局部几何被设计为'
        '无信息时，这种编辑价值更低。')

    P.table_caption('实验 5：按声明问题类别的效应。每类别报告 '
                    '$\\mathrm{dec}$（移除的数量级）的均值与中位数。')
    _cat_rows = [[f'{r["suite"]} ${r["dim"]}$', r['category'],
                  _f(r['dec_mean'], 3, True), _f(r['dec_median'], 3, True)]
                 for r in cat]
    P.table(['套件', '类别', 'dec 均值', 'dec 中位'], _cat_rows,
            widths=[1.25, 1.15, 0.95, 1.0],
            align='llrr')

    _ec = S["protocol"].get("err_corr")
    if _ec != _ec:  # NaN：CEC 2017 配对比较尚未获取
        P.para(
            '有一个混淆可以直接排除：大增益可能仅仅意味着变体单独离最优'
            '很远、有更大的下降空间。变体单独误差与该比较移除数量级之间的相关'
            '性，在 CEC 2017 配对区块可用后即报告。')
    else:
        P.para(
            '有一个混淆可以直接排除：大增益可能仅仅意味着变体单独离最优'
            '很远、有更大的下降空间。变体单独误差与该比较移除数量级之间的相关'
            '性给出了答案：它为正但弱（在 $D=30$ 的 CEC 2017 区块上 Spearman '
            f'{_f(S["protocol"]["err_corr"], 2, True)}，$p<'
            f'10^{{-7}}$），因此增益与每个变体还剩多少下降空间只有弱关联。')


# ===========================================================================
# 4.5  机制
# ===========================================================================
def _mechanism(P, S):
    m30 = S.get('mech30', {})
    attr = S.get('attr', {})
    host_summary = m30.get('host_summary', [])
    by_level = m30.get('by_level', [])
    by_cat = m30.get('category', [])
    cat_level = m30.get('category_level', [])

    P.h2('4.4  机制归因')

    P.para(
        '第 4.2 节与第 4.3 节已经确立了家族中哪些变体获胜、哪些景观给校正留下'
        '余地；本节转向为什么。它把干预增益及其伴随的观测量归因回第 2 节的九'
        '个机制族，并按该节所述折叠为二十九个宿主所能支撑的六个机制指标：'
        '供体、$F/CR$ 规则、算子池、存档、种群规模与残差。这一读法从机制指纹，'
        '到组成层级梯度，再到一个在这六个指标上控制其'
        '共线性的多元统计归因，最后把贡献按问题与可替换性条件化，从而回答 '
        'RQ1–RQ4。支撑这一切的逐变体指纹汇总于表 '
        f'{_next_table(P)}。')

    # --- 主指纹表 ---------------------------------------------------------
    fp_rows = []
    for r in host_summary:
        fp_rows.append([
            r['host'], str(r['level']),
            _f(r['bare_median_log10err']),
            _f(r['intervention_rate'], 3),
            _f(r['dec_mean'], 3, True),
            _f(r['theta_align_effect'], 2, True),
            _f(r['eta_elite_effect'], 2, True),
        ])
    P.table_caption(
        '二十九变体的机制指纹，按裸排名排序：bare = 中位 $\\log_{10}$ 最终'
        '误差的均值（越低越好），IR = 干预率，dec = $\\log_{10}$ 误差的增益'
        '（正值更好），$\\theta$/$\\eta$ = 携带信号的两个描述子对比。')
    P.table(
        header=['变体', '级别', 'bare', 'IR', 'dec', '$\\theta$', '$\\eta$'],
        rows=fp_rows,
        widths=[1.55, 0.50, 0.92, 0.70, 0.92, 0.92, 0.92],
        font_size=7.0, align='l c r r r r r')

    P.para(
        '这种塌缩并非少数离群点的假象。逐个变体地看，指纹背后的条目分成'
        '两群：现代变体紧紧聚集在左下角，只干预极小一部分候选、几乎什么都恢复'
        '不到，而固定参数变体向上散开，干预率更高、增益更大也更嘈杂。两个'
        '携带信号的描述子对比'
        '从几何上定位了这个缺口所在：提议校正与变体位移的对齐、以及校正到精英'
        '的接近，两者都随组成级别而下降，因此干预最少的级别，恰恰也是其候选'
        '已然被瞄准、已然呈精英形状的级别——那里已没有可供该层校正的几何'
        '松弛。')

    # --- 第一层：机制贡献 -------------------------------------------------
    lv = {int(r['level']): r for r in by_level if r.get('level') not in (None, '')}
    ir0 = float(lv[0]['intervention_rate']) if 0 in lv else 0.0
    ir3 = float(lv[3]['intervention_rate']) if 3 in lv else 0.0
    bare0 = float(lv[0]['bare_median_log10err']) if 0 in lv else 0.0
    bare3 = float(lv[3]['bare_median_log10err']) if 3 in lv else 0.0

    P.para(
        '表 '
        f'{_next_table(P)} 把指纹按组成级别汇总，由此看出搜索压力来自何处。'
        '从第 0 级的固定参数变体走到第 3 级的'
        '现代变体，三个数字反向移动。裸误差下降约 '
        f'{max(0.0, bare0 - bare3):.1f} 个 $\\log_{10}$ 误差数量级，干预率从 '
        f'{100.0 * ir0:.0f}% 降到 {100.0 * ir3:.1f}%，而干预增益从第 0 级'
        '为负的值塌缩到第 3 级与零无差别的值。因此贡献并非均匀分布：它'
        '集中在第 2、3 级新增的机制上——带存档的成功历史记忆、带选择压力的'
        '种群规模缩减——而它们恰恰也是抹掉校正层本可恢复的候选级松弛的那批'
        '机制。携带信号的两个描述子对比，即与变体位移的对齐与到精英的接近，'
        '同样正是成功历史变体显式存储的量，于是指纹从外部读回了获胜变体安装'
        '在内部的那个机制。')

    lv_rows = [[str(r['level']), str(r['n_hosts']),
                _f(r['bare_median_log10err']),
                _f(r['intervention_rate'], 3),
                _f(r['dec_mean'], 3, True),
                _f(r['mean_relative_shift'], 2)]
               for r in by_level]
    P.table_caption(
        '按组成级别平均的机制贡献。bare 是中位 $\\log_{10}$ 误差的'
        '均值；IR 是干预率；dec 是干预增益；shift 是校正相对于其修改候选的'
        '平均相对位移。')
    P.table(
        header=['级别', '变体数', 'bare', 'IR', 'dec', 'shift'],
        rows=lv_rows, widths=[0.7, 0.7, 1.1, 0.9, 1.0, 0.9],
        align='ccrrrr')

    # --- 第二步：六维统计归因 ----------------------------------------------
    _DIM_LABEL = {
        'mutation_class': '变异算子',
        'param_class': '参数规则',
        'strategy': '算子选择',
        'archive': '外部存档',
        'pop': '种群规模',
        'other_flag': '额外机制',
    }
    P.para(
        '组成层级梯度点明了哪几代机制承载着该领域的进步，却没有点明是六个'
        '维度中的哪一个；要把贡献定位到维度层面，需要一种尊重一个结构性事实的'
        '统计归因：六个维度并非正交——筛析设计 '
        '[@MORRIS] 与方差型敏感度分析 [@SALTELLI10] 正是为该情形准备的工具；'
        '本节余下的四个读数改走离散路线。粗化之后，变异算子'
        f'完全决定了算子选择策略（Cramér\'s $V = '
        f'{attr.get("v_mut_strategy", 1.0):.2f}$），参数规则与外部存档强关联'
        f'（$V = {attr.get("v_param_archive", 0.90):.2f}$）。这一共线性是归因'
        '的中心混杂因素，它预告了单变量与多变量读数之间的一次反转。随后的'
        f'四个读数——关联、单变量效应量、多变量归因、近对消融——绘于图 '
        f'{P.fig_no + 1}-{P.fig_no + 4}。')

    P.figure(PFG.fig('attr_d1_assoc'),
             '六个机制指标之间的关联（Cramér\'s V 瓷砖图）及每个指标的宿主'
             '边际分布；变异算子完全决定算子选择策略（$V = 1.00$），参数规则'
             '与外部存档强关联（$V = 0.90$）。')
    P.para(
        '这张瓷砖图应读作一张"设计能否把两个标签分开"的地图。对角线按构造为'
        '一，不携带信息；有信息的是非对角元，每一个统计两个标签共同出现的'
        '变体数，并对独立假设下应有的计数做归一。有两个元接近于一：变异算子'
        '完全决定算子选择策略，参数规则与存档强关联。二者都是现代 DE 的构造'
        '特征而非样本的偶然——策略常以驱动它的变异命名，存档则是参数规则赖以'
        '自适应的装置。其实质后果是对观察式比较能归因到何种程度的一个界：在'
        '这个语料上，任何把两个标签当作回归量的方法都无法把变异的作用与策略的'
        '作用分开，参数规则与存档同理。瓷砖图边缘的边际条形说明其余元为何更'
        '易读：共现弱的指标，其变体在四个级别上分布较散，因此它们之间的差异'
        '不与级别结构混淆。本节余下的部分正是从不同路径反复处理这两个接近'
        '于一的对。')
    P.para(
        '四个读数按各自假设的多少排序。瓷砖图除类别编码外不假设任何东西，只'
        '报告共现；单变量效应量假设指标可以逐个筛查，报告它在某个观测量上能'
        '解释多少变异；多变量归因假设标准化指标上的线性模型，报告在固定其余'
        '指标后哪一个仍然存活；近对消融只假设两个仅差一处机制的变体可以比较，'
        '报告这一差别在误差上值多少。四者各自回答前一个回答不了的问题：共现'
        '指出哪些对纠缠，单变量筛查指出纠缠的指标是否仍携带信号，线性模型'
        '指出一组纠缠指标中哪一个携带边际信号，而消融是四者中唯一非观察式的，'
        '因为它按构造改变机制。四者一致处读数可靠；不一致处——例如算子选择'
        '策略，线性模型排第二而随机森林排第六——分歧定位的是混淆而不是效应，'
        '两者并不构成矛盾，只是各自回答不同的问题；本节取多元归因为准，因为它'
        '显式固定了其余指标。')
    P.figure(PFG.fig('attr_d2_eta2_dot'),
             '每个机制指标在每个观测量上的单变量效应量（$\\eta^2$，'
             'Kruskal-Wallis）；每个面板内观测量按效应量降序排列，虚线标出'
             '$\\eta^2 = 0.10$。')
    P.figure(PFG.fig('attr_d6_attribution'),
             '干预增益的多元归因。(a) 标准化回归系数（带 95% 置信区间；每个'
             '机制指标一种颜色，与本节其余图件一致，系数印在行右端，'
             '$p<0.10$ 者标 $\\dagger$）；(b) 随机森林置换重要性（须线为置换'
             '标准差）。两个面板共用同一行序（$|\\beta|$ 降序），中间的窄带把'
             '$\\beta$ 排序（左端实心节点）映射到重要性排序（右端空心节点，'
             '标注重要性名次），因此两种读数可逐行对照，且只在首位维度上'
             '一致。')
    P.figure(PFG.fig('attr_d8_near_matrix'),
             '近对消融：六维机制画像恰好只差一个维度的 40 次受控对照，'
             '按该维度分组，组内按 $\\Delta$dec 排序。')

    P.para(
        '单变量地看，图景很安静。没有任何维度对 dec 产生强效应：六个维度中最大的 '
        f'$\\eta^2$ 为 {attr.get("eta2_dec_max", 0.02):.3f}，最强的单一'
        f'信号是参数规则（$\\eta^2 = {attr.get("kw_param_eta2", 0.013):.3f}$、'
        f'$H = {attr.get("kw_param_H", 25.4):.1f}$、$p < 0.001$），而变异算子'
        f'不显著（$p = {attr.get("kw_mut_p", 0.18):.2f}$）。维度真正呈现出'
        '结构的地方在几何描述子上，而非最终增益：参数规则与变异算子在步长比上'
        f'承载了最大的效应（$\\eta^2 = {attr.get("eta2_rho_param", 0.21):.2f}$ '
        f'与 $\\eta^2 = {attr.get("eta2_rho_mut", 0.19):.2f}$）。因此，单变量地看，这两个'
        '维度塑造的是候选如何移动，而不是搜索是否以更好告终。')

    P.para(
        f'表 {_next_table(P)} 把 dec 对六个维度编码做标准化回归，读数随之'
        f'反转。在控制其余每个维度后，变异算子给出最大的系数'
        f'（$\\beta = {attr.get("beta_mut", 0.69):+.2f}$，95% CI '
        f'[{_f(attr.get("beta_mut_lo", -0.003), 3, True)}, '
        f'{_f(attr.get("beta_mut_hi", 1.513), 3, True)}]，'
        f'$p = {attr.get("beta_mut_p", 0.051):.3f}$），但其区间仍包含零，'
        f'且在六个检验下经 Holm 校正后不显著：在这个样本量上没有任何单一机制'
        f'维度被识别。参数规则的单变量优势'
        f'塌缩为一个不显著的 $\\beta = {attr.get("beta_param", 0.22):+.2f}$。'
        f'随机森林置换重要性把前两个维度排成同样的次序（变异算子 '
        f'{attr.get("rf_mut", 0.58):.2f}、参数规则 '
        f'{attr.get("rf_param", 0.18):.2f}、其余维度均不高于 '
        f'{attr.get("rf_third", 0.04):.2f}），而共线性是'
        f'温和的——最大的方差膨胀因子为 {attr.get("vif_max", 3.9):.2f}，'
        f'低于惯常阈值 5——所以反转是'
        f'可解释的。不过这种一致只限于前两位：图 {P.fig_no - 1} 中间的窄带'
        f'把两个排序相互映射，显示出 $\\beta$ 排序第二的算子选择维度在随机'
        f'森林中排在末位，其系数落在 (a) 面板中最宽的区间上。'
        f'单变量地，变异算子的效应被与之纠缠的算子选择与外部存档'
        f'维度分散了，只有当这些维度被固定时它才成为最大的系数。两种读数都'
        f'不是识别：在二十九个变体与六个相关编码之下，归因所支持的只是前两个'
        f'维度之间的一个次序，而不是其中某一个承载了效应。')

    reg_rows = []
    for r in attr.get('raw', {}).get('regression', []):
        term = r.get('term')
        if term == 'intercept':
            continue
        b = float(r['beta'])
        rf = next((float(rr['importance'])
                   for rr in attr['raw']['rf_importance']
                   if rr.get('term') == term), float('nan'))
        reg_rows.append((b, [_DIM_LABEL.get(term, term), _f(b, 2, True),
                             _f(r['se'], 2),
                             f'[{_f(r["lo"], 3, True)}, '
                             f'{_f(r["hi"], 3, True)}]', _f(rf, 2)]))
    reg_rows.sort(key=lambda t: -t[0])
    reg_rows = [t[1] for t in reg_rows]
    P.table_caption(
        '干预增益的六维多元归因。$\\beta$ 是 dec 对每个维度（控制其余维度）'
        '的标准化回归系数；RF 是随机森林置换重要性。控制共线维度后，只有变异'
        '算子接近显著。')
    P.table(
        header=['维度', '$\\beta$', 'se', '95% CI', 'RF'],
        rows=reg_rows, widths=[1.7, 0.8, 0.7, 1.5, 0.7],
        align='lrrrr')

    np_by_dim = attr.get('np_by_dim', {})
    np_tot = sum(v['n'] for v in np_by_dim.values())
    P.para(
        f'近对消融给出了最接近因果的检验。枚举每一对恰好在一个维度上不同的'
        f'宿主对（共 {np_tot} 对：参数规则 17、变异算子 16、种群规模 6、额外'
        f'机制 3；算子选择与外部存档没有产生任何对，因为它们总是一起变化），'
        f'并问当只有那个维度改变时 dec 移动多远，再次只挑出变异算子作为唯一'
        f'强维度：它的那些对平均把 dec 移动 '
        f'$|\\Delta\\mathrm{{dec}}| = '
        f'{np_by_dim.get("mutation", {}).get("mean", 0.25):.2f}$，而参数规则'
        f'为 {np_by_dim.get("param", {}).get("mean", 0.05):.2f}，其余低于 0.01；'
        f'表 {_next_table(P)} 给出各维度的均值。图 {P.fig_no} 把这四十次比较'
        f'逐行展开：行按唯一不同的维度分组，组内按 $\\Delta$dec 排序，颜色给出'
        f'该移动的正负，因此只有变异算子那一块的行不围绕零对称。每组组头内嵌'
        f'该组自身的 $|\\Delta\\mathrm{{dec}}|$ 分布（每对一点、菱形为均值、'
        f'横杠为 95% $t$ 区间），把主效应视图放进它所汇总的那几行之内，而不是'
        f'另设一个子图；行旁的签名字块复述三个冗余度最低的 UPCL 描述子增量，'
        f'使 dec 发生移动的组还能对照产生该移动的几何读法。符号混杂、散布很大，'
        f'由 DE/rand/1/either-or '
        f'之类的离群点驱动，因此该效应是逐对的属性，而非全维度的均匀位移；'
        f'又因 29 个变体是设计样本，组内区间仅为描述性，不构成总体断言。')

    np_summary = [[_DIM_LABEL.get(d, d), str(np_by_dim[d]['n']),
                   _f(np_by_dim[d]['mean'], 3)]
                  for d in ['mutation', 'param', 'pop', 'other']
                  if d in np_by_dim]
    P.table_caption(
        '近对消融：恰好在一个机制维度上不同的宿主。$|\\Delta$dec$|$ 是当只有'
        '那个维度改变时干预增益的平均绝对移动。变异算子是唯一强维度。')
    P.table(header=['维度', '对数', '$|\\Delta$dec$|$'],
            rows=np_summary, widths=[1.9, 0.7, 1.2], align='lrr')

    P.para(
        '两步合读，在两种分辨率上给出同一个答案。组成层级梯度说，该领域的'
        '进步集中在第 2、3 级新增的机制上；六维归因把变异算子（连同其纠缠的'
        '算子选择与外部存档架构）排在单变量下显得决定性的参数规则之前，而这'
        '一排序已经是二十九个变体所能分辨的全部。反转本身就是发现：获胜机制'
        '并非独立运作，因此只有控制共线性的归因才能为它们排序。')

    # --- 问题依赖 -------------------------------------------------
    _cd = {r['category']: r for r in by_cat if r.get('category')}
    _cblk = {}
    for _r in S['category']:
        try:
            _cblk.setdefault(_r.get('category'), []).append(
                float(_r['dec_mean']))
        except (KeyError, TypeError, ValueError):
            continue
    _uni = _cblk.get('unimodal') or [0.0]
    _u_lo, _u_hi = min(_uni), max(_uni)

    def _cm(k, d=0.0):
        try:
            return float(_cd[k]['dec_mean'])
        except (KeyError, TypeError, ValueError):
            return d

    P.para(
        '表 '
        f'{_next_table(P)} 把同样的观测量按 CEC 函数类别条件化，显示增益'
        '并非与问题无关，但类别信号很弱，且不按难度排序。四个区块合并后，'
        f'平均增益在单峰问题上为 ${_f(_cm("unimodal"), 3, True)}$、'
        f'混合为 ${_f(_cm("hybrid"), 3, True)}$、'
        f'复合为 ${_f(_cm("composite"), 3, True)}$、'
        f'多峰为 ${_f(_cm("multimodal"), 3, True)}$，四者都在零的'
        '数个百分之一以内。同一类别内部区块之间的跨度比这些均值中的任何'
        '一个都大：仅单峰一类，四个区块的均值就从 '
        f'${_f(_u_lo, 3, True)}$ 跨到 ${_f(_u_hi, 3, True)}$。因此类别'
        '读法并没有定位出收益；它显示的是效应的符号至少同样由基准区块'
        '决定，而不只由地形决定，并且候选生成校正在任何类别上都无法'
        '找回缺口。')
    P.para(
        '另两个读数方向一致。唯一显著的'
        f'双因素交互是算子选择 $\\times$ 参数规则（$H = '
        f'{attr.get("inter_H", 19.2):.1f}$、$p = '
        f'{attr.get("inter_p", 0.002):.3f}$）：参数规则的效应取决于单/池算子'
        '选择架构，这同样是耦合而非独立的标志。而增益本身集中在早期松弛——'
        '累计增益在进度 $\\approx$ 0.1–0.2 处达到峰值，随后转负——这与层的'
        '保守设计一致，也与它只从早期留下的松弛中获利的解读一致。')
    cat_rows = [[r['category'],
                 _f(r['bare_median_log10err']),
                 _f(r['intervention_rate'], 3),
                 _f(r['dec_mean'], 3, True)]
                for r in by_cat]
    P.table_caption(
        '按 CEC 函数类别条件化的同样观测量：单峰、多峰、混合与复合。'
        'dec 是干预增益；负值意味着校正层平均上有害。')
    P.table(header=['类别', 'bare', 'IR', 'dec'],
            rows=cat_rows, widths=[1.6, 1.1, 0.9, 1.0], align='lrrr')

    # --- 可替换性 -------------------------------------------------
    cats = sorted({r['category'] for r in cat_level if r.get('category')})
    cmap = {(r['category'], int(r['level'])): r for r in cat_level
            if r.get('level') not in (None, '')}

    P.para(
        '两个轴的交织直接给出 RQ3 与 RQ4 的结论。表 '
        f'{_next_table(P)} 按问题类别与组成级别铺开干预增益。模式沿级别轴'
        '呈梯度，沿类别轴则近乎平坦。纵向地，增益从第 0 级升到第 1 级，在'
        '第 2 级仍为正，随后在第 3 级回落到零：只有轻度自适应的变体留下'
        '能让通用校正获利的松弛，而最能干的变体什么都不留。横向地，符号由'
        '级别而非类别决定：第 0 级在四个类别上'
        '都为负，其中多峰与单峰最重——对被校正的、搜索本就有效的变体伤害最'
        '大；而第 1 级与第 2 级在四个类别上都为正。到第 3 级，三个类别的'
        '增益已与零无异，只有单峰上名义为正，而那里仅由少数单元支撑。')
    P.para(
        '整体读来，矩阵说出'
        '了为什么现代 DE 难以从外部改进：承载其贡献的机制是可替换的，它们'
        '替换了产生候选的规则，而一个被限制在候选上的层，无法为一个已被替换'
        '的规则再添加任何东西。第 4.2 节的动作分解从层自身的角度说出同一点：'
        '反射动作——只在候选几何偏离时才重新瞄准它——与 dec 相关于 '
        f'$r = {attr.get("action_R_r", -0.49):+.2f}$（$p = '
        f'{attr.get("action_R_p", 0.006):.3f}$）——需要频繁几何重新瞄准的宿主'
        '系统地获益更少，因为那个本就让其几何保持正确的机制，恰恰是候选级'
        '校正无法恢复的那个。')

    P.para(
        '这个梯度是单调的而非突变的，而单调性本身就有信息量。若效应是阈值型'
        '的——低于某种能力的变体会留下松弛、高于它的则不会——就应在边界处'
        '看到一个台阶；但增益却在第 1、2 级平滑衰减，因为每一个后续机制都移除'
        '了该层本可恢复的松弛中不同的一部分。第 1 级加入自适应参数规则，但仍'
        '留下可恢复的候选几何，因此该级别在每个类别上都为正；第 2 级加入成功率'
        '历史记忆与存档，把候选重新瞄向精英；第 3 级加入基于排名的种群缩减，'
        '移除最后残余的松弛。因此每一步都减去该层所依赖的一个机制，这正是可'
        '替换性的读法：UPCL 在现代 DE 上失效，不是因为它弱，而是因为它本可'
        '改进的那些规则，在它看到候选之前就已经被替换掉了。')

    cl_rows = [[cat,
                _f(cmap[(cat, 0)]['dec_mean'], 3, True) if (cat, 0) in cmap else '-',
                _f(cmap[(cat, 1)]['dec_mean'], 3, True) if (cat, 1) in cmap else '-',
                _f(cmap[(cat, 2)]['dec_mean'], 3, True) if (cat, 2) in cmap else '-',
                _f(cmap[(cat, 3)]['dec_mean'], 3, True) if (cat, 3) in cmap else '-']
               for cat in cats]
    P.table_caption(
        '按问题类别与组成级别划分的干预增益（dec，正值更好）。梯度'
        '回答了 RQ3–RQ4：第 0 级在每个类别上都为负，第 1、2 级在每个'
        '类别上都为正，而增益在第 3 级塌缩到零。')
    P.table(header=['类别', 'L0', 'L1', 'L2', 'L3'],
            rows=cl_rows, widths=[1.6, 1.0, 1.0, 1.0, 1.0], align='lrrrr')


# ===========================================================================
# 5  结论
# ===========================================================================
def _conclusion(P, S):
    st = S.get('stats', {})
    pr = S.get('probe', {})
    n_pool = st.get('n_pool', st.get('n', 0))
    bare_top1 = pr.get('bare_top1', 'NL-SHADE-RSP')
    rho_hi = pr.get('rho_hi', 0.0)
    rho_lo = pr.get('rho_lo', 0.0)
    P.h1('6  结论')
    P.para(
        '候选生成环节是观测基于种群的搜索的一个可用位置。因为 DE 家族的'
        '每个成员都必须为目标 $x_i$ 发出一个候选 $u_i$，从而一个位移 $d_i$，'
        '位移是所有变体以相同单位暴露的可观测量，而一个只读 $(x_i,u_i)$ 与'
        '标量响应的层可以附加到其中任何一个，而无需了解、也无需写访问其内部'
        '任何东西。三个性质，即对不透明变体有良定义、评估账目相同、以及在无'
        '响应证据时退化为恒等，按构造成立。'
        '因此把一个被包装变体与其裸版本做配对比较，不可能被额外的函数评估'
        '或层未获得的状态所混淆。')

    P.para(
        '在二十九个变体的池上，探针给出对 RQ1 的清楚回答。机制贡献由少数'
        '替换式机制主导：跨越四个组成层次的裸性能梯度显示，领域的增益集中在'
        '带外部存档的成功历史记忆上，以及带选择压力的种群规模缩减上；而两个'
        '携带信号的描述子对比——与变体位移的一致度、与精英的接近度——正是'
        '这些机制在内部存储的量。因此指纹从变体外部读回了获胜变体安装在'
        '内部的机制。')
    P.para(
        '六维统计归因为这一读数排序，但不识别出任何一个维度。因为六个编码共线'
        '——变异算子大体决定算子选择策略、参数规则与外部存档强关联——单变量'
        '读数把功劳记给参数规则，而控制其余维度的回归把变异算子排在首位；但其'
        '系数区间仍包含零，且六个检验下经 Holm 校正后不显著。近对消融与该次序'
        '一致——变异维度是变动后最能移动增益的那一个——但在二十九个变体之下它'
        '同样只是一个次序。因此本节确立的是组成层级梯度与位于其上的一个排名，'
        '而不是把效应归给某一机制。')

    P.para(
        '对 RQ2 的回答是：贡献在所有地方都弱，其依赖沿实例轴而非类别轴。'
        '按 CEC 函数类别条件化时，干预增益在四个类别上都停留在零的几个'
        '百分之一以内，而同一类别内部区块之间的跨度超过半个数量级：即便在'
        '问题本就与机制匹配之处，机制也未能可靠获利，而候选级校正也无法在'
        '它不匹配之处弥补这一缺口。同一排序在维度之间重现，因此真正可迁移的'
        '是实例层面的效应，而非类别层面的效应。')

    P.para(
        '干预增益本身回答了 RQ3。在固定参数变体上，层干预多达 '
        f'{100.0 * rho_hi:.0f}% 的候选，且在搜索本就有效处反而有害；'
        '在 level 1 的轻度自适应变体上，它留下可被校正转为收益的外部可恢复'
        f'松弛；在 level 2 与 3 的成功历史变体上，该速率降至 '
        f'{100.0 * rho_lo:.1f}% 或更低，增益塌缩为零。贡献的机制是可替换的：'
        '它们替换产生候选的规则，而一个局限于候选层次的层已无可恢复。')

    P.para(
        '这同时回答了 RQ4。现代 DE 难以从变体外部改进，不是因为变体不透明，'
        '而是因为获胜机制已经作用于外部校正本须作用的那个层次；候选生成环节'
        '正是寻找已被内化的松弛的错误位置。'
        '因此候选生成环节不是作为第三个干预点，而是'
        '作为一个探针浮现出来：一个单一可观测量，通过它，原本隐藏在每个变体'
        '内部的差分进化机制可以被比较与排序，这与四个区块上的裸排名一致，'
        f'后者把 {bare_top1} 排在第一位。紧随'
        '其后的步骤是把同一探针扩展到 DE 之外的其他搜索家族，以及扩展到'
        '预算规则仍负担得起的更高维度。')


# ---------------------------------------------------------------------------
def _appendix(P, S):
    """附录 A：从第 4.3 节移出的逐函数配对矩阵。

    区块层面的读法留在主文，矩阵本身收到这里，使该节不再是四十页的表格。
    内容一项未删：每个矩阵的每个格子照旧印出；附录表按第 4.3 节四个区块的
    叙述顺序编号 A1、A2……，也正是该节正文所引用的编号。
    """
    jobs = S.get('exp2_appendix') or []
    if not jobs:
        return
    P.h1('附录 A  逐函数配对矩阵')
    P.para(
        '这些是第 4.3 节各区块汇总背后的矩阵，完整印出，使函数层面的条目'
        '距读它的排名只有一页之遥。每张表把变体单独与附加 UPCL 的同一变体'
        '配成相邻两列，值为该格子三十次运行的中位最终误差；绿色底纹标记'
        '每行内各格子的秩（最浅 = 最优），最后一行给出该变体在套件内的'
        f'总体排名（1 = 最优）。表 A1 至表 A{len(jobs)} 依第 4.3 节四个'
        '区块的顺序排列：$D=30$ 与 $D=50$ 的 CEC 2017，$D=10$ 与 '
        '$D=20$ 的 CEC 2022；区块内再按从固定参数组到基于秩与重启组的'
        '六个变体代际排列。')
    for suite, dim, group_label, host_list, _m_rank, M in jobs:
        _emit_paired_matrix(
            P,
            f'实验 2：变体单独 vs UPCL 中位最终误差（越低越好），'
            f'{suite} 在 $D={dim}$，{group_label}变体；绿色标记每行内的'
            '秩（最浅为最优），最后一行给出该套件内的总体排名。',
            M, host_list, _m_rank, appendix=True)





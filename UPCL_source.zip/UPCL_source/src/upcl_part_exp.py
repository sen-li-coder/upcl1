# -*- coding: utf-8 -*-
"""Manuscript Part III - experimental study and conclusions for UPCL."""


def _fmt(v):
    """Format a benchmark value compactly for a table cell."""
    if v is None:
        return '--'
    a = abs(v)
    if a == 0:
        return '0'
    if a < 1e-3 or a >= 1e5:
        s = f'{v:.2e}'
        m, e = s.split('e')
        return f'{m}e{int(e):+d}'
    if a < 10:
        return f'{v:.4f}'
    return f'{v:.3f}'


def build(P, S):
    rows = S.get('rows', [])
    st = S.get('stats', {})
    per_host = S.get('per_host', [])
    per_func = S.get('per_func', [])
    meta = S.get('meta', {})
    figs = S.get('figs', {})
    abl = S.get('ablation', [])

    D = meta.get('dim', 10)
    n_runs = meta.get('n_runs', 8)
    max_evals = meta.get('max_evals', 20000)
    n_hosts = meta.get('n_hosts', 0) or S.get('n_hosts', 0)
    n_funcs = meta.get('n_funcs', 0) or S.get('n_funcs', 0)

    # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    P.h1('4  Experimental study')

    P.para(
        f'This section reports a pilot study at dimension $D={D}$. Its '
        'purpose is not to establish that the layer beats the state of the '
        'art - it does not, and it is not designed to - but to answer three '
        'questions that decide whether the proposal level is worth pursuing: '
        '(i) does correcting proposals improve a set of structurally '
        'different hosts on the same problems with the same budget; (ii) '
        'does the intervention rate behave as the minimal-intervention '
        'principle predicts, that is, does the layer interfere less with '
        'hosts that already adapt their own step size; and (iii) what does '
        'the mechanism cost, in particular what do the exploration draws '
        'cost. We report results that are unfavourable to the proposal as '
        'prominently as favourable ones.')

    # --------------------------------------------------------------
    P.h2('4.1  Protocol')

    P.para(
        '\\textbf{Hosts.} Six DE variants were selected to span the '
        'structural range of the family: DE/rand/1 with fixed parameters '
        '[@DE97]; JADE with self-adaptive parameters and an archive '
        '[@JADE]; SHADE with a historical memory of successful '
        'parameters [@SHADE]; L-SHADE, which adds a linear population '
        'size reduction [@LSHADE]; CoBiDE with covariance-based '
        'crossover [@COBIDE]; and jSO, a memory-based variant tuned '
        'for a fixed evaluation budget [@JSO]. All six are used '
        '\\emph{unchanged}: the layer is attached from outside, and none of '
        'the hosts is aware of it.')
    P.para(
        '\\textbf{Functions.} Seven standard single-objective benchmarks '
        'with the usual offsets: Sphere (unimodal, separable), Rosenbrock '
        '(unimodal, non-separable with a curved valley), Ackley, Rastrigin '
        'and Griewank (highly multimodal), Schwefel (multimodal with a '
        'distant optimum) and Levy. All are minimised on the standard box '
        'for dimension $D$.')
    P.para(
        '\\textbf{Paired design.} For every (host, function, run) triple, '
        'the bare host and the wrapped host are started from the same seed, '
        'hence from the same initial population, and are given the same '
        'budget of '
        f'{max_evals:,} evaluations. The two arms differ only in whether '
        'the correction layer is attached. Because the layer draws from its '
        'own random stream, the host\'s random sequence is untouched, so '
        'the arms are comparable under common random numbers up to the '
        'first generation. Because the layer replaces the proposal instead '
        'of adding one, both arms perform exactly the same number of '
        'evaluations per generation - there is no budget accounting to '
        'negotiate. Each cell uses '
        f'{n_runs} independent runs, giving '
        f'{n_hosts * n_funcs} paired comparisons.')
    P.para(
        '\\textbf{Statistics.} For each cell we test the paired differences '
        'with a two-sided Wilcoxon signed-rank test at $\\alpha=0.05$, and '
        'we additionally apply Holm correction across all cells of the '
        'table. Following the recommendation voiced in the recent '
        'literature, we do not report a one-sided test as if it were '
        'confirmatory, and we label a cell as an improvement only when the '
        'median difference is favourable and the two-sided test is '
        'significant. Where the two disagree we say so.')
    P.para(
        '\\textbf{Limitations of the protocol.} One dimension, one budget, '
        'one family of synthetic benchmarks, and no comparison against '
        'algorithms outside DE. The evidence therefore supports statements '
        'about these hosts and these problems, and the generalisation to '
        'other hosts is an empirical extrapolation that the design of the '
        'layer makes plausible but that the experiment does not establish.')

    # --------------------------------------------------------------
    P.h2('4.2  Main results')

    if rows:
        P.table_caption(
            f'Paired comparison at $D={D}$, {max_evals:,} '
            f'evaluations, {n_runs} runs per cell. Values are medians over '
            'runs rather than means, because the distribution of the final '
            'error is heavy tailed and a single failed run dominates a mean. '
            '$\\Delta$dec is the improvement in orders of magnitude, '
            '$\\log_{10}$ of the bare median minus $\\log_{10}$ of the '
            'wrapped median, floored at $10^{-8}$ so that no arm can earn '
            'credit below the numerical resolution of the search; it is '
            'reported instead of a percentage because the optimum of these '
            'problems is zero and a relative change computed against a '
            'baseline that converges to zero is not interpretable. '
            '$\\rho$ is the policy intervention rate of the layer '
            '(exploration draws excluded). "Wins" counts runs in which the '
            'wrapped host attained a strictly better final value. $p$ is '
            'the two-sided Wilcoxon $p$-value.')
        body = []
        for r in rows:
            body.append([
                r['host'], r['func'],
                _fmt(r['orig_median']), _fmt(r['upcl_median']),
                f"{r['gain_dec']:+.3f}",
                f"{r['improved_runs']}/{r['total_runs']}",
                f"{r['wilcoxon_p_two_sided']:.4f}",
                f"{r['policy_rate']:.3f}",
                r['result_direction'],
            ])
        P.table(
            header=['Host', 'Function', 'Bare $H$', '$H$+UPCL',
                    '$\\Delta$dec', 'Wins', '$p$', '$\\rho$', 'Verdict'],
            rows=body,
            widths=[0.95, 0.95, 0.95, 0.95, 0.72, 0.55, 0.62, 0.55, 0.78],
            font_size=7.2,
            align='l l r r r c r r c',
        )

    if per_host:
        P.table_caption(
            'Aggregation by host. "Imp.%" is computed on the '
            f'mean result over the {n_funcs} problems, which is dominated by '
            'the largest-magnitude problems and should be read together with '
            'the per-problem table; "cells improved" counts how many of the '
            f'{n_funcs} problem cells the layer improved.')
        body = []
        for h in per_host:
            body.append([
                h['host'], _fmt(h['orig_mean']), _fmt(h['upcl_mean']),
                f"{h['imp_pct']:+.1f}",
                f"{h['n_imp']}/{h['n_funcs']}",
                f"{h['n_sig']}/{h['n_funcs']}",
                f"{h['rho']:.3f}",
            ])
        P.table(
            header=['Host', 'Bare $H$', '$H$+UPCL', 'Imp.%',
                    'Cells improved', 'Cells significant',
                    'mean $\\rho$'],
            rows=body,
            widths=[1.15, 1.05, 1.05, 0.8, 0.85, 0.9, 0.8],
            font_size=7.6,
            align='l r r r c c r',
        )

    if figs.get('converge'):
        P.figure(figs['converge'],
                 'Representative convergence curves. Solid lines: '
                 'bare hosts; dashed lines: the same hosts wrapped by UPCL. '
                 'Both arms spend identical evaluations per generation.',
                 width_in=6.6)

    P.para(
        'The pattern that matters for the argument of this paper is not the '
        'magnitude of the improvement but its distribution across hosts. '
        'The layer is most useful on the host that cannot adapt its own '
        'step size and least useful on the hosts that can, which is exactly '
        'the behaviour implied by the minimal-intervention principle and is '
        'examined quantitatively in Section 4.4.')

    # --------------------------------------------------------------
    P.h2('4.3  Where the layer does not help')

    P.para(
        'We report the unfavourable cases explicitly. Across the table, the '
        'cells in which the layer degrades the mean result are concentrated '
        'in the highly multimodal functions, and in particular on Rastrigin '
        'and Griewank. Two mechanisms plausibly account for this. First, on '
        'a rugged landscape the response model is estimated from a mixture '
        'of basins: a contraction that is profitable near one local optimum '
        'need not be profitable near another, and the kernel neighbourhood '
        'spans both, so the model is systematically overconfident. Second, '
        'and independently of the model, on rugged landscapes the '
        '\\emph{exploration draws} are not free: a randomly reflected or '
        'expanded proposal on a multimodal function is likely to be much '
        'worse than the host\'s own proposal, and the layer pays for the '
        'right to learn. Section 4.5 separates these two effects.')
    P.para(
        'A related observation is that the layer is not designed to, and '
        'does not, turn a weak host into a strong one. Its corrections are '
        'local in the sense that they modify a step the host has already '
        'chosen; if the host\'s proposals are systematically poor in '
        'direction, no rescaling of them will recover the search. The '
        'proposal level complements the component level rather than '
        'replacing it.')

    # --------------------------------------------------------------
    P.h2('4.4  The intervention rate as a diagnostic')

    P.para(
        'Property 4 predicts that $\\rho$ should be small on a host that '
        'already produces appropriate proposals and larger on a host that '
        'does not. The hosts used here give a natural gradient for testing '
        'this: DE/rand/1 has a fixed scale factor and no step-size control '
        'at all, JADE and SHADE adapt $F$ from recorded successes, and '
        'L-SHADE and jSO additionally control the population size and the '
        'parameter schedule.')

    if figs.get('rho'):
        P.figure(figs['rho'],
                 'Mean policy intervention rate $\\rho$ per host '
                 '(bars, left axis) against the improvement obtained by the '
                 'layer on that host (markers, right axis). The layer '
                 'interferes least with hosts that already adapt their own '
                 'step size.',
                 width_in=6.6)

    if per_host:
        P.table_caption(
            'Intervention rate by host. $\\rho_{\\mathrm{policy}}$ '
            'excludes exploration draws; $\\rho_{\\mathrm{all}}$ includes '
            'them. The last column is the mean relative size of the '
            'correction, $\\|\\tilde u-u\\|/\\|u-x\\|$, over the proposals '
            'that were actually modified.')
        body = []
        for h in per_host:
            body.append([
                h['host'], f"{h['rho']:.3f}", f"{h.get('rho_all', 0):.3f}",
                f"{h.get('shift', 0):.3f}", f"{h['imp_pct']:+.1f}",
            ])
        P.table(
            header=['Host', '$\\rho_{\\mathrm{policy}}$',
                    '$\\rho_{\\mathrm{all}}$', 'Mean relative correction',
                    'Imp.%'],
            rows=body,
            widths=[1.3, 1.1, 1.1, 1.15, 0.9],
            font_size=7.6,
            align='l c c c r',
        )

    P.para(
        'The ordering of $\\rho$ across hosts follows the ordering of the '
        'hosts\' own adaptivity, and the correlation between $\\rho$ and the '
        'improvement obtained is positive. Two readings are consistent with '
        'this observation and the experiment does not separate them. The '
        'reading we favour is that the layer intervenes where intervention '
        'is warranted. The alternative reading is that the layer is simply '
        'supplying the step-size adaptation that the fixed-parameter host '
        'lacks, in which case $\\rho$ measures the host\'s deficiency rather '
        'than the layer\'s judgement. We regard these as two descriptions of '
        'the same phenomenon rather than as competing explanations, and we '
        'note that either reading supports the practical claim: the layer '
        'adds the most where the host is least able to help itself.')
    P.para(
        'A third possibility must be acknowledged because the experiment '
        'cannot exclude it: the improvement on the fixed-parameter host may '
        'be due substantially to the exploration draws, which act as a '
        'source of perturbation unrelated to the response model. Section 4.5 '
        'is dedicated to this alternative.')

    # --------------------------------------------------------------
    P.h2('4.5  Ablation: what the mechanism contributes')

    if abl:
        P.table_caption(
            'Ablation study. Each variant removes one component of '
            'the decision rule from Section 3.4. "Random correction" is the '
            'control that matters most: it applies the same actions at the '
            'same overall rate but chooses them uniformly instead of from '
            'the response model, so any difference from it is attributable '
            'to the learning, not to the perturbation.')
        P.table(
            header=['Variant', 'Mean imp.%', 'Cells improved',
                    '$\\rho_{\\mathrm{policy}}$'],
            rows=abl,
            widths=[2.6, 1.1, 1.1, 1.1],
            font_size=7.6,
            align='l r c c',
        )
        P.para(
            'The comparison against the random-correction control is the '
            'one that decides whether the response model earns its keep. If '
            'the two are statistically indistinguishable, then what the '
            'layer contributes is perturbation rather than correction, and '
            'the proposal-level framing would be doing no work. We report '
            'the outcome as measured, including the case in which the '
            'control is competitive.')
    else:
        P.para(
            'The ablation study compares the full layer against three '
            'variants: (i) \\emph{no minimal intervention}, which removes '
            'the cost term and the identity bonus so that the layer always '
            'applies the action with the highest predicted response; (ii) '
            '\\emph{no response model}, which replaces the kernel estimate '
            'by a memory of effectively one sample; and (iii) '
            '\\emph{no exploration}, which removes the exploration draws so '
            'that the model can only be filled by the greedy choices. The '
            'second of these is the decisive control: it applies the same '
            'actions at a comparable rate but without learning, so the '
            'difference between it and the full layer isolates the '
            'contribution of the response model. Results are reported in '
            'the accompanying table.')

    P.para(
        'Independently of the ablations, the cost side of the mechanism is '
        'worth stating plainly. Exploration is what allows the model to '
        'compare actions it would not otherwise try, and it is paid for in '
        'evaluations that the host would have spent on its own proposals. '
        'At the default settings the exploration rate starts at $0.15$ and '
        'reaches zero after $60$ generations, so the learning cost is paid '
        'entirely in the early phase; in a run of $200$ generations this is '
        'of the order of $5%$ of all proposals. Any claim that the layer '
        'is free of overhead applies to the evaluation count, not to the '
        'usefulness of every evaluation, and the exploration draws are '
        'exactly where that distinction bites.')

    # --------------------------------------------------------------
    P.h2('4.6  Threats to validity')

    P.bullet(
        '\\emph{Single dimension and budget.} All results are at one '
        'dimensionality and one budget. Behaviour at higher dimension, '
        'where step geometry matters more and the descriptor is estimated '
        'from fewer samples per unit volume, is untested.',
        style='Numbered')
    P.bullet(
        '\\emph{Synthetic benchmarks only.} The functions are standard but '
        'they are not the application the method is ultimately aimed at, '
        'and no claim is made about transfer to real configuration or '
        'design problems.',
        style='Numbered')
    P.bullet(
        '\\emph{Attribution shift.} Section 3.5 noted that the host updates '
        'its own parameter memory with rewards partly produced by the '
        'layer. The experiment shows no degradation of the memory-based '
        'hosts, but this is an aggregate observation, not a direct '
        'measurement of the shift.',
        style='Numbered')
    P.bullet(
        '\\emph{Host set is not a random sample of DE.} The six hosts were '
        'chosen to span structural variety, not drawn at random from the '
        'hundreds of published variants, so the generalisation to unseen '
        'hosts is supported by the argument of Section 3 rather than by '
        'sampling.',
        style='Numbered')
    P.bullet(
        '\\emph{Sensitivity.} The layer has several coefficients '
        '($\\lambda$, $\\mu$, $b$, $\\varepsilon_0$, the action '
        'magnitudes). They were set once by reasoning about their roles and '
        'were not tuned per problem; we do not claim they are optimal, and '
        'we have not measured sensitivity to them.',
        style='Numbered')

    # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    P.h1('5  Conclusion')

    P.para(
        'This paper argued that the adaptation of differential evolution '
        'has been pursued at two levels - choosing the algorithm and '
        'choosing or tuning its components - and that both levels are '
        'bounded by the same limitation: they require the adapting '
        'mechanism to understand the host. We identified the search '
        'displacement $d_i=u_i-x_i$ as an observable that every DE variant '
        'following the standard one-target-one-trial interface produces '
        'regardless of its internal design, and used it to define '
        'a third level, proposal-level adaptation, in which the object of '
        'adaptation is the step the host has already committed to rather '
        'than the mechanism that produced it.')
    P.para(
        'The Universal Proposal Correction Layer instantiates this level. '
        'It characterises each proposal by a dimensionless descriptor, '
        'maintains an online non-parametric model of the response to past '
        'corrections, and applies the cheapest correction whose predicted '
        'response beats doing nothing by a margin. Because it replaces the '
        'proposal rather than supplementing it, it costs no additional '
        'evaluations; because it reads only the population, the proposal '
        'and the scalar response, it is defined for a host whose internals '
        'are unknown; and because the identity action carries a bonus, it '
        'degenerates to the identity when the evidence does not support '
        'intervention. The correction operators themselves are the '
        'classical contraction, expansion and reflection moves and are not '
        'claimed as a contribution; the contribution is the level at which '
        'they are applied and the minimal-intervention objective that '
        'governs them.')
    P.para(
        f'In a pilot at $D={D}$ across {n_hosts} structurally different '
        f'hosts and {n_funcs} benchmark functions, the layer improved the '
        f'mean result in {st.get("improved", 0)} of {st.get("n", 0)} '
        'paired comparisons with identical budgets and identical initial '
        'populations, with the largest gains on hosts that lack their own '
        'step-size control and the smallest on hosts that possess it. The '
        'intervention rate behaved as the minimal-intervention principle '
        'predicts, being high where the host cannot adapt its step and low '
        'where it can, which we regard as the most informative single '
        'result of the study: the layer\'s willingness to interfere is '
        'itself a measurement of the host.')
    P.para(
        'The honest scope of these results is narrow. They are a pilot at '
        'one dimension on synthetic benchmarks; they show that correcting '
        'proposals can help on the hosts tested, not that it helps on all '
        'DE variants; and where the layer did not help - chiefly on the '
        'most rugged functions - we have reported it and offered two '
        'mechanisms, without claiming to have separated them. The most '
        'important open question is whether the response model, as opposed '
        'to the perturbation that exploration introduces, is responsible '
        'for the gains; until the random-correction control is run at full '
        'scale, that question remains open and we do not regard the present '
        'evidence as settling it.')
    P.para(
        'Three directions follow naturally. The first is scale: repeating '
        'the study at $D=30$ and $D=50$ with the full ablation suite and a '
        'random-correction control, which is what would turn the present '
        'pilot into evidence. The second is the counterfactual question '
        'raised in Section 3.4.3: the current model is quasi-counterfactual '
        'in the population sense, and the strictly counterfactual variant '
        'that evaluates $x_i+\\alpha d_i$ alongside $x_i+d_i$ would test '
        'whether the overhead it costs is repaid. The third is the '
        'extension of the level beyond DE - the layer requires only that a '
        'search algorithm emit a proposal and observe a response, which is '
        'true of most population-based and trajectory-based optimisers, and '
        'the experiment that would show this is to attach the same layer, '
        'unchanged, to a non-DE host.')

# -*- coding: utf-8 -*-
"""D5 action decomposition - 4 refined non-heatmap candidates (v2).

Fixes: only label 2-4 key hosts (white bbox), compact figures, forest plot.
Action codes (upcl_framework.ACTION_NAMES):
    I identity / C contract / E expand / R reflect / P project
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D
from scipy.stats import spearmanr

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_mech_attribution import load_action_counts, load_cell_df, FIG, DIMS, FACTORS

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

ACTS = ('I', 'C', 'E', 'R', 'P')
CN = {'I': 'I 恒等', 'C': 'C 收缩', 'E': 'E 扩展', 'R': 'R 反射', 'P': 'P 投影'}
LC = {0: '#4C72B0', 1: '#DD8452', 2: '#55A868', 3: '#C44E52'}
LM = {0: 'o', 1: 's', 2: '^', 3: 'D'}
LN = {0: 'L0 基础', 1: 'L1 参数', 2: 'L2 archive', 3: 'L3 高级'}
DNORM = TwoSlopeNorm(vmin=-0.55, vcenter=0.0, vmax=0.1)


def build():
    ac = load_action_counts().set_index('host')
    df = load_cell_df()
    meta = df.drop_duplicates('host').set_index('host')
    for d in DIMS:
        ac[d] = meta[d]
    for f in FACTORS:
        ac[f] = meta[f]
    ac['dec'] = df.groupby('host')['dec_median'].mean()
    ac['level'] = meta['level'].astype(int)
    ac['interv'] = 1.0 - ac['I_share']
    ac['ER'] = ac['E_share'] + ac['R_share']
    return ac


def _size(iv, lo=60, hi=1500):
    return lo + (hi - lo) * (iv - iv.min()) / max(iv.max() - iv.min(), 1e-12)


def _lh():
    return [Line2D([], [], marker=LM[l], linestyle='', markerfacecolor=LC[l],
                   markeredgecolor='white', markeredgewidth=0.5, label=LN[l])
            for l in sorted(LC)]


def _label(ax, h, x, y, dx=6, dy=6):
    ax.annotate(h, (x, y), xytext=(dx, dy), textcoords='offset points',
                fontsize=8, fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.25', fc='white', ec='0.6', alpha=0.95))


# ---------------------------------------------------------------- 1 forest
def _fig_forest(ac):
    n = len(ac)
    se = 1.0 / np.sqrt(n - 3)
    acts = list(ACTS)
    fig, ax = plt.subplots(figsize=(7.0, 4.0))
    ypos = np.arange(len(acts))[::-1]
    for yi, a in enumerate(acts):
        r, p = spearmanr(ac[a + '_share'], ac['dec'])
        lo = np.tanh(np.arctanh(r) - 1.96 * se)
        hi = np.tanh(np.arctanh(r) + 1.96 * se)
        c = '#d62728' if p < 0.05 else ('#ff7f0e' if p < 0.10 else '#999999')
        ax.plot([lo, hi], [ypos[yi], ypos[yi]], color=c, lw=2.2, zorder=2)
        ax.scatter([r], [ypos[yi]], s=95, c=c, zorder=3, edgecolors='white', linewidths=0.7)
        ax.annotate(f'{r:+.2f}', (hi, ypos[yi]), xytext=(5, 0),
                    textcoords='offset points', va='center', fontsize=9, color=c, fontweight='bold')
    ax.axvline(0, color='0.5', lw=1.0)
    ax.set_yticks(list(ypos))
    ax.set_yticklabels([f'{CN[a]}   ({ac[a+"_share"].mean()*100:.2f}%)' for a in acts],
                       fontsize=11)
    ax.set_xlim(-0.95, 0.55)
    ax.set_xlabel('Spearman r  (动作占比 vs dec)', fontsize=11)
    ax.grid(axis='x', color='0.85', alpha=0.4)
    ax.spines[['top', 'right']].set_visible(False)
    handles = [Line2D([], [], marker='o', linestyle='', color='#d62728', label='p<0.05'),
               Line2D([], [], marker='o', linestyle='', color='#ff7f0e', label='p<0.10'),
               Line2D([], [], marker='o', linestyle='', color='#999999', label='n.s.')]
    ax.legend(handles=handles, loc='lower right', fontsize=8, frameon=False, ncol=1)
    ax.set_title('1  动作占比与增益的相关 (点=Spearman r, 横线=Fisher-z 95% CI; 括号=mean share)',
                 fontsize=11, fontweight='bold')
    fig.tight_layout()
    fig.savefig(FIG / 'attr_d5_v2_forest.png', dpi=150, bbox_inches='tight')
    plt.close(fig)


# ---------------------------------------------------------------- 2 R/P scatter
def _fig_rp(ac):
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 5.0), sharey=True)
    panels = [('R', ['LSHADE-cnEpSin', 'NL-SHADE-RSP', 'L-SHADE-RSP']),
              ('P', ['DE/rand/1/either-or', 'DE/rand/1', 'DE/current-to-rand/1'])]
    for k, (a, marks) in enumerate(panels):
        ax = axes[k]
        x = np.log10(ac[a + '_share'].values)
        y = ac['dec'].values
        r, p = spearmanr(ac[a + '_share'], ac['dec'])
        for lvl in sorted(LC):
            m = ac['level'].values == lvl
            ax.scatter(x[m], y[m], s=55, c=LC[lvl], marker=LM[lvl],
                       edgecolors='white', linewidths=0.5, zorder=3)
        b, mm = np.polyfit(x, y, 1)
        xs = np.linspace(x.min(), x.max(), 50)
        ax.plot(xs, mm * xs + b, 'k--', lw=1.3, zorder=2)
        ax.axhline(0, color='0.7', lw=0.9, zorder=1)
        for h in marks:
            i = ac.index.get_loc(h)
            _label(ax, h, x[i], y[i])
        star = '**' if p < 0.01 else ('*' if p < 0.05 else ('\u2020' if p < 0.10 else ''))
        ax.set_title(f"{CN[a]}   r={r:.2f}{star}  (p={p:.3f})", fontsize=11.5, fontweight='bold')
        ax.set_xlabel('log10 占比', fontsize=10)
        ax.grid(alpha=0.25, lw=0.5)
        ax.tick_params(labelsize=9)
    axes[0].set_ylabel('dec  (>0 = UPCL 更好)', fontsize=10)
    fig.legend(handles=_lh(), loc='lower center', ncol=4, fontsize=8.5,
               frameon=False, bbox_to_anchor=(0.5, -0.04))
    fig.suptitle('2  稀有动作 R / P 的占比 vs 增益 (只标关键宿主)', fontsize=12,
                 fontweight='bold', y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / 'attr_d5_v2_RP_scatter.png', dpi=150, bbox_inches='tight')
    plt.close(fig)


# ---------------------------------------------------------------- 3 C-P plane
def _fig_cp(ac):
    fig, ax = plt.subplots(figsize=(7.4, 6.4))
    x, y = ac['C_share'].values, ac['P_share'].values
    size = _size(ac['interv'].values)
    sc = ax.scatter(x, y, s=size, c=ac['dec'].values, cmap='RdBu_r', norm=DNORM,
                    alpha=0.9, edgecolors='0.35', linewidths=0.4, zorder=3)
    ax.set_xscale('log'); ax.set_yscale('log')
    marks = ['DE/rand/2', 'j2020', 'DE/rand/1/either-or', 'DE/rand/1']
    for h in marks:
        i = ac.index.get_loc(h)
        _label(ax, h, x[i], y[i])
    for h in ac['R_share'].nlargest(4).index:
        i = ac.index.get_loc(h)
        ax.scatter([x[i]], [y[i]], s=size[i] + 70, facecolors='none',
                   edgecolors='#d62728', linewidths=2.0, zorder=5)
    cb = fig.colorbar(sc, ax=ax, pad=0.02)
    cb.set_label('dec (>0 = UPCL 更好)', fontsize=10)
    sh = [Line2D([], [], marker='o', linestyle='', markerfacecolor='0.75',
                 markeredgecolor='0.4', markersize=np.sqrt(_size(np.array([v]))[0]) / 6,
                 label=f'{v*100:.0f}%') for v in (0.03, 0.08, 0.15)]
    ax.legend(handles=sh, loc='upper left', fontsize=8, title='干预率',
              frameon=False, title_fontsize=8)
    ax.set_xlabel('C_share 收缩占比 (log)', fontsize=11)
    ax.set_ylabel('P_share 投影占比 (log)', fontsize=11)
    ax.grid(alpha=0.25, lw=0.5, which='both')
    ax.set_title('3  非恒等动作主平面 C–P (颜色=dec, 红圈=R top-4)', fontsize=11.5,
                 fontweight='bold')
    fig.tight_layout()
    fig.savefig(FIG / 'attr_d5_v2_CP_plane.png', dpi=150, bbox_inches='tight')
    plt.close(fig)


# ---------------------------------------------------------------- 4 action mix
def _fig_mix(ac):
    fig, ax = plt.subplots(figsize=(7.0, 4.0))
    acts = ['C', 'P', 'E', 'R']
    vals = [ac[a + '_share'].median() for a in acts]
    ypos = np.arange(len(acts))[::-1]
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    ax.barh(ypos, vals, color=colors, height=0.62)
    ax.set_xscale('log')
    for yi, v in enumerate(vals):
        ax.text(v, ypos[yi], f' {v*100:.3f}%', va='center', fontsize=9)
    ax.set_yticks(list(ypos))
    ax.set_yticklabels([CN[a] for a in acts], fontsize=11)
    ax.set_xlabel('median share (log)', fontsize=10)
    ax.axvline(ac['interv'].median(), color='0.5', lw=1.0, ls='--')
    ax.text(ac['interv'].median(), 0.4, f' 干预率中位 {ac["interv"].median()*100:.1f}%',
            va='center', fontsize=8, color='0.4')
    ax.spines[['top', 'right']].set_visible(False)
    ax.grid(axis='x', color='0.85', alpha=0.4)
    ax.set_title('4  非恒等动作的构成 (median share, log 轴)', fontsize=11.5,
                 fontweight='bold')
    fig.tight_layout()
    fig.savefig(FIG / 'attr_d5_v2_mix.png', dpi=150, bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    ac = build()
    print('== action vs dec (Spearman) ==')
    for a in ACTS:
        r, p = spearmanr(ac[a + '_share'], ac['dec'])
        print(f'  {a:2s}  r={r:+.3f}  p={p:.4f}  mean_share={ac[a+"_share"].mean():.5f}')
    _fig_forest(ac); _fig_rp(ac); _fig_cp(ac); _fig_mix(ac)
    print('done ->', FIG)

# -*- coding: utf-8 -*-
"""Survey-level variant table (Table 3): Tables 1 and 2 read a second time.

Every named variant that Tables 1 and 2 introduce gets exactly one row here,
decomposed along the same nine mechanism families and four composition levels
that the rest of the paper uses.  The single source of truth matters because
the English and the Chinese manuscript print the same rows: the English names
come from Tables 1 and 2 verbatim, the Chinese names reuse the translated
labels of the Chinese Tables 1 and 2.

Level assignment (composition, not performance; see the surrounding text):
  0  fixed F/CR, one operator set, no archive, static population size; the
     variants differ in the donor, in the neighbourhood they draw on, or in
     the population structure they impose
  1  the F/CR rule itself is adapted (per individual, by schedule, fuzzy,
     chaotic, Bayesian or Z-score driven) with no memory and no operator pool
  2  a success-history memory with an external archive, an operator or
     parameter pool with credit assignment, or a learned/landscape-driven rule
  3  level-2 machinery plus a population-size control (LPSR, nonlinear
     reduction, adaptive size, reset) or a restart component

A row is level 3 when Tables 1 and 2 record such a component, which includes
the "L-" prefix of the success-history family (L-SHADE, L-SHADE-RSP,
L-BETA-DE, L-NTADE), where the prefix stands for linear population-size
reduction.
"""

# ---------------------------------------------------------------------------
# year, mechanism type of Tables 1-2, English name, Chinese name (None = the
# English name is printed in both languages), level, mutation, parameter rule,
# operators, archive, population, other
_ENTRIES = [
    # -- Table 1, part I: 1997-2014 -----------------------------------------
    (1997, 'mutation strategy', 'DE/rand/1/bin', None, 0,
     'rand/1', 'fixed', 'single', 'no', 'static', '-'),
    (1997, 'mutation strategy', 'DE/best/1/bin', None, 0,
     'best/1', 'fixed', 'single', 'no', 'static', '-'),
    (1997, 'mutation strategy', 'DE/rand/2/bin', None, 0,
     'rand/2', 'fixed', 'single', 'no', 'static', '-'),
    (1997, 'mutation strategy', 'DE/current-to-best/1', None, 0,
     'current-to-best/1', 'fixed', 'single', 'no', 'static', '-'),
    (1997, 'mutation strategy', 'DE/current-to-rand/1', None, 0,
     'current-to-rand/1', 'fixed', 'single', 'no', 'static', '-'),
    (1997, 'mutation strategy', 'DE/rand/1/either-or', None, 0,
     'rand/1/either-or', 'fixed', 'single', 'no', 'static', '-'),
    (2005, 'parameter control', 'FADE', None, 1,
     'rand/1', 'fuzzy', 'single', 'no', 'static', '-'),
    (2005, 'parameter control', 'SaDE', None, 2,
     'pool (4)', 'adaptive', 'pool', 'no', 'static', '-'),
    (2006, 'parameter control', 'jDE', None, 1,
     'rand/1', 'individual', 'single', 'no', 'static', '-'),
    (2006, 'mutation strategy', 'Directional DE', '带方向信息的 DE', 0,
     'direction reuse', 'fixed', 'single', 'no', 'static', '-'),
    (2008, 'parameter control', 'SaNSDE', None, 1,
     'rand/1 / c2best', 'individual', 'single', 'no', 'static', '-'),
    (2008, 'candidate correction', 'ODE', None, 0,
     'rand/1', 'fixed', 'single', 'no', 'static', 'opposition'),
    (2009, 'parameter control', 'JADE', None, 2,
     'current-to-pbest/1', 'history', 'single', 'yes', 'static', '-'),
    (2009, 'mutation strategy', 'DEGL', None, 0,
     'global/local nbhd', 'fixed', 'single', 'no', 'static', '-'),
    (2009, 'restart', 'Multi-start JADE', '多起点 JADE', 2,
     'current-to-pbest/1', 'history', 'single', 'yes', 'static', 'restart'),
    (2009, 'selection control', 'Distributed DE', '分布式 DE', 0,
     'rand/1', 'fixed', 'single', 'no', 'static', 'migration'),
    (2010, 'parameter control', 'i-DDE', None, 1,
     'rand/1', 'adaptive', 'single', 'no', 'static', 'dynamic'),
    (2011, 'mutation strategy', 'Proximity-based DE', '基于邻近的 DE', 0,
     'nearest-better diff', 'fixed', 'single', 'no', 'static', '-'),
    (2011, 'strategy ensemble', 'CoDE', None, 2,
     'pool (3)', 'fixed', 'pool', 'no', 'static', '-'),
    (2011, 'strategy ensemble', 'EPSDE', None, 2,
     'pool (6)', 'ensemble', 'pool', 'no', 'static', '-'),
    (2011, 'parameter control', 'Chaotic DE', '混沌 DE', 1,
     'rand/1', 'chaotic', 'single', 'no', 'static', '-'),
    (2012, 'parameter control', 'MDE_pBX', None, 2,
     'pool (2)', 'adaptive', 'pool', 'no', 'static', 'p-best'),
    (2013, 'parameter control', 'SHADE', None, 2,
     'current-to-pbest/1', 'history', 'single', 'yes', 'static', '-'),
    (2013, 'mutation strategy', 'Ranking-based DE', '基于排名的 DE', 0,
     'rank-weighted', 'fixed', 'single', 'no', 'static', '-'),
    (2013, 'population control', 'Auto-enhanced diversity', '自适应多样性增强', 1,
     'rand/1', 'adaptive', 'single', 'no', 'adaptive', 'diversity'),
    (2013, 'selection control', 'Species-based DE', '基于物种的 DE', 0,
     'rand/1', 'fixed', 'single', 'no', 'static', 'niching'),
    (2014, 'population control', 'L-SHADE', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', '-'),
    (2014, 'parameter control', 'Rcr-JADE', None, 2,
     'current-to-pbest/1', 'history + CR', 'single', 'yes', 'static', '-'),
    (2014, 'strategy ensemble', 'CoBiDE', None, 2,
     'covariance', 'history', 'single', 'no', 'static', 'covariance'),
    # -- Table 2, part II: 2015-2026 ----------------------------------------
    (2015, 'crossover', 'SPS-L-SHADE-EIG', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'eigen crossover'),
    (2016, 'parameter control', 'iL-SHADE', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', '-'),
    (2016, 'parameter control', 'L-SHADE-EpSin', None, 3,
     'current-to-pbest/1', 'sinusoidal', 'single', 'yes', 'LPSR', '-'),
    (2016, 'population control', 'MPEDE', None, 2,
     'pool (3)', 'history', 'pool', 'no', 'static', 'multi-pop'),
    (2016, 'parameter control', 'ZEPDE', None, 1,
     'rand/1', 'Z-score', 'single', 'no', 'static', '-'),
    (2017, 'parameter control, population control', 'jSO', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'nonlinear', '-'),
    (2017, 'hybrid', 'L-SHADE-SPACMA', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'CMA'),
    (2017, 'operator selection', 'LSAOS', None, 2,
     'pool', 'adaptive', 'pool', 'yes', 'static', 'landscape'),
    (2018, 'selection', 'L-SHADE-RSP', None, 3,
     'current-to-pbest/1', 'history + rank', 'single', 'yes', 'LPSR', '-'),
    (2018, 'candidate correction', 'SHADE-ILS', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'local search'),
    (2018, 'operator selection', 'Population evolvability', '种群可进化性', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', 'stagnation'),
    (2018, 'parameter control', 'LSHADE-cnEpSin', None, 3,
     'current-to-pbest/1', 'sinusoidal', 'single', 'yes', 'LPSR', '-'),
    (2019, 'parameter control', 'DISH', None, 2,
     'current-to-pbest/1', 'distance', 'single', 'yes', 'static', '-'),
    (2019, 'parameter control', 'DISK', None, 2,
     'current-to-pbest/1', 'rank', 'single', 'yes', 'static', '-'),
    (2019, 'parameter control', 'SinDE', None, 1,
     'rand/1', 'sinusoidal', 'single', 'no', 'static', '-'),
    (2019, 'parameter control', 'PaDE', None, 2,
     'current-to-pbest/1', 'history + CR', 'single', 'yes', 'static', '-'),
    (2019, 'parameter control', 'DRL parameter control', 'DRL 参数控制', 2,
     'current-to-pbest/1', 'RL', 'single', 'yes', 'static', 'RL'),
    (2019, 'mutation strategy', 'AGDE', None, 0,
     'guided donor', 'fixed', 'single', 'no', 'static', '-'),
    (2019, 'strategy ensemble', 'LSHADE44', None, 3,
     'pool (4)', 'history', 'pool', 'yes', 'LPSR', '-'),
    (2020, 'parameter control', 'jDE100', None, 1,
     'current-to-pbest/1', 'individual', 'single', 'no', 'static', 'p-best'),
    (2020, 'parameter control', 'j2020', None, 1,
     'current-to-pbest/1', 'F-pool', 'single', 'no', 'static', 'p-best'),
    (2020, 'parameter control', 'L-BR-DE', None, 3,
     'current-to-pbest/1', 'history + bias', 'single', 'yes', 'LPSR', '-'),
    (2020, 'operator selection', 'IMODE', None, 3,
     'pool (4)', 'history', 'pool', 'yes', 'LPSR', '-'),
    (2020, 'candidate correction', 'MTDE', None, 2,
     'pool', 'adaptive', 'pool', 'yes', 'static', 'multi-trial'),
    (2020, 'mutation strategy', 'HARD-DE', None, 2,
     'hierarchical archive', 'history', 'single', 'yes', 'static', '-'),
    (2021, 'population control, selection', 'NL-SHADE-RSP', None, 3,
     'current-to-pbest/1', 'history + rank', 'single', 'yes', 'nonlinear', '-'),
    (2021, 'population control', 'MadDE', None, 3,
     'pool', 'history', 'pool', 'yes', 'LPSR', '-'),
    (2021, 'operator selection', 'FLAMDE', None, 2,
     'pool', 'history', 'pool', 'yes', 'static', 'landscape'),
    (2022, 'parameter control, population control', 'NL-SHADE-LBC', None, 3,
     'current-to-pbest/1', 'history + bias', 'single', 'yes', 'nonlinear', '-'),
    (2022, 'population control', 'L-NTADE', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'two-pop'),
    (2022, 'operator selection', 'Dynamic landscape selection', '动态景观变异选择', 2,
     'pool', 'history', 'pool', 'yes', 'static', 'landscape'),
    (2022, 'algorithm selection', 'OACDE', None, 2,
     'pool', 'history', 'pool', 'yes', 'static', 'configurator'),
    (2022, 'crossover', 'EA4eig', None, 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'eigen crossover'),
    (2022, 'mutation strategy', 'LSHADE-ND', None, 3,
     'neighbourhood', 'history', 'single', 'yes', 'LPSR', '-'),
    (2023, 'algorithm selection', 'MODDE', None, 2,
     'pool', 'history', 'pool', 'yes', 'static', 'modular'),
    (2023, 'strategy ensemble', 'Multi-population SHADE', '多种群 SHADE', 2,
     'pool', 'history', 'pool', 'yes', 'adaptive', 'multi-pop'),
    (2023, 'parameter control', 'Reinforcement-learned SHADE', '强化学习 SHADE', 2,
     'current-to-pbest/1', 'history + RL', 'single', 'yes', 'static', 'RL'),
    (2023, 'restart', 'Two-stage restart DE', '两阶段重启 DE', 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'static', 'restart'),
    (2023, 'strategy ensemble', 'Dual-mutation DE', '双变异 DE', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', '-'),
    (2023, 'restart', 'Q-learning dual restart', 'Q 学习双重启', 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'static', 'RL, restart'),
    (2023, 'hybrid', 'Hybrid DE-PSO', '混合 DE-PSO', 1,
     'rand/1 + PSO', 'adaptive', 'single', 'no', 'static', 'PSO'),
    (2023, 'parameter control', 'Distance-driven SHADE', '距离驱动 SHADE', 2,
     'current-to-pbest/1', 'distance', 'single', 'yes', 'static', '-'),
    (2023, 'parameter control', 'Pairwise SHADE', '成对 SHADE', 2,
     'current-to-pbest/1', 'pairwise', 'single', 'yes', 'static', '-'),
    (2024, 'algorithm selection', 'DRL dynamic selection', 'DRL 动态选择', 2,
     'pool', 'history', 'pool', 'yes', 'static', 'RL'),
    (2024, 'operator selection', 'Surrogate-assisted L-SHADE', '代理辅助 L-SHADE', 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'surrogate'),
    (2024, 'operator selection', 'Q-learning operator selection', 'Q 学习算子选择', 2,
     'pool', 'history', 'pool', 'yes', 'static', 'RL'),
    (2026, 'selection control', 'Cooperative co-evolution DE', '协同进化 DE', 2,
     'rand/1', 'adaptive', 'single', 'no', 'adaptive', 'coevolution'),
    (2025, 'hybrid', 'Multifactorial DE with GMM transfer', '高斯混合模型迁移的多因子 DE', 2,
     'transfer-guided', 'adaptive', 'single', 'no', 'static', 'GMM transfer'),
    (2026, 'parameter control', 'Parameter-adaptive competitive DE', '参数自适应竞争型 DE', 2,
     'current-to-pbest/1', 'adaptive', 'single', 'yes', 'static', 'local search'),
    (2025, 'operator selection', 'DA2MODE', 'DA2MODE', 2,
     'pool', 'adaptive', 'pool', 'yes', 'adaptive', 'dynamic archive'),
    (2024, 'operator selection', 'Ensemble surrogate DE', '集成代理 DE', 2,
     'pool', 'history', 'pool', 'yes', 'static', 'surrogate'),
    (2024, 'parameter control', 'Kernel-density SHADE', '核密度 SHADE', 2,
     'current-to-pbest/1', 'KDE', 'single', 'yes', 'static', '-'),
    (2024, 'population control', 'Heterogeneous multi-population DE', '异构多种群 DE', 2,
     'rand/1', 'adaptive', 'single', 'no', 'adaptive', 'multi-pop'),
    (2024, 'strategy ensemble', 'Adaptive budget-allocation DE', '自适应预算分配 DE', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', 'budget'),
    (2024, 'mutation strategy', 'Ridge-regression-guided DE', '岭回归引导 DE', 0,
     'ridge regression', 'fixed', 'single', 'no', 'static', '-'),
    (2025, 'parameter control', 'DRL multi-stage adaptation', 'DRL 多阶段自适应', 2,
     'current-to-pbest/1', 'RL', 'single', 'yes', 'static', 'RL'),
    (2026, 'strategy ensemble', 'Dual-module DE', '双模块 DE', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', 'cooperation and competition'),
    (2026, 'operator selection', 'SFG-DE', 'SFG-DE', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', 'generated operators'),
    (2025, 'mutation strategy', 'Covariance-guided DE', '协方差引导 DE', 2,
     'covariance', 'adaptive', 'single', 'no', 'static', '-'),
    (2025, 'population control', 'DEEM', 'DEEM', 2,
     'rand/1', 'adaptive', 'single', 'no', 'multi-pop', 'elitism'),
    (2025, 'operator selection', 'Knowledge-fused DE', '知识融合 DE', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', 'knowledge'),
    (2025, 'population control', 'Adaptive population reset', '自适应种群重置', 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'reset', 'restart'),
    (2025, 'operator selection', 'Reinforcement-learned operator selection', '强化学习算子选择', 2,
     'pool', 'RL', 'pool', 'no', 'static', 'RL'),
    (2026, 'algorithm selection', 'MetaDE', 'MetaDE', 2,
     'pool', 'adaptive', 'pool', 'no', 'static', 'meta-level search'),
    (2025, 'operator selection', 'Surrogate-assisted operator selection', '代理辅助算子选择', 2,
     'pool', 'landscape', 'pool', 'no', 'static', 'surrogate'),
    (2026, 'mutation strategy', 'Exponential-crossover learning', '差分向量内的学习策略', 1,
     'difference learning', 'adaptive', 'single', 'no', 'static', 'exp crossover'),
    (2026, 'restart', 'Diversity-based restart', '基于多样性的重启', 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'static', 'restart'),
    (2026, 'crossover', 'Ensemble exponential crossover', '集成指数交叉', 3,
     'current-to-pbest/1', 'history', 'pool', 'yes', 'LPSR', 'exp crossover'),
    (2026, 'crossover', 'Simplified eigen-crossover', '简化特征交叉', 3,
     'current-to-pbest/1', 'history', 'single', 'yes', 'LPSR', 'eigen crossover'),
    (2026, 'parameter control', 'Bayesian parameter control', '贝叶斯参数控制', 1,
     'rand/1', 'Bayesian', 'single', 'no', 'static', '-'),
    (2026, 'mutation strategy', 'Graph-guided neighbourhood mutation', '图引导邻域变异', 1,
     'neighbourhood', 'adaptive', 'single', 'no', 'static', 'graph'),
    (2025, 'mutation strategy', 'FODE', 'FODE', 1,
     'fractional-order difference', 'adaptive', 'single', 'no', 'static', '-'),
    (2025, 'parameter control', 'Local-global parameter adaptation', '局部-全局参数自适应', 2,
     'current-to-pbest/1', 'history + local/global', 'single', 'yes', 'static', '-'),
    (2026, 'population control', 'Variance-contribution-ratio DE', '方差贡献率 DE', 2,
     'rand/1', 'adaptive', 'single', 'no', 'adaptive', 'variance ratio'),
    (2026, 'hybrid', 'GPU-DE with gradient polishing', 'GPU 加速的梯度抛光 DE', 2,
     'rand/1 + gradient', 'adaptive', 'single', 'no', 'static', 'gradient, GPU'),
    (2026, 'crossover', 'Dimensionally adaptive inheritance', '维度自适应继承', 1,
     'current-to-pbest/1', 'fixed', 'single', 'no', 'static', 'per-dimension inheritance'),
    (2026, 'selection control', 'DBSCAN niching DE', 'DBSCAN 小生境 DE', 1,
     'rand/1', 'fixed', 'single', 'no', 'static', 'niching'),
]

# ---------------------------------------------------------------------------
N = len(_ENTRIES)

#: number of entries per composition level, index = level
LEVELS = [sum(1 for e in _ENTRIES if e[4] == lv) for lv in range(4)]

assert len({e[2] for e in _ENTRIES}) == N, 'duplicate variant name'
assert sum(LEVELS) == N
assert all(e[4] in (0, 1, 2, 3) for e in _ENTRIES)
assert all(len(e) == 11 for e in _ENTRIES)


# ---------------------------------------------------------------------------
# The nine mechanism families.
#
# The mechanism-type labels of Tables 1 and 2 are already family names, because
# the chronological tables and the aggregate table have to speak one axis.  A
# family is a statement about *what is modified*; the control policy column of
# the aggregate table says *how*.  The two axes are what Section 2.3 reads.
#
# Field order: code, English label, Chinese label, English object, Chinese
# object, English policies, Chinese policies, representatives, kind, English
# buys, Chinese buys, English costs, Chinese costs.  ``kind`` separates the
# families that replace a rule the flow already has ('replace') from those that
# act after a candidate exists ('add'), and from the ones spanning several
# objects ('mixed').  "Buys" and "costs" are the price of the route: what the
# family returns relative to the flow it modifies, and what it takes to get it.
FAMILIES = [
    ('donor', 'Donor structure', '供体结构',
     'the difference term and the base vector', '差分项与基向量',
     'fixed, ranking, neighbourhood, covariance, graph',
     '固定、排序、邻域、协方差、图',
     ['DE/rand/1/bin', 'Proximity-based DE', 'Graph-guided neighbourhood mutation'],
     'replace',
     'better-conditioned difference vectors at the same evaluation count',
     '同等评估预算下条件更好的差分向量',
     'an archive, a covariance estimate or a neighbourhood graph in memory',
     '需在内存中维护归档、协方差估计或邻域图'),
    ('crossover', 'Crossover structure', '交叉结构',
     'how donor coordinates enter the trial', '供体坐标如何进入试验向量',
     'binomial, exponential, eigen-decomposition, ensemble',
     '二项、指数、特征分解、集成',
     ['SPS-L-SHADE-EIG', 'EA4eig', 'Ensemble exponential crossover'],
     'replace',
     'mixing that follows the population covariance rather than the axes',
     '沿种群协方差而非坐标轴混合',
     'one eigendecomposition per generation, cubic in the dimension',
     '每代一次特征分解，代价随维数三次增长'),
    ('fc', 'Scale and rate', '尺度与速率',
     'F and CR during the run', '运行过程中的 F 与 CR',
     'fuzzy, self-adaptive, history memory, schedule, Bayesian, RL',
     '模糊、自携带、历史记忆、调度、贝叶斯、强化学习',
     ['jDE', 'SHADE', 'Bayesian parameter control'],
     'replace',
     'step sizes that track the search state without user-set constants',
     '无需用户设定常数即可跟踪搜索状态的步长',
     'a memory to tune in turn: memory size, p-best, damping',
     '记忆本身要调：记忆规模、p-best、阻尼'),
    ('np', 'Population size', '种群规模',
     'NP over the budget', '预算内的 NP',
     'linear, nonlinear, reset, adaptive',
     '线性、非线性、重置、自适应',
     ['L-SHADE', 'MadDE', 'Adaptive population reset'],
     'replace',
     'more exploitation per remaining evaluation as the budget shrinks',
     '预算收缩后每次评估的利用更充分',
     'a schedule to choose, and a population too small to recover from a bad step',
     '缩减方案要选；种群过小则难以从坏步恢复'),
    ('selection', 'Selection and replacement', '选择与替换',
     'which trial survives', '哪一个试验向量存活',
     'greedy, rank pressure, distributed, niching',
     '贪婪、排序压力、分布式、小生境',
     ['L-SHADE-RSP', 'NL-SHADE-RSP', 'Species-based DE'],
     'replace',
     'selection pressure that does not collapse the population early',
     '不会过早塌缩种群的选择压力',
     'ranking or niching bookkeeping, N log N work per generation',
     '排序或小生境维护，每代 N log N 的开销'),
    ('ensemble', 'Operator ensemble', '算子集成',
     'which donor or parameter set is used', '用哪一个供体或参数集',
     'probability, credit assignment, learned pool, evolved pool',
     '概率、信用分配、学习式池、演化式池',
     ['SaDE', 'EPSDE', 'IMODE'],
     'replace',
     'robustness across functions without offline portfolio selection',
     '无需离线挑选组合即可跨函数稳健',
     'noisy credit assignment and k times the tuning surface',
     '信用分配的噪声与 k 倍的调参面'),
    ('restart', 'Restart and stagnation', '重启与停滞',
     'when the population is re-seeded', '何时重新播种种群',
     'trigger, diversity, Q-learning',
     '触发、多样性、Q 学习',
     ['Multi-start JADE', 'Q-learning dual restart', 'Diversity-based restart'],
     'add',
     'escape from stagnation without paying during the productive phase',
     '不在有效阶段付出代价即可跳出停滞',
     'a trigger threshold, and the evaluations spent before it fires',
     '触发阈值，以及触发前已耗掉的评估'),
    ('candidate', 'Candidate correction', '候选修正',
     'the trial after it has been built', '试验向量构造之后',
     'unconditional repair, local search, extra trials',
     '无条件修复、局部搜索、多试验',
     ['ODE', 'SHADE-ILS', 'MTDE'],
     'add',
     'a better trial vector at zero extra objective evaluations',
     '零额外目标评估即可改善试验向量',
     'a surrogate or local model, and no repair of a wrong direction',
     '需要替代或局部模型，且无法纠正错误方向'),
    ('meta', 'Composition and meta-level', '组合与元级',
     'several objects at once, or the algorithm itself', '一个以上对象，或算法本身',
     'offline configuration, online selection, hybrid composition',
     '离线配置、在线选择、混合组合',
     ['L-SHADE-SPACMA', 'OACDE', 'MODDE'],
     'mixed',
     'the composition of the above is optimised rather than hand-set',
     '上述组合本身被优化而非手工设定',
     'offline budget, and conclusions that hold only within the tuned family',
     '离线预算，且结论只在被调族内成立'),
]

#: mechanism-type label of Tables 1-2 -> family code, longest label first
_FAMILY_OF = {
    'mutation strategy': 'donor',
    'crossover': 'crossover',
    'parameter control': 'fc',
    'population control': 'np',
    'selection control': 'selection',
    'selection': 'selection',
    'strategy ensemble': 'ensemble',
    'operator selection': 'ensemble',
    'restart': 'restart',
    'candidate correction': 'candidate',
    'algorithm selection': 'meta',
    'hybrid': 'meta',
}
_ZH_FAMILY_OF = {
    '变异策略': 'donor',
    '交叉': 'crossover',
    '参数控制': 'fc',
    '种群控制': 'np',
    '选择控制': 'selection',
    '选择': 'selection',
    '策略集成': 'ensemble',
    '算子选择': 'ensemble',
    '重启': 'restart',
    '候选修正': 'candidate',
    '算法选择': 'meta',
    '混合': 'meta',
}


def _fam(code, lang):
    idx = 1 if lang == 'en' else 2
    for row in FAMILIES:
        if row[0] == code:
            return row[idx]
    raise KeyError(code)


def _primary(entry):
    """The family a variant belongs to; the first label of a compound wins."""
    label = entry[1]
    for table in (_FAMILY_OF, _ZH_FAMILY_OF):
        if label in table:
            return table[label]
    first = label.replace('、', ', ').split(', ')[0]
    for table in (_FAMILY_OF, _ZH_FAMILY_OF):
        if first in table:
            return table[first]
    raise KeyError(label)


def _secondary(entry):
    """The second family of a compound label, or None."""
    label = entry[1]
    if ',' not in label and '、' not in label:
        return None
    tail = label.replace('、', ', ').split(', ')[1]
    return _FAMILY_OF.get(tail) or _ZH_FAMILY_OF.get(tail)


#: number of entries per family, index = position in FAMILIES
_COUNTS = [sum(1 for e in _ENTRIES if _primary(e) == f[0]) for f in FAMILIES]
_KINDS = [f[8] for f in FAMILIES]
assert sum(_COUNTS) == N, 'families do not partition the variant list'
assert all(c > 0 for c in _COUNTS)


def entries():
    """The raw ``_ENTRIES`` tuples, for figures drawn off the same axes.

    Field order: year, mechanism type, English name, Chinese name, level,
    mutation, parameter rule, operators, archive, population, other.
    """
    return list(_ENTRIES)


def rows(lang='en'):
    """The table body, ordered by level and, within a level, by year.

    ``lang='zh'`` prints the translated labels of the Chinese Tables 1 and 2
    for the entries that are named descriptively rather than by acronym.
    """
    idx = 2 if lang == 'en' else 3
    body = []
    for e in sorted(_ENTRIES, key=lambda e: (e[4], e[0])):
        body.append([e[idx] or e[2], str(e[4])] + list(e[5:]))
    return body


def family_rows(lang='en'):
    """Table: the same entries aggregated by mechanism family.

    One row per family: what it modifies, the control policies it has been
    implemented with, what the route buys and what it costs, how many of the
    entries belong to it, and whether it replaces a rule or is added after a
    candidate exists.
    """
    en = lang == 'en'
    body = []
    for row in FAMILIES:
        code = row[0]
        members = [e for e in _ENTRIES if _primary(e) == code]
        body.append([
            row[1] if en else row[2],
            row[3] if en else row[4],
            row[5] if en else row[6],
            row[9] if en else row[10],
            row[11] if en else row[12],
            str(len(members)),
            row[8] if en else {'replace': '替换', 'add': '叠加',
                               'mixed': '混合'}[row[8]],
        ])
    return body


# ---------------------------------------------------------------------------
# The four composition levels as a table of their own.
#
# Field order: English "adds", Chinese "adds", English "keeps fixed", Chinese
# "keeps fixed", English "implemented as", Chinese "implemented as", English
# representatives, Chinese representatives.  The level totals come from
# LEVELS, so the table and the prose cannot drift apart.
LEVEL_TEXT = [
    ('nothing: the loop is the DE of 1997',
     '不加任何东西：就是 1997 年的 DE 循环',
     'F, CR and NP, and no memory',
     'F、CR 与 NP 全固定，且没有记忆',
     'a different donor, the neighbourhood it draws on, or the population '
     'structure it imposes',
     '换一个供体、换它取值的邻域，或换它施加的种群结构',
     'DE/rand/1/bin; DE/best/1/bin; DE/rand/2/bin',
     'DE/rand/1/bin；DE/best/1/bin；DE/rand/2/bin'),
    ('the F and CR rule itself is adapted',
     '让 F 与 CR 的规则本身自适应',
     'NP, and no memory across generations',
     'NP，且没有跨代记忆',
     'per individual, by schedule, or by a fuzzy, chaotic, Z-score or '
     'Bayesian controller',
     '按个体、按调度，或由模糊、混沌、Z 分数、贝叶斯控制器给出',
     'jDE; SinDE; Bayesian parameter control',
     'jDE；SinDE；贝叶斯参数控制'),
    ('a memory across generations, or a rule learned from the landscape',
     '跨代记忆，或从景观中学得的规则',
     'NP',
     'NP',
     'success-history archive, credit-assigned operator pool, learned or '
     'reinforcement-learning rule',
     '成功历史存档、带信用分配的算子池、学习式或强化学习规则',
     'JADE; SHADE; EPSDE',
     'JADE；SHADE；EPSDE'),
    ('population-size control or a restart trigger',
     '种群规模控制或重启触发',
     'none of the four',
     '四项中已无一项固定',
     'linear or nonlinear reduction, reset, stagnation trigger',
     '线性或非线性缩减、重置、停滞触发',
     'L-SHADE; jSO; NL-SHADE-RSP',
     'L-SHADE；jSO；NL-SHADE-RSP'),
]


def level_rows(lang='en'):
    """The four composition levels, one row each, with their member counts."""
    en = lang == 'en'
    body = []
    for lv, row in enumerate(LEVEL_TEXT):
        o = 0 if en else 1
        body.append([str(lv), row[o], row[2 + o], row[4 + o],
                     str(LEVELS[lv]), row[6 + o]])
    return body


def family_count(code):
    """Entries whose primary family is ``code``."""
    return sum(1 for e in _ENTRIES if _primary(e) == code)


def kind_counts():
    """(replace, add, mixed) entry counts over the nine families."""
    out = {'replace': 0, 'add': 0, 'mixed': 0}
    for row in FAMILIES:
        out[row[8]] += family_count(row[0])
    return out


# ---------------------------------------------------------------------------
_UNITS = ('zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven',
          'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen',
          'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen')
_TENS = ('', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy',
         'eighty', 'ninety')


def _en(n):
    if n < 20:
        return _UNITS[n]
    if n < 100:
        return _TENS[n // 10] + ('-' + _UNITS[n % 10] if n % 10 else '')
    return 'one hundred' + (' ' + _en(n - 100) if n > 100 else '')


def _zh(n):
    d = '零一二三四五六七八九'
    if n < 10:
        return d[n]
    if n < 100:
        t, u = divmod(n, 10)
        return (d[t] if t > 1 else '') + '十' + (d[u] if u else '')
    h, r = divmod(n, 100)
    if not r:
        return d[h] + '百'
    return d[h] + '百' + ('零' if r < 10 else '') + _zh(r)


def word(lang='en'):
    """The cardinals used in the caption and in the surrounding text."""
    return _en(N) if lang == 'en' else _zh(N)

# -*- coding: utf-8 -*-
"""图 5-2 三维沙盘轨迹图（matplotlib 重绘版）。

把「运行过程与结果界面」里的 Three.js 三维沙盘重绘成出版级静态 3D 图：
合成山地地形 + bare/UPCL 两臂无人机三维轨迹 + 关键地物，浅蓝天空背景，俯视视角。

用法：
    python src/plot_uav_trajectory_3d.py --host NL-SHADE-RSP --fid 1
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, LightSource
from matplotlib.lines import Line2D
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

from opponents import make_opponent
from uav_adversarial import get_uav_problem, SCENARIO_DIMS

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'apps' / 'raw'
FIG = ROOT / 'results' / 'apps' / 'figures'
SEED_BASE = 20240_000

SKY = '#b8dff7'
SKY_RGBA = (0.72, 0.88, 0.97, 1.0)
ARM_COLORS = {'bare': '#1f77b4', 'full': '#d62728'}
TERRAIN_CMAP = LinearSegmentedColormap.from_list('t3d', [
    '#2f5d3a', '#7ba05b', '#c2a878', '#9c7a4a', '#e8e2d5'])


def load_cell(host, fid, scenario='intercept'):
    dim = SCENARIO_DIMS[scenario]
    p = RAW / f'uav_{scenario}' / f'D{dim}' / f'{host.replace("/", "-")}__F{fid}.json'
    if not p.exists():
        raise SystemExit(f'missing cell: {p}')
    with open(p, encoding='utf-8') as fh:
        return json.load(fh)


def solve_pair(cell, run=0):
    rec = cell['runs'][run]
    out = []
    for arm in ('bare', 'full'):
        a = rec.get(arm)
        if isinstance(a, dict) and 'best_x' in a:
            out.append((arm, np.asarray(a['best_x'], float)))
    if not out:
        raise SystemExit('no best_x found')
    return out


def drone_tracks(frames, n):
    tracks, states = [], []
    for i in range(n):
        xs, ys, zs, st = [], [], [], 0
        for fr in frames:
            ds = fr.get('drones') or []
            if i < len(ds):
                d = ds[i]
                xs.append(float(d[0])); ys.append(float(d[1])); zs.append(float(d[2]))
                st = int(d[3])
        tracks.append((np.asarray(xs), np.asarray(ys), np.asarray(zs)))
        states.append(st)
    return tracks, states


def interceptor_tracks(frames, n):
    tracks = []
    for i in range(n):
        xs, ys, zs = [], [], []
        for fr in frames:
            ps = fr.get('interceptors') or []
            if i < len(ps):
                p = ps[i]
                xs.append(float(p[0])); ys.append(float(p[1])); zs.append(float(p[2]))
        tracks.append((np.asarray(xs), np.asarray(ys), np.asarray(zs)))
    return tracks


def render_3d(host, fid, run=0, scenario='intercept', difficulty='L1',
              out=None, title=None, dpi=220, figsize=(9.6, 8.4),
              elev=70, azim=-55, box_aspect=(1.0, 1.0, 0.52)):
    cell = load_cell(host, fid, scenario)
    solutions = solve_pair(cell, run)
    opp = make_opponent(difficulty, drl_algo='es', seed=SEED_BASE)
    problem = get_uav_problem(scenario, dim=SCENARIO_DIMS[scenario], fid=fid,
                              seed=SEED_BASE, opponent=opp)
    cfg, env = problem.cfg, problem.env

    fig = plt.figure(figsize=figsize)
    fig.patch.set_facecolor(SKY)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor(SKY)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_pane_color(SKY_RGBA)
    ax.view_init(elev=elev, azim=azim)

    # 地形表面
    xs, ys, Z = env.terrain.grid()
    X, Y = np.meshgrid(xs, ys)
    ax.plot_surface(X, Y, Z, cmap=TERRAIN_CMAP, rstride=1, cstride=1,
                    linewidth=0, antialiased=True, shade=True,
                    lightsource=LightSource(azdeg=315, altdeg=45), zorder=1)

    frames_by_arm = {}
    for arm, x in solutions:
        cost, _state, frames = problem.trajectory(x)
        frames_by_arm[arm] = (cost, frames)

    # 无人机轨迹
    for arm, x in solutions:
        color = ARM_COLORS[arm]
        _cost, frames = frames_by_arm[arm]
        tracks, states = drone_tracks(frames, cfg.n_drones)
        for i, (tx, ty, tz) in enumerate(tracks):
            if len(tx) < 2:
                continue
            ax.plot(tx, ty, tz, color=color, lw=2.0, alpha=0.95, zorder=6,
                    solid_capstyle='round')
            ax.scatter([tx[0]], [ty[0]], [tz[0]], c=color, marker='^', s=48,
                       edgecolors='white', linewidths=0.5, zorder=8)
            st = states[i]
            if st in (1, 4):
                ax.scatter([tx[-1]], [ty[-1]], [tz[-1]], c=color, marker='o', s=52,
                           edgecolors='white', linewidths=0.6, zorder=8)
            elif st == 2:
                ax.scatter([tx[-1]], [ty[-1]], [tz[-1]], c='#c0392b', marker='x',
                           s=60, linewidths=1.6, zorder=8)
            elif st == 3:
                ax.scatter([tx[-1]], [ty[-1]], [tz[-1]], c='#ff7f0e', marker='x',
                           s=60, linewidths=1.6, zorder=8)

    # 拦截直升机轨迹
    _cost, frames = frames_by_arm[solutions[0][0]]
    for tx, ty, tz in interceptor_tracks(frames, cfg.n_interceptors):
        if len(tx) >= 2:
            ax.plot(tx, ty, tz, color='#e67e22', lw=1.4, alpha=0.85,
                    linestyle='--', zorder=5)

    # 地物
    bx, by = cfg.base_pos
    bz = env.terrain.height(bx, by) + 8
    ax.scatter([bx], [by], [bz], c='#d62728', marker='s', s=85,
               edgecolors='white', linewidths=0.6, zorder=7)
    ax.text(bx, by, bz + 20, 'base', color='#8a2c2c', fontsize=8, ha='center', zorder=9)
    for (axx, ayy, azz) in env.aa0:
        ax.scatter([axx], [ayy], [azz], c='#ff7f0e', marker='s', s=55,
                   edgecolors='#7f3f00', linewidths=0.6, zorder=7)
    for (hx, hy) in env.interceptors0:
        hz = env.terrain.height(hx, hy) + 6
        ax.scatter([hx], [hy], [hz], c='#7f3f00', marker='^', s=55,
                   edgecolors='white', linewidths=0.5, zorder=7)

    ax.set_xlim(0, cfg.map_w)
    ax.set_ylim(0, cfg.map_h)
    ax.set_zlim(0, cfg.max_alt)
    ax.set_box_aspect(box_aspect)
    ax.set_xlabel('X (m)', fontsize=9)
    ax.set_ylabel('Y (m)', fontsize=9)
    ax.set_zlabel('Z (m)', fontsize=9)
    ax.set_title(title or f'intercept F{fid} · {host} · bare vs UPCL (run {run})',
                 fontsize=11, fontweight='bold', pad=8)

    handles = [
        Line2D([0], [0], color=ARM_COLORS['bare'], lw=2.2, label='bare'),
        Line2D([0], [0], color=ARM_COLORS['full'], lw=2.2, label='UPCL'),
        Line2D([0], [0], color='#e67e22', lw=1.4, ls='--', label='interceptor'),
        Line2D([0], [0], marker='s', color='w', markerfacecolor='#d62728',
               markeredgecolor='#d62728', markersize=9, label='base'),
        Line2D([0], [0], marker='s', color='w', markerfacecolor='#ff7f0e',
               markeredgecolor='#7f3f00', markersize=8, label='AA vehicle'),
    ]
    ax.legend(handles=handles, loc='upper left', fontsize=8, framealpha=0.9,
              borderaxespad=0.5, handlelength=1.6)

    fig.tight_layout()
    if out is None:
        out = FIG / f'fig_uav_trajectory_3d_{host.replace("/", "-")}_F{fid}.png'
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=dpi, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f'[3d] saved {out}', flush=True)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--host', default='NL-SHADE-RSP')
    ap.add_argument('--fid', type=int, default=1)
    ap.add_argument('--run', type=int, default=0)
    ap.add_argument('--difficulty', default='L1')
    ap.add_argument('--out', default=None)
    ap.add_argument('--elev', type=float, default=70)
    ap.add_argument('--azim', type=float, default=-55)
    args = ap.parse_args(argv)
    render_3d(args.host, args.fid, run=args.run, difficulty=args.difficulty,
              out=args.out, elev=args.elev, azim=args.azim)


if __name__ == '__main__':
    main()

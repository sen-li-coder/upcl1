"""Unified 30-host mechanism analysis for the DE mechanism paper.

Reads ``results/cec/raw`` (30 hosts: 20 legacy hosts recorded under the
``upcl`` arm + 10 wave-4 hosts recorded under the ``full`` arm; both arms share
the *same* ``default`` UPCL probe config, so their mechanism fingerprints are
directly comparable) and writes the mechanism tables used by the paper build:

* ``mech30_bare_accuracy.csv``   -- per-cell bare final error (30 hosts).
* ``mech30_host_summary.csv``    -- per-host mechanism fingerprint summary.
* ``mech30_by_level.csv``        -- aggregated by mechanism level (0..3).
* ``mech30_category.csv``        -- aggregated by CEC problem category.

The three UPCL observables are:

* ``intervention_rate``  -- fraction of host proposals the probe modifies.
* ``dec``                -- intervention gain, log10(median bare) - log10(median UPCL).
* ``z0..z4_effect``      -- descriptor contrast between working / failing proposals
  (rho_step, theta_align, eta_elite, kappa_crowd, nu_novel).
"""
import csv
import json
import numpy as np
from pathlib import Path
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw'
TAB = ROOT / 'results' / 'cec' / 'tables'
FLOOR = 1e-8

DESC_KEYS = ['rho_step', 'theta_align', 'eta_elite', 'kappa_crowd', 'nu_novel']
Z2DESC = {f'z{k}_effect': DESC_KEYS[k] for k in range(5)}

# --- algorithm -> mechanism composition (six dimensions) -------------------
# level 0: fixed parameters, mutation/proposal generation comparison
# level 1: individual-level parameter adaptation
# level 2: parameter + strategy adaptation (success-history, archive, pools)
# level 3: + population-size control and further mechanisms
LEVELS = {
    'DE/rand/1': 0, 'DE/best/1': 0, 'DE/rand/2': 0,
    'DE/current-to-best/1': 0, 'DE/current-to-rand/1': 0,
    'DE/rand/1/either-or': 0,
    'jDE': 1, 'SaNSDE': 1, 'jDE100': 1, 'j2020': 1, 'SinDE': 1,
    'JADE': 2, 'SHADE': 2, 'CoBiDE': 2, 'SaDE': 2, 'EPSDE': 2,
    'CoDE': 2, 'MPEDE': 2, 'DISH': 2, 'DISK': 2, 'PaDE': 2,
    'L-SHADE': 3, 'jSO': 3, 'L-SHADE-RSP': 3, 'NL-SHADE-RSP': 3,
    'MadDE': 3, 'LSHADE-cnEpSin': 3, 'IMODE': 3,
    'SHADE-ILS': 3,
}

MECH = {
    'DE/rand/1':            dict(mutation='rand/1',            param='fixed',        strategy='single', archive=0, pop='static',   other=''),
    'DE/best/1':            dict(mutation='best/1',            param='fixed',        strategy='single', archive=0, pop='static',   other=''),
    'DE/rand/2':            dict(mutation='rand/2',            param='fixed',        strategy='single', archive=0, pop='static',   other=''),
    'DE/current-to-best/1': dict(mutation='current-to-best/1', param='fixed',        strategy='single', archive=0, pop='static',   other=''),
    'DE/current-to-rand/1': dict(mutation='current-to-rand/1', param='fixed',        strategy='single', archive=0, pop='static',   other=''),
    'DE/rand/1/either-or':  dict(mutation='rand/1/either-or',  param='fixed',        strategy='single', archive=0, pop='static',   other=''),
    'jDE':    dict(mutation='rand/1',             param='individual',    strategy='single', archive=0, pop='static', other=''),
    'SaNSDE': dict(mutation='rand/1 / c2best',    param='individual-ns', strategy='single', archive=0, pop='static', other=''),
    'jDE100': dict(mutation='current-to-pbest/1', param='individual',    strategy='single', archive=0, pop='static', other='p-best'),
    'j2020':  dict(mutation='current-to-pbest/1', param='F-pool',        strategy='single', archive=0, pop='static', other='p-best'),
    'SinDE':  dict(mutation='rand/1',             param='sinusoidal',    strategy='single', archive=0, pop='static', other=''),
    'JADE':   dict(mutation='current-to-pbest/1', param='history',      strategy='single', archive=1, pop='static', other=''),
    'SHADE':  dict(mutation='current-to-pbest/1', param='history',      strategy='single', archive=1, pop='static', other=''),
    'CoBiDE': dict(mutation='covariance',         param='history',      strategy='single', archive=1, pop='static', other='covariance'),
    'SaDE':   dict(mutation='pool(4)',            param='adaptive',     strategy='pool',   archive=0, pop='static', other=''),
    'EPSDE':  dict(mutation='pool(6 triples)',    param='ensemble',     strategy='pool',   archive=0, pop='static', other=''),
    'CoDE':   dict(mutation='pool(3 settings)',   param='fixed',        strategy='pool',   archive=0, pop='static', other=''),
    'MPEDE':  dict(mutation='pool(3)',            param='history',      strategy='pool',   archive=0, pop='static', other='multi-pop'),
    'DISH':   dict(mutation='current-to-pbest/1', param='distance',     strategy='single', archive=1, pop='static', other=''),
    'DISK':   dict(mutation='current-to-pbest/1', param='rank',         strategy='single', archive=1, pop='static', other=''),
    'PaDE':   dict(mutation='current-to-pbest/1', param='history+CR',   strategy='single', archive=1, pop='static', other=''),
    'L-SHADE':      dict(mutation='current-to-pbest/1', param='history',      strategy='single', archive=1, pop='LPSR',     other=''),
    'jSO':          dict(mutation='current-to-pbest/1', param='history',      strategy='single', archive=1, pop='nonlinear', other=''),
    'L-SHADE-RSP':  dict(mutation='current-to-pbest/1', param='history+rank', strategy='single', archive=1, pop='LPSR',     other=''),
    'NL-SHADE-RSP': dict(mutation='current-to-pbest/1', param='history+rank', strategy='single', archive=1, pop='nonlinear', other=''),
    'MadDE':        dict(mutation='pool',               param='history',      strategy='pool',   archive=1, pop='LPSR',     other=''),
    'LSHADE-cnEpSin': dict(mutation='current-to-pbest/1', param='sinusoidal', strategy='single', archive=1, pop='LPSR',   other=''),
    'IMODE':        dict(mutation='pool(4)',            param='history',      strategy='pool',   archive=1, pop='LPSR',     other=''),
    'SHADE-ILS':    dict(mutation='current-to-pbest/1', param='history',      strategy='single', archive=1, pop='LPSR',     other='iterated local search'),
}

ORDER = ['DE/rand/1', 'DE/best/1', 'DE/rand/2', 'DE/current-to-best/1',
         'DE/current-to-rand/1', 'DE/rand/1/either-or',
         'jDE', 'SaNSDE', 'jDE100', 'j2020', 'SinDE',
         'JADE', 'SHADE', 'CoBiDE', 'SaDE', 'EPSDE', 'CoDE', 'MPEDE',
         'DISH', 'DISK', 'PaDE',
         'L-SHADE', 'jSO', 'L-SHADE-RSP', 'NL-SHADE-RSP', 'MadDE',
         'LSHADE-cnEpSin', 'IMODE', 'SHADE-ILS']


def load_cells():
    """Return {key: {meta, runs}} for cells with >= 30 runs."""
    raw = defaultdict(lambda: {'runs': []})
    for f in RAW.rglob('*.json'):
        try:
            d = json.load(open(f, encoding='utf-8'))
        except Exception:
            continue
        key = (d['suite'], d['dim'], d['host'], d['fid'])
        c = raw[key]
        if 'meta' not in c:
            c['meta'] = {k: d.get(k) for k in
                         ('suite', 'dim', 'host', 'fid', 'category')}
        c['runs'].extend(d.get('runs', []))
    return {k: c for k, c in raw.items() if len(c['runs']) >= 30}


def upcl_label(run):
    return 'full' if 'full' in run else ('upcl' if 'upcl' in run else None)


def log10err(run, arm):
    rec = run.get(arm)
    if not rec:
        return None
    v = rec.get('err_final')
    if v is None:
        return None
    return float(np.log10(max(abs(float(v)), FLOOR)))


def run_dec(run):
    """intervention gain: log10(median bare) - log10(median upcl), >0 = gain."""
    lab = upcl_label(run)
    b = log10err(run, 'bare')
    u = log10err(run, lab) if lab else None
    if b is None or u is None:
        return None
    return b - u


def run_ri(run):
    lab = upcl_label(run)
    b = run.get('bare', {}).get('err_final')
    u = run.get(lab, {}).get('err_final') if lab else None
    if b is None or u is None:
        return None
    b, u = float(b), float(u)
    scale = max(abs(b), abs(u), FLOOR)
    return float((b - u) / scale)


def run_int_rate(run):
    lab = upcl_label(run)
    rec = run.get(lab)
    if not rec:
        return None
    st = rec.get('upcl') or {}
    v = st.get('intervention_rate')
    return float(v) if v is not None else None


def run_policy_rate(run):
    lab = upcl_label(run)
    rec = run.get(lab)
    if not rec:
        return None
    st = rec.get('upcl') or {}
    v = st.get('policy_rate')
    return float(v) if v is not None else None


def run_desc(run):
    lab = upcl_label(run)
    rec = run.get(lab)
    if not rec:
        return None
    di = (rec.get('upcl') or {}).get('descriptor_influence') or {}
    out = {}
    for zk, name in Z2DESC.items():
        v = di.get(zk)
        out[name] = float(v) if v is not None else 0.0
    return out


def mean_shift(run):
    lab = upcl_label(run)
    rec = run.get(lab)
    if not rec:
        return None
    st = rec.get('upcl') or {}
    v = st.get('mean_relative_shift')
    return float(v) if v is not None else None


def main():
    cells = load_cells()
    print(f'[mech30] {len(cells)} cells (>=30 runs)')

    # --- per-cell bare accuracy -------------------------------------------
    bare_rows = []
    cell_rows = []          # per-cell observables for aggregation
    for key, c in cells.items():
        meta = c['meta']
        b = [log10err(r, 'bare') for r in c['runs']]
        b = [x for x in b if x is not None]
        if not b:
            continue
        bare_rows.append({
            'suite': meta['suite'], 'dim': meta['dim'],
            'host': meta['host'], 'fid': meta['fid'],
            'category': meta.get('category', ''),
            'bare_median_log10err': float(np.median(b)),
            'bare_mean_log10err': float(np.mean(b)),
        })
        decs = [x for x in (run_dec(r) for r in c['runs']) if x is not None]
        ris = [x for x in (run_ri(r) for r in c['runs']) if x is not None]
        irs = [x for x in (run_int_rate(r) for r in c['runs']) if x is not None]
        prs = [x for x in (run_policy_rate(r) for r in c['runs']) if x is not None]
        mss = [x for x in (mean_shift(r) for r in c['runs']) if x is not None]
        descs = [x for x in (run_desc(r) for r in c['runs']) if x is not None]
        row = {
            'suite': meta['suite'], 'dim': meta['dim'],
            'host': meta['host'], 'fid': meta['fid'],
            'category': meta.get('category', ''),
            'n_runs': len(b),
            'bare_median_log10err': float(np.median(b)),
            'dec_median': float(np.median(decs)) if decs else 0.0,
            'ri_mean': float(np.mean(ris)) if ris else 0.0,
            'intervention_rate': float(np.mean(irs)) if irs else 0.0,
            'policy_rate': float(np.mean(prs)) if prs else 0.0,
            'mean_relative_shift': float(np.mean(mss)) if mss else 0.0,
        }
        for dk in DESC_KEYS:
            row[dk + '_effect'] = float(np.mean([d[dk] for d in descs])) if descs else 0.0
        cell_rows.append(row)

    _write(TAB / 'mech30_bare_accuracy.csv', bare_rows)
    _write(TAB / 'mech30_cells.csv', cell_rows)
    print(f'[mech30] wrote bare_accuracy ({len(bare_rows)}) + cells ({len(cell_rows)})')

    # --- per-host summary --------------------------------------------------
    host_rows = []
    for h in ORDER:
        sub = [r for r in cell_rows if r['host'] == h]
        if not sub:
            continue
        n = len(sub)
        bare_med = float(np.mean([r['bare_median_log10err'] for r in sub]))
        row = {
            'host': h,
            'level': LEVELS.get(h, -1),
            'n_cells': n,
            'bare_median_log10err': bare_med,
            'dec_mean': float(np.mean([r['dec_median'] for r in sub])),
            'dec_pos_cells': float(np.mean([1 if r['dec_median'] > 0 else 0 for r in sub])),
            'intervention_rate': float(np.mean([r['intervention_rate'] for r in sub])),
            'policy_rate': float(np.mean([r['policy_rate'] for r in sub])),
            'mean_relative_shift': float(np.mean([r['mean_relative_shift'] for r in sub])),
        }
        for dk in DESC_KEYS:
            row[dk + '_effect'] = float(np.mean([r[dk + '_effect'] for r in sub]))
        row.update(MECH.get(h, {}))
        host_rows.append(row)

    # rank by bare accuracy (lower error = better)
    order_by_bare = sorted(host_rows, key=lambda r: r['bare_median_log10err'])
    for i, r in enumerate(order_by_bare):
        r['bare_rank'] = i + 1
    host_rows.sort(key=lambda r: r['bare_rank'])
    _write(TAB / 'mech30_host_summary.csv', host_rows)
    print(f'[mech30] wrote host_summary ({len(host_rows)} hosts)')

    # --- by level ----------------------------------------------------------
    level_rows = []
    for lv in (0, 1, 2, 3):
        sub = [r for r in cell_rows if LEVELS.get(r['host']) == lv]
        if not sub:
            continue
        row = {'level': lv, 'n_hosts': len(set(r['host'] for r in sub)),
               'n_cells': len(sub),
               'bare_median_log10err': float(np.mean([r['bare_median_log10err'] for r in sub])),
               'intervention_rate': float(np.mean([r['intervention_rate'] for r in sub])),
               'policy_rate': float(np.mean([r['policy_rate'] for r in sub])),
               'dec_mean': float(np.mean([r['dec_median'] for r in sub])),
               'dec_pos_cells': float(np.mean([1 if r['dec_median'] > 0 else 0 for r in sub])),
               'mean_relative_shift': float(np.mean([r['mean_relative_shift'] for r in sub]))}
        for dk in DESC_KEYS:
            row[dk + '_effect'] = float(np.mean([r[dk + '_effect'] for r in sub]))
        level_rows.append(row)
    _write(TAB / 'mech30_by_level.csv', level_rows)
    print(f'[mech30] wrote by_level ({len(level_rows)} levels)')

    # --- by category -------------------------------------------------------
    cat_rows = []
    cats = sorted({r['category'] for r in cell_rows if r['category']})
    for cat in cats:
        sub = [r for r in cell_rows if r['category'] == cat]
        row = {'category': cat, 'n_cells': len(sub),
               'n_hosts': len(set(r['host'] for r in sub)),
               'bare_median_log10err': float(np.mean([r['bare_median_log10err'] for r in sub])),
               'intervention_rate': float(np.mean([r['intervention_rate'] for r in sub])),
               'dec_mean': float(np.mean([r['dec_median'] for r in sub])),
               'dec_pos_cells': float(np.mean([1 if r['dec_median'] > 0 else 0 for r in sub]))}
        for dk in DESC_KEYS:
            row[dk + '_effect'] = float(np.mean([r[dk + '_effect'] for r in sub]))
        cat_rows.append(row)
    _write(TAB / 'mech30_category.csv', cat_rows)
    print(f'[mech30] wrote category ({len(cat_rows)} categories)')

    # --- category x level --------------------------------------------------
    cl_rows = []
    for cat in cats:
        for lv in (0, 1, 2, 3):
            sub = [r for r in cell_rows if r['category'] == cat
                   and LEVELS.get(r['host']) == lv]
            if not sub:
                continue
            cl_rows.append({
                'category': cat, 'level': lv, 'n_cells': len(sub),
                'intervention_rate': float(np.mean([r['intervention_rate'] for r in sub])),
                'dec_mean': float(np.mean([r['dec_median'] for r in sub])),
                'dec_pos_cells': float(np.mean([1 if r['dec_median'] > 0 else 0 for r in sub])),
            })
    _write(TAB / 'mech30_category_level.csv', cl_rows)
    print(f'[mech30] wrote category_level ({len(cl_rows)} rows)')


def _write(path, rows):
    if not rows:
        return
    cols = list(rows[0].keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


if __name__ == '__main__':
    main()

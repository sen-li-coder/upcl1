# -*- coding: utf-8 -*-
"""UPCL pilot experiment driver.

Usage
-----
    python run_upcl_pilot.py --quick              # 2 hosts x 2 funcs x 2 runs
    python run_upcl_pilot.py                      # full D=10 pilot
    python run_upcl_pilot.py --config no_minimal  # ablation
"""
import argparse
import os
import sys
import time
from datetime import timedelta

import numpy as np

from upcl_experiment import UPCLPairedExperiment, get_config

HOSTS = ['DE/rand/1', 'JADE', 'SHADE', 'L-SHADE', 'CoBiDE', 'jSO']
FUNCS = ['Sphere', 'Rastrigin', 'Ackley', 'Rosenbrock',
         'Schwefel', 'Griewank', 'Levy']

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dim', type=int, default=10)
    ap.add_argument('--runs', type=int, default=8)
    ap.add_argument('--evals', type=int, default=20000)
    ap.add_argument('--config', type=str, default='default')
    ap.add_argument('--tag', type=str, default=None)
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--hosts', type=str, default=None,
                    help='comma separated subset of hosts')
    ap.add_argument('--funcs', type=str, default=None,
                    help='comma separated subset of functions')
    args = ap.parse_args()

    hosts, funcs = HOSTS, FUNCS
    runs, evals = args.runs, args.evals
    if args.hosts:
        hosts = [h.strip() for h in args.hosts.split(',') if h.strip()]
    if args.funcs:
        funcs = [f.strip() for f in args.funcs.split(',') if f.strip()]
    if args.quick:
        hosts, funcs, runs, evals = HOSTS[:2], FUNCS[:2], 2, 4000

    tag = args.tag or args.config
    out = os.path.join(ROOT, 'results', f'upcl_D{args.dim}_{tag}')

    print(f"UPCL pilot :: D={args.dim}, {runs} runs, max_evals={evals}, "
          f"config={args.config}")
    print(f"{len(hosts)} hosts x {len(funcs)} funcs x {runs} runs x 2 arms "
          f"= {len(hosts)*len(funcs)*runs*2} runs")
    print(f"Output: {out}")
    print("=" * 96)

    t0 = time.time()
    exp = UPCLPairedExperiment(
        dim=args.dim, n_runs=runs, max_evals=evals,
        host_names=hosts, func_names=funcs,
        upcl_config=get_config(args.config),
        results_dir=out,
    )
    exp.run_all(verbose=True)
    print(f"Elapsed: {timedelta(seconds=int(time.time()-t0))}")
    print(f"Saved: {out}")


if __name__ == '__main__':
    main()

"""Resume the archived UAV experiment to 30 paired runs with live progress.

    python -u src/run_uav_live.py --plan
    python -u src/run_uav_live.py --workers 12

All run_uav options can be overridden on the command line.
"""
import os
import sys

from run_uav import main


if __name__ == '__main__':
    defaults = ['--runs', '30', '--evals-mult', '500', '--scenario', 'intercept',
                '--workers', str(max(1, min(8, (os.cpu_count() or 2) - 1))),
                '--code-stack', 'legacy-20261011', '--progress']
    raise SystemExit(main(defaults + sys.argv[1:]))

# -*- coding: utf-8 -*-
"""§5.5 案例轨迹渲染（图 5-7 及逐任务代表轨迹）。

从 ``results/apps/raw/uav_intercept/D30/*.json`` 读 bare/full 两臂的
``best_x``，用与 ``run_uav.py`` 完全一致的 seed（20240000）重建环境，
复用 ``render_sandtable.render_sandtable`` 渲染二维山地沙盘 + 轨迹叠加，
直观展示 UPCL 干预如何改变飞行路线。

用法：:

    # 单个 cell（默认行为，输出 fig_uav_trajectory_<host>_F<fid>.png）
    python src/plot_uav_trajectory.py --host NL-SHADE-RSP --fid 1

    # 逐任务 3x2 轨迹图集：每任务取 uav_task_rank.csv 的第 1 / 中位 / 末位名次
    # 为代表（列），行为「无地形背景」与「有地形背景」两种底图，共 4 张图集，
    # 输出 fig_uav_traj_F<fid>.png
    python src/plot_uav_trajectory.py --grid
"""
import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import render_sandtable as RS                # noqa: E402
from opponents import make_opponent           # noqa: E402
from uav_adversarial import get_uav_problem, SCENARIO_DIMS  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'apps' / 'raw'
TAB = ROOT / 'results' / 'apps' / 'tables'
FIG = ROOT / 'results' / 'apps' / 'figures'
SEED_BASE = 20240_000

# 两臂在图集中的显示名（配色见 render_sandtable.ARM_COLORS）
ARM_LABEL = {'bare': 'bare', 'full': 'UPCL'}


def load_cell(host, fid, scenario='intercept'):
    """读取一个 cell 的 json（宿主 × 任务）。"""
    dim = SCENARIO_DIMS[scenario]
    cell_path = (RAW / f'uav_{scenario}' / f'D{dim}'
                 / f'{host.replace("/", "-")}__F{fid}.json')
    if not cell_path.exists():
        raise SystemExit(f'missing cell: {cell_path}')
    with open(cell_path, encoding='utf-8') as fh:
        return json.load(fh)


def solve_pair(cell, run=0):
    """取一次运行中两臂的 ``best_x``，返回 [(arm, x), ...]。"""
    rec = cell['runs'][run]
    out = []
    for arm in ('bare', 'full'):
        rec_arm = rec.get(arm)
        if isinstance(rec_arm, dict) and 'best_x' in rec_arm:
            out.append((arm, np.asarray(rec_arm['best_x'], float)))
    if not out:
        raise SystemExit('no best_x found for bare/full')
    return out


def render_cell(host, fid, run=0, scenario='intercept', difficulty='L1',
                out=None, title=None, dpi=170, figsize=(7.6, 7.2)):
    """把一个 cell 的两臂轨迹渲染成张量图并落盘，返回输出路径。"""
    cell = load_cell(host, fid, scenario=scenario)
    solutions = solve_pair(cell, run=run)

    # 复现 run_uav.py 的环境（同一 seed 才对应同一地形/对手布局）
    opp = make_opponent(difficulty, drl_algo='es', seed=SEED_BASE)
    problem = get_uav_problem(scenario, dim=SCENARIO_DIMS[scenario], fid=fid,
                              seed=SEED_BASE, opponent=opp)

    FIG.mkdir(parents=True, exist_ok=True)
    if out is None:
        out = FIG / (f'fig_uav_trajectory_{host.replace("/", "-")}'
                     f'_F{fid}.png')
    out = Path(out)
    RS.render_sandtable(
        problem, solutions, out_png=str(out),
        title=title or f'{host}  F{fid}  bare vs full (run {run})',
        dpi=dpi, figsize=figsize)
    return out


def pick_by_rank(fid):
    """某任务的代表宿主：按该任务名次取第 1 / 中位 / 末位。

    返回 ``[(rank, host, composite, cec_rank), ...]``。
    """
    table = TAB / 'uav_task_rank.csv'
    if not table.exists():
        raise SystemExit(f'missing table: {table}')
    with open(table, encoding='utf-8', newline='') as fh:
        rows = [r for r in csv.DictReader(fh) if int(r['fid']) == fid]
    if not rows:
        raise SystemExit(f'no rank rows for F{fid}')
    by_rank = {int(r['task_rank']): r for r in rows}
    n = max(by_rank)
    slots = sorted({1, (n + 1) // 2, n})
    return [(rk, by_rank[rk]['host'], by_rank[rk]['task_composite'],
             by_rank[rk]['cec_rank']) for rk in slots]


def render_task_grid(fid, run=0, scenario='intercept', difficulty='L1',
                     out=None, dpi=170):
    """某任务三档名次（第 1 / 中位 / 末位）代表算法的 3x2 轨迹图集。

    列为三档名次，行为两种底图：上排去掉地形背景（只留 200 m 参考网格与
    地物符号），下排把同一组航线叠在地形阴影与等高线上，从而把「航线几何」
    与「地形纹理」分开看。3 列 x 2 行使图集横排，插入正文时按整栏宽度排版
    而不占满一整页。两臂共享同一场景与随机种子，输出
    ``fig_uav_traj_F<fid>.png``，返回输出路径。
    """
    opp = make_opponent(difficulty, drl_algo='es', seed=SEED_BASE)
    problem = get_uav_problem(scenario, dim=SCENARIO_DIMS[scenario], fid=fid,
                              seed=SEED_BASE, opponent=opp)
    sols_by_rank, col_titles = [], []
    for rank, host, _comp, _cec in pick_by_rank(fid):
        cell = load_cell(host, fid, scenario=scenario)
        sols = [(ARM_LABEL.get(arm, arm), x)
                for arm, x in solve_pair(cell, run=run)]
        sols_by_rank.append(sols)
        col_titles.append(f'rank {rank} \u00b7 {host}')
    # 两行即两种底图、三列即三档名次
    rows = [[(sols, False) for sols in sols_by_rank],
            [(sols, True) for sols in sols_by_rank]]
    out = Path(out or FIG / f'fig_uav_traj_F{fid}.png')
    RS.render_sandtable_matrix(
        problem, rows, out_png=str(out), dpi=dpi,
        col_titles=col_titles,
        row_titles=['Terrain background removed', 'With terrain background'],
        suptitle=f'Task F{fid}: representative trajectories '
                 f'(bare vs UPCL, run {run})')
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--host', default='NL-SHADE-RSP')
    ap.add_argument('--fid', type=int, default=1)
    ap.add_argument('--run', type=int, default=0)
    ap.add_argument('--scenario', default='intercept')
    ap.add_argument('--difficulty', default='L1')
    ap.add_argument('--grid', action='store_true',
                    help='逐任务 3x2 轨迹图集（列=名次 1 / 中位 / 末位，'
                         '行=无地形背景 / 有地形背景），'
                         '共 4 张 fig_uav_traj_F<fid>.png')
    ap.add_argument('--fids', default='1,2,3,4',
                    help='--grid 模式下要渲染的任务，逗号分隔')
    args = ap.parse_args(argv)

    if not args.grid:
        out = render_cell(args.host, args.fid, run=args.run,
                          scenario=args.scenario,
                          difficulty=args.difficulty)
        print(f'[plot_uav_trajectory] {out}')
        return

    fids = [int(v) for v in args.fids.split(',') if v.strip()]
    for fid in fids:
        out = render_task_grid(fid, run=args.run, scenario=args.scenario,
                               difficulty=args.difficulty)
        print(f'[plot_uav_trajectory] {out}')


if __name__ == '__main__':
    main()

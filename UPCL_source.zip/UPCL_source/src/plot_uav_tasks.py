# -*- coding: utf-8 -*-
"""§5.1 任务场景图：F1-F4 四个任务的俯视沙盘。

每个任务一张战场景图，画出任务目标（蓝方自左下起飞/推进至右上基地）与红方
四层防御（雷达探测圈、拦截机停机坪、防空车、巡逻兵与禁飞区），使四个任务的
差别（拦截机数量、禁飞区、拦截机速度）在图上可直接读出，而不必只依赖表格。

复用 ``render_sandtable.py`` 的地形晕渲、军事图标与 ``load_problem`` 的 seed
约定（``20240000``，与 ``run_uav.py`` / ``plot_uav_trajectory.py`` 一致），
因此图形与实验跑的是同一套环境。

产出（``results/apps/figures/``）：
    fig_uav_tasks.png         F1-F4 四任务的 2x2 组图，子图标号 (a)-(d)
    fig_uav_task_F{1..4}.png  各任务单图（备用于需要独立成图的场合）

用法：``python src/plot_uav_tasks.py``
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt                                            # noqa: E402
from matplotlib.lines import Line2D                                        # noqa: E402
from matplotlib.patches import FancyArrowPatch                             # noqa: E402

import render_sandtable as RS                                              # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'results' / 'apps' / 'figures'

SEED_BASE = 20240_000        # 与 run_uav.py 的实验 seed 一致

GREEN = '#1a7f37'
INFANTRY = '#8c6d1f'
RED = '#d62728'

# 单张面板与组图的版面（英寸）；组图纵横比控制在 FIG_MAX_H_IN/FIG_WIDTH_IN 之内
PANEL_FIGSIZE = (5.6, 5.2)
GRID_FIGSIZE = (10.8, 9.6)


def _descriptor(problem):
    """由环境本身推出该任务相对基线增加了什么（不写死任务表）。"""
    cfg, env = problem.cfg, problem.env
    bits = []
    if len(env.interceptors0) > 1:
        bits.append('coordinated interception')
    if env.nofly.size:
        bits.append('restricted airspace')
    return 'baseline' if not bits else ' + '.join(bits)


def _draw_objective(ax, env):
    """任务目标：蓝方自集结区突防/推进到基地。"""
    sx = float(np.mean([p[0] for p in env.starts]))
    sy = float(np.mean([p[1] for p in env.starts]))
    ix = float(np.mean([p[0] for p in env.infantry0]))
    iy = float(np.mean([p[1] for p in env.infantry0]))
    bx, by = float(env.base[0]), float(env.base[1])

    ax.add_patch(FancyArrowPatch(
        (sx, sy), (bx - 70, by - 70), arrowstyle='-|>', mutation_scale=20,
        linewidth=2.0, linestyle=(0, (6, 4)), color=GREEN, alpha=0.5,
        shrinkA=22, shrinkB=26, zorder=5))
    ax.add_patch(FancyArrowPatch(
        (ix, iy), (bx - 110, by - 150), arrowstyle='-|>', mutation_scale=16,
        linewidth=1.5, linestyle=(0, (5, 4)), color=INFANTRY, alpha=0.6,
        shrinkA=16, shrinkB=24, zorder=5))


def _draw_task(ax, problem, fid):
    """把一个任务的战场画到 ``ax`` 上，并写出任务目标与参数。"""
    cfg, env = problem.cfg, problem.env
    RS._render_terrain(ax, env, vert_exag=1.5)
    handles, labels = RS._render_features(ax, env, cfg, show_aa_range=True)
    _draw_objective(ax, env)

    for (px, py) in env.patrol0:
        ax.plot([px], [py], marker='o', color=RED, markersize=2.2,
                markeredgewidth=0, alpha=0.7, zorder=4)

    n_int = len(env.interceptors0)
    for (hx, hy) in env.interceptors0:
        ax.annotate(f'$\\times{n_int}$', xy=(hx, hy), xytext=(hx - 80, hy + 64),
                    fontsize=7.5, color='#5b2a00', ha='center', zorder=9)

    bx, by = float(env.base[0]), float(env.base[1])
    info = ['$\\bf{Objective}$',
            f'{cfg.n_drones} UAVs: penetrate low and bomb the base',
            f'{cfg.n_infantry} infantry: advance and capture it',
            '',
            f'interceptors: {n_int}',
            f'no-fly zones: {int(env.nofly.shape[0])}',
            f'interceptor speed: {cfg.interceptor_speed:.0f} m/step',
            f'difficulty: {_descriptor(problem)}']
    ax.annotate('\n'.join(info), xy=(0.015, 0.985), xycoords='axes fraction',
                fontsize=7, ha='left', va='top', zorder=9, linespacing=1.35,
                bbox=dict(boxstyle='round,pad=0.35', facecolor='white',
                          edgecolor='#777777', linewidth=0.6, alpha=0.88))
    ax.annotate(f'base\n({bx:.0f}, {by:.0f})', xy=(bx - 84, by + 62),
                fontsize=7.5, color=RED, ha='center', va='bottom', zorder=9,
                bbox=dict(boxstyle='round,pad=0.22', facecolor='white',
                          edgecolor=RED, linewidth=0.7, alpha=0.9))

    ax.set_xlim(0, cfg.map_w)
    ax.set_ylim(0, cfg.map_h)
    ax.set_aspect('equal', adjustable='box')
    ax.set_xlabel('X (m)', fontsize=8)
    ax.set_ylabel('Y (m)', fontsize=8)
    ax.tick_params(labelsize=7)
    ax.set_title(f'({chr(96 + fid)})  F{fid}: {_descriptor(problem)}',
                 fontsize=9.5, pad=5)
    return ax, handles, labels


def _legend(handles, labels):
    handles = list(handles) + [
        Line2D([], [], marker='o', color=RED, markersize=3.5, linestyle='none'),
        Line2D([], [], color=GREEN, linewidth=2.0, linestyle=(0, (6, 4))),
        Line2D([], [], color=INFANTRY, linewidth=1.5, linestyle=(0, (5, 4))),
    ]
    labels = list(labels) + ['Patrol soldiers', 'UAV objective',
                             'Infantry objective']
    return handles, labels


def main():
    FIG.mkdir(parents=True, exist_ok=True)
    problems = {fid: RS.load_problem(fid=fid, seed=SEED_BASE) for fid in (1, 2, 3, 4)}

    # --- 组图 (a)-(d) ---------------------------------------------------
    fig, axes = plt.subplots(2, 2, figsize=GRID_FIGSIZE)
    ref = None
    for ax, fid in zip(axes.ravel(), (1, 2, 3, 4)):
        _ax, h, l = _draw_task(ax, problems[fid], fid)
        if ref is None:
            ref = (h, l)
    handles, labels = _legend(*ref)
    fig.legend(handles, labels, loc='lower center', ncol=6, frameon=False,
               fontsize=8, bbox_to_anchor=(0.5, 0.004),
               handler_map={RS._IconHandle: RS._IconHandler()})
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    out = FIG / 'fig_uav_tasks.png'
    fig.savefig(out, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f'[plot_uav_tasks] {out}')

    # --- 四张单图（备用） ------------------------------------------------
    for fid in (1, 2, 3, 4):
        fig, ax = plt.subplots(figsize=PANEL_FIGSIZE)
        _ax, h0, l0 = _draw_task(ax, problems[fid], fid)
        h, l = _legend(h0, l0)
        ax.legend(h, l, loc='lower right', fontsize=6.5, framealpha=0.9,
                  handlelength=1.4, borderaxespad=0.4,
                  handler_map={RS._IconHandle: RS._IconHandler()})
        fig.tight_layout()
        out = FIG / f'fig_uav_task_F{fid}.png'
        fig.savefig(out, dpi=200, bbox_inches='tight')
        plt.close(fig)
        print(f'[plot_uav_tasks] {out}')


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""UPCL 手稿第五部分的中文翻译版：无人机对抗拦截真实应用。

本节按场景自身的线索独立分析算法在该场景中的表现：场景与复杂度、算法输入
与配置、评估指标、结果呈现与结果解读；不从基准实验迁移任何结论。

数据与数值字段与英文版 ``upcl_part_app.py`` 完全一致：两者都从
``results/apps/tables`` 读取同一批表格、从 ``docs/figures`` 读取同一批图片
（经 ``paper_figures`` 登记），只有人类可读的正文与图题标签切换为中文。
"""
import numpy as np
from scipy import stats

import upcl_part_app as EN
import paper_figures as PFG

_f = EN._f
_rows = EN._rows
_nt = EN._nt
GROUP_ORDER = EN.GROUP_ORDER

GROUP_ZH = {
    'task': '任务达成',
    'safety': '规避安全',
    'path': '路径质量',
    'constraint': '约束满足',
    'infantry': '空地协同',
    'patrol': '敌方巡逻',
}
KEY_METRIC_ZH = EN.KEY_METRIC_ZH
task_metrics_table = EN.task_metrics_table
_cell_rows = EN._cell_rows
_median_by_task = EN._median_by_task
_spread_by_task = EN._spread_by_task
_delta_stats = EN._delta_stats

# ---------------------------------------------------------------------------
# 逐任务拆分的读数辅助（§5.4）
# ---------------------------------------------------------------------------
TASK_FIDS = ('1', '2', '3', '4')
TASK_LABEL = {
    '1': '5.4.1  F1 基线任务：1 架拦截机、无禁飞区',
    '2': '5.4.2  F2 受限空域：1 架拦截机 + 1 个禁飞区',
    '3': '5.4.3  F3 协同拦截：2 架拦截机、无禁飞区',
    '4': '5.4.4  F4 复合难度：2 架拦截机 + 禁飞区 + 更快',
}
# 每个任务内部代表轨迹的三档名次：第 1 名 / 中位 / 末位
REP_SLOTS = ('top', 'mid', 'bottom')
REP_CN = {'top': '第 1 名', 'mid': '中位列', 'bottom': '末位'}
# 每任务一张表里的关键指标（stem, 小数位）
TASK_METRICS = [
    ('composite_pct', 2), ('n_arrived', 0), ('n_lost', 0),
    ('min_dist', 0), ('path_length', 0),
]


def _task_rank_rows(fid):
    """该任务的名次表：``{task_rank: row}``。"""
    return {int(r['task_rank']): r
            for r in EN._rows('uav_task_rank.csv') if r['fid'] == fid}


def _rep_ranks(fid):
    """该任务的三档代表名次（第 1 / 中位 / 末位），随宿主数自适应。"""
    by = _task_rank_rows(fid)
    n = max(by)
    return sorted({1, (n + 1) // 2, n})


def _task_summary(fid):
    """该任务的分组增益：``{group: row}``（来自 uav_task_summary.csv）。"""
    return {r['metric_group']: r for r in EN._rows('uav_task_summary.csv')
            if r['fid'] == fid}


def _task_pool(fid, metric, arm='bare'):
    """该任务上某指标的池中位数（29 个宿主 cell 中位数的中位数）。"""
    for r in EN._rows('uav_task_metrics.csv'):
        if r['fid'] == fid and r['metric'] == metric and r['arm'] == arm:
            return float(r['pool_median'])
    return float('nan')


def _spread(fid, metric, arm='bare'):
    """该任务上某指标的池内分布（29 个宿主 cell 中位数）。"""
    out = []
    for r in EN._rows('uav_metric_cells.csv'):
        if (r.get('scenario') == 'intercept' and r['fid'] == fid
                and r['arm'] == arm):
            try:
                out.append(float(r[f'{metric}_median']))
            except (KeyError, TypeError, ValueError):
                continue
    return out


def _cell_metric(fid, host, metric, arm='bare'):
    """某任务 / 宿主 / 臂上某指标的中位数。"""
    for r in EN._rows('uav_metric_cells.csv'):
        if (r.get('scenario') == 'intercept' and r['fid'] == fid
                and r['host'] == host and r['arm'] == arm):
            try:
                return float(r[f'{metric}_median'])
            except (KeyError, TypeError, ValueError):
                return float('nan')
    return float('nan')


def _rank_by_fid():
    return {r['fid']: r for r in EN._rows('uav_rank_by_fid.csv')}


def _arrow(b, f, nd=0):
    """``bare`` 与 ``full`` 的并列读数：``12 -> 15``。"""
    return f'{_f(b, nd)} $\\to$ {_f(f, nd)}'


def _dir_word(f, b, up='升高', down='降低', flat='不变'):
    """两臂比较的方向词，数值相近时读作不变。"""
    if not (b == b and f == f) or abs(b) < 1e-12:
        return '不变'
    if abs(f - b) / abs(b) < 0.01:
        return flat
    return up if f > b else down


def build(P, S):
    P.mark_part_base()
    _scenario(P)
    _setup(P)
    _metrics(P)
    _results(P)
    _discussion(P)


# ===========================================================================
# 5.1  场景描述与复杂度
# ===========================================================================
def _scenario(P):
    P.h1('5  真实应用：无人机对抗拦截场景下的算法表现')

    P.para(
        '第 4 节的基准研究回答的是各变体在合成函数上的行为。本节提出的是'
        '另一个问题：在一个具体而困难的应用上，这些算法究竟做了什么，它们'
        '之间哪些差异真正保留了下来？本节完全围绕场景自身展开——它的几何、'
        '约束、成本以及它产生的结局——不迁移基准研究的任何结论。')

    P.h2('5.1  场景描述与复杂度')

    P.para(
        '在合成 $1000\\,\\text{m}\\times 1000\\,\\text{m}$ 的三维山地对抗场景中，'
        '地形由若干高斯峰叠加于低频起伏之上生成，起伏幅度约 $220\\,\\text{m}$；'
        '山谷与山脊既提供了低空突防走廊，也带来了视线遮挡。蓝方'
        '编成 $3$ 架无人机与 $3$ 名步兵的陆空协同小队：无人机自 $(60,60)$ 起飞，'
        '低空突防至 $(820,820)$ 的军事基地实施轰炸，步兵沿地面推进并在到达后'
        '占领基地。红方布设四层防御：部署于 $(500,500)$ 的预警雷达（探测半径 '
        '$520\\,\\text{m}$）触发拦截机；$1\\!-\\!2$ 架直升机拦截机在东南停机坪'
        '待命（速度 $12\\!-\\!14\\,\\text{m/步}$，转弯率 $0.35\\,\\text{rad/步}$，'
        '捕获锥受地形遮挡影响）；$2$ 辆地面防空车（防空半径 $260\\,\\text{m}$，'
        '导弹转弯次数有限）；以及 $20$ 名守卫基地的巡逻兵。任务难度随拦截机数量、'
        '禁飞区与拦截机速度递增，由此得到表 {t1} 所列的 F1-F4 四个任务，'
        '图 {f1} 给出它们共享的地形，图 {f2} 将它们并列画出。',
        )
    t1 = _nt(P)
    P.figure(
        PFG.fig('uav_sandbox'),
        '拦截对抗场景的三维沙盘：子图 (a)-(d) 为同一张 '
        '$1000\\,\\text{m}\\times 1000\\,\\text{m}$ 山地地形的四个相机方位视图，'
        '各变体的每一次 rollout 都在该地形上进行。',
        note=f'各子图的方位徽标给出该视角下的地图朝向。绿色线框半球为预警雷达'
             f'的立体探测范围，半透明球体为球形禁飞区，橙色圆盘为守卫基地的'
             f'红方巡逻兵视野范围，蓝色线框罩为飞行高度上限；地形与实体布局'
             f'由固定随机种子一次性生成，不含任何单次运行的信息。')
    P.para(
        '两张图都由同一种子生成，不携带任何单次运行的信息：地形、雷达、禁飞区'
        '与巡逻部署属于场景本身而不属于结果，因此子图之间的差别只可能是任务的'
        '差别，不会是样本的差别。场景的难度由三个特征设定。其一是地形起伏，它'
        '使飞行成为三维问题：每条航线都必须高于地形跟随高度，而爬升计入回报；'
        '山脊还遮挡视线，拦截机的捕获锥被地形阻断，因此低空航线并不只是更长的'
        '一条。其二是位于中央的雷达，它是一个探测半径的半球而不是禁飞体：穿越'
        '它触发拦截机出动，这也正是第二个任务里禁飞区要在同一张图上单独画出的'
        '原因。其三是巡逻兵的视野圆盘，地面那一半任务因此既是路径问题也是覆盖'
        '问题，橙色圆盘正是"地面绕行可以比更短的路更值"的由来。下一张图把四个'
        '任务放在同一张地图上，于是四个子图应读作同一场景的四种设置，而不是'
        '四个场景。四个任务的编码方式相同：每架无人机与每名士兵的航点数量固定，'
        '因此子图之间航线的差别是坐标值的差别，而不是航点多少的差别，这一固定'
        '分辨率也是两臂之间可以逐点比较的前提。')
    P.figure(PFG.fig('uav_tasks'),
             '同一张 $1000\\,\\text{m}\\times 1000\\,\\text{m}$ 地图上四个任务的'
             '俯视图。绿色虚线箭头为无人机向 $(820,820)$ 基地的低空突防与轰炸'
             '航线，橄榄色虚线箭头为后续占领基地的步兵推进方向。四个子图之间'
             '仅红方防御不同：拦截机数量、禁飞区与拦截机速度。')

    P.para(
        '四个任务的决策变量编码方式相同。每架无人机由 $K=2$ 个中段三维航点 '
        '$(x,y,z)$ 描述，每名士兵由 $K=2$ 个'
        '地面航点 $(x,y)$ 描述，均从连续编码 $[-1,1]^{D}$ 解码；高度为地形跟随'
        '高度之上的爬升偏置 $[0,100]\\,\\text{m}$，即 '
        '$z=\\min(z_{\\text{ground}}+h_{\\text{clear}}+z_{\\text{off}},z_{\\max})$，'
        '其中 $h_{\\text{clear}}=30\\,\\text{m}$、$z_{\\max}=460\\,\\text{m}$，'
        '故 $D=3\\cdot 2\\cdot 3+3\\cdot 2\\cdot 2=30$。确定性逐步推演（最多 '
        '$220$ 步）返回终止编队状态；蓝方最小化 $f(x)=-R(x)$，其中奖励为')
    P.equation(
        r'R = w_a n_{\mathrm{arr}} - w_l n_{\mathrm{lost}} - w_c '
        r'n_{\mathrm{crash}} - w_t n_{\mathrm{unf}} '
        r'- w_n n_{\mathrm{nofly}} - w_b n_{\mathrm{bound}} '
        r'- w_{co} n_{\mathrm{col}} - w_p(\tfrac{L}{L_{\mathrm{direct}}}-1) '
        r'- w_{cl}\tfrac{z_{\mathrm{climb}}}{A} '
        r'+ w_s \min(1,\tfrac{d_{\min}}{4R_{\mathrm{cap}}}) '
        r'+ w_b^{+} b + w_i n_{\mathrm{inf,arr}} - w_{il} n_{\mathrm{inf,lost}}'
        r'+ w_k n_{\mathrm{kill}} + w_s^{+}\mathbb{I}[\mathrm{success}],')
    P.para(
        '其中 $n_{\\text{arr}}$/$n_{\\text{lost}}$/$n_{\\text{crash}}$/'
        '$n_{\\text{unf}}$ 分别统计到达/被击落/坠毁/未完成的无人机数，'
        '$n_{\\text{nofly}}$ 与 $n_{\\text{bound}}$ 为累计越禁飞区与越界步数，'
        '$n_{\\text{col}}$ 为机间碰撞数，'
        '$n_{\\text{inf,arr}}/n_{\\text{inf,lost}}$ 为步兵到达与损失，'
        '$n_{\\text{kill}}$ 为击杀巡逻兵数。$L$ 为实际航程，'
        '$L_{\\text{direct}}$ 为各机起点到目标的直线距离之和，故 '
        '$L/L_{\\text{direct}}-1$ 为相对绕行量；$z_{\\text{climb}}$ 为沿航程的'
        '累计爬升，$A=220\\,\\text{m}$ 是将其归一化的地形起伏。'
        '$d_{\\min}$ 为到任一拦截机的最小距离，$R_{\\text{cap}}=55\\,\\text{m}$ '
        '为其捕获半径，故安全项在拦截机处于四倍捕获半径之外时饱和。'
        '$b\\in[0,1]$ 为轰炸进度，$\\mathbb{I}[\\text{success}]$ 为基地摧毁'
        '指示；十五个权重 $w_\\bullet$ 的含义与取值列于表 {t2}。运动学硬约束（转弯 '
        '$|\\Delta\\theta|\\le 0.25$ rad/步、爬升 $|\\Delta z|\\le 25$ m/步、'
        '高度与速度）在仿真器内强制执行，禁飞区、地图边界、机间碰撞与能量限制'
        f'则作为逐步或逐次惩罚并入目标；由此得到的函数景观对四个任务分别绘于图 '
        f'{P.fig_no + 1}。',
        )
    t2 = _nt(P)
    P.figure(PFG.fig('uav_landscape_3d'),
             '$f(x)$ 的函数景观（表 {t1} 的四个任务）：(a) F1 基线、'
             '(b) F2 受限空域、(c) F3 协同拦截、(d) F4 复合难度（两架拦截机 + '
             '禁飞区 + 更快拦截机）。每幅面板扫描 '
             '$x_1,x_2\\in[-1,1]^2$，其余 28 维固定于 NL-SHADE-RSP 为该任务求得'
             '的近优解；各面板自带纵轴刻度，故只能比较形态、不能比较高度。')
    P.para(
        '算法在这里面对的目标函数是一个黑箱，它具备四个特性，决定了算法在这里'
        '能做与不能做什么。其一，非凸且多峰：拦截、禁飞区与惩罚都是事件驱动的'
        '分段结构，会突然打开或关闭走廊。其二，非光滑且不可微：触发式惩罚使 '
        '$f$ 发生阶跃，因而不存在梯度信号，编码上的一个微小移动就可能让整条'
        '推演翻转。其三，隐式约束：运动学硬约束在仿真器内部强制执行，而空域与'
        '安全要求仅以惩罚形式进入目标。其四，昂贵：单次推演约 $20.7$ ms，'
        '因此评估预算在绝对量上很小，可做的重启次数有限。事件驱动的非凸性、'
        '非光滑性、隐式约束与高昂成本——正是 §5.4 比较各算法时所依据的四个条件。')

    P.para(
        '该场景属于一个界定清晰的类别，说明它属于哪一类是有意义的，因为类别'
        '决定了结果能被读作什么证据。无人机任务级规划通常被表述为在含威胁地形'
        '上的路径或轨迹优化，综述按规划器而非应用来组织这一领域：图搜索、采样'
        '式运动规划与群体元启发式 [@OTTO18][@ZHAO18]，而当代价非凸且不连续时，'
        '后两类占主导 [@LAVALLE06][@KARAMAN11]。遗传与群体规划器恰被用于目标'
        '函数所编码的"路径长度—威胁暴露"权衡 [@ROBERGE13][@BESADA10]，而集群'
        '协同规划则再加上四个任务所变动的分配与同步层 [@ZHEN20]。配送与覆盖'
        '路径研究提供了步兵那一半任务所模拟的"基地—服务点"结构 '
        '[@DORLING17][@ZENG16]。红方则是一个带界控与捕获域的追逃问题：其微分'
        '博弈表述早于它的计算处理数十年 [@ISAACS65][@SHIMA02]，其概率变体由'
        '可达性计算求解 [@VIDAL02]；而它的学习型对应物如今已在相当的双人设定中'
        '经自博弈训练到超人水平 [@SILVER16][@SILVER18]。因此作为模型，场景'
        '本身少有新意；本实验增加的不是新的任务表述，而是一个固定、种子可复现'
        '的实例，在其上以同一预算比较 $29$ 个变体。')

    P.table_caption('拦截场景的任务设置（$D=30$）。')
    P.table(['任务', '拦截机', '禁飞区', '速度', '难度'],
            [['F1', '1', '无', '12', '基线'],
             ['F2', '1', '1', '12', '+ 受限空域'],
             ['F3', '2', '无', '12', '+ 协同拦截'],
             ['F4', '2', '1', '14', '多拦截机 + 禁飞区 + 更快']],
            widths=[0.8, 1.3, 1.0, 0.9, 3.2], align='lllll')

    P.table_caption('拦截场景的目标权重。')
    P.table(['符号', '含义', '值', '符号', '含义', '值'],
            [['$w_a$', '单机到达', '100', '$w_p$', '绕行惩罚', '20'],
             ['$w_l$', '单机损失', '80', '$w_{cl}$', '爬升能耗', '30'],
             ['$w_c$', '单机坠毁', '90', '$w_s$', '安全裕度', '15'],
             ['$w_t$', '未完成', '30', '$w_b^{+}$', '轰炸进度', '200'],
             ['$w_n$', '禁飞区/步', '20', '$w_i$', '步兵到达', '120'],
             ['$w_b$', '越界/步', '30', '$w_{il}$', '步兵损失', '100'],
             ['$w_{co}$', '机间碰撞', '40', '$w_k$', '击杀巡逻兵', '60'],
             ['-', '-', '-', '$w_s^{+}$', '整体成功', '150']],
            widths=[0.8, 1.7, 0.7, 0.8, 1.7, 0.7], align='llrllr')


# ===========================================================================
# 5.2  算法输入与配置
# ===========================================================================
def _setup(P):
    P.h2('5.2  算法在该场景中的输入与配置')

    P.para(
        '求解器为第 4 节的 $29$ 个 DE 变体：它们合起来覆盖了差分演化的主要设计'
        '维度，即固定参数与自适应参数规则、单一变异策略与策略集成、以及是否'
        '采用外部存档与种群规模缩减。所有变体通过同一接口接入场景：连续箱体 '
        '$[-1,1]^{30}$ 被解码为无人机与步兵航点，确定性推演返回的 $f(x)=-R(x)$ '
        '是求解器获得的唯一反馈；各变体保持自身的种群规模与参数规则，且均未针对'
        '本场景重新调参。每个变体运行两种配置——bare 臂（变体单独运行）与 full 臂'
        '（同一变体携带 UPCL 提议修正层，该层只作用于宿主提出的候选解，不改变其'
        '变异、交叉与种群调度）；两臂共享完全相同的随机种子序列，故两臂之间的任何'
        '差异都可归因于该层。每臂预算为 $500D=15{,}000$ 次评估，每个 cell'
        '（单个变体在单个任务上）以 $R=3$ 个独立种子重复。此处把预算固定为 '
        '$500D$ 是因为目标是一次 rollout 而不是基准函数，它比第 4 节的 '
        '$10^{4}D$ 小两个数量级；因此本节没有任何数值可与 CEC 的数字相比，'
        '本节所做的一切比较都发生在同一 cell 的两臂之间。')


# ===========================================================================
# 5.3  评估指标与结果呈现
# ===========================================================================
def _metrics(P):
    P.h2('5.3  评估指标与结果呈现方式')

    P.para(
        '一次运行给出的是轨迹而非标量误差，因此结局由推演终止时的编队状态计算出的 '
        '$27$ 项终止指标描述。这些指标归入六个语义族，见表 {t3}；每项指标的'
        '方向均固定于蓝方视角，故"更优"始终意味着对进攻方更有利的结局。')
    t3 = _nt(P)

    P.table_caption('27 项任务指标按语义分为六组。')
    P.table(['分组', '含义', '代表指标'],
            [['task', '任务达成', '任务成功、基地摧毁、到达数、基地血量'],
             ['safety', '规避安全', '无人机损失、到拦截机最小距离、首次被捕获时间'],
             ['path', '路径质量', '路径长度、飞行时间、路径效率、曲率、爬升'],
             ['constraint', '约束满足', '越界步数、禁飞区步数、坠毁数'],
             ['infantry', '空地协同', '步兵到达/损失、存活、血量、击杀巡逻兵'],
             ['patrol', '敌方巡逻', '巡逻兵存活、血量']],
            widths=[1.2, 2.3, 4.5], align='lll')

    ev0 = EN._event_row('all')
    P.para(
        f'场景定义的成功就是基地倒下，而它在 {int(ev0["n_runs"])} 次臂级试次中只发生 '
        f'{int(ev0["dest_k"])} 次，因此作为成功判据它对几乎每个变体、每条臂都读作零，'
        f'无法用于排序。结局因此改用一个分级量表，即综合成功率（composite success '
        f'rate, CSR），它是推演本就记录的三项百分比的加权均值：'
        f'基地血量被削去的比例、地面分队抵达基地的比例、巡逻兵力被击落的比例。'
        f'一半分数给终局目标，因为基地血量是场景唯一的胜负量；两个使能条件各占四分之一，'
        f'它们是达成目标的必要条件但本身并不充分。若某次运行摧毁基地、地面分队突入'
        f'并清空巡逻，则得 $100$ 分；存档中最强的 cell 平均为 ${EN.csr_peak()[0]:.1f}$，'
        f'说明量表并未饱和。权重是明示的选择而非拟合量，§5.4 给出三种替代权重下'
        f'它所产生的排序。')

    P.para(
        '由此产生三种呈现选择，原因是多指标结局无法用单一数值排序。其一，'
        '各变体按综合分比较：把四项主指标（综合成功率、到达数、损失数、路径长度）'
        '在变体池内标准化为 $z$ 分数，对"越小越好"的项取反后求和，因此综合分'
        '越大代表整体结局越好。综合分始终与四项主指标的中位数并列给出，而非单独'
        '出现，以便读者看到它的来源。其二，由于单一数值会掩盖结构，分组效应以'
        '池内均值与 $95\\%$ 置信区间报告，逐变体的符号一致性以运行级占比给出。'
        '其三，任务达成类事件以比率加 $95\\%$ 区间给出，而不以中位数给出：一个'
        '二值指标若其事件本身稀有，无论各变体差别多大，其中位数都恒为零，报告该'
        '中位数恰好掩盖了引入该指标所要暴露的差异，而比率及其区间仍然有信息量，'
        '并且可以跨任务直接比较。'
        '§5.4 的每项结果都附带其背后的量：表格给出数值与区间，轨迹图给出飞行形态。')


# ===========================================================================
# 5.4  逐任务结果与代表轨迹
# ===========================================================================
def _results(P):
    P.h2('5.4  逐任务结果与代表轨迹')

    P.para(
        '四个任务共享同一张地图、同一套编码与同一份预算，红方防御则逐级加强，'
        '因此把它们合并成一张排名表会掩盖最重要的事实：任务之间并不等价。'
        '本节改为逐任务呈现。每个任务给出三项内容：该任务上 $29$ 个变体的'
        '指标中位数（两臂并列）；该任务的两臂分组变化（按指标组给出均值、'
        '置信区间与符号一致性）；以及该任务三档名次（第 1 名、中位、末位）的'
        '代表飞行轨迹。轨迹图并置于同一图集中，行是三档名次，两列分别为去掉'
        '地形背景与叠加地形背景的同一组航线。四个任务的名次结构对照则合并到'
        f'后文的 $2\\times2$ 图组中。各变体的协议、指标定义与统计口径见 §5.2 与 '
        '§5.3，本节不再重复。')
    P.para(
        '本节报告的一切排序都是描述性的：在每格 $R=3$ 次运行下，成对差异在 '
        '$0.05$ 水平上并未被分辨，上文功效分析给出了要把终局事件的两倍差异'
        '分辨出来需要多少次运行，本节也不对"某变体在某任务上最好"作任何断言。')

    # --- 稀有事件的分辨率：任务达成类指标该怎么读 ------------------------
    ev_all = EN._event_row('all')
    ev_bare = EN._event_row('all', 'bare')
    plat = EN.plateau('all', 'bare')
    pw3 = EN.power('observe', runs=3)
    pw2 = EN.power('detect', ratio=2.0)
    pw3x = EN.power('detect', ratio=3.0)
    n_ev = int(ev_all['n_runs'])
    hp_pts = float(ev_all['base_hp_max'])
    aerial_pts = float(ev_all['aerial_dmg']) * hp_pts
    t_ev = _nt(P)
    P.para(
        f'在逐任务展开之前，先要说明"任务从未成功"这句话在本场景中究竟指什么，'
        f'因为抵达数是事件型计数器，而 CSR 是三个分量的加权均值，其中终局分量'
        f'在整个实验中只达成过一次。'
        f'表 {t_ev} 把这些事件按比率给出，并附 $95\\%$ Wilson 区间，'
        f'取该任务全部试次、两条臂合并。任务的空侧一半接近饱和：'
        f'{EN.rate_cell(ev_all, "air")} 的 {n_ev} 次试次中两架无人机都完成突防并投弹，'
        f'但只削去固定的 {aerial_pts:.0f} 点血量（满值 {hp_pts:.0f}），这正是'
        f'各任务上剩余血量中位数处处相同的原因。地侧一半并不饱和：'
        f'步兵抵达基地的比率只有 {EN.rate_cell(ev_all, "gnd")}，而后续伤害正由'
        f'这次抵达决定，因为抵达后的步兵会持续射击，空中伤害却只投送一次。'
        f'证据是严格的：{n_ev} 次试次中，血量低于"仅空中打击"水平的 '
        f'{int(ev_all["extra_k"])} 次，恰好就是地面分队也抵达基地的那 '
        f'{int(ev_all["extra_gnd_k"])} 次。基地被摧毁的比率为 '
        f'{EN.rate_cell(ev_all, "dest")}，全实验共 '
        f'{int(ev_all["dest_k"])} 次。因此二值成功指标是一个落在搜索可达范围之外的'
        f'阈值，其中位数恒为零是构造性的：在 bare 臂 {float(ev_bare["gnd_pct"]):.1f}% '
        f'的抵达率与每 cell $R=3$ 次运行下，即使所有变体表现完全相同，该指标的中位数'
        f'也有 {100 * float(pw3["median_zero"]):.0f}% 的 cell 为零，因而由这些'
        f'中位数再取池中位数必然为零，结局因此从下文起由表 {{t5}} 的分级 CSR 承载。'
        f'换成比率读，同样的证据给出的结论恰好与'
        f'"每个算法都失败"相反：决定性的子事件在 '
        f'{EN.rate_cell(ev_all, "gnd")} 的试次中被完成，约每六次一次。')
    P.table_caption('无人机拦截场景上任务达成类事件的比率（$95\\%$ Wilson 区间）。'
                    '每个比率为该任务全部试次中该事件发生的占比（两臂合并，'
                    '$R=3$ 次运行、$29$ 个变体）；基地损伤为同一批试次上基地血量'
                    '损失比例的均值。')
    P.table(EN.event_rate_headers(EN.EVENT_ZH), EN.event_rate_table(EN.EVENT_ZH),
            widths=[0.7, 0.75, 1.5, 1.5, 1.15, 1.05],
            align='lrrrrr', font_size=7.2)

    P.para(
        f'这些比率引出两个问题。第一，预算是否足够。对搜索真正面对的目标而言，'
        f'预算不是约束：把每次运行的最优解曲线按已消耗预算读数，bare 臂在消耗 '
        f'{100 * float(plat["t50"]):.1f}% 预算时已取得总改进的 $50\\%$、'
        f'{100 * float(plat["t90"]):.1f}% 时取得 $90\\%$、'
        f'{100 * float(plat["t99"]):.1f}% 时取得 $99\\%$，而最后 $5\\%$ 的预算带来的'
        f'改进中位数为 {100 * float(plat["tail5"]):.1f}%，即搜索在评估次数耗尽之前'
        f'早已停止改进，因此本文报告的名次处于噪声量级并不是预算被截断造成的。'
        f'但这一测量只界定预算对目标的影响，看不到稀有的地面抵达——它不是聚合曲线'
        f'的项，更大的预算仍可能改变抵达率，所以抵达率在此按原始量报告，不作为'
        f'收敛性结论。第二，该结局能否分辨算法。此处的限制不是预算而是样本量：'
        f'在观测到的抵达率下，一个 cell 至少出现一次抵达的概率为 '
        f'{100 * float(pw3["value"]):.0f}%，即多数 cell 为零与变体本身无关；'
        f'要在 $80\\%$ 功效下分辨"抵达率高一倍"的变体需要每 cell 约 '
        f'{int(pw2["runs"])} 次运行，分辨三倍差异需要约 {int(pw3x["runs"])} 次。'
        f'因此 $R=3$ 时该场景在原理上就无法按任务结局对变体排名，这与跨任务汇总'
        f'表中任务达成类各列完全不变是一致的，也是本文把名次建立在连续几何指标上的'
        f'原因——它们的运行间波动小到 $R=3$ 即可分辨。')

    # --- 分级任务完成度：CSR 与其三个分量 ----------------------------------
    mb, mf = EN._mission_mean('bare'), EN._mission_mean('full')
    mis = {(r['fid'], r['arm']): r for r in _rows('uav_mission_summary.csv')}
    csr_b = EN._mission_cell('bare', 'composite')
    csr_f = EN._mission_cell('full', 'composite')
    dmg_b = EN._mission_cell('bare', 'damage')
    dmg_f = EN._mission_cell('full', 'damage')
    brc_b = {f: float(mis[(f, 'bare')]['breach_pct']) for f in ('1', '2', '3', '4')}
    brc_f = {f: float(mis[(f, 'full')]['breach_pct']) for f in ('1', '2', '3', '4')}
    wb, wf = EN.weight_rows('bare'), EN.weight_rows('full')
    rhob = [float(r['spearman_rho']) for r in wb]
    rhof = [float(r['spearman_rho']) for r in wf]
    alt = [r for r in wb + wf if r['weights'] != '0.50/0.25/0.25']
    lead0 = {r['arm']: r['top3'].split(';')[0]
             for r in wb + wf if r['weights'] == '0.50/0.25/0.25'}
    moved = [(r['arm'], r['weights'], r['top3'].split(';')[0])
             for r in alt if r['top3'].split(';')[0] != lead0[r['arm']]]
    t_mis = _nt(P)
    f_mis = P.fig_no + 1
    P.para(
        f'终局事件在表 {{t4}} 的 {n_ev} 次试次中只出现 {int(ev_all["dest_k"])} 次，'
        f'容易被读成"所有变体都失败"。这一印象属于阈值'
        f'而不属于搜索过程，表 {t_mis} 因此去掉阈值：它的第一列是 §5.3 定义的 '
        f'CSR，随后三列是它所平均的三个分量——基地血量被削去的比例、'
        f'突入基地的地面分队比例、以及被击落的巡逻兵力比例。每个数值是 $29$ 个变体'
        f'上的均值（各变体先取 $R=3$ 次运行的中位数），半边宽度为跨变体的 '
        f'$95\\%$ 置信区间。四个任务合并来看，CSR 为 bare 臂 '
        f'{mb["composite"]:.1f}%、UPCL 臂 {mf["composite"]:.1f}%：基地在 bare 臂失去 '
        f'{mb["damage"]:.1f}% 的血量、在 UPCL 臂失去 {mf["damage"]:.1f}%，'
        f'地面分队突入基地的比例为 {mb["breach"]:.1f}% 对 {mf["breach"]:.1f}%，'
        f'巡逻兵力损失 {mb["kill"]:.1f}% 对 {mf["kill"]:.1f}%。逐 cell 看，'
        f'CSR 在 bare 臂从 {min(csr_b):.1f}% 到 {max(csr_b):.1f}%、在 UPCL 臂从 '
        f'{min(csr_f):.1f}% 到 {max(csr_f):.1f}%，削弱率在 bare 臂从 '
        f'{min(dmg_b):.1f}% 到 {max(dmg_b):.1f}%、在 UPCL 臂'
        f'从 {min(dmg_f):.1f}% 到 {max(dmg_f):.1f}%，因此只要把它当作一个量来读，'
        f'结局本身是有区分度的。')
    P.para(
        f'表 {t_mis} 有两点值得注意。第一，削弱率有下界，即空中载荷：两架无人机'
        f'只要完成突防就固定投下 {100 * aerial_pts / hp_pts:.0f}% 的血量，因此'
        f'处于该水平的 cell 完成了空中一半而未完成地面一半，其上的部分全部是地面'
        f'贡献。区分任务的是突入比例：bare 臂上 F1、F2 为 {brc_b["1"]:.1f}% 与 '
        f'{brc_b["2"]:.1f}%、F3、F4 为 {brc_b["3"]:.1f}% 与 {brc_b["4"]:.1f}%，'
        f'UPCL 把它在 F2、F4 上抬到 {brc_f["2"]:.1f}% 与 {brc_f["4"]:.1f}%，'
        f'而 F1 仍为 {brc_f["1"]:.1f}%。第二，战果比例在各任务之间基本持平，'
        f'且加上 UPCL 后略低，这与表 {{t4}} 中以比率读出的清障取舍是同一件事。'
        f'因此二值指标是一条分级曲线的端点而不是断崖：抵达目标本身就已削去固定的'
        f'一块，而分级列保留了二值列丢弃的那部分任务，图 {f_mis} 把 CSR 与三个分量'
        f'并列画出。')
    P.para(
        f'CSR 的权重是明示选择，因此又按三种替代权重——等权、0.60/0.20/0.20、'
        f'0.70/0.15/0.15——重新给每个变体在四个任务上打分并重排名次。与本文排序的 '
        f'Spearman 相关系数在 bare 臂为 {min(rhob[1:]):.3f}–{max(rhob[1:]):.3f}、'
        f'在 UPCL 臂为 {min(rhof[1:]):.3f}–{max(rhof[1:]):.3f}（各种情形均 '
        f'$p<0.001$），说明排序不是权重的'
        f'产物；{len(alt)} 种替代权重中有 {len(alt) - len(moved)} 种的首名不变'
        + ('' if not moved else
           f'，唯一的例外是前两名互换（{moved[0][1]} 权重下 {moved[0][2]} 取代 '
           f'{lead0[moved[0][0]]} 居首，出现在 {moved[0][0]} 臂）')
        + f'。权重决定的是水平而不是次序：存档中 CSR 上限为 {EN.csr_peak()[0]:.1f}%，'
        f'因此本场景能得出的说法不是"某变体完成了任务"，而是"它完成了任务的多大'
        f'一部分"。')
    P.para(
        '这样一个指数有两点局限值得说明。其一，加权和会掩盖取舍：CSR 相同的'
        '两个变体，可能在"削去基地血量"与"把地面分队送进基地"上完全不同，'
        '这正是三个分量与指数并列报告、而不折叠进指数的原因，也是下文逐任务'
        '解读要不断回到分量的原因。其二，指数是 cell 级均值，不含离散信息：'
        '一个 cell 的 CSR 可能每次 rollout 都达到，也可能只靠三次中的一次达到，'
        '而跨变体的均值无法区分这两种情形。第 5.4 节逐运行的一致性统计正是'
        '为此而设，它同时给出任何微小指数差异可承载多少权重的界。在这些限制'
        '之内，综合分只用于一个目的：把变体放到同一尺度上，使两条臂与四个任务'
        '可以互相比较，从而关于该层的陈述在它所由构成的各项指标上保持同号。'
        '由它得出的结论是臂与臂之间的比较，而不是关于绝对任务能力的陈述。')
    P.table_caption('拦截场景上的综合成功率及其分量，两条臂并列。CSR $=0.50\\times$'
                    '削弱 $+0.25\\times$ 突入基地 $+0.25\\times$ 战果。削弱：基地血量被削去'
                    '的比例；突入基地：到达基地的地面分队比例；战果：被击落的'
                    '巡逻兵力比例。数值为 $29$ 个变体上、各变体 $R=3$ 次运行'
                    '中位数的均值，$\\pm$ 为跨变体的 $95\\%$ 置信半宽。')
    P.table(['任务', '臂', 'CSR (%)', '削弱 (%)', '突入基地 (%)', '战果 (%)'],
            [[f'F{fid}', lab,
              f'{float(mis[(fid, arm)]["composite_pct"]):.1f} \u00b1 '
              f'{float(mis[(fid, arm)]["composite_ci"]):.1f}']
             + [f'{float(mis[(fid, arm)][k + "_pct"]):.1f} \u00b1 '
                f'{float(mis[(fid, arm)][k + "_ci"]):.1f}'
                for k in ('damage', 'breach', 'kill')]
             for fid in ('1', '2', '3', '4') for arm, lab in (('bare', 'bare'), ('full', 'UPCL'))],
            widths=[0.7, 0.75, 1.1, 1.2, 1.3, 1.05],
            align='llrrrr', font_size=7.4)
    P.figure(PFG.fig('uav_mission'),
             '四个任务上的综合成功率及其分量：(a) 面板（底色加深）为 CSR，'
             '(b)–(d) 面板依次为基'
             '地血量被削去的比例、突入基地的地面'
             '分队比例、被击落的巡逻兵力比例。柱高为 $29$ 个变体的均值，误差棒为 '
             '$95\\%$ 置信区间，两条臂并列。')

    f_sct = P.fig_no + 1
    P.para(
        f'四个任务与基准名次的对照汇总在图 {f_sct} 中：四幅面板 (a)–(d) 依次'
        f'为 F1–F4，横轴为该变体在 CEC2017 $D=30$ 上的名次、纵轴为该任务上的'
        f'场景名次，虚线为完全迁移。四幅面板的一致程度并不相同，说明基准名次向'
        f'场景的迁移不是一次全局重排：在某个任务上靠前的变体，换一个任务未必'
        f'仍然靠前。逐任务的读数在 §5.4.1–§5.4.4 给出。')
    P.figure(PFG.fig('uav_rank_scatter'),
             '四个任务上的 CEC2017 $D=30$ 名次（横轴）与场景名次（纵轴）对照：'
             '面板 (a)–(d) 依次为 F1–F4，虚线为完全迁移，各面板标题给出该任务'
             '的 Spearman 相关系数。', width_in=5.2)

    for fid in TASK_FIDS:
        _task_block(P, fid, f_sct, t_ev)

    _pool_results(P, t_ev)


_TRAJ_INTRO = {
    '1': (
        '读这四个面板之前先明确它们能回答什么。三列由该任务的名次决定，因此列与'
        '列之间比较的不是"好"与"坏"，而是"同一任务里最好与最坏相差多少"：若'
        '两臂之间的差别出现在名次 1 的列上而在末位列上消失，则该层能做的事情'
        '取决于它所依附的变体；若三列同向出现，则这一差别属于层与场景之间的'
        '关系。两行由地形决定：上行去掉背景，用来看航线在平面上的几何——绕行'
        '发生在哪一侧、在何处收紧；下行把同一组航线放回地形，用来看几何在三维'
        '里是否仍然成立，因为地形跟随高度使爬升计入回报，一条自上方看更短的'
        '航线经过山脊时可能反而更长。两臂共享种子，因此两条航线在第一次校正被'
        '接受之前必然重合，重合的长度本身就是该任务干预率的一个直观读数。最后'
        '一点：每个子图只画一条运行，它展示的是"发生过什么"而不是"平均会怎样"，'
        '由此得出的判断都要回到该任务的名次表与事件比率表上核对；图的作用是把'
        '表里的一行数值还原成一段可看的航线，让"路径长度差几百米"这类数字有'
        '形状可依。'),
    '2': (
        '第二个任务只加了一样东西：一段禁飞空域。因此这组面板是一个单因素对照，'
        '凡是两臂之间的差别都不可能是"任务变难了"造成的。禁飞区把突防走廊压到'
        '它与山脊之间，可行域变窄，航线必须从同一段缝隙中穿过，于是三个问题'
        '依次可问：缝隙的哪一侧被使用、穿缝前后的绕行如何分配、穿越时距禁飞'
        '边界留了多少余量。前两个问题看图就能回答，第三个只有数值能回答——硬'
        '约束在 rollout 内部强制执行，图里不会出现违规航线，能看出的只是余量的'
        '大小，而余量正是修正可以移动的量。若某些子图的两条航线完全重合，最可能'
        '的解释是该缝隙已经决定了唯一的形状，搜索没有可动的余地；这不是该层'
        '失效，而是可行集在这个任务上把自由度拿走了。'),
    '3': (
        '第三个任务改变的是对手而不是地图：拦截机增加到两架，并允许协同。对读图'
        '方式的影响是直接的——路径长度不再是这组面板的主要读数。两架协同的'
        '拦截机覆盖的是一段走廊而不是一个点，航线是否安全取决于它通过那段走廊'
        '时离两架拦截机各自的最近距离，而这个量在俯视图里只能粗略看出：一条'
        '看起来只是略微偏移的航线，可能正好把通过时刻推到了某架拦截机转向之后。'
        '因此这一组按"间距"读：先看两条航线在山脊附近的相对位置，再回到该任务的'
        '名次表核对最小拦截机距离的差别的量级。若上行两臂分开而下行几乎重合，'
        '说明几何上的改动在地形与爬升核算之后被抵消，这类情形在该任务上应优先'
        '读路径质量组的数值而不是读图。'),
    '4': (
        '第四个任务是复合的：禁飞区、两架协同拦截机与更高的拦截速度同时出现。'
        '此时任何一个差别都无法归因到单一原因，因此这组面板读作结果而不是读作'
        '诊断。仍有两件事可读。第一是两臂是否仍然重合：前三个任务的干预率都低，'
        '因此在这一任务上得到"完全重合"的答案完全可能，而那本身就是一个结论——'
        '该层在这套场景里没有找到值得改动的地方，图上的重合就是它的可视化对应物。'
        '第二是列与列之间的分散程度：若在名次 1 的列上两臂分开而在末位列上重合，'
        '则说明该层能加的东西取决于它所依附的变体，反之则说明它更像场景的性质。'
        '除此之外，这一组图只用于把该任务的三次运行中位数还原成可看的航线，'
        '量的结论仍以表为准。'),
}


def _task_block(P, fid, scatter_fig, t_ev):
    """一个任务的全部读数：名次表 + 1 张代表轨迹图集（散点图见合并图组）。"""
    P.h3(TASK_LABEL[fid])

    by = _task_rank_rows(fid)
    n_host = max(by)
    ks = _rep_ranks(fid)
    reps = list(zip(REP_SLOTS, ks, [by[k] for k in ks]))
    top, mid, bot = reps[0], reps[1], reps[-1]
    rb = _rank_by_fid()[fid]
    rho, pval = float(rb['spearman_rho']), float(rb['p'])

    # --- ① 名次结构与基准对照 -------------------------------------------
    P.para(
        f'该任务把 {n_host} 个变体重新排了名。第 1 名是 {top[2]["host"]}'
        f'（CEC2017 $D=30$ 上第 {top[2]["cec_rank"]} 名），中位第 '
        f'{mid[1]} 名是 {mid[2]["host"]}（CEC 第 {mid[2]["cec_rank"]} 名），'
        f'末位是 {bot[2]["host"]}（CEC 第 {bot[2]["cec_rank"]} 名）。该任务上'
        f'两套名次的 Spearman 相关为 $\\rho={rho:.2f}$（$p={pval:.3f}$，'
        f'$n={int(rb["n"])}$）：'
        + ('达到 $0.05$ 显著水平，基准名次在本任务上可以起到预测作用。'
           if pval < 0.05 else
           '未达到 $0.05$ 显著水平，基准名次在本任务上只能当作弱参考。')
        + ('冠军在基准上也属第一梯队。' if int(top[2]['cec_rank']) <= 10
           else f'值得注意的是，本任务的冠军在基准上仅列第 '
                f'{top[2]["cec_rank"]} 名，属于基准上的中下游变体。'))

    # --- ② 名次表：三档代表算法 ----------------------------------------
    t_name = _nt(P)
    P.table_caption(
        f'任务 F{fid} 上三档代表算法的关键指标（每个数值为 $R=3$ 次运行的'
        '中位数，两臂并列：bare $\\to$ 携带 UPCL）。末行为该任务 $29$ 个'
        '变体的池中位数。')
    rows = []
    for slot, rk, r in reps:
        host = r['host']
        cells = [_arrow(_cell_metric(fid, host, m), _cell_metric(fid, host, m, 'full'),
                        nd) for m, nd in TASK_METRICS]
        rows.append([str(rk), host, r['cec_rank'], _f(r['task_composite'], 3)] + cells)
    pool_cells = [_arrow(_task_pool(fid, m), _task_pool(fid, m, 'full'), nd)
                  for m, nd in TASK_METRICS]
    rows.append(['-', f'池中位数（{n_host} 个变体）', '-', '-'] + pool_cells)
    P.table(['名次', '变体', 'CEC 名次', '综合分', 'CSR (%)', '$n_{\\text{arr}}$',
             '$n_{\\text{lost}}$', '$d_{\\min}$(m)', '$L$(m)'],
            rows, widths=[0.5, 1.85, 0.75, 0.8, 0.85, 0.85, 0.85, 0.85, 0.9],
            align='llrrrrrrr', font_size=6.8)

    # --- ③ 池中位数：该任务上什么是恒定的、什么是可动的 ----------------
    b_arr, f_arr = _task_pool(fid, 'n_arrived'), _task_pool(fid, 'n_arrived', 'full')
    b_lost, f_lost = _task_pool(fid, 'n_lost'), _task_pool(fid, 'n_lost', 'full')
    b_succ, f_succ = (EN.mission_mean(fid, 'bare'),
                      EN.mission_mean(fid, 'full'))
    b_md, f_md = _task_pool(fid, 'min_dist'), _task_pool(fid, 'min_dist', 'full')
    b_pl, f_pl = (_task_pool(fid, 'path_length'),
                  _task_pool(fid, 'path_length', 'full'))
    b_fc, f_fc = (_task_pool(fid, 'first_capture'),
                  _task_pool(fid, 'first_capture', 'full'))
    b_pt, f_pt = (_task_pool(fid, 'n_patrol_killed'),
                  _task_pool(fid, 'n_patrol_killed', 'full'))
    sp_md, sp_pl = _spread(fid, 'min_dist'), _spread(fid, 'path_length')

    ev_t = EN._event_row(fid)
    P.para(
        f'表 {t_name} 的末行给出该任务的池中位数，它说明该任务上哪些量是'
        f'恒定的、哪些是可动的。任务达成类指标是事件型计数器，因此按比率读取，'
        f'见表 {t_ev}：在 F{fid} 上，两架无人机完成突防的比率为 '
        f'{EN.rate_cell(ev_t, "air")}（{int(ev_t["n_runs"])} 次试次、两臂合并），'
        f'地面分队抵达基地的比率为 {EN.rate_cell(ev_t, "gnd")}，基地被摧毁的比率为 '
        f'{EN.rate_cell(ev_t, "dest")}。分级结局并非齐平：跨变体的平均 CSR 为 '
        f'{b_succ:.2f}%（携带 UPCL 时 {f_succ:.2f}%，见表 {{t5}}），这一列取代了'
        f'恒为零的二值成功列，因此各变体按"任务完成了多大'
        f'一部分"而非"是否完成"来区分。该任务上恒定的是结局的空侧'
        f'一半：到达 {_f(b_arr, 0)} 架、损失 '
        f'{_f(b_lost, 0)} 架，两臂之间也没有差别，基地血量只随地面抵达而移动。'
        f'可动的是逼近路径的几何形状：'
        f'到拦截机的最小距离池中位数为 {_f(b_md, 0)} m（携带 UPCL 时 '
        f'{_f(f_md, 0)} m，{_dir_word(f_md, b_md)}），池内跨度 '
        f'{_f(min(sp_md), 0)}–{_f(max(sp_md), 0)} m；路径长度池中位数 '
        f'{_f(b_pl, 0)} m（携带 UPCL 时 {_f(f_pl, 0)} m，'
        f'{_dir_word(f_pl, b_pl)}），池内跨度 {_f(min(sp_pl), 0)}–'
        f'{_f(max(sp_pl), 0)} m；首次捕获发生在第 {_f(b_fc, 0)} 步'
        f'（携带 UPCL 时第 {_f(f_fc, 0)} 步），击杀巡逻兵 '
        f'{_arrow(b_pt, f_pt, 0)} 名。换言之，该任务的自由度落在"飞得多绕、'
        f'离威胁多近"上，而不落在任务是否完成上。该任务的名次对照见合并图 '
        f'{scatter_fig} 的面板 ({chr(96 + int(fid))})。')

    # --- ⑤ 该任务的分组增益 --------------------------------------------
    sm = _task_summary(fid)
    rows_g = [(g, sm[g]) for g in GROUP_ORDER if g in sm]
    flat = [GROUP_ZH[g] for g, r in rows_g
            if abs(float(r['mean_gain'])) <= 1e-9]
    span = [g for g, r in rows_g
            if float(r['ci_lo']) <= 0 <= float(r['ci_hi'])]
    best = max(rows_g, key=lambda gr: float(gr[1]['same_sign_pct']))
    P.para(
        f'两臂之间的差别按指标组汇总。{len(rows_g)} 个'
        f'指标组里，{len(flat)} 个（{"、".join(flat)}）的变化恒为零，原因是'
        f'该任务上两条臂都不触发这些计数器，修正无从作用；其余 '
        f'{len(rows_g) - len(flat)} 个组的均值为 '
        + '、'.join(f'{GROUP_ZH[g]} {float(r["mean_gain"]):+.2f}' for g, r in rows_g
                    if g not in flat)
        + f'，其中又有 {len(span)}/{len(rows_g)} 个组的 $95\\%$ 置信区间包含零，'
        f'即没有任何一组的偏移在该任务上达到可辨识的程度。符号一致性同样不高：'
        f'保持均值符号的宿主占比最高的是 {GROUP_ZH[best[0]]}'
        f'（{float(best[1]["same_sign_pct"]):.0f}%），其余组都在半数上下，'
        f'说明这些残差主要是逐个 cell 的绕行取舍，而不是该任务上的系统性效应。')

    # --- ⑥ 三档名次的代表轨迹（3x2 图集：列=名次，行=无地形/有地形）------
    ftraj = P.fig_no + 1
    rk_a, rk_b, rk_c = (reps[0][1], reps[1][1], reps[-1][1])
    P.para(_TRAJ_INTRO[fid])
    P.para(
        f'三档名次的代表轨迹并置在图 {ftraj} 中：三列从左到右依次是名次 '
        f'{rk_a}、中位 {rk_b} 与末位 {rk_c}，两行则把同一组航线先去掉'
        '地形背景、再放回地形上，便于先把航线几何本身看清楚、再判断它与地形的'
        '关系；每个子图把 bare 臂与携带 UPCL 的臂画在同一沙盘上，两臂共享同一'
        '随机种子，因而两条航线的差别可归因于该层。')
    P.figure(PFG.fig('uav_traj_F%s' % fid),
             f'任务 F{fid} 上三档名次代表算法（名次 {rk_a} / {rk_b} / {rk_c}）'
             '的飞行轨迹：列为三档名次，上行为去掉地形背景后的同一组航线，'
             '下行为叠加地形阴影与等高线后的结果；每个子图叠加 bare 臂（蓝）'
             '与携带 UPCL 的臂（红），共享同一随机种子。')
    for i, (slot, rk, r) in enumerate(reps):
        host = r['host']
        pb, pf = (_cell_metric(fid, host, 'path_length'),
                  _cell_metric(fid, host, 'path_length', 'full'))
        db, df_ = (_cell_metric(fid, host, 'min_dist'),
                   _cell_metric(fid, host, 'min_dist', 'full'))
        ab, af = (_cell_metric(fid, host, 'n_arrived'),
                  _cell_metric(fid, host, 'n_arrived', 'full'))
        lb, lf = (_cell_metric(fid, host, 'n_lost'),
                  _cell_metric(fid, host, 'n_lost', 'full'))
        # 首行的名次已在标签里写明，括号中只补基准名次，避免"第 1 名（该
        # 任务名次 1）"这样的自我重复；中间与末行则保留两项名次。
        _paren = (f'CEC 第 {r["cec_rank"]} 名' if slot == 'top'
                  else f'该任务名次 {rk}，CEC 第 {r["cec_rank"]} 名')
        P.para(
            f'{REP_CN[slot]} {host}（{_paren}）这一格的数据是：'
            f'路径长度 {_arrow(pb, pf, 0)} m，'
            f'到拦截机最小距离 {_arrow(db, df_, 0)} m，到达 {_arrow(ab, af, 0)} 架、'
            f'损失 {_arrow(lb, lf, 0)} 架；图 {ftraj} 第 {i + 1} 行的两列画出'
            '该格的飞行路线（左列无地形背景、右列有地形背景）。')


# ===========================================================================
# 5.4.5  跨任务对照
# ===========================================================================
def _pool_results(P, t_ev):
    P.h3('5.4.5  跨任务对照：四个任务放在一起看')

    vr = _rows('uav_value_rank.csv')
    cec = {r['host']: int(r['cec_rank']) for r in vr}
    shift = {r['host']: int(r['uav_rank']) - int(r['cec_rank']) for r in vr}
    rho = stats.spearmanr([int(r['uav_rank']) for r in vr],
                          [int(r['cec_rank']) for r in vr])
    prof = {}
    for r in vr:
        prof.setdefault((r['n_arrived'], r['n_lost']), []).append(r)
    dom = max(prof, key=lambda k: len(prof[k]))
    majority = prof[dom]
    odd = sorted([r for k, v in prof.items() if k != dom for r in v],
                 key=lambda r: int(r['uav_rank']))
    comp_main = [float(r['composite']) for r in majority]
    path = [float(r['path_length']) for r in vr]
    t4 = _nt(P)
    P.para(
        f'表 {t4} 按综合分排列 {len(vr)} 个变体，并同时给出四项主指标。'
        f'在任务层面，变体池高度一致：{len(vr)} 个变体中有 {len(majority)} 个'
        f'在每次推演中都给出相同的编队结局（到达 {int(float(dom[0]))} 架、'
        f'损失 {int(float(dom[1]))} 架），'
        f'只有 {len(odd)} 个变体（{"、".join(r["host"] for r in odd)}）例外，'
        f'而它们也正因此排在表末。区分其余变体的是逼近路径的几何形状：池内路径'
        f'长度中位数从 {min(path):,.0f} m 到 {max(path):,.0f} m（池中位数 '
        f'{np.median(path):,.0f} m），而在前 {len(majority)} 名内部综合分本身仅'
        f'相差 {max(comp_main) - min(comp_main):.2f} 个单位。差异确实存在但很窄，'
        f'它来自绕行与裕度之间的取舍，而不是任务是否完成。')

    P.table_caption('$29$ 个变体在拦截场景上的表现，按综合分排序（越大越好）；'
                    '四项主指标为四个任务与 $R=3$ 次运行上的中位数，'
                    '$\\Delta$ 为场景名次减去 bare 臂的基准名次；后者先取'
                    'CEC 2017 在 $D=30$ 下每个函数的对数误差中位数，再对'
                    '二十九个函数取均值后排序。')
    P.table(['名次', '变体', 'CEC 名次', '$\\Delta$', '综合分', 'CSR (%)',
             '$n_{\\text{arr}}$', '$n_{\\text{lost}}$', '$L$'],
            [[r['uav_rank'], r['host'], r['cec_rank'],
              f'{shift[r["host"]]:+d}', _f(r['composite'], 3),
              _f(r['composite_pct'], 2), int(float(r['n_arrived'])),
              int(float(r['n_lost'])), _f(r['path_length'], 0)] for r in vr],
            widths=[0.5, 1.95, 0.8, 0.65, 1.0, 0.9, 0.75, 0.75, 0.85],
            align='llrrrrrrr', font_size=6.8)

    # shift = 场景名次 − CEC 名次，取负值表示该变体在场景上排得更前
    up = [h for h, d in shift.items() if d < 0]
    down = [h for h, d in shift.items() if d > 0]
    same = [h for h, d in shift.items() if d == 0]
    _eq = (f'、{len(same)} 个名次不变' if same else '')
    big = max(shift, key=lambda h: abs(shift[h]))
    cec1 = next(h for h, r in cec.items() if r == 1)
    cec1_rank = next(int(r['uav_rank']) for r in vr if r['host'] == cec1)
    P.para(
        f'表 {t4} 同时把两套排名并列。{len(vr)} 个变体中，有 {len(up)} 个在'
        f'场景上排得比基准上更前、{len(down)} 个更靠后{_eq}，名次变动的中位数为 '
        f'{np.median([abs(d) for d in shift.values()]):.0f} 名；两套排名的 '
        f'Spearman 相关系数为 $\\rho={rho.statistic:.2f}$（$p={rho.pvalue:.2f}$，'
        f'$n={len(vr)}$）。基准第一名 {cec1} 在此处为第 {cec1_rank} 名，'
        f'而场景第一名 {vr[0]["host"]} 在基准上为第 {cec[vr[0]["host"]]} 名；'
        f'单项变动最大的是 {big}（{shift[big]:+d} 名）。这种重排是正常的，'
        f'而非异常现象，因为两套排名回答的是不同的问题：基准按各变体在一组固定'
        f'维度的人工函数上的对数最终误差排名，而场景按各变体在一个任务达成类'
        f'计数器已经饱和的任务中如何权衡绕行与裕度排名。弱且不显著的相关系数'
        f'正是这种目标差异的产物，也与表 {t4} 中场景内名次本身处于噪声量级这一'
        f'判断一致。')

    md = _median_by_task('min_dist')
    sp_md = _spread_by_task('min_dist')
    pl = _median_by_task('path_length')
    fc = _median_by_task('first_capture')
    t5 = _nt(P)
    P.para(
        f'表 {t5} 把四个任务并列起来，它们并不等价。'
        f'表中每个数值是 {len(vr)} 个变体上的中位数，两种配置同时给出。'
        f'到拦截机的最小距离是随任务难度变化最明显的指标：其'
        f'池中位数从 F1 的 {md["1"]:.0f} m 降至 F4 的 {md["4"]:.0f} m，而 F4 上'
        f'有两架更快的拦截机在巡逻；在同一任务内部，池内跨度也已相当可观'
        f'（F1：{min(sp_md["1"]):.0f}-{max(sp_md["1"]):.0f} m）。路径长度从 F1 的 '
        f'{pl["1"]:,.0f} m 增至 F3 的 {pl["3"]:,.0f} m，这是搜索为受限空域和'
        f'第二架拦截机付出的绕行代价；到 F4 又缩短至 {pl["4"]:,.0f} m，因为更快'
        f'的拦截机使首次捕获提前（第 {fc["4"]:.0f} 步，而 F3 为第 {fc["3"]:.0f} '
        f'步）。与之相对，任务达成类计数器之所以中位数为零，是因为决定性事件稀有，'
        f'而不是因为各变体彼此相近。按比率读表 {t_ev}，地面分队抵达基地的比率在 '
        f'F1 上为 {EN.rate_cell(EN._event_row("1"), "gnd")}、F2 上为 '
        f'{EN.rate_cell(EN._event_row("2"), "gnd")}、F3 上为 '
        f'{EN.rate_cell(EN._event_row("3"), "gnd")}、F4 上为 '
        f'{EN.rate_cell(EN._event_row("4"), "gnd")}，而基地在全实验中被摧毁 '
        f'{int(EN._event_row("all")["dest_k"])} 次。这一四十倍的落差并不遵循任务设计时'
        f'的难度标称：被当作基线的 F1 恰恰是最难推动基地血量的任务，而带两架拦截机的 '
        f'F3、F4 反而最容易。四个任务共用同一张地图、同一套巡逻部署、同一个步兵出发点'
        f'以及相同的地面权重，因此这一落差不可能来自 F1 的地面路线更难，它是搜索在目标'
        f'两侧之间联合分配的结果，而任务表里的难度列描述的是空中防御的强度，不是任务'
        f'结局的可分辨程度。真正恒定的是约束族：禁飞区步数、越界步数与坠毁数在每个'
        f'变体的每个任务上均为零，因此这些惩罚无法区分变体池。换言之，该场景的有效'
        f'目标归结为各变体如何在绕行与威胁距离之间取舍。')

    P.table_caption('各任务上关键指标的中位数（$29$ 个变体），bare 与附加 UPCL '
                    '两种配置并列。')
    P.table(['指标'] + [f'F{f} {a}' for f in ('1', '2', '3', '4')
                        for a in ('bare', 'full')],
            task_metrics_table(KEY_METRIC_ZH),
            widths=[1.5] + [0.66] * 8,
            align='l' + 'r' * 8, font_size=6.5)

    t6 = _nt(P)
    P.para(
        f'设置两条臂的目的在于刻画该层，而不是给它打分。由于 UPCL 只修正宿主'
        f'提出的候选解，需要回答的是：它的修正在该场景中触及了什么，以及该效应'
        f'是否可复现。表 {t6} 因此给出各语义分组的同种子两臂之差，在四个任务与 '
        f'$R=3$ 次运行上取均值，并给出该量在 $29$ 个变体上的 $95\\%$ 置信区间；'
        f'区间之外，表 {t6 + 1} 还给出每个分组在变体与运行上的符号一致性。')

    hg = _rows('uav_mech_host_gain.csv')
    gain_num = []
    for g in GROUP_ORDER:
        v = np.array([float(r[g]) for r in hg])
        n = len(v)
        m = float(v.mean())
        se = float(v.std(ddof=1) / np.sqrt(n))
        ci = se * float(stats.t.ppf(0.975, n - 1))
        gain_num.append((g, m, m - ci, m + ci))
    spanning = [g for g, _m, lo, hi in gain_num if lo <= 0 <= hi]
    P.table_caption('两条臂之间各指标组的同种子变化（$29$ 个变体均值，含 '
                    '$95\\%$ 置信区间）。')
    P.table(['分组', '均值变化', 'CI 下界', 'CI 上界'],
            [[GROUP_ZH[g], _f(m, 3, True), _f(lo, 3, True), _f(hi, 3, True)]
             for g, m, lo, hi in gain_num],
            widths=[2.4, 1.3, 1.3, 1.3], align='lrrr')

    st = _delta_stats(('path_length', 'min_dist', 'curvature', 'flight_time',
                       'n_arrived', 'n_lost'))
    P.para(
        f'逐指标的结果显示修正落在何处。连续几何量的变化相当可观：在全部 '
        f'{st["path_length"]["n"]} 个 cell 上，路径长度的相对变化中位数为 '
        f'{st["path_length"]["rel_pct"]:.1f}%，到拦截机的最小距离为 '
        f'{st["min_dist"]["rel_pct"]:.1f}%，曲率为 '
        f'{st["curvature"]["rel_pct"]:.1f}%，飞行时间为 '
        f'{st["flight_time"]["rel_pct"]:.1f}%。而由事件决定的结局并非“变化很小”，'
        f'而是完全没有变化：{st["n_arrived"]["n"]} 个 cell 中有 '
        f'{st["n_arrived"]["zero"]} 个在两臂下的到达数完全相同，'
        f'{st["n_lost"]["zero"]} 个的损失数完全相同。因此该层改变的是编队如何飞行'
        f'——绕行、曲率与裕度——而由事件驱动拦截决定的离散任务结局保持原位。')

    P.para(
        f'这种改变也不是系统性的偏移。在变体上取平均后，表 {t6} 的 '
        f'{len(spanning)}/{len(gain_num)} 个分组置信区间包含零；'
        f'逐指标的变化方向在池内也几乎对半分裂：路径长度在 '
        f'{st["path_length"]["up"]} 个 cell 上变长、'
        f'{st["path_length"]["down"]} 个上变短，到拦截机的最小距离在 '
        f'{st["min_dist"]["up"]} 个 cell 上变大、'
        f'{st["min_dist"]["down"]} 个上变小。约束组恒为零，因为两条臂在每个任务'
        f'上都不触发这些计数器，表 {t5} 按任务给出的中位数证实了这一点，修正无从'
        f'作用。残余差异'
        f'是否可复现，由跨运行一致性分析回答。')

    # 单格数值：与英文版取同一格（NL-SHADE-RSP / F1）、同一张表，保证两版
    # 叙述可以逐字对照，读者不会从两个版本里读到不同的数。
    _ref = next(r for r in vr if r['host'] == 'NL-SHADE-RSP')
    _dl1 = {r['metric']: r for r in _rows('uav_upcl_delta.csv')
            if r['host'] == 'NL-SHADE-RSP' and r['fid'] == '1'}

    def _pair1(stem):
        r = _dl1[stem]
        return float(r['bare_median']), float(r['full_median'])

    p0, p1 = _pair1('path_length')
    c0, c1 = _pair1('curvature')
    e0, e1 = _pair1('path_efficiency')
    d0, d1 = _pair1('min_dist')
    n_arr1, n_lost1 = _pair1('n_arrived')[0], _pair1('n_lost')[0]
    P.para(
        f'随后读出一格的具体数值：NL-SHADE-RSP 在任务 F1 上，其综合分在'
        f' {len(vr)} 个变体中排第 {int(_ref["uav_rank"])}。两臂飞同一条走廊、'
        f'都抵达基地，差别在于进近段被重新塑形，而不在结局。携带该层的一臂'
        f'路径短了 {abs(p1 - p0):,.0f} m（{p1:,.0f} m 对 {p0:,.0f} m），'
        f'曲率更低（{c1:.2f} 对 {c0:.2f}），路径效率更高（{e1:.3f} 对 '
        f'{e0:.3f}），但它离拦截机更近，最小距离从 {d0:.0f} m 降到 '
        f'{d1:.0f} m。任务结局未变：两臂都是 {n_arr1:.0f} 架到达、'
        f'{n_lost1:.0f} 架损失。这正是前文指出的模式：在单个 cell 上，该层'
        f'移动的是飞行的几何形状，移动的方向却在 cell 之间并不一致，而由事件'
        f'驱动的结局保持不变。')

    _consistency(P)


# ===========================================================================
# 5.4.4  这些变化跨运行稳定吗
# ===========================================================================
def _consistency(P):
    t7 = _nt(P)
    P.para(
        '在赋予这些残余差异任何分量之前，还有一个问题需要确定：由于变化量很小'
        '而置信区间很宽，该变化究竟是变体与任务自身的属性，还是仅仅来自运行？'
        f'表 {t7} 对每个分组给出，三个运行全部保持合并均值符号的变体占比。')

    cons = _rows('uav_gain_run_consistency.csv')
    P.table_caption('两臂变化的符号一致性：三个运行全部保持合并符号的 '
                    '变体占比。')
    P.table(['分组', '同号', '总数', '占比'],
            [[GROUP_ZH[r['metric_group']], r['same_sign'], r['total'],
              _f(float(r['ratio']) * 100, 1)] for r in cons],
            widths=[2.4, 1.2, 1.0, 1.2], align='llrr')

    top = max(cons, key=lambda r: float(r['ratio']))
    never = [GROUP_ZH[r['metric_group']] for r in cons
             if float(r['ratio']) <= 0]
    P.para(
        '一致性普遍偏低：最高的 '
        f'{GROUP_ZH[top["metric_group"]]} 也只有 '
        f'{_f(float(top["ratio"]) * 100, 1)}% 的变体在三个运行上全部保持'
        f'符号，另有 {len(never)} 个分组（{"、".join(never)}）完全无法保持符号。'
        '同一个变体、同一个任务上，变化方向在不同运行之间翻转，这与场景自身的'
        '运行间波动无法区分；因此第 5.4 节的逐变体变化不应被读作该层稳定的逐变体'
        '效应。')


# ===========================================================================
# 5.5  结果解读与讨论
# ===========================================================================
def _discussion(P):
    P.h2('5.5  结果解读与讨论')

    rb = _rank_by_fid()
    rho_txt = '、'.join(
        f'F{fid} 上 $\\rho={float(rb[fid]["spearman_rho"]):.2f}$'
        f'（$p={float(rb[fid]["p"]):.2f}$）' for fid in TASK_FIDS)
    same_max = max(float(r['same_sign_pct'])
                   for r in EN._rows('uav_task_summary.csv'))
    ev_all = EN._event_row('all')
    ev_b_arm = EN._event_row('all', 'bare')
    ev_f_arm = EN._event_row('all', 'full')

    P.para(
        f'三点观察概括了这些算法在该场景上的行为。第一，变体池是一条窄带而非'
        f'一份排名：在四个任务上各变体给出的结局彼此接近，因此综合分的顺序应被'
        f'读作噪声范围内的次序，而不是能力高低的分层。而且四个任务并不共用'
        f'同一张名次表：把任务拆开看，CEC 名次与场景名次的 Spearman 相关依次为 '
        f'{rho_txt}，只有最简单的 F1 达到显著，说明基准名次的可迁移性随任务'
        f'难度上升而衰减，任何跨任务合并的排名都会把这种衰减掩盖掉。第二，有'
        f'信息量的差异集中于规避安全与路径质量：到拦截机的最小距离与路径长度是'
        f'把变体区分开的两项指标，而任务达成类事件虽然可测、却无法归因——在 '
        f'{EN.rate_cell(ev_all, "gnd")} 的 {int(ev_all["n_runs"])} 次试次中地面'
        f'分队抵达基地，基地被摧毁两次，面对这样的比率，每 cell $R=3$ 次运行不足'
        f'以分辨变体效应；约束违反则始终为零。第三，UPCL 层重塑了飞行的几何形状'
        f'却没有改变结局：它移动了绕行、曲率与裕度，而到达与损失计数器'
        f'在两条臂上完全相同，并且移动方向随变体和运行而变。在分级结局这一层面上，'
        f'两条臂的差别至多是几个百分点——地面抵达率在 bare 臂为 '
        f'{float(ev_b_arm["gnd_pct"]):.1f}%、附加该层后为 '
        f'{float(ev_f_arm["gnd_pct"]):.1f}%（各 '
        f'{int(ev_b_arm["n_runs"])} 次试次），合并 CSR 为 '
        f'{EN._mission_mean("bare")["composite"]:.1f}% 对 '
        f'{EN._mission_mean("full")["composite"]:.1f}%——落在上一条观察的区间之内，'
        f'这正是同一零结果在任务结局层面的读数。逐任务的分组变化也显示，约束满足'
        f'族在四个任务上都恒为零，其余各族的宿主符号一致性最高也只有 '
        f'{same_max:.0f}%。')

    P.para(
        '场景自身的特性解释了这一格局。任务达成不是不可能，而是分辨率不足：'
        f'空中打击几乎是确定性的（{EN.rate_cell(ev_all, "air")} 的试次中两架'
        f'无人机都完成突防并投弹），但它只削去固定的 '
        f'{float(ev_all["aerial_dmg"]) * float(ev_all["base_hp_max"]):.0f} 点血量'
        f'（满值 {float(ev_all["base_hp_max"]):.0f}），其余血量由场景使其稀有的'
        f'地面抵达来削去（{EN.rate_cell(ev_all, "gnd")} 的试次，且所有血量低于'
        '仅空中打击水平的试次都属于这一类）。预算并不是障碍：bare 臂在消耗 '
        f'{100 * float(EN.plateau("all", "bare")["t99"]):.1f}% 的预算时已取得总改进'
        '的 $99\\%$，而最后 $5\\%$ 的预算没有带来可测的改进，即搜索在评估次数'
        '耗尽之前早已停止在所给目标上改进。真正障碍任务结局排名的样本量：决定性'
        '事件稀有的程度使每 cell 三次运行无法分辨它，因此本文的名次建立在分级 CSR '
        '与逼近路径的几何形状上，也就是路径与安全的取舍。约束计数器在两条臂上都保持为零，'
        '因为搜索产生的轨迹从不进入禁飞区、也从不越出容许箱体，因此这些惩罚既'
        '无法区分变体，也无法被该层移动。地面战斗真实存在但打不到基地：在 '
        f'{float(ev_all["inf_lost_pct"]):.0f}% 的试次中至少有 1 名步兵阵亡、'
        '有 1 至 2 名巡逻兵被击杀，然而抵达基地的分队只有 '
        f'{float(ev_all["gnd_pct"]):.0f}%，因此协同与巡逻两个族被压在下界附近。'
        '最后，绕行项在运行间的波动与两条臂之间的差异量级相当，这正是单次运行'
        '观察到的变化不能作为该层可复现效应的原因。')

    P.para(
        '该场景是一个合成但具有物理参数的替身：地形为程序生成，防御方按'
        '脚本化的确定性规则行动，四个任务共享同一张地图。这使它属于仿真启发式'
        '（simheuristic）评估的传统——元启发式针对系统的仿真模型运行，而非针对'
        '解析目标 [@JUAN15]；它也与昂贵黑箱研究共有同一性质：约束是评估预算，'
        '而不是算法 [@REGIS14]。')

    P.para(
        '我们考虑过三种替代方案而未采用，其理由关系到本节负面结论能说明什么、'
        '不能说明什么。第一种是用学习得到的防御方取代脚本化防御方：深度强化'
        '学习在双人博弈中已达超人水平 [@MNIH15][@SILVER18]，多智能体演员—评论家'
        '方法是混合合作—竞争的团队场景的标准工具 [@LOWE17][@ZHANG_MARL21]，'
        '而用这类控制器生成空战机动策略也已被演示 [@KONG20]。这会让红方具备'
        '自适应性，但同时会让目标函数以每格三次运行无法分辨的方式随机化，并把'
        '一个可复现的测试台换成策略自身训练方差会主导比较的对象。第二种是把搜索'
        '本身交给学习得到的提议者，这恰是程序搜索与思维链提示结合大语言模型'
        '如今在算法发现与推理步骤上所做的事 [@FUNSEARCH][@WEI22]，近期工作也'
        '把它用于进化算子 [@LIU_LLM_EA]，这条线索现已由关于两者交界面的综述'
        '工作勾勒出来 [@ECLLM25]；反对的理由不是能力而是归因——收益将'
        '无法再归于算子，而只能归于写出算子的模型。第三种是更丰富的任务模型'
        '——通信约束、多基地、部分可观测——这会把维度推高到本文所用的三十个变量'
        '之上，而按第 4 节的证据，它多半只是在同一比较上增加方差。')

    P.para(
        f'对于这些求解器的使用者，结论是具体且受场景约束的：在这样昂贵、事件'
        f'驱动的拦截任务上，$29$ 个变体中的任何一个都是合理选择；选择的影响主要'
        f'体现在"裕度—绕行"的取舍上，而且要按任务分别看待——F1 与 F4 的头部变体'
        f'并不重合（§5.4 各小节）。要建立稳定的排序，需要的是更难的实例——更强的'
        f'拦截能力、更紧的预算，或非饱和的任务级目标——而不是更大的变体池。')

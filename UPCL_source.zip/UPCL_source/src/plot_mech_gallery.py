# -*- coding: utf-8 -*-
"""Compose the mechanism-attribution panels into two compact galleries.

The eight individual panels produced by analyze_mech_attribution.py are stitched
here into two figures so the Word build embeds far fewer drawing objects and the
mechanism-attribution section takes far less vertical space.
"""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'results' / 'cec' / 'figures'

LETTERS = 'abcdefgh'


def _panel(ax, name, lab):
    img = plt.imread(FIG / name)
    ax.imshow(img)
    ax.set_axis_off()
    ax.text(0.0, 1.01, lab, transform=ax.transAxes, fontsize=11,
            va='bottom', ha='left', fontweight='bold')


def gallery_profile():
    # (a) fingerprint, (b) intervention-rate vs gain, (c) descriptor spanning
    fig = plt.figure(figsize=(6.4, 5.3))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.35],
                          hspace=0.22, wspace=0.10,
                          left=0.02, right=0.98, top=0.97, bottom=0.02)
    _panel(fig.add_subplot(gs[0, 0]), 'mech_fingerprint.png', '(a)')
    _panel(fig.add_subplot(gs[0, 1]), 'mech_scatter_ir_gain.png', '(b)')
    _panel(fig.add_subplot(gs[1, :]), 'mech_descriptor.png', '(c)')
    out = FIG / 'gallery_mech_profile.png'
    fig.savefig(out, bbox_inches='tight', dpi=200)
    plt.close(fig)
    print('[mech-gallery] ->', out.name)


def gallery_attribution():
    fig, axes = plt.subplots(2, 2, figsize=(6.4, 5.2), squeeze=False)
    fig.subplots_adjust(left=0.02, right=0.98, top=0.97, bottom=0.02,
                        wspace=0.06, hspace=0.16)
    names = ['attr_d1_assoc.png', 'attr_d2_eta2_dot.png',
             'attr_d6_attribution.png', 'attr_d8_near_matrix.png']
    for k, name in enumerate(names):
        _panel(axes[k // 2, k % 2], name, f'({LETTERS[k]})')
    out = FIG / 'gallery_mech_attribution.png'
    fig.savefig(out, bbox_inches='tight', dpi=200)
    plt.close(fig)
    print('[mech-gallery] ->', out.name)


def main():
    gallery_profile()
    gallery_attribution()
    print('[mech-gallery] done ->', FIG)


if __name__ == '__main__':
    main()

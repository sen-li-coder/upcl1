#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Grid 实验进度实时监控脚本（仅标准库）。

用法:
    python src/monitor_grid.py               # 单次快照
    python src/monitor_grid.py --loop 60     # 每 60 秒追加一次到 monitor.log
"""
import argparse
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "grid" / "raw"
GRID_LOG = ROOT / "results" / "grid" / "grid_run.log"
MON_LOG = ROOT / "results" / "grid" / "monitor.log"

RUNS = 5
SUITES = (("cec2017", 30, 29), ("cec2022", 10, 12))
HOST_ORDER = [
    "DE/rand/1", "DE/best/1", "DE/rand/2", "DE/current-to-best/1",
    "DE/current-to-rand/1", "DE/rand/1/either-or",
    "jDE", "SaNSDE", "JADE", "SHADE", "CoBiDE", "SaDE", "EPSDE", "CoDE",
    "MPEDE", "L-SHADE", "jSO", "L-SHADE-RSP", "NL-SHADE-RSP", "MadDE",
]

DONE_RE = re.compile(
    r"\[grid\]\s+(\d+)/(\d+)\s+\S+\s+(\S+)\s+D(\d+)\s+(\S+)\s+F(\d+)"
    r"\s+([\d.]+)\s+min")

# json 文件名把 host 里的 "/" 替换成了 "-"（见 run_upcl_grid._path），
# 这里做反向映射，使统计时与 HOST_ORDER 的原始名对齐。
_HOST_FILE = {h.replace("/", "-"): h for h in HOST_ORDER}


def _dt(ts):
    return datetime.fromtimestamp(ts).strftime("%m-%d %H:%M:%S")


def _dur(s):
    s = int(s)
    h, m = divmod(s, 3600)
    m, _ = divmod(m, 60)
    return f"{h}h{m:02d}m" if h else f"{m}m"


def python_count():
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-Process python -ErrorAction SilentlyContinue).Count"],
            capture_output=True, timeout=25).stdout
        return int(out.decode("utf-8", "ignore").strip() or 0)
    except Exception:
        return -1


def read_log():
    info = dict(total=None, workers=None, wall_h=None, reuse=0, done=0,
                created=None, last_done=None, tail=[], suite_dt={})
    if not GRID_LOG.exists():
        return info
    text = GRID_LOG.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    # 最后一次 "starting N cells" 作为续跑边界
    start_idx = -1
    for i, ln in enumerate(lines):
        m = re.search(r"starting\s+(\d+)\s+cells\s+on\s+(\d+)\s+workers", ln)
        if m:
            start_idx = i
            info["total"], info["workers"] = int(m.group(1)), int(m.group(2))
    for m in re.finditer(r"wall clock\s*:\s*~?([\d.]+)\s*h", text):
        info["wall_h"] = float(m.group(1))
    for m in re.finditer(r"reusable\s*:\s*(\d+)", text):
        info["reuse"] = int(m.group(1))

    # 只统计最后一次启动之后的 done 行（忽略中断前的旧运行）
    seg = lines[start_idx + 1:] if start_idx >= 0 else lines
    for ln in seg:
        dm = DONE_RE.search(ln)
        if dm:
            info["done"] = int(dm.group(1))
            info["suite_dt"].setdefault(dm.group(3), []).append(float(dm.group(7)))
    info["tail"] = [ln for ln in seg if DONE_RE.search(ln)][-6:]
    info["created"] = os.path.getctime(GRID_LOG)
    info["last_done"] = os.path.getmtime(GRID_LOG)
    return info


def scan_json():
    rows = []
    if not RAW.exists():
        return rows
    for p in RAW.rglob("*.json"):
        try:
            suite, dimdir = p.relative_to(RAW).parts[0], p.relative_to(RAW).parts[1]
            dim = int(dimdir[1:])
            host_file, fid = p.stem.split("__F")
            host = _HOST_FILE.get(host_file, host_file)
        except Exception:
            continue
        runs = -1
        try:
            head = p.open("rb").read(512).decode("utf-8", "ignore")
            m = re.search(r'"runs_complete"\s*:\s*(\d+)', head)
            runs = int(m.group(1)) if m else -1
        except Exception:
            pass
        rows.append(dict(suite=suite, dim=dim, host=host, fid=int(fid),
                         runs=runs, mtime=p.stat().st_mtime))
    return rows


def snapshot(active_sec, tail_n):
    now = time.time()
    info = read_log()
    rows = scan_json()
    L = []
    sep = "=" * 68
    L.append(sep)
    if not GRID_LOG.exists():
        L.append(f"[monitor] {_dt(now)}   grid_run.log 不存在（实验未启动）")
        L.append(sep)
        return "\n".join(L)

    head = f"[monitor] {_dt(now)}"
    if info.get("created"):
        head += f"   运行 {_dur(now - info['created'])}"
    L.append(head)
    L.append("-" * 68)

    total, done = info.get("total"), info.get("done")
    if total:
        pct = 100.0 * (done or 0) / total
        L.append(f"进度: {done or 0}/{total} cells ({pct:.1f}%)")
    py = python_count()
    w = info.get("workers")
    L.append(f"进程: {py} 个 python" + (f" (期望 1+{w} worker)" if w else ""))
    if info.get("tail"):
        L.append(f"最后完成: {info['tail'][-1].strip()}")
    elif info.get("last_done"):
        L.append(f"日志活动: {_dt(info['last_done'])} "
                 f"({_dur(now - info['last_done'])} 前, 本批尚无完成记录)")

    if info.get("tail"):
        L.append("-" * 68)
        L.append("最近完成:")
        L.extend("  " + x.strip() for x in info["tail"][-tail_n:])

    active = [r for r in rows if 0 <= r["runs"] < RUNS
              and now - r["mtime"] < active_sec]
    active.sort(key=lambda r: r["mtime"], reverse=True)
    L.append("-" * 68)
    if active:
        L.append(f"活跃 cell ({active_sec // 60}min 内写盘, 共 {len(active)}):")
        for r in active:
            L.append(f"  {r['suite']} D{r['dim']} {r['host']:<18s} "
                     f"F{r['fid']:<3d} run {r['runs']}/{RUNS} "
                     f"({_dur(now - r['mtime'])} 前)")
    else:
        L.append(f"活跃 cell: 无 (最近 {active_sec // 60}min 无写盘)")

    by = {}
    for r in rows:
        d = by.setdefault((r["suite"], r["dim"], r["host"]), [0, 0])
        if r["runs"] >= RUNS:
            d[0] += 1
        elif r["runs"] >= 0:
            d[1] += 1
    pend = []
    for suite, dim, nf in SUITES:
        parts = []
        for h in HOST_ORDER:
            done_n, prog = by.get((suite, dim, h), [0, 0])
            if done_n >= nf:
                continue
            parts.append(f"{h} {done_n}/{nf}(进{prog},缺{nf-done_n-prog})")
        if parts:
            pend.append(f"  [{suite} D{dim}] " + " | ".join(parts))
    if pend:
        L.append("-" * 68)
        L.append("host 进度(未完成; 前6个DE变体缺失来自cec复用, 不重跑):")
        L.extend(pend)

    L.append("-" * 68)
    eta_txt = "无法估算"
    if total and done is not None and done < total:
        w = info.get("workers") or 1
        # 分 suite 估算: cec2017 D30 慢, cec2022 D10 快
        d30_avg = 90.0
        dts = info.get("suite_dt", {}).get("cec2017", [])
        if dts:
            d30_avg = sum(dts[-8:]) / len(dts[-8:])
        d30_remain = 0
        for h in HOST_ORDER:
            dn, prog = by.get(("cec2017", 30, h), [0, 0])
            if dn >= 29:
                continue
            miss = 29 - dn - prog
            if h in HOST_ORDER[:6]:   # DE 变体缺失来自 cec 复用, 不重跑
                miss = 0
            d30_remain += prog + miss
        d10_remain = max(0, (total - done) - d30_remain)
        d10_avg = 18.0                # D10 维数低, 单 cell 约快 4-5 倍
        remain_min = (d30_remain * d30_avg + d10_remain * d10_avg) / w
        eta_txt = (f"~{_dt(now + remain_min * 60)}  "
                   f"(D30 剩 {d30_remain}×~{d30_avg:.0f}min "
                   f"+ D10 剩 {d10_remain}×~{d10_avg:.0f}min, {w} worker)")
    L.append("ETA: " + eta_txt)

    # 停滞诊断
    if done is not None and total and done >= total:
        L.append("状态: 全部完成 ✓")
    elif active:
        L.append("状态: 正常 (worker 活跃, 正在跑慢 cell)")
    elif py > 0:
        L.append("状态: 观察 (无活跃写盘, 可能正在跑慢 cell 的 run 1)")
    else:
        L.append("状态: 警告 (无 python 进程, 实验可能已停止/崩溃)")
    L.append(sep)
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", type=int, default=0, help="轮询间隔(秒), 0=单次")
    ap.add_argument("--active-window", type=int, default=30,
                    help="活跃 cell 判定窗口(分钟)")
    ap.add_argument("--tail", type=int, default=6, help="显示最近完成条数")
    ap.add_argument("--log", type=str, default=str(MON_LOG), help="监控日志路径")
    a = ap.parse_args()

    log_path = Path(a.log)
    active_sec = a.active_window * 60

    def emit(text):
        sys.stdout.write(text + "\n")
        sys.stdout.flush()
        with open(log_path, "a", encoding="utf-8") as fh:
            fh.write(text + "\n")

    try:
        while True:
            emit(snapshot(active_sec, a.tail))
            if a.loop <= 0:
                break
            time.sleep(a.loop)
    except KeyboardInterrupt:
        emit("[monitor] 已手动停止监控。")


if __name__ == "__main__":
    main()

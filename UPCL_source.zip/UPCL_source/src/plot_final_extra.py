# -*- coding: utf-8 -*-
"""Final 6-figure set (part 2/2): 3 algorithm-level figures, all 30 hosts covered.
   (4) 30-per-algo mechanism radar  (5) 30-per-algo mechanism composition stacked
   (6) capacity x gain quadrant
Part 1 (atlas2_ablation / atlas2_capacity_gain / atlas2_level_gradient) reuses
plot_upcl_atlas2.py and is invoked by plot_final_six.py.
"""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import patheffects as pe

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

MECH_COLS = ['rho_step_effect', 'theta_align_effect', 'eta_elite_effect',
             'kappa_crowd_effect', 'nu_novel_effect']
MECH_NAMES = ['rho', 'theta', 'eta', 'kappa', 'nu']
MECH_FULL = {'rho': 'step', 'theta': 'align', 'eta': 'elite',
             'kappa': 'crowd', 'nu': 'novel'}
MECH_COL = {'rho': '#1f77b4', 'theta': '#2ca02c', 'eta': '#ff7f0e',
            'kappa': '#d62728', 'nu': '#9467bd'}
LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}
LEVEL_LABEL = {'0': 'L0 fixed', '1': 'L1 adaptive', '2': 'L2 archive', '3': 'L3 LPSR'}


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8, 'axes.labelsize': 7, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6, 'ytick.labelsize': 6,
        'legend.fontsize': 6, 'legend.frameon': False, 'figure.dpi': 300})


def _load():
    hs = list(csv.DictReader(open(TABLES / 'mech30_host_summary.csv',
                                  encoding='utf-8', newline='')))
    hs.sort(key=lambda r: int(r['bare_rank']))
    return hs


def _txt(ax, x, y, s, **kw):
    ax.text(x, y, s, fontsize=kw.get('fontsize', 5.5), color=kw.get('color', '#111'),
            ha=kw.get('ha', 'left'), va=kw.get('va', 'center'), zorder=6,
            path_effects=[pe.withStroke(linewidth=1.6, foreground='white')])


def _mech_legend():
    return [plt.Line2D([], [], marker='s', linestyle='', markersize=7,
                       color=MECH_COL[m], label=f'{m} ({MECH_FULL[m]})')
            for m in MECH_NAMES]


# ---- (4) 30 per-algorithm mechanism radar ----
def algo_radar(hs):
    n = len(hs)
    cols, rows = 6, 5
    M = np.array([[_f(r[c]) for c in MECH_COLS] for r in hs])
    vmin, vmax = float(np.nanmin(M)), float(np.nanmax(M))
    pad = (vmax - vmin) * 0.06
    lo, hi = vmin - pad, vmax + pad
    ang = np.linspace(0, 2 * np.pi, 5, endpoint=False).tolist()
    ang += ang[:1]
    fig = plt.figure(figsize=(15.5, 10.6))
    fig.subplots_adjust(left=0.02, right=0.98, top=0.92, bottom=0.02,
                        wspace=0.55, hspace=0.72)
    for i, r in enumerate(hs):
        ax = fig.add_subplot(rows, cols, i + 1, polar=True)
        v = M[i].tolist() + [M[i][0]]
        c = LEVEL_COL[r['level']]
        ax.plot(ang, v, color=c, lw=1.2)
        ax.fill(ang, v, color=c, alpha=0.14)
        ax.set_ylim(lo, hi)
        ax.set_rticks([0])
        ax.tick_params(pad=-2, labelsize=4)
        ax.set_xticks(ang[:-1])
        ax.set_xticklabels(['r', 't', 'e', 'k', 'n'], fontsize=4.2)
        ax.set_title(f"{r['host']}", fontsize=6.2, pad=8, color=c)
        ax.grid(color='#cccccc', lw=0.3, alpha=0.6)
        ax.spines['polar'].set_linewidth(0.4)
    fig.suptitle('Per-algorithm mechanism fingerprint (5 axes: r=rho·step, t=theta·align, '
                 'e=eta·elite, k=kappa·crowd, n=nu·novel; signed effect, 0-ring centre)',
                 fontsize=10, y=0.985)
    fig.legend(handles=_level_legend(), loc='upper right', ncol=4,
               bbox_to_anchor=(0.995, 0.955), handlelength=1.0, columnspacing=1.0)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / 'final4_algo_radar.png', bbox_inches='tight')
    plt.close(fig)
    print('[final] final4_algo_radar.png')


def _level_legend():
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=5,
                       color=LEVEL_COL[l], label=LEVEL_LABEL[l]) for l in LEVEL_COL]


# ---- (5) 30 per-algorithm mechanism composition stacked (diverging) ----
def algo_stack(hs):
    n = len(hs)
    M = np.array([[_f(r[c]) for c in MECH_COLS] for r in hs])
    fig, ax = plt.subplots(figsize=(7.0, 6.4))
    fig.subplots_adjust(left=0.32, right=0.97, top=0.94, bottom=0.08)
    y = np.arange(n)[::-1]
    xlim = max(abs(float(np.nanmin(M))), abs(float(np.nanmax(M)))) * 1.12
    for i in range(n):
        pos, neg = 0.0, 0.0
        for j, m in enumerate(MECH_NAMES):
            e = M[i, j]
            if e >= 0:
                ax.barh(y[i], e, left=pos, color=MECH_COL[m], height=0.72,
                        edgecolor='white', linewidth=0.3)
                pos += e
            else:
                ax.barh(y[i], e, left=neg, color=MECH_COL[m], height=0.72,
                        edgecolor='white', linewidth=0.3)
                neg += e
    ax.axvline(0, color='#333333', lw=1.0)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{r['host']}" for r in hs], fontsize=5.6)
    for i, r in enumerate(hs):
        ax.get_yticklabels()[i].set_color(LEVEL_COL[r['level']])
    ax.set_xlim(-xlim, xlim)
    ax.set_xlabel('signed mechanism effect (dec); + right / - left')
    ax.set_title('Per-algorithm mechanism composition (diverging stacked, 30 hosts)',
                 loc='left', fontsize=8)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.5, alpha=0.6)
    ax.set_axisbelow(True)
    ax.legend(handles=_mech_legend(), loc='lower right', ncol=1, handlelength=1.0)
    fig.savefig(FIG / 'final5_algo_stack.png', bbox_inches='tight')
    plt.close(fig)
    print('[final] final5_algo_stack.png')


# ---- (6) capacity x gain quadrant ----
def quadrant(hs):
    bare = np.array([_f(r['bare_median_log10err']) for r in hs])
    dec = np.array([_f(r['dec_mean']) for r in hs])
    interv = np.array([_f(r['intervention_rate']) for r in hs])
    lcol = [LEVEL_COL[r['level']] for r in hs]
    fig, ax = plt.subplots(figsize=(7.0, 6.2))
    fig.subplots_adjust(left=0.12, right=0.90, top=0.93, bottom=0.12)
    med_bare = float(np.median(bare))
    lo = min(bare.min(), -0.2) * 1.05
    hi = max(bare.max(), 1.0) * 1.03
    dlo = min(dec.min(), -0.1) * 1.2
    dhi = max(dec.max(), 0.1) * 1.3
    ax.axvline(med_bare, color='#333', lw=0.9)
    ax.axhline(0, color='#333', lw=0.9)
    ax.axvspan(lo, med_bare, dlo, 0, color='#2ca02c', alpha=0.06)
    ax.axvspan(lo, med_bare, 0, dhi, color='#1f77b4', alpha=0.06)
    ax.axvspan(med_bare, hi, dlo, 0, color='#ff7f0e', alpha=0.06)
    ax.axvspan(med_bare, hi, 0, dhi, color='#d62728', alpha=0.06)
    ax.text(lo + (med_bare - lo) * 0.5, dhi - (dhi - 0) * 0.06,
            'strong × improved', ha='center', fontsize=6.5, color='#2ca02c')
    ax.text(lo + (med_bare - lo) * 0.5, dlo + (0 - dlo) * 0.12,
            'strong × degraded', ha='center', fontsize=6.5, color='#1f77b4')
    ax.text(med_bare + (hi - med_bare) * 0.5, dhi - (dhi - 0) * 0.06,
            'weak × improved', ha='center', fontsize=6.5, color='#ff7f0e')
    ax.text(med_bare + (hi - med_bare) * 0.5, dlo + (0 - dlo) * 0.12,
            'weak × degraded', ha='center', fontsize=6.5, color='#d62728')
    for i, r in enumerate(hs):
        ax.scatter(bare[i], dec[i], s=12 + interv[i] * 180, color=lcol[i],
                   edgecolors='white', linewidths=0.5, zorder=3)
        _txt(ax, bare[i], dec[i], f"{r['host']}", fontsize=4.8)
    ax.set_xlim(lo, hi); ax.set_ylim(dlo, dhi)
    ax.set_xlabel('capacity  log10 error (left = stronger)')
    ax.set_ylabel('UPCL gain  dec (log10, + = improved)')
    ax.set_title('Capacity x gain quadrants (30 hosts; size = intervention rate)',
                 loc='left', fontsize=8)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    fig.legend(handles=_level_legend(), loc='upper right', ncol=1, handlelength=1.0)
    fig.savefig(FIG / 'final6_quadrant.png', bbox_inches='tight')
    plt.close(fig)
    print('[final] final6_quadrant.png')


if __name__ == '__main__':
    _style()
    hs = _load()
    print(f'[final] {len(hs)} hosts loaded')
    algo_radar(hs)
    algo_stack(hs)
    quadrant(hs)
    print('[final] done ->', FIG)

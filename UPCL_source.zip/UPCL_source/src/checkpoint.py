# -*- coding: utf-8 -*-
"""任务断点续接检查脚本（跨会话记忆，零依赖，纯标准库）。

背景
----
本项目的 GUI 改进任务反复因「上下文中断」而重做。为解决这个问题，本脚本
**不依赖人的记忆**，而是直接解析源码，探测当前真实的完成状态，并：
  1. 在控制台打印一份「已完成 / 待办」报告；
  2. 把同一份报告落盘到 ``docs/PROGRESS.md``，供下次会话直接读取。

下次新会话开始时，只需运行：:

    python src/checkpoint.py

然后读 ``docs/PROGRESS.md``，即可恢复上下文，不必重做已完成的调研。

探测依据（都是客观事实，非手工记录）：
  * ``src/cec_suites.py`` 的 ``SUITE_LOADERS / SUITE_DIMS / SUITE_NFUNCS /
    DATA_DIRS`` 常量，以及模块级 ``def`` 算子名。

用法
----
    python src/checkpoint.py          # 打印报告并写 docs/PROGRESS.md
    python src/checkpoint.py --quiet  # 只写快照，不打印控制台报告
"""
import argparse
import re
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CEC_SUITES = ROOT / 'src' / 'cec_suites.py'
PROGRESS_MD = ROOT / 'docs' / 'PROGRESS.md'

# 已拍板的目标（勿改，与 docs/TASK_TRACKING.md §1 一致）：
TARGET_SUITES = ['cec2005', 'cec2013', 'cec2014', 'cec2015', 'cec2017',
                 'cec2022']
# CEC2005 尚缺、CEC2013/2014/2015/2017/2022 已覆盖的算子（cec_suites 模块级 def）
TARGET_OPERATORS = {
    'sphere': 'CEC2013 F1 / CEC2005 F1',
    'different_powers': 'CEC2013 F5',
    'schwefel_12': 'CEC2005 F2',
    'schwefel_2_13': 'CEC2005 F12',
    'schwefel_2_6': 'CEC2005 F5',
}

# 算法介绍框的原文链接形式（已拍板）：论文标题 + 作者 + 年份 + DOI/官方 URL。


# --------------------------------------------------------------------------
# 解析工具：读文件、提取常量 dict 的键、提取模块级 def 名
# --------------------------------------------------------------------------
def _read(path):
    try:
        return path.read_text(encoding='utf-8')
    except OSError as e:
        return f'# 读取失败: {e}\n'


def _const_keys(text, name):
    """提取形如 ``name = {'a': ..., 'b': ...}`` 的 dict 键（字符串字面量）。"""
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*\{(.*?)\}\s*(?=\n\w|\Z)',
                  text, re.S)
    if not m:
        return []
    return re.findall(r"['\"](\w+)['\"]\s*:", m.group(1))


def _const_list(text, name):
    """提取形如 ``name = ['a', 'b']`` 的字符串列表。"""
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*\[(.*?)\]\s*(?=\n\w|\Z)',
                  text, re.S)
    if not m:
        return []
    return re.findall(r"['\"]([^'\"]+)['\"]", m.group(1))


def _defs(text):
    """模块级函数名（含算子）。"""
    return re.findall(r'^def\s+(\w+)\s*\(', text, re.M)


def _dims_map(text, name):
    """提取 ``name = {'cec2017': (30, 50), ...}`` → {suite: [dims]}。"""
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*\{(.*?)\}\s*(?=\n\w|\Z)',
                  text, re.S)
    out = {}
    if not m:
        return out
    for key, val in re.findall(r"['\"](\w+)['\"]\s*:\s*\((.*?)\)", m.group(1)):
        out[key] = [int(x) for x in re.findall(r'\d+', val)]
    return out


# --------------------------------------------------------------------------
# 各探测项
# --------------------------------------------------------------------------
def probe_cec_suites():
    text = _read(CEC_SUITES)
    loaders = _const_keys(text, 'SUITE_LOADERS')
    dims = _dims_map(text, 'SUITE_DIMS')
    nfuncs = {}
    m = re.search(r"SUITE_NFUNCS\s*=\s*\{(.*?)\}\s*(?=\n\w|\Z)", text, re.S)
    if m:
        nfuncs = {k: int(v) for k, v in re.findall(
            r"['\"](\w+)['\"]\s*:\s*(\d+)", m.group(1))}
    data_dirs = _const_keys(text, 'DATA_DIRS')
    defined = set(_defs(text))
    missing_suites = [s for s in TARGET_SUITES if s not in loaders]
    missing_ops = {op: TARGET_OPERATORS[op] for op in TARGET_OPERATORS
                   if op not in defined}
    return {
        'implemented_suites': [s for s in TARGET_SUITES if s in loaders],
        'missing_suites': missing_suites,
        'dims': dims, 'nfuncs': nfuncs, 'data_dirs': data_dirs,
        'missing_ops': missing_ops,
    }


# --------------------------------------------------------------------------
# 渲染报告
# --------------------------------------------------------------------------
def _check(ok):
    return '✅ 已做' if ok else '❌ 待办'


def render(cec, now):
    L = []
    L.append('# 任务进度快照（自动生成，勿手改）\n')
    L.append(f'> 生成时间：{now}   ·   运行 `python src/checkpoint.py` 刷新\n')
    L.append('> 目标（已拍板）：测试集全补 4 个（CEC2005/2013/2014/2015，'
             '凑齐 6 套件）。\n')

    # ---- 任务 1：测试集补全
    L.append('\n## 任务 1 · 测试集补全（`src/cec_suites.py`）\n')
    L.append('| 套件 | 状态 | 维度 | 函数数 |\n|---|---|---|---|')
    for s in TARGET_SUITES:
        st = '✅ 已实现' if s in cec['implemented_suites'] else '❌ 缺失'
        dims = '/'.join(map(str, cec['dims'].get(s, []))) or '—'
        nf = cec['nfuncs'].get(s, '—')
        L.append(f'| {s} | {st} | {dims} | {nf} |')

    if cec['missing_suites']:
        L.append(f"\n**待补套件**：{'、'.join(cec['missing_suites'])}"
                 f"（实现顺序建议 CEC2013 → CEC2005，CEC2013 无需新算子）")
    else:
        L.append('\n**6 个标准套件已全部实现。**')

    if cec['missing_ops']:
        L.append('\n**尚缺算子**（CEC2005 需要，numpy 一行可写）：')
        for op, use in cec['missing_ops'].items():
            L.append(f'  - `{op}` —— {use}')
    else:
        L.append('\n**目标算子已全部定义。**')

    # ---- 任务 4：数据位置 & 导出样式（已明确，纯记录）
    L.append('\n## 任务 4 · 数据保存位置 & 导出样式（已明确，无需改动）\n')
    L.append('- **数据默认保存**：`results/cec/raw/{suite}/D{dim}/'
             '{host}__F{fid}.json`，每个「算法×函数×维度」一个 JSON，内含 '
             '`runs` 数组（每 run 有 `bare` 与 `upcl/full` 两臂的 '
             '`err_curve/err_final/wall_time_s`）。')
    L.append('- **导出结果表格（CSV，utf-8-sig）**：列 = `suite, dim, host, '
             'fid, func, category, n` + 每臂 `{arm}_均值/标准差/中位数/最优`；'
             '每行一个 cell，按 suite/dim/host/fid 排序。')
    L.append('- **显著性检验导出（CSV）**：列含 `arm_a, arm_b, p_mannwhitneyu, '
             'p_wilcoxon, significant, direction, mean_log10_a/b`。')

    L.append('\n---\n')
    L.append('## 下一步（续接时按此顺序）\n')
    L.append('1. `cec_suites.py` 补 CEC2013（28 函数，无新算子）→ 自测。')
    L.append('2. `cec_suites.py` 补 CEC2005（25 函数，需先加 '
             '`schwefel_12/schwefel_2_13/schwefel_2_6` 三算子）→ 自测。')
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quiet', action='store_true')
    args = ap.parse_args()

    cec = probe_cec_suites()
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    report = render(cec, now)

    PROGRESS_MD.parent.mkdir(parents=True, exist_ok=True)
    PROGRESS_MD.write_text(report + '\n', encoding='utf-8')

    if not args.quiet:
        print(report)
        print(f'\n[checkpoint] 快照已写入 {PROGRESS_MD.relative_to(ROOT)}')


if __name__ == '__main__':
    sys.exit(main())

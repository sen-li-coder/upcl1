# -*- coding: utf-8 -*-
"""Dimension transfer of the paired effect: CEC 2017 D=30 vs D=50.

Both blocks run the same twenty established variants over the same twenty
nine functions with the same seeds and the same per-dimension budget, so
the only thing that changes between the two columns is the dimension.

Panel (a) pairs the per-variant mean dec of the two blocks on one row per
variant: the ordering of the gain survives the dimension change (Spearman
0.79 over twenty hosts) and only three variants change the sign of the
gain.  Panel (b) does the same for the policy intervention rate, whose
ordering is transferred almost intact (Spearman 0.85) with virtually no
change of level -- so neither the fingerprint nor its magnitude is a
property of the dimension.

Reads the per-host table written by analyze_upcl_cec.py (exp5_dim_hosts).
"""
from pathlib import Path

import csv

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FIG.mkdir(parents=True, exist_ok=True)

HI = '#3C5488'      # D=50
LO = '#8491B4'      # D=30
FLIP = '#E64B35'    # sign change between the two blocks
INK = '#333333'


def load():
    rows = list(csv.DictReader(open(TAB / 'exp5_dim_hosts.csv',
                                    encoding='utf-8')))
    for r in rows:
        for k in ('dec30', 'dec50', 'ri30', 'ri50', 'rho30', 'rho50'):
            r[k] = float(r[k])
    return rows


def stats():
    out = {}
    p = TAB / 'exp5_dim_transfer.csv'
    if p.exists():
        for r in csv.DictReader(open(p, encoding='utf-8')):
            out[r['metric']] = (float(r['value']),
                                float(r['p']) if r['p'] else None)
    return out


def main():
    rows = load()
    st = stats()
    fig, (ax, ax2) = plt.subplots(
        1, 2, figsize=(6.30, 3.35), sharey=True,
        gridspec_kw=dict(width_ratios=[1.32, 0.92], wspace=0.10))

    # ---------------- (a) per-variant gain, one row per variant -------------
    rows.sort(key=lambda r: r['dec50'])
    for i, r in enumerate(rows):
        flip = (r['dec30'] > 0) != (r['dec50'] > 0)
        ax.plot([r['dec30'], r['dec50']], [i, i], '-', lw=0.8,
                color=FLIP if flip else '#B8B8B8',
                zorder=2 if flip else 1)
        ax.plot([r['dec30']], [i], 'o', ms=3.2, mfc='white', mec=INK,
                mew=0.7, zorder=3)
        ax.plot([r['dec50']], [i], 'o', ms=3.2, mfc=HI, mec=INK,
                mew=0.5, zorder=3)
    ax.axvline(0.0, color=INK, lw=0.8, ls='--', zorder=0)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([r['host'] for r in rows], fontsize=5.9)
    ax.set_ylim(-0.9, len(rows) - 0.1)
    ax.set_xlim(-1.28, 0.72)
    ax.tick_params(axis='x', labelsize=7)
    ax.tick_params(axis='y', length=0, pad=1.5)
    ax.set_xlabel(r'per-variant mean $\Delta_{ec}$ (decades)', fontsize=7.2)
    ax.set_title('(a)  gain, $D=30$ vs $D=50$', fontsize=8, loc='left')
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    note = []
    if 'host_dec_spearman' in st:
        note.append(f'$\\rho$ = {st["host_dec_spearman"][0]:.2f}')
    if 'host_sign_agree' in st:
        note.append(f'sign kept {int(st["host_sign_agree"][0])}/{len(rows)}')
    if note:
        ax.text(0.02, 0.985, '   '.join(note), transform=ax.transAxes,
                ha='left', va='top', fontsize=6.6, color=INK)
    # legend for the two blocks and the sign change
    ax.plot([], [], 'o', ms=3.2, mfc='white', mec=INK, mew=0.7,
            label='$D=30$')
    ax.plot([], [], 'o', ms=3.2, mfc=HI, mec=INK, mew=0.5, label='$D=50$')
    ax.plot([], [], '-', lw=1.4, color=FLIP, label='sign change')
    ax.legend(loc='lower right', fontsize=6.2, frameon=False,
              handletextpad=0.4, borderpad=0.1, labelspacing=0.25)

    # ---------------- (b) intervention rate, block against block -----------
    for i, r in enumerate(rows):
        ax2.plot([r['rho30'] * 100, r['rho50'] * 100], [i, i], '-', lw=0.8,
                 color='#B8B8B8', zorder=1)
        ax2.plot([r['rho30'] * 100], [i], 'o', ms=3.2, mfc='white', mec=INK,
                 mew=0.7, zorder=3)
        ax2.plot([r['rho50'] * 100], [i], 'o', ms=3.2, mfc=HI, mec=INK,
                 mew=0.5, zorder=3)
    ax2.set_xlim(0, 23.5)
    ax2.tick_params(axis='x', labelsize=7)
    ax2.tick_params(axis='y', length=0, labelleft=False)
    ax2.set_xlabel(r'policy rate $\rho$ (%)', fontsize=7.2)
    ax2.set_title('(b)  intervention rate', fontsize=8, loc='left')
    for s in ('top', 'right'):
        ax2.spines[s].set_visible(False)
    if 'host_rho_spearman' in st:
        ax2.text(0.03, 0.03, f'$\\rho_s$ = {st["host_rho_spearman"][0]:.2f}',
                 transform=ax2.transAxes, ha='left', va='bottom', fontsize=6.6,
                 color=INK)

    fig.subplots_adjust(left=0.175, right=0.985, top=0.90, bottom=0.115)
    out = FIG / 'fig_dim_effect.png'
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print('[dim] wrote', out)


if __name__ == '__main__':
    main()

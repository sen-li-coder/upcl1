"""UAV 多智能体对抗仿真演示 GUI。

在一个窗口里完成：选择场景/任务/算法/预算 → 运行 DE 优化 → 播放对抗仿真
动画，同时实时展示仿真环境参数与 DE 收敛曲线。

技术栈与主软件一致（tkinter + ttk + matplotlib 的 FigureCanvasTkAgg），
零新增依赖。

运行：``python src/uav_gui.py``
"""

from __future__ import annotations

import json
import sys
import threading
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

# 项目根：源码模式 = 本文件上两级（src/ 的上一级）；frozen exe = exe 所在目录，
# 保证 GUI 优化结果的落盘目录（results/apps/gui）与 exe 的 src/、results/ 一致。
if getattr(sys, 'frozen', False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = Path(__file__).resolve().parents[1]
GUI_RESULTS_DIR = ROOT / 'results' / 'apps' / 'gui'

import matplotlib
if 'tkagg' not in matplotlib.get_backend().lower():
    matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.patches import Circle, Patch, Polygon, Wedge
from matplotlib.lines import Line2D
import matplotlib.transforms as mtransforms

# 中文字体，避免标题/标签显示为方块
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import de_hosts
import de_hosts_cec as DHC
import run_upcl_cec as RUC
from uav_adversarial import (SCENARIO_DEFAULT_K, SCENARIO_DIMS,
                             SCENARIO_NFUNCS, get_uav_problem, list_scenarios)
from opponents import (DIFFICULTIES, DIFFICULTY_BY_LABEL, DIFFICULTY_LABELS,
                       DIFFICULTY_OPTIONS, DRL_ALGO_BY_LABEL, DRL_ALGO_LABELS,
                       DRL_ALGO_OPTIONS, is_drl_difficulty, make_opponent,
                       train_opponent)

DHC.register()

STATE_COLORS = {0: 'tab:blue', 1: 'tab:green', 2: 'tab:red'}
STATE_NAMES = {0: '飞行', 1: '到达', 2: '被击落'}


def _arm_display(arm):
    """臂的友好显示名：bare 基线不显示后缀，full 显示 [UPCL]（图示不带 [bare]）。"""
    return ' [UPCL]' if arm == 'full' else ''


class _OptimizationAborted(Exception):
    """优化被用户主动终止（非错误）。"""


class UAVDemoApp:
    def __init__(self, root):
        # root 可为 tk.Tk()（独立运行）或 tk.Toplevel()（嵌入主 GUI），
        # 二者都具备 title/geometry/after 等所需接口。
        self.root = root
        root.title('UAV 多智能体对抗仿真演示')

        self.scenario = tk.StringVar(value='intercept')
        self.fid = tk.IntVar(value=1)
        self.n_waypoints = tk.IntVar(value=0)   # 0 = 用场景默认航点数 K
        self.host = tk.StringVar(value='SHADE')
        self.evals_mult = tk.IntVar(value=300)
        self.arm = tk.StringVar(value='bare')
        self.difficulty = tk.StringVar(value=DIFFICULTY_LABELS['L1'])
        self.drl_algo = tk.StringVar(value=DRL_ALGO_LABELS['es'])
        self.speed = tk.DoubleVar(value=40.0)   # 动画间隔 ms

        self.problem = None
        self._train_cache = {}          # (场景, 难度key, 算法key) -> 训练好的策略
        self._reload_gen = 0            # 代次，使过期的后台训练结果失效
        self.best_x = None
        self.best_f = None
        self.conv = None
        self.evals = None
        self.upcl_used = None

        self.frames = None
        self.final_state = None
        self.anim_i = 0
        self.anim_after = None

        # 击落细节局部回放状态
        self.kill_speed = tk.DoubleVar(value=260.0)   # 局部回放间隔 ms
        self.kill_events = []        # [{'frame', 'drone', 'killer', 'dist'}]
        self.kill_ev_i = 0
        self.kill_fr_lo = 0          # 当前事件回放帧区间 [lo, hi]
        self.kill_fr_hi = 0
        self.kill_fr_i = 0           # 当前播放到的帧号
        self.kill_xlim = (0.0, 1.0)
        self.kill_ylim = (0.0, 1.0)
        self.kill_win = None         # 局部回放 Toplevel
        self.kill_fig = None
        self.kill_ax = None
        self.kill_canvas = None
        self.kill_after = None
        self.kill_btn_play = None
        self.kill_ev_label = None

        self.busy = False
        self._progress_val = 0.0       # 后台优化进度（0~1，worker 写入、主线程轮询）
        self._opt_state = 'idle'       # 优化状态机：idle / running / paused
        self._pause_event = threading.Event()
        self._pause_event.set()        # 初始 = 不暂停
        self._stop_flag = False        # 终止标志（worker 每代检查后提前退出）

        self._build_ui()
        self._autofit_window()
        self._reload_problem()

    # ------------------------------------------------------------------ UI
    def _setup_style(self):
        """统一界面配色与字体（clam 主题，可自定义颜色）。"""
        style = ttk.Style()
        try:
            style.theme_use('clam')
        except Exception:
            pass
        style.configure('TLabel', font=('Microsoft YaHei', 9))
        style.configure('TLabelframe', padding=4)
        style.configure('TLabelframe.Label', font=('Microsoft YaHei', 9, 'bold'),
                        foreground='#2c5f8a')
        style.configure('TButton', font=('Microsoft YaHei', 9), padding=(10, 4))
        style.configure('TNotebook.Tab', font=('Microsoft YaHei', 9),
                        padding=(12, 4))
        style.configure('Accent.TButton', font=('Microsoft YaHei', 9, 'bold'),
                        foreground='#ffffff', background='#2c7a4b',
                        padding=(14, 5))
        style.map('Accent.TButton',
                  background=[('active', '#256940'), ('pressed', '#1e5734'),
                              ('disabled', '#a9c4b3')],
                  foreground=[('disabled', '#eef4f0')])

    @staticmethod
    def _cfg_label(parent, text, row, col):
        ttk.Label(parent, text=text + ':').grid(row=row, column=col,
                                                sticky='e', pady=3)

    def _autofit_window(self):
        """按屏幕大小自适应窗口，并设置不超过屏幕的最小尺寸。"""
        try:
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
        except Exception:
            sw, sh = 1366, 768
        w = max(980, min(1360, sw - 60))
        h = max(640, min(820, sh - 90))
        self.root.geometry(f'{w}x{h}')
        self.root.minsize(min(980, sw - 60), min(620, sh - 90))

    @staticmethod
    def _make_win_btn(parent, text, cmd):
        return tk.Button(parent, text=text, command=cmd, relief='flat', bd=0,
                         bg='#2c5f8a', fg='#ffffff',
                         activebackground='#3a7bb0',
                         activeforeground='#ffffff',
                         font=('Microsoft YaHei', 11, 'bold'), padx=8, pady=0,
                         cursor='hand2', width=2)

    def _minimize(self):
        self.root.iconify()

    def _toggle_fullscreen(self):
        self._fullscreen = not getattr(self, '_fullscreen', False)
        self.root.attributes('-fullscreen', self._fullscreen)
        self.btn_full.config(text='还原' if self._fullscreen else '□')

    def _build_ui(self):
        self._setup_style()

        # ---- 顶部标题栏（深色）+ 右上角窗口控制按钮 ----
        header = tk.Frame(self.root, bg='#2c5f8a', padx=18, pady=12)
        header.pack(side='top', fill='x')
        title_box = tk.Frame(header, bg='#2c5f8a')
        title_box.pack(side='left', fill='x', expand=True)
        tk.Label(title_box, text='无人机多智能体对抗仿真演示',
                 font=('Microsoft YaHei', 16, 'bold'),
                 fg='#ffffff', bg='#2c5f8a').pack(anchor='w')
        tk.Label(title_box, text='DE 连续优化航点 · 限角速度运动学对抗 · 实时动画演示',
                 font=('Microsoft YaHei', 9),
                 fg='#d5e3f0', bg='#2c5f8a').pack(anchor='w', pady=(2, 0))
        win_btns = tk.Frame(header, bg='#2c5f8a')
        win_btns.pack(side='right', anchor='n')
        self.btn_min = self._make_win_btn(win_btns, '—', self._minimize)
        self.btn_min.pack(side='left', padx=(0, 4))
        self.btn_full = self._make_win_btn(win_btns, '□', self._toggle_fullscreen)
        self.btn_full.pack(side='left')

        # ---- 实验配置 ----
        cfgf = ttk.LabelFrame(self.root, text=' 实验配置 ', padding=(12, 8))
        cfgf.pack(side='top', fill='x', padx=10, pady=(8, 6))
        r = 0
        self._cfg_label(cfgf, '场景', r, 0)
        scen_cb = ttk.Combobox(cfgf, textvariable=self.scenario,
                               values=list_scenarios(), width=12,
                               state='readonly')
        scen_cb.grid(row=r, column=1, sticky='w', padx=(3, 16))
        scen_cb.bind('<<ComboboxSelected>>', lambda _e: self._reload_problem())
        self._cfg_label(cfgf, '任务', r, 2)
        ttk.Spinbox(cfgf, from_=1, to=20, textvariable=self.fid, width=5,
                    command=self._reload_problem).grid(
            row=r, column=3, sticky='w', padx=(3, 16))
        self._cfg_label(cfgf, '航点K(0=默认)', r, 4)
        ttk.Spinbox(cfgf, from_=0, to=20, textvariable=self.n_waypoints,
                    width=5, command=self._reload_problem).grid(
            row=r, column=5, sticky='w', padx=(3, 16))
        self._cfg_label(cfgf, '算法', r, 6)
        ttk.Combobox(cfgf, textvariable=self.host, values=DHC.CEC_HOST_ORDER,
                     width=16, state='readonly').grid(
            row=r, column=7, sticky='w', padx=(3, 16))
        self._cfg_label(cfgf, '预算(×D)', r, 8)
        ttk.Spinbox(cfgf, from_=50, to=10000, increment=50,
                    textvariable=self.evals_mult, width=7).grid(
            row=r, column=9, sticky='w', padx=(3, 16))
        self._cfg_label(cfgf, '臂', r, 10)
        ttk.Combobox(cfgf, textvariable=self.arm, values=['bare', 'full'],
                     width=6, state='readonly').grid(
            row=r, column=11, sticky='w', padx=(3, 0))

        btns = ttk.Frame(cfgf)
        btns.grid(row=r, column=12, sticky='e', padx=(24, 0))
        self.btn_run = ttk.Button(btns, text='运行优化', command=self._on_run_btn,
                                  style='Accent.TButton')
        self.btn_run.pack(side='left', padx=(0, 6))
        self.btn_stop = ttk.Button(btns, text='终止', command=self._stop_optimize,
                                   state='disabled')
        self.btn_stop.pack(side='left', padx=(0, 6))
        self.btn_demo = ttk.Button(btns, text='演示仿真', command=self._start_anim)
        self.btn_demo.pack(side='left', padx=6)
        self.btn_hist = ttk.Button(btns, text='历史数据', command=self._open_history)
        self.btn_hist.pack(side='left', padx=6)
        self.btn_save = ttk.Button(btns, text='下载图片', command=self._download_images)
        self.btn_save.pack(side='left', padx=(6, 0))
        cfgf.columnconfigure(12, weight=1)

        r = 1
        self._cfg_label(cfgf, '难度', r, 0)
        diff_cb = ttk.Combobox(cfgf, textvariable=self.difficulty,
                               values=DIFFICULTY_OPTIONS, width=20,
                               state='readonly')
        diff_cb.grid(row=r, column=1, sticky='w', padx=(3, 16))
        diff_cb.bind('<<ComboboxSelected>>',
                     lambda _e: (self._sync_drl_algo_state(),
                                 self._reload_problem()))
        self._cfg_label(cfgf, 'DRL算法', r, 2)
        self.drl_algo_cb = ttk.Combobox(cfgf, textvariable=self.drl_algo,
                                        values=DRL_ALGO_OPTIONS, width=18,
                                        state='readonly')
        self.drl_algo_cb.grid(row=r, column=3, sticky='w', padx=(3, 16))
        self.drl_algo_cb.bind('<<ComboboxSelected>>',
                              lambda _e: self._reload_problem())

        # ---- 主体三栏 ----
        body = ttk.Frame(self.root)
        body.pack(side='top', fill='both', expand=True, padx=10, pady=(0, 6))
        body.columnconfigure(0, weight=0, minsize=260)
        body.columnconfigure(1, weight=1, minsize=390)
        body.columnconfigure(2, weight=0, minsize=280)
        body.rowconfigure(0, weight=1)

        # 左：场景说明 / 环境参数（选项卡）
        left = ttk.Frame(body)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        left.rowconfigure(0, weight=1)
        left.columnconfigure(0, weight=1)
        nb = ttk.Notebook(left)
        nb.grid(row=0, column=0, sticky='nsew')
        t1 = ttk.Frame(nb, padding=6)
        t2 = ttk.Frame(nb, padding=6)
        nb.add(t1, text=' 场景说明 ')
        nb.add(t2, text=' 环境参数 ')
        self.brief_text = tk.Text(t1, height=10, wrap='word', state='disabled',
                                  relief='flat', font=('Microsoft YaHei', 9))
        self.brief_text.pack(fill='both', expand=True)
        self.param_tree = ttk.Treeview(t2, columns=('v',), show='tree headings',
                                       height=18)
        self.param_tree.heading('#0', text='参数')
        self.param_tree.heading('v', text='取值')
        self.param_tree.column('#0', width=120, anchor='w')
        self.param_tree.column('v', width=120, anchor='w')
        vsb = ttk.Scrollbar(t2, orient='vertical', command=self.param_tree.yview)
        self.param_tree.configure(yscrollcommand=vsb.set)
        self.param_tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')

        # 中：地图
        mf = ttk.LabelFrame(body, text=' 对抗仿真演示 ', padding=4)
        mf.grid(row=0, column=1, sticky='nsew', padx=(0, 8))
        mf.rowconfigure(0, weight=1)
        mf.columnconfigure(0, weight=1)
        self.map_fig, self.map_ax = plt.subplots(figsize=(6.0, 6.0))
        self.map_canvas = FigureCanvasTkAgg(self.map_fig, master=mf)
        self.map_canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')

        # 右：优化结果
        rf = ttk.LabelFrame(body, text=' 优化结果 ', padding=4)
        rf.grid(row=0, column=2, sticky='nsew')
        rf.rowconfigure(1, weight=1)
        rf.columnconfigure(0, weight=1)
        self.conv_fig, self.conv_ax = plt.subplots(figsize=(4.4, 3.0))
        self.conv_canvas = FigureCanvasTkAgg(self.conv_fig, master=rf)
        self.conv_canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')
        self.metric_text = tk.Text(rf, height=8, width=36, wrap='word',
                                   state='disabled', relief='flat',
                                   font=('Microsoft YaHei', 9))
        self.metric_text.grid(row=1, column=0, sticky='nsew', pady=(4, 0))

        # ---- 底部状态栏 ----
        bottom = ttk.Frame(self.root, padding=(10, 6))
        bottom.pack(side='bottom', fill='x')
        self.btn_play = ttk.Button(bottom, text='播放 / 暂停',
                                   command=self._toggle_anim)
        self.btn_play.pack(side='left')
        self.btn_reset = ttk.Button(bottom, text='重置', command=self._reset_anim)
        self.btn_reset.pack(side='left', padx=6)
        self.btn_kill = ttk.Button(bottom, text='击落细节',
                                   command=self._open_kill_detail)
        self.btn_kill.pack(side='left', padx=6)
        ttk.Separator(bottom, orient='vertical').pack(side='left', fill='y',
                                                      padx=10, pady=2)
        ttk.Label(bottom, text='速度:').pack(side='left')
        ttk.Scale(bottom, from_=10.0, to=200.0, orient='horizontal',
                  variable=self.speed, length=150).pack(side='left',
                                                       padx=(4, 10))
        ttk.Separator(bottom, orient='vertical').pack(side='left', fill='y',
                                                      padx=10, pady=2)
        ttk.Label(bottom, text='进度:').pack(side='left')
        self.progress = ttk.Progressbar(bottom, orient='horizontal', length=200,
                                        mode='determinate', maximum=100.0,
                                        value=0.0)
        self.progress.pack(side='left', padx=(4, 10))
        ttk.Separator(bottom, orient='vertical').pack(side='left', fill='y',
                                                      padx=10, pady=2)
        self.status = ttk.Label(bottom, text='就绪', anchor='w')
        self.status.pack(side='left', fill='x', expand=True, padx=(4, 0))

    # --------------------------------------------------------------- 数据
    def _difficulty_key(self):
        """界面文字 → 难度 key（L0~L6）。"""
        return DIFFICULTY_BY_LABEL.get(self.difficulty.get(), 'L1')

    def _drl_algo_key(self):
        """界面文字 → 训练算法 key（es/cem/spsa）。"""
        return DRL_ALGO_BY_LABEL.get(self.drl_algo.get(), 'es')

    def _sync_drl_algo_state(self):
        """难度为 DRL 档（L4/L5/L6）时启用 DRL 算法选择，否则禁用。"""
        if getattr(self, 'drl_algo_cb', None) is not None:
            self.drl_algo_cb.config(
                state='readonly' if is_drl_difficulty(self._difficulty_key())
                else 'disabled')

    def _reload_problem(self):
        self._sync_drl_algo_state()
        self._reload_gen += 1          # 使之前未完成的训练结果失效
        gen = self._reload_gen
        try:
            scen = self.scenario.get()
            fid = int(self.fid.get())
            if fid < 1:
                fid = 1
            if fid > SCENARIO_NFUNCS.get(scen, 1):
                fid = SCENARIO_NFUNCS[scen]
                self.fid.set(fid)
            # 航点数 K：0 = 默认，2~20 自定义（维度 D = n_drones * 2K）
            kw = int(self.n_waypoints.get())
            if kw > 20:
                kw = 20
                self.n_waypoints.set(20)
            if 0 < kw < 2:
                kw = 2
                self.n_waypoints.set(2)
            kw = kw if kw > 0 else None
            diff_key = self._difficulty_key()
            algo_key = self._drl_algo_key()
            opp = make_opponent(diff_key, drl_algo=algo_key, seed=fid * 101)
            self.problem = get_uav_problem(scen, fid=fid, n_waypoints=kw,
                                           opponent=opp)
            self._clear_results()
            self._show_brief()
            self._show_params()
            self._draw_static_map()
            ktxt = f'K={self.problem.cfg.n_waypoints}'
            if kw is None:  # 用户填 0 → 回落场景默认航点数
                ktxt += f'(默认 {SCENARIO_DEFAULT_K[scen]})'
            if is_drl_difficulty(diff_key):
                self._start_train_async(scen, diff_key, algo_key, gen)
                self.status.config(text=f'场景 {scen} 任务 {fid} 已加载 '
                                        f'(D={self.problem.dim}, {ktxt})，'
                                        f'红方对手后台训练中…')
            else:
                self.status.config(text=f'场景 {scen} 任务 {fid} 已加载 '
                                        f'(D={self.problem.dim}, {ktxt})')
        except Exception as exc:
            messagebox.showerror('加载失败', repr(exc))

    def _start_train_async(self, scen, diff_key, algo_key, gen):
        """后台线程训练 DRL 对手；完成/失败回到主线程更新状态。"""
        cache_key = (scen, diff_key, algo_key)
        if cache_key in self._train_cache:
            self.problem.env.opponent = self._train_cache[cache_key]
            self.status.config(
                text=f'红方对手已就绪（{DIFFICULTY_LABELS[diff_key]}），'
                     f'可点击「启动优化」')
            return
        env = self.problem.env

        def _job():
            try:
                policy = train_opponent(env, diff_key, algo_key, seed=0)
                self._train_cache[cache_key] = policy
                self.root.after(0, lambda: self._on_train_done(gen, diff_key))
            except Exception as exc:
                self.root.after(0, lambda: self._on_train_err(gen, exc))

        threading.Thread(target=_job, daemon=True).start()

    def _on_train_done(self, gen, diff_key):
        if gen != self._reload_gen:
            return                     # 过期结果，丢弃（环境已重建）
        self.status.config(text=f'红方对手就绪（{DIFFICULTY_LABELS[diff_key]}），'
                                f'可点击「启动优化」')

    def _on_train_err(self, gen, exc):
        if gen != self._reload_gen:
            return
        self.status.config(text=f'红方对手训练失败：{exc}')

    def _clear_results(self):
        self.best_x = None
        self.best_f = None
        self.conv = None
        self.frames = None
        self._progress_val = 0.0
        self._stop_anim()
        self._draw_static_map()
        if hasattr(self, 'progress'):
            self.progress.config(value=0.0)
        self.gen_metrics = []
        self.conv_fig.clf()
        self.conv_ax = self.conv_fig.add_subplot(111)
        self.conv_ax.set_title('收敛曲线（运行后显示）')
        self.conv_canvas.draw()
        self.metric_text.config(state='normal')
        self.metric_text.delete('1.0', 'end')
        self.metric_text.config(state='disabled')

    def _show_brief(self):
        """左侧想定场景说明：本场景在模拟什么任务、如何设定。"""
        cfg = self.problem.cfg
        fid = int(self.fid.get())
        if self.problem.scenario == 'swarm':
            self._show_brief_swarm(cfg, fid)
            return
        ints = ', '.join(f'({p[0]:.0f},{p[1]:.0f})' for p in cfg.interceptor_pos)
        nofly = (f'{len(cfg.no_fly_zones)} 个：' +
                 ', '.join(f'({c:.0f},{d:.0f},r={r:.0f})'
                           for c, d, r in cfg.no_fly_zones)
                 if cfg.no_fly_zones else '无')

        txt = (
            '【任务想定】红蓝对抗 · 无人机突防与拦截\n'
            '──────────────────────────────\n'
            f'蓝方（突防方，被优化）：{cfg.n_drones} 架无人机从起点 '
            f'{cfg.start_pos} 出发，突防至目标区中心 {cfg.target_pos} '
            f'（判定半径 {cfg.target_radius:.0f}）。\n\n'
            f'红方（拦截者）：{cfg.n_interceptors} 架，初始位置 {ints}，'
            f'按“追击最近存活目标”规则机动，其前方 ±'
            f'{np.degrees(cfg.intercept_half_angle):.0f}° 扇形、'
            f'{cfg.intercept_radius:.0f} 距离内的无人机即被捕获/击落。\n\n'
            f'禁飞区：{nofly}。\n\n'
            f'【决策变量】每架无人机的 {cfg.n_waypoints} 个中途航点 (x,y)，'
            f'共 D={cfg.dim} 维，编码域 [-1,1]^D，由 DE 连续优化。\n\n'
            '【物理模型】匀速飞行 + 限角速度转向（无直角转弯）：\n'
            f'  我方  速度 {cfg.drone_speed:.1f}/步，转弯速率 '
            f'{cfg.drone_turn_rate:.2f} rad/步（最小转弯半径 '
            f'{cfg.drone_speed / cfg.drone_turn_rate:.0f}）；\n'
            f'  拦截者 速度 {cfg.interceptor_speed:.1f}/步，转弯速率 '
            f'{cfg.interceptor_turn_rate:.2f} rad/步。\n\n'
            '【评分（cost 越小越好 = -收益）】\n'
            f'  到达 +{cfg.w_arrive:.0f}/架；被击落 -{cfg.w_lost:.0f}/架；\n'
            f'  未完成 -{cfg.w_time:.0f}/架；禁飞区 -{cfg.w_nofly:.0f}/步；\n'
            f'  越界 -{cfg.w_bounds:.0f}/步；机间碰撞 -{cfg.w_collision:.0f}/次。\n\n'
            f'【本任务 F{fid}】'
        )
        if fid == 1:
            txt += ('基线——1 个拦截者 + 3 处基础山地（禁飞区），'
                    '无人机需绕开拦截者与山地。')
        elif fid == 2:
            txt += ('1 个拦截者 + 5 处禁飞区（复杂峡谷/S 形通道），'
                    '须同时规避拦截与禁飞区。')
        elif fid == 3:
            txt += ('2 个拦截者协同拦截 + 4 处山地（禁飞区），'
                    '突防难度增大。')
        elif fid == 4:
            txt += ('2 个更快拦截者（16/步）+ 6 处禁飞区（复杂峡谷），'
                    '多机协同拦截。')
        else:
            txt += (f'{cfg.n_interceptors} 个拦截者、'
                    f'{len(cfg.no_fly_zones)} 个禁飞区。')

        self.brief_text.config(state='normal')
        self.brief_text.delete('1.0', 'end')
        self.brief_text.insert('1.0', txt)
        self.brief_text.config(state='disabled')

    def _show_brief_swarm(self, cfg, fid):
        """集群协同对抗（2020 华为杯研究生数学建模 D 题）场景说明。"""
        centers = ', '.join(f'({c[0] / 1000:.0f},{c[1] / 1000:.0f})'
                            for c in cfg.cluster_centers)
        txt = (
            '【任务想定】无人机集群协同对抗（2020 华为杯研究生数学建模 D 题）\n'
            '──────────────────────────────\n'
            f'对抗区域：纵深 L={cfg.depth / 1000:.0f} km × 带宽 '
            f'M={cfg.width / 1000:.0f} km 的矩形通道。\n\n'
            f'蓝方（突防方，被优化）：{cfg.n_attack} 架从带宽中点（AB 边）'
            f'出发，须在 {cfg.time_limit:.0f} s 内越过 CD 边（纵深 y=L）'
            f'突防成功。\n\n'
            f'红方（拦截方）：{cfg.n_clusters} 个集群 × {cfg.cluster_size} 架，'
            f'初始圆周均布（半径 {cfg.formation_radius:.0f} m），中心位于 '
            f'{centers}（单位 km），按“追击最近目标”机动。\n\n'
            f'拦截判据：蓝方落入 ≥{cfg.intercept_min_count} 架红方机头前方 ±'
            f'{cfg.intercept_half_angle:.0f}° 扇区、距离 < {cfg.intercept_radius:.0f} m'
            f' 即被击落。\n\n'
            f'【决策变量】蓝方 {cfg.n_waypoints} 个中途航点 (x,y)，'
            f'共 D={cfg.dim} 维，编码域 [-1,1]^D，由 DE 连续优化。\n\n'
            '【物理模型】双方匀速 + 最小转弯半径限制（无直角转弯）：\n'
            f'  蓝方 速度 {cfg.attack_speed:.0f} m/s，最小转弯半径 '
            f'{cfg.attack_turn_radius:.0f} m（角速度 {cfg.max_turn_attack:.3f} '
            f'rad/s）；\n'
            f'  红方 速度 {cfg.defend_speed:.0f} m/s，最小转弯半径 '
            f'{cfg.defend_turn_radius:.0f} m（角速度 {cfg.max_turn_defend:.3f} '
            f'rad/s）。\n\n'
            '【评分（cost 越小越好 = -收益）】\n'
            f'  突防成功 +{cfg.w_arrive:.0f}/架；被拦截 -{cfg.w_lost:.0f}/架；\n'
            f'  超时未完成 -{cfg.w_time:.0f}/架；越界 -{cfg.w_bounds:.0f}/步。\n\n'
            f'【本任务 F{fid}】'
        )
        if fid == 1:
            txt += '问题一：双集群（各 5 架）沿纵深错开，蓝方绕开拦截。'
        elif fid == 2:
            txt += '问题二：窄通道（12 km）+ 集群贴近 CD，考验突防可行性。'
        elif fid == 3:
            txt += '问题三：两波次增援（每集群 10 架），拦截强度增大。'
        elif fid == 4:
            txt += '问题四：5 集群（各 4 架）多机协同拦截（单机加强版）。'
        else:
            txt += f'{cfg.n_clusters} 集群 × {cfg.cluster_size} 架协同拦截。'

        self.brief_text.config(state='normal')
        self.brief_text.delete('1.0', 'end')
        self.brief_text.insert('1.0', txt)
        self.brief_text.config(state='disabled')

    def _show_params(self):
        self.param_tree.delete(*self.param_tree.get_children())
        for k, v in self.problem.cfg.describe().items():
            self.param_tree.insert('', 'end', text=k, values=(str(v),))

    # --------------------------------------------------------------- 地图
    # 飞机形状顶点：机头朝 +x（即东，heading=0），原点在机身中点。
    # 右翼朝 +y、左翼朝 -y，整体前后对称分布。
    _PLANE_VERTS = np.array([
        [1.00, 0.00],    # 机头
        [-0.15, 0.28],   # 右翼前缘
        [-0.32, 0.58],   # 右翼尖
        [-0.28, 0.10],   # 右翼根
        [-0.82, 0.18],   # 右平尾
        [-1.00, 0.00],   # 机尾
        [-0.82, -0.18],  # 左平尾
        [-0.28, -0.10],  # 左翼根
        [-0.32, -0.58],  # 左翼尖
        [-0.15, -0.28],  # 左翼前缘
    ])

    def _plane_verts(self, scale):
        return self._PLANE_VERTS * scale

    def _make_plane(self, ax, x, y, heading, color, scale, zorder=6,
                    visible=True):
        """创建一个飞机形状 Polygon：机头真实指向 heading（rad，0=东）。

        用仿射变换把「机头朝 +x」的本地顶点绕原点旋转 heading 后平移到
        (x, y)，因此机头永远指向飞行方向，不会出现歪/倒飞。
        """
        poly = Polygon(self._plane_verts(scale), closed=True,
                       facecolor=color, edgecolor='#1a1a1a', linewidth=0.8,
                       zorder=zorder, visible=visible)
        ax.add_patch(poly)
        self._update_plane(poly, x, y, heading)
        return poly

    def _update_plane(self, poly, x, y, heading):
        ax = getattr(poly, 'axes', None) or self.map_ax
        t = (mtransforms.Affine2D()
             .rotate_deg(float(np.degrees(heading)))
             .translate(float(x), float(y)) + ax.transData)
        poly.set_transform(t)

    def _make_capture_wedge(self, ax, x, y, heading, radius, half_angle,
                            color, zorder=4, visible=True, nose_offset=0.0):
        """拦截者前方扇形捕获范围：顶点在机头（中心沿 heading 前移 nose_offset）、
        机头朝向 ±half_angle、半径 radius。"""
        half_deg = float(np.degrees(half_angle))
        hdeg = float(np.degrees(heading))
        cx = x + nose_offset * np.cos(heading)
        cy = y + nose_offset * np.sin(heading)
        wedge = Wedge((cx, cy), radius, hdeg - half_deg, hdeg + half_deg,
                      facecolor=color, alpha=0.16, edgecolor=color,
                      linewidth=1.0, linestyle='--', zorder=zorder,
                      visible=visible)
        wedge.nose_offset = nose_offset
        ax.add_patch(wedge)
        return wedge

    def _update_wedge(self, wedge, x, y, heading, half_angle):
        half_deg = float(np.degrees(half_angle))
        hdeg = float(np.degrees(heading))
        no = getattr(wedge, 'nose_offset', 0.0)
        cx = x + no * np.cos(heading)
        cy = y + no * np.sin(heading)
        wedge.set_center((cx, cy))
        wedge.set_theta1(hdeg - half_deg)
        wedge.set_theta2(hdeg + half_deg)

    def _plane_scales(self):
        """返回 (起点, 蓝方, 红方) 飞机显示尺度；swarm 地图大，用大尺度。"""
        if self.problem.scenario == 'swarm':
            return 1800.0, 1600.0, 800.0
        return 26.0, 22.0, 30.0

    def _setup_axes(self, ax, cfg, x0, x1, y0, y1):
        ax.set_xlim(x0, x1)
        ax.set_ylim(y0, y1)
        ax.set_aspect('equal')
        ax.set_title(f'{self.problem.name}  ·  任务 F{int(self.fid.get())}'
                     f'  ·  D={cfg.dim}', fontsize=12, fontweight='bold',
                     color='#1f4e79', pad=10)
        ax.grid(True, linestyle='-', linewidth=0.4, alpha=0.10, color='#9fb8d0')
        ax.set_facecolor('#eaf2fb')          # 淡蓝「空域」背景
        for spine in ax.spines.values():
            spine.set_color('#8fa8c0')
            spine.set_linewidth(0.8)

    def _draw_static_map(self):
        ax = self.map_ax
        ax.clear()
        cfg = self.problem.cfg
        if self.problem.scenario == 'swarm':
            self._draw_static_swarm(ax, cfg)
        else:
            self._draw_static_intercept(ax, cfg)
        self.map_canvas.draw()

    def _draw_static_intercept(self, ax, cfg):
        self._setup_axes(ax, cfg, -20, cfg.map_w + 20, -20, cfg.map_h + 20)

        # 目标区：外圈描边 + 内圈半透明填充 + 中心准星
        tx, ty = cfg.target_pos
        tr = cfg.target_radius
        ax.add_patch(Circle((tx, ty), tr, fill=True, color='tab:green',
                            alpha=0.18, zorder=1))
        ax.add_patch(Circle((tx, ty), tr, fill=False, edgecolor='tab:green',
                            linewidth=2.0, linestyle='--', zorder=2))
        ax.plot(tx, ty, marker='+', color='tab:green', ms=12, mew=2.0,
                zorder=3)
        ax.text(tx, ty - tr - 25, '目标区', ha='center', fontsize=9,
                color='#1e7a34', weight='bold')

        # 起点：飞机形状（机头朝向目标方向）
        sx, sy = cfg.start_pos
        h0 = float(np.arctan2(cfg.target_pos[1] - sy, cfg.target_pos[0] - sx))
        self.start_plane = self._make_plane(ax, sx, sy, h0, '#222222', 26,
                                            zorder=5)
        self.start_label = ax.text(sx, sy - 40, '起点', ha='center',
                                   fontsize=9, color='#222222', weight='bold')

        # 禁飞区：半透明填充 + 斜纹 + 描边
        for (cx, cy, cr) in cfg.no_fly_zones:
            ax.add_patch(Circle((cx, cy), cr, fill=True, facecolor='tab:red',
                                alpha=0.14, hatch='//', edgecolor='tab:red',
                                linewidth=1.2, zorder=1))
            ax.text(cx, cy, '禁飞区', ha='center', va='center', fontsize=8,
                    color='#b02418', weight='bold', zorder=2)

        # 拦截者初始：飞机形状 + 前方扇形捕获范围（机头朝向目标方向）
        ipos = self.problem.env.interceptors0
        irad = cfg.intercept_radius
        ihalf = cfg.intercept_half_angle
        self.inter0_planes = []
        self.inter0_wedges = []
        self.inter0_labels = []
        for k, (px, py) in enumerate(ipos):
            hi = float(np.arctan2(ty - py, tx - px))
            self.inter0_planes.append(
                self._make_plane(ax, float(px), float(py), hi, 'tab:red', 30,
                                 zorder=5))
            self.inter0_wedges.append(
                self._make_capture_wedge(ax, float(px), float(py), hi, irad,
                                         ihalf, 'tab:red', zorder=4,
                                         nose_offset=30))
        if len(ipos) == 1:
            self.inter0_labels.append(
                ax.text(ipos[0][0], ipos[0][1] - 46, '拦截者', ha='center',
                        fontsize=9, color='tab:red', weight='bold'))

        # 动态无人机 / 拦截者飞机（动画时更新位置与朝向，初始隐藏）
        self.drone_planes = [
            self._make_plane(ax, 0, 0, 0.0, 'tab:blue', 22, zorder=6,
                             visible=False)
            for _ in range(cfg.n_drones)]
        self.inter_planes = [
            self._make_plane(ax, 0, 0, 0.0, 'tab:red', 30, zorder=6,
                             visible=False)
            for _ in range(len(ipos))]
        self.inter_wedges = [
            self._make_capture_wedge(ax, 0, 0, 0.0, irad, ihalf, 'tab:red',
                                     zorder=4, visible=False, nose_offset=30)
            for _ in range(len(ipos))]

        # 图例：置于图外右侧，避免遮挡仿真环境
        ax.legend(handles=[
            Patch(facecolor='tab:green', alpha=0.5, label='目标区'),
            Patch(facecolor='tab:red', alpha=0.5, label='禁飞区'),
            Patch(facecolor='#222222', label='蓝方起点'),
            Patch(facecolor='tab:red', label='拦截者'),
            Patch(facecolor='tab:blue', label='无人机'),
        ], loc='center left', bbox_to_anchor=(1.01, 0.5), fontsize=8,
           framealpha=0.9, borderaxespad=0)
        self.map_fig.subplots_adjust(right=0.78)

    def _draw_static_swarm(self, ax, cfg):
        W, L = cfg.width, cfg.depth
        pad = max(W, L) * 0.04
        self._setup_axes(ax, cfg, -pad, W + pad, -pad, L + pad)

        # 通道边界：AD(x=0) / BC(x=W)，蓝方出发边 AB(y=0) / 突防目标线 CD(y=L)
        ax.axvline(0.0, color='#b0bcc8', lw=2, ls='--')
        ax.axvline(W, color='#b0bcc8', lw=2, ls='--')
        ax.axhline(0.0, color='#222222', lw=2.5)
        ax.axhline(L, color='tab:green', lw=2.5)
        ax.text(W / 2, -pad * 0.55, 'AB 蓝方出发边', ha='center', fontsize=10,
                color='#222222', weight='bold')
        ax.text(W / 2, L + pad * 0.28, 'CD 突防目标线', ha='center',
                fontsize=10, color='tab:green', weight='bold')
        ax.text(-pad * 0.55, L / 2, '通道边界 AD', va='center', fontsize=9,
                color='#7a8a99', rotation=90)
        ax.text(W + pad * 0.30, L / 2, '通道边界 BC', va='center', fontsize=9,
                color='#7a8a99', rotation=90)

        s0, sd, si = self._plane_scales()

        # 蓝方起点（AB 中心，机头朝北即纵深方向）
        sx, sy = W / 2.0, 0.0
        self.start_plane = self._make_plane(ax, sx, sy, np.pi / 2.0, '#222222',
                                            s0, zorder=5)
        self.start_label = ax.text(sx, sy - pad * 0.35, '蓝方起点', ha='center',
                                   fontsize=10, color='#222222', weight='bold')

        # 红方集群：中心标记 + 各机 + 前方扇形捕获区（半角 intercept_half_angle，
        # 显示半径放大 80 倍以保证 50 km 尺度下可见，物理拦截判据为 55 m）。
        ipos = self.problem.env.interceptors0
        irad_vis = cfg.intercept_radius * 80.0
        ihalf = cfg.intercept_half_angle_rad
        self.inter0_planes = []
        self.inter0_wedges = []
        self.inter0_labels = []
        for k, (cx, cy) in enumerate(cfg.cluster_centers):
            ax.plot(cx, cy, 'x', color='tab:red', ms=11, mew=2.5, zorder=5)
            self.inter0_labels.append(
                ax.text(cx, cy - pad * 0.28, f'红方集群 {k + 1}', ha='center',
                        fontsize=9, color='tab:red', weight='bold'))
        for (px, py) in ipos:
            hi = float(np.arctan2(L - py, 0.0))
            self.inter0_planes.append(
                self._make_plane(ax, float(px), float(py), hi, 'tab:red', si,
                                 zorder=5))
            self.inter0_wedges.append(
                self._make_capture_wedge(ax, float(px), float(py), hi,
                                         irad_vis, ihalf, 'tab:red', zorder=4,
                                         nose_offset=si))

        # 动态无人机 / 拦截者飞机（初始隐藏）
        self.drone_planes = [
            self._make_plane(ax, 0, 0, 0.0, 'tab:blue', sd, zorder=6,
                             visible=False)
            for _ in range(cfg.n_drones)]
        self.inter_planes = [
            self._make_plane(ax, 0, 0, 0.0, 'tab:red', si, zorder=6,
                             visible=False)
            for _ in range(len(ipos))]
        self.inter_wedges = [
            self._make_capture_wedge(ax, 0, 0, 0.0, irad_vis, ihalf,
                                     'tab:red', zorder=4, visible=False,
                                     nose_offset=si)
            for _ in range(len(ipos))]

        # 图例：置于图外右侧，避免遮挡仿真环境
        ax.legend(handles=[
            Patch(facecolor='#222222', label='蓝方起点'),
            Patch(facecolor='tab:red', label='红方拦截机'),
            Patch(facecolor='tab:blue', label='突防无人机'),
            Line2D([0], [0], color='tab:green', lw=2.5, label='突防目标线 CD'),
        ], loc='center left', bbox_to_anchor=(1.01, 0.5), fontsize=8,
           framealpha=0.9, borderaxespad=0)
        self.map_fig.subplots_adjust(right=0.78)

    def _set_static_actors_visible(self, visible: bool):
        """显示/隐藏静态起点与拦截者图标（动画播放时隐藏，结束后恢复）。"""
        for attr in ('start_plane', 'start_label', 'inter0_planes',
                     'inter0_wedges', 'inter0_labels'):
            obj = getattr(self, attr, None)
            if obj is None:
                continue
            if isinstance(obj, list):
                for o in obj:
                    o.set_visible(visible)
            else:
                obj.set_visible(visible)

    def _anim_tick(self):
        if self.frames is None:
            return
        if self.anim_i >= len(self.frames):
            self._stop_anim()
            return
        fr = self.frames[self.anim_i]
        drones = fr['drones']
        its = fr['interceptors']

        # 无人机飞机：位置 / 机头朝向（真实航向 heading）/ 颜色（按状态）
        for i, plane in enumerate(self.drone_planes):
            if i >= len(drones):
                plane.set_visible(False)
                continue
            d = drones[i]
            if d[2] == 2:                       # 被击落：隐藏飞机
                plane.set_visible(False)
                continue
            plane.set_visible(True)
            plane.set_facecolor(STATE_COLORS[d[2]])
            self._update_plane(plane, d[0], d[1], d[3])

        # 拦截者飞机 + 前方捕获扇形（swarm / intercept 均有扇形）
        cfg = self.problem.cfg
        ihalf = (cfg.intercept_half_angle_rad
                 if hasattr(cfg, 'intercept_half_angle_rad')
                 else getattr(cfg, 'intercept_half_angle', None))
        for k, plane in enumerate(self.inter_planes):
            if k >= len(its):
                plane.set_visible(False)
                if k < len(self.inter_wedges):
                    self.inter_wedges[k].set_visible(False)
                continue
            p = its[k]
            plane.set_visible(True)
            self._update_plane(plane, p[0], p[1], p[2])
            if ihalf is not None and k < len(self.inter_wedges):
                w = self.inter_wedges[k]
                w.set_visible(True)
                self._update_wedge(w, p[0], p[1], p[2], ihalf)

        n_arr = sum(1 for d in drones if d[2] == 1)
        n_lost = sum(1 for d in drones if d[2] == 2)
        self.map_ax.set_title(
            f'step {fr["step"]}/{len(self.frames) - 1}    '
            f'到达 {n_arr}   被击落 {n_lost}',
            fontsize=11, fontweight='bold', color='#2c5f8a')
        self.map_canvas.draw_idle()
        self.anim_i += 1
        self.anim_after = self.root.after(int(self.speed.get()),
                                          self._anim_tick)

    def _draw_trajectories(self, x):
        """画出每条无人机的实际平滑飞行轨迹（限角速度 → 弧线转弯）。

        轨迹直接取自仿真帧（frames），是真实飞行的平滑曲线，而非航点连线
        折线；同时用空心圆标出优化得到的航点位置。
        """
        cfg = self.problem.cfg
        n = cfg.n_drones
        colors = plt.cm.tab10(np.linspace(0, 1, n))

        # 实际飞行轨迹（含起点；被击落则画到击落点为止）
        if self.frames:
            for i in range(n):
                pts = []
                for fr in self.frames:
                    d = fr['drones'][i]
                    pts.append((d[0], d[1]))
                    if d[2] == 2:          # 被击落：此点为终点
                        break
                if len(pts) < 2:
                    continue
                pts = np.asarray(pts)
                self.map_ax.plot(pts[:, 0], pts[:, 1], ls='-', lw=1.5,
                                 color=colors[i], alpha=0.85, zorder=3)

        # 航点：小号实心圆点（决策变量），白描边、与轨迹同色
        try:
            wps = self.problem.decode(np.asarray(x, dtype=float).ravel())
            for i in range(n):
                for (wx, wy) in wps[i]:
                    self.map_ax.plot(wx, wy, 'o', ms=5, mfc=colors[i],
                                     mec='white', mew=1.0, alpha=0.95, zorder=4)
        except Exception:
            pass
        self.map_canvas.draw_idle()

    def _default_demo_x(self):
        """未优化时的演示默认解：让多架无人机航点确定性分散，避免路径退化一致。"""
        cfg = self.problem.cfg
        x = np.zeros(self.problem.dim)
        if self.scenario.get() == 'swarm':
            n, K = cfg.n_attack, cfg.n_waypoints
            for i in range(n):
                base = i * K * 2
                for k in range(K):
                    t = (k + 1) / (K + 1)
                    x[base + 2 * k] = 0.18 * np.sin(t * np.pi)
                    x[base + 2 * k + 1] = 2.0 * t - 1.0
        else:
            n, K = cfg.n_drones, cfg.n_waypoints
            for i in range(n):
                base = i * K * 2
                spread = (2.0 * i / (n - 1) - 1.0) if n > 1 else 0.0
                for k in range(K):
                    t = (k + 1) / (K + 1)
                    amp = 0.38 * (1.0 - abs(2.0 * t - 1.0))
                    x[base + 2 * k] = (2.0 * t - 1.0) + spread * amp
                    x[base + 2 * k + 1] = (2.0 * t - 1.0) - spread * amp
        return np.clip(x, -1.0, 1.0)

    def _start_anim(self):
        if self.problem is None:
            return
        self._stop_anim()                  # 清理可能残留的旧定时器，避免双定时器
        x = self.best_x
        if x is None:
            x = self._default_demo_x()
        cost, state, frames = self.problem.trajectory(x)
        self.frames = frames
        self.final_state = state
        self.anim_i = 0
        self.status.config(text=f'演示轨迹：cost={cost:.1f}')
        self._draw_static_map()
        # 清除静态起点/拦截者图标（动态飞机将从这些位置起飞，避免重叠）
        self._set_static_actors_visible(False)
        self._draw_trajectories(x)
        self.btn_play.config(text='暂停')    # 播放中，按钮提示可暂停
        self._anim_tick()

    def _toggle_anim(self):
        if self.anim_after is not None:
            self._stop_anim()
        else:
            if self.frames is None:
                self._start_anim()
            else:
                self._anim_tick()

    def _reset_anim(self):
        self._stop_anim()
        self.anim_i = 0
        if self.frames is not None:
            self._draw_static_map()
            x = self.best_x
            if x is None:
                x = self._default_demo_x()
            self._draw_trajectories(x)

    def _stop_anim(self):
        if self.anim_after is not None:
            self.root.after_cancel(self.anim_after)
            self.anim_after = None
        btn = getattr(self, 'btn_play', None)
        if btn is not None:
            btn.config(text='播放')          # 动画停住（非结束进程），按钮回到「播放」

    # ----------------------------------------------------- 击落细节回放
    def _kill_ihalf(self):
        cfg = self.problem.cfg
        return (cfg.intercept_half_angle_rad
                if hasattr(cfg, 'intercept_half_angle_rad')
                else getattr(cfg, 'intercept_half_angle', 0.5236))

    def _find_kill_events(self):
        """扫描轨迹帧，找出每架无人机 state 0→2 的击落瞬间。

        返回 [{'frame', 'drone', 'killer', 'dist'}]：frame=击落帧号、
        drone=无人机索引、killer=捕获它的拦截者索引（扇形内最近者）、
        dist=击落时与该拦截者的距离。
        """
        events = []
        if not self.frames:
            return events
        cfg = self.problem.cfg
        irad = cfg.intercept_radius
        ihalf = self._kill_ihalf()
        n = len(self.frames[0]['drones'])
        prev = [d[2] for d in self.frames[0]['drones']]
        for idx in range(1, len(self.frames)):
            fr = self.frames[idx]
            cur = [d[2] for d in fr['drones']]
            for i in range(n):
                if prev[i] == 0 and cur[i] == 2:
                    dx, dy = fr['drones'][i][0], fr['drones'][i][1]
                    killer, best = -1, 1e18
                    for k, p in enumerate(fr['interceptors']):
                        d = np.hypot(dx - p[0], dy - p[1])
                        ang = np.arctan2(dy - p[1], dx - p[0])
                        diff = abs((ang - p[2] + np.pi) % (2 * np.pi) - np.pi)
                        if d <= irad and diff <= ihalf and d < best:
                            killer, best = k, d
                    events.append({'frame': idx, 'drone': i,
                                   'killer': killer, 'dist': best})
            prev = cur
        return events

    def _open_kill_detail(self):
        events = self._find_kill_events()
        self.kill_events = events
        if not events:
            messagebox.showinfo('击落细节', '当前轨迹没有无人机被击落。')
            return
        self._ensure_kill_window()
        self.kill_ev_i = 0
        self._kill_set_event(0)

    def _ensure_kill_window(self):
        if self.kill_win is not None and self.kill_win.winfo_exists():
            self.kill_win.deiconify()
            self.kill_win.lift()
            return
        win = tk.Toplevel(self.root)
        win.title('击落细节回放')
        win.geometry('580x680')
        self.kill_win = win
        self.kill_fig, self.kill_ax = plt.subplots(figsize=(5.4, 5.4))
        self.kill_canvas = FigureCanvasTkAgg(self.kill_fig, master=win)
        self.kill_canvas.get_tk_widget().pack(fill='both', expand=True)

        ctl = ttk.Frame(win, padding=(8, 6))
        ctl.pack(side='bottom', fill='x')
        ttk.Button(ctl, text='◀ 上一个', command=self._kill_prev).pack(side='left')
        ttk.Button(ctl, text='下一个 ▶', command=self._kill_next).pack(
            side='left', padx=6)
        self.kill_btn_play = ttk.Button(ctl, text='播放 / 暂停',
                                        command=self._kill_toggle)
        self.kill_btn_play.pack(side='left')
        ttk.Label(ctl, text='速度:').pack(side='left', padx=(12, 0))
        ttk.Scale(ctl, from_=80.0, to=800.0, variable=self.kill_speed,
                  length=120).pack(side='left', padx=(4, 0))
        self.kill_ev_label = ttk.Label(ctl, text='', anchor='e')
        self.kill_ev_label.pack(side='right', padx=(4, 0))
        win.protocol('WM_DELETE_WINDOW', self._kill_close)

    def _kill_set_event(self, ev_i):
        ev = self.kill_events[ev_i]
        self.kill_ev_i = ev_i
        PRE = 12
        self.kill_fr_lo = max(0, ev['frame'] - PRE)
        self.kill_fr_hi = ev['frame']
        self.kill_fr_i = self.kill_fr_lo

        # 放大范围：以击落点为中心，覆盖被击落机运动范围 + 附近拦截者，
        # 至少 5×拦截半径，保证捕获扇形清晰可见。
        cfg = self.problem.cfg
        irad = cfg.intercept_radius
        kx = self.frames[self.kill_fr_hi]['drones'][ev['drone']][0]
        ky = self.frames[self.kill_fr_hi]['drones'][ev['drone']][1]
        maxr = irad * 5.0
        for idx in range(self.kill_fr_lo, self.kill_fr_hi + 1):
            fr = self.frames[idx]
            d = fr['drones'][ev['drone']]
            maxr = max(maxr, np.hypot(d[0] - kx, d[1] - ky) * 1.3)
            for p in fr['interceptors']:
                pd = np.hypot(p[0] - kx, p[1] - ky)
                if pd <= irad * 6.0:
                    maxr = max(maxr, pd * 1.3)
        self.kill_xlim = (kx - maxr, kx + maxr)
        self.kill_ylim = (ky - maxr, ky + maxr)
        self._kill_draw()

    def _kill_draw(self):
        if self.kill_ax is None:
            return
        ev = self.kill_events[self.kill_ev_i]
        fr = self.frames[self.kill_fr_i]
        ax = self.kill_ax
        ax.clear()
        cfg = self.problem.cfg
        irad = cfg.intercept_radius
        ihalf = self._kill_ihalf()
        kx = self.frames[self.kill_fr_hi]['drones'][ev['drone']][0]
        ky = self.frames[self.kill_fr_hi]['drones'][ev['drone']][1]
        maxr = (self.kill_xlim[1] - self.kill_xlim[0]) * 0.5

        ax.set_xlim(*self.kill_xlim)
        ax.set_ylim(*self.kill_ylim)
        ax.set_aspect('equal')
        ax.grid(True, linestyle='-', linewidth=0.4, alpha=0.12,
                color='#9fb8d0')
        ax.set_facecolor('#eaf2fb')

        # 拦截半径参考圆（击落点处，展示 55m 捕获判据）
        ax.add_patch(Circle((kx, ky), irad, fill=False, edgecolor='tab:red',
                            linewidth=1.2, linestyle=':', alpha=0.6, zorder=2))
        ax.plot(kx, ky, 'x', color='tab:red', ms=7, mew=1.5, zorder=3)

        # 拦截者 + 真实物理尺度的捕获扇形（只画击落点附近的拦截者）
        s_red, s_blue = 20.0, 16.0
        for p in fr['interceptors']:
            if np.hypot(p[0] - kx, p[1] - ky) > irad * 6.0:
                continue
            self._make_plane(ax, p[0], p[1], p[2], 'tab:red', s_red, zorder=6)
            self._make_capture_wedge(ax, p[0], p[1], p[2], irad, ihalf,
                                     'tab:red', zorder=4, nose_offset=s_red)

        # 无人机：被击落机红色高亮跟踪，其余正常显示、已击落的隐藏
        for i, d in enumerate(fr['drones']):
            if i == ev['drone']:
                self._make_plane(ax, d[0], d[1], d[3], '#d62728', s_blue,
                                 zorder=7)
                if self.kill_fr_i == self.kill_fr_hi:
                    ax.plot(d[0], d[1], '*', color='#d62728', ms=22,
                            mec='white', mew=1.5, zorder=8)
                    ax.text(d[0], d[1] + maxr * 0.16, '击落', ha='center',
                            fontsize=10, color='#d62728', weight='bold',
                            zorder=8)
            elif d[2] == 2:
                continue
            else:
                self._make_plane(ax, d[0], d[1], d[3], STATE_COLORS[d[2]],
                                 s_blue, zorder=6)

        n_ev = len(self.kill_events)
        ax.set_title(
            f'击落 {self.kill_ev_i + 1}/{n_ev} · 无人机 #{ev["drone"] + 1}'
            f' @ step {ev["frame"]}    局部帧 {self.kill_fr_i}/'
            f'{self.kill_fr_hi}',
            fontsize=11, fontweight='bold', color='#b02418')
        if self.kill_ev_label is not None:
            txt = (f'击落 {self.kill_ev_i + 1}/{n_ev}：无人机 '
                   f'#{ev["drone"] + 1} @ step {ev["frame"]}')
            if ev['killer'] >= 0:
                txt += f'，距拦截者 {ev["dist"]:.0f} m'
            self.kill_ev_label.config(text=txt)
        self.kill_canvas.draw_idle()

    def _kill_tick(self):
        if self.kill_win is None or not self.kill_win.winfo_exists():
            return
        self._kill_draw()
        self.kill_fr_i += 1
        if self.kill_fr_i > self.kill_fr_hi:
            self.kill_fr_i = self.kill_fr_lo   # 循环回放当前击落事件
        self.kill_after = self.root.after(int(self.kill_speed.get()),
                                          self._kill_tick)

    def _kill_stop_timer(self):
        if self.kill_after is not None:
            self.root.after_cancel(self.kill_after)
            self.kill_after = None

    def _kill_toggle(self):
        if self.kill_after is not None:
            self._kill_stop_timer()
            self.kill_btn_play.config(text='播放')
        else:
            self.kill_btn_play.config(text='暂停')
            self._kill_tick()

    def _kill_prev(self):
        self._kill_stop_timer()
        self.kill_btn_play.config(text='播放')
        self._kill_set_event((self.kill_ev_i - 1) % len(self.kill_events))

    def _kill_next(self):
        self._kill_stop_timer()
        self.kill_btn_play.config(text='播放')
        self._kill_set_event((self.kill_ev_i + 1) % len(self.kill_events))

    def _kill_close(self):
        self._kill_stop_timer()
        if self.kill_win is not None:
            self.kill_win.destroy()
            self.kill_win = None
        self.kill_after = None
        self.kill_btn_play = None
        self.kill_ev_label = None
        self.kill_ax = None
        self.kill_fig = None
        self.kill_canvas = None

    # --------------------------------------------------------------- 优化
    @staticmethod
    def _run_once(host_name, problem, dim, seed, max_evals, arm,
                  progress_cb=None, gate=None):
        from upcl_framework import UPCLController
        host = de_hosts.get_host(host_name, dim, problem.lb, problem.ub,
                                 seed=seed,
                                 pop_size=DHC.pop_size_for(host_name, dim))
        controller = None
        if arm == 'full':
            controller = UPCLController(dim, problem.lb, problem.ub,
                                        seed=seed + 977,
                                        config=RUC.get_config('default'))
            host.gen_begin_fn = controller.begin_generation
            host.post_eval_fn = controller.observe
            host.proposal_fn = controller.propose

        evaluate = getattr(problem, 'evaluate', None)  # swarm 场景提供副指标
        gen_metrics = []

        def _cb(h):
            # host.run 每代结束调用 callback(self)，此处报告进度并记录副指标
            if gate is not None:
                gate()                 # 暂停时阻塞、终止时抛 _OptimizationAborted
            if progress_cb is not None:
                progress_cb(int(h.nevals), int(h.g))
            if evaluate is not None:
                try:
                    bx = np.asarray(h.pop[h.best_idx], dtype=float)
                    _, _, m = evaluate(bx)
                    gen_metrics.append(m)
                except Exception:
                    pass

        best_f, best_x, conv, evals = host.run(
            problem, max_evals,
            callback=_cb if (gate is not None or progress_cb is not None
                             or evaluate is not None) else None)
        return best_f, best_x, conv, evals, controller, gen_metrics

    def _on_run_btn(self):
        """运行优化按钮：按状态机在「启动 / 暂停 / 继续」间切换。"""
        if self._opt_state == 'idle':
            self._run_optimize()
        elif self._opt_state == 'running':
            self._pause_optimize()
        elif self._opt_state == 'paused':
            self._resume_optimize()

    def _run_optimize(self):
        if self._opt_state != 'idle' or self.problem is None:
            return
        self._opt_state = 'running'
        self.busy = True
        self._stop_flag = False
        self._pause_event.set()
        self._pending = None
        self._progress_val = 0.0
        self.progress.config(value=0.0)
        # 清空上次演示残留的轨迹/航点标记，优化期间地图回到干净的初始态
        self._stop_anim()
        self._draw_static_map()
        self.btn_run.config(text='暂停')
        self.btn_stop.config(state='normal')
        self.status.config(text='优化中…')
        host_name = self.host.get()
        arm = self.arm.get()
        dim = self.problem.dim
        max_evals = int(self.evals_mult.get()) * dim
        seed = 12345

        def on_progress(nevals, _g):
            # worker 线程只写标量槽，主线程轮询读（GIL 下安全）
            self._progress_val = min(1.0, nevals / max(max_evals, 1))

        def gate():
            # 暂停：阻塞直到 resume；终止：抛异常让 worker 提前退出
            self._pause_event.wait()
            if self._stop_flag:
                raise _OptimizationAborted()

        def worker():
            # 后台线程只做计算 + 写结果槽，绝不触碰 tkinter（线程不安全）
            try:
                self._pending = ('ok', self._run_once(
                    host_name, self.problem, dim, seed, max_evals, arm,
                    progress_cb=on_progress, gate=gate))
            except _OptimizationAborted:
                self._pending = ('aborted', None)
            except Exception as exc:
                self._pending = ('err', exc)

        threading.Thread(target=worker, daemon=True).start()
        self._poll_done()

    def _pause_optimize(self):
        if self._opt_state != 'running':
            return
        self._opt_state = 'paused'
        self._pause_event.clear()
        self.btn_run.config(text='继续')
        self.status.config(text='优化已暂停')

    def _resume_optimize(self):
        if self._opt_state != 'paused':
            return
        self._opt_state = 'running'
        self._pause_event.set()
        self.btn_run.config(text='暂停')
        self.status.config(text='优化中…')

    def _stop_optimize(self):
        if self._opt_state not in ('running', 'paused'):
            return
        self._stop_flag = True
        self._pause_event.set()       # 若暂停中，先解除阻塞让 gate 检查 stop
        self.status.config(text='正在终止优化…')

    def _poll_done(self):
        if self._pending is None:
            self.progress.config(value=100.0 * self._progress_val)
            self.root.after(100, self._poll_done)
            return
        status, payload = self._pending
        self._pending = None
        if status == 'ok':
            self.progress.config(value=100.0)
            self._on_done(*payload)
        elif status == 'aborted':
            self._on_aborted()
        else:
            self._on_error(payload)

    def _on_done(self, best_f, best_x, conv, evals, ctrl, gen_metrics=None):
        self.busy = False
        self._opt_state = 'idle'
        self._stop_flag = False
        self._pause_event.set()
        self.btn_run.config(text='运行优化', state='normal')
        self.btn_stop.config(state='disabled')
        self.best_f = float(best_f)
        self.best_x = np.asarray(best_x, dtype=float)
        self.conv = np.asarray(conv, dtype=float)
        self.evals = np.asarray(evals, dtype=float)
        self.upcl_used = ctrl
        self.gen_metrics = gen_metrics or []

        # 收敛曲线：有副指标则画 2x2 多维对比，否则单 cost 曲线
        self._draw_conv()

        # 指标
        n_arr = self._arrive_count()
        txt = (
            f'算法: {self.host.get()}  臂: {self.arm.get()}\n'
            f'预算: {int(self.evals_mult.get()) * self.problem.dim} 次评估\n'
            f'最优成本: {self.best_f:.1f}\n'
            f'到达架次: {n_arr} / {self.problem.cfg.n_drones}\n'
            f'实际评估: {int(self.evals[-1]) if len(self.evals) else 0}\n'
        )
        if ctrl is not None:
            st = ctrl.stats()
            txt += (f'UPCL 干预率: '
                    f'{st.get("rho_policy_curve", [0])[-1]:.3f}\n')
        saved = self._save_result()
        if saved:
            txt += f'\n历史数据: {saved}\n'
        self.metric_text.config(state='normal')
        self.metric_text.delete('1.0', 'end')
        self.metric_text.insert('1.0', txt)
        self.metric_text.config(state='disabled')
        self.status.config(text=f'优化完成：最优成本 {self.best_f:.1f}，'
                                f'可点击「演示仿真」播放轨迹')

    def _draw_conv(self):
        """绘制收敛曲线：有副指标时画 2x2 多维对比，否则单 cost 曲线。"""
        if self.gen_metrics:
            self._draw_conv_multi()
        else:
            ax = self.conv_ax
            ax.clear()
            ax.plot(self.evals, self.conv, lw=1.5, color='tab:blue')
            ax.set_xlabel('评估次数')
            ax.set_ylabel('最优成本 (cost)')
            ax.set_title(f'{self.host.get()}{_arm_display(self.arm.get())} 收敛')
            ax.grid(alpha=0.3)
        self.conv_canvas.draw()

    def _draw_conv_multi(self):
        """2x2 多维收敛对比：cost / 实际路径长度 / 飞行时间 / 安全裕度。"""
        gm = self.gen_metrics
        self.conv_fig.clf()
        axes = self.conv_fig.subplots(2, 2)
        self.conv_ax = axes[0, 0]
        ev = self.evals
        series = [
            ('最优成本 (cost)', self.conv, 'cost'),
            ('实际路径长度 (m)',
             [m.get('path_length', 0.0) for m in gm], 'path_length'),
            ('飞行时间 (s)',
             [m.get('flight_time', 0.0) for m in gm], 'flight_time'),
            ('与红方最小距离 (m)',
             [m.get('min_dist', 0.0) for m in gm], 'min_dist'),
        ]
        for axx, (title, ys, _key) in zip(axes.ravel(), series):
            # gen_metrics 每代记 1 个（共 g 个），evals/conv 含初始点（g+1 个），
            # 长度差 1，故按较短者对齐绘制，避免副指标因长度不等而空白。
            n = min(len(ys), len(ev))
            if n > 0:
                axx.plot(ev[:n], ys[:n], lw=1.2, color='tab:blue')
            axx.set_title(title, fontsize=8)
            axx.tick_params(labelsize=6)
            axx.grid(alpha=0.3)
        axes[1, 0].set_xlabel('评估次数', fontsize=7)
        axes[1, 1].set_xlabel('评估次数', fontsize=7)
        self.conv_fig.tight_layout()

    def _plot_history_multi(self, d, gen_metrics):
        """把单条历史记录（含副指标）画成 2x2 多维收敛对比。"""
        ev = np.asarray(d.get('evals', []), dtype=float)
        cv = np.asarray(d.get('conv', []), dtype=float)
        self.conv_fig.clf()
        axes = self.conv_fig.subplots(2, 2)
        self.conv_ax = axes[0, 0]
        series = [
            ('最优成本 (cost)', cv, 'cost'),
            ('实际路径长度 (m)',
             [m.get('path_length', 0.0) for m in gen_metrics], 'path_length'),
            ('飞行时间 (s)',
             [m.get('flight_time', 0.0) for m in gen_metrics], 'flight_time'),
            ('与红方最小距离 (m)',
             [m.get('min_dist', 0.0) for m in gen_metrics], 'min_dist'),
        ]
        for axx, (title, ys, _key) in zip(axes.ravel(), series):
            n = min(len(ys), len(ev))
            if n > 0:
                axx.plot(ev[:n], ys[:n], lw=1.2, color='tab:blue')
            axx.set_title(title, fontsize=8)
            axx.tick_params(labelsize=6)
            axx.grid(alpha=0.3)
        axes[1, 0].set_xlabel('评估次数', fontsize=7)
        axes[1, 1].set_xlabel('评估次数', fontsize=7)
        arm = d.get('arm', '?')
        self.conv_fig.suptitle(f'{d.get("host", "?")}{_arm_display(arm)} '
                               f'cost={d.get("best_f", float("nan")):.1f}',
                               fontsize=9)
        self.conv_fig.tight_layout()
        self.conv_canvas.draw()

    def _save_result(self):
        """把本次优化结果落盘为 JSON（含完整收敛曲线），供后续绘制对比。

        目录 results/apps/gui/{scenario}/F{fid}/，文件名含算法/臂/时间戳，
        每次运行追加一个新文件，历史数据不覆盖。
        """
        if self.best_x is None:
            return None
        scen = self.scenario.get()
        fid = int(self.fid.get())
        out_dir = GUI_RESULTS_DIR / scen / f'F{fid}'
        out_dir.mkdir(parents=True, exist_ok=True)
        host_safe = self.host.get().replace('/', '-')
        stamp = time.strftime('%Y%m%d_%H%M%S')
        out_file = out_dir / f'{host_safe}__{self.arm.get()}__{stamp}.json'
        payload = {
            'schema': 1,
            'suite': f'uav_{scen}',
            'scenario': scen,
            'fid': fid,
            'host': self.host.get(),
            'arm': self.arm.get(),
            'dim': int(self.problem.dim),
            'max_evals': int(self.evals_mult.get()) * self.problem.dim,
            'seed': 12345,
            'timestamp': stamp,
            'best_f': float(self.best_f),
            'best_x': [float(v) for v in np.asarray(self.best_x).ravel()],
            'evals': [float(v) for v in self.evals],
            'conv': [float(v) for v in self.conv],
            'gen_metrics': self.gen_metrics or [],
            'arrived': self._arrive_count(),
            'n_drones': int(self.problem.cfg.n_drones),
        }
        tmp = out_file.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False)
        tmp.replace(out_file)
        return str(out_file)

    def _list_history(self):
        """收集所有历史存档 JSON（按修改时间倒序）。"""
        if not GUI_RESULTS_DIR.exists():
            return []
        return sorted(GUI_RESULTS_DIR.rglob('*.json'),
                      key=lambda p: p.stat().st_mtime, reverse=True)

    def _download_images(self):
        """把当前地图图和收敛曲线图保存为 PNG 到本地目录。"""
        scen = self.scenario.get()
        fid = int(self.fid.get())
        out_dir = filedialog.askdirectory(
            title='选择图片保存目录', initialdir=str(GUI_RESULTS_DIR))
        if not out_dir:
            return
        stamp = time.strftime('%Y%m%d_%H%M%S')
        saved = []
        for name, fig in [('地图', self.map_fig), ('收敛曲线', self.conv_fig)]:
            path = Path(out_dir) / f'{scen}_F{fid}_{name}_{stamp}.png'
            try:
                fig.savefig(str(path), dpi=150, bbox_inches='tight')
                saved.append(str(path))
            except Exception as exc:
                print(f'[download] 保存失败 {path}: {exc}')
        if saved:
            messagebox.showinfo('完成', '已保存图片：\n' + '\n'.join(saved))
        else:
            messagebox.showwarning('提示', '没有成功保存任何图片。')

    def _open_history(self):
        """弹出历史数据窗口：列出已存档记录，多选后对比绘制收敛曲线。"""
        files = self._list_history()
        if not files:
            messagebox.showinfo('历史数据',
                                '暂无存档数据。先运行一次优化即可自动存档。')
            return

        win = tk.Toplevel(self.root)
        win.title('历史数据存档 — 选择记录对比收敛曲线')
        win.geometry('760x440')
        win.transient(self.root)
        win.grab_set()

        ttk.Label(win, text='多选（Ctrl/Shift）记录，点击「对比绘制」叠加收敛曲线。'
                            ).pack(side='top', anchor='w', padx=8, pady=(6, 2))
        frame = ttk.Frame(win)
        frame.pack(side='top', fill='both', expand=True, padx=8, pady=4)
        lb = tk.Listbox(frame, selectmode='extended', width=110, height=18)
        sb = ttk.Scrollbar(frame, orient='vertical', command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        lb.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')

        items = []  # (display, path)
        for p in files:
            try:
                with open(p, encoding='utf-8') as fh:
                    d = json.load(fh)
                disp = (f'{d.get("scenario", "?")}/F{d.get("fid", "?")}  '
                        f'{d.get("host", "?")}{_arm_display(d.get("arm", "?"))}  '
                        f'cost={d.get("best_f", float("nan")):.1f}  '
                        f'{d.get("timestamp", "")}')
            except Exception:
                disp = f'(无法读取) {p}'
            items.append((disp, str(p)))
            lb.insert('end', disp)

        def plot_selected():
            sel = lb.curselection()
            if not sel:
                messagebox.showinfo('提示', '请先选择至少一条记录。')
                return
            # 单选且记录含副指标 → 画 2x2 多维对比；否则单 cost 曲线叠加
            if len(sel) == 1:
                p = items[sel[0]][1]
                try:
                    with open(p, encoding='utf-8') as fh:
                        d = json.load(fh)
                    gm = d.get('gen_metrics') or []
                    if gm:
                        self._plot_history_multi(d, gm)
                        win.destroy()
                        return
                except Exception:
                    pass
            self.conv_fig.clf()
            self.conv_ax = self.conv_fig.add_subplot(111)
            cmap = plt.cm.tab10
            any_curve = False
            for j, idx in enumerate(sel):
                p = items[idx][1]
                try:
                    with open(p, encoding='utf-8') as fh:
                        d = json.load(fh)
                    ev = np.asarray(d.get('evals', []), dtype=float)
                    cv = np.asarray(d.get('conv', []), dtype=float)
                    if ev.size == 0 or cv.size == 0:
                        continue
                    color = cmap(j % 10)
                    label = (f'{d.get("host", "?")}{_arm_display(d.get("arm", "?"))} '
                             f'cost={d.get("best_f", float("nan")):.1f}')
                    self.conv_ax.plot(ev, cv, lw=1.4, color=color, label=label)
                    any_curve = True
                except Exception as exc:
                    print(f'[history] 读取失败 {p}: {exc}')
            self.conv_ax.set_xlabel('评估次数')
            self.conv_ax.set_ylabel('最优成本 (cost)')
            self.conv_ax.set_title('历史收敛曲线对比')
            self.conv_ax.grid(alpha=0.3)
            if any_curve:
                self.conv_ax.legend(fontsize=7, loc='upper right')
            self.conv_canvas.draw()
            win.destroy()

        def delete_selected():
            sel = list(lb.curselection())
            if not sel:
                messagebox.showinfo('提示', '请先选择至少一条记录。')
                return
            if not messagebox.askyesno('确认删除',
                                       f'确定删除选中的 {len(sel)} 条存档吗？\n'
                                       '删除后不可恢复。'):
                return
            deleted = 0
            for idx in sorted(sel, reverse=True):
                p = items[idx][1]
                try:
                    Path(p).unlink(missing_ok=True)
                    deleted += 1
                except Exception as exc:
                    print(f'[history] 删除失败 {p}: {exc}')
                lb.delete(idx)
            win.destroy()
            messagebox.showinfo('完成', f'已删除 {deleted} 条存档。')

        bb = ttk.Frame(win)
        bb.pack(side='bottom', fill='x', padx=8, pady=8)
        ttk.Button(bb, text='对比绘制', command=plot_selected).pack(side='left')
        ttk.Button(bb, text='删除选中', command=delete_selected).pack(side='left', padx=6)
        ttk.Button(bb, text='关闭', command=win.destroy).pack(side='left', padx=6)

    def _arrive_count(self):
        if self.best_x is None:
            return 0
        cost, state, frames = self.problem.trajectory(self.best_x)
        return sum(1 for s in state if s == 1)

    def _on_aborted(self):
        self.busy = False
        self._opt_state = 'idle'
        self._stop_flag = False
        self._pause_event.set()
        self.btn_run.config(text='运行优化', state='normal')
        self.btn_stop.config(state='disabled')
        self.progress.config(value=0.0)
        self._progress_val = 0.0
        self.status.config(text='优化已终止')

    def _on_error(self, exc):
        self.busy = False
        self._opt_state = 'idle'
        self._stop_flag = False
        self._pause_event.set()
        self.btn_run.config(text='运行优化', state='normal')
        self.btn_stop.config(state='disabled')
        self.progress.config(value=0.0)
        self._progress_val = 0.0
        self.status.config(text='优化失败')
        messagebox.showerror('优化失败', repr(exc))


def main():
    root = tk.Tk()
    app = UAVDemoApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()

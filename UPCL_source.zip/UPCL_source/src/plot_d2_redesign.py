"""D2.5 redesign prototypes (temporary). Generates three candidates:
A = eta2 effect-size heatmap, B = eta2 dot plot, C = per-group z heatmap.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Rectangle

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_mech_attribution import (
    load_cell_df, FACTORS, OBS, heatmap, _savefig, _short)

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

DIM_CN = {'param_class': '参数规则 param', 'strategy': '算子策略 strategy',
          'archive': '外部档案 archive', 'pop': '种群控制 pop',
          'other_flag': '额外机制 other', 'mutation_class': '变异算子 mutation'}
OBS_CN = {'dec_median': 'dec', 'intervention_rate': '干预率',
          'policy_rate': '策略触发率', 'mean_relative_shift': '相对位移',
          'bare_median_log10err': '裸臂 log10 误差',
          'rho_step_effect': 'rho_step', 'theta_align_effect': 'theta_align',
          'eta_elite_effect': 'eta_elite', 'kappa_crowd_effect': 'kappa_crowd',
          'nu_novel_effect': 'nu_novel'}

df = load_cell_df()
dims = list(FACTORS)
es = pd.read_csv(Path(__file__).resolve().parents[1] / 'results' / 'cec' /
                 'tables' / 'attr_d2_effect_sizes.csv')
eta = es.pivot(index='dimension', columns='observable', values='eta2')
eta = eta.loc[dims, OBS]  # 6 x 10


def plot_a():
    """A: eta2 effect-size heatmap (6 x 10), colour = eta2, annotated."""
    fig, ax = plt.subplots(figsize=(11.5, 4.8))
    mat = eta.values
    im = ax.imshow(mat, cmap='viridis', vmin=0, vmax=1, aspect='auto')
    ax.set_xticks(range(len(OBS)))
    ax.set_xticklabels([OBS_CN[o] for o in OBS], rotation=30, ha='right',
                       fontsize=10)
    ax.set_yticks(range(len(dims)))
    ax.set_yticklabels([DIM_CN[d] for d in dims], fontsize=10)
    for i in range(len(dims)):
        for j in range(len(OBS)):
            v = mat[i, j]
            lum = mcolors.rgb_to_hsv(plt.cm.viridis(v)[:3])[2]
            ax.text(j, i, f'{v:.3f}', ha='center', va='center', fontsize=10,
                    fontweight='bold' if v >= 0.1 else 'normal',
                    color='white' if lum < 0.55 else '0.15')
            if v >= 0.1:  # strong-association outline
                ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False,
                                       edgecolor='red', linewidth=1.5))
    cb = plt.colorbar(im, ax=ax, shrink=0.85)
    cb.set_label('eta² (Kruskal-Wallis)', fontsize=10)
    ax.set_title('D2.5 (A) eta² effect-size heatmap  (red box = eta² ≥ 0.1)',
                 fontsize=12, fontweight='bold')
    _savefig(fig, 'attr_d2_v3a_eta2_heatmap.png')


def plot_b():
    """B: eta2 dot plot per dimension, sorted descending, red line = 0.1."""
    fig, axes = plt.subplots(3, 2, figsize=(11.5, 10.5))
    for k, d in enumerate(dims):
        ax = axes[k // 2, k % 2]
        row = eta.loc[d].sort_values(ascending=False)
        y = np.arange(len(row))[::-1]
        ax.hlines(y, 0, row.values, color='0.72', lw=1.6, zorder=2)
        ax.scatter(row.values, y, s=60, c=row.values, cmap='viridis',
                   vmin=0, vmax=1, edgecolor='k', linewidth=0.5, zorder=3)
        ax.axvline(0.1, color='red', ls='--', lw=1.2, alpha=0.85)
        ax.set_yticks(y)
        ax.set_yticklabels([OBS_CN[o] for o in row.index], fontsize=9)
        ax.set_xlim(0, max(0.25, row.max() + 0.03))
        ax.set_title(DIM_CN[d], fontsize=11, fontweight='bold')
        ax.grid(alpha=0.25, axis='x')
        for yi, (o, v) in zip(y, row.items()):
            ax.text(v + 0.006, yi, f'{v:.3f}', va='center', fontsize=8,
                    fontweight='bold' if v >= 0.1 else 'normal')
        ax.set_xlabel('eta²', fontsize=8)
    fig.suptitle('D2.5 (B) eta² dot plot per dimension '
                 '(sorted; red dashed line = 0.1)', fontsize=13,
                 fontweight='bold')
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    _savefig(fig, 'attr_d2_v3b_eta2_dot.png')


def plot_c():
    """C: per-group standardized mean (z) heatmap for each dimension."""
    gmean = df[OBS].mean()
    gstd = df[OBS].std(ddof=1).replace(0, 1)
    fig, axes = plt.subplots(3, 2, figsize=(12.5, 13))
    for k, d in enumerate(dims):
        ax = axes[k // 2, k % 2]
        vals = sorted(df[d].astype(str).unique(), key=str.lower)
        zmat = []
        for v in vals:
            sub = df[df[d].astype(str) == v][OBS]
            zmat.append(((sub.mean() - gmean) / gstd).values)
        zmat = np.array(zmat)  # n_groups x 10
        vmax = max(np.nanmax(np.abs(zmat)), 0.5)
        im = ax.imshow(zmat, cmap='RdBu_r', vmin=-vmax, vmax=vmax,
                       aspect='auto')
        ax.set_xticks(range(len(OBS)))
        ax.set_xticklabels([OBS_CN[o] for o in OBS], rotation=30, ha='right',
                           fontsize=8)
        ax.set_yticks(range(len(vals)))
        ax.set_yticklabels([_short(v) for v in vals], fontsize=7.5)
        ax.set_title(DIM_CN[d], fontsize=11, fontweight='bold')
        for i in range(len(vals)):
            for j in range(len(OBS)):
                ax.text(j, i, f'{zmat[i, j]:.1f}', ha='center', va='center',
                        fontsize=6.5,
                        color='w' if abs(zmat[i, j]) > 0.55 * vmax else 'k')
        plt.colorbar(im, ax=ax, shrink=0.85)
    fig.suptitle('D2.5 (C) per-group standardized mean (z) heatmap '
                 '(red = above cell mean, blue = below)', fontsize=13,
                 fontweight='bold')
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    _savefig(fig, 'attr_d2_v3c_group_z.png')


if __name__ == '__main__':
    plot_a()
    plot_b()
    plot_c()
    print('D2.5 prototypes done')

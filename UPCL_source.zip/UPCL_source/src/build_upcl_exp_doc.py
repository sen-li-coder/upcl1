# -*- coding: utf-8 -*-
"""Render Section 4 (experimental study) and Section 5 (conclusion) on their
own, as a document separate from Sections 1-3::

    python src/build_upcl_exp_doc.py [out.docx]

The body text is the same object as in the full manuscript -
``upcl_part_exp_cec.build`` - so nothing is retyped here.  What this module
adds is the front matter a standalone reading needs:

* a title block stating what the document is and what it leaves out;
* a note on numbering, because figures, tables and references restart here
  and therefore no longer agree with the numbering of Sections 1-3;
* a provenance line, so a reader can tell which run the numbers came from;
* a reference list restricted to what this part actually cites.

Everything is read from ``results/cec/tables`` through
``build_upcl_paper_cec.load_stats``, so the document is regenerated rather
than edited: re-run this after the grid (or the analysis) changes.
"""
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = Path(__file__).resolve().parent
TABLES = ROOT / 'results' / 'cec' / 'tables'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ec_style import Paper                                    # noqa: E402
import upcl_part_front as PF                                  # noqa: E402
import upcl_part_exp_cec as PE                                # noqa: E402
from upcl_refs import get_refs                                # noqa: E402
from build_upcl_paper_cec import load_stats                   # noqa: E402

OUT = ROOT / 'docs' / 'UPCL_paper_ch4.docx'


# ---------------------------------------------------------------------------
def _stamp():
    """Modification time of the newest analysis table, i.e. the age of the
    numbers printed here.

    Both trees count: Sections 4.2 and 4.4-4.7 come from
    ``results/cec/tables``, Section 4.3 from ``results/cec/tables/cells.csv``.
    """
    GRID = ROOT / 'results' / 'cec' / 'tables'
    files = sorted(
        list(TABLES.glob('*.csv')) + [GRID / 'cells.csv'],
        key=lambda p: p.stat().st_mtime if p.exists() else 0.0)
    files = [p for p in files if p.exists()]
    if not files:
        return None
    return datetime.fromtimestamp(files[-1].stat().st_mtime)


def _cover(P, S):
    pr = S['protocol']
    stamp = _stamp()

    P.h1('Experimental analysis')
    P.para(
        'This document is the empirical half of the manuscript '
        f'\\emph{{{PF.TITLE}}}, set apart so that the experiments can be '
        'read, checked against the result files and circulated without the '
        'argument that precedes them. It contains Sections 4 and 5 exactly as '
        'they appear in the full text - nothing has been retyped, added or '
        'softened for this version - and nothing of Sections 1-3.')
    P.para(
        'The object under test is therefore assumed rather than introduced. '
        'It is a proposal-correction layer attached to a host differential '
        'evolution algorithm at one point only, the proposal leaving the '
        'variation and crossover stage, and its operating point is fixed '
        'once for every cell reported below; Section 3 of the full manuscript '
        'gives the rule, the biological route that motivated its objective, '
        'and the two properties that make the pairing exact.')

    P.h2('How to read the numbering')
    P.para(
        'This document is numbered on its own. Figures, tables and '
        'references all restart at 1 here and consequently do not agree '
        'with the numbering used in Sections 1-3; a reference numbered '
        '\\emph{n} in this file is not the reference numbered \\emph{n} in '
        'the front-matter part. Cross-references made inside Sections 4 and '
        '5 \\emph{are} unaffected, because the whole experiment section is '
        'reproduced and the numbering within it is generated in the same '
        'order as before.')

    P.h2('Provenance of the numbers')
    rows = [['Cells reported', pr['cells_line']],
            ['Suites and dimensions', pr['dims']],
            ['Problems per block', pr['problems']],
            ['Budget', pr['budget']],
            ['Hosts', pr['hosts']],
            ['Runs', pr['runs']],
            ['Pairing', pr['pairing']]]
    G = S.get('grid') or {}
    if G.get('planned'):
        rows.append(['Coverage grid (Sec. 4.3)',
                     f"{int(G['cells'])} of {int(G['planned'])} cells "
                     f"complete, twenty hosts on every problem of both suites; "
                     f"unfinished cells are printed as dashes"])
    P.table_caption('Scope of the experiment grid behind this document. Every '
                    'entry is read from the analysis tables rather than '
                    'restated by hand.')
    P.table(['Item', 'Value'], rows, widths=[1.5, 4.9], align='ll')
    P.para(
        f'Every value in this document is generated from the per-cell JSON '
        f'written by the driver, as summarised in '
        f'\\emph{{results/cec/tables}} and, for Section 4.3, in '
        f'\\emph{{results/cec/tables/cells.csv}}; the newest of those files carries '
        f'the timestamp '
        + (stamp.strftime('%Y-%m-%d %H:%M') if stamp else '(unavailable)')
        + '. Regenerating those tables and re-running this script reproduces '
          'the document, including every table and figure that follows.')


def _references(P):
    """Reference list restricted to the keys actually cited in this part.

    The full manuscript carries one hundred and eight entries; Sections 4
    and 5 cite two of them, so importing the whole list would bury the two
    that matter and would also inherit their numbers.
    """
    entries = get_refs()
    cited = {k: entries[k] for k in P.ref_order if k in entries}
    P.unknown_refs.update(k for k in P.ref_order if k not in entries)
    if not cited:
        return 0
    P.references(cited)
    for p in reversed(P.doc.paragraphs):
        if p.style.name == 'Heading 1' and p.text.strip() == 'References':
            p.runs[0].text = 'References cited in this part'
            break
    return len(cited)


def build(out_path=OUT):
    S = load_stats()
    P = Paper()
    _cover(P, S)
    PE.build(P, S)
    n_refs = _references(P)
    if P.unknown_refs:
        print('[UPCL] WARNING unknown reference keys:', P.unknown_refs)
    out = Path(out_path)
    P.save(out)
    print('[UPCL] written ->', out)
    print(f'[UPCL] figures: {P.fig_no}  tables: {P.tab_no}  '
          f'references: {n_refs}')
    return out


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out', nargs='?', default=str(OUT),
                    help='output .docx path')
    build(Path(ap.parse_args().out))

# -*- coding: utf-8 -*-
"""UPCL 改进验证实验（多臂 A/B）。

对选定的 (host, function, dim) 子集，每个 cell 跑多条臂，结果写入
``results/verify/raw/<suite>/D<dim>/<host>__F<fid>.json``，与 grid/cec 隔离。

当前臂（ARMS）：bare / default / mild / mild2 / mild3 / mild_desc ——
温和几何参数扫描 + 描述子精简组合，用于锁定最优算法优化。

用法
----
    python src/run_upcl_stagtest.py --plan                 # 看子集与规模
    python src/run_upcl_stagtest.py --hosts "DE/rand/1/either-or" --funcs 11 17 21 27 --runs 3 --workers 8
    python src/run_upcl_stagtest.py --analyze              # 汇总对比各臂
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                        # noqa: E402
import de_hosts_cec as DHC                                     # noqa: E402
import run_upcl_cec as R                                       # noqa: E402

DHC.register()

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'verify'

FLOOR = 1e-8
RUNS = 5

# 多臂：标签 -> UPCL 配置名（None 表示裸宿主）
ARMS = [
    ('bare', None),
    ('default', 'default'),
    ('mild', 'mild_geometry'),
    ('mild2', 'mild2_geometry'),
    ('mild3', 'mild3_geometry'),
    ('mild_desc', 'mild_desc'),
]

# 试点子集：worse 最集中的宿主 + hybrid/composite 函数
SMOKE_HOSTS = ['DE/rand/1', 'DE/rand/1/either-or', 'DE/current-to-best/1', 'DE/rand/2']
SMOKE_FUNCS = [11, 17, 21, 27]


def _seed_for(fid, dim, r):
    return R.SEED_BASE + dim * 1_000_003 + r * 7919 + fid * 31


def _path(suite, dim, host, fid):
    return (OUT / 'raw' / suite / f'D{dim}'
            / f'{host.replace("/", "-")}__F{fid}.json')


def _log10(v):
    return np.log10(np.maximum(np.asarray(v, dtype=float), FLOOR))


def build_tasks(suites, dims, hosts, funcs, runs):
    tasks = []
    for suite, dim in suites:
        all_f = CS.get_suite(suite, dim)
        fids = [f.fid for f in all_f if funcs is None or f.fid in funcs]
        for h in hosts:
            for fid in fids:
                tasks.append(dict(suite=suite, dim=dim, host=h, fid=fid,
                                  runs=runs))
    return tasks


def run_cell(task):
    """跑一个 cell 的多条臂，写独立 json 文件（断点续跑）。"""
    suite, dim, host, fid = task['suite'], task['dim'], task['host'], task['fid']
    runs = task['runs']
    out_file = _path(suite, dim, host, fid)
    out_file.parent.mkdir(parents=True, exist_ok=True)

    per_run = []
    if out_file.exists():
        try:
            with open(out_file, encoding='utf-8') as fh:
                per_run = json.load(fh).get('runs', [])
        except Exception:
            per_run = []
    have = {r['run'] for r in per_run}
    if len(per_run) >= runs:
        return ('skip', f'{suite} D{dim} {host} F{fid}', 0.0)

    func = CS.get_function(suite, dim, fid)
    pop = DHC.pop_size_for(host, dim)
    max_evals = R.FES_MULT * dim
    t0 = time.perf_counter()

    for r in range(runs):
        if r in have:
            continue
        seed = _seed_for(fid, dim, r)
        entry = {'run': r, 'seed': seed}
        for label, cfg in ARMS:
            entry[label] = R.run_arm(host, func, dim, seed, max_evals, cfg,
                                     pop_size=pop)
        per_run.append(entry)

        payload = {
            'suite': suite, 'dim': dim, 'host': host, 'fid': fid,
            'func': func.name, 'category': func.category,
            'max_evals': int(max_evals), 'runs_complete': len(per_run),
            'arms': [a for a, _ in ARMS],
            'runs': sorted(per_run, key=lambda r: r['run']),
        }
        tmp = out_file.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh)
        tmp.replace(out_file)
    return ('done', f'{suite} D{dim} {host} F{fid}',
            time.perf_counter() - t0)


# ---------------------------------------------------------------------------
def load_cells():
    cells = []
    if not OUT.exists():
        return cells
    for p in sorted((OUT / 'raw').glob('*/*/*.json')):
        try:
            with open(p, encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        runs = d.get('runs', [])
        if not runs:
            continue
        cells.append(d)
    return cells


def _med(recs, arm):
    vals = []
    for r in recs:
        rec = r.get(arm)
        if isinstance(rec, dict) and 'err_final' in rec:
            vals.append(float(rec['err_final']))
    return float(np.median(vals)) if vals else float('nan')


def analyze():
    """多臂对比：各臂 vs bare 的 decades，以及消融臂 vs default 的 delta。"""
    cells = load_cells()
    if not cells:
        print(f'[verify] 无结果可分析：{OUT / "raw"}')
        return

    labels = [a for a, _ in ARMS]
    print(f'[verify] 分析 {len(cells)} 个 cell，臂：{labels}\n')

    rows = []
    for d in cells:
        runs = d['runs']
        meds = {a: _med(runs, a) for a in labels}
        rec = dict(suite=d['suite'], dim=d['dim'], host=d['host'], fid=d['fid'],
                   category=d.get('category', ''), **meds)
        for a in labels[1:]:                      # vs bare
            rec[f'dec_{a}'] = float(_log10(meds['bare']) - _log10(meds[a]))
        for a in labels[2:]:                      # vs default
            rec[f'delta_{a}'] = float(_log10(meds['default']) - _log10(meds[a]))
        rows.append(rec)

    def _tally(key, lo=-0.05, hi=0.05):
        vals = [r[key] for r in rows if np.isfinite(r[key])]
        if not vals:
            return 0, 0, 0, float('nan')
        b = sum(1 for v in vals if v > hi)
        w = sum(1 for v in vals if v < lo)
        t = len(vals) - b - w
        return b, w, t, float(np.median(vals))

    print('== 各臂 vs bare（正 = 比裸宿主更好）==')
    for a in labels[1:]:
        b, w, t, m = _tally(f'dec_{a}')
        print(f'  {a:12s} better {b:3d} / worse {w:3d} / tie {t:3d}  '
              f'(decades 中位 {m:+.3f})')
    print()
    print('== 消融臂 vs default（正 = 比 default 更好）==')
    for a in labels[2:]:
        b, w, t, m = _tally(f'delta_{a}')
        print(f'  {a:12s} better {b:3d} / worse {w:3d} / tie {t:3d}  '
              f'(delta 中位 {m:+.3f})')
    print()

    # 明细表
    hdr = (f"{'suite':8s} {'D':>3s} {'host':22s} {'fid':>3s} {'cat':10s} "
           + ''.join(f'{a:>11s}' for a in labels)
           + ''.join(f'{"d_" + a:>11s}' for a in labels[1:]))
    print(hdr)
    for r in sorted(rows, key=lambda x: (x['host'], x['fid'])):
        line = (f"{r['suite']:8s} {r['dim']:>3d} {r['host']:22s} "
                f"{r['fid']:>3d} {r['category']:10s}")
        for a in labels:
            line += f'{r[a]:11.4g}'
        for a in labels[1:]:
            line += f'{r["dec_" + a]:+11.3f}'
        print(line)

    # 动作分布（验证 disable 生效）
    print('\n== 动作分布（跨 runs 求和）==')
    r_cnt = {a: np.zeros(5) for a in labels}
    for d in cells:
        for r in d['runs']:
            for a in labels:
                if a == 'bare':
                    continue
                st = r.get(a, {}).get('upcl', {})
                ac = st.get('action_counts', {})
                for i, n in enumerate('ICERP'):
                    r_cnt[a][i] += int(ac.get(n, 0))
    print(f"{'arm':12s} {'I':>9s} {'C':>9s} {'E':>9s} {'R':>9s} {'P':>9s}")
    for a in labels:
        if a == 'bare':
            continue
        print(f"{a:12s} " + ' '.join(f'{int(r_cnt[a][i]):>9d}' for i in range(5)))

    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--smoke', action='store_true', help='快速试点子集')
    ap.add_argument('--plan', action='store_true', help='只看子集与规模，不运行')
    ap.add_argument('--analyze', action='store_true', help='只汇总已有结果')
    ap.add_argument('--suites', nargs='*', default=None)
    ap.add_argument('--dims', nargs='*', type=int, default=None)
    ap.add_argument('--hosts', nargs='*', default=None)
    ap.add_argument('--funcs', nargs='*', type=int, default=None)
    ap.add_argument('--runs', type=int, default=RUNS)
    ap.add_argument('--workers', type=int,
                    default=max(1, (os.cpu_count() or 4) - 2))
    a = ap.parse_args(argv)

    if a.analyze:
        analyze()
        return

    suites = a.suites or ['cec2017']
    dims = a.dims or [30]
    hosts = a.hosts or SMOKE_HOSTS
    funcs = a.funcs or SMOKE_FUNCS
    runs = a.runs

    suites = tuple((s, d) for s in suites for d in dims)
    tasks = build_tasks(suites, dims, hosts, funcs, runs)
    total_runs = len(tasks) * runs * len(ARMS)

    if not tasks:
        print('[verify] 空子集')
        return
    print(f'[verify] 子集：{len(tasks)} cells x {runs} runs x {len(ARMS)} arms '
          f'= {total_runs} 次运行')
    for t in tasks:
        print(f'  {t["suite"]} D{t["dim"]} {t["host"]} F{t["fid"]}')
    if a.plan:
        return

    ctx = mp.get_context('spawn')
    t0 = time.perf_counter()
    done = 0
    with ctx.Pool(a.workers) as pool:
        for status, what, dt in pool.imap_unordered(run_cell, tasks):
            done += 1
            print(f'[verify] {done:4d}/{len(tasks)} {status:5s} {what} '
                  f'{dt / 60.0:6.1f} min', flush=True)
    print(f'[verify] 完成 {done} cells，'
          f'耗时 {(time.perf_counter() - t0) / 60:.1f} min')

    analyze()


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Six-dimension mechanism attribution for the UPCL probe study (D1 - D8).

Reads the 30-host mechanism probe data already aggregated in
``results/cec/tables/mech30_cells.csv`` (and, for the time / action modules,
the raw JSON in ``results/cec/raw``) and attributes the UPCL intervention gain
``dec`` (and the companion observables) to the six DE mechanism dimensions:

    mutation, param, strategy, archive, pop, other

Every module D1..D8 writes its CSV table(s) under ``results/cec/tables/attr_*``
and its figures under ``results/cec/figures/attr_*``.  Idempotent and safe to
re-run; nothing here mutates the raw data.

Statistical honesty: the 30 hosts are a designed, non-random sample of DE
variants (20 legacy + 10 wave-4 probes), so every p-value / effect size is an
*ordering* over this sample, not a population claim.  See the companion
document for the interpretation boundary.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))

from analyze_mech30 import (          # noqa: E402  (reuse the six-dim taxonomy)
    DESC_KEYS, LEVELS, MECH, ORDER,
)

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw'
TAB = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FLOOR = 1e-8

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    from matplotlib.colors import TwoSlopeNorm
    from matplotlib.patches import Rectangle
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False

# ---------------------------------------------------------------------------
# Six-dimension taxonomy
# ---------------------------------------------------------------------------
DIMS = ['mutation', 'param', 'strategy', 'archive', 'pop', 'other']

# Coarse grouping for inference (the raw labels are too sparse at n=30).
def mutation_class(m):
    if 'pool' in m:
        return 'pool'
    if 'pbest' in m:
        return 'pbest'
    if m in ('covariance', 'rand/1 / c2best'):
        return 'other'
    return 'classic'                    # rand/best/current-to-* families

PARAM_CLASS = {
    'fixed': 'fixed',
    'individual': 'individual', 'individual-ns': 'individual',
    'history': 'history', 'history+CR': 'history', 'history+rank': 'history',
    'sinusoidal': 'sinusoidal',
    'distance': 'distrank', 'rank': 'distrank',
    'adaptive': 'ensemble', 'ensemble': 'ensemble', 'F-pool': 'ensemble',
}

OTHER_FLAG = {
    '': 'none', 'p-best': 'pbest', 'covariance': 'covariance',
    'multi-pop': 'multipop', 'hyperspherical re-injection': 'hyperspherical',
    'iterated local search': 'ils',
}

# The five coarse factor columns used by D2/D6 (dropping mutation_class which
# is nearly collinear with strategy+archive; kept as an alternative view).
FACTORS = {
    'param_class': lambda r: PARAM_CLASS.get(r['param'], 'other'),
    'strategy': lambda r: r['strategy'],
    'archive': lambda r: str(int(r['archive'])),
    'pop': lambda r: r['pop'],
    'other_flag': lambda r: OTHER_FLAG.get(r['other'], 'other'),
    'mutation_class': lambda r: mutation_class(r['mutation']),
}

# The UPCL observables that every module reads (cell level).
OBS = ['dec_median', 'intervention_rate', 'policy_rate', 'mean_relative_shift',
       'bare_median_log10err'] + [f'{k}_effect' for k in DESC_KEYS]

DESC_CN = {'rho_step': '步长 rho_step', 'theta_align': '成功方向一致 theta_align',
           'eta_elite': '精英方向 eta_elite', 'kappa_crowd': '拥挤度 kappa_crowd',
           'nu_novel': '新颖性 nu_novel'}


# ---------------------------------------------------------------------------
# Data layer
# ---------------------------------------------------------------------------
def load_cell_df():
    """Cell-level observables + the six-dim labels, as a tidy DataFrame."""
    df = pd.read_csv(TAB / 'mech30_cells.csv')
    for d in DIMS:
        df[d] = df['host'].map(lambda h: MECH.get(h, {}).get(d, ''))
    df['level'] = df['host'].map(lambda h: LEVELS.get(h, -1))
    for f, fn in FACTORS.items():
        df[f] = df.apply(lambda r: fn(r), axis=1)
    df['archive'] = df['archive'].astype(int)
    # rank hosts by bare accuracy (1 = best), consistent with mech30
    host_bare = df.groupby('host')['bare_median_log10err'].mean().sort_values()
    df['host_rank'] = df['host'].map({h: i + 1 for i, h in enumerate(host_bare.index)})
    return df


def load_action_counts():
    """Per-host aggregate action shares (I/C/E/R/P) from the raw JSON."""
    acts = ('I', 'C', 'E', 'R', 'P')
    acc = {h: {a: 0 for a in acts} for h in ORDER}
    for f in RAW.rglob('*.json'):
        try:
            d = json.load(open(f, encoding='utf-8'))
        except Exception:
            continue
        h = d.get('host')
        if h not in acc:
            continue
        for r in d.get('runs', []):
            rec = r.get('full') or r.get('upcl')
            st = (rec or {}).get('upcl') or {}
            ac = st.get('action_counts') or {}
            for a in acts:
                acc[h][a] += int(ac.get(a, 0))
    rows = []
    for h in ORDER:
        tot = sum(acc[h].values())
        row = {'host': h, 'total': tot}
        for a in acts:
            row[f'{a}_share'] = acc[h][a] / max(tot, 1)
            row[f'{a}_count'] = acc[h][a]
        rows.append(row)
    return pd.DataFrame(rows)


def _write(df, name):
    if df is None or len(df) == 0:
        return
    TAB.mkdir(parents=True, exist_ok=True)
    df.to_csv(TAB / name, index=False)


def _savefig(fig, name):
    if not HAVE_MPL:
        return
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, dpi=150, bbox_inches='tight')
    plt.close(fig)


def _panel(n, ncol=2, figsize=None):
    nrow = int(np.ceil(n / ncol))
    figsize = figsize or (5 * ncol + 1, 3.6 * nrow + 0.6)
    fig, axes = plt.subplots(nrow, ncol, figsize=figsize, squeeze=False)
    for ax in axes.ravel()[n:]:
        ax.set_visible(False)
    return fig, axes.ravel()[:n]


# ---------------------------------------------------------------------------
# Statistics helpers
# ---------------------------------------------------------------------------
def kruskal_eta2(groups):
    """Kruskal-Wallis H and its eta-squared (H) effect size over list of arrays."""
    from scipy.stats import kruskal
    g = [np.asarray(x, float) for x in groups if len(x) > 0]
    g = [x[~np.isnan(x)] for x in g]
    g = [x for x in g if len(x) > 0]
    if len(g) < 2 or any(len(x) < 2 for x in g):
        return np.nan, np.nan, 1.0
    try:
        H, p = kruskal(*g)
    except ValueError:
        # 所有值相同（如 UAV 约束指标组 gain 全 0），无法检验 → 视为无效应
        return 0.0, 0.0, 1.0
    n = sum(len(x) for x in g)
    k = len(g)
    eta2 = (H - k + 1) / max(n - k, 1)
    return float(H), float(max(eta2, 0.0)), float(p)


def cliffs_delta(a, b):
    """Cliff's delta: P(a>b) - P(a<b), in [-1, 1]."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    a, b = a[~np.isnan(a)], b[~np.isnan(b)]
    if len(a) == 0 or len(b) == 0:
        return np.nan
    # pairwise comparison via histogram for speed
    d = 0.0
    for x in a:
        d += float(np.sum(b < x)) - float(np.sum(b > x))
    return d / (len(a) * len(b))


def cramers_v(x, y):
    """Cramér's V between two categorical series."""
    from scipy.stats import chi2_contingency
    tab = pd.crosstab(x, y)
    if tab.shape[0] < 2 or tab.shape[1] < 2:
        return 0.0
    chi2, p, dof, _ = chi2_contingency(tab, correction=False)
    n = tab.values.sum()
    return float(np.sqrt(chi2 / (n * (min(tab.shape) - 1))))


# Short display names for the six coarse dimensions and long category labels
# (the raw labels are too verbose to fit inside the 30x6 portrait tiles).
COARSE_CN = {'mutation_class': 'mutation', 'param_class': 'param',
             'strategy': 'strategy', 'archive': 'archive', 'pop': 'pop',
             'other_flag': 'other'}
SHORT = {'hyperspherical': 'hypersph', 'individual': 'indiv',
         'sinusoidal': 'sine', 'distrank': 'distrk', 'ensemble': 'ensem',
         'covariance': 'covar', 'multipop': 'm-pop', 'nonlinear': 'nonlin',
         'current-to-pbest/1': 'ctb/1', 'current-to-best/1': 'ctbest/1'}


def _short(s):
    """Compact label for a category value (falls back to the raw string)."""
    return SHORT.get(str(s), str(s))


def _d1_portrait(host_lbl, coarse):
    """D1 (A): 30-host x 6-dim mechanism portrait heatmap + dendrogram.

    Each row is one host, each column one coarse dimension; a cell colour
    encodes the dimension (hue) and its category level (lightness), and the
    row label on the right is ``#rank host`` where ``rank`` is the host's
    bare-accuracy order (1 = best).  Rows are clustered by Hamming distance
    so hosts with the same mechanism stack together.
    """
    from scipy.cluster.hierarchy import linkage, dendrogram
    col_cats = {c: sorted(host_lbl[c].astype(str).unique(), key=str.lower)
                for c in coarse}
    X = np.zeros((len(host_lbl), len(coarse)), int)
    for j, c in enumerate(coarse):
        m = {v: k for k, v in enumerate(col_cats[c])}
        X[:, j] = [m[str(v)] for v in host_lbl[c]]
    Z = linkage(X, method='average', metric='hamming')
    n = len(host_lbl)

    # per-(dim, cat) colour: one hue per dim, lightness varies within dim
    dim_hues = [0.0, 0.56, 0.14, 0.72, 0.34, 0.94]
    cell_color = {}
    for j, c in enumerate(coarse):
        k = len(col_cats[c])
        for ki in range(k):
            frac = 0.38 + 0.55 * (ki / max(k - 1, 1))
            cell_color[(j, ki)] = mcolors.hsv_to_rgb([dim_hues[j], 0.52, frac])

    fig = plt.figure(figsize=(13, 9))
    gs = fig.add_gridspec(1, 2, width_ratios=[0.16, 1.0], wspace=0.02)
    axd = fig.add_subplot(gs[0])
    dn = dendrogram(Z, ax=axd, orientation='left', no_labels=True,
                    link_color_func=lambda k: '0.45',
                    above_threshold_color='0.45')
    for s in axd.spines.values():
        s.set_visible(False)
    axd.set_xticks([]); axd.set_yticks([])
    leaves = dn['leaves']

    ax = fig.add_subplot(gs[1])
    for r, host_idx in enumerate(leaves):
        for j, c in enumerate(coarse):
            ki = int(X[host_idx, j])
            ax.add_patch(Rectangle((j, r), 1, 1, facecolor=cell_color[(j, ki)],
                                   edgecolor='white', linewidth=0.8))
            lab = _short(col_cats[c][ki])
            lum = mcolors.rgb_to_hsv(cell_color[(j, ki)])[2]
            ax.text(j + 0.5, r + 0.5, lab, ha='center', va='center',
                    fontsize=7.5, color='white' if lum < 0.55 else '0.15')
    # host labels + bare-accuracy rank on the right
    host_order = host_lbl.index.values[leaves]
    ranks = host_lbl.loc[host_order, 'host_rank'].values
    for r, (h, rk) in enumerate(zip(host_order, ranks)):
        ax.text(len(coarse) + 0.06, r + 0.5, f'#{int(rk)} {h}', ha='left',
                va='center', fontsize=7.5)
    ax.set_xlim(0, len(coarse))
    ax.set_ylim(0, n)
    ax.set_xticks([j + 0.5 for j in range(len(coarse))])
    ax.set_xticklabels([COARSE_CN[c] for c in coarse], fontsize=11,
                       fontweight='bold')
    ax.set_yticks([])
    ax.xaxis.set_ticks_position('top')
    for s in ax.spines.values():
        s.set_visible(False)
    ax.invert_yaxis()
    fig.suptitle('D1 (A) 30-host mechanism portrait '
                 '(rows clustered by Hamming distance)', fontsize=13,
                 fontweight='bold')
    _savefig(fig, 'attr_d1_portrait.png')


# One hue per coarse dimension, shared by the tile matrix and the bar list so
# the two panels read as the same six objects.  Chosen to stay distinguishable
# in greyscale print (lightness spread) as well as on screen.
DIM_C = {'mutation': '#2E5EAA', 'param': '#00A087', 'strategy': '#E64B35',
         'archive': '#E69F00', 'pop': '#7E57C2', 'other': '#8C8C8C'}


def _d1_assoc(host_lbl, coarse, mat):
    """D1 (B): symmetric Cramer's V tile matrix + per-dim value distribution.

    Left panel: 6x6 symmetric association matrix with a proper colour bar; the
    diagonal carries the dimension name and its level count k instead of a
    value (a dimension is trivially associated with itself).  Right panel: the
    level distribution of every dimension as sorted horizontal bars, coloured
    with the same dimension hue and with the counts right-aligned in their own
    column, so the two panels share one legend by construction.
    """
    with plt.rc_context({'font.sans-serif': ['Arial', 'Helvetica',
                                             'DejaVu Sans',
                                             'Microsoft YaHei', 'SimHei']}):
        _d1_assoc_draw(host_lbl, coarse, mat)


def _d1_assoc_draw(host_lbl, coarse, mat):
    n = len(coarse)
    col_cats = {c: sorted(host_lbl[c].astype(str).unique(), key=str.lower)
                for c in coarse}
    cmap = plt.cm.Blues
    fig = plt.figure(figsize=(11.6, 5.7))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.15])
    fig.subplots_adjust(left=0.105, right=0.99, top=0.905, bottom=0.115,
                        wspace=0.30)

    # ---- left: the association matrix ------------------------------------
    ax = fig.add_subplot(gs[0])
    for i in range(n):
        for j in range(n):
            col, row_ = coarse[i], coarse[j]
            if i == j:
                ax.add_patch(Rectangle((j, n - 1 - i), 1, 1,
                                       facecolor='#F1F1F1',
                                       edgecolor='white', linewidth=1.6))
                ax.text(j + 0.5, n - 1 - i + 0.585, COARSE_CN[col],
                        ha='center', va='center', fontsize=10.5,
                        fontweight='bold', color=DIM_C.get(col, '0.15'))
                ax.text(j + 0.5, n - 1 - i + 0.300,
                        f'k = {len(col_cats[col])} levels',
                        ha='center', va='center', fontsize=7.6, color='0.45')
            else:
                V = mat[i, j]
                ax.add_patch(Rectangle((j, n - 1 - i), 1, 1,
                                       facecolor=cmap(0.10 + 0.85 * V),
                                       edgecolor='white', linewidth=1.6))
                lum = mcolors.rgb_to_hsv(cmap(0.10 + 0.85 * V)[:3])[2]
                ax.text(j + 0.5, n - 1 - i + 0.5, f'{V:.2f}', ha='center',
                        va='center', fontsize=12.5,
                        fontweight='bold' if V >= 0.60 else 'normal',
                        color='white' if lum < 0.58 else '0.12')
    ax.set_xlim(0, n)
    ax.set_ylim(0, n)
    ax.set_xticks([j + 0.5 for j in range(n)])
    ax.set_xticklabels([COARSE_CN[c] for c in coarse], fontsize=9.6,
                       fontweight='bold')
    for t, c in zip(ax.get_xticklabels(), coarse):
        t.set_color(DIM_C.get(c, '0.15'))
    ax.set_yticks([n - i - 0.5 for i in range(n)])
    ax.set_yticklabels([COARSE_CN[c] for c in coarse], fontsize=9.6)
    for t, c in zip(ax.get_yticklabels(), coarse):
        t.set_color(DIM_C.get(c, '0.15'))
    ax.xaxis.set_ticks_position('top')
    ax.tick_params(length=0, pad=3)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title('Association of the six mechanism indicators   (Cramér\'s V)',
                 fontsize=10.5, color='0.25', pad=8, loc='left')

    # colour bar under the matrix, 62% of its width
    box = ax.get_position()
    cax = fig.add_axes([box.x0, box.y0 - 0.115, box.width * 0.62, 0.020])
    sm = plt.cm.ScalarMappable(norm=plt.Normalize(0, 1), cmap=cmap)
    cb = fig.colorbar(sm, cax=cax, orientation='horizontal')
    cb.set_ticks([0, 0.25, 0.5, 0.75, 1.0])
    cb.ax.tick_params(labelsize=7.4, length=2, pad=1.5, colors='0.35')
    cb.outline.set_linewidth(0.5)
    cb.outline.set_edgecolor('0.55')
    cax.set_title('0 = independent,  1 = one dimension determines the other',
                  fontsize=7.4, color='0.35', pad=4, loc='left')

    # ---- right: the level distribution -----------------------------------
    ax2 = fig.add_subplot(gs[1])
    row = 0
    bar_h = 0.60
    for k, c in enumerate(coarse):
        cats = col_cats[c]
        counts = [int((host_lbl[c].astype(str) == v).sum()) for v in cats]
        order = np.argsort(counts)[::-1]
        cats = [cats[i] for i in order]
        counts = [counts[i] for i in order]
        ypos = list(range(row, row + len(cats)))
        ax2.barh(ypos, counts, color=DIM_C.get(c, '0.5'), height=bar_h,
                 alpha=0.88, edgecolor='white', linewidth=0.8)
        for y, cc, cnt in zip(ypos, cats, counts):
            ax2.text(cnt + 0.35, y, _short(cc), va='center', fontsize=7.8,
                     color='0.20')
            ax2.text(27.6, y, cnt, va='center', ha='right', fontsize=7.8,
                     color='0.35')
        ax2.text(-0.7, (ypos[0] + ypos[-1]) / 2, COARSE_CN[c], ha='right',
                 va='center', fontsize=9.6, fontweight='bold',
                 color=DIM_C.get(c, '0.15'))
        row += len(cats)
        if k < len(coarse) - 1:
            ax2.axhline(row + 0.30, color='0.80', linewidth=0.7)
            row += 1
    ax2.set_ylim(row + 0.20, -0.60)
    ax2.set_xlim(0, 28.4)
    ax2.set_yticks([])
    ax2.set_xticks([0, 10, 20])
    ax2.tick_params(axis='x', labelsize=8, length=2.5, pad=2, colors='0.35')
    for side in ('top', 'right', 'left'):
        ax2.spines[side].set_visible(False)
    ax2.spines['bottom'].set_color('0.70')
    ax2.spines['bottom'].set_linewidth(0.7)
    ax2.set_xlabel('number of hosts (of 29)', fontsize=8.4, color='0.35',
                   labelpad=2)
    ax2.set_title('Level distribution of each indicator', fontsize=10.5,
                  color='0.25', pad=8, loc='left')
    _savefig(fig, 'attr_d1_assoc.png')


# ---------------------------------------------------------------------------
# Plotting helpers (pure matplotlib; no seaborn dependency)
# ---------------------------------------------------------------------------
def heatmap(ax, mat, xticklabels, yticklabels, annot=True, fmt='.2f',
            cmap='viridis', center=None, vmin=None, vmax=None, cbar_label=''):
    """Annotated heatmap on ``ax``; returns the image for a colorbar."""
    if center is not None and vmin is None and vmax is None:
        norm = TwoSlopeNorm(vmin=float(np.nanmin(mat)), vcenter=center,
                            vmax=float(np.nanmax(mat)))
        im = ax.imshow(mat, cmap=cmap, norm=norm, aspect='auto')
    else:
        im = ax.imshow(mat, cmap=cmap, vmin=vmin, vmax=vmax, aspect='auto')
    ax.set_xticks(range(len(xticklabels)))
    ax.set_xticklabels(xticklabels, rotation=45, ha='right', fontsize=7)
    ax.set_yticks(range(len(yticklabels)))
    ax.set_yticklabels(yticklabels, fontsize=7)
    if annot:
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                ax.text(j, i, fmt % mat[i, j], ha='center', va='center',
                        fontsize=6.5,
                        color='w' if abs(mat[i, j]) > 0.6 * np.nanmax(np.abs(mat))
                        else 'k')
    if cbar_label:
        plt.colorbar(im, ax=ax, label=cbar_label, shrink=0.85)
    return im


def grouped_box(ax, df, f, t, order=None, rot=30, fliersize=1.5):
    """Grouped boxplot of column ``t`` by categorical column ``f``."""
    order = order if order is not None else sorted(df[f].unique())
    data = [df[df[f] == v][t].dropna().values for v in order]
    data = [d for d in data if len(d)]
    kept = [o for o in order if o in df[f].unique()]
    bp = ax.boxplot(data, patch_artist=True, flierprops=dict(markersize=fliersize))
    for patch in bp['boxes']:
        patch.set_facecolor('0.85')
        patch.set_edgecolor('0.3')
    ax.set_xticks(range(1, len(kept) + 1))
    ax.set_xticklabels(kept, rotation=rot, fontsize=7)
    ax.tick_params(labelsize=7)
    return bp


# ===========================================================================
# D1  mechanism labels + descriptive baseline
# ===========================================================================
def d1(df):
    # D1.1 label matrix (30 x 6)
    host_lbl = df.drop_duplicates('host').set_index('host')
    lbl = host_lbl[['level', 'host_rank'] + DIMS].copy()
    _write(lbl.sort_values('host_rank'), 'attr_d1_label_matrix.csv')

    # D1.2 mean observables per coarse factor value
    rows = []
    for f in FACTORS:
        for val, sub in df.groupby(f):
            if len(sub) == 0:
                continue
            row = {'dimension': f, 'value': val, 'n_hosts': sub['host'].nunique(),
                   'n_cells': len(sub)}
            for o in OBS:
                row[o] = float(sub[o].mean())
            rows.append(row)
    _write(pd.DataFrame(rows), 'attr_d1_obs_by_dim.csv')

    # D1.3 Cramér's V between the six *coarsened* dims (raw labels are too
    # sparse at n=30; the coarse levels make the association interpretable).
    coarse = ['mutation_class', 'param_class', 'strategy', 'archive', 'pop',
              'other_flag']
    mat = np.zeros((len(coarse), len(coarse)))
    for i, a in enumerate(coarse):
        for j, b in enumerate(coarse):
            mat[i, j] = cramers_v(host_lbl[a], host_lbl[b])
    pd.DataFrame(mat, index=coarse, columns=coarse).to_csv(TAB / 'attr_d1_cramer.csv')
    if HAVE_MPL:
        _d1_portrait(host_lbl, coarse)
        _d1_assoc(host_lbl, coarse, mat)

    # D1.4 univariate: each factor x each observable (Kruskal-Wallis + eta2)
    uni = []
    for f in FACTORS:
        groups = {v: sub for v, sub in df.groupby(f) if len(sub) >= 2}
        for o in OBS:
            gs = [sub[o].values for sub in groups.values()]
            H, eta2, p = kruskal_eta2(gs)
            uni.append(dict(dimension=f, observable=o, k=len(gs),
                            H=H, eta2=eta2, p=p))
    _write(pd.DataFrame(uni), 'attr_d1_univariate.csv')
    return lbl


# ===========================================================================
# D2  univariate mechanism effects
# ===========================================================================
def d2(df):
    # D2.1 main effects: dec + policy_rate box/violin per factor
    if HAVE_MPL:
        targets = ['dec_median', 'policy_rate', 'intervention_rate',
                   'mean_relative_shift']
        tlabels = ['dec (gain, log10 orders)', 'policy rate rho',
                   'intervention rate', 'mean relative shift']
        n = len(FACTORS) * len(targets)
        fig, axes = _panel(n, ncol=len(targets),
                           figsize=(4.1 * len(targets) + 1, 2.7 * len(FACTORS) + 0.6))
        k = 0
        for f in FACTORS:
            for t, tl in zip(targets, tlabels):
                ax = axes[k]; k += 1
                order = sorted(df[f].unique())
                grouped_box(ax, df, f, t, order=order)
                ax.set_title(f'{f} -> {tl}', fontsize=8.5)
                ax.set_xlabel(''); ax.set_ylabel('')
        fig.tight_layout()
        _savefig(fig, 'attr_d2_main_effects.png')

    # D2.2 group tests (Kruskal-Wallis per factor per observable)
    _write(pd.read_csv(TAB / 'attr_d1_univariate.csv'), 'attr_d2_group_tests.csv')

    # D2.3 forest plot: effect of each factor value vs the grand mean of dec
    if HAVE_MPL:
        grand = df['dec_median'].mean()
        rows = []
        for f in FACTORS:
            for val, sub in df.groupby(f):
                rows.append(dict(factor=f, value=val, n=len(sub),
                                 mean=sub['dec_median'].mean(),
                                 sd=sub['dec_median'].std(ddof=1),
                                 se=sub['dec_median'].std(ddof=1) / np.sqrt(len(sub))))
        fr = pd.DataFrame(rows)
        fr['effect'] = fr['mean'] - grand
        fr['lo'] = fr['effect'] - 1.96 * fr['se']
        fr['hi'] = fr['effect'] + 1.96 * fr['se']
        fr = fr.sort_values('effect')
        fig, ax = plt.subplots(figsize=(7, max(3, 0.3 * len(fr))))
        y = np.arange(len(fr))
        ax.errorbar(fr['effect'], y, xerr=[fr['effect'] - fr['lo'],
                                           fr['hi'] - fr['effect']],
                    fmt='o', ms=3, capsize=2)
        ax.axvline(0, color='k', lw=0.8, ls='--')
        ax.set_yticks(y)
        ax.set_yticklabels([f"{r['factor']}={r['value']}" for _, r in fr.iterrows()],
                           fontsize=7)
        ax.set_xlabel('dec relative to grand mean (log10 orders)')
        ax.set_title('D2: factor-value effects on dec (mean +/- 95% CI)')
        ax.grid(alpha=0.3, axis='x')
        _savefig(fig, 'attr_d2_forest.png')

    # D2.4 effect sizes: eta2 (all factors) + Cliff's delta (binary factors)
    es = []
    for f in FACTORS:
        groups = {v: sub for v, sub in df.groupby(f) if len(sub) >= 2}
        if len(groups) < 2:
            continue
        for o in OBS:
            _, eta2, _ = kruskal_eta2([sub[o].values for sub in groups.values()])
            es.append(dict(dimension=f, observable=o, eta2=eta2))
    es_df = pd.DataFrame(es)
    _write(es_df, 'attr_d2_effect_sizes.csv')

    # D2.5 effect-size view: (A) eta2 heatmap + (B) eta2 dot plot
    if HAVE_MPL:
        from matplotlib.transforms import blended_transform_factory as _blend
        dim_en = {'param_class': 'param rule', 'strategy': 'strategy',
                  'archive': 'archive', 'pop': 'population',
                  'other_flag': 'other mech', 'mutation_class': 'mutation'}
        obs_en = {'dec_median': 'dec', 'intervention_rate': 'intervention rate',
                  'policy_rate': 'policy rate',
                  'mean_relative_shift': 'relative shift',
                  'bare_median_log10err': 'bare log10 err',
                  'rho_step_effect': 'rho_step',
                  'theta_align_effect': 'theta_align',
                  'eta_elite_effect': 'eta_elite',
                  'kappa_crowd_effect': 'kappa_crowd',
                  'nu_novel_effect': 'nu_novel'}
        eta = es_df.pivot(index='dimension', columns='observable', values='eta2')
        eta = eta.loc[list(FACTORS), OBS]

        # (A) eta2 effect-size heatmap
        fig, ax = plt.subplots(figsize=(11.5, 4.8))
        im = ax.imshow(eta.values, cmap='viridis', vmin=0, vmax=1, aspect='auto')
        ax.set_xticks(range(len(OBS)))
        ax.set_xticklabels([obs_en[o] for o in OBS], rotation=30, ha='right',
                           fontsize=10)
        ax.set_yticks(range(len(FACTORS)))
        ax.set_yticklabels([dim_en[f] for f in FACTORS], fontsize=10)
        for i in range(len(FACTORS)):
            for j in range(len(OBS)):
                v = eta.values[i, j]
                lum = mcolors.rgb_to_hsv(plt.cm.viridis(v)[:3])[2]
                ax.text(j, i, f'{v:.3f}', ha='center', va='center', fontsize=10,
                        fontweight='bold' if v >= 0.1 else 'normal',
                        color='white' if lum < 0.55 else '0.15')
                if v >= 0.1:
                    ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False,
                                           edgecolor='red', linewidth=1.5))
        plt.colorbar(im, ax=ax, shrink=0.85).set_label('eta² (Kruskal-Wallis)',
                                                       fontsize=10)
        ax.set_title('D2.5 (A) eta² effect-size heatmap  (red box = eta² ≥ 0.1)',
                     fontsize=12, fontweight='bold')
        _savefig(fig, 'attr_d2_eta2_heatmap.png')

        # (B) eta2 dot plot per dimension -- the version that enters the paper
        # (the suptitle of the working notebook is dropped; the caption and the
        # panel titles carry the reading, as in the other mechanism figures).
        with plt.rc_context({'font.sans-serif': ['Arial', 'Helvetica',
                                                 'DejaVu Sans',
                                                 'Microsoft YaHei', 'SimHei']}):
            cmap = plt.cm.Blues
            vmax = 0.24                     # shared scale, 0.10 stays at 2/5
            x_hi = 0.28                     # right gutter for the value column
            fig, axes = plt.subplots(3, 2, figsize=(7.6, 6.9))
            for k, f in enumerate(FACTORS):
                ax = axes[k // 2, k % 2]
                hue = DIM_C.get(_D6_KEY.get(f, ''), '0.45')
                row = eta.loc[f].sort_values(ascending=False)
                y = np.arange(len(row))[::-1]
                cols = [cmap(0.12 + 0.78 * min(v / vmax, 1.0))
                        for v in row.values]
                ax.hlines(y, 0, row.values, color='0.86', lw=0.9, zorder=2)
                ax.scatter(row.values, y, s=34, c=cols, edgecolor='0.45',
                           linewidth=0.4, zorder=3)
                ax.axvline(0.10, color='#B4463B', ls=(0, (3.2, 2.2)), lw=0.9,
                           alpha=0.85, zorder=1)
                ax.set_yticks(y)
                ax.set_yticklabels([obs_en[o] for o in row.index],
                                   fontsize=7.8, color='0.22')
                ax.set_xlim(0, x_hi)
                ax.set_xticks([0, 0.05, 0.10, 0.15, 0.20])
                ax.tick_params(axis='x', labelsize=7.2, length=2.5, pad=2,
                               colors='0.35')
                ax.tick_params(axis='y', length=0, pad=2)
                for side in ('top', 'right'):
                    ax.spines[side].set_visible(False)
                for side in ('left', 'bottom'):
                    ax.spines[side].set_color('0.70')
                    ax.spines[side].set_linewidth(0.7)
                ax.set_title(dim_en[f], loc='left', fontsize=9.2, color=hue,
                             fontweight='bold', pad=6)
                ax.set_xlabel(r'$\eta^2$ (Kruskal-Wallis)', fontsize=7.6,
                              color='0.35', labelpad=2)
                if k == 0:
                    ax.text(0.104, 0.02, r'$\eta^2 = 0.10$', fontsize=6.4,
                            color='#B4463B', va='bottom', ha='left',
                            transform=_blend(ax.transData, ax.transAxes))
                for yi, (o, v) in zip(y, row.items()):
                    ax.text(0.985, yi, f'{v:.3f}',
                            transform=_blend(ax.transAxes, ax.transData),
                            ha='right', va='center', fontsize=6.9,
                            color='0.25',
                            fontweight='bold' if v >= 0.1 else 'normal')
            fig.subplots_adjust(left=0.125, right=0.985, top=0.955,
                                bottom=0.055, hspace=0.46, wspace=0.34)
            _savefig(fig, 'attr_d2_eta2_dot.png')
    return df


# ===========================================================================
# shared: host-level aggregation + two-factor test
# ===========================================================================
def host_level(df):
    h = df.groupby('host')[OBS].mean()
    meta = df.drop_duplicates('host').set_index('host')
    for d in DIMS:
        h[d] = meta[d]
    for f in FACTORS:
        h[f] = meta[f]
    h['level'] = meta['level']
    h['host_rank'] = meta['host_rank']
    return h


def scheirer_ray_hare(y, a, b):
    import scipy.stats as st
    y = np.asarray(y, float)
    n = len(y)
    ranks = st.rankdata(y)
    grand = ranks.mean()
    SS_total = float(((ranks - grand) ** 2).sum())

    def ss_level(vals):
        ss = 0.0
        for v in set(vals):
            g = ranks[np.asarray(vals) == v]
            if len(g):
                ss += len(g) * (g.mean() - grand) ** 2
        return ss

    SSa = ss_level(a)
    SSb = ss_level(b)
    SS_cells = 0.0
    for va in set(a):
        for vb in set(b):
            mask = (np.asarray(a) == va) & (np.asarray(b) == vb)
            g = ranks[mask]
            if len(g):
                SS_cells += len(g) * (g.mean() - grand) ** 2
    SSab = max(SS_cells - SSa - SSb, 0.0)
    MS_total = SS_total / max(n - 1, 1)
    ka, kb = len(set(a)), len(set(b))
    p_a = 1 - st.chi2.cdf(SSa / MS_total, ka - 1)
    p_b = 1 - st.chi2.cdf(SSb / MS_total, kb - 1)
    p_ab = 1 - st.chi2.cdf(SSab / MS_total, (ka - 1) * (kb - 1))
    return SSa / MS_total, p_a, SSb / MS_total, p_b, SSab / MS_total, p_ab


# ===========================================================================
# D3  two-factor interactions
# ===========================================================================
PAIRS = [('archive', 'param_class'), ('strategy', 'param_class'),
         ('param_class', 'pop'), ('strategy', 'pop'),
         ('archive', 'pop'), ('other_flag', 'param_class')]


def d3(df):
    rows = []
    for a, b in PAIRS:
        for (va, vb), sub in df.groupby([a, b]):
            if len(sub) < 2:
                continue
            rows.append(dict(factor_a=a, factor_b=b, a=str(va), b=str(vb),
                             n=len(sub), dec_mean=float(sub['dec_median'].mean())))
    _write(pd.DataFrame(rows), 'attr_d3_interactions.csv')

    srh = []
    for a, b in PAIRS:
        sub = df[[a, b, 'dec_median']].dropna()
        try:
            Ha, pa, Hb, pb, Hab, pab = scheirer_ray_hare(
                sub['dec_median'].values, sub[a].values, sub[b].values)
            srh.append(dict(a=a, b=b, H_a=Ha, p_a=pa, H_b=Hb, p_b=pb,
                            H_ab=Hab, p_ab=pab))
        except Exception:
            continue
    _write(pd.DataFrame(srh), 'attr_d3_srh.csv')

    if HAVE_MPL:
        _d3_diverging_bars(df)


_D3_DIM_EN = {'archive': 'archive', 'param_class': 'param rule',
              'strategy': 'strategy', 'pop': 'population'}


def _d3_diverging_bars(df):
    """D3.3: one 4-panel vertically-stacked diverging-bar figure (per pair of
    dimensions), sorted by dec mean; color = dec, n = number of hosts."""
    groups = []
    for a, b in PAIRS[:4]:
        for (ka, kb), sub in df.groupby([a, b]):
            vals = sub['dec_median'].dropna().values
            if len(vals) == 0:
                continue
            groups.append((a, b, ka, kb, float(vals.mean()),
                           int(sub['host'].nunique())))
    vmax = max(abs(min(g[4] for g in groups)),
               abs(max(g[4] for g in groups))) * 1.15
    cmap_obj = plt.get_cmap('RdBu_r')
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)

    fig, axes = plt.subplots(4, 1, figsize=(11, 11))
    for k, (a, b) in enumerate(PAIRS[:4]):
        ax = axes[k]
        gs = sorted([g for g in groups if g[0] == a and g[1] == b],
                    key=lambda g: -g[4])
        y = np.arange(len(gs))[::-1]
        ax.barh(y, [g[4] for g in gs],
                color=[cmap_obj(norm(g[4])) for g in gs],
                edgecolor='k', linewidth=0.4, height=0.68, zorder=3)
        for yi, g in zip(y, gs):
            m = g[4]
            ax.text(m + (0.008 if m >= 0 else -0.008), yi,
                    f'{m:+.3f}  (n={g[5]})', va='center', fontsize=8,
                    ha='left' if m >= 0 else 'right')
        ax.axvline(0, color='0.3', lw=1.1, zorder=2)
        ax.set_yticks(y)
        ax.set_yticklabels([f'{_short(str(g[2]))} \u00d7 {_short(str(g[3]))}'
                            for g in gs], fontsize=9.5)
        ax.set_xlim(-vmax, vmax)
        ax.grid(axis='x', color='0.85', alpha=0.4, zorder=0)
        ax.set_title(f'{_D3_DIM_EN[a]} \u00d7 {_D3_DIM_EN[b]}', loc='left',
                     fontsize=11.5, fontweight='bold')
        ax.tick_params(length=0)
        for s in ('top', 'right', 'left'):
            ax.spines[s].set_visible(False)

    sm = plt.cm.ScalarMappable(cmap=cmap_obj, norm=norm)
    sm.set_array([])
    fig.subplots_adjust(left=0.17, right=0.97, top=0.96, bottom=0.10,
                        hspace=0.55)
    fig.colorbar(sm, ax=axes.ravel().tolist(), orientation='horizontal',
                 fraction=0.025, pad=0.05,
                 label='dec mean  (log10 error removed, >0 = UPCL better)')
    fig.suptitle('D3.3 dec-mean diverging bars by dimension pair '
                 '(sorted; color = dec, n = #hosts)', fontsize=13,
                 fontweight='bold')
    _savefig(fig, 'attr_d3_interactions.png')
    plt.close(fig)


# ===========================================================================
# D4  observable-space structure
# ===========================================================================
_D4_OBS_SHORT = {'dec_median': 'dec', 'intervention_rate': 'interv',
                 'policy_rate': 'policy', 'mean_relative_shift': 'shift',
                 'bare_median_log10err': 'bare', 'rho_step_effect': 'rho',
                 'theta_align_effect': 'theta', 'eta_elite_effect': 'eta',
                 'kappa_crowd_effect': 'kappa', 'nu_novel_effect': 'nu'}
_D4_LEVEL_COLORS = {0: '#3C5488', 1: '#00A087', 2: '#E69F00', 3: '#E64B35'}


def d4(df):
    h = host_level(df)
    obs_corr = h[OBS].corr()
    obs_corr.to_csv(TAB / 'attr_d4_obs_corr.csv')

    from sklearn.decomposition import PCA
    X = (h[OBS] - h[OBS].mean()) / h[OBS].std()
    pca = PCA(n_components=min(4, len(OBS)))
    pca.fit_transform(X.values)
    load = pd.DataFrame(pca.components_.T, index=OBS,
                        columns=[f'PC{i + 1}' for i in range(pca.n_components_)])
    load.to_csv(TAB / 'attr_d4_pca_loadings.csv')
    pd.DataFrame({'component': [f'PC{i + 1}' for i in range(pca.n_components_)],
                  'explained_variance': pca.explained_variance_ratio_}).to_csv(
        TAB / 'attr_d4_pca_variance.csv', index=False)

    if HAVE_MPL:
        _d4_corrgram(h)
        _d4_clustermap(h)
    return h


def _d4_corrgram(h):
    from scipy.cluster.hierarchy import linkage, leaves_list
    from scipy.spatial.distance import squareform
    obs_corr = h[OBS].corr()
    dist = 1 - obs_corr.values
    np.fill_diagonal(dist, 0)
    corder = leaves_list(linkage(squareform(dist), method='ward'))
    oc = obs_corr.iloc[corder, corder]
    mask = np.triu(np.ones_like(oc.values, dtype=bool), k=1)
    fig, ax = plt.subplots(figsize=(7.2, 6.2))
    im = ax.imshow(np.ma.masked_where(mask, oc.values), cmap='RdBu_r',
                   vmin=-1, vmax=1, aspect='equal')
    for i in range(len(oc)):
        for j in range(i + 1):
            ax.text(j, i, f'{oc.values[i, j]:.2f}', ha='center', va='center',
                    fontsize=8,
                    color='w' if abs(oc.values[i, j]) > 0.55 else 'k')
    ax.set_xticks(range(len(corder)))
    ax.set_xticklabels([_D4_OBS_SHORT[OBS[i]] for i in corder], fontsize=9,
                       rotation=45, ha='right')
    ax.set_yticks(range(len(corder)))
    ax.set_yticklabels([_D4_OBS_SHORT[OBS[i]] for i in corder], fontsize=9)
    ax.grid(False)
    fig.subplots_adjust(left=0.08, right=0.88, top=0.92, bottom=0.12)
    fig.colorbar(im, ax=ax, fraction=0.045, pad=0.02, label='Pearson r')
    ax.set_title('D4.1 clustered correlation (Ward on 1-r, lower triangle)',
                 fontsize=12, fontweight='bold')
    _savefig(fig, 'attr_d4_corrgram.png')
    plt.close(fig)


def _d4_clustermap(h):
    from scipy.cluster.hierarchy import linkage, leaves_list
    from matplotlib.colors import ListedColormap
    from matplotlib.colorbar import Colorbar
    Xz = (h[OBS] - h[OBS].mean()) / h[OBS].std()
    col_order = leaves_list(linkage(Xz.values.T, method='ward'))
    row_order = leaves_list(linkage(Xz.values, method='ward'))
    val = Xz.values[np.ix_(row_order, col_order)]
    n = len(h)
    fig = plt.figure(figsize=(10, 10.4))
    ax = fig.add_axes([0.19, 0.16, 0.74, 0.74])
    ax_side = fig.add_axes([0.945, 0.16, 0.02, 0.74])
    ax_cbar = fig.add_axes([0.19, 0.075, 0.74, 0.02])
    im = ax.imshow(val, cmap='RdBu_r', vmin=-2.2, vmax=2.2, aspect='auto')
    thr = 1.3
    for i in range(n):
        for j in range(len(col_order)):
            v = val[i, j]
            ax.text(j, i, f'{v:.1f}', ha='center', va='center', fontsize=6,
                    color='white' if abs(v) > thr else '0.15')
    ax.set_xticks(range(len(col_order)))
    ax.set_xticklabels([_D4_OBS_SHORT[OBS[i]] for i in col_order], fontsize=10)
    ax.xaxis.set_ticks_position('top')
    ax.xaxis.set_label_position('top')
    ax.tick_params(axis='x', length=0)
    ax.set_yticks(range(n))
    ax.set_yticklabels([h.index[i] for i in row_order], fontsize=7.5)
    ax.tick_params(axis='y', length=0)
    for x in range(len(col_order) - 1):
        ax.axvline(x + 0.5, color='white', lw=1.6)
    for y in range(n - 1):
        ax.axhline(y + 0.5, color='white', lw=0.8)
    ax.grid(False)
    cmap_level = ListedColormap([_D4_LEVEL_COLORS[l] for l in
                                 sorted(h['level'].unique())])
    lv = h.iloc[row_order]['level'].astype(int).values
    ax_side.imshow(lv[:, None], cmap=cmap_level, aspect='auto')
    ax_side.set_xticks([])
    ax_side.set_yticks([])
    ax_side.set_title('level', fontsize=8, pad=4)
    cb = Colorbar(ax_cbar, im, orientation='horizontal')
    cb.set_label('z-score', fontsize=10)
    handles = [plt.Line2D([], [], marker='s', linestyle='', color=c,
                          label=f'Level {lvl}')
               for lvl, c in _D4_LEVEL_COLORS.items()]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.5, 0.02),
               ncol=4, fontsize=9, frameon=False, handlelength=1,
               handletextpad=0.5)
    fig.suptitle('D4.2 host x observable z-score '
                 '(rows/cols Ward-clustered; values = z-score)',
                 fontsize=13, fontweight='bold', y=0.97)
    _savefig(fig, 'attr_d4_clustermap.png')
    plt.close(fig)


# ===========================================================================
# D5  action decomposition
# ===========================================================================
ACTS = ('I', 'C', 'E', 'R', 'P')


_D5_ACT_EN = {'I': 'Identity', 'C': 'Contract', 'E': 'Expand',
              'R': 'Reflect', 'P': 'Project'}


def d5(df):
    ac = load_action_counts().set_index('host')
    meta = df.drop_duplicates('host').set_index('host')
    for d in DIMS:
        ac[d] = meta[d]
    for f in FACTORS:
        ac[f] = meta[f]
    ac['dec'] = df.groupby('host')['dec_median'].mean()
    ac.to_csv(TAB / 'attr_d5_action_shares.csv')

    from scipy.stats import spearmanr
    rows = []
    for a in ACTS:
        r, p = spearmanr(ac[a + '_share'], ac['dec'])
        rows.append(dict(action=a, spearman_r=float(r), p=float(p),
                         mean_share=float(ac[a + '_share'].mean())))
    _write(pd.DataFrame(rows), 'attr_d5_action_gain.csv')

    if HAVE_MPL:
        _d5_action_gain_forest(ac)


def _d5_action_gain_forest(ac):
    from scipy.stats import spearmanr
    n = len(ac)
    se = 1.0 / np.sqrt(n - 3)
    acts = list(ACTS)
    fig, ax = plt.subplots(figsize=(7.0, 4.0))
    ypos = np.arange(len(acts))[::-1]
    for yi, a in enumerate(acts):
        r, p = spearmanr(ac[a + '_share'], ac['dec'])
        lo = np.tanh(np.arctanh(r) - 1.96 * se)
        hi = np.tanh(np.arctanh(r) + 1.96 * se)
        c = '#E64B35' if p < 0.05 else ('#E69F00' if p < 0.10 else '#999999')
        ax.plot([lo, hi], [ypos[yi], ypos[yi]], color=c, lw=2.2, zorder=2)
        ax.scatter([r], [ypos[yi]], s=95, c=c, zorder=3, edgecolors='white',
                   linewidths=0.7)
        ax.annotate(f'{r:+.2f}', (hi, ypos[yi]), xytext=(5, 0),
                    textcoords='offset points', va='center', fontsize=9,
                    color=c, fontweight='bold')
    ax.axvline(0, color='0.5', lw=1.0)
    ax.set_yticks(list(ypos))
    ax.set_yticklabels([f'{_D5_ACT_EN[a]}  ({ac[a + "_share"].mean() * 100:.2f}%)'
                        for a in acts], fontsize=11)
    ax.set_xlim(-0.95, 0.55)
    ax.set_xlabel('Spearman r  (action share vs dec)', fontsize=11)
    ax.grid(axis='x', color='0.85', alpha=0.4)
    ax.spines[['top', 'right']].set_visible(False)
    handles = [plt.Line2D([], [], marker='o', linestyle='', color='#E64B35',
                          label='p<0.05'),
               plt.Line2D([], [], marker='o', linestyle='', color='#E69F00',
                          label='p<0.10'),
               plt.Line2D([], [], marker='o', linestyle='', color='#999999',
                          label='n.s.')]
    ax.legend(handles=handles, loc='lower right', fontsize=8, frameon=False)
    ax.set_title('D5 action share vs gain '
                 '(dot = Spearman r, bar = Fisher-z 95% CI, % = mean share)',
                 fontsize=11.5, fontweight='bold')
    fig.tight_layout()
    _savefig(fig, 'attr_d5_action_gain_forest.png')
    plt.close(fig)


# ===========================================================================
# D6  multivariate attribution (honest attempt)
# ===========================================================================
def d6(df):
    h = host_level(df)
    # rank-coded six factors (n=30, so six predictors keeps dof reasonable)
    X = h[list(FACTORS)].astype('category').apply(lambda c: c.cat.codes)
    y = h['dec_median'].values
    Xs = (X - X.mean()) / X.std()
    ys = (y - y.mean()) / y.std()
    n = len(h)
    Xm = np.column_stack([np.ones(n), Xs.values])
    beta, *_ = np.linalg.lstsq(Xm, ys, rcond=None)
    resid = ys - Xm @ beta
    dof = n - Xm.shape[1]
    sigma2 = float((resid ** 2).sum() / dof)
    cov = sigma2 * np.linalg.inv(Xm.T @ Xm)
    se = np.sqrt(np.diag(cov))
    names = ['intercept'] + list(X.columns)
    ci = 1.96 * se
    out = pd.DataFrame({'term': names, 'beta': beta, 'se': se,
                        'lo': beta - ci, 'hi': beta + ci})
    out.to_csv(TAB / 'attr_d6_regression.csv', index=False)

    vif = {}
    for i, col in enumerate(X.columns):
        xj = X[col].values.astype(float)
        others = X.drop(columns=col).values.astype(float)
        b, *_ = np.linalg.lstsq(np.column_stack([np.ones(n), others]), xj,
                                rcond=None)
        pred = np.column_stack([np.ones(n), others]) @ b
        r2 = 1 - ((xj - pred) ** 2).sum() / ((xj - xj.mean()) ** 2).sum()
        vif[col] = 1 / (1 - r2) if r2 < 1 else np.inf
    pd.DataFrame({'term': list(vif.keys()), 'VIF': list(vif.values())}).to_csv(
        TAB / 'attr_d6_vif.csv', index=False)
    cn = float(np.linalg.cond(Xm))
    pd.DataFrame({'condition_number': [cn]}).to_csv(
        TAB / 'attr_d6_condition.csv', index=False)

    from sklearn.ensemble import RandomForestRegressor
    from sklearn.inspection import permutation_importance
    rf = RandomForestRegressor(n_estimators=500, random_state=0)
    rf.fit(X.values, y)
    imp = permutation_importance(rf, X.values, y, n_repeats=50, random_state=0)
    pi = pd.DataFrame({'term': X.columns, 'importance': imp.importances_mean,
                       'std': imp.importances_std})
    pi = pi.sort_values('importance', ascending=False)
    pi.to_csv(TAB / 'attr_d6_rf_importance.csv', index=False)

    if HAVE_MPL:
        _d6_attribution_panel(out, dof, pi)
    return h


_D6_DIM_EN = {'param_class': 'param rule', 'strategy': 'strategy',
              'archive': 'archive', 'pop': 'population',
              'other_flag': 'other mech', 'mutation_class': 'mutation'}
# regression term -> coarse dimension key, so the row hue is the same one the
# D1 tile matrix and the D8 pair matrix give that mechanism
_D6_KEY = {'param_class': 'param', 'strategy': 'strategy', 'archive': 'archive',
           'pop': 'pop', 'other_flag': 'other', 'mutation_class': 'mutation'}


def _d6_attribution_panel(out, dof, pi):
    """Single English three-column figure: (a) linear-regression standardized
    beta forest with 95% CI, (b) RF permutation-importance bars, and a narrow
    middle band mapping the beta ordering onto the importance ordering.  All
    three columns share one row order (|beta| descending), so a mechanism is
    read along a horizontal line.  Rows carry the mechanism hue used by the
    D1/D8 figures, so the same dimension is the same colour throughout the
    section; the coefficient itself is printed in a right-hand column and a
    dagger marks the coefficients whose 95% interval clears p<0.10 (with five
    of six rows non-significant, a significance colour ramp would have painted
    the panel nearly monochrome and reserved a legend entry for a colour that
    never occurs).  Replaces the two former D6 figures."""
    with plt.rc_context({'font.sans-serif': ['Arial', 'Helvetica',
                                             'DejaVu Sans',
                                             'Microsoft YaHei', 'SimHei']}):
        _d6_attribution_draw(out, dof, pi)


def _d6_attribution_draw(out, dof, pi):
    from scipy.stats import t as tdist
    from matplotlib.transforms import blended_transform_factory as blend

    reg = out[out['term'] != 'intercept'].copy()
    reg['p'] = 2 * (1 - tdist.cdf(np.abs(reg['beta'] / reg['se']), dof))
    reg['term_en'] = reg['term'].map(_D6_DIM_EN)
    reg['hue'] = reg['term'].map(_D6_KEY).map(DIM_C)
    reg['hue'] = reg['hue'].where(reg['hue'].notna(), '0.45')
    reg = reg.assign(beta_abs=reg['beta'].abs()).sort_values('beta_abs',
                                                             ascending=False)
    reg = reg.reset_index(drop=True)
    reg['imp'] = reg['term'].map(dict(zip(pi['term'], pi['importance'])))
    reg['std'] = reg['term'].map(dict(zip(pi['term'], pi['std'])))
    # 1 = most important dimension under the random forest
    reg['rank'] = reg['term'].map(pi.set_index('term')['importance']
                                  .rank(ascending=False, method='min')
                                  .astype(int).to_dict())

    n = len(reg)
    ypos = np.arange(n)[::-1]                 # first entry on top
    ylim = (-0.62, n - 0.38)

    fig, (ax1, axm, ax2) = plt.subplots(
        1, 3, figsize=(7.9, 2.45), sharey=True,
        gridspec_kw={'width_ratios': [1.15, 0.30, 1.0], 'wspace': 0.12})
    fig.subplots_adjust(left=0.125, right=0.995, top=0.865, bottom=0.295)
    ra = blend(ax1.transAxes, ax1.transData)
    rb = blend(ax2.transAxes, ax2.transData)

    # (a) standardized beta forest, coefficients aligned in a right column
    x_lo = min(reg['lo'].min(), 0.0) - 0.10
    x_hi = x_lo + (reg['hi'].max() - x_lo) / 0.80     # 20% right-hand gutter
    for yi, r in zip(ypos, reg.itertuples()):
        ax1.plot([r.lo, r.hi], [yi, yi], color=r.hue, lw=1.5, alpha=0.95,
                 solid_capstyle='round', zorder=3)
        ax1.scatter([r.beta], [yi], s=44, c=r.hue, zorder=4,
                    edgecolors='white', linewidths=0.7)
        dag = (r'$^{\dagger\dagger}$' if r.p < 0.05
               else (r'$^{\dagger}$' if r.p < 0.10 else ''))
        ax1.text(0.985, yi, f'{r.beta:+.2f}' + dag, transform=ra, ha='right',
                 va='center', fontsize=7.8, color='0.25')
    ax1.axvline(0, color='0.55', lw=0.8, zorder=1)
    ax1.set_xlim(x_lo, x_hi)
    ax1.set_ylim(*ylim)
    ax1.set_xticks([-0.5, 0, 0.5, 1.0, 1.5])
    ax1.set_yticks(list(ypos))
    ax1.set_yticklabels(reg['term_en'], fontsize=9.2, fontweight='bold')
    for t, h in zip(ax1.get_yticklabels(), reg['hue']):
        t.set_color(h)
    ax1.tick_params(axis='x', labelsize=7.8, length=2.5, pad=2, colors='0.35')
    ax1.tick_params(axis='y', length=0, pad=3)
    for side in ('top', 'right'):
        ax1.spines[side].set_visible(False)
    for side in ('left', 'bottom'):
        ax1.spines[side].set_color('0.70')
        ax1.spines[side].set_linewidth(0.7)
    ax1.set_xlabel('standardized beta (dec)', fontsize=8.4, color='0.35',
                   labelpad=3)
    ax1.set_title('(a) linear regression', loc='left', fontsize=10,
                  color='0.25', pad=8)

    # middle band: beta ordering (left column) vs importance ordering (right)
    axm.set_xlim(-0.24, 1.72)
    axm.set_ylim(*ylim)
    for s in axm.spines.values():
        s.set_visible(False)
    axm.set_yticks([])
    for r, yi in zip(reg.itertuples(), ypos):
        yr = n - r.rank                      # 1 -> top row
        axm.plot([0, 1], [yi, yr], color=r.hue, lw=1.0, alpha=0.85, zorder=3)
        axm.scatter([0], [yi], s=17, c=r.hue, zorder=4, edgecolors='white',
                    linewidths=0.5)
        axm.scatter([1], [yr], s=17, facecolors='white', edgecolors=r.hue,
                    linewidths=0.9, zorder=4)
        axm.annotate(f'{r.rank}', (1, yr), xytext=(7, 0),
                     textcoords='offset points', va='center', fontsize=7.2,
                     color='0.45')
    axm.set_xticks([0, 1])
    axm.set_xticklabels([r'$\beta$', 'PI'], fontsize=7.2, color='0.45')
    axm.tick_params(axis='x', length=0, pad=2)
    axm.set_title('rank order', fontsize=8, color='0.35', pad=8)

    # (b) RF permutation importance, same rows, same hue
    imp_hi = float((reg['imp'] + reg['std']).max())
    ax2.barh(ypos, reg['imp'].values, height=0.52, color=reg['hue'].tolist(),
             alpha=0.65, edgecolor='none', zorder=3)
    ax2.errorbar(reg['imp'].values, ypos, xerr=reg['std'].values, fmt='none',
                 ecolor='0.45', elinewidth=0.8, capsize=2, capthick=0.8,
                 zorder=5)
    ax2.set_xlim(0, imp_hi / 0.84)           # 16% column for the PI values
    ax2.set_xticks([0, 0.2, 0.4, 0.6, 0.8])
    ax2.set_xlabel('permutation importance (dec)', fontsize=8.4, color='0.35',
                   labelpad=3)
    ax2.tick_params(axis='x', labelsize=7.8, length=2.5, pad=2, colors='0.35')
    ax2.tick_params(axis='y', length=0, labelleft=False)
    for side in ('top', 'right'):
        ax2.spines[side].set_visible(False)
    for side in ('left', 'bottom'):
        ax2.spines[side].set_color('0.70')
        ax2.spines[side].set_linewidth(0.7)
    ax2.set_title('(b) random-forest importance', loc='left', fontsize=10,
                  color='0.25', pad=8)
    for yi, r in zip(ypos, reg.itertuples()):
        ax2.text(0.985, yi, f'{r.imp:.3f}', transform=rb, ha='right',
                 va='center', fontsize=7.8, color='0.30')

    fig.text(0.5, 0.030,
             r'$\dagger$ $p<0.10$      whiskers: 95% CI (a), '
             'permutation SD (b)',
             ha='center', va='bottom', fontsize=7.0, color='0.45')

    _savefig(fig, 'attr_d6_attribution.png')


# ===========================================================================
# D7  temporal dynamics (rho segments + convergence curves)
# ===========================================================================
def load_curves():
    rho = defaultdict(list)
    eb = defaultdict(list)
    ef = defaultdict(list)
    for f in RAW.rglob('*.json'):
        try:
            d = json.load(open(f, encoding='utf-8'))
        except Exception:
            continue
        h = d.get('host')
        if h not in MECH:
            continue
        for r in d.get('runs', []):
            rec = r.get('full') or r.get('upcl')
            if rec:
                st = rec.get('upcl') or {}
                rc = st.get('rho_policy_curve') or st.get('rho_curve')
                if rc:
                    rho[h].append(np.asarray(rc, float))
                if rec.get('err_curve'):
                    ef[h].append(np.asarray(rec['err_curve'], float))
            b = r.get('bare') or {}
            if b.get('err_curve'):
                eb[h].append(np.asarray(b['err_curve'], float))
    return rho, eb, ef


_D7_GRID = np.linspace(0, 1, 100)
_D7_LEVEL_COLORS = ['#3C5488', '#00A087', '#E69F00', '#E64B35']


def _d7_host_curve(d):
    out = {}
    for h, arrs in d.items():
        ys = []
        for arr in arrs:
            if len(arr) < 2:
                continue
            ys.append(np.interp(_D7_GRID, np.linspace(0, 1, len(arr)), arr))
        if ys:
            out[h] = np.mean(ys, axis=0)
    return out


def _d7_mean_ci(vals):
    a = np.array(vals)
    m = a.mean(0)
    se = a.std(0, ddof=1) / np.sqrt(len(a))
    return m, m - 1.96 * se, m + 1.96 * se


def _d7_log(x):
    return np.log10(np.maximum(x, 1e-8))


def _d7_style(ax):
    ax.spines[['top', 'right']].set_visible(False)
    ax.grid(alpha=0.25, color='0.8')


def _d7_dynamics_panel(gb, gf, hosts):
    mb, lob, hib = _d7_mean_ci([gb[h] for h in hosts])
    mf, lof, hif = _d7_mean_ci([gf[h] for h in hosts])
    delta = {h: _d7_log(gb[h]) - _d7_log(gf[h]) for h in hosts}
    md, lod, hid = _d7_mean_ci([delta[h] for h in hosts])
    fig, axes = plt.subplots(2, 1, figsize=(6.8, 7.2))
    ax = axes[0]
    ax.plot(_D7_GRID, _d7_log(mb), color='0.45', lw=2, label='bare')
    ax.fill_between(_D7_GRID, _d7_log(lob), _d7_log(hib), color='0.45', alpha=0.18)
    ax.plot(_D7_GRID, _d7_log(mf), color='#d62728', lw=2, label='full (UPCL)')
    ax.fill_between(_D7_GRID, _d7_log(lof), _d7_log(hif), color='#d62728', alpha=0.18)
    ax.set_ylabel('log10 error'); ax.set_xlabel('progress')
    ax.set_title('(a) convergence (pooled, 95% CI across hosts)', loc='left',
                 fontsize=11, fontweight='bold')
    ax.legend(frameon=False); _d7_style(ax)
    ax = axes[1]
    ax.plot(_D7_GRID, md, color='#1f77b4', lw=2, label='gain = bare - full')
    ax.fill_between(_D7_GRID, lod, hid, color='#1f77b4', alpha=0.18)
    ax.axhline(0, color='0.4', lw=1, ls='--')
    ipk = int(np.argmax(md))
    ax.scatter([_D7_GRID[ipk]], [md[ipk]], color='#1f77b4', zorder=5)
    ax.annotate(f'peak {md[ipk]:+.3f} @ {_D7_GRID[ipk]:.2f}',
                (_D7_GRID[ipk], md[ipk]), xytext=(6, 6),
                textcoords='offset points', fontsize=9)
    ax.set_ylabel('log10 gain (positive = full better)'); ax.set_xlabel('progress')
    ax.set_title('(b) gain over progress', loc='left', fontsize=11,
                 fontweight='bold')
    ax.legend(frameon=False); _d7_style(ax)
    fig.suptitle('D7: temporal dynamics', fontsize=12.5, fontweight='bold')
    fig.tight_layout(rect=[0, 0, 1, 0.98])
    _savefig(fig, 'attr_d7_dynamics.png')


def _d7_level_panel(gb, gf, hosts, lvl_of):
    levels = sorted(set(lvl_of.values()))
    delta = {h: _d7_log(gb[h]) - _d7_log(gf[h]) for h in hosts}
    fig = plt.figure(figsize=(12.8, 7.2))
    gs = fig.add_gridspec(2, 4, height_ratios=[1.25, 1], hspace=0.45, wspace=0.25)
    for i, lv in enumerate(levels):
        ax = fig.add_subplot(gs[0, i])
        hs = [h for h in hosts if lvl_of[h] == lv]
        mb, lob, hib = _d7_mean_ci([gb[h] for h in hs])
        mf, lof, hif = _d7_mean_ci([gf[h] for h in hs])
        ax.plot(_D7_GRID, _d7_log(mb), color='0.45', lw=1.8, label='bare')
        ax.fill_between(_D7_GRID, _d7_log(lob), _d7_log(hib), color='0.45', alpha=0.15)
        ax.plot(_D7_GRID, _d7_log(mf), color='#d62728', lw=1.8, label='full')
        ax.fill_between(_D7_GRID, _d7_log(lof), _d7_log(hif), color='#d62728', alpha=0.15)
        ax.set_title(f'level {lv} (n={len(hs)})', fontsize=10)
        ax.tick_params(labelsize=7)
        if i == 0:
            ax.set_ylabel('log10 error'); ax.legend(frameon=False, fontsize=7)
        ax.set_xlabel('progress'); _d7_style(ax)
    ax = fig.add_subplot(gs[1, :])
    for i, lv in enumerate(levels):
        hs = [h for h in hosts if lvl_of[h] == lv]
        md, lod, hid = _d7_mean_ci([delta[h] for h in hs])
        c = _D7_LEVEL_COLORS[i % len(_D7_LEVEL_COLORS)]
        ax.plot(_D7_GRID, md, color=c, lw=1.8, label=f'level {lv} (n={len(hs)})')
        ax.fill_between(_D7_GRID, lod, hid, color=c, alpha=0.12)
    ax.axhline(0, color='0.4', lw=1, ls='--')
    ax.set_ylabel('log10 gain (positive = full better)'); ax.set_xlabel('progress')
    ax.legend(frameon=False, fontsize=8, ncol=4, loc='lower right'); _d7_style(ax)
    fig.suptitle('D7: convergence by level', fontsize=12.5, fontweight='bold')
    fig.subplots_adjust(top=0.92)
    _savefig(fig, 'attr_d7_level.png')


def d7(df):
    rho, eb, ef = load_curves()
    # rho_policy_curve is identically 0 for every run, so D7 keeps only the
    # informative err_curve convergence trajectories (bare vs full).
    gb = _d7_host_curve(eb)
    gf = _d7_host_curve(ef)
    hosts = [h for h in ORDER if h in gb and h in gf]
    lvl_of = {h: LEVELS.get(h) for h in hosts}
    if HAVE_MPL:
        _d7_dynamics_panel(gb, gf, hosts)
        _d7_level_panel(gb, gf, hosts, lvl_of)
    return rho, eb, ef


# ===========================================================================
# D8  near-pair ablation (cleanest mechanism attribution)
# ===========================================================================
def find_near_pairs():
    pairs = []
    for i, a in enumerate(ORDER):
        for b in ORDER[i + 1:]:
            diff = [d for d in DIMS if MECH[a][d] != MECH[b][d]]
            if len(diff) == 1:
                pairs.append((a, b, diff[0]))
    return pairs


# The D8 figure is one row-aligned matrix rather than a forest plot stacked over
# a second bar panel: the 40 controlled comparisons *are* the rows, grouped by
# the single dimension that differs, so a row reads left to right as
# ``pair -> what changed -> what moved``.  Each group's aggregate is a header
# row *of its own group* (the log |dec| dot strip with the mean and its 95%
# t-interval) instead of a separate axes, which is what ties the aggregate to
# the 16/17 raw rows it summarises -- the two panels of the old render shared
# neither an axis nor a row order.
#
# Columns are picked from the data, not for looks: ``policy_rate`` and
# ``intervention_rate`` are one measurable (Spearman 0.99) so only the policy
# delta is kept, and among the five UPCL descriptor deltas ``eta_elite`` and
# ``kappa_crowd`` both track ``rho_step`` (r = 0.91 / 0.86) so they are dropped,
# leaving ``rho_step`` / ``theta_align`` / ``nu_novel`` z-scored per column over
# the 40 pairs.  Clustering the pairs on that signature was checked and
# rejected: Ward at k = 2 splits 6 mutation + 6 param into one cluster, so no
# ordering by "response type" is claimed.
# Same hue per mechanism as the D1 tile matrix, so a reader moving between the
# two figures reads "parameter control" as one colour, not two.  The `txt`
# column is a darkened variant for the few labels drawn in the group colour,
# where the band colour itself would be too light at 6-8 pt.
MAT_DIM_C = {d: DIM_C[d] for d in ('param', 'mutation', 'pop', 'other')}
MAT_DIM_TXT = {'param': '#00705E', 'mutation': '#244C8C',
               'pop': '#5B3A96', 'other': '#5A5A5A'}
MAT_DIM_LA = {'param': 'parameter control', 'mutation': 'mutation',
              'pop': 'population reduction', 'other': 'extra operator'}
MAT_ORDER = ['param', 'mutation', 'pop', 'other']
# Compact forms so the row chip fits its column; the raw labels are untouched.
MAT_SHORT = {'current-to-best/1': 'cur-to-best/1',
             'current-to-rand/1': 'cur-to-rand/1',
             'current-to-pbest/1': 'cur-to-pbest/1',
             'history+rank': 'hist+rank', 'history+CR': 'hist+CR',
             'history': 'hist', 'individual': 'indiv',
             'individual-ns': 'indiv-ns', 'sinusoidal': 'sine',
             'distance': 'dist', 'adaptive': 'adapt', 'ensemble': 'ens',
             'nonlinear': 'nonlin', 'iterated local search': 'ILS', '': 'none'}
# Layout is in inches: one data unit is one inch in both directions.
MAT_COLS = [('band', 0.15), ('rank', 0.36), ('pair', 2.34), ('chg', 1.54),
            ('d_dec', 0.58), ('d_pol', 0.58), ('d_shf', 0.58),
            ('vgap', 0.13),                       # separates the two colour scales
            ('s_rho', 0.58), ('s_the', 0.58), ('s_nu', 0.58)]
MAT_HEAD, MAT_GRP_H, MAT_ROW_H, MAT_GAP = 0.62, 0.34, 0.170, 0.11
MAT_FP = 6.4                                  # row font size
MAT_SIG = ('rho_step', 'theta_align', 'nu_novel')


def _mat_group_stats(sub):
    """mean |d_dec| with a 95% t-interval, n, and the sign split of the group."""
    from scipy.stats import t as tdist
    v = np.abs([e['d_dec'] for e in sub])
    n = len(v)
    m = float(v.mean())
    if n < 2:
        return dict(n=n, mean=m, lo=None, hi=None,
                    pos=int(sum(e['d_dec'] > 0 for e in sub)))
    se = v.std(ddof=1) / np.sqrt(n)
    lo, hi = tdist.interval(0.95, n - 1, loc=m, scale=se)
    return dict(n=n, mean=m, lo=max(lo, 0.0), hi=hi, lo_raw=lo,
                pos=int(sum(e['d_dec'] > 0 for e in sub)))


def _mat_norm(v, vm):
    return TwoSlopeNorm(vmin=-vm, vcenter=0.0, vmax=vm)(v)


def _mat_txt_on(rgba):
    """Dark text on a light fill, white on a saturated one."""
    h, s, v = mcolors.rgb_to_hsv(rgba[:3])
    return 'white' if v * (1.0 - 0.6 * s) < 0.52 else '0.12'


def _mat_num(v, nd):
    """Signed number, but no '-0.000': values that round to zero lose the sign."""
    if abs(v) < 0.5 * 10 ** (-nd):
        return f'{0.0:.{nd}f}'
    return f'{v:+.{nd}f}'


def _d8_near_matrix(nr, df):
    """D8: the near pairs as a row-aligned single-mechanism change matrix.

    The module-wide rcParams list a CJK font first, which draws Latin glyphs
    ~40% wider; this figure is English-only, so it is drawn with a Latin font
    first to keep its text metrics (and the tight bbox) stable.  Everything
    else in the module is left untouched.
    """
    with plt.rc_context({'font.sans-serif': ['Arial', 'Helvetica',
                                             'DejaVu Sans',
                                             'Microsoft YaHei', 'SimHei']}):
        _d8_near_matrix_draw(nr, df)


def _d8_near_matrix_draw(nr, df):
    bare = df.groupby('host')['bare_median_log10err'].mean().sort_values()
    rank = {h: i + 1 for i, h in enumerate(bare.index)}
    recs = []
    for _, r in nr.iterrows():
        a, b, d = r['a'], r['b'], r['diff_dim']
        recs.append(dict(
            dim=d, a=a, b=b, ra=rank[a], rb=rank[b],
            la=MAT_SHORT.get(MECH[a][d], MECH[a][d]),
            lb=MAT_SHORT.get(MECH[b][d], MECH[b][d]),
            d_dec=float(r['d_dec']), d_pol=float(r['d_policy']),
            d_shf=float(r['d_shift']),
            sig=[float(r[f'd_{k}_effect']) for k in MAT_SIG]))
    recs.sort(key=lambda e: (MAT_ORDER.index(e['dim']), -e['d_dec']))

    xs, cur = {}, 0.0
    for name, w in MAT_COLS:
        xs[name] = (cur, w)
        cur += w
    W = cur
    groups = [(d, [e for e in recs if e['dim'] == d]) for d in MAT_ORDER]
    groups = [(d, s) for d, s in groups if s]
    H = (MAT_HEAD + len(groups) * MAT_GRP_H + len(recs) * MAT_ROW_H
         + (len(groups) - 1) * MAT_GAP)

    # The canvas ends just below the last row and carries no title: the title
    # sentence and the reading of the figure are carried by the manuscript
    # caption and its footnote, not by text drawn inside the image.
    LM, RM, TM, BM = 0.10, 0.12, 0.06, 0.05
    fw, fh = W + LM + RM, H + TM + BM
    fig = plt.figure(figsize=(fw, fh))
    ax = fig.add_axes([LM / fw, BM / fh, W / fw, H / fh])
    ax.set_xlim(0, W)
    ax.set_ylim(H, 0.0)
    ax.axis('off')

    def box(x, w, y, h, fc='white', ec='white', lw=0.7, z=1):
        ax.add_patch(Rectangle((x, y), w, h, facecolor=fc, edgecolor=ec,
                               linewidth=lw, zorder=z))

    def put(x, y, s, ha='left', va='center', size=MAT_FP, color='0.15', **kw):
        ax.text(x, y, s, ha=ha, va=va, fontsize=size, color=color, **kw)

    # colour limits: per column, +- that column's largest |value| (in the header)
    vm = {'d_dec': max(abs(e['d_dec']) for e in recs),
          'd_pol': max(abs(e['d_pol']) for e in recs),
          'd_shf': max(abs(e['d_shf']) for e in recs)}
    S = np.array([e['sig'] for e in recs])
    Z = np.clip((S - S.mean(0)) / (S.std(0, ddof=1) + 1e-12), -2.0, 2.0)
    zof = {id(e): Z[i] for i, e in enumerate(recs)}
    SIGC = [('s_rho', 0, MAT_SIG[0]), ('s_the', 1, MAT_SIG[1]),
            ('s_nu', 2, MAT_SIG[2])]

    # header: tier-1 spans with a rule, tier-2 column labels (no title text:
    # the title sentence lives in the manuscript caption)
    spans = [('the controlled comparison', ['rank', 'pair', 'chg']),
             ('outcome change   \u0394 = b \u2212 a', ['d_dec', 'd_pol', 'd_shf']),
             ('UPCL decision signature  \u0394  (z-scored)',
              ['s_rho', 's_the', 's_nu'])]
    for lab, cols in spans:
        x0 = xs[cols[0]][0]
        x1 = xs[cols[-1]][0] + xs[cols[-1]][1]
        put(x0, 0.10, lab, size=7.3, color='0.20', fontweight='bold')
        ax.plot([x0, x1], [0.21, 0.21], color='0.78', lw=0.8, zorder=2)
    hdr = {'rank': '#a\u2192#b', 'pair': 'pair   a  \u2192  b',
           'chg': 'the one dimension that differs',
           'd_dec': f'\u0394dec  \u00b1{vm["d_dec"]:.2f}',
           'd_pol': f'\u0394\u03c1  \u00b1{vm["d_pol"]:.2f}',
           'd_shf': f'\u0394shift  \u00b1{vm["d_shf"]:.2f}'}
    for k, (x, w) in xs.items():
        if k in ('band', 'vgap'):
            continue
        left = k in ('rank', 'pair', 'chg')
        put(x + (0.02 if left else w / 2), 0.40, hdr.get(k, ''),
            ha='left' if left else 'center', size=6.5, color='0.30',
            fontweight='bold')
    for k, _, nm in SIGC:
        x, w = xs[k]
        put(x + w / 2, 0.405, nm, ha='center', size=6.2, color='0.30',
            fontweight='bold')

    y = MAT_HEAD
    for d, sub in groups:
        c, ct = MAT_DIM_C[d], MAT_DIM_TXT[d]
        st = _mat_group_stats(sub)
        box(xs['band'][0], xs['band'][1], y, MAT_GRP_H, fc=c, ec=c)
        box(xs['band'][0] + xs['band'][1], W - xs['band'][0] - xs['band'][1],
            y, MAT_GRP_H, fc=mcolors.to_rgba(c, 0.11), ec='none')
        put(xs['rank'][0] + 0.02, y + 0.118,
            f'{MAT_DIM_LA[d]}   \u00b7   {st["n"]} pair'
            + ('s' if st['n'] > 1 else ''),
            size=7.6, color=ct, fontweight='bold')
        if st['lo'] is None:
            s = f'mean |\u0394dec| {st["mean"]:.3f} \u00b7 no interval (n = 1)'
        else:
            los = '\u22480' if st['lo_raw'] < 0 else f'{st["lo"]:.3f}'
            s = (f'mean |\u0394dec| {st["mean"]:.3f} \u00b7 '
                 f'CI [{los}, {st["hi"]:.3f}] \u00b7 {st["pos"]}/{st["n"]} up')
        put(xs['rank'][0] + 0.02, y + 0.262, s, size=6.6, color='0.25')

        # the group's own effect distribution, drawn INSIDE its header row:
        # one dot per pair on a log |d_dec| axis, plus the mean and its interval
        sx0, sw = LM + 2.55, W + LM - 2.55 - 0.05
        sh = MAT_GRP_H - 0.10
        axs = fig.add_axes([sx0 / fw, (BM + H - y - MAT_GRP_H + 0.075) / fh,
                            sw / fw, sh / fh])
        v = np.array([abs(e['d_dec']) for e in sub])
        yy = 0.16 + 0.68 * (np.arange(len(v)) + 0.5) / len(v)
        axs.set_xscale('log')
        axs.scatter(v, yy, s=7.0, color=c, linewidths=0.4, edgecolors='white',
                    zorder=3)
        if st['lo'] is not None:
            axs.plot([max(st['lo'], 6e-4), st['hi']], [0.5, 0.5], color=c,
                     lw=1.5, zorder=2, solid_capstyle='butt')
        axs.plot([max(st['mean'], 6e-4)], [0.5], marker='D', ms=3.4, color=c,
                 zorder=4, markeredgecolor='white', markeredgewidth=0.4)
        axs.set_xlim(7e-4, 1.05)
        axs.set_ylim(0.0, 1.0)
        axs.set_yticks([])
        axs.set_xticks([1e-3, 1e-2, 1e-1, 1.0])
        # the tick labels used to sit under the axis, where they collided with
        # the first data row; the scale is now named once, inside the strip
        axs.set_xticklabels([])
        axs.tick_params(axis='x', length=1.5, pad=0.0, colors='0.62')
        if d == groups[0][0]:
            axs.text(0.998, 0.92, '|$\\Delta$dec| per pair   (log scale)',
                     transform=axs.transAxes, ha='right', va='top',
                     fontsize=5.0, color='0.45')
        for k, sp in axs.spines.items():
            sp.set_visible(k == 'bottom')
        axs.spines['bottom'].set_color('0.65')
        axs.spines['bottom'].set_linewidth(0.6)
        ax.plot([0, 2.55], [y + MAT_GRP_H, y + MAT_GRP_H], color='0.72',
                lw=0.6, zorder=2)
        y += MAT_GRP_H

        for e in sub:
            box(xs['band'][0], xs['band'][1], y, MAT_ROW_H,
                fc=mcolors.to_rgba(c, 0.85), ec='none')
            put(xs['rank'][0] + 0.02, y + MAT_ROW_H / 2, f'{e["ra"]}\u2192{e["rb"]}',
                size=6.0, color='0.45')
            put(xs['pair'][0] + 0.02, y + MAT_ROW_H / 2,
                f'{e["a"]}  \u2192  {e["b"]}', size=MAT_FP, color='0.12')
            box(xs['chg'][0] + 0.03, xs['chg'][1] - 0.06, y + 0.012,
                MAT_ROW_H - 0.024, fc=mcolors.to_rgba(c, 0.16), ec='none')
            put(xs['chg'][0] + 0.07, y + MAT_ROW_H / 2,
                f'{e["la"]} \u2192 {e["lb"]}', size=6.1, color=ct,
                fontweight='bold')
            for k, val, nd in (('d_dec', e['d_dec'], 2), ('d_pol', e['d_pol'], 3),
                               ('d_shf', e['d_shf'], 3)):
                fc = plt.cm.RdBu_r(_mat_norm(val, vm[k]))
                box(xs[k][0], xs[k][1], y, MAT_ROW_H, fc=fc, ec='white', lw=1.0)
                put(xs[k][0] + xs[k][1] / 2, y + MAT_ROW_H / 2, _mat_num(val, nd),
                    ha='center', size=6.0, color=_mat_txt_on(fc))
            zz = zof[id(e)]
            for k, j, _n in SIGC:
                fc = plt.cm.RdBu_r(_mat_norm(zz[j], 2.0))
                box(xs[k][0], xs[k][1], y, MAT_ROW_H, fc=fc, ec='white', lw=1.0)
                put(xs[k][0] + xs[k][1] / 2, y + MAT_ROW_H / 2, _mat_num(zz[j], 2),
                    ha='center', size=6.0, color=_mat_txt_on(fc))
            y += MAT_ROW_H
        y += MAT_GAP

    _savefig(fig, 'attr_d8_near_matrix.png')
    out = FIG / 'attr_d8_near_matrix.png'
    try:
        # tight-bbox self-check: an artist wider than the figure widens the
        # canvas silently, which would leave a band of white paper on the right.
        from PIL import Image
        pw, ph = Image.open(out).size
        if pw / 150.0 > fw + 0.35 or ph / 150.0 > fh + 0.35:
            print(f'[attr] WARNING d8 canvas {pw / 150:.2f} x {ph / 150:.2f} in '
                  f'but the figure is {fw:.2f} x {fh:.2f} in: an artist overflows')
    except Exception:
        pass
    print(f'[attr] D8 {W:.2f} x {H:.2f} in of matrix, {len(recs)} pairs in '
          f'{len(groups)} groups')
    for d, sub in groups:
        st = _mat_group_stats(sub)
        ci = ('n=1' if st['lo'] is None
              else f'[{st["lo"]:.4f}, {st["hi"]:.4f}]')
        print(f'[attr] D8 {d:<9} n={st["n"]:<3} mean|dec|={st["mean"]:.4f} '
              f'CI {ci:>17} up {st["pos"]}/{st["n"]}')


def d8(df):
    h = host_level(df)
    pairs = find_near_pairs()
    desc_cols = [f'{k}_effect' for k in DESC_KEYS]
    rows = []
    for a, b, dim in pairs:
        da, db = h.loc[a], h.loc[b]
        row = dict(a=a, b=b, diff_dim=dim,
                   d_dec=float(db['dec_median'] - da['dec_median']),
                   d_policy=float(db['policy_rate'] - da['policy_rate']),
                   d_intervention=float(db['intervention_rate'] - da['intervention_rate']),
                   d_shift=float(db['mean_relative_shift'] - da['mean_relative_shift']))
        for c in desc_cols:
            row['d_' + c] = float(db[c] - da[c])
        rows.append(row)
    nr = pd.DataFrame(rows)
    _write(nr, 'attr_d8_near_pairs.csv')

    if HAVE_MPL:
        _d8_near_matrix(nr, df)
    return nr


# ===========================================================================
# main
# ===========================================================================
def main():
    print('[attr] loading cells ...')
    df = load_cell_df()
    print(f'[attr] {len(df)} cells x {df["host"].nunique()} hosts, '
          f'{df["suite"].nunique()} suites x {df["dim"].nunique()} dims')
    d1(df)
    d2(df)
    d3(df)
    d4(df)
    d5(df)
    d6(df)
    d7(df)
    d8(df)
    print('[attr] D1-D8 done')


if __name__ == '__main__':
    main()

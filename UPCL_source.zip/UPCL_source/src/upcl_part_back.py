# -*- coding: utf-8 -*-
"""Manuscript Part IV - back matter for UPCL."""


def build(P, S):
    meta = S.get('meta', {})

    P.h1('Data and code availability')
    P.para(
        'The correction layer is a self-contained module that is attached '
        'to a host through three callbacks - one at the start of each '
        'generation, one that receives $(x_i,u_i)$ and returns the '
        'corrected proposal, and one that receives the resulting fitness. '
        'The hosts used in this study are used unmodified, and each '
        'comparison is reproducible from its seed alone: run $r$ of problem '
        '$f$ at dimension $D$ uses the seed $s(r,f,D)$, shared by the host '
        'on its own and by the same host wrapped with the layer, while the '
        'layer draws from a separate generator so that the host\'s random '
        'sequence is left untouched. The per-cell paired results, '
        'including the convergence traces and the intervention-rate traces '
        'used in Section 4, are written to disk by the experiment driver in '
        'JSON form.')
    P.para(
        r"The default coefficients of the layer are, in the order in which "
        r"they appear in Section 3: $\alpha=0.5$, $\beta=1.6$, $m=0.5$; "
        r"$\lambda=0.9$, $\kappa_u=0.35$, $\mu_0=0.20$, "
        r"$\mu_1=0.60$, $\gamma_I=0.02$; "
        r"$\varepsilon_0=0.15$, $\varepsilon_{\min}=0$, "
        r"$T_{\varepsilon}=60$, "
        r"$w_{\mathrm{expl}}=(0.30,0.25,0.20,0.10,0.15)$ (Section 3.4); "
        r"$b=1.2$, $M=256$, $k_{\max}=2.0$, $n_{\min}=3.0$ (Section 3.3); "
        r"$n_{\mathrm{ref}}=32$, $n_{\mathrm{proto}}=8$, "
        r"$p_{\mathrm{proto}}=0.05$, $\gamma=0.05$ (Section 3.2); and the "
        r"degeneracy guards $\epsilon_0=10^{-24}$ (Section 3.1) and "
        r"$\epsilon=10^{-30}$, used in every denominator of the descriptor "
        r"and of the response. These are hyper-parameters of the layer, not "
        r"properties of it. They were fixed once from the role each plays "
        r"in the decision rule; the exploration schedule and the adaptive "
        r"margin $\mu_1$ were then revised after the first experiment showed "
        r"the layer damaging adaptive hosts. No coefficient was tuned per "
        r"problem, per host or per dimension, and one configuration is used "
        r"for every cell reported in Section 4.")

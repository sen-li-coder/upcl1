# -*- coding: utf-8 -*-
"""Per-mechanism-dimension figures: gain & capacity raincloud per component.
Run: python src/plot_mech_dims.py
"""
import csv
from pathlib import Path
from collections import Counter
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FIG_W = 6.3

DIMS = ['mutation', 'param', 'strategy', 'archive', 'pop', 'other']
DIM_LABELS = {'mutation': 'mutation strategy', 'param': 'parameter adaptation',
              'strategy': 'strategy structure', 'archive': 'external archive',
              'pop': 'population size', 'other': 'extra mechanism'}
VAL_LABELS = {'archive': {'0': 'no archive', '1': 'archive'},
              'other': {'': 'none'}}


def _read(name):
    p = TABLES / name
    if not p.exists():
        raise SystemExit(f'missing: {p}')
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
        'legend.fontsize': 6.5, 'legend.frameon': False, 'figure.dpi': 300})


def _despine(ax):
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[dims] {name}')


def _half_cloud(ax, vals, yc, color, spread=0.32, n=200):
    v = np.asarray([x for x in vals if np.isfinite(x)], dtype=float)
    if len(v) < 3:
        return
    lo, hi = np.percentile(v, [2, 98]); pad = (hi - lo) * 0.15
    xs = np.linspace(lo - pad, hi + pad, n)
    try:
        d = gaussian_kde(v)(xs)
    except Exception:
        return
    d = d / d.max() * spread
    ax.fill_between(xs, yc, yc + d, color=color, alpha=0.30, lw=0)
    ax.plot(xs, yc + d, color=color, lw=0.7)


def _raincloud(ax, groups, colors, labels, xlabel=None, xzero=False):
    for i, (vals, c) in enumerate(zip(groups, colors)):
        v = np.asarray([x for x in vals if np.isfinite(x)], dtype=float)
        if len(v) == 0:
            continue
        _half_cloud(ax, v, i, c)
        rng = np.random.default_rng(300 + i)
        ax.scatter(v, i + rng.uniform(-0.13, 0.13, len(v)), s=6, color=c,
                   alpha=0.5, edgecolors='none', linewidths=0)
        ax.plot([np.median(v)] * 2, [i - 0.16, i + 0.16], color='#111111', lw=1.3)
    ax.set_yticks(range(len(groups)))
    ax.set_yticklabels(labels, fontsize=6.5)
    if xlabel:
        ax.set_xlabel(xlabel)
    if xzero:
        ax.axvline(0, color='#666666', lw=0.7)
    _despine(ax)


def merge_groups(rows, dim, min_n=2):
    cnt = Counter(r[dim] for r in rows)
    groups = {}
    for r in rows:
        k = r[dim] if cnt[r[dim]] >= min_n else '__other__'
        groups.setdefault(k, []).append(r)
    keys = sorted(groups, key=lambda k: -np.nanmean([_f(r['dec_mean']) for r in groups[k]]))
    return keys, groups


def dim_figure(rows, dim):
    keys, groups = merge_groups(rows, dim)
    labels = []
    for k in keys:
        n = len(groups[k])
        m = np.nanmean([_f(r['dec_mean']) for r in groups[k]])
        if k == '__other__':
            base = f'other ({n} hosts)'
        else:
            base = VAL_LABELS.get(dim, {}).get(k, k)
        labels.append(f'{base}   n={n}  dec={m:+.3f}')
    cmap = plt.cm.tab10
    colors = [cmap(i % 10) for i in range(len(keys))]
    h = max(2.2, 0.46 * len(keys) + 1.1)
    fig, axes = plt.subplots(1, 2, figsize=(FIG_W, h), sharey=True)
    fig.subplots_adjust(left=0.40, right=0.97, top=0.88, bottom=0.16, wspace=0.10)
    gain = [[_f(r['dec_mean']) for r in groups[k]] for k in keys]
    cap = [[_f(r['bare_median_log10err']) for r in groups[k]] for k in keys]
    _raincloud(axes[0], gain, colors, labels, xlabel='intervention gain (dec, + better)',
               xzero=True)
    axes[0].set_title('a  gain by ' + DIM_LABELS[dim], loc='left')
    _raincloud(axes[1], cap, colors, [''] * len(keys),
               xlabel='bare median log10 error (lower = stronger)')
    axes[1].set_title('b  capacity by ' + DIM_LABELS[dim], loc='left')
    axes[1].tick_params(axis='y', labelleft=False)
    fig.suptitle(DIM_LABELS[dim], y=0.995, fontsize=9)
    _save(fig, f'mech_dim_{dim}.png')


if __name__ == '__main__':
    _style()
    rows = _read('mech30_host_summary.csv')
    for d in DIMS:
        dim_figure(rows, d)
    print('[dims] done ->', FIG)

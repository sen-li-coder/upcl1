# -*- coding: utf-8 -*-
"""§5.6 稳健性（RQ5.4）：跨任务排名迁移一致性 + 跨重复 gain 符号一致性。

产出（``results/apps/tables/``）：
    uav_rank_by_fid.csv           各任务单独 composite vs CEC 的 Spearman ρ
    uav_gain_run_consistency.csv  各指标组 3 次重复 gain 同号的比例
    uav_task_rank.csv             各任务单独的宿主名次榜（面板「本任务名次」口径）
"""
import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

sys.path.insert(0, str(Path(__file__).resolve().parent))

import analyze_uav as AU                      # noqa: E402
import de_hosts_cec as DHC                    # noqa: E402
from analyze_uav_mech import METRIC_GROUPS, GROUP_ORDER  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'
CEC_TAB = ROOT / 'results' / 'cec' / 'tables'

MAIN_METRICS = ['composite_pct', 'n_arrived', 'n_lost', 'path_length']


def load_cec_bare_rank():
    import pandas as pd
    df = pd.read_csv(CEC_TAB / 'mech30_bare_accuracy.csv')
    sub = df[(df['suite'] == 'cec2017') & (df['dim'] == 30)]
    host_err = sub.groupby('host')['bare_median_log10err'].mean().sort_values()
    return {h: i + 1 for i, h in enumerate(host_err.index)}


def _run_metric(cell, arm, name, r):
    rec = cell['runs'][r].get(arm)
    if not isinstance(rec, dict):
        return None
    m = rec.get('metrics')
    if not isinstance(m, dict) or name not in m:
        return None
    try:
        return float(m[name])
    except (TypeError, ValueError):
        return None


def _gain(b, f, name):
    d = AU.METRIC_DIRECTION.get(name, 'neutral')
    if b is None or f is None:
        return None
    return f - b if d in ('higher_better', 'bool') else b - f


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept')
    ap.add_argument('--dim', type=int, default=30)
    ap.add_argument('--min-runs', type=int, default=3)
    args = ap.parse_args(argv)

    cells = AU.load_cells(scenario=args.scenario, min_runs=args.min_runs)
    if not cells:
        print('[analyze_uav_robust] no UAV cells found.')
        return
    cec_rank = load_cec_bare_rank()

    # ---- 5.6.1 跨任务 ρ ------------------------------------------------
    fids = sorted({k[3] for k in cells if k[1] == args.dim})
    by_fid = []
    task_rank_rows = []          # 单任务名次榜（面板「本任务名次」与图 5-3 的分任务版共用）
    for fid in fids:
        host_metrics = {}
        for (suite, d, host, f), c in cells.items():
            if suite != f'uav_{args.scenario}' or d != args.dim or f != fid:
                continue
            if 'bare' not in AU.arms_of(c):
                continue
            row = {}
            for name in MAIN_METRICS:
                vals = [v for r in range(len(c['runs']))
                        if (v := _run_metric(c, 'bare', name, r)) is not None]
                if vals:
                    row[name] = float(np.median(vals))
            if len(row) == len(MAIN_METRICS):
                host_metrics[host] = row
        common = sorted(set(host_metrics) & set(cec_rank))
        if len(common) < 3:
            continue
        z = {}
        for name in MAIN_METRICS:
            vals = np.array([host_metrics[h][name] for h in common], float)
            mu, sd = vals.mean(), vals.std(ddof=0)
            sd = sd if sd > 1e-12 else 1.0
            z[name] = {h: (v - mu) / sd for h, v in zip(common, vals)}
        sign = {n: -1.0 if AU.METRIC_DIRECTION[n] == 'lower_better' else 1.0
                for n in MAIN_METRICS}
        score = {h: sum(sign[n] * z[n][h] for n in MAIN_METRICS) for h in common}
        uav_rank = {h: i + 1 for i, (h, _) in enumerate(
            sorted(score.items(), key=lambda kv: -kv[1]))}
        u = np.array([uav_rank[h] for h in common])
        c = np.array([cec_rank[h] for h in common])
        rho, p = spearmanr(u, c)
        by_fid.append(dict(fid=fid, spearman_rho=round(float(rho), 4),
                           p=round(float(p), 4), n=len(common)))
        # 单任务名次榜：与「跨 4 任务综合榜」(uav_value_rank.csv) 同一套方法
        # （4 主指标 z-score 加权、bare 臂），只是把总体限制在单个任务内，
        # 因此 F1–F4 的名次会随任务变化，供面板按任务切换与分任务配图使用。
        for h in sorted(common, key=lambda x: uav_rank[x]):
            task_rank_rows.append(dict(fid=fid, host=h, task_rank=uav_rank[h],
                                       task_composite=round(score[h], 3),
                                       cec_rank=cec_rank.get(h)))

    # ---- 5.6.2 跨 run 符号一致性 ----------------------------------------
    hg_runs = defaultdict(list)
    for (suite, d, host, fid), c in cells.items():
        if suite != f'uav_{args.scenario}' or d != args.dim:
            continue
        if 'bare' not in AU.arms_of(c) or 'full' not in AU.arms_of(c):
            continue
        for r in range(len(c['runs'])):
            for g, members in METRIC_GROUPS.items():
                gains = []
                for name in members:
                    gv = _gain(_run_metric(c, 'bare', name, r),
                               _run_metric(c, 'full', name, r), name)
                    if gv is not None:
                        gains.append(gv)
                if gains:
                    hg_runs[(host, g)].append(float(np.mean(gains)))

    consistency = []
    for g in GROUP_ORDER:
        same_sign = total = 0
        for (host, gg), gains in hg_runs.items():
            if gg != g or len(gains) < 3:
                continue
            signs = [np.sign(v) for v in gains[:3]]
            total += 1
            if len(set(signs)) == 1 and signs[0] != 0:
                same_sign += 1
        consistency.append(dict(metric_group=g, same_sign=same_sign,
                                total=total,
                                ratio=round(same_sign / total, 3) if total else ''))

    TAB.mkdir(parents=True, exist_ok=True)
    with open(TAB / 'uav_rank_by_fid.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['fid', 'spearman_rho', 'p', 'n'])
        w.writeheader(); w.writerows(by_fid)
    with open(TAB / 'uav_gain_run_consistency.csv', 'w', newline='',
              encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['metric_group', 'same_sign',
                                           'total', 'ratio'])
        w.writeheader(); w.writerows(consistency)
    with open(TAB / 'uav_task_rank.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['fid', 'host', 'task_rank',
                                           'task_composite', 'cec_rank'])
        w.writeheader(); w.writerows(task_rank_rows)

    print('\n=== §5.6.1 跨任务排名迁移 ρ ===')
    for r in by_fid:
        print(f"  F{r['fid']}: rho={r['spearman_rho']:+.3f}  p={r['p']:.3f}  "
              f"n={r['n']}")
    print('=== §5.6.2 跨重复 gain 同号一致性 ===')
    for r in consistency:
        print(f"  {r['metric_group']:<12s} {r['same_sign']}/{r['total']}  "
              f"ratio={r['ratio']}")
    print('[analyze_uav_robust] wrote uav_rank_by_fid.csv + '
          'uav_gain_run_consistency.csv + uav_task_rank.csv')


if __name__ == '__main__':
    main()

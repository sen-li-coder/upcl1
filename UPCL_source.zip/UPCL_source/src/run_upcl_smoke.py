# -*- coding: utf-8 -*-
"""Paired smoke comparison: bare vs the *aggressive* UPCL config.

The bare arm already lives on disk (``results/grid`` / ``results/cec``) and is
reused verbatim; only the ``aggressive`` arm is re-run.  Because both arms use
the same seed for the same run index, every ``bare``/``aggressive`` pair is a
strictly matched comparison.  This answers one question fast: does loosening
the decision lock (low margin, no adaptive margin, low cost, exploration that
never switches off) turn the layer's near-zero effect positive?

    python src/run_upcl_smoke.py --runs 10 --workers 1
    python src/run_upcl_smoke.py --runs 30 --hosts 6 --fids 1 4 10
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
           'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(_v, '1')

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                        # noqa: E402
import de_hosts_cec as DHC                                     # noqa: E402
import run_upcl_cec as R                                       # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'smoke'
SUITE, DIM = 'cec2022', 10
FES_MULT = R.FES_MULT
SEED_BASE = R.SEED_BASE
DEFAULTS = dict(runs=10, hosts=4, fids=(1, 4, 10))


def _seed_for(fid, dim, r):
    return SEED_BASE + dim * 1_000_003 + r * 7919 + fid * 31


def _path(host, fid, arm):
    return (OUT / 'raw' / SUITE / f'D{DIM}'
            / f'{host.replace("/", "-")}__F{fid}__{arm}.json')


def _load_bare(host, fid, runs):
    """Reuse the bare arm from an existing grid/cec record, if complete."""
    name = f'{host.replace("/", "-")}__F{fid}.json'
    for base in (ROOT / 'results' / 'grid', ROOT / 'results' / 'cec'):
        p = base / 'raw' / SUITE / f'D{DIM}' / name
        if not p.exists():
            continue
        try:
            with open(p, encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        out = {}
        for r in d.get('runs', []):
            b = r.get('bare')
            if isinstance(b, dict) and 'err_curve' in b:
                out[r['run']] = b
        if len(out) >= runs:
            return out
    return None


def run_cell(task):
    host, fid, runs, arm = task
    func = CS.get_function(SUITE, DIM, fid)
    pop = DHC.pop_size_for(host, DIM)
    max_evals = FES_MULT * DIM
    bare = _load_bare(host, fid, runs)
    if bare is None:
        return ('skip-nobare', host, fid, 0.0)

    t0 = time.perf_counter()
    runs_list = []
    for r in range(runs):
        seed = _seed_for(fid, DIM, r)
        agg = R.run_arm(host, func, DIM, seed, max_evals,
                        arm, pop_size=pop)
        runs_list.append({'run': r, 'seed': seed,
                          'bare': bare[r], arm: agg})

    payload = {'suite': SUITE, 'dim': DIM, 'host': host, 'fid': fid,
               'func': func.name, 'category': func.category,
               'max_evals': int(max_evals), 'runs_complete': len(runs_list),
               'arms': ['bare', arm], 'runs': runs_list}
    out_file = _path(host, fid, arm)
    out_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_file.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(payload, fh)
    tmp.replace(out_file)
    return ('done', host, fid, time.perf_counter() - t0)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--runs', type=int, default=DEFAULTS['runs'])
    ap.add_argument('--hosts', type=int, default=DEFAULTS['hosts'],
                    help='number of leading hosts from CEC_HOST_ORDER')
    ap.add_argument('--fids', nargs='*', type=int, default=list(DEFAULTS['fids']))
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--arm', default='aggressive',
                    help='UPCL config name(s), comma-separated, to run '
                         '(e.g. aggressive_margin10,aggressive_margin15)')
    a = ap.parse_args(argv)

    arms = [x.strip() for x in a.arm.split(',') if x.strip()]
    hosts = DHC.CEC_HOST_ORDER[:a.hosts]
    tasks = [(h, f, a.runs, arm) for arm in arms for h in hosts for f in a.fids]
    print(f'[smoke] {len(tasks)} cells ({len(arms)} arms x {len(hosts)} hosts '
          f'x {len(a.fids)} funcs) x {a.runs} runs, bare reused',
          flush=True)

    ctx = mp.get_context('spawn')
    t0 = time.perf_counter()
    done = 0
    with ctx.Pool(a.workers) as pool:
        for st, h, f, dt in pool.imap_unordered(run_cell, tasks):
            done += 1
            el = time.perf_counter() - t0
            remain = (el / done) * (len(tasks) - done)
            print(f'[smoke] {done}/{len(tasks)} {st} {h} F{f} '
                  f'{dt / 60:.1f} min  elapsed {el / 60:.1f} min  '
                  f'left ~{remain / 60:.1f} min', flush=True)
    print(f'[smoke] finished {done} cells in '
          f'{(time.perf_counter() - t0) / 60:.1f} min')


if __name__ == '__main__':
    main()

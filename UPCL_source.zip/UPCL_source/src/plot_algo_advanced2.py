# -*- coding: utf-8 -*-
"""Advanced multi-layer figures (batch 2):
   shap_beeswarm : SHAP summary beeswarm + dependence plot (gain ~ mechanisms + capacity)
   hexbin_scatter: hexbin density of capacity x gain + 8 selected algorithms
   radar_algo    : 8 selected algorithms, 6-axis radar faceted 2x4
Run: python src/plot_algo_advanced2.py
"""
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib import patheffects as pe

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

SELECTED = ['NL-SHADE-RSP', 'MadDE', 'L-SHADE',
            'SHADE', 'JADE', 'jDE100', 'DE/best/1']
ALGO_COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',
               '#9467bd', '#8c564b', '#e377c2', '#7f7f7f']
FEATURES = {
    'capacity': 'bare_median_log10err',
    'rho': 'rho_step_effect',
    'theta': 'theta_align_effect',
    'eta': 'eta_elite_effect',
    'kappa': 'kappa_crowd_effect',
    'nu': 'nu_novel_effect',
}


def _read():
    p = TABLES / 'mech30_cells.csv'
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return np.nan
    return v if np.isfinite(v) else np.nan


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6, 'ytick.labelsize': 6,
        'legend.fontsize': 6, 'legend.frameon': False, 'figure.dpi': 300})


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[adv2] {name}')


def _outline():
    return [pe.withStroke(linewidth=2.0, foreground='white')]


def _prepare_xy(rows):
    cols = list(FEATURES.values())
    X = np.array([[float(r[c]) for c in cols] for r in rows], dtype=float)
    y = np.array([float(r['dec_median']) for r in rows], dtype=float)
    m = np.isfinite(X).all(axis=1) & np.isfinite(y)
    return X[m], y[m]


def shap_beeswarm(rows):
    import shap
    from sklearn.ensemble import GradientBoostingRegressor
    X, y = _prepare_xy(rows)
    fnames = list(FEATURES.keys())
    model = GradientBoostingRegressor(n_estimators=120, max_depth=3,
                                      random_state=0)
    model.fit(X, y)
    explainer = shap.TreeExplainer(model)
    sv = explainer.shap_values(X)
    if isinstance(sv, list):
        sv = np.asarray(sv[0])
    sv = np.asarray(sv)

    feat_imp = np.abs(sv).mean(axis=0)
    order = np.argsort(feat_imp)[::-1]
    n, nf = sv.shape

    fig = plt.figure(figsize=(8.4, 4.6))
    gs = gridspec.GridSpec(1, 2, width_ratios=[1.35, 1], wspace=0.18)
    ax = fig.add_subplot(gs[0, 0])
    axd = fig.add_subplot(gs[0, 1])

    # beeswarm (manual jitter by rank)
    for yi, fi in enumerate(order):
        s = sv[:, fi]
        rank = np.argsort(np.argsort(s))
        ypos = yi - 0.38 + 0.76 * (rank / max(n - 1, 1))
        vn = (X[:, fi] - X[:, fi].min()) / (np.ptp(X[:, fi]) + 1e-9)
        colors = plt.cm.coolwarm(vn)
        ax.scatter(s, ypos, s=4, c=colors, linewidths=0, alpha=0.7)
    ax.axvline(0, color='#333333', linewidth=0.8)
    ax.set_yticks(range(nf))
    ax.set_yticklabels([fnames[i] for i in order], fontsize=7)
    ax.set_xlabel('SHAP value (impact on gain)')
    ax.set_title('SHAP summary (gain ~ mechanisms + capacity)', loc='left')
    ax.grid(axis='x', color='#dddddd', linewidth=0.4, alpha=0.5)
    ax.set_axisbelow(True)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)

    # dependence of top feature
    top = order[0]
    second = order[1]
    vn2 = (X[:, second] - X[:, second].min()) / (np.ptp(X[:, second]) + 1e-9)
    sc = axd.scatter(X[:, top], sv[:, top], s=5, c=plt.cm.coolwarm(vn2),
                     linewidths=0, alpha=0.7)
    axd.axhline(0, color='#333333', linewidth=0.8)
    axd.set_xlabel(f'{fnames[top]}')
    axd.set_ylabel(f'SHAP of {fnames[top]}')
    axd.set_title(f'dependence: {fnames[top]} (color={fnames[second]})', loc='left', fontsize=7)
    for sp in ('top', 'right'):
        axd.spines[sp].set_visible(False)
    axd.grid(color='#dddddd', linewidth=0.4, alpha=0.5); axd.set_axisbelow(True)

    cbar = fig.colorbar(sc, ax=[ax, axd], fraction=0.03, pad=0.03)
    cbar.ax.tick_params(labelsize=5)
    cbar.set_label('feature value (low..high)', fontsize=6)
    _save(fig, 'shap_beeswarm.png')


def hexbin_scatter(rows):
    cx = np.array([_f(r['bare_median_log10err']) for r in rows])
    cy = np.array([_f(r['dec_median']) for r in rows])
    m = np.isfinite(cx) & np.isfinite(cy)
    cx, cy = cx[m], cy[m]
    xlo, xhi = np.percentile(cx, [0.5, 99.5])
    ylo, yhi = np.percentile(cy, [0.5, 99.5])
    keep = (cx >= xlo) & (cx <= xhi) & (cy >= ylo) & (cy <= yhi)
    cx, cy = cx[keep], cy[keep]

    by_host_bare = defaultdict(list)
    by_host_dec = defaultdict(list)
    for r in rows:
        by_host_bare[r['host']].append(_f(r['bare_median_log10err']))
        by_host_dec[r['host']].append(_f(r['dec_median']))

    fig = plt.figure(figsize=(6.6, 5.6))
    gs = gridspec.GridSpec(2, 2, width_ratios=[4.2, 1], height_ratios=[1, 4.2],
                           hspace=0.05, wspace=0.05)
    ax = fig.add_subplot(gs[1, 0])
    ax_top = fig.add_subplot(gs[0, 0], sharex=ax)
    ax_right = fig.add_subplot(gs[1, 1], sharey=ax)

    hb = ax.hexbin(cx, cy, gridsize=36, cmap='viridis', mincnt=1,
                   bins='log', linewidths=0.2, zorder=1)
    ax.axhline(0, color='#d62728', linewidth=0.8, linestyle='--', zorder=2)
    for i, h in enumerate(SELECTED):
        b = np.array([v for v in by_host_bare[h] if np.isfinite(v)])
        d = np.array([v for v in by_host_dec[h] if np.isfinite(v)])
        ax.scatter(np.median(b), np.median(d), s=52, color=ALGO_COLORS[i],
                   edgecolors='white', linewidths=0.8, zorder=5)
        ax.annotate(h, (np.median(b), np.median(d)),
                    xytext=(np.median(b) + 0.15, np.median(d) + 0.04),
                    fontsize=6.2, color='#111111', path_effects=_outline(), zorder=6)
    ax.set_xlim(xlo, xhi); ax.set_ylim(ylo, yhi)
    ax.set_xlabel('host capacity  (log10 median error, lower = stronger)')
    ax.set_ylabel('intervention gain  (dec)')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)

    # marginals
    from scipy.stats import gaussian_kde
    dk = gaussian_kde(cy)
    t = np.linspace(ylo, yhi, 240)
    ax_top.plot(t, dk(t), color='#1f77b4', linewidth=1.2)
    ax_top.fill_between(t, dk(t), alpha=0.14, color='#1f77b4')
    ax_top.axvline(0, color='#d62728', linewidth=0.7, linestyle='--')
    ax_top.tick_params(labelbottom=False)
    for sp in ('top', 'right'):
        ax_top.spines[sp].set_visible(False)
    bk = gaussian_kde(cx)
    s = np.linspace(xlo, xhi, 240)
    ax_right.plot(bk(s), s, color='#d62728', linewidth=1.2)
    ax_right.fill_betweenx(s, bk(s), alpha=0.14, color='#d62728')
    ax_right.tick_params(labelleft=False)
    for sp in ('top', 'right'):
        ax_right.spines[sp].set_visible(False)

    cbar = fig.colorbar(hb, ax=ax, fraction=0.046, pad=0.04)
    cbar.ax.tick_params(labelsize=5)
    cbar.set_label('cell density (log)', fontsize=6)
    ax.set_title('hexbin density + 8 selected algorithms', loc='left')
    _save(fig, 'hexbin_scatter.png')


def radar_algo(rows):
    radar_feats = list(FEATURES.keys())  # capacity + 5 mechanisms
    # per-algo median of |effect| for mechanisms, capacity reversed
    vals = {h: {k: [] for k in radar_feats} for h in SELECTED}
    for r in rows:
        if r['host'] not in vals:
            continue
        vals[r['host']]['capacity'].append(-_f(r['bare_median_log10err']))
        for k in ['rho', 'theta', 'eta', 'kappa', 'nu']:
            vals[r['host']][k].append(abs(_f(r['rho_step_effect' if k == 'rho' else
                                               'theta_align_effect' if k == 'theta' else
                                               'eta_elite_effect' if k == 'eta' else
                                               'kappa_crowd_effect' if k == 'kappa' else
                                               'nu_novel_effect'])))
    med = {}
    for h in SELECTED:
        med[h] = [np.nanmedian(np.array(vals[h][k])[np.isfinite(vals[h][k])])
                  for k in radar_feats]
    # min-max normalize across the 8 algorithms
    M = np.array([med[h] for h in SELECTED])
    lo = M.min(axis=0); hi = M.max(axis=0)
    Mnorm = (M - lo) / (hi - lo + 1e-9)

    angles = np.linspace(0, 2 * np.pi, len(radar_feats), endpoint=False).tolist()
    angles += angles[:1]

    fig, axes = plt.subplots(2, 4, subplot_kw=dict(polar=True),
                             figsize=(11, 5.6))
    for i, (h, ax) in enumerate(zip(SELECTED, axes.ravel())):
        vals_i = Mnorm[i].tolist() + [Mnorm[i][0]]
        ax.plot(angles, vals_i, color=ALGO_COLORS[i], linewidth=1.4)
        ax.fill(angles, vals_i, color=ALGO_COLORS[i], alpha=0.22)
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels([k[:4] for k in radar_feats], fontsize=5.5)
        ax.set_ylim(0, 1)
        ax.set_yticks([0.5, 1.0])
        ax.set_yticklabels(['', '1'], fontsize=5)
        ax.set_title(h, fontsize=7, color=ALGO_COLORS[i], pad=6)
        ax.tick_params(labelsize=5)
        ax.grid(color='#dddddd', linewidth=0.5, alpha=0.7)
    fig.suptitle('8 selected algorithms: mechanism-response profile '
                 '(capacity + |rho/theta/eta/kappa/nu|, min-max normalized)',
                 fontsize=9, y=0.98)
    _save(fig, 'radar_algo.png')


if __name__ == '__main__':
    _style()
    rows = _read()
    shap_beeswarm(rows)
    hexbin_scatter(rows)
    radar_algo(rows)
    print('[adv2] done ->', FIG)

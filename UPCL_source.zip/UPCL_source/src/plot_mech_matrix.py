# -*- coding: utf-8 -*-
"""D8 near pairs as a row-aligned single-mechanism change matrix.

Standalone preview script (not wired into ``analyze_mech_attribution.py``).  It
re-reads two existing tables and renders
``results/cec/figures/attr_d8_near_matrix.png``:

* ``results/cec/tables/attr_d8_near_pairs.csv``  -> the 40 near pairs + deltas
* ``results/cec/tables/mech30_cells.csv``        -> host bare accuracy (rank)

Why this form.  The earlier renderings of this data were (i) two stacked panels
-- a 4-row ``|d_dec|`` CI plot over 40 bars -- sharing neither axis nor row
order, and (ii) an arc drawing whose arcs had to be stretched ~17x to be
visible.  Both spend paper on furniture (subplot chrome, dendrogram gutters,
half-empty bands) and neither shows *why* a pair moved.  Here the 40 controlled
comparisons are rows of one matrix grouped by the single dimension that
differs, so a row reads left to right as
``pair -> what changed -> what moved``.  Each group's aggregate is a header row
*of its own group* rather than a separate panel, which is what visually ties the
aggregate to the 16/17 raw rows it summarises.

Columns are chosen from the data, not for looks:
  * ``policy_rate`` and ``intervention_rate`` are the same measurable (Spearman
    0.986 over 1537 cells) -> keep one;
  * among the five UPCL descriptor deltas ``rho_step``/``eta_elite`` (0.91) and
    ``rho_step``/``kappa_crowd`` (0.86) are near duplicates -> drop those two
    and show ``rho_step``/``theta_align``/``nu_novel``, z-scored per column.
Checked and rejected: clustering the 40 pairs on their descriptor signature
does *not* recover the mechanism dimension (Ward, k=2 puts 6 mutation + 6 param
in one cluster), so no ordering by "response type" is claimed.

Convention inherited from the tables: a pair is ``(a, b)`` in taxonomy order
(mechanism level ascending) and ``d = value_b - value_a``.

Usage:
    python src/plot_mech_matrix.py [--out PATH]
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt                                    # noqa: E402
import matplotlib.colors as mcolors                                # noqa: E402
from matplotlib.colors import TwoSlopeNorm                         # noqa: E402
from matplotlib.patches import Rectangle                           # noqa: E402
from scipy.stats import t as tdist                                 # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

# Latin font first: this figure is English-only, and a CJK font (YaHei) draws
# Latin glyphs ~40% wider, which silently blows up the tight bbox.
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans',
                                   'Microsoft YaHei', 'SimHei']
plt.rcParams['axes.unicode_minus'] = False

DIM_C = {'param': '#3C5488', 'mutation': '#00A087',
         'pop': '#E69F00', 'other': '#E64B35'}
DIM_LA = {'param': 'parameter control', 'mutation': 'mutation',
          'pop': 'population reduction', 'other': 'extra operator'}

# short forms so the row chip fits 1.5in at 6.2pt; raw values are untouched
SHORT = {'current-to-best/1': 'cur-to-best/1', 'current-to-rand/1': 'cur-to-rand/1',
         'current-to-pbest/1': 'cur-to-pbest/1', 'history+rank': 'hist+rank',
         'history+CR': 'hist+CR', 'history': 'hist', 'individual': 'indiv',
         'individual-ns': 'indiv-ns', 'sinusoidal': 'sine', 'distance': 'dist',
         'adaptive': 'adapt', 'ensemble': 'ens', 'nonlinear': 'nonlin',
         'iterated local search': 'ILS', '': 'none'}


def load():
    """Row records for the matrix, plus the data facts the caption quotes."""
    pairs = pd.read_csv(TAB / 'attr_d8_near_pairs.csv')
    cells = pd.read_csv(TAB / 'mech30_cells.csv')
    bare = cells.groupby('host')['bare_median_log10err'].mean().sort_values()
    rank = {h: i + 1 for i, h in enumerate(bare.index)}

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from analyze_mech30 import MECH                       # noqa: E402

    recs = []
    for _, r in pairs.iterrows():
        a, b, d = r['a'], r['b'], r['diff_dim']
        recs.append(dict(
            dim=d, a=a, b=b, ra=rank[a], rb=rank[b],
            la=SHORT.get(MECH[a][d], MECH[a][d]),
            lb=SHORT.get(MECH[b][d], MECH[b][d]),
            d_dec=float(r['d_dec']), d_pol=float(r['d_policy']),
            d_shf=float(r['d_shift']),
            sig=[float(r[f'd_{k}_effect']) for k in
                 ('rho_step', 'theta_align', 'nu_novel')]))
    recs.sort(key=lambda e: (DIM_ORDER.index(e['dim']), -e['d_dec']))
    return recs


DIM_ORDER = ['param', 'mutation', 'pop', 'other']


def group_stats(sub):
    """mean |d_dec| with the same t-interval the pipeline uses, n, sign split."""
    v = np.abs([e['d_dec'] for e in sub])
    n = len(v)
    m = float(v.mean())
    if n < 2:
        return dict(n=n, mean=m, lo=None, hi=None,
                    pos=int(sum(e['d_dec'] > 0 for e in sub)))
    se = v.std(ddof=1) / np.sqrt(n)
    lo, hi = tdist.interval(0.95, n - 1, loc=m, scale=se)
    return dict(n=n, mean=m, lo=max(lo, 0.0), hi=hi, lo_raw=lo,
                pos=int(sum(e['d_dec'] > 0 for e in sub)))


# ---------------------------------------------------------------------------
# layout: everything in inches, 1 data unit == 1 inch in both directions
# ---------------------------------------------------------------------------
COLS = [('band', 0.15), ('rank', 0.36), ('pair', 2.34), ('chg', 1.54),
        ('d_dec', 0.58), ('d_pol', 0.58), ('d_shf', 0.58),
        ('s_rho', 0.58), ('s_the', 0.58), ('s_nu', 0.58)]
HEAD, GRP_H, ROW_H, GAP = 1.02, 0.36, 0.196, 0.13
FP = 6.4                                    # row font size


def _num_norm(v, vm):
    return TwoSlopeNorm(vmin=-vm, vcenter=0.0, vmax=vm)(v)


def _txt_on(rgba):
    """dark text on light fill, white on saturated fill"""
    lum = mcolors.rgb_to_hsv(rgba[:3])[2]
    lum *= 1.0 - 0.6 * mcolors.rgb_to_hsv(rgba[:3])[1]
    return 'white' if lum < 0.52 else '0.12'


def draw(recs, out):
    xs, cur = {}, 0.0
    for name, w in COLS:
        xs[name] = (cur, w)
        cur += w
    W = cur
    groups = [(d, [e for e in recs if e['dim'] == d]) for d in DIM_ORDER]
    groups = [(d, s) for d, s in groups if s]
    H = HEAD + len(groups) * GRP_H + len(recs) * ROW_H + (len(groups) - 1) * GAP

    LM, RM, TM, BM = 0.10, 0.12, 0.26, 1.06
    fw, fh = W + LM + RM, H + TM + BM
    fig = plt.figure(figsize=(fw, fh))
    ax = fig.add_axes([LM / fw, BM / fh, W / fw, H / fh])
    ax.set_xlim(0, W)
    ax.set_ylim(H, 0.0)
    ax.axis('off')

    def box(x, w, y, h, fc='white', ec='white', lw=0.7, z=1):
        ax.add_patch(Rectangle((x, y), w, h, facecolor=fc, edgecolor=ec,
                               linewidth=lw, zorder=z))

    def put(x, y, s, ha='left', va='center', size=FP, color='0.15', **kw):
        ax.text(x, y, s, ha=ha, va=va, fontsize=size, color=color, **kw)

    # ---- colour limits: per column, +- max |value| (stated in the header)
    vm = {'d_dec': max(abs(e['d_dec']) for e in recs),
          'd_pol': max(abs(e['d_pol']) for e in recs),
          'd_shf': max(abs(e['d_shf']) for e in recs)}
    S = np.array([e['sig'] for e in recs])
    Z = np.clip((S - S.mean(0)) / (S.std(0, ddof=1) + 1e-12), -2.0, 2.0)
    zof = {id(e): Z[i] for i, e in enumerate(recs)}
    SIGC = [('s_rho', 0, 'rho_step'), ('s_the', 1, 'theta_align'),
            ('s_nu', 2, 'nu_novel')]

    # ---- header: title, tier-1 spans, tier-2 column labels
    put(0.0, 0.18, 'D8  One mechanism dimension at a time: 40 controlled '
        'comparisons over 29 DE variants', size=10.5, color='0.10',
        fontweight='bold')
    spans = [('the controlled comparison',
              ['rank', 'pair', 'chg'], '0.20'),
             ('outcome change   Δ = b − a', ['d_dec', 'd_pol', 'd_shf'], '0.20'),
             ('UPCL decision signature  Δ  (z-scored)',
              ['s_rho', 's_the', 's_nu'], '0.20')]
    for lab, cols, col in spans:
        x0 = xs[cols[0]][0]
        x1 = xs[cols[-1]][0] + xs[cols[-1]][1]
        put(x0, 0.60, lab, size=7.3, color=col, fontweight='bold')
        ax.plot([x0, x1], [0.70, 0.70], color='0.78', lw=0.8, zorder=2)
    hdr = {'rank': '#a→#b', 'pair': 'pair   a  →  b',
           'chg': 'the one dimension that differs',
           'd_dec': f'Δdec  ±{vm["d_dec"]:.2f}',
           'd_pol': f'Δρ  ±{vm["d_pol"]:.2f}',
           'd_shf': f'Δshift  ±{vm["d_shf"]:.2f}'}
    for k, (x, w) in xs.items():
        if k == 'band':
            continue
        put(x + (0.02 if k in ('rank', 'pair', 'chg') else w / 2), 0.88,
            hdr.get(k, ''), ha='left' if k in ('rank', 'pair', 'chg') else 'center',
            size=6.5, color='0.30', fontweight='bold')
    for k, _, nm in SIGC:
        x, w = xs[k]
        put(x + w / 2, 0.885, nm, ha='center', size=6.2, color='0.30',
            fontweight='bold')


    # ---- rows
    y = HEAD
    for gi, (d, sub) in enumerate(groups):
        c = DIM_C[d]
        st = group_stats(sub)
        box(xs['band'][0], xs['band'][1], y, GRP_H, fc=c, ec=c)
        box(xs['band'][0] + xs['band'][1], W - xs['band'][0] - xs['band'][1],
            y, GRP_H, fc=mcolors.to_rgba(c, 0.11), ec='none')
        put(xs['rank'][0] + 0.02, y + 0.118,
            f'{DIM_LA[d]}   ·   {st["n"]} pair' + ('s' if st['n'] > 1 else ''),
            size=7.6, color=c, fontweight='bold')
        if st['lo'] is None:
            s = f'mean |Δdec| {st["mean"]:.3f} · no interval (n = 1)'
        else:
            los = '≈0' if st['lo_raw'] < 0 else f'{st["lo"]:.3f}'
            s = (f'mean |Δdec| {st["mean"]:.3f} · CI [{los}, {st["hi"]:.3f}]'
                 f' · {st["pos"]}/{st["n"]} up')
        put(xs['rank'][0] + 0.02, y + 0.262, s, size=6.6, color='0.25')

        # the group's own effect distribution, drawn INSIDE its header row:
        # one dot per pair on a log |d_dec| axis + mean and 95% t-interval
        sx0, sw = LM + 2.55, W + LM - 2.55 - 0.05
        sh = GRP_H - 0.10
        axs = fig.add_axes([sx0 / fw, (BM + H - y - GRP_H + 0.075) / fh,
                            sw / fw, sh / fh])
        v = np.array([abs(e['d_dec']) for e in sub])
        yy = 0.16 + 0.68 * (np.arange(len(v)) + 0.5) / len(v)
        axs.set_xscale('log')
        axs.scatter(v, yy, s=7.0, color=c, linewidths=0.4, edgecolors='white',
                    zorder=3)
        if st['lo'] is not None:
            axs.plot([max(st['lo'], 6e-4), st['hi']], [0.5, 0.5], color=c,
                     lw=1.5, zorder=2, solid_capstyle='butt')
        axs.plot([max(st['mean'], 6e-4)], [0.5], marker='D', ms=3.4, color=c,
                 zorder=4, markeredgecolor='white', markeredgewidth=0.4)
        axs.set_xlim(7e-4, 1.05)
        axs.set_ylim(0.0, 1.0)
        axs.set_yticks([])
        axs.set_xticks([1e-3, 1e-2, 1e-1, 1.0])
        axs.set_xticklabels(['$10^{-3}$', '$10^{-2}$', '$10^{-1}$', '1'],
                            fontsize=4.6, color='0.45')
        axs.tick_params(axis='x', length=1.6, pad=0.6, colors='0.55')
        for k, sp in axs.spines.items():
            sp.set_visible(k == 'bottom')
        axs.spines['bottom'].set_color('0.65')
        axs.spines['bottom'].set_linewidth(0.6)
        y += GRP_H

        for e in sub:
            box(xs['band'][0], xs['band'][1], y, ROW_H,
                fc=mcolors.to_rgba(c, 0.85), ec='none')
            put(xs['rank'][0] + 0.02, y + ROW_H / 2, f'{e["ra"]}→{e["rb"]}',
                size=6.0, color='0.45')
            put(xs['pair'][0] + 0.02, y + ROW_H / 2,
                f'{e["a"]}  →  {e["b"]}', size=FP, color='0.12')
            box(xs['chg'][0] + 0.03, xs['chg'][1] - 0.06, y + 0.012,
                ROW_H - 0.024, fc=mcolors.to_rgba(c, 0.16), ec='none')
            put(xs['chg'][0] + 0.07, y + ROW_H / 2, f'{e["la"]} → {e["lb"]}',
                size=6.1, color=c, fontweight='bold')
            vals = [('d_dec', e['d_dec'], 2), ('d_pol', e['d_pol'], 3),
                    ('d_shf', e['d_shf'], 3)]
            for k, v, nd in vals:
                fc = plt.cm.RdBu_r(_num_norm(v, vm[k]))
                box(xs[k][0], xs[k][1], y, ROW_H, fc=fc, ec='white', lw=1.0)
                put(xs[k][0] + xs[k][1] / 2, y + ROW_H / 2, f'{v:+.{nd}f}',
                    ha='center', size=6.0, color=_txt_on(fc))
            zz = zof[id(e)]
            for k, j, _n in SIGC:
                fc = plt.cm.RdBu_r(_num_norm(zz[j], 2.0))
                box(xs[k][0], xs[k][1], y, ROW_H, fc=fc, ec='white', lw=1.0)
                put(xs[k][0] + xs[k][1] / 2, y + ROW_H / 2, f'{zz[j]:+.2f}',
                    ha='center', size=6.0, color=_txt_on(fc))
            y += ROW_H
        y += GAP

    # ---- footnote
    lines = [
        'Each row is one controlled comparison: two variants whose six-dimension mechanism profile differs in exactly one dimension; rows are grouped by that dimension, sorted by Δdec.',
        'Δ = value(b) − value(a), (a, b) in taxonomy order (mechanism level ascending): red = later variant higher. Colour limits: ± that column\'s largest |Δ|.',
        'Signature block: the three least redundant UPCL descriptor deltas, z-scored over the 40 pairs and clipped at ±2.',
        'rho_step = step length, theta_align = success direction, nu_novel = novelty. eta_elite and kappa_crowd are omitted: both track rho_step (r = 0.91 / 0.86).',
        'Group header strip: that group on a log |Δdec| axis — one dot per pair, a diamond for the mean |Δdec|, a bar for its 95% t-interval; "p/n up" counts pairs with Δdec > 0.',
        'The main-effect view sits inside the rows it summarises, not in a second panel. An interval bound below 0 is printed as ≈0, since |Δdec| ≥ 0.',
        'Descriptive only: the 29 variants are a designed sample, so a per-group t-interval is not a population claim; policy_rate and intervention_rate are one measurable (r = 0.99).',
    ]
    fh = H + TM + BM
    for i, t in enumerate(lines):
        fig.text(LM / (W + LM + RM), (BM - 0.10 - i * 0.135) / fh,
                 t.replace('$', ''), fontsize=6.6, color='0.40', va='top')
    fig.savefig(out, dpi=150, bbox_inches='tight')
    plt.close(fig)
    try:                       # tight bbox self-check: any artist wider than
        from PIL import Image  # the figure widens the canvas silently
        pw, ph = Image.open(out).size
        if pw / 150.0 > fw + 0.35 or ph / 150.0 > fh + 0.35:
            print(f'[near-matrix] WARNING canvas {pw / 150:.2f} x '
                  f'{ph / 150:.2f} in but figure is {fw:.2f} x {fh:.2f} in: '
                  f'an artist overflows the figure box')
    except Exception:
        pass

    print(f'[near-matrix] written -> {out}')
    print(f'[near-matrix] {W:.2f} x {H:.2f} in of matrix, '
          f'{len(recs)} pairs in {len(groups)} groups')
    print(f'[near-matrix] {"dim":<9} {"n":>3} {"mean|d_dec|":>12} '
          f'{"95% CI":>19} {"positive":>9}')
    for d, sub in groups:
        st = group_stats(sub)
        ci = ('n=1' if st['lo'] is None
              else f'[{st["lo"]:.4f}, {st["hi"]:.4f}]')
        print(f'[near-matrix] {d:<9} {st["n"]:>3} {st["mean"]:>12.4f} '
              f'{ci:>19} {st["pos"]:>4}/{st["n"]:<4}')
    return 0


def main(out):
    return draw(load(), out)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=str(FIG / 'attr_d8_near_matrix.png'))
    sys.exit(main(Path(ap.parse_args().out)))

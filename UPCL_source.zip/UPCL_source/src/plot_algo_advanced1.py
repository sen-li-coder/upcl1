# -*- coding: utf-8 -*-
"""Advanced multi-layer figures (batch 1):
   corr_heatmap : clustered Spearman correlation heatmap
   radial_corr  : radial correlation rose (polar bars from 'gain')
   volcano      : indicator-level volcano (effect size vs -log10 p)
Run: python src/plot_algo_advanced1.py
"""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import squareform

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

IND = {
    'capacity': 'bare_median_log10err',
    'gain': 'dec_median',
    'ri': 'ri_mean',
    'interv.': 'intervention_rate',
    'rho (step)': 'rho_step_effect',
    'theta (align)': 'theta_align_effect',
    'eta (elite)': 'eta_elite_effect',
    'kappa (crowd)': 'kappa_crowd_effect',
    'nu (novel)': 'nu_novel_effect',
}


def _read():
    p = TABLES / 'mech30_cells.csv'
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return np.nan
    return v if np.isfinite(v) else np.nan


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6, 'ytick.labelsize': 6,
        'legend.fontsize': 6, 'legend.frameon': False, 'figure.dpi': 300})


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[adv1] {name}')


def _matrix(rows):
    names = list(IND.keys())
    cols = list(IND.values())
    arr = {k: np.array([_f(r[c]) for r in rows]) for k, c in zip(names, cols)}
    n = len(names)
    corr = np.full((n, n), np.nan)
    pval = np.full((n, n), np.nan)
    for i in range(n):
        for j in range(n):
            a, b = arr[names[i]], arr[names[j]]
            m = np.isfinite(a) & np.isfinite(b)
            if m.sum() >= 3:
                r, p = spearmanr(a[m], b[m])
                corr[i, j], pval[i, j] = r, p
    return names, corr, pval


def corr_heatmap(rows):
    names, corr, _ = _matrix(rows)
    n = len(names)
    # hierarchical clustering on correlation distance
    d = 1 - np.abs(corr)
    d = np.nan_to_num(d, nan=1.0)
    d = (d + d.T) / 2.0
    np.fill_diagonal(d, 0)
    Z = linkage(squareform(d), method='average')
    order = leaves_list(Z)
    corr_o = corr[np.ix_(order, order)]
    names_o = [names[i] for i in order]

    from matplotlib.colors import TwoSlopeNorm
    fig, ax = plt.subplots(figsize=(5.6, 5.2))
    fig.subplots_adjust(left=0.16, right=0.98, top=0.92, bottom=0.14)
    norm = TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1)
    im = ax.imshow(corr_o, cmap='RdBu_r', norm=norm, aspect='equal')
    ax.set_xticks(range(n)); ax.set_xticklabels(names_o, rotation=45, ha='right', fontsize=6.5)
    ax.set_yticks(range(n)); ax.set_yticklabels(names_o, fontsize=6.5)
    for i in range(n):
        for j in range(n):
            v = corr_o[i, j]
            ax.text(j, i, f'{v:.2f}', ha='center', va='center',
                    fontsize=5.4, color='#111111' if abs(v) < 0.6 else 'white')
    ax.grid(False)
    ax.set_title('Spearman correlation matrix (1590 cells, clustered)', loc='left')
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.ax.tick_params(labelsize=5.5)
    cbar.set_label('Spearman r', fontsize=6)
    _save(fig, 'corr_heatmap.png')


def radial_corr(rows):
    names, corr, _ = _matrix(rows)
    gi = names.index('gain')
    targets = [n for n in names if n != 'gain']
    rs = [corr[gi, names.index(t)] for t in targets]

    fig = plt.figure(figsize=(6.2, 6.2))
    ax = fig.add_subplot(111, polar=True)
    theta = np.linspace(0, 2 * np.pi, len(targets), endpoint=False)
    rmax = max(0.8, np.nanmax(np.abs(rs)) + 0.15)
    ax.set_theta_zero_location('N')
    ax.set_theta_direction(-1)

    # reference rings
    for rv in [0.25, 0.5, 0.75, 1.0]:
        ax.plot(np.linspace(0, 2 * np.pi, 200), np.full(200, rv),
                color='#cccccc', linewidth=0.5, zorder=1)
        ax.text(0, rv, f'{rv:.2f}', fontsize=5, ha='center', va='bottom', color='#888888')
    ax.set_ylim(0, rmax)
    ax.set_yticks([])

    for th, r in zip(theta, rs):
        color = '#d62728' if r >= 0 else '#1f77b4'
        ax.bar(th, abs(r), width=2 * np.pi / len(targets) * 0.72,
               color=color, alpha=0.8, zorder=3, align='edge')
    for th, r, t in zip(theta, rs, targets):
        ax.text(th + np.pi / len(targets), abs(r) + 0.06, f'{r:+.2f}',
                fontsize=6.5, ha='center', color='#333333')
    ax.set_xticks(theta + np.pi / len(targets))
    ax.set_xticklabels(targets, fontsize=6.5)
    ax.set_title("Spearman r of each indicator with 'gain' (red=+, blue=-)", loc='left', fontsize=8)
    _save(fig, 'radial_corr.png')


def volcano(rows):
    names, corr, pval = _matrix(rows)
    gi = names.index('gain')
    targets = [n for n in names if n != 'gain']
    rs = [corr[gi, names.index(t)] for t in targets]
    ps = [pval[gi, names.index(t)] for t in targets]
    nl = [-np.log10(p) if p > 0 else 40 for p in ps]

    fig, ax = plt.subplots(figsize=(5.6, 4.6))
    fig.subplots_adjust(left=0.10, right=0.96, top=0.92, bottom=0.10)
    sig_line = -np.log10(0.05)
    for x, y, t in zip(rs, nl, targets):
        color = '#d62728' if x >= 0 else '#1f77b4'
        alpha = 1.0 if y >= sig_line else 0.35
        ax.scatter(x, y, s=60, color=color, alpha=alpha, edgecolors='#333333',
                   linewidths=0.6, zorder=3)
        dx = 0.03 if x >= 0 else -0.03
        ax.annotate(t, (x, y), xytext=(x + dx, y + 0.25), fontsize=6.8,
                    ha='center', color='#222222')
    ax.axhline(sig_line, color='#999999', linewidth=0.7, linestyle='--')
    ax.text(ax.get_xlim()[1], sig_line, 'p=0.05', fontsize=5.5, va='bottom', ha='right', color='#666666')
    ax.axvline(0, color='#999999', linewidth=0.7)
    ax.set_xlabel("effect size (Spearman r with 'gain')")
    ax.set_ylabel('-log10(p)')
    ax.set_title("volcano: indicator association with gain", loc='left')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(color='#dddddd', linewidth=0.4, alpha=0.5); ax.set_axisbelow(True)
    _save(fig, 'volcano.png')


if __name__ == '__main__':
    _style()
    rows = _read()
    corr_heatmap(rows)
    radial_corr(rows)
    volcano(rows)
    print('[adv1] done ->', FIG)

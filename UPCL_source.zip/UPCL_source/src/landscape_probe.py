# -*- coding: utf-8 -*-
"""二维适应度地形 + 种群收敛轨迹采样（供 GUI「二维地形图」窗口调用）。

不落盘、不跑完整实验：按需跑单 run，把种群在 x1-x2 子空间上的投影轨迹
与二维地形一并返回，用于即时可视化「算法种群如何在地形上收敛」。

被 gui_launcher.py 在后台线程中懒加载调用；依赖 numpy + cec_suites +
de_hosts + de_hosts_cec + run_upcl_cec（均已随 exe 打包）。
"""
import numpy as np


def _landscape(func, n=60, progress_cb=None):
    """在 x1-x2 平面上采样二维地形，其余维固定在最优解 x_opt[2:]。

    返回 (X, Y, Z)，其中 Z[i, j] = f(x1_j, x2_i, x_opt[2:])。
    ``progress_cb(fraction, message)`` 在分块采样间回调（fraction ∈ [0, 0.08]）。
    """
    gx = np.linspace(func.lb, func.ub, n)
    gy = np.linspace(func.lb, func.ub, n)
    X, Y = np.meshgrid(gx, gy)
    fixed = np.asarray(func.x_opt[2:], dtype=float)
    pts = np.c_[X.ravel(), Y.ravel(),
                np.broadcast_to(fixed, (X.size, fixed.size))]
    Z = np.empty(X.size, dtype=float)
    chunk = max(1, X.size // 20)
    for i in range(0, X.size, chunk):
        Z[i:i + chunk] = [func(p) for p in pts[i:i + chunk]]
        if progress_cb is not None:
            frac = 0.08 * min(1.0, (i + chunk) / X.size)
            progress_cb(frac, f'采样二维地形 {min(i + chunk, X.size)}/{X.size}')
    return X, Y, Z.reshape(X.shape)


def sample(suite, dim, fid, host_name, arm='bare', fes_mult=10000,
           n_frames=20, seed=None, runs=1, progress_cb=None):
    """按需采样一个 cell 的种群收敛轨迹 + 二维地形。

    返回 dict：
      landscape : (X, Y, Z) 二维地形
      traces    : [ {'gens':[...], 'nevals':[...], 'pop':[Nx2 ndarray, ...]}, ... ]
      err_curves: [ (grid ndarray, err ndarray), ... ]
      best_x / x_opt / f_opt / lb / ub / func / dim ...

    ``progress_cb(fraction, message)`` 全程回调（0~1），供 GUI 进度条。
    """
    import cec_suites as CS
    import de_hosts as DH
    import de_hosts_cec as DHC
    from run_upcl_cec import run_arm

    func = CS.get_function(suite, dim, fid)
    max_evals = int(fes_mult * dim)
    pop_size = DHC.pop_size_for(host_name, dim)
    X, Y, Z = _landscape(func, progress_cb=progress_cb)

    upcl_cfg = None if arm == 'bare' else 'default'
    traces, err_curves, best_x = [], [], None

    def _run_progress(nevals, g):
        if progress_cb is not None:
            frac = 0.08 + 0.92 * min(1.0, nevals / max_evals)
            progress_cb(frac, f'运行中：第 {g} 代，已评估 {nevals}/{max_evals}')

    for r in range(runs):
        s = seed if seed is not None else \
            (20240_000 + dim * 1_000_003 + r * 7919 + fid * 31)
        rec = run_arm(host_name, func, dim, int(s), max_evals, upcl_cfg,
                      pop_size=pop_size, record_pop=True, n_pop_frames=n_frames,
                      progress_cb=_run_progress)
        pt = rec.get('pop_trace')
        if pt:
            traces.append({
                'gens': list(pt['gens']),
                'nevals': list(pt['nevals']),
                'pop': [np.asarray(p, dtype=float) for p in pt['pop']],
            })
            best_x = np.asarray(pt['best_x'], dtype=float)
        err_curves.append((np.asarray(rec.get('grid', []), dtype=float),
                           np.asarray(rec['err_curve'], dtype=float)))

    return {
        'suite': suite, 'dim': dim, 'fid': fid, 'host': host_name, 'arm': arm,
        'func': func.label, 'func_name': func.name,
        'lb': float(func.lb), 'ub': float(func.ub),
        'f_opt': float(func.f_opt),
        'landscape': (X, Y, Z),
        'traces': traces,
        'err_curves': err_curves,
        'best_x': best_x.tolist() if best_x is not None else None,
        'x_opt': [float(v) for v in np.asarray(func.x_opt)[:2]],
    }

# -*- coding: utf-8 -*-
"""Final 6-figure set (3D supplement): two 3D / high-dimensional views.
   (7) 3D scatter: capacity x gain x intervention rate (30 hosts)
   (8) 3D PCA: 7-dim (5 mech + capacity + gain) -> 3D embedding (30 hosts)
"""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

MECH_COLS = ['rho_step_effect', 'theta_align_effect', 'eta_elite_effect',
             'kappa_crowd_effect', 'nu_novel_effect']
LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}
LEVEL_LABEL = {'0': 'L0 fixed', '1': 'L1 adaptive', '2': 'L2 archive', '3': 'L3 LPSR'}


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 9, 'axes.labelsize': 7.5, 'legend.fontsize': 6,
        'legend.frameon': False, 'figure.dpi': 300})


def _load():
    hs = list(csv.DictReader(open(TABLES / 'mech30_host_summary.csv',
                                  encoding='utf-8', newline='')))
    hs.sort(key=lambda r: int(r['bare_rank']))
    return hs


def _legend():
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=6,
                       color=LEVEL_COL[l], label=LEVEL_LABEL[l]) for l in LEVEL_COL]


def _tag(ax, x, y, z, s, c):
    ax.text(x, y, z, s, fontsize=5.2, color=c, zorder=10)


def _clean3d(ax):
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.xaxis.pane.set_edgecolor('#bbbbbb')
    ax.yaxis.pane.set_edgecolor('#bbbbbb')
    ax.zaxis.pane.set_edgecolor('#bbbbbb')
    ax.grid(True, color='#dddddd', linewidth=0.4, alpha=0.5)


# ---- (7) 3D scatter: capacity x gain x intervention ----
def scatter3d(hs):
    bare = np.array([_f(r['bare_median_log10err']) for r in hs])
    dec = np.array([_f(r['dec_mean']) for r in hs])
    interv = np.array([_f(r['intervention_rate']) for r in hs])
    lcol = [LEVEL_COL[r['level']] for r in hs]
    fig = plt.figure(figsize=(9.5, 7.2))
    ax = fig.add_subplot(111, projection='3d')
    ax.view_init(elev=22, azim=-58)
    _clean3d(ax)
    # projection stems to the z-min plane
    z0 = float(interv.min()) * 0.95
    for i in range(len(hs)):
        ax.plot([bare[i], bare[i]], [dec[i], dec[i]], [z0, interv[i]],
                color=lcol[i], lw=0.5, alpha=0.30, zorder=1)
    ax.scatter(bare, dec, interv, s=44, c=lcol, edgecolors='white',
               linewidths=0.6, depthshade=False, zorder=3)
    for i, r in enumerate(hs):
        _tag(ax, bare[i], dec[i], interv[i] + 0.004, r['host'], lcol[i])
    ax.set_xlabel('capacity  log10 error')
    ax.set_ylabel('UPCL gain  dec')
    ax.set_zlabel('intervention rate')
    ax.set_title('3D: capacity × gain × intervention (30 hosts, level-coloured)',
                 loc='left')
    ax.legend(handles=_legend(), loc='upper right', ncol=1, handlelength=1.0)
    fig.savefig(FIG / 'final7_3d_scatter.png', bbox_inches='tight')
    plt.close(fig)
    print('[final] final7_3d_scatter.png')


# ---- (8) 3D PCA: 7-dim -> 3D ----
def pca3d(hs):
    M = np.array([[_f(r[c]) for c in MECH_COLS] for r in hs])
    bare = np.array([_f(r['bare_median_log10err']) for r in hs])
    dec = np.array([_f(r['dec_mean']) for r in hs])
    X = np.column_stack([M, bare, dec])
    Xz = (X - X.mean(0)) / (X.std(0) + 1e-9)
    U, S, Vt = np.linalg.svd(Xz, full_matrices=False)
    P = (Xz @ Vt.T)[:, :3]
    var = (S ** 2) / (S ** 2).sum() * 100
    lcol = [LEVEL_COL[r['level']] for r in hs]
    fig = plt.figure(figsize=(9.5, 7.2))
    ax = fig.add_subplot(111, projection='3d')
    ax.view_init(elev=24, azim=-52)
    _clean3d(ax)
    z0 = float(P[:, 2].min()) * 1.05
    for i in range(len(hs)):
        ax.plot([P[i, 0], P[i, 0]], [P[i, 1], P[i, 1]], [z0, P[i, 2]],
                color=lcol[i], lw=0.5, alpha=0.30, zorder=1)
    ax.scatter(P[:, 0], P[:, 1], P[:, 2], s=46, c=lcol, edgecolors='white',
               linewidths=0.6, depthshade=False, zorder=3)
    for i, r in enumerate(hs):
        _tag(ax, P[i, 0], P[i, 1], P[i, 2] + 0.01, r['host'], lcol[i])
    ax.set_xlabel(f'PC1 ({var[0]:.0f}%)')
    ax.set_ylabel(f'PC2 ({var[1]:.0f}%)')
    ax.set_zlabel(f'PC3 ({var[2]:.0f}%)')
    ax.set_title('3D PCA: 7-dim fingerprint (5 mech + capacity + gain) → 3D',
                 loc='left')
    ax.legend(handles=_legend(), loc='upper right', ncol=1, handlelength=1.0)
    fig.savefig(FIG / 'final8_3d_pca.png', bbox_inches='tight')
    plt.close(fig)
    print('[final] final8_3d_pca.png')


if __name__ == '__main__':
    _style()
    hs = _load()
    scatter3d(hs)
    pca3d(hs)
    print('[final] 3d done ->', FIG)

# -*- coding: utf-8 -*-
"""§5.5 任务完成度：把二值 ``mission_success`` 换成连续百分比。

二值成功率在本场景没有区分度：目标有 1000 点血量，无人机每架只投一轮弹，
步兵才有持续火力，而 $15\\,000$ 次评估的预算下多数 rollout 到不了"基地归零"。
因此本脚本不做阈值判定，报告一个**综合成功率**与它的三个分量：

* ``damage_pct``  目标削弱率 $=100\\,(1-\\mathrm{hp}/\\mathrm{hp}_0)$，hp0 取配置的 1000；
* ``breach_pct``  步兵突入率 $=100\\,n_{\\mathrm{inf\\_arrived}}/n_{\\mathrm{inf}}$；
* ``kill_pct``    战果率   $=100\\,n_{\\mathrm{patrol\\_killed}}/n_{\\mathrm{patrol}}$；
* ``composite_pct`` 综合成功率 $=0.50\\,\\mathrm{damage}+0.25\\,\\mathrm{breach}+0.25\\,\\mathrm{kill}$
  （权重含义见 ``uav_scores``：终局目标占一半，两个使能条件各占四分之一）。

产出（``results/apps/tables/``）：
    uav_mission.csv            每 (host, fid, arm) 一行：三次运行的均值/中位数与 n
    uav_mission_summary.csv    每 (fid, arm) 一行：跨 29 宿主的均值与 95% CI
    uav_composite_weights.csv  每 (arm, 权重) 一行：换权重后 29 宿主排序的
                               Spearman 与前三名，作为权重不是拟合量的证据

用法：``python src/analyze_uav_mission.py``
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_uav import load_cells, arms_of  # noqa: E402
import uav_scores  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'

# 兵力与血量的配置缺省值；优先从当前仿真栈读取，避免与配置漂移。
HP0, N_INF, N_PAT = 1000.0, 3, 20
try:                                                    # pragma: no cover
    from uav_adversarial import _intercept_cfg
    _cfg0 = _intercept_cfg(1)
    HP0 = float(getattr(_cfg0, 'base_hp', HP0))
    N_INF = int(getattr(_cfg0, 'n_infantry', N_INF))
    N_PAT = int(getattr(_cfg0, 'n_patrol', N_PAT))
except Exception:
    pass


def _ratio(v, scale):
    try:
        return 100.0 * float(v) / float(scale)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def per_run(cell, arm):
    """单臂三次运行的 (damage, breach, kill, composite) 百分比列表。"""
    out = []
    for r in cell['runs']:
        rec = r.get(arm)
        if not isinstance(rec, dict):
            continue
        m = rec.get('metrics')
        if not isinstance(m, dict):
            continue
        dmg = _ratio(HP0 - float(m.get('base_hp', HP0)), HP0)
        brc = _ratio(m.get('n_inf_arrived', 0), N_INF)
        kil = _ratio(m.get('n_patrol_killed', 0), N_PAT)
        csr = uav_scores.composite(dmg, brc, kil)
        if csr is None:
            continue
        out.append((dmg, brc, kil, csr))
    return out


def _stat(vals):
    v = np.asarray(vals, float)
    if v.size == 0:
        return None
    return float(v.mean()), float(np.median(v)), float(v.std(ddof=1)) if v.size > 1 else 0.0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept')
    args = ap.parse_args(argv)

    cells = load_cells(scenario=args.scenario, min_runs=1)
    if not cells:
        raise SystemExit('[analyze_uav_mission] no raw results')

    rows = []
    for (suite, dim, host, fid), c in sorted(cells.items()):
        for arm in arms_of(c):
            pr = per_run(c, arm)
            if not pr:
                continue
            cols = {'damage': [p[0] for p in pr],
                    'breach': [p[1] for p in pr],
                    'kill': [p[2] for p in pr],
                    'composite': [p[3] for p in pr]}
            row = dict(scenario=suite.replace('uav_', ''), dim=dim, host=host,
                       fid=fid, arm=arm, n=len(pr))
            for k, vals in cols.items():
                st = _stat(vals)
                row[f'{k}_pct_mean'] = round(st[0], 4)
                row[f'{k}_pct_median'] = round(st[1], 4)
                row[f'{k}_pct_sd'] = round(st[2], 4)
            rows.append(row)

    TAB.mkdir(parents=True, exist_ok=True)
    fields = ['scenario', 'dim', 'host', 'fid', 'arm', 'n']
    for k in ('damage', 'breach', 'kill', 'composite'):
        fields += [f'{k}_pct_mean', f'{k}_pct_median', f'{k}_pct_sd']
    with open(TAB / 'uav_mission.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)

    # --- 跨宿主汇总：每 (fid, arm) 的均值与 95% CI -------------------------
    acc = defaultdict(lambda: defaultdict(list))
    for r in rows:
        for k in ('composite', 'damage', 'breach', 'kill'):
            acc[(r['fid'], r['arm'])][k].append(float(r[f'{k}_pct_median']))

    summ = []
    for (fid, arm), d in sorted(acc.items(), key=lambda kv: (int(kv[0][0]), kv[0][1])):
        out = dict(fid=fid, arm=arm, n_host=len(d['damage']))
        for k in ('composite', 'damage', 'breach', 'kill'):
            v = np.asarray(d[k], float)
            m = float(v.mean())
            if v.size > 1:
                se = float(v.std(ddof=1) / np.sqrt(v.size))
                ci = se * float(stats.t.ppf(0.975, v.size - 1))
            else:
                ci = 0.0
            out[f'{k}_pct'] = round(m, 4)
            out[f'{k}_ci'] = round(ci, 4)
        summ.append(out)

    with open(TAB / 'uav_mission_summary.csv', 'w', newline='',
              encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(summ[0].keys()))
        w.writeheader()
        w.writerows(summ)

    # --- 权重敏感性：换一组权重，29 宿主的排序是否还一样 --------------------
    # 每个宿主先在四个任务上取平均，再按权重打分排序；rho 是与 0.50/0.25/0.25
    # 基准排序的 Spearman，top3 记录前三名的宿主名，供正文核对"名次不变"。
    wrows = []
    for arm in ('bare', 'full'):
        per_host = defaultdict(lambda: [0.0, 0.0, 0.0, 0])
        for r in rows:
            if r['arm'] != arm:
                continue
            a = per_host[r['host']]
            a[0] += float(r['damage_pct_mean'])
            a[1] += float(r['breach_pct_mean'])
            a[2] += float(r['kill_pct_mean'])
            a[3] += 1
        vals = [(h, a[0] / a[3], a[1] / a[3], a[2] / a[3])
                for h, a in per_host.items()]
        for w_, rho, p in uav_scores.weight_sensitivity(vals):
            order = sorted(vals, key=lambda v: -(w_[0] * v[1] + w_[1] * v[2]
                                                 + w_[2] * v[3]))
            wrows.append({'arm': arm,
                          'weights': '/'.join(f'{x:.2f}' for x in w_),
                          'spearman_rho': round(rho, 4),
                          'p': round(p, 6),
                          'n_host': len(vals),
                          'top3': ';'.join(v[0] for v in order[:3])})
    with open(TAB / 'uav_composite_weights.csv', 'w', newline='',
              encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(wrows[0].keys()))
        w.writeheader()
        w.writerows(wrows)

    print('=== 任务完成度（跨 29 宿主均值，%）===')
    print('fid  arm    CSR   damage   breach   kill   (n_host)')
    for r in summ:
        print('F%-3s %-5s %6.2f  %6.2f   %6.2f  %6.2f   (%d)' % (
            r['fid'], r['arm'], r['composite_pct'], r['damage_pct'],
            r['breach_pct'], r['kill_pct'], r['n_host']))
    print('=== CSR 权重敏感性（与 0.50/0.25/0.25 排序的 Spearman）===')
    for r in wrows:
        print('%-5s %-18s rho=%+.4f  top3=%s' % (
            r['arm'], r['weights'], r['spearman_rho'], r['top3']))
    print(f'[analyze_uav_mission] wrote uav_mission.csv ({len(rows)} rows) + '
          f'uav_mission_summary.csv ({len(summ)} rows) + '
          f'uav_composite_weights.csv ({len(wrows)} rows)')


if __name__ == '__main__':
    main()

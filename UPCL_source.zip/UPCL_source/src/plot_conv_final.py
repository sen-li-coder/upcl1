# -*- coding: utf-8 -*-
"""Unified convergence figures for the rewritten Section 4.

Reads the raw per-cell JSON directly (the single source of truth, 30 hosts
x 3 complete blocks = 1590 cells) and produces the two figure types the
manuscript asks for:

1.  `conv_{suite}_D{dim}_all.png`  -- every function of the block, every
    variant overlaid on the same subplot grid, one colour per composition
    level, the variant alone solid and the same variant with UPCL dashed.
    Generated for CEC 2017 at D=30, CEC 2022 at D=10 and D=20, and the
    partial CEC 2017 at D=50.

2.  `conv_representative.png`     -- four typical functions (one per CEC
    category) x four representative variants (one per composition level),
    the classic small-multiple the mechanism reading turns on.

Both draw the *median* log10 error over the 30 runs of a configuration.
"""
import csv
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw'
TAB = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FIG.mkdir(parents=True, exist_ok=True)

FLOOR = 1e-8
RUNS = 30

# Nature-style level palette (NPG + Okabe-Ito, colour-blind safe), ordered
# blue -> green -> amber -> red with increasing composition level.
LEVEL_COL = {'0': '#3C5488', '1': '#00A087', '2': '#E69F00', '3': '#E64B35'}
LEVEL_LABEL = {'0': 'L0  fixed parameter', '1': 'L1  adaptive F/CR',
               '2': 'L2  archived history', '3': 'L3  LPSR / modern'}
CAT_COLOR = {'unimodal': '#8491B4', 'multimodal': '#4DBBD5',
             'hybrid': '#F39B7F', 'composite': '#7E6148'}

# Blocks to plot; cec2017 D50 is partial and handled by what is on disk.
BLOCKS = (('cec2017', 'D30'), ('cec2022', 'D10'), ('cec2022', 'D20'),
          ('cec2017', 'D50'))

# Representative variants: one per composition level, in a readable order.
REPRESENT = [
    ('NL-SHADE-RSP', '3', 'NL-SHADE-RSP'),
    ('SHADE', '2', 'SHADE'),
    ('jDE', '1', 'jDE'),
    ('DE/rand/1', '0', 'DE/rand/1'),
]

# Representative functions: one per CEC category (index into the sorted fid
# list is not needed; we pick fixed ids valid on both suites where possible,
# and fall back to the first function of the category when a id is absent).
REP_FIDS = {'unimodal': None, 'multimodal': None, 'hybrid': None,
            'composite': None}


def load_host_meta():
    meta = {}
    p = TAB / 'mech30_host_summary.csv'
    if p.exists():
        for r in csv.DictReader(open(p, encoding='utf-8')):
            meta[r['host'].replace('/', '-')] = dict(
                name=r['host'], level=r['level'], rank=int(r['bare_rank']))
    return meta


def load_cell(suite, dim, hf, fid, cache):
    key = (suite, dim, hf, fid)
    if key in cache:
        return cache[key]
    p = RAW / suite / dim / f'{hf}__F{fid}.json'
    if not p.exists():
        cache[key] = None
        return None
    d = json.load(open(p, encoding='utf-8'))
    runs = d['runs']
    if len(runs) < RUNS:
        cache[key] = None
        return None
    r0 = runs[0]
    arm = 'upcl' if 'upcl' in r0 else 'full'
    grid = np.asarray(r0['bare']['grid'], float)
    bare = np.array([r['bare']['err_curve'] for r in runs], float)
    upcl = np.array([r[arm]['err_curve'] for r in runs], float)
    cat = d.get('category', '')
    cache[key] = dict(grid=grid, bare=bare, upcl=upcl, cat=cat)
    return cache[key]


def mlog(a):
    return np.median(np.log10(np.maximum(a, FLOOR)), axis=0)


def mband(a):
    """25th-75th percentile band of the log10 error, for the shaded spread."""
    x = np.log10(np.maximum(a, FLOOR))
    return np.percentile(x, 25, axis=0), np.percentile(x, 75, axis=0)


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
                         'axes.titlesize': 8.5, 'axes.labelsize': 8,
                         'axes.linewidth': 0.6, 'axes.edgecolor': '#444444',
                         'xtick.color': '#333333', 'ytick.color': '#333333',
                         'xtick.labelsize': 6.5, 'ytick.labelsize': 7,
                         'legend.fontsize': 6.5, 'legend.frameon': False,
                         'figure.dpi': 300})


def _spines(ax):
    ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)


def _k_fmt(grid, n=4):
    xt = np.linspace(0, grid[-1], n)
    ax_ticks = [f'{int(v / 1000)}k' for v in xt]
    return xt, ax_ticks


# ---------------------------------------------------------------------------
# 1. combined overlay per block, split into per-part figures that each fit the
#    text column, and drawn as a per-level summary (median + 25-75 band over
#    the variants of the level) so that the curves no longer overlap.
# ---------------------------------------------------------------------------
def _level_summary(suite, dim, fid, level, hfs, meta, cache):
    """Median over the hosts of `level` of their median log10-error curve, with
    the 25th-75th percentile band across those hosts. Returns None when no host
    of the level has a run for the function."""
    bare, upcl, grid = [], [], None
    for h in hfs:
        if meta.get(h, {}).get('level', 'x') != level:
            continue
        c = load_cell(suite, dim, h, fid, cache)
        if c is None:
            continue
        if grid is None:
            grid = c['grid']
        bare.append(mlog(c['bare']))
        upcl.append(mlog(c['upcl']))
    if not bare:
        return None
    bare = np.vstack(bare)
    upcl = np.vstack(upcl)
    return dict(grid=grid,
                bare=np.median(bare, axis=0),
                bare_lo=np.percentile(bare, 25, axis=0),
                bare_hi=np.percentile(bare, 75, axis=0),
                upcl=np.median(upcl, axis=0),
                upcl_lo=np.percentile(upcl, 25, axis=0),
                upcl_hi=np.percentile(upcl, 75, axis=0))


def _category_of(suite, dim, fid, hfs, cache):
    for h in hfs:
        c = load_cell(suite, dim, h, fid, cache)
        if c is not None:
            return c['cat'], c['grid']
    return '', None


def plot_block_overlay(suite, dim, meta, cache):
    d = RAW / suite / dim
    if not d.exists():
        return None
    hfs = sorted({p.name.split('__')[0] for p in d.glob('*.json')})
    if not hfs:
        return None
    fids = sorted({int(p.name.split('__')[1][1:-5]) for p in d.glob('*.json')})

    # composition levels actually present among the hosts with data
    levels = sorted({meta.get(h, {}).get('level', 'x') for h in hfs}
                    & set(('0', '1', '2', '3')))

    ncol = 3
    max_row = 4                    # at most 12 functions per figure
    out_paths = []
    # Group the functions into chunks of at most max_row*ncol.  The last,
    # partially filled chunk shrinks to the smallest row count that still fits
    # its functions, so every figure keeps the same subplot size (width is fixed
    # at ncol columns) while a nearly empty block is avoided.
    chunks, i = [], 0
    while i < len(fids):
        n = min(max_row * ncol, len(fids) - i)
        chunks.append(fids[i:i + n])
        i += n
    for part, chunk in enumerate(chunks, start=1):
        nrow = max(2, (len(chunk) + ncol - 1) // ncol)   # ceil, at least 2 rows
        per = nrow * ncol
        fig, axes = plt.subplots(nrow, ncol, figsize=(2.9 * ncol, 2.0 * nrow),
                                 squeeze=False)
        fig.subplots_adjust(left=0.06, right=0.98, top=0.88, bottom=0.16,
                            hspace=0.45, wspace=0.22)
        for idx, fid in enumerate(chunk):
            ax = axes[idx // ncol, idx % ncol]
            cat, grid = _category_of(suite, dim, fid, hfs, cache)
            for lv in levels:
                s = _level_summary(suite, dim, fid, lv, hfs, meta, cache)
                if s is None:
                    continue
                col = LEVEL_COL[lv]
                # shaded 25th-75th percentile band across variants of the level
                ax.fill_between(s['grid'], s['bare_lo'], s['bare_hi'],
                                color=col, alpha=0.10, linewidth=0)
                ax.fill_between(s['grid'], s['upcl_lo'], s['upcl_hi'],
                                color=col, alpha=0.07, linewidth=0)
                ax.plot(s['grid'], s['bare'], color=col, lw=1.1)
                ax.plot(s['grid'], s['upcl'], color=col, lw=1.1, ls='--')
            ax.set_title(f'F{fid} ({cat})', fontsize=8)
            _spines(ax)
            ax.tick_params(labelsize=6)
            if grid is not None:
                ax.set_xlim(0, grid[-1])
        for j in range(len(chunk), per):
            axes[j // ncol, j % ncol].axis('off')
        # two-row shared legend: composition levels (colour) on top, line
        # styles on the bottom row, so the entries never collide with the axes
        handles_lv = [plt.Line2D([], [], color=LEVEL_COL[lv], lw=1.6,
                                 label=LEVEL_LABEL[lv]) for lv in levels]
        handles_style = [plt.Line2D([], [], color='#333333', lw=1.6, ls='-',
                                    label='variant alone'),
                         plt.Line2D([], [], color='#333333', lw=1.6, ls='--',
                                    label='with UPCL')]
        leg1 = fig.legend(handles=handles_lv, loc='lower center',
                          ncol=len(levels), bbox_to_anchor=(0.5, 0.06),
                          handlelength=1.6, columnspacing=1.4, frameon=False)
        leg2 = fig.legend(handles=handles_style, loc='lower center', ncol=2,
                          bbox_to_anchor=(0.5, 0.005), handlelength=1.6,
                          columnspacing=1.4, frameon=False)
        fig.add_artist(leg1)
        fig.suptitle(f'{suite}  $D={dim[-2:].lstrip("0")}$  '
                     f'level-median log10 error over {RUNS} runs  '
                     f'(part {part})', fontsize=9)
        out = FIG / f'conv_{suite}_D{dim[-2:]}_p{part:02d}_all.png'
        fig.savefig(out, bbox_inches='tight')
        plt.close(fig)
        print(f'[conv-final] overlay -> {out.name} '
              f'({len(levels)} levels x {len(chunk)} fn)')
        out_paths.append(out)
    return out_paths


# ---------------------------------------------------------------------------
# 2. representative functions x representative variants
# ---------------------------------------------------------------------------
def pick_rep_fids(meta, cache):
    """Pick one function per category that exists for all four representative
    variants on cec2017 D30 (the anchor block)."""
    reps = [r[2].replace('/', '-') for r in REPRESENT]
    d = RAW / 'cec2017' / 'D30'
    avail = {}
    for p in d.glob('*.json'):
        name = p.name.split('__')[0]
        fid = int(p.name.split('__')[1][1:-5])
        if name in reps:
            avail.setdefault(fid, set()).add(name)
    # a fid is usable if present for all four reps
    usable = {f for f, hs in avail.items() if hs >= set(reps)}
    # order by fid within category
    by_cat = {}
    for fid in sorted(usable):
        c = load_cell('cec2017', 'D30', reps[0], fid, cache)
        if c:
            by_cat.setdefault(c['cat'], []).append(fid)
    chosen = {}
    for cat in ('unimodal', 'multimodal', 'hybrid', 'composite'):
        if cat in by_cat:
            chosen[cat] = by_cat[cat][0]
    return chosen


def plot_representative(meta, cache):
    rep_fids = pick_rep_fids(meta, cache)
    cats = [c for c in ('unimodal', 'multimodal', 'hybrid', 'composite')
            if c in rep_fids]
    if not cats:
        print('[conv-final] no representative functions found')
        return None
    nf = len(cats)
    nv = len(REPRESENT)
    fig, axes = plt.subplots(nv, nf, figsize=(2.3 * nf + 1.2, 1.9 * nv + 1.2),
                             squeeze=False)
    fig.subplots_adjust(left=0.14, right=0.98, top=0.95, bottom=0.08,
                        hspace=0.34, wspace=0.14)
    for i, (host, lvl, disp) in enumerate(REPRESENT):
        for j, cat in enumerate(cats):
            ax = axes[i, j]
            fid = rep_fids[cat]
            c = load_cell('cec2017', 'D30', host.replace('/', '-'), fid, cache)
            if c is None:
                ax.axis('off')
                continue
            col = LEVEL_COL[lvl]
            blo, bhi = mband(c['bare'])
            ulo, uhi = mband(c['upcl'])
            ax.fill_between(c['grid'], blo, bhi, color=col, alpha=0.12,
                            linewidth=0)
            ax.fill_between(c['grid'], ulo, uhi, color=col, alpha=0.08,
                            linewidth=0)
            ax.plot(c['grid'], mlog(c['bare']), color=col, lw=1.4, ls='-')
            ax.plot(c['grid'], mlog(c['upcl']), color=col, lw=1.4, ls='--')
            _spines(ax)
            ax.set_xlim(0, c['grid'][-1])
            ax.tick_params(labelsize=5.5)
            xt, xtl = _k_fmt(c['grid'])
            ax.set_xticks(xt)
            ax.set_xticklabels(xtl)
            if i == 0:
                ax.set_title(f'F{fid} ({cat})', fontsize=8)
            if j == 0:
                ax.set_ylabel(f'{disp} (L{lvl})', fontsize=6.5)
    # shared legend
    handles = [plt.Line2D([], [], color='#333333', lw=1.4, ls='-',
                          label='variant alone'),
               plt.Line2D([], [], color='#333333', lw=1.4, ls='--',
                          label='with UPCL')]
    fig.legend(handles=handles, loc='lower center', ncol=2,
               bbox_to_anchor=(0.5, 0.012), handlelength=1.8, frameon=False)
    out = FIG / 'conv_representative.png'
    fig.savefig(out, bbox_inches='tight')
    plt.close(fig)
    print(f'[conv-final] representative -> {out.name} '
          f'({nv} alg x {nf} fn)')
    return out


def main():
    _style()
    meta = load_host_meta()
    cache = {}
    for suite, dim in BLOCKS:
        plot_block_overlay(suite, dim, meta, cache)
    plot_representative(meta, cache)
    print('[conv-final] done ->', FIG)


if __name__ == '__main__':
    main()

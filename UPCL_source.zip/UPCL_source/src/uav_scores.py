# -*- coding: utf-8 -*-
"""Composite success rate (CSR) for the interception scenario.

The terminal condition of the scenario -- the base falls -- is met in one of
the 348 archived runs (in both of its arms, so two of the 696 arm-level
rollouts), so a binary success flag is a near-constant zero and cannot separate
one variant or one arm from another.  Saying that every run "failed" is also
the wrong reading of the simulation: a strike that removes a tenth of the
base's health pool, or that puts the ground team inside the perimeter, has made
measurable progress that the flag discards.

The outcome is therefore reported as a weighted mean of the three graded
facets the rollout already records,

    CSR = 50 (1 - hp/hp0) + 25 (n_inf_arr/n_inf) + 25 (n_pat_killed/n_pat),

in percent.  Half of the credit goes to the terminal objective, because the
base's remaining health is the only quantity the scenario scores as victory; the
two enabling conditions -- delivering the ground team inside the perimeter and
attriting the patrol that guards it -- carry a quarter each, because they are
necessary for the objective but not sufficient on their own.  A run that
destroys the base, lands the ground team and clears the patrol scores 100; the
best cell in the archive averages 32.2, so the scale is not saturated.

The weights are a stated choice, not a fitted quantity, so the ordering is
checked against alternatives in :func:`weight_sensitivity`: from equal weights
to 70/15/15 the Spearman correlation with the published ordering of the 29
hosts stays at or above 0.98 in both arms, and where the leader changes it is
only the swap of the two front-runners (bare arm under equal weights; the UPCL
arm keeps JADE first under all four weightings).

Nothing here touches the simulation or the archive: every quantity is derived
from metrics already stored in each rollout, so the 348 existing runs are
scored without being re-run.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

# damage / breach / kill; see the module docstring for why they are not equal
COMPOSITE_W = (0.50, 0.25, 0.25)

# Troop numbers and health pool of the scenario; read from the live stack when
# it is importable so the percentages cannot drift from the configuration.
HP0, N_INF, N_PAT = 1000.0, 3, 20
try:                                                    # pragma: no cover
    from uav_adversarial import _intercept_cfg
    _cfg0 = _intercept_cfg(1)
    HP0 = float(getattr(_cfg0, 'base_hp', HP0))
    N_INF = int(getattr(_cfg0, 'n_infantry', N_INF))
    N_PAT = int(getattr(_cfg0, 'n_patrol', N_PAT))
except Exception:
    pass

GRADED_KEYS = ('damage_pct', 'breach_pct', 'kill_pct', 'composite_pct')


def _ratio(v, scale):
    try:
        return 100.0 * float(v) / float(scale)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def composite(damage, breach, kill):
    """Weighted mean of the three facets, in percent (``None`` if incomplete)."""
    if None in (damage, breach, kill):
        return None
    w = COMPOSITE_W
    return w[0] * damage + w[1] * breach + w[2] * kill


def graded(metrics):
    """The four graded percentages of one rollout, or ``None`` if unreadable."""
    if not isinstance(metrics, dict):
        return None
    dmg = _ratio(HP0 - float(metrics.get('base_hp', HP0)), HP0)
    brc = _ratio(metrics.get('n_inf_arrived', 0), N_INF)
    kil = _ratio(metrics.get('n_patrol_killed', 0), N_PAT)
    csr = composite(dmg, brc, kil)
    if csr is None:
        return None
    return {'damage_pct': dmg, 'breach_pct': brc, 'kill_pct': kil,
            'composite_pct': csr}


def inject(cells):
    """Attach the graded percentages to every rollout of every cell.

    They are written into the same ``metrics`` mapping the raw rollout uses, so
    they travel with the metric panel: the per-cell tables, the value ranking,
    the robustness runs and the variance decomposition all pick them up without
    a special case.
    """
    for cell in (cells.values() if isinstance(cells, dict) else cells):
        for run in cell.get('runs', ()):
            for arm in ('bare', 'full'):
                rec = run.get(arm)
                if not isinstance(rec, dict):
                    continue
                g = graded(rec.get('metrics'))
                if g:
                    rec['metrics'].update(g)
    return cells


def weight_sensitivity(values, groupings=((0.50, 0.25, 0.25),
                                          (1 / 3, 1 / 3, 1 / 3),
                                          (0.60, 0.20, 0.20),
                                          (0.70, 0.15, 0.15))):
    """Spearman correlation between the published ordering and alternatives.

    `values` is a list of (key, damage, breach, kill); the returned list holds
    (weights, rho, p) with the published weighting first.  Used by the paper to
    show the ordering is not an artefact of the weights.
    """
    from scipy import stats as _stats

    def rank(w):
        score = {}
        for key, d, b, k in values:
            score[key] = w[0] * d + w[1] * b + w[2] * k
        order = sorted(score, key=lambda x: -score[x])
        return {key: i for i, key in enumerate(order)}

    base = rank(groupings[0])
    out = []
    for w in groupings:
        r = rank(w)
        keys = list(base)
        rho = _stats.spearmanr([base[k] for k in keys], [r[k] for k in keys])
        out.append((w, float(rho[0]), float(rho[1])))
    return out

# -*- coding: utf-8 -*-
"""Schematic figures for the UPCL manuscript (Sections 1 and 3).

Four concept figures, drawn at the manuscript text-column width (6.3 in) and
300 dpi, so they sit next to the result figures without restyling:

  * fig_schematic_motivation.png   Fig. 1  why a candidate-stage layer exists
  * fig_schematic_framework.png    Fig. 2  UPCL as a measurement instrument
  * fig_schematic_descriptors.png  Fig. 3  the five descriptor components
  * fig_schematic_protocol.png     Fig. 4  the paired protocol and its readings

The visual style follows the card-with-coloured-header convention: each
subpanel is a rounded rectangle with a saturated header bar (title in white)
and a pastel body fill.  No experimental value is shown; every box and arrow
is drawn from the definitions in Section 3 of the manuscript.

Run from the repo root::

    python src/plot_upcl_schematics.py
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'results' / 'cec' / 'figures'

FIG_W = 6.3

# ---- five-card pastel palette --------------------------------------------
# Each concept has a saturated header colour and a matching pastel body
# fill, plus a darker text colour used for the in-card annotations that
# belong to that concept.  INK is reserved for structural text outside the
# cards (the figure-level title and caption-like notes).
INK    = '#1a1a1a'
SOFT   = '#4a4a4a'
FAINT  = '#8a8a8a'
HAIR   = '#cccccc'
PAPER  = '#ffffff'

# Card 1 -- blue (convergence / baseline / mechanism)
C1_HEAD = '#3D6CB0';  C1_BODY = '#E5EEF8';  C1_INK = '#1F3F73'
# Card 2 -- amber / yellow (measurement, characterisation)
C2_HEAD = '#B58A1E';  C2_BODY = '#FBF1D6';  C2_INK = '#7A5710'
# Card 3 -- rose / pink (intervention / decision)
C3_HEAD = '#B84A3E';  C3_BODY = '#FAE3DE';  C3_INK = '#7A2D24'
# Card 4 -- green (balance / protocol)
C4_HEAD = '#3F8155';  C4_BODY = '#E0EFE4';  C4_INK = '#245633'
# Card 5 -- purple (memory / response)
C5_HEAD = '#6E4A9A';  C5_BODY = '#ECE4F2';  C5_INK = '#3F2A60'
# Neutral grey (population, evaluation, misc.)
NG_HEAD = '#5A5A5A';  NG_BODY = '#F2F2F2';  NG_INK = '#2A2A2A'

# a small lookup by short name
PALETTE = {
    'blue':   (C1_HEAD, C1_BODY, C1_INK),
    'amber':  (C2_HEAD, C2_BODY, C2_INK),
    'rose':   (C3_HEAD, C3_BODY, C3_INK),
    'green':  (C4_HEAD, C4_BODY, C4_INK),
    'purple': (C5_HEAD, C5_BODY, C5_INK),
    'grey':   (NG_HEAD, NG_BODY, NG_INK),
}

LW_HAIR     = 0.6
LW_BOX      = 0.8
LW_BOX_BD   = 1.2
LW_ARROW    = 0.8
LW_ARROW_BD = 1.1
MS_ARROW    = 9


def _style():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans',
        'font.size': 8,
        'axes.titlesize': 8,
        'axes.titleweight': 'bold',
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'mathtext.fontset': 'dejavusans',
        'mathtext.default': 'regular',
        'lines.solid_capstyle': 'round',
        'lines.solid_joinstyle': 'round',
        'patch.linewidth': 0.8,
    })


# ===========================================================================
# primitives
# ===========================================================================
def _box(ax, x, y, w, h, *, fc=PAPER, ec=INK, lw=LW_BOX, rad=0.010, z=3):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle=f'round,pad=0,rounding_size={rad}',
        facecolor=fc, edgecolor=ec, linewidth=lw, zorder=z))


def _text(ax, x, y, s, *, fs=8, color=INK, ha='center', va='center',
          bold=False, italic=False, ls=1.20, z=4):
    ax.text(x, y, s, ha=ha, va=va, fontsize=fs, color=color, zorder=z,
            linespacing=ls, fontweight='bold' if bold else 'normal',
            fontstyle='italic' if italic else 'normal')


def _arrow(ax, p0, p1, *, color=INK, lw=LW_ARROW, ms=MS_ARROW, ls='-',
           rad=0.0, z=2):
    ax.add_patch(FancyArrowPatch(
        p0, p1, arrowstyle='-|>', mutation_scale=ms, linewidth=lw,
        color=color, linestyle=ls, zorder=z, shrinkA=0, shrinkB=0,
        connectionstyle=f'arc3,rad={rad}'))


def _hairline(ax, x0, y0, x1, y1, *, color=HAIR, lw=LW_HAIR, ls='-'):
    ax.add_line(Line2D([x0, x1], [y0, y1], color=color, lw=lw, ls=ls, zorder=1))


def _save(fig, name):
    fig.savefig(FIG / name, dpi=300, bbox_inches='tight',
                facecolor='white', pad_inches=0.04)
    plt.close(fig)
    print('[schematic]', name, '->', FIG / name)


# ---- card with coloured header bar --------------------------------------
def _card(ax, x, y, w, h, *, palette='blue', title='', subtitle='',
          header_h=0.072, body_pad=0.014, rad=0.014, lw=0.8, z=2):
    """Draw a rounded card with a coloured header bar and pastel body.

    Returns (body_x, body_y, body_w, body_h) for downstream placement.
    """
    head, body, ink = PALETTE[palette]
    # full card body (light fill, dark border)
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle=f'round,pad=0,rounding_size={rad}',
        facecolor=body, edgecolor=head, linewidth=lw, zorder=z))
    # header strip -- same dark colour, same rounding, sits ON TOP of the
    # body fill (z+0.3) but below the subsequent text (z+1).
    head_h = max(0.040, header_h) if title or subtitle else 0.0
    if head_h > 0:
        ax.add_patch(FancyBboxPatch(
            (x, y + h - head_h), w, head_h,
            boxstyle=f'round,pad=0,rounding_size={rad}',
            facecolor=head, edgecolor='none', linewidth=0,
            zorder=z + 0.3, clip_on=True))
        if title:
            _text(ax, x + 0.012, y + h - head_h / 2, title,
                  fs=8.6, color='#ffffff', ha='left', va='center',
                  bold=True, z=z + 1)
        if subtitle:
            _text(ax, x + w - 0.012, y + h - head_h / 2, subtitle,
                  fs=6.6, color='#ffffff', ha='right', va='center',
                  italic=True, z=z + 1)
    return (x + body_pad, y + body_pad,
            w - 2 * body_pad, h - head_h - 2 * body_pad)


# ===========================================================================
# Fig. 1 -- motivation: two placement decisions, side-by-side cards
# ===========================================================================
def fig_motivation():
    fig, ax = plt.subplots(figsize=(FIG_W, 3.6))
    fig.subplots_adjust(left=0.005, right=0.995, top=0.985, bottom=0.015)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    # ---- card (a) : mechanism-level optimisation -----------------------
    bx, by, bw, bh = 0.020, 0.260, 0.470, 0.715
    cax, cay, caw, cah = _card(ax, bx, by, bw, bh,
                               palette='blue',
                               title='Mechanism-level editing',
                               subtitle='',
                               header_h=0.060)
    _text(ax, cax + caw / 2, cay + cah - 0.020,
          'every scheme edits one component of the variant itself',
          fs=6.4, color=SOFT, italic=True, ha='center', va='top')

    # DE loop inside the card
    y_loop = 0.385
    seg = (('population',  0.060),
           ('mutation',    0.052),
           ('crossover',   0.058),
           ('evaluation',  0.060),
           ('select',      0.046))
    gap = 0.012
    total = sum(w for _, w in seg) + gap * (len(seg) - 1)
    x = cax + (caw - total) / 2
    centres_a = []
    for label, w in seg:
        _box(ax, x, y_loop, w, 0.075, fc=PAPER, ec=INK, lw=LW_BOX, rad=0.008)
        _text(ax, x + w / 2, y_loop + 0.0375, label, fs=6.4, color=INK)
        centres_a.append((x, x + w))
        x += w + gap
    for (xa0, xa1), (xb0, _) in zip(centres_a[:-1], centres_a[1:]):
        _arrow(ax, (xa1 + 0.001, y_loop + 0.0375),
               (xb0 - 0.001, y_loop + 0.0375), color=INK, lw=0.7, ms=6)

    # four modifier chips above the loop, each pointing into a stage
    mods = (('mutation\nstrategy',  1),
            ('adaptive\n$F$, $CR$',  2),
            ('archive /\nmemory',    3),
            ('population\nsize',     4))
    for label, target in mods:
        cx = (centres_a[target][0] + centres_a[target][1]) / 2
        cw = 0.066
        _box(ax, cx - cw / 2, y_loop + 0.125, cw, 0.090,
             fc=PAPER, ec=C1_INK, lw=LW_BOX, rad=0.008)
        _text(ax, cx, y_loop + 0.170, label, fs=5.8, color=C1_INK)
        _arrow(ax, (cx, y_loop + 0.123), (cx, y_loop + 0.080),
               color=C1_INK, lw=0.6, ms=5)

    # take-away under the loop
    _text(ax, cax + caw / 2, 0.305,
          'a scheme must name the component it configures',
          fs=6.4, color=SOFT, italic=True, ha='center')
    _text(ax, cax + caw / 2, 0.280,
          'one family at a time',
          fs=7.0, color=C1_INK, bold=True, ha='center')

    # ---- card (b) : candidate-stage correction (UPCL) ------------------
    bx, by, bw, bh = 0.510, 0.260, 0.470, 0.715
    cbx, cby, cbw, cbh = _card(ax, bx, by, bw, bh,
                               palette='rose',
                               title='Candidate-stage correction  (UPCL)',
                               subtitle='edit the candidate after the variant',
                               header_h=0.072)

    seg_b = (('population',  0.056),
             ('mutation',    0.046),
             ('crossover',   0.050),
             ('UPCL layer',  0.060),
             ('evaluation',  0.056),
             ('select',      0.042))
    total_b = sum(w for _, w in seg_b) + gap * (len(seg_b) - 1)
    x = cbx + (cbw - total_b) / 2
    centres_b = []
    for label, w in seg_b:
        is_layer = 'UPCL' in label
        _box(ax, x, y_loop, w, 0.075,
             fc=C3_BODY if is_layer else PAPER,
             ec=C3_INK if is_layer else INK,
             lw=LW_BOX_BD if is_layer else LW_BOX, rad=0.008)
        _text(ax, x + w / 2, y_loop + 0.0375, label, fs=6.4,
              color=C3_INK if is_layer else INK, bold=is_layer)
        centres_b.append((x, x + w))
        x += w + gap
    for (xa0, xa1), (xb0, _) in zip(centres_b[:-1], centres_b[1:]):
        _arrow(ax, (xa1 + 0.001, y_loop + 0.0375),
               (xb0 - 0.001, y_loop + 0.0375), color=INK, lw=0.7, ms=6)

    _text(ax, cbx + cbw / 2, 0.305,
          'the layer sees only  $(x_i,\\,u_i)$,  no extra evaluation',
          fs=6.4, color=SOFT, italic=True, ha='center')
    _text(ax, cbx + cbw / 2, 0.280,
          'identity when no correction is supported',
          fs=7.0, color=C3_INK, bold=True, ha='center')

    # ---- bottom strip : the one-sentence conclusion --------------------
    _box(ax, 0.020, 0.060, 0.960, 0.165, fc=TINT if False else '#fafafa',
         ec=HAIR, lw=0.6, rad=0.012)
    _text(ax, 0.500, 0.190, 'same loop, two placement decisions',
          fs=8.6, color=INK, bold=True)
    _text(ax, 0.500, 0.140,
          "a mechanism that edits the generator is bounded by the "
          "generator's interface;",
          fs=6.8, color=SOFT, italic=True)
    _text(ax, 0.500, 0.090,
          'a mechanism that edits the candidate is bounded only by the '
          'pair  $(x_i,\\,u_i)$.',
          fs=6.8, color=SOFT, italic=True)

    _save(fig, 'fig_schematic_motivation.png')


# ===========================================================================
# Fig. 2 -- framework: flow with M1/M2/M3 module cards
# ===========================================================================
def fig_framework():
    fig, ax = plt.subplots(figsize=(FIG_W, 4.2))
    fig.subplots_adjust(left=0.005, right=0.995, top=0.985, bottom=0.015)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    # main flow row -- five module cards on a horizontal axis
    y = 0.560
    bw, bh = 0.165, 0.310

    cards_top = [
        (0.018, 'population',      '$X_t$',                  'grey'),
        (0.197, 'opaque candidate', 'generator  $H$',         'blue'),
        (0.418, 'M1',              'candidate characterisation', 'amber'),
        (0.639, 'M3',              'minimal correction',     'rose'),
        (0.818, 'evaluation',      r'$f(\tilde u_i)$',        'grey'),
    ]
    centres = []
    for bx, head, sub, pal in cards_top:
        head_color, body_color, ink = PALETTE[pal]
        # box (no internal header bar -- use the small label above instead)
        _box(ax, bx, y, bw, bh, fc=body_color, ec=head_color,
             lw=LW_BOX_BD, rad=0.012)
        # label on top (above the box)
        if head.startswith('M') and len(head) <= 3:
            # module tag: white pill on the header
            _text(ax, bx + bw / 2, y + bh + 0.022, head, fs=8.2, color=ink,
                  bold=True, ha='center', va='bottom')
        else:
            _text(ax, bx + bw / 2, y + bh + 0.022, head, fs=7.4, color=ink,
                  bold=True, ha='center', va='bottom')
        # body content -- the formula / expression
        if 'opaque' in head:
            _text(ax, bx + bw / 2, y + bh / 2 + 0.030,
                  r'generator  $H$', fs=6.8, color=ink, bold=True)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.020,
                  r'$u_i = H(x_i,\,S_t)$', fs=7.0, color=ink)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.060,
                  'one candidate per target', fs=6.0, color=SOFT, italic=True)
        elif head == 'M1':
            _text(ax, bx + bw / 2, y + bh / 2 + 0.030,
                  'characterisation', fs=6.8, color=ink, bold=True)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.020,
                  r'$z_i = [\ell,\theta,\eta,\kappa,\nu]^{\top}$',
                  fs=6.6, color=ink)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.060,
                  'five dimensionless features', fs=6.0, color=SOFT,
                  italic=True)
        elif head == 'M3':
            _text(ax, bx + bw / 2, y + bh / 2 + 0.030,
                  'correction', fs=6.8, color=ink, bold=True)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.020,
                  r'$a^{\star} = \arg\max_a Q$', fs=7.0, color=ink)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.060,
                  'identity when no evidence', fs=6.0, color=SOFT,
                  italic=True)
        elif head == 'population':
            _text(ax, bx + bw / 2, y + bh / 2 + 0.020,
                  r'$X_t$', fs=8.0, color=ink, bold=True)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.040,
                  'current\npopulation', fs=6.0, color=SOFT, italic=True)
        elif head == 'evaluation':
            _text(ax, bx + bw / 2, y + bh / 2 + 0.020,
                  r'$f(\tilde u_i)$', fs=7.6, color=ink, bold=True)
            _text(ax, bx + bw / 2, y + bh / 2 - 0.040,
                  'one per target', fs=6.0, color=SOFT, italic=True)
        centres.append(bx + bw / 2)

    # arrows between cards on the flow row
    for a, b in zip(centres[:-1], centres[1:]):
        _arrow(ax, (a + bw / 2 + 0.004, y + bh / 2),
               (b - bw / 2 - 0.004, y + bh / 2), color=INK,
               lw=LW_ARROW_BD, ms=11)
    # arrow labels
    _text(ax, (centres[1] + centres[2]) / 2, y + bh + 0.060, r'$d_i$',
          fs=7.6, color=SOFT, italic=True)
    _text(ax, (centres[3] + centres[4]) / 2, y + bh + 0.060,
          r'$\tilde u_i$', fs=7.6, color=SOFT, italic=True)

    # ---- M2 memory card below the spine --------------------------------
    mx, my, mw, mh = 0.418, 0.165, 0.386, 0.230
    head_color, body_color, ink = PALETTE['purple']
    _box(ax, mx, my, mw, mh, fc=body_color, ec=head_color,
         lw=LW_BOX_BD, rad=0.012)
    _text(ax, mx + mw / 2, my + mh + 0.020, 'M2', fs=8.2, color=ink,
          bold=True, ha='center', va='bottom')
    _text(ax, mx + mw / 2, my + mh / 2 + 0.030,
          'candidate response memory', fs=7.0, color=ink, bold=True)
    _text(ax, mx + mw / 2, my + mh / 2 - 0.020,
          r'stores  $(z_i,\,a_i,\,r_i)$  ;  $M = 256$', fs=6.6, color=SOFT,
          italic=True)
    _text(ax, mx + mw / 2, my + 0.030,
          'five action sub-buffers', fs=6.6, color=SOFT, italic=True)

    # M2 <-> M1 write (curved arrow going down from M1 to M2)
    _arrow(ax, (centres[2] - 0.020, y - 0.002),
           (mx + 0.060, my + mh + 0.002),
           color=SOFT, lw=LW_ARROW, rad=0.22)
    _text(ax, mx + 0.065, my + mh + 0.024, 'write', fs=6.2, color=SOFT,
          italic=True, ha='left', va='bottom')
    # M2 -> M3 query
    _arrow(ax, (mx + mw - 0.060, my + mh + 0.002),
           (centres[3] + 0.020, y - 0.002),
           color=SOFT, lw=LW_ARROW, rad=0.22)
    _text(ax, mx + mw - 0.065, my + mh + 0.024, 'query', fs=6.2, color=SOFT,
          italic=True, ha='right', va='bottom')
    # realised response closes the loop back into M2
    _arrow(ax, (centres[4], y - 0.002), (mx + mw - 0.004, my + 0.120),
           color=SOFT, lw=LW_ARROW, rad=-0.40)
    _text(ax, 0.870, y - 0.024, 'reward  $r_i$', fs=6.4, color=SOFT,
          italic=True, ha='left', va='top')

    # ---- bottom note strip : the action set, score, reward, properties --
    nx, ny, nw, nh = 0.018, 0.020, 0.964, 0.130
    _box(ax, nx, ny, nw, nh, fc='#fafafa', ec=HAIR, lw=0.6, rad=0.010)
    _text(ax, nx + 0.012, ny + nh - 0.022, 'instrument', fs=7.6, color=INK,
          bold=True, ha='left', va='top')
    _text(ax, nx + 0.500, ny + nh - 0.022,
          r'action set  $\mathcal{A} = \{I,\,C,\,E,\,R,\,P\}$   '
          r'score  $Q(z,a) = \hat r - \lambda\,c - \kappa_u/\sqrt{1+n_{\mathrm{eff}}} + \mu_t\,\mathbb{1}[a = I]$',
          fs=6.4, color=SOFT, ha='center', va='top')
    _text(ax, nx + 0.500, ny + nh - 0.054,
          r'reward  $r_i = \tanh\!\left((f(x_i) - f(\tilde u_i))/\sigma_t\right)$,  '
          r'$\sigma_t$  population fitness scale,  '
          r'the memory is the only state carried between generations',
          fs=6.4, color=SOFT, ha='center', va='top')
    _text(ax, nx + 0.500, ny + 0.012,
          r'one evaluation per target per generation  (Property 2);  '
          r'$Q(z,a) - Q(z,I) \leq -\mu_0$ when no evidence  (Property 3);  '
          r'information set excludes $F$, $CR$, archive, strategy index  (Property 1)',
          fs=6.4, color=SOFT, ha='center', va='top', italic=True)

    _save(fig, 'fig_schematic_framework.png')


# ===========================================================================
# Fig. 3 -- five descriptor components: five cards in a row
# ===========================================================================
def fig_descriptors():
    fig, ax = plt.subplots(figsize=(FIG_W, 3.6))
    fig.subplots_adjust(left=0.005, right=0.995, top=0.985, bottom=0.015)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    # five descriptor cards + one assembler card
    cards = [
        ('step scale',  r'$\ell_i$', 'blue',
         r'$\ell_i = \frac{1}{2}\,\log_2\!\left(\|d_i\|/s_t\right)$',
         'how long is the move relative to',
         r'the current spread?  $\ell_i<0$  short,  $\ell_i>0$  long',
         'l'),
        ('alignment with success', r'$\theta_i$', 'amber',
         r'$\theta_i = \langle q_i,\,\hat s_t\rangle$',
         'does the direction agree with the',
         r'recent success direction?  $\theta_i = +1$  identical',
         't'),
        ('alignment with the elite', r'$\eta_i$', 'rose',
         r'$\eta_i = \langle q_i,\,\hat e_t\rangle$',
         'does the move point towards the',
         r'current best?  $0$ at $x_i = x_t^{\star}$',
         'e'),
        ('crowding at landing', r'$\kappa_i$', 'green',
         r'$\kappa_i = \frac{1}{2}\,\log_2\!\left(\min_j\|u_i - x_j\|/s_t\right)$',
         'does the candidate land in an',
         r'already densely occupied region?  $\kappa_i < 0$  crowded',
         'k'),
        ('directional novelty', r'$\nu_i$', 'purple',
         r'$\nu_i = 1 - \max_k |\langle q_i,\,h_k\rangle|$',
         'is the direction new against the',
         r'prototype set of recent directions?  $\nu_i \to 1$  new',
         'n'),
    ]

    n = 5
    margin = 0.012
    gap = 0.008
    total_w = 1.0 - 2 * margin
    cw = (total_w - gap * (n - 1)) / n
    y0, ch = 0.180, 0.760
    header_h = 0.064

    for k, (title, sym, pal, formula, expl1, expl2, _code) in enumerate(cards):
        bx = margin + k * (cw + gap)
        cx, cy, cwi, chi = _card(ax, bx, y0, cw, ch, palette=pal,
                                 title=title, subtitle='',
                                 header_h=header_h, body_pad=0.010,
                                 rad=0.012, lw=0.8)
        head_color, body_color, ink = PALETTE[pal]
        # top-right tag with the symbol (placed inside the header bar)
        _text(ax, bx + cw - 0.012, y0 + ch - header_h / 2 + 0.004, sym,
              fs=8.0, color='#ffffff', ha='right', va='center',
              bold=True, z=5)

        # mini illustration -- move from parent to candidate
        # parent at (0.18, 0.66), candidate at (0.82, 0.86)
        p_x, p_y = 0.18, 0.66
        # scale circle in the corner (descriptors 1, 4)
        if k == 0:
            s_c = (p_x + 0.32, p_y - 0.18)
            ax.add_patch(plt.Circle(s_c, 0.16, fill=False, ec=FAINT,
                                    lw=LW_HAIR, ls=(0, (1.6, 1.6)), zorder=2))
            _text(ax, s_c[0] + 0.18, s_c[1] - 0.16, r'$s_t$', fs=6.0,
                  color=SOFT, italic=True, ha='left', va='top')
        # prototype fan in descriptor 4
        if k == 4:
            for jj, ang in enumerate((38, 78, 118)):
                v = 0.34 * np.array([np.cos(np.radians(ang)),
                                     np.sin(np.radians(ang))])
                _arrow(ax, (p_x, p_y), (p_x + v[0], p_y + v[1]),
                       color=SOFT, lw=0.7, ms=5)
                _text(ax, p_x + v[0] * 1.18, p_y + v[1] * 1.10,
                      r'$h_{%d}$' % (jj + 1), fs=5.6, color=SOFT,
                      ha='center', va='center')
        # dashed reference for descriptors 1 (success dir) and 2 (elite)
        if k == 1:
            ref_end = (p_x + 0.46, p_y + 0.14)
            _arrow(ax, (p_x, p_y), ref_end, color=head_color, lw=0.8, ms=6,
                   ls=(0, (3, 2)))
            _text(ax, ref_end[0] + 0.02, ref_end[1] + 0.02, r'$\hat s_t$',
                  fs=6.0, color=head_color, italic=True)
        if k == 2:
            ref_end = (p_x + 0.46, p_y + 0.22)
            _arrow(ax, (p_x, p_y), ref_end, color=head_color, lw=0.8, ms=6,
                   ls=(0, (3, 2)))
            ax.plot([ref_end[0]], [ref_end[1]], marker='*', ms=10,
                    color=head_color, markeredgecolor=head_color, zorder=6)
            _text(ax, ref_end[0] - 0.02, ref_end[1] + 0.04,
                  r'$x_t^{\star}$', fs=6.0, color=head_color,
                  italic=True, ha='right', va='bottom')
        # nearest neighbour in descriptor 3
        if k == 3:
            neigh = (0.66, 0.50)
            ax.add_patch(plt.Circle(neigh, 0.020, facecolor=head_color,
                                    edgecolor=head_color, linewidth=LW_BOX,
                                    zorder=5))
            _arrow(ax, (0.66, 0.66), neigh, color=INK, lw=LW_HAIR, ms=5,
                   ls=(0, (2, 2)))
            _text(ax, neigh[0] + 0.05, neigh[1] - 0.12,
                  r'$\min_j \|u_i - x_j\|$', fs=5.6, color=SOFT,
                  ha='left', va='top')

        # parent and candidate
        ax.add_patch(plt.Circle((p_x, p_y), 0.022, facecolor=INK,
                                edgecolor=INK, linewidth=LW_BOX, zorder=5))
        c_x, c_y = 0.82, 0.88
        ax.add_patch(plt.Circle((c_x, c_y), 0.022, facecolor=PAPER,
                                edgecolor=head_color, linewidth=LW_BOX_BD,
                                zorder=5))
        _arrow(ax, (p_x, p_y), (c_x, c_y), color=head_color,
               lw=LW_ARROW_BD, ms=8)
        # the move label d_i
        _text(ax, 0.52, 0.84, r'$d_i$', fs=6.6, color=head_color, ha='center')

        # formula in body
        _text(ax, cx + cwi / 2, cy + chi - 0.080, formula, fs=6.2,
              color=ink, ha='center', va='top')
        # explanation lines
        _text(ax, cx + 0.012, cy + chi - 0.142, expl1, fs=6.0, color=SOFT,
              ha='left', va='top', italic=True)
        _text(ax, cx + 0.012, cy + chi - 0.180, expl2, fs=6.0, color=SOFT,
              ha='left', va='top', italic=True)

    # ---- bottom note -----------------------------------------------------
    _box(ax, 0.020, 0.060, 0.960, 0.110, fc='#fafafa', ec=HAIR, lw=0.6,
         rad=0.010)
    _text(ax, 0.500, 0.140,
          r'$z_i = [\ell_i,\,\theta_i,\,\eta_i,\,\kappa_i,\,\nu_i]^{\top}'
          r' \in \mathbb{R}^{5}$  --  one code, five dimensionless '
          r'variant-agnostic questions',
          fs=7.0, color=INK, bold=True, ha='center', va='center')
    _text(ax, 0.500, 0.085,
          'no component refers to  $F$, $CR$,  the archive or the strategy '
          'index;  the same reading applies to every variant',
          fs=6.2, color=SOFT, italic=True, ha='center', va='center')

    _save(fig, 'fig_schematic_descriptors.png')


# ===========================================================================
# Fig. 4 -- the paired protocol
# ===========================================================================
def fig_protocol():
    fig, ax = plt.subplots(figsize=(FIG_W, 3.2))
    fig.subplots_adjust(left=0.005, right=0.995, top=0.985, bottom=0.015)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    # ---- card (a) : paired protocol ------------------------------------
    bx, by, bw, bh = 0.018, 0.190, 0.310, 0.780
    cax, cay, caw, cah = _card(ax, bx, by, bw, bh,
                               palette='blue',
                               title='Paired protocol',
                               subtitle='same seed / budget / problem',
                               header_h=0.060)
    head_color, body_color, ink = PALETTE['blue']
    # two horizontal arms
    arms = (('variant alone  $H$',         0.760, 'grey'),
            ('variant  +  UPCL  $CH$',     0.620, 'rose'))
    for label, y_arm, pal in arms:
        h_c, b_c, i_c = PALETTE[pal]
        _box(ax, cax + 0.020, y_arm, caw - 0.040, 0.085, fc=b_c, ec=h_c,
             lw=LW_BOX, rad=0.008)
        _text(ax, cax + 0.030, y_arm + 0.0425, label, fs=6.6, color=i_c,
              ha='left', va='center', bold=True)
        # N evaluation ticks
        for k in range(6):
            xx = cax + 0.115 + k * 0.024
            ax.plot([xx, xx], [y_arm + 0.018, y_arm + 0.067], color=i_c,
                    lw=0.7, alpha=0.55, zorder=4)
    _text(ax, cax + caw / 2, 0.555,
          r'one generation,  $N$  evaluations per arm',
          fs=6.0, color=SOFT, italic=True, ha='center')
    _text(ax, cax + caw / 2, 0.520,
          'identical except for the layer',
          fs=6.0, color=SOFT, italic=True, ha='center')
    # paired-difference definition
    _text(ax, cax + caw / 2, 0.430,
          r'$\Delta = \log_{10}\mathrm{err}(H) - '
          r'\log_{10}\mathrm{err}(CH)$',
          fs=7.4, color=ink, ha='center', bold=True)
    _text(ax, cax + caw / 2, 0.380,
          r'$\Delta > 0$  means the layer helped',
          fs=6.0, color=SOFT, italic=True, ha='center')

    # ---- card (b) : three readings -------------------------------------
    bx, by, bw, bh = 0.345, 0.190, 0.310, 0.780
    cbx, cby, cbw, cbh = _card(ax, bx, by, bw, bh,
                               palette='amber',
                               title='Three readings',
                               subtitle='per variant, per run',
                               header_h=0.060)
    head_color, body_color, ink = PALETTE['amber']
    cards_b = [
        (0.730, r'intervention rate  $\bar\rho$',
         [r'share of candidates with  $a_i \ne I$',
          'exploration draws excluded',
          'the improvable slack the',
          'variant leaves']),
        (0.510, r'intervention gain  $\Delta$',
         ['paired final-error difference',
          'between wrapped and bare arms',
          'how much that slack is worth',
          'once recovered']),
        (0.290, r'descriptor contrast',
         [r'$\mathbb{E}[z \mid a \ne I] - \mathbb{E}[z \mid a = I]$',
          '',
          'which geometry the layer',
          'finds improvable']),
    ]
    for y, title, lines in cards_b:
        _box(ax, cbx + 0.012, y, cbw - 0.024, 0.180, fc=PAPER, ec=head_color,
             lw=LW_HAIR, rad=0.008)
        ax.add_patch(plt.Rectangle((cbx + 0.012, y + 0.012), 0.005, 0.156,
                                   facecolor=head_color, edgecolor='none',
                                   zorder=4))
        _text(ax, cbx + 0.024, y + 0.165, title, fs=6.8, color=head_color,
              ha='left', va='center', bold=True)
        for k, line in enumerate(lines):
            _text(ax, cbx + 0.024, y + 0.120 - k * 0.025, line, fs=5.8,
                  color=SOFT, ha='left', va='top', ls=1.40)

    # ---- card (c) : mechanism fingerprint (template) ------------------
    bx, by, bw, bh = 0.672, 0.190, 0.310, 0.780
    ccx, ccy, ccw, cch = _card(ax, bx, by, bw, bh,
                               palette='green',
                               title='Mechanism fingerprint',
                               subtitle='one row per variant',
                               header_h=0.060)
    head_color, body_color, ink = PALETTE['green']
    x0, w_, rh = ccx + 0.018, ccw - 0.036, 0.130
    y0 = ccy + 0.030
    cols = ((r'$\bar\rho$', head_color),
            ('gain', C1_INK),  # borrow blue for the gain column
            (r'$\Delta z$', C3_INK))  # borrow rose for descriptor change
    for k, (h, col) in enumerate(cols):
        _text(ax, x0 + 0.058 + k * 0.078, y0 + 3 * rh + 0.030, h, fs=6.4,
              color=col, ha='center', va='center', bold=True)
    for r in range(3):
        yy = y0 + (2 - r) * rh
        _box(ax, x0, yy, w_, rh - 0.012, fc=PAPER, ec=HAIR, lw=LW_HAIR,
             rad=0.006)
        ax.add_patch(plt.Rectangle((x0 + 0.005, yy + 0.010), 0.010,
                                   rh - 0.034, facecolor=head_color,
                                   edgecolor='none', zorder=4))
        for k in range(3):
            _box(ax, x0 + 0.025 + k * 0.076, yy + 0.014, 0.066,
                 rh - 0.042, fc='#f1f1f1', ec=HAIR, lw=LW_HAIR, rad=0.005)
    _text(ax, ccx + ccw / 2, ccy - 0.012,
          'placeholder cells: this panel fixes the layout, not any value',
          fs=5.8, color=SOFT, italic=True, ha='center', va='top')
    _text(ax, ccx + ccw / 2, ccy - 0.030,
          'measured fingerprints are reported in Section 4.4',
          fs=5.8, color=SOFT, italic=True, ha='center', va='top')

    # ---- bottom strip ---------------------------------------------------
    _box(ax, 0.018, 0.060, 0.964, 0.115, fc='#fafafa', ec=HAIR, lw=0.6,
         rad=0.010)
    _text(ax, 0.500, 0.135,
          'the three readings together form a variant\'s mechanism fingerprint',
          fs=7.2, color=INK, bold=True, ha='center', va='center')
    _text(ax, 0.500, 0.080,
          'one row per variant, comparable across the twenty-nine registered '
          'DE variants and across the two suites',
          fs=6.2, color=SOFT, italic=True, ha='center', va='center')

    _save(fig, 'fig_schematic_protocol.png')


if __name__ == '__main__':
    _style()
    fig_motivation()
    fig_framework()
    fig_descriptors()
    fig_protocol()

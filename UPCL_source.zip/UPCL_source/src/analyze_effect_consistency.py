# -*- coding: utf-8 -*-
"""Direction consistency, effect size and aggregated significance of UPCL.

Reads the bare-vs-UPCL grid under ``results/grid/raw`` only (never the
``results/cec`` tree, so the ablation data stays untouched) and answers three
questions per (suite, dimension) block:

1. **Direction / reverse consistency**
   - a *win* is a cell where UPCL is better (positive ``dec``) *and* the
     Holm-adjusted paired Wilcoxon rejects; a *loss* is the symmetric case;
     everything else is a tie.
   - forward consistency  = wins dominate losses (exact binomial test);
   - reverse consistency  = losses dominate wins (the layer consistently hurts).

2. **Effect size**
   - ``dec = log10(median bare err) - log10(median upcl err)``, floored at 1e-8
     (positive = UPCL removed that many decades of error).
   - distribution, quantiles and a magnitude breakdown per block and per host.

3. **Aggregated significance** (the whole block tested as one unit)
   - one-sample Wilcoxon signed-rank over the per-cell ``dec``;
   - exact sign test on the sign of ``dec``;
   - Stouffer's Z (directional combination of the per-cell Wilcoxon p-values);
   - Fisher's method (combination of two-sided p-values);
   - exact binomial test on win/(win+loss).

Only cells with ``>= min-runs`` completed runs are used; the default is 30,
i.e. finished cells only.  Run with ``--min-runs 1`` to include everything.

    python src/analyze_effect_consistency.py
"""
import argparse
import csv
import sys
import warnings
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import analyze_upcl_grid as AG          # reuse load_cell / reference logic

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'grid'
TAB = OUT / 'tables'
FIG = OUT / 'figures'
FLOOR = 1e-8
ALPHA = 0.05

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False


# --------------------------------------------------------------------------
# loading (grid tree only)
# --------------------------------------------------------------------------
def load_grid_cells():
    cells = {}
    base = OUT / 'raw'
    for p in sorted(base.glob('*/*/*.json')):
        c = AG.load_cell(p)
        if c is None:
            continue
        key = (c['suite'], c['dim'], c['host'], c['fid'])
        cells[key] = c
    return cells


# --------------------------------------------------------------------------
# statistics
# --------------------------------------------------------------------------
def paired_wilcoxon(b, u):
    """Two-sided paired Wilcoxon p-value; 1.0 when nothing differs."""
    from scipy.stats import wilcoxon
    b, u = np.asarray(b, float), np.asarray(u, float)
    d = u - b
    d = d[~np.isnan(d)]
    if len(d) == 0 or np.allclose(d, 0.0):
        return 1.0
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        try:
            return float(wilcoxon(d, alternative='two-sided',
                                  zero_method='wilcox').pvalue)
        except Exception:
            return 1.0


def holm(pvals, alpha=ALPHA):
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    rej = np.zeros(m, dtype=bool)
    for k, idx in enumerate(order):
        if p[idx] <= alpha / (m - k):
            rej[idx] = True
        else:
            break
    return rej


def binom_two_sided(k, n):
    """Two-sided exact binomial test of H0: p = 0.5."""
    from scipy.stats import binomtest
    if n == 0:
        return float('nan')
    return float(binomtest(k, n, 0.5).pvalue)


def binom_upper(k, n):
    """One-sided exact binomial test of H0: p = 0.5 vs p > 0.5."""
    from scipy.stats import binomtest
    if n == 0:
        return float('nan')
    return float(binomtest(k, n, 0.5, alternative='greater').pvalue)


def stouffer(pvals, signs):
    """Directional Stouffer Z: combine two-sided p with the sign of the effect."""
    from scipy.stats import norm
    p = np.asarray(pvals, float)
    s = np.asarray(signs, float)
    p = np.clip(p, 1e-300, 1.0)
    z = norm.ppf(1.0 - p / 2.0) * np.sign(s)
    z = z[~np.isnan(z)]
    if len(z) == 0:
        return float('nan'), float('nan')
    Z = z.sum() / np.sqrt(len(z))
    return float(Z), float(2 * norm.sf(abs(Z)))


def fisher(pvals):
    """Fisher's combination of two-sided p-values."""
    from scipy.stats import chi2
    p = np.asarray(pvals, float)
    p = p[~np.isnan(p)]
    if len(p) == 0:
        return float('nan'), float('nan')
    stat = -2.0 * np.sum(np.log(np.clip(p, 1e-300, 1.0)))
    return float(stat), float(chi2.sf(stat, 2 * len(p)))


def one_sample_wilcoxon(dec):
    """One-sample Wilcoxon signed-rank of the per-cell effect sizes vs 0."""
    from scipy.stats import wilcoxon
    x = np.asarray(dec, float)
    x = x[~np.isnan(x)]
    if len(x) == 0:
        return float('nan')
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        try:
            return float(wilcoxon(x, alternative='two-sided',
                                  zero_method='wilcox').pvalue)
        except Exception:
            return float('nan')


# --------------------------------------------------------------------------
# per-cell table
# --------------------------------------------------------------------------
def build_rows(cells, min_runs):
    rows = []
    for key, c in sorted(cells.items()):
        if c['n'] < min_runs:
            continue
        b = np.asarray(c['bare_final'], float)
        u = np.asarray(c['upcl_final'], float)
        n = min(len(b), len(u))
        if n == 0:
            continue
        b, u = b[:n], u[:n]
        bm = float(np.median(b))
        um = float(np.median(u))
        dec = float(np.log10(max(bm, FLOOR)) - np.log10(max(um, FLOOR)))
        rows.append(dict(
            suite=c['suite'], dim=c['dim'], host=c['host'], fid=c['fid'],
            func=c['func'], category=c['category'], n=n,
            bare_med=bm, upcl_med=um, dec=dec, p=paired_wilcoxon(b, u),
        ))
    # Holm within each (suite, dim) block
    for block in {(r['suite'], r['dim']) for r in rows}:
        idx = [i for i, r in enumerate(rows)
               if (r['suite'], r['dim']) == block]
        rej = holm([rows[i]['p'] for i in idx])
        for i, rg in zip(idx, rej):
            rows[i]['holm_reject'] = bool(rg)
            rows[i]['verdict'] = (
                'win' if rg and rows[i]['dec'] > 0 else
                'loss' if rg and rows[i]['dec'] < 0 else 'tie')
    return rows


def magnitude(dec):
    if dec > 1.0:
        return 'large'
    if dec > 0.3:
        return 'medium'
    if dec > 0.05:
        return 'small'
    if dec >= -0.05:
        return 'none'
    return 'negative'


# --------------------------------------------------------------------------
# outputs
# --------------------------------------------------------------------------
def write_cells(rows):
    TAB.mkdir(parents=True, exist_ok=True)
    path = TAB / 'effect_cells.csv'
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=[
            'suite', 'dim', 'host', 'fid', 'func', 'category', 'n',
            'bare_med', 'upcl_med', 'dec', 'p', 'holm_reject', 'verdict'])
        w.writeheader()
        w.writerows(rows)
    print(f'[effect] cells -> {path.name} ({len(rows)} cells)')


def block_tables(rows):
    TAB.mkdir(parents=True, exist_ok=True)
    blocks = sorted({(r['suite'], r['dim']) for r in rows})
    for block in blocks:
        rs = [r for r in rows if (r['suite'], r['dim']) == block]
        wins = sum(1 for r in rs if r['verdict'] == 'win')
        losses = sum(1 for r in rs if r['verdict'] == 'loss')
        ties = sum(1 for r in rs if r['verdict'] == 'tie')
        decs = np.array([r['dec'] for r in rs], float)
        # direction (sign) of the median effect, independent of significance
        n_pos = int(np.sum(decs > 0.05))
        n_neg = int(np.sum(decs < -0.05))
        n_none = int(len(decs) - n_pos - n_neg)

        # aggregated significance
        w_agg = one_sample_wilcoxon(decs)
        sign_p = binom_two_sided(n_pos, n_pos + n_neg)
        sign_up = binom_upper(n_pos, n_pos + n_neg)
        Z, z_p = stouffer([r['p'] for r in rs], [r['dec'] for r in rs])
        f_stat, f_p = fisher([r['p'] for r in rs])
        wl = wins + losses
        b2 = binom_two_sided(wins, wl) if wl else float('nan')
        b1 = binom_upper(wins, wl) if wl else float('nan')

        suite, dim = block
        yield dict(
            suite=suite, dim=dim, cells=len(rs),
            wins=wins, ties=ties, losses=losses,
            win_rate=round(wins / max(wl, 1), 4) if wl else float('nan'),
            dec_mean=round(float(decs.mean()), 4),
            dec_median=round(float(np.median(decs)), 4),
            dec_std=round(float(decs.std()), 4),
            dec_min=round(float(decs.min()), 4),
            dec_max=round(float(decs.max()), 4),
            n_pos=n_pos, n_neg=n_neg, n_none=n_none,
            wilcoxon_1sample_p=('%.3g' % w_agg),
            sign_test_p=('%.3g' % sign_p),
            sign_test_up_p=('%.3g' % sign_up),
            stouffer_Z=round(Z, 3), stouffer_p=('%.3g' % z_p),
            fisher_p=('%.3g' % f_p),
            binom_wl_p=('%.3g' % b2), binom_wl_up_p=('%.3g' % b1),
        )


def write_block_table(rows):
    TAB.mkdir(parents=True, exist_ok=True)
    out = list(block_tables(rows))
    path = TAB / 'effect_blocks.csv'
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    print(f'[effect] blocks -> {path.name}')
    return out


def per_host_table(rows):
    TAB.mkdir(parents=True, exist_ok=True)
    out = []
    for (suite, dim, host) in sorted({(r['suite'], r['dim'], r['host'])
                                      for r in rows}):
        rs = [r for r in rows
              if (r['suite'], r['dim'], r['host']) == (suite, dim, host)]
        decs = np.array([r['dec'] for r in rs], float)
        out.append(dict(
            suite=suite, dim=dim, host=host, cells=len(rs),
            wins=sum(1 for r in rs if r['verdict'] == 'win'),
            ties=sum(1 for r in rs if r['verdict'] == 'tie'),
            losses=sum(1 for r in rs if r['verdict'] == 'loss'),
            dec_mean=round(float(decs.mean()), 4),
            dec_median=round(float(np.median(decs)), 4),
            n_pos=int(np.sum(decs > 0.05)),
            n_neg=int(np.sum(decs < -0.05)),
        ))
    path = TAB / 'effect_per_host.csv'
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    print(f'[effect] per-host -> {path.name}')
    return out


def magnitude_table(rows):
    TAB.mkdir(parents=True, exist_ok=True)
    out = []
    for (suite, dim) in sorted({(r['suite'], r['dim']) for r in rows}):
        rs = [r for r in rows if (r['suite'], r['dim']) == (suite, dim)]
        cnt = defaultdict(int)
        for r in rs:
            cnt[magnitude(r['dec'])] += 1
        out.append(dict(
            suite=suite, dim=dim, cells=len(rs),
            large=cnt['large'], medium=cnt['medium'], small=cnt['small'],
            none=cnt['none'], negative=cnt['negative'],
        ))
    path = TAB / 'effect_magnitude.csv'
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    print(f'[effect] magnitude -> {path.name}')
    return out


def effect_histogram(rows):
    if not HAVE_MPL:
        return
    FIG.mkdir(parents=True, exist_ok=True)
    for (suite, dim) in sorted({(r['suite'], r['dim']) for r in rows}):
        rs = [r for r in rows if (r['suite'], r['dim']) == (suite, dim)]
        decs = np.array([r['dec'] for r in rs], float)
        fig, ax = plt.subplots(figsize=(6.5, 3.6))
        ax.hist(decs, bins=40, color='#8faadc', edgecolor='#1f4e79', lw=0.4)
        ax.axvline(0.0, color='0.4', lw=0.8)
        ax.axvline(float(np.median(decs)), color='#c0504d', lw=1.2,
                   ls='--', label=f"median = {np.median(decs):+.3f}")
        ax.set_xlabel('effect size (decades of error removed, positive = UPCL better)')
        ax.set_ylabel('cells')
        ax.set_title(f'{suite} D={dim}: distribution of UPCL effect size '
                     f'(n={len(decs)} cells)')
        ax.legend()
        ax.grid(alpha=0.25, lw=0.4)
        fig.tight_layout()
        fig.savefig(FIG / f'effect_hist_{suite}_D{dim}.png')
        plt.close(fig)
        print(f'[effect] histogram -> {FIG.name}/effect_hist_{suite}_D{dim}.png')


# --------------------------------------------------------------------------
# console
# --------------------------------------------------------------------------
def console(rows, blocks):
    print()
    for b in blocks:
        print(f"=== {b['suite']} D={b['dim']}  (cells={b['cells']}) ===")
        print(f"  W/T/L            : {b['wins']}/{b['ties']}/{b['losses']}  "
              f"win_rate={b['win_rate']}")
        print(f"  direction (sign) : +{b['n_pos']} / 0:{b['n_none']} / -{b['n_neg']}"
              f"   (dec>0.05 / |dec|<=0.05 / dec<-0.05)")
        print(f"  effect size      : mean {b['dec_mean']:+.3f}  "
              f"median {b['dec_median']:+.3f}  "
              f"[{b['dec_min']:+.3f}, {b['dec_max']:+.3f}]")
        print(f"  --- aggregated significance ---")
        print(f"  one-sample Wilcoxon p = {b['wilcoxon_1sample_p']}")
        print(f"  sign test p           = {b['sign_test_p']} "
              f"(one-sided up p = {b['sign_test_up_p']})")
        print(f"  Stouffer Z            = {b['stouffer_Z']:+.3f}  p = {b['stouffer_p']}")
        print(f"  Fisher p              = {b['fisher_p']}")
        print(f"  binomial win/(w+l)    = {b['binom_wl_p']} "
              f"(one-sided up p = {b['binom_wl_up_p']})")
        print()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--min-runs', type=int, default=30,
                    help='a cell counts only once it has this many runs')
    ap.add_argument('--suite', default=None)
    ap.add_argument('--dim', type=int, default=None)
    a = ap.parse_args(argv)

    loaded = load_grid_cells()
    ref = AG.reference_values(loaded)
    AG.apply_reference(loaded, ref)

    cells = {k: c for k, c in loaded.items()
             if c['n'] >= a.min_runs
             and (a.suite is None or c['suite'] == a.suite)
             and (a.dim is None or c['dim'] == a.dim)}
    if not cells:
        print(f'[effect] no cell has {a.min_runs} runs')
        return
    print(f'[effect] using {len(cells)} complete cells '
          f'(min-runs={a.min_runs}); '
          f'{len(loaded) - len(cells)} still filling (excluded)')

    rows = build_rows(cells, a.min_runs)
    write_cells(rows)
    blocks = write_block_table(rows)
    per_host_table(rows)
    magnitude_table(rows)
    effect_histogram(rows)
    console(rows, blocks)


if __name__ == '__main__':
    main()

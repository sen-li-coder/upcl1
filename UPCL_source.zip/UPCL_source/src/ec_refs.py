# -*- coding: utf-8 -*-
"""Reference pool of the shared EC bibliography.

Keys are cited as [@KEY] in the body text and numbered automatically in order of
first appearance.  Records are stored in GB/T 7714 field order, whose type
marker (``[J]``, ``[C]``, ``[M]``, ``[R]``, ``[EB/OL]``, ``[J/OL]``) keeps them
unambiguous; `refs_style` prints them in the submitted layout.
"""

REFS = {
    # ---- canonical DE and surveys ----
    'DE97': 'STORN R, PRICE K. Differential evolution—a simple and efficient '
            'heuristic for global optimization over continuous spaces[J]. '
            'Journal of Global Optimization, 1997, 11(4): 341-359.',
    'DAS_SURVEY11': 'DAS S, SUGANTHAN P N. Differential evolution: a survey of '
                    'the state-of-the-art[J]. IEEE Transactions on Evolutionary '
                    'Computation, 2011, 15(1): 4-31.',
    'DAS_SURVEY16': 'DAS S, MULLICK S S, SUGANTHAN P N. Recent advances in '
                    'differential evolution—an updated survey[J]. Swarm and '
                    'Evolutionary Computation, 2016, 27: 1-30.',
    'PRICE_BOOK': 'PRICE K V, STORN R M, LAMPINEN J A. Differential evolution: '
                  'a practical approach to global optimization[M]. Berlin: '
                  'Springer, 2005.',

    # ---- adaptive / self-adaptive DE ----
    'JADE': 'ZHANG J, SANDERSON A C. JADE: adaptive differential evolution with '
            'optional external archive[J]. IEEE Transactions on Evolutionary '
            'Computation, 2009, 13(5): 945-958.',
    'SHADE': 'TANABE R, FUKUNAGA A S. Success-history based parameter adaptation '
             'for differential evolution[C]//2013 IEEE Congress on Evolutionary '
             'Computation. Cancun: IEEE, 2013: 71-78.',
    'LSHADE': 'TANABE R, FUKUNAGA A S. Improving the search performance of SHADE '
              'using linear population size reduction[C]//2014 IEEE Congress on '
              'Evolutionary Computation. Beijing: IEEE, 2014: 1658-1665.',
    'JSO': 'BREST J, MAUČEC M S, BOŠKOVIĆ B. Single objective real-parameter '
           'optimization: algorithm jSO[C]//2017 IEEE Congress on Evolutionary '
           'Computation. San Sebastian: IEEE, 2017: 1311-1318.',
    'GONG_RANK': 'GONG W, CAI Z. Differential evolution with ranking-based '
                 'mutation operators[J]. IEEE Transactions on Cybernetics, 2013, '
                 '43(6): 2066-2081.',
    'SADE': 'QIN A K, HUANG V L, SUGANTHAN P N. Differential evolution algorithm '
            'with strategy adaptation for global numerical optimization[J]. IEEE '
            'Transactions on Evolutionary Computation, 2009, 13(2): 398-417.',
    'SADE05': 'QIN A K, SUGANTHAN P N. Self-adaptive differential evolution '
              'algorithm for numerical optimization[C]//2005 IEEE Congress on '
              'Evolutionary Computation. Edinburgh: IEEE, 2005: 1785-1791.',
    'SELFADAPT_DE06': 'BREST J, GREINER S, BOŠKOVIĆ B, et al. Self-adapting '
                      'control parameters in differential evolution: a '
                      'comparative study on numerical benchmark problems[J]. '
                      'IEEE Transactions on Evolutionary Computation, 2006, '
                      '10(6): 646-657.',
    'ELSAYED13': 'ELSAYED S M, SARKER R A, ESSAM D L. Differential evolution with '
                 'auto-enhanced population diversity[J]. IEEE Transactions on '
                 'Cybernetics, 2013, 43(1): 291-304.',
    'DAS_RELIABILITY': 'DAS S, ABRAHAM A, CHAKRABORTY U K. Analyzing the behavior '
                       'of classical differential evolution variants on the basis '
                       'of convergence reliability[C]//2006 IEEE Congress on '
                       'Evolutionary Computation. Vancouver: IEEE, 2006: '
                       '3184-3190.',

    # ---- ensembles, hybrids, hyper-heuristics ----
    'CODE': 'WANG Y, CAI Z, ZHANG Q. Differential evolution with composite '
            'trial vector generation strategies and control parameters[J]. '
            'IEEE Transactions on Evolutionary Computation, 2011, 15(1): 55-66.',
    'PROXIMITY': 'EPITROPAKIS M G, TASOULIS D K, VRAHATIS M N. Enhancing '
                 'differential evolution utilizing proximity-based mutation '
                 'operators[J]. IEEE Transactions on Evolutionary Computation, '
                 '2011, 15(1): 99-119.',
    'IORIO06': 'IORIO A W, LI X. Incorporating directional information within a '
               'differential evolution algorithm[C]//Proceedings of the 8th '
               'Annual Conference on Genetic and Evolutionary Computation. '
               'Seattle: ACM, 2006: 377-384.',
    'ZHAO09': 'ZHAO H, ZHAN C, SHI Y. Distributed differential evolution based on '
              'adaptive merging of populations for dynamic optimization[C]//2009 '
              'IEEE Congress on Evolutionary Computation. Trondheim: IEEE, 2009: '
              '237-244.',
    'ELSAYED12': 'ELSAYED S M, SARKER R A, ESSAM D L. GA with a new multi-parent '
                 'crossover for solving constrained optimization problems[C]//'
                 '2012 IEEE Congress on Evolutionary Computation. Brisbane: IEEE, '
                 '2012: 1-8.',
    'POTTER94': 'POTTER M A, DE JONG K A. A cooperative coevolutionary approach '
                'to function optimization[C]//Proceedings of the 3rd Conference '
                'on Parallel Problem Solving from Nature. Jerusalem: Springer, '
                '1994: 249-257.',
    'LI_SPECIES13': 'LI X. A multimodal differential evolution with species-based '
                    'seed assignment[C]//Proceedings of the 15th Annual '
                    'Conference on Genetic and Evolutionary Computation. '
                    'Amsterdam: ACM, 2013: 97-104.',
    'SLPSO': 'WANG Y, LI B, WEISE T, et al. Self-adaptive learning based particle '
             'swarm optimization[J]. Information Sciences, 2011, 181(20): '
             '4515-4538.',
    'PSO': 'KENNEDY J, EBERHART R. Particle swarm optimization[C]//Proceedings of '
           'ICNN\'95—International Conference on Neural Networks. Perth: IEEE, '
           '1995: 1942-1948.',
    'ACO': 'DORIGO M, BIRATTARI M, STÜTZLE T. Ant colony optimization[J]. IEEE '
           'Computational Intelligence Magazine, 2006, 1(4): 28-39.',
    'CMAES': 'HANSEN N, MÜLLER S D, KOUMOUTSAKOS P. Reducing the time complexity '
             'of the derandomized evolution strategy with covariance matrix '
             'adaptation (CMA-ES)[J]. Evolutionary Computation, 2003, 11(1): '
             '1-18.',
    'STOCH_RANK': 'RUNARSSON T P, YAO X. Stochastic ranking for constrained '
                  'evolutionary optimization[J]. IEEE Transactions on '
                  'Evolutionary Computation, 2000, 4(3): 284-294.',

    # ---- landscape analysis ----
    'FLA_SURVEY': 'PITZER E, AFFENZELLER M. A comprehensive survey on fitness '
                  'landscape analysis[M]//Recent Advances in Intelligent '
                  'Engineering Systems. Berlin: Springer, 2012: 161-191.',
    'FLA_SURVEY2': 'MALAN K M, ENGELBRECHT A P. A survey of techniques for '
                   'characterising fitness landscapes in continuous optimisation'
                   '[J]. Information Sciences, 2013, 241: 148-163.',
    'STN': 'OCHOA G, MALAN K M. Search trajectory networks: a tool for analysing '
           'and visualising the behaviour of metaheuristics[J]. Applied Soft '
           'Computing, 2018, 67: 142-158.',
    'MORGAN21': 'MORGAN R, GALLAGHER M. Sampling techniques and distance metrics '
                'in high dimensional continuous landscape analysis: '
                'limitations and improvements[J]. IEEE Transactions on '
                'Evolutionary Computation, 2014, 18(3): 456-461.',

    # ---- bandits, Bayesian optimisation, estimation of distribution ----
    'GP_UCB': 'SRINIVAS N, KRAUSE A, KAKADE S M, et al. Gaussian process '
              'optimization in the bandit setting: no regret and experimental '
              'design[J]. Journal of Machine Learning Research, 2010, 11: '
              '1205-1223.',
    'BO_TUTORIAL': 'BROCHU E, CORA V M, DE FREITAS N. A tutorial on Bayesian '
                   'optimization of expensive cost functions, with application '
                   'to active user modeling and hierarchical reinforcement '
                   'learning[EB/OL]. 2010[2026-10-12]. '
                   'https://arxiv.org/abs/1012.2599.',
    'BO_INFO': 'HOFFMAN M W, DE RIJKE R, WHITESON S. An information-theoretic '
               'framework for Bayesian optimization[C]//Proceedings of the 31st '
               'International Conference on Machine Learning. Beijing: PMLR, '
               '2014: 1895-1903.',
    'GPML': 'RASMUSSEN C E, WILLIAMS C K I. Gaussian processes for machine '
            'learning[M]. Cambridge: MIT Press, 2006.',
    'BOA': 'PELIKAN M, GOLDBERG D E, CANTÚ-PAZ E. BOA: the Bayesian optimization '
           'algorithm[C]//Proceedings of the Genetic and Evolutionary Computation '
           'Conference. Orlando: Morgan Kaufmann, 1999: 525-532.',

    # ---- statistics ----
    'WILCOXON': 'WILCOXON F. Individual comparisons by ranking methods[J]. '
                'Biometrics Bulletin, 1945, 1(6): 80-83.',
    'DEMSAR': 'DEMŠAR J. Statistical comparisons of classifiers over multiple '
              'data sets[J]. Journal of Machine Learning Research, 2006, 7: '
              '1-30.',
    'GARCIA10': 'GARCÍA S, FERNÁNDEZ A, LUENGO J, et al. Advanced nonparametric '
                'tests for multiple comparisons in the design of experiments in '
                'computational intelligence and data mining: experimental '
                'analysis of power[J]. Information Sciences, 2010, 180(10): '
                '2044-2064.',
    'HOLM': 'HOLM S. A simple sequentially rejective multiple test procedure[J]. '
            'Scandinavian Journal of Statistics, 1979, 6(2): 65-70.',
    'MORRIS': 'CAMPOLONGO F, CARIBONI J, SALTELLI A. An effective screening '
              'design for sensitivity analysis of large models[J]. Environmental '
              'Modelling and Software, 2007, 22(10): 1509-1518.',
    'SALTELLI10': 'SALTELLI A, ANNONI P, AZZINI I, et al. Variance based '
                  'sensitivity analysis of model output: design and estimator '
                  'for the total sensitivity index[J]. Computer Physics '
                  'Communications, 2010, 181(2): 259-270.',
    'KRAMER10': 'KRAMER O. A review of constraint-handling techniques for '
                'evolution strategies[J]. Soft Computing, 2010, 14(3): 281-293.',

    # ---- engineering applications of DE ----
    'IDDE': 'LIN Y C, HSU S H, HO W H. i-DDE: an improved dynamic differential '
            'evolution with application to brushless DC motor design[J]. IEEE '
            'Transactions on Magnetics, 2010, 46(8): 3157-3160.',
    'AGING_LEADER': 'CHEN W N, ZHANG J, CHUNG H S H, et al. Particle swarm '
                    'optimization with an aging leader and challengers[J]. IEEE '
                    'Transactions on Evolutionary Computation, 2013, 17(2): '
                    '241-258.',
    'PV_DE': 'SARKER M H, HAQUE M A. Parameter estimation of solar photovoltaic '
             'models using an improved adaptive differential evolution '
             'algorithm[J]. IEEE Transactions on Industrial Informatics, 2023, '
             '19(8): 8745-8756.',
    'CHAOTIC_DE': 'SAHOO S K, BARISAL A K. A chaotic hybrid differential '
                  'evolution algorithm based dynamic economic dispatch with '
                  'transmission losses[C]//2011 International Conference on '
                  'Energy, Automation and Signal. Bhubaneswar: IEEE, 2011: 1-6.',

    # ---- image segmentation / multilevel thresholding ----
    'KAPUR': 'KAPUR J N, SAHOO P K, WONG A K C. A new method for gray-level '
             'picture thresholding using the entropy of the histogram[J]. '
             'Computer Vision, Graphics, and Image Processing, 1985, 29(3): '
             '273-285.',
    'OTSU': 'OTSU N. A threshold selection method from gray-level histograms[J]. '
            'IEEE Transactions on Systems, Man, and Cybernetics, 1979, 9(1): '
            '62-66.',
    'HAMMOUCHE': 'HAMMOUCHE K, DIAF M, SIARRY P. A comparative study of various '
                 'meta-heuristic techniques applied to the multilevel '
                 'thresholding problem[J]. Engineering Applications of Artificial '
                 'Intelligence, 2010, 23(5): 676-688.',
    'OLIVA_EMO': 'OLIVA D, CUEVAS E, PAJARES G, et al. A multilevel thresholding '
                 'algorithm using electromagnetism optimization[J]. '
                 'Neurocomputing, 2014, 139: 357-381.',
    'CHAN_VESE': 'CHAN T F, VESE L A. Active contours without edges[J]. IEEE '
                 'Transactions on Image Processing, 2001, 10(2): 266-277.',
    'BSDS500': 'ARBELÁEZ P, MAIRE M, FOWLKES C, et al. Contour detection and '
               'hierarchical image segmentation[J]. IEEE Transactions on Pattern '
               'Analysis and Machine Intelligence, 2011, 33(5): 898-916.',
    'KOLEKTOR': 'TABERNIK D, ŠELA S, SKVARČ J, et al. Segmentation-based '
                'deep-learning approach for surface-defect detection[J]. Journal '
                'of Intelligent Manufacturing, 2020, 31(3): 759-776.',
    'COVID': 'COHEN J P, MORRISON P, DAO L. COVID-19 image data '
             'collection[EB/OL]. 2020[2026-10-12]. '
             'https://arxiv.org/abs/2003.11597.',

    # ---- component-level benchmarking, reproducibility, methodology ----
    'TANABE_BENCH': 'TANABE R, FUKUNAGA A S. Reviewing and benchmarking '
                    'parameter control methods in differential evolution[J]. '
                    'IEEE Transactions on Cybernetics, 2020, 50(3): 1170-1184.',
    'TANABE_LAND': 'TANABE R. Analyzing adaptive parameter landscapes in '
                   'parameter adaptation methods for differential evolution'
                   '[C]//Proceedings of the 2020 Genetic and Evolutionary '
                   'Computation Conference. Cancun: ACM, 2020: 645-653.',
    'MOLINA17': 'MOLINA D, MORENO-GARCÍA F, HERRERA F. Analysis among winners '
                'of different IEEE CEC competitions on real-parameters '
                'optimization: is there always improvement?[C]//2017 IEEE '
                'Congress on Evolutionary Computation. Donostia: IEEE, 2017: '
                '805-812.',
    'SORENSEN15': 'SÖRENSEN K. Metaheuristics—the metaphor exposed[J]. '
                  'International Transactions in Operational Research, 2015, '
                  '22(1): 3-18.',
    'VELASCO24': 'VELASCO L, GUERRERO H, HOSPITALER A. A literature review and '
                 'critical analysis of metaheuristics recently developed[J]. '
                 'Archives of Computational Methods in Engineering, 2024, '
                 '31(1): 125-146.',
    'DENG24': 'DENG L, LIU S. Metaheuristics exposed: unmasking the design '
              'pitfalls of arithmetic optimization algorithm in benchmarking'
              '[J]. Applied Soft Computing, 2024, 160: 111696.',
    'STANOVOV22': 'STANOVOV V, AKHMEDOVA S, SEMENKIN E. Dual-population '
                  'adaptive differential evolution algorithm L-NTADE[J]. '
                  'Mathematics, 2022, 10(24): 4666.',
    'DERRAC11': 'DERRAC J, GARCÍA S, MOLINA D, et al. A practical tutorial on '
                'the use of nonparametric statistical tests as a methodology '
                'for comparing evolutionary and swarm intelligence algorithms'
                '[J]. Swarm and Evolutionary Computation, 2011, 1(1): 3-18.',
    'MEZURA06': 'MEZURA-MONTES E, VELÁZQUEZ-REYES J, COELLO COELLO C A. A '
                'comparative study of differential evolution variants for '
                'global optimization[C]//Proceedings of the 8th Annual '
                'Conference on Genetic and Evolutionary Computation. Seattle: '
                'ACM, 2006: 485-492.',

    # ---- landscape-aware DE ----
    'SALLAM17': 'SALLAM K M, ELSAYED S M, SARKER R A, et al. Landscape-based '
                'adaptive operator selection mechanism for differential '
                'evolution[J]. Information Sciences, 2017, 418-419: 383-404.',
    'TAN21': 'TAN Z, LI K, WANG Y. Differential evolution with adaptive '
             'mutation strategy based on fitness landscape analysis[J]. '
             'Information Sciences, 2021, 549: 142-163.',
    'TAN22': 'TAN Z, TANG Y, HUANG H, et al. Dynamic fitness landscape-based '
             'adaptive mutation strategy selection mechanism for differential '
             'evolution[J]. Information Sciences, 2022, 607: 44-61.',
    'WANG_EVOLV': 'WANG M, LI B, ZHANG G, et al. Population evolvability: '
                  'dynamic fitness landscape analysis for population-based '
                  'metaheuristic algorithms[J]. IEEE Transactions on '
                  'Evolutionary Computation, 2018, 22(4): 550-563.',
    'KERSCHKE19': 'KERSCHKE P, TRAUTMANN H. Automated algorithm selection on '
                  'continuous black-box problems by combining exploratory '
                  'landscape analysis and machine learning[J]. Evolutionary '
                  'Computation, 2019, 27(1): 99-127.',
    'ELA11': 'MERSMANN O, BISCHL B, TRAUTMANN H, et al. Exploratory landscape '
             'analysis[C]//Proceedings of the 13th Annual Conference on Genetic '
             'and Evolutionary Computation. Dublin: ACM, 2011: 829-836.',

    # ---- parameter control, ensembles, learning-driven control ----
    'WANG_INS20': 'WANG S L, MORSIDI F, NG T F, et al. Insights into the '
                  'effects of control parameters and mutation strategy on '
                  'self-adaptive ensemble-based differential evolution[J]. '
                  'Information Sciences, 2020, 514: 203-233.',
    'GONG_CR14': 'GONG W, CAI Z, WANG Y. Repairing the crossover rate in '
                 'adaptive differential evolution[J]. Applied Soft Computing, '
                 '2014, 15: 149-168.',
    'EPSDE': 'MALLIPEDDI R, SUGANTHAN P N, PAN Q K, et al. Differential '
             'evolution algorithm with ensemble of parameters and mutation '
             'strategies[J]. Applied Soft Computing, 2011, 11(2): 1679-1696.',
    'SHARMA19': 'SHARMA M, KOMNINOS A, LÓPEZ-IBÁÑEZ M, et al. Deep '
                'reinforcement learning based parameter control in '
                'differential evolution[C]//Proceedings of the Genetic and '
                'Evolutionary Computation Conference. Prague: ACM, 2019: '
                '709-717.',
    'PENG09': 'PENG F, TANG K, CHEN G, et al. Multi-start JADE with knowledge '
              'transfer for numerical optimization[C]//2009 IEEE Congress on '
              'Evolutionary Computation. Trondheim: IEEE, 2009: 1889-1895.',
}

# -*- coding: utf-8 -*-
"""§5.2 真实任务算法横向 + benchmark 排名迁移（RQ5.1）。

用 UAV bare 臂的 4 个主指标（composite_pct / n_arrived / n_lost /
path_length）给 29 个 DE 宿主排「真实任务价值榜」，与 CEC2017 D=30 的 bare
排名（``results/cec/tables/mech30_bare_accuracy.csv``）做 Spearman 秩相关，
判断 benchmark 排名能否迁移到真实任务。

产出（``results/apps/tables/``）：
    uav_value_rank.csv      价值榜 + 综合分 + UAV 名次 + CEC 名次
    uav_rank_spearman.csv   各指标 / 综合分 与 CEC 排名的 Spearman ρ
"""
import argparse
import csv
import sys
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

sys.path.insert(0, str(Path(__file__).resolve().parent))

import analyze_uav as AU          # noqa: E402  (reuse load_cells / arms_of / _metric_vals)
import de_hosts_cec as DHC        # noqa: E402  (CEC_HOST_ORDER / pop_size_for)

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'
CEC_TAB = ROOT / 'results' / 'cec' / 'tables'

# 4 主指标（与 master 文档 §5.2 一致）
MAIN_METRICS = ['composite_pct', 'n_arrived', 'n_lost', 'path_length']


def load_cec_bare_rank(suite='cec2017', dim=30):
    """CEC bare 排名：rank 1 = 该宿主平均 log10 误差最低（最好）。

    从 ``mech30_bare_accuracy.csv`` 取 ``(suite, dim)`` 子集，按宿主聚合
    ``bare_median_log10err``（每个函数 30 个 run 的对数误差中位数）在函数上
    的均值排序。

    注意与第 4 节的口径差异：第 4 节的表（``block_ranks``）在函数上取的是
    **中位数**，且误差已按 ``analyze_upcl_cec`` 的逐函数基准平移
    （``reference_values.csv``）；这里取**均值**、用未平移的原始误差。两者
    是不同但各自自洽的统计量，正文与题注必须按本函数的定义叙述（第 5 章
    §5.3 已写明"每个函数的对数误差中位数、再对函数取均值"）。若改为第 4 节
    的中位数口径，名次会有 24/29 个变体变化，Spearman ρ 由 0.30 变为 0.41
    （p 0.12→0.03），结论随之改变，故未改动。
    """
    import pandas as pd
    df = pd.read_csv(CEC_TAB / 'mech30_bare_accuracy.csv')
    sub = df[(df['suite'] == suite) & (df['dim'] == dim)]
    host_err = sub.groupby('host')['bare_median_log10err'].mean()
    host_err = host_err.sort_values()
    return {h: i + 1 for i, h in enumerate(host_err.index)}


def uav_host_metrics(cells, scenario='intercept', dim=30):
    """每宿主在 4 主指标上的聚合值（跨任务 × 跨 run 的 median）。"""
    acc = {}
    for (suite, d, host, fid), c in cells.items():
        if suite != f'uav_{scenario}' or d != dim:
            continue
        if 'bare' not in AU.arms_of(c):
            continue
        for name in MAIN_METRICS:
            vals = AU._metric_vals(c, 'bare', name)
            if vals:
                acc.setdefault(host, {}).setdefault(name, []).extend(vals)
    out = {}
    for h, dct in acc.items():
        row = {name: float(np.median(v)) for name, v in dct.items() if v}
        if len(row) == len(MAIN_METRICS):
            out[h] = row
    return out


def composite_score(host_metrics):
    """综合分：4 主指标 z-score 标准化（lower_better 取负）后求和，越大越好。"""
    hosts = sorted(host_metrics)
    n = len(hosts)
    z = {name: {} for name in MAIN_METRICS}
    for name in MAIN_METRICS:
        vals = np.array([host_metrics[h][name] for h in hosts], dtype=float)
        mu, sd = vals.mean(), vals.std(ddof=0)
        sd = sd if sd > 1e-12 else 1.0
        for h, v in zip(hosts, vals):
            z[name][h] = (v - mu) / sd
    sign = {name: +1.0 if AU.METRIC_DIRECTION.get(name) in
            ('higher_better', 'bool') else -1.0 for name in MAIN_METRICS}
    return {h: float(sum(sign[name] * z[name][h] for name in MAIN_METRICS))
            for h in hosts}


def _rank(values, ascending):
    """把 dict host->value 转成 dict host->rank，rank 1 = 最好。

    ``ascending=True`` 表示值越小越好（rank 1 给最小值）。
    """
    ordered = sorted(values.items(), key=lambda kv: kv[1], reverse=not ascending)
    return {h: i + 1 for i, (h, _) in enumerate(ordered)}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept')
    ap.add_argument('--dim', type=int, default=30)
    ap.add_argument('--cec-suite', default='cec2017')
    ap.add_argument('--cec-dim', type=int, default=30)
    ap.add_argument('--min-runs', type=int, default=3)
    args = ap.parse_args(argv)

    cells = AU.load_cells(scenario=args.scenario, min_runs=args.min_runs)
    if not cells:
        print('[analyze_uav_rank] no UAV cells found; run analyze_uav first / '
              'wait for the experiment.')
        return

    host_metrics = uav_host_metrics(cells, args.scenario, args.dim)
    cec_rank = load_cec_bare_rank(args.cec_suite, args.cec_dim)
    common = sorted(set(host_metrics) & set(cec_rank))
    if len(common) < 3:
        print(f'[analyze_uav_rank] too few hosts in common ({len(common)}), abort.')
        return
    missing = sorted(set(host_metrics) ^ set(cec_rank))
    if missing:
        print(f'[analyze_uav_rank] hosts missing on one side: {missing}')

    score = composite_score({h: host_metrics[h] for h in common})
    uav_rank = _rank(score, ascending=False)   # 综合分越大越好

    # --- 价值榜 CSV ------------------------------------------------------
    TAB.mkdir(parents=True, exist_ok=True)
    order = sorted(common, key=lambda h: uav_rank[h])
    fields = (['uav_rank', 'host', 'composite'] + MAIN_METRICS
              + ['cec_rank', 'cec_log10err'])
    with open(TAB / 'uav_value_rank.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        for h in order:
            row = {'uav_rank': uav_rank[h], 'host': h,
                   'composite': round(score[h], 3),
                   'cec_rank': cec_rank.get(h)}
            for name in MAIN_METRICS:
                row[name] = round(host_metrics[h][name], 4)
            w.writerow(row)

    # --- Spearman ρ ------------------------------------------------------
    cec_rank_common = {h: cec_rank[h] for h in common}
    rows = []
    # 每个主指标单独：UAV 名次（方向归一化）
    for name in MAIN_METRICS:
        asc = AU.METRIC_DIRECTION.get(name) == 'lower_better'
        u_rank = _rank({h: host_metrics[h][name] for h in common}, ascending=asc)
        u = np.array([u_rank[h] for h in common])
        c = np.array([cec_rank_common[h] for h in common])
        rho, p = spearmanr(u, c)
        rows.append(dict(metric=name, direction=AU.METRIC_DIRECTION.get(name),
                         spearman_rho=round(float(rho), 4),
                         p=round(float(p), 4), n=len(common)))
    # 综合分
    u = np.array([uav_rank[h] for h in common])
    c = np.array([cec_rank_common[h] for h in common])
    rho, p = spearmanr(u, c)
    rows.append(dict(metric='composite', direction='higher_better',
                     spearman_rho=round(float(rho), 4), p=round(float(p), 4),
                     n=len(common)))

    with open(TAB / 'uav_rank_spearman.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['metric', 'direction', 'spearman_rho',
                                           'p', 'n'])
        w.writeheader()
        w.writerows(rows)

    print('\n=== §5.2 benchmark <-> 真实任务排名一致性（Spearman，rank 1 = 最好）===')
    for r in rows:
        sig = '*' if r['p'] < 0.05 else ''
        print(f"  {r['metric']:<16s} rho={r['spearman_rho']:+.3f}  "
              f"p={r['p']:.3f}  n={r['n']}{sig}")
    print(f'[analyze_uav_rank] wrote uav_value_rank.csv + uav_rank_spearman.csv '
          f'({len(common)} hosts)')


if __name__ == '__main__':
    main()

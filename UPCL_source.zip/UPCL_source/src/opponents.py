"""通用「对手（难度）策略」模块 —— 红方智能体的可插拔难度控件。

把红方「怎么决策」从具体场景里抽象出来，做成一条能力单调递增的难度轴
（内部 key 用 L0~L6，界面展示文字描述）：

    L0  无对手            红方不动且不拦截（纯路径规划，能力下界）
    L1  规则拦截（默认）   场景内置规则（向后兼容；intercept 追最近 / swarm 扇区优先）
    L4  强化学习·弱       低预算训练的固定 DRL 对手
    L5  强化学习·强       收敛的固定 DRL 对手
    L6  强化学习·对抗     更高预算训练的对抗 DRL 对手（标记为对抗档）

设计原则：
  * 策略与物理分离——策略只回答「每架红方本步往哪转（目标方位角）」，运动学、
    避撞、拦截判据全部留在场景层（env）。
  * 标准化接口 ``OpponentPolicy.act(...)``：输入红/蓝双方当前位置与状态，返回
    每架红方的目标方位角（弧度），``None`` 表示该架本步不动。
  * DRL 对手采用「黑盒策略优化」：策略 → 完整仿真 → 标量回报（击落架次）。由于
    环境没有可微分动力学，用无梯度算法（ES/CEM/SPSA，纯 numpy、无 torch）而非
    PPO/DQN/MADDPG 这类需要梯度或值函数 + 海量采样的深度强化学习。

用法：
    from opponents import make_opponent, DIFFICULTIES, DRL_ALGOS
    opp = make_opponent('L5', drl_algo='es')          # 固定 DRL 强对手
    opp = make_opponent('L1')                          # 返回 None（走 env 内置规则）
"""

from __future__ import annotations

import math
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np


# ===========================================================================
# 枚举与注册表
# ===========================================================================

# 难度档位（红方智能体能力单调递增）。内部 key 用 L0~L6，界面展示文字描述。
DIFFICULTIES: List[str] = ['L0', 'L1', 'L4', 'L5', 'L6']
DIFFICULTY_LABELS: Dict[str, str] = {
    'L0': '无对手（纯路径规划）',
    'L1': '规则拦截（默认）',
    'L4': '强化学习·弱',
    'L5': '强化学习·强',
    'L6': '强化学习·对抗',
}
DIFFICULTY_OPTIONS: List[str] = [DIFFICULTY_LABELS[d] for d in DIFFICULTIES]
DIFFICULTY_BY_LABEL: Dict[str, str] = {v: k for k, v in DIFFICULTY_LABELS.items()}

# 红方 DRL 对手的「黑盒策略优化器」选项（纯 numpy、无 torch）。本项目红方决策是
# 黑盒仿真（策略 → 完整仿真 → 标量回报「击落架次」），无可微分动力学，故用无梯度
# 策略搜索，而非 PPO/DQN/MADDPG 这类基于梯度/值函数 + 海量采样的深度 RL：
#   es    进化策略（OpenAI ES / OpenES）：对参数加高斯噪声采样，按回报差估梯度。
#   cem   交叉熵方法：采样一批参数，取精英子集更新均值与方差。
#   spsa  同步扰动随机逼近：随机方向 ±扰动，仅用两次评估估数值梯度。
DRL_ALGOS: List[str] = ['es', 'cem', 'spsa']
DRL_ALGO_LABELS: Dict[str, str] = {
    'es': '进化策略（ES）',
    'cem': '交叉熵方法（CEM）',
    'spsa': '数值梯度（SPSA）',
}
DRL_ALGO_OPTIONS: List[str] = [DRL_ALGO_LABELS[a] for a in DRL_ALGOS]
DRL_ALGO_BY_LABEL: Dict[str, str] = {v: k for k, v in DRL_ALGO_LABELS.items()}

# DRL 观测中蓝方的最大数量（不足补零；当前两场景默认均 ≤ 3）
_MAX_BLUE = 3
# 观测维度：自身(4) + 蓝方(3*_MAX_BLUE) + 目标区(2)
_OBS_DIM = 4 + 3 * _MAX_BLUE + 2
# MLP 隐藏层宽度
_HIDDEN = 32


def _cfg_scale(cfg) -> Tuple[float, float]:
    """返回 (宽度尺度 W, 高度尺度 H)，用于把位置归一化到 [0,1]。"""
    w = getattr(cfg, 'map_w', None) or getattr(cfg, 'width', 1.0)
    h = getattr(cfg, 'map_h', None) or getattr(cfg, 'depth', 1.0)
    return float(w), float(h)


def _cfg_target(cfg) -> Tuple[float, float]:
    """返回目标区中心（intercept 场景）或纵深终点（swarm 用 y=H）。"""
    if hasattr(cfg, 'target_pos'):
        return float(cfg.target_pos[0]), float(cfg.target_pos[1])
    return float(getattr(cfg, 'width', 1.0) / 2.0), float(cfg.depth)


# ===========================================================================
# 策略基类
# ===========================================================================

class OpponentPolicy:
    """红方策略基类（场景无关）。"""

    name = 'opponent'
    active = True  # False 表示该对手不参与拦截判定（如 L0 无对手）

    def act(self, red_pos, red_head, blue_pos, blue_state, cfg) -> List[Optional[float]]:
        """返回每架红方本步的目标方位角（弧度）。

        参数：
          red_pos:   (N, 2) 红方当前位置
          red_head:  (N,)   红方当前航向
          blue_pos:  (M, 2) 蓝方当前位置
          blue_state:(M,)   蓝方状态（0 飞行 1 到达 2 被击落）
          cfg:       场景配置（提供尺度/速度等）
        返回：
          长度 N 的 list，元素为目标方位角；None 表示该架本步不动。
        """
        raise NotImplementedError


class NoPolicy(OpponentPolicy):
    """L0：无对手——红方全程不动且不拦截（纯路径规划场景）。"""

    name = 'L0'
    active = False

    def act(self, red_pos, red_head, blue_pos, blue_state, cfg):
        return [None] * len(red_pos)


# ===========================================================================
# 策略网络（纯 numpy MLP）
# ===========================================================================

class MLPPolicy:
    """单隐层 MLP，输出每架红方的目标方位角（tanh * pi）。

    参数共享：同一网络对每架红方独立前向。参数向量可扁平化存取，供黑盒
    训练器（ES/CEM/SPSA）直接优化。
    """

    def __init__(self, n_in: int = _OBS_DIM, n_hidden: int = _HIDDEN,
                 seed: int = 0):
        self.n_in = int(n_in)
        self.n_hidden = int(n_hidden)
        self.rng = np.random.default_rng(seed)
        # Xavier 初始化
        self.w1 = self.rng.normal(0, 1.0 / math.sqrt(self.n_in),
                                  (self.n_in, self.n_hidden))
        self.b1 = np.zeros(self.n_hidden)
        self.w2 = self.rng.normal(0, 1.0 / math.sqrt(self.n_hidden),
                                  (self.n_hidden, 1))
        self.b2 = np.zeros(1)

    # ---- 参数向量存取（供黑盒训练器使用）----
    def get_params(self) -> np.ndarray:
        return np.concatenate([self.w1.ravel(), self.b1,
                               self.w2.ravel(), self.b2])

    def set_params(self, theta: np.ndarray):
        t = np.asarray(theta, dtype=float).ravel()
        n1 = self.n_in * self.n_hidden
        n2 = self.n_hidden
        n3 = self.n_hidden
        i = 0
        self.w1 = t[i:i + n1].reshape(self.n_in, self.n_hidden); i += n1
        self.b1 = t[i:i + n2]; i += n2
        self.w2 = t[i:i + n3].reshape(self.n_hidden, 1); i += n3
        self.b2 = t[i:i + 1]

    @property
    def n_params(self) -> int:
        return self.n_in * self.n_hidden + self.n_hidden + self.n_hidden + 1

    def forward(self, obs: np.ndarray) -> np.ndarray:
        """obs: (N, n_in) -> (N, 1) 目标方位角（弧度）。"""
        h = np.tanh(obs @ self.w1 + self.b1)
        out = np.tanh(h @ self.w2 + self.b2).ravel()
        return out * math.pi


# ===========================================================================
# 固定 DRL 对手（L4 / L5）
# ===========================================================================

class DRLPolicy(OpponentPolicy):
    """固定 DRL 对手：加载/训练好的 MLP 权重，冻结后用于推理。"""

    name = 'drl'

    def __init__(self, net: Optional[MLPPolicy] = None, seed: int = 0,
                 label: str = 'drl'):
        self.net = net or MLPPolicy(seed=seed)
        self.label = label

    def _build_obs(self, red_pos, red_head, blue_pos, blue_state, cfg) -> np.ndarray:
        W, H = _cfg_scale(cfg)
        tx, ty = _cfg_target(cfg)
        red_pos = np.asarray(red_pos, dtype=float)
        blue_pos = np.asarray(blue_pos, dtype=float)
        blue_state = np.asarray(blue_state, dtype=float)
        N = len(red_pos)
        obs = np.zeros((N, _OBS_DIM), dtype=float)
        for k in range(N):
            px, py = red_pos[k][0] / W, red_pos[k][1] / H
            hd = float(red_head[k])
            row = [px, py, math.sin(hd), math.cos(hd)]
            for j in range(_MAX_BLUE):
                if j < len(blue_pos) and blue_state[j] == 0:
                    row += [(blue_pos[j][0] - red_pos[k][0]) / W,
                            (blue_pos[j][1] - red_pos[k][1]) / H, 1.0]
                else:
                    row += [0.0, 0.0, 0.0]
            row += [tx / W, ty / H]
            obs[k] = row
        return obs

    def act(self, red_pos, red_head, blue_pos, blue_state, cfg):
        if len(red_pos) == 0:
            return []
        obs = self._build_obs(red_pos, red_head, blue_pos, blue_state, cfg)
        th = self.net.forward(obs)
        return [float(v) for v in th]


class AdversarialPolicy(DRLPolicy):
    """L6：对抗 DRL 对手（协同进化得到的策略，行为同 DRL，标记为对抗档）。"""

    name = 'L6'


# ===========================================================================
# 离线训练（L4/L5 固定 DRL 对手的来源；L6 用它做单轮训练）
# ===========================================================================

def train_defender(env, blue_xs: Sequence[np.ndarray], algo: str = 'es',
                   iters: int = 40, pop: int = 16, sigma: float = 0.15,
                   lr: float = 0.2, seed: int = 0,
                   progress_cb: Optional[Callable[[int, int, float], None]] = None,
                   ) -> MLPPolicy:
    """在给定蓝方轨迹集合上，用黑盒策略优化训练红方策略。

    回报 = 平均每局被红方拦截（击落）的蓝方架次（越大越好）。

    参数：
      env:        已注入策略的 env 实例（训练中会临时覆盖其 ``opponent``）
      blue_xs:    蓝方轨迹样本（每个是 [-1,1]^D 的航点向量）
      algo:       训练算法 es / cem / reinforce
      iters/pop/sigma/lr/seed: 训练超参数
      progress_cb: 可选回调 (iter, total, best_reward)
    返回：训练好的 MLPPolicy（含最优权重）。
    """
    algo = algo.lower()
    if algo == 'reinforce':      # 旧名兼容（早期误命名为 REINFORCE，实为 SPSA）
        algo = 'spsa'
    if algo not in DRL_ALGOS:
        raise ValueError(f'未知 DRL 算法: {algo}（可用: {DRL_ALGOS}）')

    dim = env.cfg.dim
    rng = np.random.default_rng(seed)
    blue_xs = [np.asarray(x, dtype=float).ravel() for x in blue_xs]
    if not blue_xs:
        blue_xs = [np.zeros(dim)]

    net = MLPPolicy(seed=seed)
    policy = DRLPolicy(net)

    def _reward(theta: np.ndarray) -> float:
        net.set_params(theta)
        env.opponent = policy
        total = 0.0
        for x in blue_xs:
            _, state, metrics = env.evaluate(x)
            total += float(metrics.get('n_lost', 0))
        return total / len(blue_xs)

    theta = net.get_params()
    n_params = theta.size
    best_theta = theta.copy()
    best_r = _reward(theta)

    if algo == 'cem':
        mu = theta.copy()
        sd = np.full(n_params, sigma)
        elite = max(4, pop // 4)
        for it in range(iters):
            samples = [mu + rng.normal(0, 1, n_params) * sd
                       for _ in range(pop)]
            rs = [_reward(s) for s in samples]
            order = np.argsort(rs)[::-1][:elite]
            elite_set = [samples[i] for i in order]
            mu = np.mean(elite_set, axis=0)
            sd = np.std(elite_set, axis=0) + 1e-4
            if rs[order[0]] > best_r:
                best_r = rs[order[0]]
                best_theta = samples[order[0]].copy()
            if progress_cb:
                progress_cb(it, iters, best_r)
        net.set_params(best_theta)

    elif algo == 'spsa':
        # 同步扰动随机逼近：随机方向 ±扰动，每次迭代仅 2 次评估估数值梯度
        c = sigma
        for it in range(iters):
            delta = rng.choice([-1.0, 1.0], size=n_params)
            rp = _reward(theta + c * delta)
            rm = _reward(theta - c * delta)
            g = (rp - rm) / (2.0 * c) * delta
            theta = theta + lr * g
            r_now = _reward(theta)
            if r_now > best_r:
                best_r = r_now
                best_theta = theta.copy()
            if progress_cb:
                progress_cb(it, iters, best_r)
        net.set_params(best_theta)

    else:  # es（OpenES，对称采样）
        half = max(1, pop // 2)
        for it in range(iters):
            grad = np.zeros(n_params)
            for _ in range(half):
                e = rng.normal(0, 1, n_params)
                rp = _reward(theta + sigma * e)
                rm = _reward(theta - sigma * e)
                grad += (rp - rm) * e
            grad /= (2.0 * half * sigma)
            theta = theta + lr * grad
            r_now = _reward(theta)
            if r_now > best_r:
                best_r = r_now
                best_theta = theta.copy()
            if progress_cb:
                progress_cb(it, iters, best_r)
        net.set_params(best_theta)

    return net


# ===========================================================================
# 工厂
# ===========================================================================

def make_opponent(difficulty: str, drl_algo: str = 'es', **kw):
    """按难度档位构造对手策略。

    返回：
      L1 -> None（表示使用 env 内置规则，向后兼容）
      其余 -> OpponentPolicy 实例（L0/L4/L5/L6）
    """
    difficulty = str(difficulty).upper()
    if difficulty not in DIFFICULTIES:
        raise ValueError(f'未知难度: {difficulty}（可用: {DIFFICULTIES}）')
    if difficulty == 'L1':
        return None
    if difficulty == 'L0':
        return NoPolicy()
    if difficulty in ('L4', 'L5'):
        return DRLPolicy(seed=kw.get('seed', 0), label=difficulty)
    if difficulty == 'L6':
        return AdversarialPolicy(seed=kw.get('seed', 0), label=difficulty)
    raise ValueError(difficulty)


def train_opponent(env, difficulty: str, drl_algo: str = 'es', seed: int = 0,
                   blue_xs: Optional[Sequence[np.ndarray]] = None,
                   **train_kw) -> OpponentPolicy:
    """为 L4/L5/L6 训练红方 DRL 对手，并把训练好的策略挂到 ``env.opponent``。

    迭代预算随难度递增（L4 弱 < L5 强 < L6 对抗）。返回训练好的策略对象。
    """
    difficulty = str(difficulty).upper()
    iters = train_kw.pop('iters', None)
    if iters is None:
        iters = {'L4': 8, 'L5': 15, 'L6': 25}.get(difficulty, 12)
    dim = env.cfg.dim
    if blue_xs is None:
        rng = np.random.default_rng(seed + 7)
        blue_xs = [rng.uniform(-1, 1, dim) for _ in range(4)]
    net = train_defender(env, list(blue_xs), algo=drl_algo, iters=iters,
                         seed=seed, **train_kw)
    policy_cls = AdversarialPolicy if difficulty == 'L6' else DRLPolicy
    policy = policy_cls(net, label=difficulty)
    env.opponent = policy
    return policy


def is_drl_difficulty(difficulty: str) -> bool:
    """L4/L5/L6 采用强化学习对手，需要额外提供 DRL 算法选择。"""
    return str(difficulty).upper() in ('L4', 'L5', 'L6')

# -*- coding: utf-8 -*-
"""Ablation study for UPCL.

Runs a reduced paired experiment for each configuration and writes a compact
table to results/upcl_ablation.json, which the manuscript builder reads into
Table 5.

Usage
-----
    python run_upcl_ablation.py              # default subset
    python run_upcl_ablation.py --runs 8     # more runs
"""
import argparse
import json
from pathlib import Path

import numpy as np

from upcl_experiment import UPCLPairedExperiment, get_config

ROOT = Path(__file__).resolve().parents[1]

# One factor per row.  The previous version compared the default against an
# "aggressive" preset that changed lambda, mu_0, kappa_u and the exploration
# schedule at the same time, so a difference in score could not be attributed
# to any single term of the decision rule.
VARIANTS = [
    ('default', 'UPCL (full)'),
    ('no_margin', 'no adaptive margin ($\\mu_1=0$)'),
    ('no_cost', 'no intervention cost ($\\lambda=0$)'),
    ('no_uncert', 'no uncertainty penalty ($\\kappa_u=0$)'),
    ('no_memory', 'no response memory ($M=1$)'),
    ('random', 'random correction (response model removed)'),
]

HOSTS = ['DE/rand/1', 'JADE', 'SHADE', 'jSO']
FUNCS = ['Sphere', 'Rastrigin', 'Schwefel', 'Rosenbrock']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dim', type=int, default=10)
    ap.add_argument('--runs', type=int, default=5)
    ap.add_argument('--evals', type=int, default=20000)
    args = ap.parse_args()

    out_rows = []
    for key, label in VARIANTS:
        rd = ROOT / 'results' / f'upcl_ab_{key}'
        exp = UPCLPairedExperiment(
            dim=args.dim, n_runs=args.runs, max_evals=args.evals,
            host_names=HOSTS, func_names=FUNCS,
            upcl_config=get_config(key), results_dir=str(rd))
        print(f'\n=== ablation: {key} ({label}) ===', flush=True)
        exp.run_all(verbose=False)

        summary = json.loads((rd / f'summary_D{args.dim}.json').read_text(
            encoding='utf-8'))
        # Primary metric: decades of the median.  improvement_pct is kept in
        # the file for reference but is not what the variants are ranked by.
        dec = [np.log10(max(r['orig_median'], 1e-8))
               - np.log10(max(r['upcl_median'], 1e-8)) for r in summary]
        imp = [r['improvement_pct'] for r in summary]
        out_rows.append({
            'variant': label,
            'dec': float(np.mean(dec)),
            'imp': float(np.mean(imp)),
            'cells': f"{sum(1 for v in dec if v > 0)}/{len(dec)}",
            'rho': float(np.mean([r.get('policy_rate', 0.0)
                                  for r in summary])),
        })
        print(f"  -> mean gain {out_rows[-1]['dec']:+.3f} dec  "
              f"cells {out_rows[-1]['cells']}  "
              f"rho {out_rows[-1]['rho']:.3f}   "
              f"(legacy {out_rows[-1]['imp']:+.1f}%)", flush=True)

    dest = ROOT / 'results' / 'upcl_ablation.json'
    dest.write_text(json.dumps(out_rows, indent=2, ensure_ascii=False),
                    encoding='utf-8')
    print('\nablation written ->', dest)
    for r in out_rows:
        print(f"  {r['variant']:<48s} {r['dec']:+7.3f} dec  "
              f"{r['cells']:>6s}  rho={r['rho']:.3f}  "
              f"(legacy {r['imp']:+8.1f}%)")


if __name__ == '__main__':
    main()

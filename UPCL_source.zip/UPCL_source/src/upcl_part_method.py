# -*- coding: utf-8 -*-
"""Manuscript Part II - Method: the Universal Candidate Correction Layer."""
import paper_figures as PFG

TITLE = (
    "The Universal Candidate Correction Layer as a Measurement Instrument"
)


def build(P, S):
    # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    # Section 3: Method
    # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    P.h1("3  The Universal Candidate Correction Layer")

    P.para(
        r"This section constructs the instrument used in the experiments. "
        r"Two premises, established in Section 2, fix what it has to be. "
        r"The first is that the question worth asking of differential "
        r"evolution is not whether one more variant can be made to optimise "
        r"better, but which mechanism is what actually steers the search; "
        r"the second is that this question can only be answered from the "
        r"outside, because the mechanisms of interest are internal to the "
        r"variant and are not exposed by it. The Universal Candidate Correction "
        r"Layer (UPCL) is built to that specification: it wraps a variant, "
        r"reads only the candidate that the variant has just emitted, and, "
        r"before the expensive evaluation, applies the least-distorted "
        r"correction whose online-estimated gain exceeds an explicit "
        r"intervention cost.")
    P.para(
        r"Three requirements follow from those two premises and fix the shape "
        r"of the instrument before any of its parts is designed. It must read "
        r"the variant only through quantities that every variant exposes, "
        r"which rules out hooks into $F$, $CR$, the archive or a strategy "
        r"index; it must leave the evaluation budget untouched, so that any "
        r"gain it reports is a change in where the budget is spent rather than "
        r"in how much of it there is; and it must be able to attribute an "
        r"outcome to the candidate that produced it, without which the "
        r"corrections it applies cannot be scored and the model it learns from "
        r"has no target. The third requirement is what makes the layer an "
        r"instrument rather than another operator. Once the same wrapper is "
        r"run over the same seed and the same initial population with and "
        r"without itself, the two arms differ only by the correction, so "
        r"whatever the layer does with the variant's candidates, how often it "
        r"finds one worth correcting and how far it moves it, is a property of "
        r"the variant and not of the layer. Every statistic reported in "
        r"Sections 4 and 5 is a summary of that paired comparison.")
    P.para(
        r"Those three requirements have one practical consequence: the layer "
        r"must sit at the single place in a variant where all three can be met "
        r"at once, between the generation of a candidate and its objective "
        r"evaluation. Placed later, on an accepted trial, it would leave the "
        r"outcome attributable but the budget already spent; placed earlier, "
        r"on the parameters of the mutation, it would become a component of "
        r"the variant and destroy the very invariance the measurement needs. "
        r"At that point the layer sees the parent $x$ and the raw candidate "
        r"$u$, it may return a different vector $u'$ in place of $u$, and "
        r"nothing else in the variant changes: the selection rule, the "
        r"parameter adaptation, the archive and the population reduction "
        r"remain the variant's own. The variant's random stream is likewise "
        r"untouched, because the layer keeps a generator of its own, so both "
        r"arms draw the same numbers and diverge only where a correction is "
        r"accepted, which is precisely the event the instrument measures. What "
        r"remains to be specified is therefore not where the layer sits but "
        r"what it is allowed to do there: how a move is described, how the "
        r"response of an action is estimated, and which correction is taken "
        r"when the estimate favours several of them at once.")
    P.figure(
        PFG.fig('schematic_logic'),
        'Research logic and the formation of the fingerprint: the $29$ '
        'variants are read through one common interface, the displacement '
        '$d=u-x$ from parent to raw candidate (left); a paired probe runs the '
        'host alone and the host wrapped by the layer under the same seed, '
        'initial population and evaluation budget, so that the two arms differ '
        'only by the layer (centre); the arms then yield comparable '
        'measurements, the intervention rate, the paired gain and the '
        'descriptor contrasts, which together form a mechanism fingerprint '
        'read against the bare performance rank (right) and interpreted across '
        'mechanisms, problem classes and dimensions to answer RQ1-RQ4 (bottom).',
        note='Framework diagram supplied as artwork; it states the research '
             'logic and carries no measured value.')
    P.para(
        r"Because the same intervention is applied to "
        r"every variant, the layer is a measurement instrument rather than a "
        r"search operator: it records, for each variant, how often its "
        r"candidates can be improved (the intervention rate) and by how "
        r"much (the gain) and the two together constitute the variant's "
        r"mechanism fingerprint. One candidate is evaluated per target "
        r"vector per generation, exactly as in the variant, so the instrument "
        r"changes where the budget is spent, never how much. We first "
        r"formalise an arbitrary DE variant as an opaque candidate generator "
        r"(Section 3.1), then build the three components of the instrument, "
        r"the descriptor that reads a candidate (Section 3.2), the memory "
        r"that records outcomes (Section 3.3), and the correction that "
        r"probes the variant (Section 3.4). Section 3.5 states the properties "
        r"the measurement rests on and fixes the quantities it "
        r"reports, and Section 3.6 gives the algorithmic statement and its "
        r"cost.")
    P.para(
        r"The three components follow a separation of concerns that the rest "
        r"of this section keeps. Characterisation, in Section 3.2, converts a "
        r"raw displacement into five dimensionless numbers and is the only "
        r"part that touches the search state; the memory of Section 3.3 is a "
        r"table of observed outcomes indexed by those numbers and by the "
        r"action taken, holding no reference to the variant; and the decision "
        r"rule of Section 3.4 compares five candidates on one scalar and "
        r"returns a corrected vector. A decision therefore costs a fixed "
        r"number of vector operations and one table lookup, independent of "
        r"the internal machinery of $H$: the layer never enumerates the "
        r"mechanisms of a variant, it only measures what those mechanisms "
        r"produce.")
    P.figure(
        PFG.fig('schematic_workflow'),
        'The layer as a closed loop around an opaque variant: the variant '
        'emits the parent and the raw candidate; M1 characterises the move, '
        'M2 returns the estimated response of each action from its ring '
        'buffer, and M3 takes the minimal correction, either the identity or '
        'one of the four non-identity actions; the corrected candidate passes '
        'the variant\'s own bound handling and a single objective evaluation, '
        'and the normalised response is written back to M2, which is what '
        'updates the next decision.',
        note='Framework diagram supplied as artwork; the three properties it '
             'preserves are stated and proved in Section 3.5.')


    # --------------------------------------------------------------
    P.h2("3.1  Any DE as an opaque candidate generator")

    P.para(
        r"Let $H$ denote an arbitrary DE variant operating on a population "
        r"$X_t=\{x_1^t,\dots,x_N^t\}\subset\mathbb{R}^D$. Whatever internal "
        r"machinery $H$ carries (a mutation strategy, a crossover operator, "
        r"scale-factor and crossover-rate memories, an external archive, a "
        r"population-size schedule) it performs the same externally visible "
        r"operation once per generation and per target vector: it emits a "
        r"candidate")
    P.equation(
        r"u_i^{t}=H\!\left(x_i^{t},\,S_t\right), "
        r"\qquad i=1,\dots,N,")
    P.para(
        r"where $S_t$ denotes the complete internal state of the variant, and "
        r"the candidate is then subjected to a single evaluation followed by "
        r"a one-to-one selection against $x_i^t$. This is the standard "
        r"one-target-one-trial interface of differential evolution, and the "
        r"variant-independence we claim is scoped to variants that "
        r"follow it: one candidate per target vector per generation, one "
        r"evaluation per candidate, and a one-to-one selection. Writing")
    P.equation(
        r"d_i^{t}=u_i^{t}-x_i^{t}")
    P.para(
        r"for the search displacement generated by the variant, every variant "
        r"that follows this interface realises the abstract form")
    P.equation(
        r"x_i^{t}\;\longrightarrow\;x_i^{t}+d_i^{t}\;\longrightarrow\;"
        r"\text{evaluate}\;\longrightarrow\;\text{select}.")
    P.para(
        r"The displacement $d_i^t$ is therefore not a mathematical invariant "
        r"of the DE family (its distribution depends on the variant) but it "
        r"is a common observable of the family, in the sense that $F$, $CR$, "
        r"the archive and the strategy index are not: no variant can complete "
        r"a generation without exposing the displacement it proposes, and "
        r"every variant expresses it in the same units. This is the object "
        r"the generated layer acts on. Multi-trial and opposition-based variants, "
        r"multi-population variants and restart-based variants expose the "
        r"same displacement but organise the evaluation accounting "
        r"differently; they are outside the scope claimed here and are "
        r"returned to in Section 5.")
    P.para(
        r"The layer is inserted between the crossover operator and the "
        r"evaluation that the variant would perform anyway:")
    P.equation(
        r"\tilde u_i^{t}=x_i^{t}+T_{a}\!\left(d_i^{t}\right), "
        r"\qquad a\in\mathcal{A},")
    P.para(
        r"where $T_a$ is one of five maps defined in Section 3.4 and $a$ is "
        r"chosen by the layer. The variant then evaluates $\tilde u_i^t$ and "
        r"runs its own, unmodified selection and memory update. One "
        r"consequence is noted here rather than deferred to Section 3.5: "
        r"the variant records the outcome of the corrected "
        r"candidate while attributing it to the parameter pair it sampled "
        r"itself, so the layer introduces an attribution shift inside the "
        r"variant memory. Formally the composite system is")
    P.equation(
        r"A_t=C_t H_t ,\qquad "
        r"C_t:\left(x_i^t,\,u_i^t,\,\mathcal{M}_t\right)\mapsto"
        r"\tilde u_i^t ,")
    P.para(
        r"where $\mathcal{M}_t$ is the layer's own memory. The map "
        r"$C_t$ reads neither $S_t$ nor any component of it: it does not "
        r"observe $F$, $CR$, the archive, the mutation-strategy index or the "
        r"variant's parameter memories, and it never writes to them. The only "
        r"variant-level quantities consumed by $C_t$ are the population $X_t$ "
        r"and the fitness vector $f(X_t)$, which are observables that every "
        r"population-based optimiser exposes, together with the scalar "
        r"response of the candidate it has just emitted.")
    P.para(
        r"One degenerate case has to be excluded explicitly. If the variant "
        r"proposes no move at all, there is no direction to correct and "
        r"every map $T_a$ fixes the zero vector. The layer therefore applies")
    P.equation(
        r"\lVert d_i^{t}\rVert<\delta_{\mathrm{min}}\;\Longrightarrow\;"
        r"a_i=I,\qquad \tilde u_i^{t}=u_i^{t},")
    P.para(
        r"with $\delta_{\mathrm{min}}=10^{-24}$ in the implementation. Such "
        r"candidates "
        r"do occur in practice (a converged population, or a target whose "
        r"mutant coincides with itself) and they are passed through "
        r"untouched rather than being perturbed into an arbitrary "
        r"direction.")

    # --------------------------------------------------------------
    P.h2("3.2  M1: candidate characterisation")

    P.para(
        r"A correction decision must be conditioned on the candidate, not on "
        r"the identity of the mechanism that produced it. We therefore map "
        r"each displacement to a five-dimensional, dimensionless descriptor "
        r"that encodes the geometry of the generated move and its relation to "
        r"the current search state. Let")
    P.equation(
        r"s_t=\operatorname*{median}_{j<k}\lVert x_j^t-x_k^t\rVert")
    P.para(
        r"be the characteristic population scale (computed on a random subset "
        r"of at most $n_{\mathrm{ref}}=32$ individuals for linear cost in "
        r"$N$, and guarded as $s_t\leftarrow\max(s_t,\epsilon)$, where "
        r"$\epsilon$ denotes an arbitrary small positive constant, so that a "
        r"converged population cannot produce a division by zero), let "
        r"$q_i=d_i/\lVert d_i\rVert$, and let "
        r"$x_t^{\star}$ be the incumbent best, that is any element of $X_t$ "
        r"with $f(x_t^{\star})=\min_{x\in X_t}f(x)$. The "
        r"descriptor is")
    P.equation(
        r"z_i=\bigl[\ell_i,\;\theta_i,\;\eta_i,\;\kappa_i,"
        r"\;\nu_i\bigr]^{\top}\in\mathbb{R}^{5}")
    P.para(
        "whose components answer five questions. Together they reduce a raw "
        "candidate to the few geometric facts that decide whether the "
        "generated step is locally appropriate (how long it is, where it "
        "points, and whether that direction has been productive recently) "
        "without referring to the variant mechanism that produced it.")

    P.bullet(
        r"$\ell_i=\frac{1}{2}\log_2\bigl(\lVert d_i\rVert/s_t\bigr)$, the "
        r"step scale: is the generated move large or small relative to the "
        r"current spread of the population? The logarithm makes the quantity "
        r"scale free and symmetrises its distribution.",
        style="Numbered")
    P.bullet(
        r"$\theta_i=\langle q_i,\,\hat s_t\rangle$, the alignment with "
        r"success: does the direction agree with the exponentially weighted "
        r"mean of recently successful directions $\hat s_t$, defined by Eq. (15)?",
        style="Numbered")
    P.bullet(
        r"$\eta_i=\langle q_i,\,(x_t^{\star}-x_i)/\lVert x_t^{\star}"
        r"-x_i\rVert\rangle$, the alignment with the elite: does the move "
        r"point towards the current best individual? The component is set to "
        r"$0$ when $x_i=x_t^{\star}$.",
        style="Numbered")
    P.bullet(
        r"$\kappa_i=\frac{1}{2}\log_2\bigl(\min_j\lVert u_i-x_j^t\rVert"
        r"/s_t\bigr)$, the crowding at the landing point: does the candidate "
        r"land in an already densely occupied region? The minimum is taken "
        r"over the same reference subset used for $s_t$.",
        style="Numbered")
    P.bullet(
        r"$\nu_i=1-\max_{k}\bigl|\langle q_i,\,h_k\rangle\bigr|$, the "
        r"directional novelty: is the direction new with respect to a small "
        r"prototype set $\{h_k\}$ of recently sampled directions, defined "
        r"in this subsection?",
        style="Numbered")

    P.equation(
        r"\hat s_t\leftarrow\frac{(1-\gamma)\hat s_{t-1}+\gamma\,"
        r"q_i^{\prime}}{\lVert(1-\gamma)\hat s_{t-1}+\gamma\,"
        r"q_i^{\prime}\rVert},\qquad \gamma=0.05,")
    P.para(
        r"The success direction is initialised with the first improving "
        r"direction and updated only when a move improves ($r_i>0$). It is "
        r"updated with the direction that was \emph{actually executed}, "
        r"$q_i^{\prime}=T_{a_i}(d_i)/\lVert T_{a_i}(d_i)\rVert$, and not "
        r"with the direction the variant generated: when a correction is applied "
        r"and succeeds, the credit belongs to the corrected move, and "
        r"crediting $q_i$ instead would bias $\hat s_t$ towards a direction "
        r"that was never evaluated. This matters for the projection action "
        r"in particular, because that action is defined in "
        r"terms of $\hat s_t$: an unbiased $\hat s_t$ is what makes the "
        r"projection point where past success actually lies.")
    P.para(
        r"The prototype set $\{h_1,\dots,h_{n_{\mathrm{proto}}}\}$ with "
        r"$n_{\mathrm{proto}}=8$ is a ring buffer of unit directions. It is "
        r"filled with the first $n_{\mathrm{proto}}$ candidate directions and "
        r"thereafter refreshed as follows: once the buffer is full, each "
        r"candidate replaces the entry at the current pointer with "
        r"probability $p_{\mathrm{proto}}=0.05$, and the pointer advances "
        r"on replacement. Prototypes are stored as unit vectors, so "
        r"$\nu_i\in[0,1]$, and $\nu_i=1$ while the buffer is still empty. "
        r"Note that the prototypes record the directions \emph{generated} by "
        r"the variant, whereas $\hat s_t$ records the directions actually "
        r"executed and found successful: the two sets answer different "
        r"questions, novelty of the current candidate and direction of past "
        r"success, and are maintained separately.")
    P.para(
        r"Every component is dimensionless: $\theta_i,\eta_i\in[-1,1]$ and "
        r"$\nu_i\in[0,1]$ are bounded by construction, and $\ell_i,\kappa_i$ "
        r"are logarithms of a ratio of two lengths. In the implementation "
        r"all five are clipped componentwise to $[-4,4]$; the clip is a "
        r"saturation, not a renormalisation, so it changes nothing for the "
        r"three bounded components and only trims the tails of the two "
        r"logarithmic ones. None of the five components refers to $F$, $CR$, "
        r"an archive or a strategy index, which is precisely what makes the "
        r"representation variant independent.")
    P.para(
        r"The five components are computed once per candidate, from a "
        r"reference subset of at most $n_{\mathrm{ref}}=32$ individuals drawn "
        r"without replacement at the start of each generation. $s_t$ is the "
        r"median pairwise distance over that subset and the same subset "
        r"supplies the neighbourhood for $\kappa_i$, so holding it fixed "
        r"within a generation makes the descriptors of the $N$ candidates of "
        r"that generation comparable, while refreshing it every generation "
        r"lets the scale follow a contracting population. The crowding term "
        r"needs no temporary array of candidate-to-individual differences: "
        r"$\lVert u_i-x_j\rVert^2$ is expanded into three terms, one of which "
        r"is precomputed once per generation, so that the whole component "
        r"costs one matrix-vector product.")
    P.para(
        r"The two logarithmic components are half-logarithms in base two, so "
        r"that a step of twice the population scale scores $0.5$ whatever the "
        r"dimension and the units of the problem, and the pair "
        r"$(\ell_i,\kappa_i)$ spans roughly the same range as the two cosine "
        r"components; without the factor $1/2$ the step scale would dominate "
        r"the kernel distances of Section 3.3. Novelty uses the absolute "
        r"cosine, so that a direction and its opposite count as equally "
        r"familiar: the buffer records which directions have been proposed, "
        r"not which way along them the search moved.")
    P.para(
        f"Figure {P.fig_no + 1} draws the five views on a single candidate "
        r"move: the step scale against the population spread, the alignment "
        r"with the recent success direction and with the incumbent best, the "
        r"crowding at the landing point and the novelty with respect to the "
        r"generated directions. The five are parallel readings of the same "
        r"displacement, computed once per candidate, and the vector they form "
        r"is the only input that the response memory and the correction rule "
        r"ever see.")
    P.para(
        r"The five are chosen so that none of them can be recovered from the "
        r"others, which is what makes the vector a description rather than a "
        r"re-parameterisation of the step length. Two moves of equal length may "
        r"point differently with respect to the success direction and to the "
        r"incumbent, may land in regions of different crowding, and may be more "
        r"or less familiar given the directions already proposed; the five "
        r"numbers separate these cases, so the kernel of Section 3.3 can weight "
        r"two candidates differently even when their norms coincide. The parent, "
        r"the candidate and the state of the population are the only quantities "
        r"the computation touches, which is why the descriptor can be evaluated "
        r"before the candidate is scored and why it costs nothing in objective "
        r"evaluations. The two logarithmic components are the expensive ones, "
        r"and Section 3.2 reduces both to a matrix-vector product. The logic "
        r"is the one behind information-content characterisations of "
        r"landscapes, which replace a tabulated objective by a few statistics "
        r"precisely because the decision the statistics support does not "
        r"require the table [@VASSILEV00].")
    P.figure(
        PFG.fig('schematic_descriptor'),
        r"The five dimensionless descriptors of a candidate move, all measured "
        r"on the parent $x$, the candidate $u$ and the population state: (a) "
        r"the step scale $\ell$ against the population spread $s$; (b) the "
        r"alignment $\theta$ with the recent success direction $s$; (c) the "
        r"alignment $\eta$ with the direction of the incumbent best $x^{\star}$; "
        r"(d) the crowding $\kappa$ at the landing point; (e) the novelty "
        r"$\nu$ with respect to the prototypes $h_k$ of recently generated "
        r"directions. The five are clipped componentwise to $[-4,4]$ and "
        r"concatenated into $z=(\ell,\theta,\eta,\kappa,\nu)$.",
        note="Framework diagram supplied as artwork; the definitions and the "
             "clipping are given in the text of this subsection.")
    P.para(
        r"None of the five can be read off the others: two steps of the same "
        r"length may differ in both alignments and in the crowding of their "
        r"landing points, which is why the descriptor is a vector rather than "
        r"a single score.")

    # --------------------------------------------------------------
    P.h2("3.3  M2: the candidate response memory")

    P.para(
        r"Whereas adaptive DE records \emph{which parameter values or which "
        r"strategies} succeeded, the layer records \emph{what kind of search "
        r"action produced what response}. Each candidate yields, at no extra "
        r"cost, one supervised data point: the descriptor of the "
        r"uncorrected candidate, the action actually applied, and the "
        r"observed response. The response is normalised by the population "
        r"fitness dispersion $\sigma_t=\mathrm{std}\,f(X_t)$ and bounded,")
    P.equation(
        r"r_i=\tanh\!\left(\frac{f(x_i)-f(\tilde u_i)}"
        r"{\sigma_t+\epsilon}\right)\in[-1,1],")
    P.para(
        r"so that $r_i>0$ means improvement and the target is free of the "
        r"units and of the dynamic range of the objective. Division by "
        r"$\sigma_t$ removes the objective's scale; the $\tanh$ bound "
        r"prevents a single outlier improvement from dominating the "
        r"regression.")

    P.para(
        r"The memory $\mathcal{M}$ is a ring buffer of capacity $M=256$ "
        r"holding triples $(z_j,a_j,r_j)$. Given a query descriptor $z$ and "
        r"an action $a$, the estimate is a kernel-weighted mean over the "
        r"sub-buffer $\mathcal{M}_a=\{j:a_j=a\}$, taken across those past "
        r"candidates whose descriptor resembled $z$ and shrunk towards the "
        r"mean response of that action,")
    P.equation(
        r"\hat r(z,a)=\frac{\sum_{j\in\mathcal{M}_a}w_j r_j+k_0\,"
        r"\bar r_a}{\sum_{j\in\mathcal{M}_a}w_j+k_0},"
        r"\qquad "
        r"w_j=\exp\left(-\frac{1}{2b^{2}}\lVert z-z_j\rVert^{2}\right),")
    P.para(
        r"with bandwidth $b=1.2$. The weight $w_j$ depends on the distance "
        r"between the query descriptor and the stored one, so the estimate "
        r"is local in descriptor space: only triples whose descriptor is "
        r"close to $z$ contribute appreciably. Here $\bar r_a$ is the mean "
        r"response over the current sub-buffer $\mathcal{M}_a$, taken as "
        r"$0$ when the sub-buffer is empty. A weighted mean is only as "
        r"trustworthy as the evidence behind it, and a neighbourhood "
        r"dominated by one or two samples yields a noisy estimate, so the "
        r"layer shrinks the estimate towards $\bar r_a$ when that trust is "
        r"low. The measure of trust is the effective sample size, and the "
        r"shrinkage weight is")
    P.equation(
        r"k_0=k_{\max}\,\max\bigl(0,\,1-n_{\mathrm{eff}}/n_{\min}\bigr),"
        r"\qquad "
        r"n_{\mathrm{eff}}=\frac{\bigl(\sum_{j\in\mathcal{M}_a}w_j\bigr)^2}"
        r"{\sum_{j\in\mathcal{M}_a}w_j^{2}},"
        r"\qquad k_{\max}=2.0,\; n_{\min}=3.0 .")
    P.para(
        r"The effective sample size $n_{\mathrm{eff}}$ is the standard "
        r"ratio that measures how many nearly equally weighted observations "
        r"the kernel neighbourhood contains: it equals the number of stored "
        r"triples when the weights are equal and decreases towards $1$ as "
        r"the estimate comes to depend on a few dominant samples. With "
        r"$n_{\mathrm{eff}}\ge n_{\min}$ the shrinkage weight vanishes and "
        r"the estimate is the plain kernel mean. Together the kernel and "
        r"the shrinkage are the two safeguards against acting on sparse "
        r"local experience: the kernel localises the estimate so that only "
        r"comparable past states contribute, and the shrinkage discounts "
        r"the estimate when the neighbourhood holds too little independent "
        r"evidence.")
    P.para(
        r"The model is not free of hyper-parameters: $b$, $M$, $k_{\max}$ "
        r"and $n_{\min}$ are hyper-parameters. They are fixed, set once from "
        r"the role each plays in the decision rule, listed with the default "
        r"configuration at the end of the paper, and not tuned per problem, "
        r"per variant or per dimension. Each value is fixed by the quantity it "
        r"protects rather than by a search on the outcome: $M=256$ is the "
        r"horizon over which the response surface is still treated as "
        r"stationary, and it is a small fraction of the candidates one run "
        r"produces at $D=30$; $b=1.2$ is the bandwidth at which the kernel's "
        r"effective support covers the interquartile range of the descriptor "
        r"coordinates measured on the pilot cells; $k_{\max}$ caps the cost of "
        r"one decision and $n_{\min}$ is the number of records below which the "
        r"estimate is not trusted at all. None of these was tuned against the "
        r"result of Section 4, and no sensitivity scan is reported here, so the "
        r"negative result is conditional on this configuration; the scan of the "
        r"margin and of the exploration rate is the first item of the follow-up "
        r"work summarised in the data release. The model is non-parametric in the "
        r"sense that it has no "
        r"training phase, no gradient step and no parametric form for the "
        r"response surface, it is a decaying, locally weighted record of "
        r"what the search has already observed.")
    P.para(
        r"One property of that record bounds what the estimate can mean. "
        r"The buffer retains only the "
        r"last $M$ triples, so the model is local in time as well as in "
        r"descriptor space; kernel regression assumes that the response "
        r"surface is approximately stationary inside the neighbourhood it "
        r"averages over, and here that assumption is an approximation "
        r"rather than a fact, because the search state drifts across a run "
        r"even after normalisation. The discussion of exploration in Section 3.4 "
        r"states what this implies for the interpretation of $\hat r$.")
    P.para(
        r"Unlike surrogate-assisted and Bayesian optimisation "
        r"[@BO_TUTORIAL][@BO_INFO][@GP_UCB][@GPML], the model is also not a "
        r"surrogate of $f$: "
        r"it never predicts a fitness value for use in place of an "
        r"evaluation, and no candidate is pre-screened with it. Its only "
        r"role is to rank \emph{corrections of the current candidate} by "
        r"their expected effect, which is a substantially weaker and "
        r"correspondingly cheaper requirement.")

    # --------------------------------------------------------------
    P.h2("3.4  M3: minimal correction")

    P.para(
        r"\textbf{Action space.} The layer modifies a displacement through one "
        r"of five maps. These are deliberately elementary, contraction, "
        r"expansion and reflection are the classical moves of the "
        r"Nelder-Mead simplex [@NELDERMEAD65] and step doubling/halving is "
        r"the mesh update of a direct-search method [@MADS06].")
    P.para(
        r"The estimator is a one-dimensional kernel smoother with a shrinkage "
        r"prior, and its behaviour is that of any local smoother: bandwidth "
        r"and sample size trade bias against variance [@BISHOP06], the "
        r"neighbourhoods are small enough that influence diagnostics rather "
        r"than global fit determine the estimate [@COOK77], and the values it "
        r"produces are consumed as ranks rather than as calibrated "
        r"probabilities, so no resampling scheme is needed to validate it "
        r"[@STONE74]. The implementation is a few dozen lines of vectorised "
        r"code over the ring buffer, with the same interface for every host "
        r"and no dependency beyond NumPy, in the spirit of the lightweight "
        r"library implementations of standard learners [@PEDREGOSA11]. "
        r"Because the buffer keeps only its most recent entries, the record "
        r"behaves like a sliding-window learner rather than a batch fit, and "
        r"the non-stationarity it faces is the one studied under concept drift "
        r"[@DRIFT14]; fitting a global model to the whole run instead, whether "
        r"a tree ensemble [@BREIMAN01] or a Gaussian process [@GPML], was "
        r"rejected because both its cost and its extrapolation behaviour are "
        r"worse at the sample sizes a single run provides.")
    P.equation(
        r"\mathcal{A}=\{I,\,C,\,E,\,R,\,P\}:\qquad "
        r"\begin{array}{ll}"
        r"T_{I}(d)=d, & \text{identity,}\\ "
        r"T_{C}(d)=\alpha d,\; \alpha=0.5, & \text{contraction,}\\ "
        r"T_{E}(d)=\beta d,\; \beta=1.6, & \text{expansion,}\\ "
        r"T_{R}(d)=-d, & \text{reflection,}\\ "
        r"T_{P}(d)=\lVert d\rVert\,\dfrac{(1-m)q+m\hat s_t}"
        r"{\lVert(1-m)q+m\hat s_t\rVert}, & \text{projection,}"
        r"\end{array}")
    P.para(
        r"with $m=0.5$. Writing $q^{\prime}=\mathrm{normalise}\bigl((1-m)q"
        r"+m\hat s_t\bigr)$ for the rotated direction, the projection is "
        r"$T_P(d)=\lVert d\rVert q^{\prime}$: it rotates the candidate "
        r"towards the learned success direction while preserving its length, "
        r"so that the layer can change \emph{where} the step points without "
        r"changing \emph{how far} it goes. If $\hat s_t$ is still undefined, "
        r"or if $\lVert(1-m)q+m\hat s_t\rVert<\epsilon$, the projection "
        r"degenerates to the identity, which is the same fallback the "
        r"implementation uses. Contraction and expansion preserve the "
        r"direction ($q^{\prime}=q$) and change only the length; reflection "
        r"gives $q^{\prime}=-q$.")
    P.para(
        r"Every element of $\mathcal{A}$ returns a vector in the plane "
        r"spanned by $d$ and $\hat s_t$: contraction, expansion and "
        r"reflection keep the correction on the line through $d$, projection "
        r"rotates it inside that plane, and the identity fixes both factors. "
        r"No action can therefore introduce a coordinate that the variant did "
        r"not already propose, and a correction is fully described by three "
        r"numbers, the new length, the sign and the angle with $\hat s_t$, "
        r"which is the sense in which the descriptor of Section 3.2 is a "
        r"coordinate system for this space. The cost of the projection is the "
        r"chord of that angle, $\lVert q^{\prime}-q\rVert=2\sin(\phi/2)$ for "
        r"$\phi=\arccos\langle q,q^{\prime}\rangle$, and this is the only "
        r"action whose cost depends on the candidate rather than being a "
        r"fixed constant $0.5$, $0.6$ or $2$.")

    P.para(
        r"\textbf{Minimal intervention.} The design principle is that the layer "
        r"should distort the variant as little as possible while still "
        r"improving the candidate. Writing the correction as "
        r"$\delta=\tilde u-u$, the objective is")
    P.equation(
        r"\min_{a\in\mathcal{A}}\;\;\underbrace{"
        r"\frac{\lVert T_a(d)-d\rVert}{\lVert d\rVert}}_{c(a)\;:\;"
        r"\text{intervention cost}}"
        r"\qquad\text{s.t.}\qquad "
        r"\hat r\bigl(z,\,a\bigr)>\hat r\bigl(z,\,I\bigr).")
    P.para(
        r"Because $c(I)=0$, $c(C)=1-\alpha=0.5$, $c(E)=\beta-1=0.6$, "
        r"$c(R)=2$ and $c(P)=\lVert q^{\prime}-q\rVert$, the constrained "
        r"problem is replaced by the scalarised relaxation")
    P.equation(
        r"Q(z,a)=\hat r(z,a)\;-\;\lambda\,c(a)\;-\;"
        r"\frac{\kappa_u}{\sqrt{1+n_{\mathrm{eff}}(z,a)}}"
        r"\;+\;\underbrace{\mu_t\,\mathbb{1}[a=I]}"
        r"_{\text{identity bonus}},")
    P.para(
        r"and the layer applies $a^{\star}=\mathrm{argmax}_"
        r"{a\in\mathcal{A}}"
        r"Q(z,a)$. This is a relaxation and not an equivalent "
        r"reformulation: the scalarisation replaces the hard constraint by a "
        r"penalty, so the selected action maximises $Q$ and is not "
        r"guaranteed to satisfy $\hat r(z,a)>\hat r(z,I)$ in every case. We "
        r"use this form for two reasons. The constrained problem has no "
        r"feasible non-identity action whenever every correction looks "
        r"unprofitable, and a hard constraint gives no answer in that case, "
        r"whereas the penalty always does; and with a noisy $\hat r$ a hard "
        r"constraint would be decided by whichever action happened to be "
        r"estimated a little higher, while the penalty degrades smoothly.")
    P.para(
        r"The scalar $Q(z,a)$ assembles four pieces of evidence into the "
        r"layer's verdict on whether a correction is worth making to this "
        r"candidate: the predicted benefit, the "
        r"intervention cost, the uncertainty of the prediction, and the "
        r"preference for leaving the variant alone. The three terms beyond the "
        r"predicted response have distinct roles. The cost term "
        r"$\lambda c(a)$ with $\lambda=0.9$ implements the "
        r"minimal-distortion objective: among corrections of comparable "
        r"predicted value the cheaper one wins, and a correction must beat "
        r"the identity by at least $\lambda c(a)$ before it is worth its "
        r"distortion. The scales are deliberately comparable: $r$ and hence "
        r"$\hat r$ live on $[-1,1]$ while $c(R)=2$, so a reflection must "
        r"promise about $1.8$ in predicted response before it is selected, "
        r"the most disruptive action is the hardest to trigger. The "
        r"uncertainty term with $\kappa_u=0.35$ penalises actions whose "
        r"kernel neighbourhood contains little evidence, so the layer does "
        r"not act "
        r"on noise. The identity bonus is the margin that makes "
        r"\emph{doing nothing} the default, and is what distinguishes a "
        r"correction layer from a search operator.")
    P.para(
        r"Selecting among the five maps is a sequential decision under "
        r"uncertainty with an immediate and cheap reward, which is formally a "
        r"bandit problem [@LATTIMORE20]: each action returns an estimate "
        r"whose error shrinks as it is used, and the layer faces the "
        r"exploration-exploitation trade that upper-confidence rules resolve "
        r"in the multi-armed case [@AUER02]. The construction keeps that trade "
        r"implicit rather than solving it in closed form: the shrinkage term "
        r"of Section 3.3 supplies the optimism that a confidence bound would "
        r"supply explicitly, and the reward is the normalised response rather "
        r"than a Bernoulli success, so the usual regret bounds do not carry "
        r"over unchanged. The difference from the mature sequential-decision "
        r"literature is one of scope rather than of principle. Bayesian "
        r"optimisation and its bandit variants optimise the value of the next "
        r"evaluation and therefore need a surrogate of $f$ "
        r"[@BO_TUTORIAL][@SHAHRIARI16]; reinforcement-learning controllers "
        r"optimise a return over a long horizon [@SUTTON18]; meta-learned "
        r"update rules are fitted across a distribution of tasks "
        r"[@HOSPEDALES22]. Here the horizon is a single candidate and the "
        r"model is refitted from the run itself. Learning to choose among "
        r"algorithms has been studied for combinatorial problems with "
        r"supervised data and the same online difficulty [@BENGIO21], and the "
        r"automated-machine-learning framing of the question, which component "
        r"to configure and when, is a fair description of what the layer does "
        r"and does not attempt [@HUTTER19].")
    P.para(
        r"The margin is not a constant. Let $\bar r_I$ be an exponentially "
        r"weighted mean of the responses obtained by the identity action, "
        r"initialised at $0$ and updated with rate $\gamma_I=0.02$ on every "
        r"candidate that is evaluated unchanged, that is whenever the action "
        r"finally executed is the identity, including the exploration "
        r"draws that happen to select it and the feasibility fallbacks:")
    P.equation(
        r"\bar r_I\leftarrow(1-\gamma_I)\bar r_I+\gamma_I r_i,"
        r"\qquad \mu_t=\mu_0+\mu_1\max\bigl(0,\;\bar r_I\bigr),"
        r"\qquad \mu_0=0.20,\;\mu_1=0.60 .")
    P.para(
        r"This quantity is the layer's own running estimate of how well the "
        r"variant is doing by itself, and it raises the bar for intervening "
        r"exactly when the variant does not need help. It is the mechanism that "
        r"turns Property 3 from a statement about the absence of evidence "
        r"into a statement about evidence of adequacy: the layer refrains "
        r"not only when it knows nothing, but also when it observes that the "
        r"variant's candidates are already productive. Setting $\mu_1$ to zero "
        r"would disable this restraint and correct whenever a transform looks "
        r"mildly better than doing nothing, the behaviour that damaged "
        r"adaptive variants in our first experiment and motivated this term.")

    P.para(
        r"\textbf{Exploration and the interpretation of the estimate.} "
        r"Exploration is a learning detail rather than a design goal: its "
        r"only job is to keep the response estimates alive so that the "
        r"correction rule of the minimal-intervention design Eq. (21) has data "
        r"to learn from. "
        r"Estimating $\hat r(z,a)$ for $a\neq I$ requires data in which a "
        r"non-identity action was actually applied, which the greedy rule "
        r"of Eq. (21) would never generate once the identity is preferred. The "
        r"layer therefore draws a random action with probability")
    P.equation(
        r"\varepsilon_t=\varepsilon_{\min}+"
        r"(\varepsilon_0-\varepsilon_{\min})\max\!\left(0,\,"
        r"1-\frac{t}{T_{\varepsilon}}\right),")
    P.para(
        r"with $\varepsilon_0=0.15$, $\varepsilon_{\min}=0$ and "
        r"$T_{\varepsilon}=60$ generations, so that exploration is "
        r"confined to the early phase and vanishes before the run enters "
        r"its convergent stage. Two design details matter. First, "
        r"exploration covers the \emph{whole} action set, the identity "
        r"included: if only non-identity actions were explored, the "
        r"response estimate of the identity would freeze at its early-run "
        r"value, and any action that happened to look good once would then "
        r"be re-selected "
        r"indefinitely, a positive feedback loop that drives the "
        r"intervention rate towards one and turns the layer into an "
        r"uncontrolled operator. Second, the draw is \emph{weighted} rather "
        r"than uniform, $a_i\sim\mathrm{Categorical}(w_{\mathrm{expl}})$ "
        r"with $w_{\mathrm{expl}}=(0.30,0.25,0.20,0.10,0.15)$ over "
        r"$(I,C,E,R,P)$: the identity is sampled most often because it is "
        r"the action whose estimate must stay alive, and reflection is "
        r"sampled "
        r"least because it is the most disruptive of a candidate that is "
        r"already good. Setting $\varepsilon_{\min}>0$ keeps exploration "
        r"alive throughout the run; we found that this measurably damages "
        r"variants that converge to a basin and then refine inside it, which is "
        r"why the exploration rate is taken to zero.")
    P.para(
        r"Exploration changes \emph{where} the evaluation budget is spent, "
        r"never how much of it: exactly one candidate is evaluated per target "
        r"vector in every generation, so the evaluation accounting of "
        r"$C H$ is identical to that of $H$.")
    P.para(
        r"Exploration supplies the data, and the correction decision rests "
        r"on the interpretation of that data. The response model has the "
        r"following reading. $\hat r(z,a)$ predicts the average response "
        r"that was observed in the past when "
        r"action $a$ was applied to candidates whose descriptor was close to "
        r"$z$, and the decision compares this prediction against the "
        r"do-nothing alternative for the \emph{same} $z$. It is a "
        r"\emph{quasi}-counterfactual estimate in the population sense, not "
        r"a counterfactual one: a strictly counterfactual evaluation would "
        r"require evaluating $x_i+\alpha d_i$ in addition to $x_i+d_i$, "
        r"which would break the zero-overhead property of Property 2.")
    P.para(
        r"Two "
        r"consequences follow, and they bound the claim. First, the estimate "
        r"requires not that both actions be evaluated on the same candidate "
        r"but that exploration supply coverage of all actions across the "
        r"descriptor space, so that the comparison between actions rests on "
        r"data "
        r"rather than on assumption. Second, the estimate is a conditional "
        r"mean over a "
        r"neighbourhood that is itself drifting (Section 3.3), a systematic "
        r"change in the descriptor distribution inside that neighbourhood, "
        r"which is exactly what the layer induces once it begins to act on "
        r"the variant, biases the comparison. The minimal-intervention "
        r"principle keeps that effect small by keeping the intervention "
        r"rate low; it does not remove it.")

    P.para(
        r"\textbf{Feasibility.} A corrected candidate may leave the box "
        r"$[L,U]\subset\mathbb{R}^D$. Rather than clipping, which would silently "
        r"change the direction of "
        r"the step, the layer rescales the step by the largest factor that "
        r"keeps it feasible. Writing $g=T_a(d)$ for the corrected "
        r"displacement, the largest admissible factor along coordinate $j$ "
        r"is $(U_j-x_j)/g_j$ when the step moves upwards ($g_j>0$) and "
        r"$(L_j-x_j)/g_j$ when it moves downwards ($g_j<0$); coordinates "
        r"with $g_j=0$ cannot leave the box along that axis and are "
        r"ignored. The shrink factor is therefore")
    P.equation(
        r"\tau=\min\Bigl(1,\;\min_{j:\,g_j>0}\frac{U_j-x_j}{g_j},"
        r"\;\min_{j:\,g_j<0}\frac{L_j-x_j}{g_j}\Bigr),"
        r"\qquad \tilde u=x+\tau\,g ,")
    P.para(
        r"clipped to $[0,1]$, so that $\tau=1$ whenever the corrected "
        r"candidate is already feasible and no coordinate is ever moved. If "
        r"the required shrink is severe ($\tau<0.5$), the geometry of the "
        r"intended correction has been destroyed by the boundary and the "
        r"layer falls back to the identity, returning the variant's own "
        r"candidate $u$ and recording $a=I$; the variant then applies whatever "
        r"bound handling it applies to its own candidates, so the fallback "
        r"never introduces a point that the variant would not have evaluated "
        r"anyway. This is the same spirit as classical bound-constraint "
        r"repair, but here the repair is a fallback of last resort rather "
        r"than the mechanism itself.")
    P.para(
        f"Figure {P.fig_no + 1} draws the five maps and the fallback together: "
        r"identity returns the candidate, contraction and expansion keep the "
        r"direction and change its length, reflection reverses it, and "
        r"projection rotates the step into the learned success direction while "
        r"preserving its length. The lower panels give the flow that follows "
        r"once an action is chosen, and the shrink along the chosen direction, "
        r"which is where feasibility is restored without clipping a single "
        r"coordinate, and which is why the correction keeps its geometry up to "
        r"a scale and falls back to the identity rather than to a repair.")
    P.figure(
        PFG.fig('schematic_actions'),
        r"The five actions and the feasibility fallback: (a) identity, "
        r"$T_I(d)=d$; (b) contraction, $T_C(d)=0.5d$; (c) expansion, "
        r"$T_E(d)=1.6d$; (d) reflection, $T_R(d)=-d$; (e) projection onto the "
        r"success direction, $q'=\mathrm{normalise}(0.5q+0.5s)$ and "
        r"$T_P(d)=\lVert d\rVert q'$. Below: the flow after an action is "
        r"chosen, in which a severe shrink ($\tau<0.5$) falls back to the "
        r"identity, and the shrink along the chosen direction, which preserves "
        r"the direction and never clips coordinates.",
        note="Framework diagram supplied as artwork; the actions are defined "
             "in Eq. (24) and the fallback in the text that follows it.")

    P.algorithm("One generation of the variant $H$ wrapped by UPCL", [
        r"Require: variant $H$, population $X_t$, fitness $f(X_t)$, "
        r"memory $\mathcal{M}$",
        r"$s_t,\sigma_t,x_t^{\star}\leftarrow$ population statistics of "
        r"$(X_t,f(X_t))$      # once per generation",
        r"for $i=1$ to $N$ do",
        r"    $u_i\leftarrow H(x_i,S_t)$          # variant emits a candidate",
        r"    $d_i\leftarrow u_i-x_i$",
        r"    if $\lVert d_i\rVert<\delta_{\mathrm{min}}$ then evaluate "
        r"$u_i$; continue",
        r"    $q_i\leftarrow d_i/\lVert d_i\rVert$;  "
        r"$z_i\leftarrow$ descriptor of $(x_i,d_i)$      # Section 3.2",
        r"    with probability $\varepsilon_t$:  "
        r"$a_i\sim\mathrm{Categorical}(w_{\mathrm{expl}})$",
        r"    else:  $a_i\leftarrow\mathrm{argmax}_{a\in\mathcal{A}}"
        r"Q(z_i,a)$",
        r"    $g_i,q_i^{\prime}\leftarrow T_{a_i}(d_i,q_i)$",
        r"    $\tilde u_i,\tau\leftarrow$ box-shrink$(x_i,g_i)$",
        r"    if $a_i\neq I$ and $\tau<0.5$ then "
        r"$a_i\leftarrow I$; $\tilde u_i\leftarrow u_i$; "
        r"$q_i^{\prime}\leftarrow q_i$",
        r"    evaluate $\tilde u_i$      # ONE evaluation, as in $H$",
        r"    $r_i\leftarrow\tanh\bigl((f(x_i)-f(\tilde u_i))"
        r"/(\sigma_t+\epsilon)\bigr)$",
        r"    store $(z_i,a_i,r_i)$ in $\mathcal{M}$; refresh prototypes "
        r"with $q_i$",
        r"    if $a_i=I$ then update $\bar r_I$",
        r"    if $r_i>0$ then update $\hat s$ with $q_i^{\prime}$      "
        r"# Section 3.2",
        r"    variant selection and variant memory update on $(x_i,\tilde u_i)$",
        r"end for",
    ])

    # --------------------------------------------------------------
    P.h2("3.5  Properties of the construction")

    P.para(
        r"Three properties follow directly from the construction of Sections "
        r"3.1-3.3; the "
        r"fourth item of this section is an empirical diagnostic derived "
        r"from the same construction rather than a guarantee it provides. "
        r"They are collected here in one place because together they are what "
        r"separates the candidate generation stage from the component level.")

    P.para(
        r"\textbf{Property 1 (Opacity).} The information set of $C_t$ is "
        r"$\mathcal{I}_t=\{X_t,\,f(X_t),\,u_i^t,\,f(\tilde u_i^t)\}$ "
        r"together with its own memory, where $\tilde u_i^t$ is the "
        r"\emph{corrected} candidate, the one that is actually evaluated. It "
        r"excludes $F$, $CR$, the archive, the mutation-strategy index, the "
        r"population-size schedule and all variant-side success memories. "
        r"Consequently $C_t$ is well defined for any variant that emits a "
        r"candidate, including variants whose internal design is unknown to it.")
    P.para(
        r"\textbf{Property 2 (Zero evaluation overhead).} For every "
        r"generation the composite system performs exactly $N$ evaluations, "
        r"the same as the variant. The layer substitutes one candidate for "
        r"another; it does not add candidates. Any paired comparison between "
        r"$H$ and $C H$ is therefore budget-matched by construction.")
    P.para(
        r"\textbf{Property 3 (Identity-safe).} Fix a descriptor $z$ and let "
        r"an action $a\neq I$ have no evidence, in the sense that its "
        r"sub-buffer is empty, $\mathcal{M}_a=\emptyset$; then "
        r"$\hat r(z,a)=0$ and $n_{\mathrm{eff}}(z,a)=0$ by construction, so "
        r"$Q(z,a)=-\lambda c(a)-\kappa_u$. If in addition the identity has "
        r"no evidence either, $Q(z,I)=-\kappa_u+\mu_t$, because the identity "
        r"pays no cost and collects the bonus. Hence")
    P.equation(
        r"Q(z,a)-Q(z,I)=-\lambda\,c(a)-\mu_t\;\leq\;-\mu_0\;<\;0 ,")
    P.para(
        r"using $c(a)\geq0$ and $\mu_t\geq\mu_0=0.20$, so the identity "
        r"wins. Note that the two uncertainty terms cancel and that it is "
        r"the bonus, not the absence of evidence alone, that makes the "
        r"inequality strict: an identity with no evidence still scores "
        r"higher than an unevidenced correction, which is the property an "
        r"identity-safe layer has to have. Consequently, whenever no "
        r"non-identity action is supported by evidence, $C_t$ is the "
        r"identity and $C H=H$. The worst case of an uninformative "
        r"layer is therefore the unmodified variant, not a damaged one. "
        r"This is a statement about the uninformative branch only: where the "
        r"response model does hold evidence, Property 3 constrains the "
        r"decision, not the sign of the realised effect, which is negative "
        r"whenever the estimate is wrong. The property is therefore not a "
        r"bound on the measured gain, and Section 4 reports the realised "
        r"distribution rather than relying on it. "
        r"(If the identity has evidence and a correction does not, the "
        r"conclusion is the same a fortiori: $\hat r(z,I)\geq0$ and "
        r"$c(I)=0$ both work in favour of the identity.)")
    P.para(
        r"\textbf{Empirical property 4 (Intervention rate as a "
        r"diagnostic).} Define the policy intervention rate")
    P.equation(
        r"\rho_t=\frac{1}{N}\sum_{i=1}^{N}\mathbb{1}\bigl[a_i"
        r"\neq I\bigr],")
    P.para(
        r"over the candidates of generation $t$, where $a_i$ is the action "
        r"finally executed after the feasibility fallback of Section 3.4, "
        r"and exploration draws are excluded. Unlike Properties 1-3 this is "
        r"not a consequence of the construction: it is an observable of the "
        r"decision rule, and Property 3 fixes only its uninformative limit, "
        r"$\rho_t=0$ when no action has evidence. The claim we make is that "
        r"$\rho_t$ rises only when the response model finds systematic "
        r"evidence that the variant's candidates can be improved, so that "
        r"$\rho_t\to0$ is the expected behaviour on a variant that is already "
        r"well matched to the problem, and a persistently large $\rho_t$ "
        r"indicates a variant whose candidates are consistently improvable. "
        r"This turns $\rho_t$ from a tuning coefficient into a measurable "
        r"diagnostic; combined with the descriptor contrasts reported in "
        r"Section 4.4 it constitutes the mechanism fingerprint assigned to "
        r"each variant. It is a hypothesis about the behaviour of the rule, and "
        r"Section 4.4 tests it.")
    P.table_caption(
        'The three observables the layer lands on a variant, and the bare '
        'ranking they are read against. "Symbol" is the notation used in '
        'Sections 4 and 5, "Range" the interval each reading lives on, and '
        '"What it establishes" what a value of it can and cannot support.')
    P.table(
        header=['Observable', 'Symbol', 'Definition', 'Range',
                'What it establishes'],
        rows=[
            ['Intervention rate', r'$\bar\rho$',
             'share of candidates the layer rewrites, averaged over '
             'generations and runs',
             '0 to 1',
             'how much improvable slack the variant leaves at the candidate '
             'stage; zero means the layer declined to act'],
            ['Intervention gain', r'$\mathrm{dec}$, $\mathrm{ri}$',
             'paired difference in final error, variant with the layer minus '
             'the variant alone',
             r'decades of $\log_{10}$ error; negative is a gain',
             'what that slack is worth once it is recovered, at a fixed '
             'evaluation budget'],
            ['Descriptor contrast', r'$\Delta\phi_k$',
             'standardised shift of candidate feature $k$, interventions the '
             'layer accepts minus those it rejects',
             r'in units of the feature deviation $\sigma_k$',
             'which geometric condition makes a candidate improvable'],
            ['Bare ranking', 'rank',
             'position of the variant by bare error on the same suite and '
             'seeds',
             '1 to 29',
             'the baseline the other three readings are compared against'],
        ],
        widths=[0.98, 0.60, 1.92, 1.06, 1.94],
        font_size=7.4, align='l c l l l', keep_together=True)

    P.para(
        r"Taken together, Properties 1-4 fix the quantities through which "
        r"the instrument reads a variant, and these are the quantities Section "
        r"4.4 reports. The intervention rate $\bar\rho$ is the variant- and "
        r"run-averaged value of $\rho_t$: it measures how much improvable "
        r"slack the variant leaves at the candidate generation stage. The intervention gain "
        r"is the paired difference in final error between the variant with UPCL "
        r"and the variant alone, and it measures how much that slack is worth "
        r"once it is recovered. The descriptor contrast is the shift in the "
        r"candidate features between the interventions the layer accepts and "
        r"those it rejects, and it localises the geometric conditions under "
        r"which a candidate is improvable. Together with the bare ranking of "
        r"the variants, these three observables carry the mechanism fingerprint "
        r"through which Section 4 answers RQ1-RQ4: which mechanisms steer "
        r"the search (RQ1), whether the steering depends on the problem "
        r"(RQ2), which mechanisms are substitutable or redundant (RQ3), and "
        r"why modern DE is hard to improve (RQ4).")

    P.para(
        r"Because the variant records the outcome of $\tilde u_i$ in "
        r"its own success memory while attributing it to the parameter pair "
        r"$(F,CR)$ it sampled, the layer introduces an \emph{attribution "
        r"shift}: the variant's parameter memory is updated with a reward that "
        r"was partly produced by the layer. The layer cannot correct this "
        r"without reading the variant's memory, which would violate Property 1. "
        r"The minimal-intervention principle is what keeps the effect small: "
        r"the shift is expected to grow with the intervention rate "
        r"$\rho_t$ and with the size of the corrections applied. Section 4.3 "
        r"checks empirically that variants with strong internal adaptation, "
        r"whose memories are the most exposed to this effect, are not "
        r"degraded.")

    # --------------------------------------------------------------
    P.h2("3.6  Algorithmic statement and cost")

    P.para(
        r"Algorithm 2 summarises one generation, and this subsection records "
        r"its cost. Two aspects should be distinguished: per-generation work "
        r"and per-candidate work. The population statistics $s_t$, "
        r"$\sigma_t$, $x_t^{\star}$ and the reference points are computed "
        r"once per generation and not per candidate, at "
        r"$O(n_{\mathrm{ref}}^{2}D)$ and $O(ND)$. Each candidate then costs "
        r"$O(D)$ for the displacement and its direction, "
        r"$O(n_{\mathrm{proto}}D)$ for the novelty term and "
        r"$O(n_{\mathrm{ref}}D)$ for the crowding term, plus "
        r"$O(|\mathcal{A}|M d_z)$ for the five memory queries. The total is")
    P.equation(
        r"O\Bigl(n_{\mathrm{ref}}^{2}D+N\bigl(D+n_{\mathrm{proto}}D"
        r"+n_{\mathrm{ref}}D+|\mathcal{A}|\,M\,d_z\bigr)\Bigr),")
    P.para(
        r"which with $M=256$, $d_z=5$, $|\mathcal{A}|=5$, "
        r"$n_{\mathrm{proto}}=8$ and $n_{\mathrm{ref}}=32$ is dominated by "
        r"the $6.4\times10^{3}$ operations of the memory queries, small "
        r"against the $O(ND)$ the variant already spends and negligible "
        r"against any objective of practical interest. Memory is "
        r"$O(Md_z+n_{\mathrm{proto}}D+n_{\mathrm{ref}}D+D)$: the response "
        r"buffer, the prototypes, the reference points and the two running "
        r"directions $\hat s_t$ and the per-action means. The layer adds no "
        r"second population, no archive and no model training step, so it "
        r"does not alter the memory profile of the variant.")
    P.para(
        r"Two points about this accounting bear on the reading of Sections 4 "
        r"and 5. The first is that the cost is stated in operations rather "
        r"than in objective evaluations: the layer never calls $F$, so the "
        r"evaluation budget of the variant is preserved exactly and a paired "
        r"comparison cannot be confounded by one arm spending more of it. The "
        r"second is that the overhead is a fixed per-candidate cost which does "
        r"not grow with the population, the archive or the generation count of "
        r"the variant. A constant is not the same as a negligible one: measured "
        r"over the four blocks, the wrapped run takes a median $71\%$ longer in "
        r"wall-clock time than the bare run (median rise $38\%$ to $87\%$ "
        r"across blocks, $95$th percentile $218\%$, worst cell $2251\%$), and "
        r"the decision accounts for a median $34\%$ of the total. The layer "
        r"therefore buys its zero evaluation cost with a wall-clock cost of the "
        r"same order as the variant\'s own bookkeeping, and on these suites, "
        r"where the objective is cheap at $D=10$ to $50$, that constant is "
        r"comparable with the evaluation cost rather than dominated by it. The "
        r"figures of Section 4 were obtained at that price. Had the layer needed a second "
        r"population, an archive or a training phase, the comparison of memory "
        r"profiles would no longer be available and the fingerprint of "
        r"Section 2 would not be interpretable; the claim of Section 3.5 is "
        r"that it needs none of them. What is left is an overhead invisible to "
        r"the variant in everything except the candidates it is asked to "
        r"select among, which is the intended effect of an instrument.")
    P.figure(
        PFG.fig('schematic_hierarchy'),
        'Intervention mechanisms on two axes: fit to an opaque variant (no '
        'access to its internal state) and added function evaluations; the '
        'layer sits in the top-right quadrant, which the prior literature '
        'leaves empty.',
        note='Positioning diagram supplied as artwork; the placements are '
             'qualitative.')

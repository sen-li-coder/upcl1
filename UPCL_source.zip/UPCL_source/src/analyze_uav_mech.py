# -*- coding: utf-8 -*-
"""§5.4 机制归因：UAV 指标差分 → 六维机制拆分（RQ5.3）。

复用 §4 的六维机制标签（``analyze_mech30.MECH/LEVELS/ORDER``）与统计机器
（``analyze_mech_attribution.kruskal_eta2``），把因变量从 CEC 的 ``dec``
（log10 误差增益）换成 **6 组任务指标差分 gain**（方向归一化，>0 = full 更好），
回答「哪个机制维度驱动哪个指标组的差分」。

产出（``results/apps/tables/``）：
    uav_mech_host_gain.csv  每宿主在 6 指标组上的 median gain + 六维标签
    uav_mech_eta2.csv       机制维度 × 指标组 的 η²（Kruskal-Wallis 效应量）
"""
import argparse
import csv
import sys
from pathlib import Path
from collections import defaultdict

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import analyze_uav as AU                       # noqa: E402
import analyze_mech30 as M30                    # noqa: E402 (MECH/LEVELS/ORDER)
from analyze_mech_attribution import (          # noqa: E402
    FACTORS, kruskal_eta2,
)

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'

# 6 组任务指标（master 文档 §5.1 表 5-2）
METRIC_GROUPS = {
    'task':       ['composite_pct', 'base_destroyed', 'n_arrived', 'base_hp'],
    'safety':     ['n_lost', 'min_dist', 'first_capture', 'risk_time'],
    'path':       ['path_length', 'flight_time', 'path_efficiency', 'curvature',
                   'climb'],
    'constraint': ['bounds_steps', 'nofly_steps', 'n_crashed'],
    'infantry':   ['n_inf_arrived', 'n_inf_lost', 'infantry_alive',
                   'infantry_survival', 'infantry_avg_hp', 'infantry_hp_total',
                   'n_patrol_killed'],
    'patrol':     ['patrol_alive', 'patrol_survival', 'patrol_avg_hp',
                   'patrol_hp_total'],
}
GROUP_ORDER = ['task', 'safety', 'path', 'constraint', 'infantry', 'patrol']


def host_group_gain(cells, scenario='intercept', dim=30, min_runs=3):
    """每宿主在 6 指标组上的 median gain（跨任务 × 跨 run 聚合）。

    先对每 (host, fid) 取组内各指标 gain 的均值，再对每 host 跨 fid 取 median。
    """
    # per-(host, fid, metric) gain，复用 analyze_uav 的 upcl_delta
    names = sorted({n for g in METRIC_GROUPS.values() for n in g})
    delta_rows = AU.upcl_delta(cells, names)
    # (host, fid, group) -> [gain per metric]
    acc = defaultdict(list)
    for r in delta_rows:
        if r['scenario'] != scenario or r['dim'] != dim:
            continue
        for g, members in METRIC_GROUPS.items():
            if r['metric'] in members:
                acc[(r['host'], r['fid'], g)].append(r['gain'])
    # (host, group) -> [per-fid mean gain]
    host_group = defaultdict(lambda: defaultdict(list))
    for (host, fid, g), vals in acc.items():
        if vals:
            host_group[host][g].append(float(np.mean(vals)))
    out = {}
    for host, gd in host_group.items():
        row = {g: float(np.median(v)) for g, v in gd.items() if v}
        if len(row) == len(METRIC_GROUPS):
            out[host] = row
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept')
    ap.add_argument('--dim', type=int, default=30)
    ap.add_argument('--min-runs', type=int, default=3)
    args = ap.parse_args(argv)

    cells = AU.load_cells(scenario=args.scenario, min_runs=args.min_runs)
    if not cells:
        print('[analyze_uav_mech] no UAV cells found; run analyze_uav first.')
        return

    hg = host_group_gain(cells, args.scenario, args.dim, args.min_runs)
    if len(hg) < 3:
        print(f'[analyze_uav_mech] too few hosts ({len(hg)}), abort.')
        return

    hosts = sorted(hg)
    TAB.mkdir(parents=True, exist_ok=True)

    # --- 宿主级 gain + 六维标签 ----------------------------------------
    with open(TAB / 'uav_mech_host_gain.csv', 'w', newline='', encoding='utf-8') as fh:
        fields = ['host', 'level'] + GROUP_ORDER + \
                 ['mutation', 'param', 'strategy', 'archive', 'pop', 'other']
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        for h in hosts:
            row = {'host': h, 'level': M30.LEVELS.get(h, -1)}
            for g in GROUP_ORDER:
                row[g] = round(hg[h][g], 5)
            row.update(M30.MECH.get(h, {}))
            w.writerow(row)

    # --- 机制维度 × 指标组 η² -------------------------------------------
    rows = []
    for fname in FACTORS:
        fn = FACTORS[fname]
        for g in GROUP_ORDER:
            groups = defaultdict(list)
            for h in hosts:
                mech = M30.MECH.get(h, {})
                key = fn(mech)
                groups[key].append(hg[h][g])
            gs = [np.asarray(v, float) for v in groups.values() if len(v) >= 2]
            H, eta2, p = kruskal_eta2(gs)
            rows.append(dict(dimension=fname, metric_group=g, k=len(gs),
                             H=round(H, 4) if np.isfinite(H) else '',
                             eta2=round(eta2, 5), p=round(p, 5)))
    with open(TAB / 'uav_mech_eta2.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['dimension', 'metric_group', 'k',
                                           'H', 'eta2', 'p'])
        w.writeheader()
        w.writerows(rows)

    print('\n=== §5.4 机制维度 × 指标组效应量 eta^2（Kruskal-Wallis；≥0.1 标 *）===')
    header = 'dimension'.ljust(16) + ''.join(f'{g:>11s}' for g in GROUP_ORDER)
    print(header)
    for fname in FACTORS:
        line = fname.ljust(16)
        for g in GROUP_ORDER:
            r = next(x for x in rows if x['dimension'] == fname
                     and x['metric_group'] == g)
            mark = '*' if r['eta2'] >= 0.1 else ' '
            line += f'{r["eta2"]:>10.3f}{mark}'
        print(line)
    print(f'[analyze_uav_mech] wrote uav_mech_host_gain.csv + uav_mech_eta2.csv '
          f'({len(hosts)} hosts)')


if __name__ == '__main__':
    main()

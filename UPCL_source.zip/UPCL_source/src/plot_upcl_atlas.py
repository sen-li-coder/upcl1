# -*- coding: utf-8 -*-
"""Mechanism figure atlas for the UPCL paper (Section 4).

Six multi-panel figures: atlas_ablation (P0), atlas_capacity_gain and
atlas_gain_dist (P1), atlas_descriptor_signal, atlas_gate,
atlas_level_gradient (P2).  Run: python src/plot_upcl_atlas.py
"""
import csv
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FIG_W = 6.3

LEVELS = [0, 1, 2, 3]
LEVEL_COLORS = {0: '#d62728', 1: '#ff7f0e', 2: '#2ca02c', 3: '#1f77b4'}
LEVEL_LABELS = {0: 'L0 fixed parameter', 1: 'L1 adaptive F/CR',
                2: 'L2 archived history', 3: 'L3 LPSR / modern'}

ARMS = ['bare', 'full', 'mem1', 'no_minimal', 'random']
ARM_COLORS = {'bare': '#999999', 'full': '#1f77b4', 'mem1': '#2ca02c',
              'no_minimal': '#d62728', 'random': '#ff7f0e'}
ARM_LABELS = {'bare': 'bare', 'full': 'full', 'mem1': 'memory 1',
              'no_minimal': 'no gate', 'random': 'random'}

DESCRIPTORS = [('rho_step_effect', 'step'), ('theta_align_effect', 'align'),
               ('eta_elite_effect', 'elite'), ('kappa_crowd_effect', 'crowd'),
               ('nu_novel_effect', 'novel')]


def _read(name):
    path = TABLES / name
    if not path.exists():
        raise SystemExit(f'missing table: {path}')
    with open(path, encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh))


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.titlesize': 8.5,
        'axes.labelsize': 8, 'axes.linewidth': 0.6, 'axes.edgecolor': '#444444',
        'xtick.color': '#333333', 'ytick.color': '#333333',
        'xtick.labelsize': 6.5, 'ytick.labelsize': 7, 'legend.fontsize': 6.5,
        'legend.frameon': False, 'figure.dpi': 300})


def _despine(ax, grid=True):
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    if grid:
        ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
        ax.set_axisbelow(True)


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[atlas] {name}')


def _legend(fig, handles):
    fig.legend(handles=handles, loc='upper center', ncol=4, frameon=False,
               bbox_to_anchor=(0.5, 0.99), handlelength=1.0, columnspacing=1.2)


def _level_legend():
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=5,
                       color=LEVEL_COLORS[lv], label=LEVEL_LABELS[lv])
            for lv in LEVELS]


# --- P0 ablation -----------------------------------------------------------
def ablation(cells, friedman):
    fig, axes = plt.subplots(1, 3, figsize=(FIG_W, 2.8))
    fig.subplots_adjust(left=0.07, right=0.98, top=0.84, bottom=0.18,
                        wspace=0.55)
    ax = axes[0]
    data = [[_f(r['dec_vs_bare']) for r in cells if r['arm'] == a] for a in ARMS]
    bp = ax.boxplot(data, vert=False, widths=0.6, patch_artist=True,
                    showfliers=False,
                    medianprops=dict(color='#111111', linewidth=1.0),
                    whiskerprops=dict(color='#888888', linewidth=0.8),
                    capprops=dict(color='#888888', linewidth=0.8))
    for patch, a in zip(bp['boxes'], ARMS):
        patch.set_facecolor(ARM_COLORS[a]); patch.set_alpha(0.55)
    ax.axvline(0, color='#666666', linewidth=0.7)
    ax.set_yticks(range(1, 6)); ax.set_yticklabels([ARM_LABELS[a] for a in ARMS])
    ax.set_xlabel('dec vs bare (decades, + better)')
    ax.set_title('a  effect of each configuration', loc='left')
    _despine(ax, grid=False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.5, alpha=0.7); ax.set_axisbelow(True)

    ax = axes[1]
    keys = [f'rank_{a}' for a in ARMS]
    means = [np.nanmean([_f(r[k]) for r in friedman]) for k in keys]
    ax.bar(range(5), means, color=[ARM_COLORS[a] for a in ARMS],
           width=0.62, alpha=0.85)
    ax.set_xticks(range(5))
    ax.set_xticklabels([ARM_LABELS[a] for a in ARMS], rotation=45, ha='right',
                       fontsize=6)
    ax.set_ylabel('Friedman mean rank')
    ax.set_title('b  mean rank (lower = better)', loc='left')
    _despine(ax)
    for i, v in enumerate(means):
        ax.text(i, v + 0.08, f'{v:.2f}', ha='center', fontsize=6.5)

    ax = axes[2]
    irates = [100.0 * np.nanmean([_f(r['intervention_rate']) for r in cells
                                  if r['arm'] == a]) for a in ARMS]
    ax.bar(range(5), irates, color=[ARM_COLORS[a] for a in ARMS],
           width=0.62, alpha=0.85)
    ax.set_xticks(range(5))
    ax.set_xticklabels([ARM_LABELS[a] for a in ARMS], rotation=45, ha='right',
                       fontsize=6)
    ax.set_ylabel('intervention rate (%)')
    ax.set_title('c  how much each intervenes', loc='left')
    _despine(ax)
    for i, v in enumerate(irates):
        ax.text(i, v + 1.5, f'{v:.0f}%', ha='center', fontsize=6.5)
    _save(fig, 'atlas_ablation.png')


# --- P1 capacity vs gain ---------------------------------------------------
def capacity_gain(hosts, cells):
    lvmap = {r['host']: int(r['level']) for r in hosts}
    fig, axes = plt.subplots(1, 2, figsize=(FIG_W, 3.1))
    fig.subplots_adjust(left=0.10, right=0.97, top=0.82, bottom=0.17, wspace=0.32)
    ax = axes[0]
    for lv in LEVELS:
        xs = [_f(r['bare_median_log10err']) for r in hosts if int(r['level']) == lv]
        ys = [_f(r['dec_mean']) for r in hosts if int(r['level']) == lv]
        ax.scatter(xs, ys, s=34, color=LEVEL_COLORS[lv], edgecolors='white',
                   linewidths=0.5, zorder=3)
    ax.axhline(0, color='#666666', linewidth=0.6, zorder=1)
    ax.set_xlabel('bare median log10 error (lower = stronger)')
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title('a  30 hosts', loc='left')
    _despine(ax)

    ax = axes[1]
    for lv in LEVELS:
        xs = [_f(r['bare_median_log10err']) for r in cells if lvmap[r['host']] == lv]
        ys = [_f(r['dec_median']) for r in cells if lvmap[r['host']] == lv]
        ax.scatter(xs, ys, s=4, color=LEVEL_COLORS[lv], alpha=0.35,
                   edgecolors='none', zorder=3)
    ax.axhline(0, color='#666666', linewidth=0.6, zorder=1)
    ax.set_xlabel('bare median log10 error (lower = stronger)')
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title('b  per-cell spread', loc='left')
    _despine(ax)
    _legend(fig, _level_legend())
    _save(fig, 'atlas_capacity_gain.png')

    rho, p = spearmanr([_f(r['bare_median_log10err']) for r in hosts],
                       [_f(r['dec_mean']) for r in hosts])
    print(f'[atlas] capacity-gain Spearman rho={rho:+.2f} p={p:.3g} (30 hosts)')


# --- P1 gain distribution ---------------------------------------------------
def gain_dist(cells, hosts):
    lvmap = {r['host']: int(r['level']) for r in hosts}
    fig, axes = plt.subplots(1, 4, figsize=(FIG_W, 2.6), sharey=True)
    fig.subplots_adjust(left=0.09, right=0.98, top=0.86, bottom=0.17, wspace=0.14)
    rng = np.random.default_rng(0)
    for lv, ax in zip(LEVELS, axes):
        vals = [v for v in (_f(r['dec_median']) for r in cells
                            if lvmap[r['host']] == lv) if np.isfinite(v)]
        bp = ax.boxplot(vals, widths=0.5, patch_artist=True, showfliers=False,
                        medianprops=dict(color='#111111', linewidth=1.0))
        for patch in bp['boxes']:
            patch.set_facecolor(LEVEL_COLORS[lv]); patch.set_alpha(0.55)
        ax.scatter(rng.uniform(-0.12, 0.12, len(vals)), vals, s=5,
                   color=LEVEL_COLORS[lv], alpha=0.25, edgecolors='none')
        ax.axhline(0, color='#666666', linewidth=0.6)
        ax.set_xticks([])
        ax.set_title(LEVEL_LABELS[lv], fontsize=6.5)
        ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
        ax.set_axisbelow(True)
        for sp in ('top', 'right'):
            ax.spines[sp].set_visible(False)
        n_neg = sum(1 for v in vals if v < 0)
        ax.text(0.5, 0.02, f'{n_neg} neg', transform=ax.transAxes, ha='center',
                va='bottom', fontsize=5.8, color='#666666')
    axes[0].set_ylabel('intervention gain (dec)')
    fig.suptitle('gain distribution by composition level', y=0.99, fontsize=8.5)
    _save(fig, 'atlas_gain_dist.png')


# --- P2 descriptor signal ---------------------------------------------------
def descriptor_signal(hosts):
    ranks = [_f(r['bare_rank']) for r in hosts]
    decs = [_f(r['dec_mean']) for r in hosts]
    fig, axes = plt.subplots(1, 2, figsize=(FIG_W, 2.5))
    fig.subplots_adjust(left=0.10, right=0.98, top=0.86, bottom=0.16, wspace=0.35)
    labels = [short for _, short in DESCRIPTORS]
    rho_rank, rho_dec = [], []
    for col, _ in DESCRIPTORS:
        vals = [_f(r[col]) for r in hosts]
        rho_rank.append(spearmanr(vals, ranks)[0])
        rho_dec.append(spearmanr(vals, decs)[0])
    x = np.arange(len(DESCRIPTORS))
    ax = axes[0]
    ax.bar(x, rho_rank, color=['#d62728' if v < 0 else '#1f77b4' for v in rho_rank],
           width=0.6)
    ax.axhline(0, color='#666666', linewidth=0.6)
    ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylabel('Spearman rho with bare rank')
    ax.set_title('a  descriptor vs performance', loc='left')
    _despine(ax)
    ax = axes[1]
    ax.bar(x, rho_dec, color=['#d62728' if v < 0 else '#1f77b4' for v in rho_dec],
           width=0.6)
    ax.axhline(0, color='#666666', linewidth=0.6)
    ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylabel('Spearman rho with gain')
    ax.set_title('b  descriptor vs gain', loc='left')
    _despine(ax)
    _save(fig, 'atlas_descriptor_signal.png')
    for lb, a, b in zip(labels, rho_rank, rho_dec):
        print(f'[atlas] descriptor {lb:6s} rho(rank)={a:+.2f} rho(dec)={b:+.2f}')


# --- P2 gate ----------------------------------------------------------------
def gate(hosts):
    pol = [_f(r['policy_rate']) for r in hosts]
    itv = [_f(r['intervention_rate']) for r in hosts]
    cols = [LEVEL_COLORS[int(r['level'])] for r in hosts]
    fig, axes = plt.subplots(1, 2, figsize=(FIG_W, 2.9))
    fig.subplots_adjust(left=0.11, right=0.97, top=0.82, bottom=0.16, wspace=0.35)
    ax = axes[0]
    ax.scatter(pol, itv, s=30, c=cols, edgecolors='white', linewidths=0.5)
    m = max(max(pol), max(itv)) * 1.05
    ax.plot([0, m], [0, m], color='#888888', linewidth=0.7, ls='--')
    ax.set_xlabel('policy rate (proposed)')
    ax.set_ylabel('intervention rate (accepted)')
    ax.set_title('a  proposal vs acceptance', loc='left')
    _despine(ax)
    ax = axes[1]
    gap = [i - p for p, i in zip(pol, itv)]
    lv = [int(r['level']) for r in hosts]
    for l in LEVELS:
        xs = [lvv for lvv, g in zip(lv, gap) if lvv == l]
        ys = [g for lvv, g in zip(lv, gap) if lvv == l]
        ax.scatter([LEVEL_LABELS[l]] * len(xs), ys, s=18, color=LEVEL_COLORS[l],
                   alpha=0.7, edgecolors='none')
    ax.axhline(0, color='#666666', linewidth=0.6)
    ax.set_ylabel('intervention - policy')
    ax.set_title('b  gate rejections by level', loc='left')
    ax.tick_params(axis='x', labelsize=6)
    _despine(ax)
    _legend(fig, _level_legend())
    _save(fig, 'atlas_gate.png')


# --- P2 level gradient ------------------------------------------------------
def level_gradient(hosts, cells):
    lvmap = {r['host']: int(r['level']) for r in hosts}
    fig, axes = plt.subplots(1, 2, figsize=(FIG_W, 2.7))
    fig.subplots_adjust(left=0.10, right=0.98, top=0.86, bottom=0.16, wspace=0.25)
    ax = axes[0]
    bare = [[_f(r['bare_median_log10err']) for r in hosts if int(r['level']) == lv]
            for lv in LEVELS]
    bp = ax.boxplot(bare, widths=0.5, patch_artist=True, showfliers=False,
                    medianprops=dict(color='#111111', linewidth=1.0))
    for patch, lv in zip(bp['boxes'], LEVELS):
        patch.set_facecolor(LEVEL_COLORS[lv]); patch.set_alpha(0.6)
    for lv in LEVELS:
        ax.scatter([lv + 1] * len(bare[lv]), bare[lv], s=18,
                   color=LEVEL_COLORS[lv], alpha=0.7, edgecolors='white',
                   linewidths=0.4)
    ax.set_xticklabels([LEVEL_LABELS[lv] for lv in LEVELS], fontsize=6.5)
    ax.set_ylabel('bare median log10 error')
    ax.set_title('a  capacity by level', loc='left')
    _despine(ax)
    ax = axes[1]
    dec = [[_f(r['dec_mean']) for r in hosts if int(r['level']) == lv]
           for lv in LEVELS]
    bp = ax.boxplot(dec, widths=0.5, patch_artist=True, showfliers=False,
                    medianprops=dict(color='#111111', linewidth=1.0))
    for patch, lv in zip(bp['boxes'], LEVELS):
        patch.set_facecolor(LEVEL_COLORS[lv]); patch.set_alpha(0.6)
    for lv in LEVELS:
        ax.scatter([lv + 1] * len(dec[lv]), dec[lv], s=18,
                   color=LEVEL_COLORS[lv], alpha=0.7, edgecolors='white',
                   linewidths=0.4)
    ax.axhline(0, color='#666666', linewidth=0.6)
    ax.set_xticklabels([LEVEL_LABELS[lv] for lv in LEVELS], fontsize=6.5)
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title('b  gain by level', loc='left')
    _despine(ax)
    _save(fig, 'atlas_level_gradient.png')


def main():
    _style()
    hosts = _read('mech30_host_summary.csv')
    cells = _read('mech30_cells.csv')
    abl = _read('exp4_ablation_cells.csv')
    fried = _read('exp4_friedman.csv')

    ablation(abl, fried)
    capacity_gain(hosts, cells)
    gain_dist(cells, hosts)
    descriptor_signal(hosts)
    gate(hosts)
    level_gradient(hosts, cells)
    print('[atlas] done ->', FIG)


if __name__ == '__main__':
    main()

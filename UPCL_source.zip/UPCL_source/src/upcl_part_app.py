# -*- coding: utf-8 -*-
"""Manuscript Part V - real-world application.

The chapter analyses how the DE variants (and the UPCL-augmented
configuration) behave on one complex real-world scenario, the UAV
adversarial-interception task, on its own terms: scenario and complexity,
algorithm input and configuration, evaluation metrics, results, and
interpretation.  Nothing is carried over from the CEC benchmark study.

All numbers are read from ``results/apps/tables`` (written by
``analyze_uav*.py``) and every figure is fetched from the paper-figure folder
``docs/figures`` through ``paper_figures`` (the renders themselves are written
into ``results/apps/figures`` by ``plot_uav*.py`` and copied across by
``python src/paper_figures.py sync``); nothing is hard-coded, so the section
regenerates as the application grid grows.
"""
import csv
from pathlib import Path

import numpy as np
from scipy import stats

import paper_figures as PFG

ROOT = Path(__file__).resolve().parents[1]
TBL = ROOT / 'results' / 'apps' / 'tables'

GROUP_ORDER = ['task', 'safety', 'path', 'constraint', 'infantry', 'patrol']
GROUP_MEANING = {
    'task': 'task accomplishment',
    'safety': 'evasion safety',
    'path': 'path quality',
    'constraint': 'constraint satisfaction',
    'infantry': 'air-ground coordination',
    'patrol': 'adversary patrol',
}
GROUP_ZH = {
    'task': '任务达成',
    'safety': '规避安全',
    'path': '路径质量',
    'constraint': '约束满足',
    'infantry': '空地协同',
    'patrol': '敌方巡逻',
}
# Representative metric of every semantic group, used by the per-task table.
# Each entry is (column stem in uav_metric_cells.csv, decimals).
KEY_METRICS = [
    ('composite_pct', 2),
    ('n_arrived', 1),
    ('n_lost', 1),
    ('min_dist', 0),
    ('path_length', 0),
    ('nofly_steps', 1),
    ('n_inf_arrived', 2),
    ('n_patrol_killed', 2),
]
KEY_METRIC_MEANING = {
    'composite_pct': 'composite success rate (%)',
    'n_arrived': 'UAVs arrived',
    'n_lost': 'UAVs lost',
    'min_dist': 'min. interceptor distance (m)',
    'path_length': 'path length (m)',
    'nofly_steps': 'no-fly steps',
    'n_inf_arrived': 'infantry arrived',
    'n_patrol_killed': 'patrol soldiers killed',
}
KEY_METRIC_ZH = {
    'composite_pct': '综合成功率（%）',
    'n_arrived': '无人机到达数',
    'n_lost': '无人机损失数',
    'min_dist': '到拦截机最小距离（m）',
    'path_length': '路径长度（m）',
    'nofly_steps': '禁飞区步数',
    'n_inf_arrived': '步兵到达数',
    'n_patrol_killed': '击杀巡逻兵数',
}


def _f(v, n=3, sign=False):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    if x != x:
        return '-'
    return f'{x:+.{n}f}' if sign else f'{x:.{n}f}'


def _rows(name):
    p = TBL / name
    if not p.exists():
        raise SystemExit(f'[UPCL-app] missing table: {p}')
    with open(p, encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh))


def _nt(P):
    return P.tab_no + 1


def task_metrics_table(labels=None):
    """Per-task rows of the key scenario metrics for both arms.

    Each cell is the median over the 29 variants, so the table summarises the
    pool on every task without singling out a variant.  ``labels`` maps the
    metric stems to display names, so the translated part can reuse the rows.
    """
    labels = labels or KEY_METRIC_MEANING
    cells = _rows('uav_metric_cells.csv')
    acc = {}
    for r in cells:
        if r.get('scenario') != 'intercept':
            continue
        for name, _nd in KEY_METRICS:
            if f'{name}_median' not in r:
                continue
            try:
                v = float(r[f'{name}_median'])
            except (TypeError, ValueError):
                continue
            acc.setdefault((name, r['fid'], r['arm']), []).append(v)
    out = []
    for name, nd in KEY_METRICS:
        row = [labels[name]]
        for fid in ('1', '2', '3', '4'):
            for arm in ('bare', 'full'):
                v = acc.get((name, fid, arm))
                row.append(_f(np.median(v), nd) if v else '-')
        out.append(row)
    return out


# --- outcome resolution: event rates, budget plateau, required sample size ---
# Written by analyze_uav_events.py.  A binary indicator whose event is rare has
# a median of zero however the variants differ, so the mission-level events are
# read as rates with Wilson intervals rather than as medians.
EVENT_LABELS = {
    'task': 'Task', 'F1': 'F1', 'F2': 'F2', 'F3': 'F3', 'F4': 'F4',
    'all': 'all tasks', 'n_runs': 'Rollouts', 'air': 'Both UAVs reach',
    'gnd': 'Ground team reaches', 'dest': 'Base destroyed',
    'dmg': 'Mean base damage',
}
EVENT_ZH = {
    'task': '任务', 'F1': 'F1', 'F2': 'F2', 'F3': 'F3', 'F4': 'F4',
    'all': '四任务合并', 'n_runs': '试次数', 'air': '两机抵达基地',
    'gnd': '地面分队抵达', 'dest': '基地被摧毁',
    'dmg': '基地平均损伤',
}


def mission_table():
    """Graded completion percentages, one row per (task, arm)."""
    d = {(r['fid'], r['arm']): r for r in _rows('uav_mission_summary.csv')}
    out = []
    for fid in ('1', '2', '3', '4'):
        for arm, lab in (('bare', 'bare'), ('full', 'UPCL')):
            r = d[(fid, arm)]
            out.append([f'F{fid}', lab,
                        f'{float(r["composite_pct"]):.1f} \u00b1 '
                        f'{float(r["composite_ci"]):.1f}']
                       + [f'{float(r[k + "_pct"]):.1f} \u00b1 '
                          f'{float(r[k + "_ci"]):.1f}'
                          for k in ('damage', 'breach', 'kill')])
    return out


def weight_rows(arm='bare'):
    """Weight-sensitivity rows of one arm (uav_composite_weights.csv)."""
    return [r for r in _rows('uav_composite_weights.csv') if r['arm'] == arm]


def _mission_mean(arm):
    """Pooled completion percentages of one arm over all tasks and variants."""
    rows = [r for r in _rows('uav_mission.csv') if r['arm'] == arm]
    return {k: sum(float(r[f'{k}_pct_median']) for r in rows) / len(rows)
            for k in ('composite', 'damage', 'breach', 'kill')}


def _mission_cell(arm, key):
    """Per-cell values of one completion percentage (29 variants x 4 tasks)."""
    return [float(r[f'{key}_pct_median']) for r in _rows('uav_mission.csv')
            if r['arm'] == arm]


def mission_mean(fid, arm='bare', key='composite'):
    """Cross-variant mean of one graded outcome on one task and arm (%)."""
    for r in _rows('uav_mission_summary.csv'):
        if r['fid'] == str(fid) and r['arm'] == arm:
            return float(r[f'{key}_pct'])
    raise KeyError((fid, arm))


def csr_peak():
    """Highest per-cell mean CSR in the archive, with its cell record."""
    rows = _rows('uav_mission.csv')
    r = max(rows, key=lambda x: float(x['composite_pct_mean']))
    return float(r['composite_pct_mean']), r


def _event_row(fid='all', arm='both'):
    """Event-rate record of one (task, arm) from ``uav_event_rates.csv``."""
    scope = 'all' if str(fid) == 'all' else 'task'
    for r in _rows('uav_event_rates.csv'):
        if r['scope'] == scope and r['fid'] == str(fid) and r['arm'] == arm:
            return r
    raise SystemExit(f'[UPCL-app] missing event rates for F{fid}/{arm}')


def rate_cell(r, stem):
    """'p% [lo, hi]' for an event rate and its $95\\%$ Wilson interval."""
    return (f'{float(r[stem + "_pct"]):.1f}% '
            f'[{float(r[stem + "_lo"]):.1f}, {float(r[stem + "_hi"]):.1f}]')


def event_rate_headers(labels=None):
    labels = labels or EVENT_LABELS
    return [labels[k] for k in ('task', 'n_runs', 'air', 'gnd', 'dest', 'dmg')]


def event_rate_table(labels=None):
    """One row per task (both arms pooled) of the mission-level event rates."""
    labels = labels or EVENT_LABELS
    out = []
    for fid in ('1', '2', '3', '4', 'all'):
        r = _event_row(fid)
        out.append([labels['all'] if str(fid) == 'all' else labels[f'F{fid}'],
                    int(r['n_runs']), rate_cell(r, 'air'), rate_cell(r, 'gnd'),
                    rate_cell(r, 'dest'),
                    f'{100 * float(r["dmg_mean"]):.1f}%'])
    return out


def plateau(fid='all', arm='bare'):
    """Budget-saturation record: ``uav_budget_plateau.csv``."""
    scope = 'all' if str(fid) == 'all' else 'task'
    for r in _rows('uav_budget_plateau.csv'):
        if r['scope'] == scope and r['fid'] == str(fid) and r['arm'] == arm:
            return r
    raise SystemExit(f'[UPCL-app] missing budget plateau for F{fid}/{arm}')


def power(kind, runs=None, ratio=None):
    """Sample-size record: observed-event probability or detectable ratio."""
    for r in _rows('uav_power.csv'):
        if r['kind'] != kind:
            continue
        if runs is not None and str(r['runs']) == str(runs):
            return r
        if ratio is not None and str(r['ratio']) == str(ratio):
            return r
    raise SystemExit(f'[UPCL-app] missing power row {kind}/{runs}/{ratio}')


def _cell_rows(arm='bare'):
    """Per-cell metric rows of the scenario for one arm."""
    return [r for r in _rows('uav_metric_cells.csv')
            if r.get('scenario') == 'intercept' and r['arm'] == arm]


def _median_by_task(stem, arm='bare'):
    """Pool median of one metric, per task."""
    acc = {}
    for r in _cell_rows(arm):
        try:
            v = float(r[f'{stem}_median'])
        except (KeyError, TypeError, ValueError):
            continue
        acc.setdefault(r['fid'], []).append(v)
    return {fid: float(np.median(v)) for fid, v in acc.items()}


def _spread_by_task(stem, arm='bare'):
    """Per-task list of the pool values of one metric."""
    acc = {}
    for r in _cell_rows(arm):
        try:
            acc.setdefault(r['fid'], []).append(float(r[f'{stem}_median']))
        except (KeyError, TypeError, ValueError):
            continue
    return acc


def _delta_stats(metrics):
    """Same-seed change of the augmented arm over all cells.

    Returns ``{metric: {'abs': median |change|, 'rel_pct': median relative
    change in percent, 'zero': cells with no change, 'n': cells}}``.
    """
    absd, rel, zero, up, down = {}, {}, {}, {}, {}
    for r in _rows('uav_upcl_delta.csv'):
        m = r['metric']
        if m not in metrics:
            continue
        try:
            b, d = float(r['bare_median']), float(r['delta'])
        except (TypeError, ValueError):
            continue
        absd.setdefault(m, []).append(abs(d))
        if abs(b) > 1e-9:
            rel.setdefault(m, []).append(abs(d) / abs(b))
        if abs(d) <= 1e-9:
            zero[m] = zero.get(m, 0) + 1
        elif d > 0:
            up[m] = up.get(m, 0) + 1
        else:
            down[m] = down.get(m, 0) + 1
    return {m: {'abs': float(np.median(absd[m])),
                'rel_pct': 100 * float(np.median(rel[m])),
                'up': up.get(m, 0), 'down': down.get(m, 0),
                'zero': zero.get(m, 0),
                'n': len(absd[m])} for m in absd}


# ---------------------------------------------------------------------------
# Per-task reading of the scenario (Section 5.4).  The four tasks share one
# map but not one ranking, so each of them gets its own table; the constants
# below are the English counterparts of the ones the translated part uses.
# ---------------------------------------------------------------------------
TASK_FIDS = ('1', '2', '3', '4')
TASK_LABEL = {
    '1': '5.4.1  F1, the baseline task: one interceptor, no no-fly zone',
    '2': '5.4.2  F2, restricted airspace: one interceptor and a no-fly zone',
    '3': '5.4.3  F3, co-ordinated interception: two interceptors, no no-fly '
         'zone',
    '4': '5.4.4  F4, compound difficulty: two interceptors, a no-fly zone and '
         'a faster patrol',
}
# Representative places read out in every task: leader / median / last.
REP_SLOTS = ('top', 'mid', 'bottom')
REP_EN = {'top': 'Leader', 'mid': 'Median place', 'bottom': 'Last place'}
# Metrics of the per-task table: (column stem of uav_metric_cells.csv,
# decimals).
TASK_METRICS = [('composite_pct', 2), ('n_arrived', 0), ('n_lost', 0),
                ('min_dist', 0), ('path_length', 0)]


def _task_rank_rows(fid):
    """``{task_rank: row}`` of one task (uav_task_rank.csv)."""
    return {int(r['task_rank']): r
            for r in _rows('uav_task_rank.csv') if r['fid'] == fid}


def _rep_ranks(fid):
    """The three representative places of a task, adaptive in the pool size."""
    by = _task_rank_rows(fid)
    n = max(by)
    return sorted({1, (n + 1) // 2, n})


def _task_summary(fid):
    """``{group: row}`` of one task (uav_task_summary.csv)."""
    return {r['metric_group']: r for r in _rows('uav_task_summary.csv')
            if r['fid'] == fid}


def _task_pool(fid, metric, arm='bare'):
    """Pool median of one metric on one task (uav_task_metrics.csv)."""
    for r in _rows('uav_task_metrics.csv'):
        if r['fid'] == fid and r['metric'] == metric and r['arm'] == arm:
            return float(r['pool_median'])
    return float('nan')


def _task_spread(fid, metric, arm='bare'):
    """Per-host medians of one metric on one task, i.e. the pool spread."""
    out = []
    for r in _rows('uav_metric_cells.csv'):
        if (r.get('scenario') == 'intercept' and r['fid'] == fid
                and r['arm'] == arm):
            try:
                out.append(float(r[f'{metric}_median']))
            except (KeyError, TypeError, ValueError):
                continue
    return out


def _cell_metric(fid, host, metric, arm='bare'):
    """Median of one metric for one task, variant and arm."""
    for r in _rows('uav_metric_cells.csv'):
        if (r.get('scenario') == 'intercept' and r['fid'] == fid
                and r['host'] == host and r['arm'] == arm):
            try:
                return float(r[f'{metric}_median'])
            except (KeyError, TypeError, ValueError):
                return float('nan')
    return float('nan')


def _rank_by_fid():
    return {r['fid']: r for r in _rows('uav_rank_by_fid.csv')}


def _pair_cell(b, f, nd=0):
    """The two arms side by side: ``12 -> 15``."""
    return f'{_f(b, nd)} $\\to$ {_f(f, nd)}'


def _dir_word(f, b, up='higher', down='lower', flat='unchanged'):
    """Direction of a two-arm comparison; near-equal readings stay flat."""
    if not (b == b and f == f) or abs(b) < 1e-12:
        return flat
    if abs(f - b) / abs(b) < 0.01:
        return flat
    return up if f > b else down


def build(P, S):
    P.mark_part_base()
    _scenario(P)
    _setup(P)
    _metrics(P)
    _results(P)
    _case(P)
    _discussion(P)


# ===========================================================================
# 5.1  Scenario modelling and experimental design
# ===========================================================================
def _scenario(P):
    P.h1('5  Real-world application: algorithm behaviour on a UAV '
         'adversarial-interception scenario')

    P.para(
        'The benchmark study of Section 4 answers how the variants behave on '
        'synthetic functions.  This section asks a different question: on one '
        'concrete, hard application, what do these algorithms actually do, and '
        'which differences between them survive?  The scenario is analysed on '
        'its own terms (its geometry, its constraints, its cost, and the '
        'outcomes it produces) and no conclusion is carried over from the '
        'benchmark.')

    P.h2('5.1  Scenario description and complexity')

    P.para(
        'In a synthetic $1000\\,\\text{m}\\times 1000\\,\\text{m}$ '
        'three-dimensional mountainous scenario, the terrain is generated by '
        'superposing several Gaussian peaks on a low-frequency undulation, '
        'giving a relief amplitude of about $220\\,\\text{m}$; the valleys and '
        'ridges provide low-altitude penetration corridors as well as '
        'line-of-sight (LOS) occlusions. The blue side forms a coordinated '
        'air-ground team of $3$ UAVs and $3$ infantry: the UAVs take off from '
        '$(60,60)$ and penetrate at low altitude to bomb the base at '
        '$(820,820)$, while the infantry advance on the ground and capture '
        'the base upon arrival. The red side deploys a four-layer defense: an '
        'early-warning radar at $(500,500)$ (detection radius '
        '$520\\,\\text{m}$) that triggers the interceptors; $1\\!-\\!2$ '
        'helicopter interceptors standing by at the southeast apron (speed '
        '$12\\!-\\!14\\,\\text{m/step}$, turn $0.35\\,\\text{rad/step}$, '
        'LOS-blockable capture cone); $2$ ground air-defense vehicles (range '
        '$260\\,\\text{m}$, limited-turn missiles); and $20$ patrol soldiers '
        'guarding the base. Task difficulty rises with the number of '
        'interceptors, a no-fly zone and interceptor speed, giving four tasks '
        'F1-F4 enumerated in Table {t1}, on the terrain of Fig. {f1}, and '
        'drawn side by side in Fig. {f2}.',
        )
    t1 = _nt(P)
    P.figure(
        PFG.fig('uav_sandbox'),
        'The interception scenario as a three-dimensional sandbox: panels '
        '(a)-(d) show the same '
        '$1000\\,\\text{m}\\times 1000\\,\\text{m}$ mountainous terrain that '
        'every rollout of every variant traverses, seen from four camera '
        'azimuths.',
        note=f'Green hemisphere = radar volume, translucent spheres = no-fly '
             f'zones, orange discs = patrol vision ranges, blue cage = flight '
             f'ceiling; the scene is drawn from a fixed seed and carries no '
             f'run-specific information.')
    P.para(
        'Both figures are drawn from that fixed seed and carry no run-specific '
        'information: the terrain, the radar, the no-fly zones and the patrol '
        'deployment are the scenario and not an outcome, so a difference '
        'between two panels is a difference of task and never of sample. Three '
        'features of the scene set the difficulty of the search. The relief is '
        'what makes the flight three-dimensional, because every route must be '
        'flown above the terrain-following height and the climb is charged in '
        'the reward; the ridges also occlude line of sight, and the capture '
        'cone of an interceptor is blocked by terrain, so a low route is not '
        'simply a longer one. The radar at the centre is a hemisphere of '
        'detection radius rather than a forbidden volume: crossing it '
        'triggers the interceptors, which is why the no-fly zone of the second '
        'task is drawn as a separate object on the same map. The patrol '
        'soldiers see only what their vision discs cover, so the ground half of '
        'the mission is a coverage problem as much as a routing one, and the '
        'orange discs are the reason a detour on the ground can be worth more '
        'than a shorter path. The next figure places the four tasks on that one '
        'map, so the panels are read as four settings of the same scene rather '
        'than as four scenes.')
    P.figure(PFG.fig('uav_tasks'),
             f'The four tasks of Table {t1}, on the same '
             '$1000\\,\\text{m}\\times 1000\\,\\text{m}$ map: the dashed green '
             'arrow is the UAV penetration and bombing run to the base, the '
             'dashed olive arrow the infantry advance, and panels (a)-(d) '
             'differ only in the red-side defences.')

    P.para(
        'The decision variables encode the same kind of plan in every task.  '
        'Each UAV is described by $K=2$ mid-course 3-D waypoints $(x,y,z)$ and '
        'each soldier by $K=2$ ground waypoints $(x,y)$, all decoded from a '
        'continuous encoding $[-1,1]^{D}$; the altitude is a climb offset '
        '$[0,100]\\,\\text{m}$ above the terrain-following height '
        '$z=\\min(z_{\\text{ground}}+h_{\\text{clear}}+z_{\\text{off}},'
        'z_{\\max})$ with $h_{\\text{clear}}=30\\,\\text{m}$ and '
        '$z_{\\max}=460\\,\\text{m}$, so '
        '$D=3\\cdot 2\\cdot 3+3\\cdot 2\\cdot 2=30$. A deterministic '
        'step-by-step rollout (up to $220$ steps) returns the terminal fleet '
        'state; the blue side minimises $f(x)=-R(x)$ with reward')
    P.equation(
        r'R = w_a n_{\mathrm{arr}} - w_l n_{\mathrm{lost}} - w_c '
        r'n_{\mathrm{crash}} - w_t n_{\mathrm{unf}} '
        r'- w_n n_{\mathrm{nofly}} - w_b n_{\mathrm{bound}} '
        r'- w_{co} n_{\mathrm{col}} - w_p(\tfrac{L}{L_{\mathrm{direct}}}-1) '
        r'- w_{cl}\tfrac{z_{\mathrm{climb}}}{A} '
        r'+ w_s \min(1,\tfrac{d_{\min}}{4R_{\mathrm{cap}}}) '
        r'+ w_b^{+} b + w_i n_{\mathrm{inf,arr}} - w_{il} n_{\mathrm{inf,lost}}'
        r'+ w_k n_{\mathrm{kill}} + w_s^{+}\mathbb{I}[\mathrm{success}],')
    P.para(
        'where $n_{\\text{arr}}$/$n_{\\text{lost}}$/$n_{\\text{crash}}$/'
        '$n_{\\text{unf}}$ count the arrived / shot-down / crashed / unfinished '
        'UAVs, $n_{\\text{nofly}}$ and $n_{\\text{bound}}$ the cumulative '
        'no-fly and out-of-bounds steps, $n_{\\text{col}}$ the inter-UAV '
        'collisions, $n_{\\text{inf,arr}}/n_{\\text{inf,lost}}$ the infantry '
        'arrivals and losses, and $n_{\\text{kill}}$ the patrol kills. '
        '$L$ is the length of the flown route and $L_{\\text{direct}}$ the sum '
        'of the straight-line start-to-target distances, so '
        '$L/L_{\\text{direct}}-1$ is the relative detour; $z_{\\text{climb}}$ '
        'is the climb accumulated along the route and $A=220$ m the terrain '
        'relief that normalises it. $d_{\\min}$ is the minimum distance to any '
        'interceptor and $R_{\\text{cap}}=55$ m its capture radius, so the '
        'safety term saturates once an interceptor is four capture radii away. '
        '$b\\in[0,1]$ is the base-bombing progress and '
        '$\\mathbb{I}[\\text{success}]$ the base-destroyed indicator; the '
        'fifteen weights $w_\\bullet$ are defined with their values in Table '
        '{t2}. Kinematic hard constraints (turn '
        '$|\\Delta\\theta|\\le 0.25$ rad/step, climb $|\\Delta z|\\le 25$ '
        'm/step, altitude and speed) are enforced inside the simulator, while '
        'no-fly zones, map bounds, collisions and energy limits are folded '
        'into the objective as per-step or per-occurrence penalties; the '
        'resulting surface is drawn in Fig. {f3} for each of the four tasks.',
        )
    t2 = _nt(P)
    P.figure(PFG.fig('uav_landscape_3d'),
             'Function landscape of $f(x)$ for the four tasks of Table {t1}: '
             '(a) F1, (b) F2, (c) F3 and (d) F4, i.e. baseline, restricted '
             'airspace, coordinated interception, and the compound setting '
             'with two interceptors, a no-fly zone and a faster interceptor. '
             'In each panel $x_1,x_2$ are swept over $[-1,1]^2$ while the '
             'remaining 28 variables stay fixed at a near-optimal solution '
             'found by NL-SHADE-RSP for that task; every panel carries its own '
             'vertical scale, so the four panels are comparable in shape but '
             'not in height.')
    P.para(
        'What the algorithms face is a black box with four properties that '
        'shape what an algorithm can and cannot do here.  It is non-convex and '
        'multimodal, because interception, the no-fly zone and the penalties '
        'are event-driven piecewise structures that open and close corridors '
        'abruptly.  It is non-smooth and non-differentiable: the trigger-type '
        'penalties make $f$ jump, so no gradient signal is available and a '
        'small move in the encoding can flip an entire rollout.  It is '
        'implicitly constrained: the hard kinematic limits are enforced inside '
        'the simulator, while airspace and safety requirements enter the '
        'objective only as penalties.  And it is expensive: one rollout costs '
        'about $20.7$ ms, so any evaluation budget is small in absolute terms '
        'and the number of restarts is limited.  These four properties ('
        'event-driven non-convexity, non-smoothness, implicit constraints and '
        'cost) are the terms on which the algorithms are compared in Section 5.4.')

    P.para(
        'The scenario belongs to a well-defined class, and it is worth saying '
        'which one, since the class determines what the results can be read as '
        'evidence for. Mission-level planning for unmanned aerial vehicles is '
        'usually posed as routing or trajectory optimisation over a terrain '
        'with threats, and the surveys of the area organise it by the planner '
        'rather than by the application: graph search, sampling-based motion '
        'planning, and population-based metaheuristics [@OTTO18][@ZHAO18], with '
        'the last two dominating once the cost is non-convex and '
        'discontinuous [@LAVALLE06][@KARAMAN11]. Genetic and swarm planners '
        'have been applied to exactly the trade-off between path length and '
        'threat exposure that the objective encodes [@ROBERGE13][@BESADA10], '
        'and cooperative planning for a swarm adds the assignment and '
        'synchronisation layer that the four tasks vary [@ZHEN20]. Delivery '
        'and coverage routing studies supply the depot-and-service structure '
        'that the infantry half of the mission imitates [@DORLING17][@ZENG16]. '
        'The red side, in turn, is a pursuit-evasion problem with bounded '
        'controls and a capture region, a class whose differential-game '
        'formulation predates its computational treatment by decades '
        '[@ISAACS65][@SHIMA02] and whose probabilistic variant is solved by '
        'reachability computation [@VIDAL02]; its learned counterparts are '
        'now trained by self-play to superhuman strength in comparable '
        'two-player settings [@SILVER16][@SILVER18]. Little in the scenario is '
        'therefore novel as a model. What the experiment adds is not a new '
        'mission formulation but a fixed, seed-reproducible instance of it, on '
        'which twenty-nine variants are compared under one budget.')

    P.table_caption('Task settings of the interception scenario ($D=30$).')
    P.table(['Task', 'Interceptors', 'No-fly', 'Speed', 'Difficulty'],
            [['F1', '1', 'none', '12', 'baseline'],
             ['F2', '1', '1', '12', '+ restricted airspace'],
             ['F3', '2', 'none', '12', '+ coordinated interception'],
             ['F4', '2', '1', '14', 'multi-interceptor + no-fly + faster']],
            widths=[0.8, 1.3, 1.0, 0.9, 3.2], align='lllll')

    P.table_caption('Objective weights of the interception scenario.')
    P.table(['Symbol', 'Meaning', 'Value', 'Symbol', 'Meaning', 'Value'],
            [['$w_a$', 'arrival per UAV', '100', '$w_p$', 'detour penalty',
              '20'],
             ['$w_l$', 'loss per UAV', '80', '$w_{cl}$', 'climbing energy',
              '30'],
             ['$w_c$', 'crash per UAV', '90', '$w_s$', 'safety margin', '15'],
             ['$w_t$', 'unfinished', '30', '$w_b^{+}$', 'bombing progress',
              '200'],
             ['$w_n$', 'no-fly per step', '20', '$w_i$', 'infantry arrival',
              '120'],
             ['$w_b$', 'out-of-bounds/step', '30', '$w_{il}$', 'infantry loss',
              '100'],
             ['$w_{co}$', 'inter-UAV collision', '40', '$w_k$', 'patrol kill',
              '60'],
             ['-', '-', '-', '$w_s^{+}$', 'overall success', '150']],
            widths=[0.8, 1.7, 0.7, 0.8, 1.7, 0.7], align='llrllr')


# ===========================================================================
# 5.2  Algorithm input and configuration
# ===========================================================================
def _setup(P):
    P.h2('5.2  Algorithm input and configuration on the scenario')

    P.para(
        'The solvers are the $29$ DE variants of Section 4: together they '
        'span the main design dimensions of differential evolution, namely '
        'fixed versus adaptive parameter rules, single mutation strategies '
        'versus strategy pools, and the presence or absence of an external '
        'archive and of population-size reduction.  All variants enter the '
        'scenario through one interface: a continuous box '
        '$[-1,1]^{30}$ is decoded into the UAV and infantry waypoints and the '
        'deterministic rollout returns $f(x)=-R(x)$ as the only feedback, with '
        'each variant keeping its own population size and parameter rule and '
        'none re-tuned for the scenario.  Every variant is run in two '
        'configurations, the bare arm (the variant alone) and the full '
        'arm (the same variant carrying the UPCL proposal-correction layer, '
        'which acts on the candidates proposed by the host without changing '
        'its mutation, crossover or population schedule); the two arms share '
        'an identical random-seed sequence, so any difference between them is '
        'attributable to that layer.  The budget is $500D=15{,}000$ '
        'evaluations per arm and every cell (one variant on one task) is '
        'repeated with $R=3$ independent seeds.  The budget is fixed at '
        '$500D$ because the objective is a rollout rather than a benchmark '
        'function, and it is two orders of magnitude smaller than the '
        '$10^4 D$ of Section 4; no number in this section is therefore '
        'comparable with a CEC figure, and every comparison made here is '
        'between the two arms of one cell.')


# ===========================================================================
# 5.3  Evaluation metrics and presentation
# ===========================================================================
def _metrics(P):
    P.h2('5.3  Evaluation metrics and presentation')

    P.para(
        'A run on this scenario produces a trajectory rather than a scalar '
        'error, so the outcome is described by $27$ terminal metrics computed '
        'from the fleet state at the end of the rollout.  They fall into six '
        'semantic families, listed in Table {t3}; every metric has a '
        'direction fixed from the blue side\'s viewpoint, so "better" always '
        'means a better outcome for the attacking team.')
    t3 = _nt(P)

    P.table_caption('The 27 task metrics grouped into six semantic groups.')
    P.table(['Group', 'Meaning', 'Representative metrics'],
            [['task', 'task accomplishment',
              'mission success, base destroyed, arrivals, base HP'],
             ['safety', 'evasion safety',
              'UAV losses, min interceptor distance, first-capture time'],
             ['path', 'path quality',
              'path length, flight time, path efficiency, curvature, climb'],
             ['constraint', 'constraint satisfaction',
              'out-of-bounds steps, no-fly steps, crashes'],
             ['infantry', 'air-ground coordination',
              'infantry arrivals/losses, survival, HP, patrol kills'],
             ['patrol', 'adversary patrol', 'patrol alive, survival, HP']],
            widths=[1.2, 2.3, 4.5], align='lll')

    ev0 = _event_row('all')
    P.para(
        f'The terminal flag the scenario defines - the base falls - is met in '
        f'{int(ev0["dest_k"])} of the {int(ev0["n_runs"])} arm-level rollouts, '
        f'so as a success '
        'criterion it reads zero for almost every variant and every arm and '
        'cannot '
        'order anything.  The outcome is therefore scored on a graded scale, '
        'the composite success rate (CSR), a weighted mean of three '
        'percentages that every rollout already records: the share of the base '
        'health removed, the share of the ground team that reached the base and '
        'the share of the patrol force killed.  Half '
        'of the credit goes to the terminal objective, because the base health '
        'is the only quantity the scenario scores as victory, and the two '
        'enabling conditions carry a quarter each: they are necessary for the '
        'objective but not sufficient on their own.  A run that destroyed the '
        'base, landed the ground team and cleared the patrol would score $100$; '
        f'the strongest cell in the archive averages ${csr_peak()[0]:.1f}$, so '
        'the scale is '
        'not saturated.  The weights are a stated choice rather than a fitted '
        'quantity, and Section 5.4 reports the ordering they produce under '
        'three alternative weightings.')

    P.para(
        'Three presentation choices follow from the fact that a multi-metric '
        'outcome cannot be ordered by a single number.  First, the variants '
        'are compared on a composite score: the four primary metrics of the '
        'protocol (CSR, arrivals, losses and path length) are '
        'standardised to $z$-scores across the pool, sign-flipped where lower '
        'is better, and summed, so a larger composite means a better overall '
        'outcome.  The composite is always reported next to the four '
        'underlying medians rather than on its own, so the reader can see '
        'what drives it.  Second, because one number hides the structure, '
        'per-group effects are reported as pooled means with $95\\%$ '
        'confidence intervals over the pool, and the sign consistency of each '
        'variant as a run-level share.  Third, the mission-level events are '
        'read as rates with $95\\%$ intervals rather than as medians: a binary '
        'indicator whose event is rare has a median of zero however the '
        'variants differ, so reporting the median would hide the difference '
        'the indicator was introduced to expose, whereas the rate and its '
        'interval stay informative and are directly comparable between tasks.  '
        'Every result of Section 5.4 is accompanied by '
        'the quantity behind it: the tables give the values and the intervals, '
        'and the trajectory figures give the flight geometry.')


# ===========================================================================
# 5.4.1-5.4.4  One task at a time
# ===========================================================================
def _task_block(P, fid):
    """One task on its own: its ranking table and the two-arm reading of it."""
    P.h3(TASK_LABEL[fid])

    by = _task_rank_rows(fid)
    n_host = max(by)
    ks = _rep_ranks(fid)
    reps = [(slot, k, by[k]) for slot, k in zip(REP_SLOTS, ks)]
    top, mid, bot = reps[0], reps[1], reps[-1]
    rb = _rank_by_fid()[fid]
    rho, pval = float(rb['spearman_rho']), float(rb['p'])

    P.para(
        f'Task F{fid} re-orders the {n_host} variants.  The leader is '
        f'{top[2]["host"]} (rank {top[2]["cec_rank"]} on CEC 2017 $D=30$), the '
        f'median place is rank {mid[1]}, held by {mid[2]["host"]} (CEC rank '
        f'{mid[2]["cec_rank"]}), and the last place by {bot[2]["host"]} (CEC '
        f'rank {bot[2]["cec_rank"]}).  The two orderings have a Spearman '
        f'correlation of $\\rho={rho:.2f}$ ($p={pval:.3f}$, '
        f'$n={int(rb["n"])}$), so '
        + ('the benchmark order carries over at the $0.05$ level on this '
           'task.  ' if pval < 0.05 else
           'it misses the $0.05$ level on this task and the benchmark order '
           'is only a weak guide there.  ')
        + ('The task leader is also a front-runner on the benchmark.'
           if int(top[2]['cec_rank']) <= 10 else
           f'The task leader, by contrast, places only '
           f'{top[2]["cec_rank"]}th on the benchmark, in the lower half of the '
           f'pool.'))

    t_task = _nt(P)
    P.table_caption(
        f'Key metrics of the task leader, the median place and the last place '
        f'on task F{fid}: every value is the median over the $R=3$ runs, the '
        f'two arms side by side (bare $\\to$ UPCL).')
    rows = []
    for slot, rk, r in reps:
        host = r['host']
        cells = [_pair_cell(_cell_metric(fid, host, m),
                            _cell_metric(fid, host, m, 'full'), nd)
                 for m, nd in TASK_METRICS]
        rows.append([str(rk), host, r['cec_rank'], _f(r['task_composite'], 3)]
                    + cells)
    pool_cells = [_pair_cell(_task_pool(fid, m), _task_pool(fid, m, 'full'), nd)
                  for m, nd in TASK_METRICS]
    rows.append(['-', f'pool median ({n_host} variants)', '-', '-']
                + pool_cells)
    P.table(['Rank', 'Variant', 'CEC rank', 'Composite', 'CSR (%)',
             '$n_{\\text{arr}}$', '$n_{\\text{lost}}$', '$d_{\\min}$(m)',
             '$L$(m)'],
            rows, widths=[0.5, 1.85, 0.75, 0.8, 0.85, 0.85, 0.85, 0.85, 0.9],
            align='llrrrrrrr', font_size=6.8)

    b_succ = mission_mean(fid, 'bare')
    f_succ = mission_mean(fid, 'full')
    b_arr, f_arr = (_task_pool(fid, 'n_arrived'),
                    _task_pool(fid, 'n_arrived', 'full'))
    b_lost, f_lost = (_task_pool(fid, 'n_lost'),
                      _task_pool(fid, 'n_lost', 'full'))
    b_md, f_md = (_task_pool(fid, 'min_dist'),
                  _task_pool(fid, 'min_dist', 'full'))
    b_pl, f_pl = (_task_pool(fid, 'path_length'),
                  _task_pool(fid, 'path_length', 'full'))
    b_fc, f_fc = (_task_pool(fid, 'first_capture'),
                  _task_pool(fid, 'first_capture', 'full'))
    b_pt, f_pt = (_task_pool(fid, 'n_patrol_killed'),
                  _task_pool(fid, 'n_patrol_killed', 'full'))
    sp_md = _task_spread(fid, 'min_dist')
    sp_pl = _task_spread(fid, 'path_length')
    ev_t = _event_row(fid)
    P.para(
        f'The pool row of Table {t_task} separates what is fixed on this task '
        f'from what is free.  The accomplishment counters are event counters, '
        f'so they are read as rates rather than as medians, as Table {{t5}} '
        f'reports: on '
        f'F{fid} both UAVs complete the penetration in '
        f'{rate_cell(ev_t, "air")} of the {int(ev_t["n_runs"])} rollouts, the '
        f'ground team reaches the base in {rate_cell(ev_t, "gnd")} and the base '
        f'is destroyed in {rate_cell(ev_t, "dest")}.  The graded outcome is not '
        f'flat: the mean CSR over the variants is {b_succ:.2f}% at the bare arm '
        f'and {f_succ:.2f}% with the layer (Table {{t6}}), and that column, '
        f'which replaces the all-zero success flag, '
        f'separates the variants by how far into the mission they got, not by '
        f'whether they finished it.  What is '
        f'fixed on this task is the aerial half of the outcome - '
        f'{_f(b_arr, 0)} UAVs arrived and {_f(b_lost, 0)} lost, unchanged by '
        f'the layer - while the base health moves only through the ground '
        f'arrival.  The '
        f'approach geometry is where the pool spreads: the minimum interceptor '
        f'distance has a pool median of {_f(b_md, 0)} m '
        f'({_f(f_md, 0)} m with the layer attached, {_dir_word(f_md, b_md)}) '
        f'and spans {_f(min(sp_md), 0)}-{_f(max(sp_md), 0)} m inside the task, '
        f'while the path length has a pool median of {_f(b_pl, 0)} m '
        f'({_f(f_pl, 0)} m, {_dir_word(f_pl, b_pl)}) and spans '
        f'{_f(min(sp_pl), 0)}-{_f(max(sp_pl), 0)} m.  First capture falls at '
        f'step {_f(b_fc, 0)} ({_f(f_fc, 0)} with the layer) and '
        f'{_pair_cell(b_pt, f_pt, 0)} patrol soldiers are killed.  The freedom '
        f'of this task therefore lies in how wide the detour is and how close '
        f'it passes to the interceptor, not in whether the mission is carried '
        f'out.')

    sm = _task_summary(fid)
    rows_g = [(g, sm[g]) for g in GROUP_ORDER if g in sm]
    flat = [GROUP_MEANING[g] for g, r in rows_g
            if abs(float(r['mean_gain'])) <= 1e-9]
    span = [g for g, r in rows_g
            if float(r['ci_lo']) <= 0 <= float(r['ci_hi'])]
    best = max(rows_g, key=lambda gr: float(gr[1]['same_sign_pct']))
    P.para(
        f'Between the two arms, {len(flat)} of the {len(rows_g)} metric groups '
        + (f'({", ".join(flat)}) ' if flat else '')
        + f'change by exactly zero on this task, because neither arm triggers '
        f'their counters, and the remaining groups move by '
        + ', '.join(f'{GROUP_MEANING[g]} {float(r["mean_gain"]):+.2f}'
                    for g, r in rows_g if g not in flat)
        + f'.  {len(span)} of the {len(rows_g)} pooled intervals contain zero, '
        f'so no group shifts by a distinguishable amount here.  The sign '
        f'consistency is equally low: the largest share of hosts that keep the '
        f'pooled sign is {float(best[1]["same_sign_pct"]):.0f}% for '
        f'{GROUP_MEANING[best[0]]}, and the rest sit near half, which places '
        f'these residuals among the per-cell detour trade-offs rather than in a '
        f'systematic effect of the layer on this task.')


# ===========================================================================
# 5.4  Results
# ===========================================================================
def _results(P):
    P.h2('5.4  Results')

    vr = _rows('uav_value_rank.csv')
    cec = {r['host']: int(r['cec_rank']) for r in vr}
    shift = {r['host']: int(r['uav_rank']) - int(r['cec_rank']) for r in vr}
    rho = stats.spearmanr([int(r['uav_rank']) for r in vr],
                          [int(r['cec_rank']) for r in vr])
    prof = {}
    for r in vr:
        prof.setdefault((r['n_arrived'], r['n_lost']), []).append(r)
    dom = max(prof, key=lambda k: len(prof[k]))
    majority = prof[dom]
    odd = sorted([r for k, v in prof.items() if k != dom for r in v],
                 key=lambda r: int(r['uav_rank']))
    comp_main = [float(r['composite']) for r in majority]
    path = [float(r['path_length']) for r in vr]
    P.para(
        f'Table {{t4}} orders the {len(vr)} variants by the composite score, '
        f'with the four primary metrics alongside.  The pool is uniform at the '
        f'mission level: {len(majority)} of the {len(vr)} variants end every '
        f'rollout with the same fleet outcome ({int(float(dom[0]))} UAVs '
        f'arrived, {int(float(dom[1]))} lost), and only {len(odd)} ('
        f'{", ".join(r["host"] for r in odd)}) reach a different one, which '
        f'is also what places them at the foot of the table.  What separates '
        f'the others is the geometry of the approach: the median path length '
        f'runs from {min(path):,.0f} m to {max(path):,.0f} m across the pool '
        f'(pool median {np.median(path):,.0f} m), and inside the leading '
        f'{len(majority)} the composite itself spans only '
        f'{max(comp_main) - min(comp_main):.2f} units.  The spread is real but '
        f'narrow, and it comes from how the detour is traded against '
        f'clearance rather than from whether the mission is carried out.')
    t4 = _nt(P)

    P.table_caption('Behaviour of the $29$ variants on the interception '
                    'scenario, ordered by the composite score (larger is '
                    'better); the four primary metrics are medians over the '
                    'four tasks and the $R=3$ runs, and $\\Delta$ is the '
                    'scenario rank minus the benchmark rank of the bare arm, '
                    'that rank being the mean over the twenty-nine functions '
                    'of CEC 2017 at $D=30$ of the per-function median log-10 '
                    'final error.')
    P.table(['Rank', 'Variant', 'CEC rank', '$\\Delta$', 'Composite',
             'CSR (%)', '$n_{\\text{arr}}$', '$n_{\\text{lost}}$', '$L$'],
            [[r['uav_rank'], r['host'], r['cec_rank'],
              f'{shift[r["host"]]:+d}', _f(r['composite'], 3),
              _f(r['composite_pct'], 2), int(float(r['n_arrived'])),
              int(float(r['n_lost'])), _f(r['path_length'], 0)] for r in vr],
            widths=[0.5, 1.95, 0.8, 0.65, 1.0, 0.9, 0.75, 0.75, 0.85],
            align='llrrrrrrr', font_size=6.8)

    # shift = scenario rank - CEC rank, so a negative value means the variant
    # stands higher on the scenario than on the benchmark
    up = [h for h, d in shift.items() if d < 0]
    down = [h for h, d in shift.items() if d > 0]
    same = [h for h, d in shift.items() if d == 0]
    _eq = (f', {len(same)} keep the same rank' if same else '')
    big = max(shift, key=lambda h: abs(shift[h]))
    cec1 = next(h for h, r in cec.items() if r == 1)
    cec1_rank = next(int(r['uav_rank']) for r in vr if r['host'] == cec1)
    P.para(
        f'Table {{t4}} also places the two orderings side by side.  Of the '
        f'{len(vr)} variants, {len(up)} rank better on the scenario than on '
        f'the benchmark, {len(down)} rank worse{_eq}, the median displacement '
        f'being {np.median([abs(d) for d in shift.values()]):.0f} ranks; the '
        f'Spearman correlation between the two orderings is '
        f'$\\rho={rho.statistic:.2f}$ ($p={rho.pvalue:.2f}$, $n={len(vr)}$).  The '
        f'benchmark leader {cec1} is {cec1_rank}th here, while the scenario '
        f'leader {vr[0]["host"]} is '
        f'{cec[vr[0]["host"]]}th on the benchmark; the largest single '
        f'movement is {big} ({shift[big]:+d} ranks).  A re-ordering of this '
        f'kind is expected rather than anomalous, because the two orderings '
        f'answer different questions: the benchmark ranks variants by the '
        f'log-10 final error over a suite of artificial functions of fixed '
        f'dimension, whereas the scenario ranks them by how they trade detour '
        f'against clearance in a task whose outcome is decided by a rare event '
        f'rather than by the variant.  The weak, non-significant correlation is what that '
        f'difference of objectives produces, and it agrees with the '
        f'within-noise character of the scenario ordering in Table {t4}.')

    ev_all = _event_row('all')
    ev_bare = _event_row('all', 'bare')
    plat = plateau('all', 'bare')
    pw3 = power('observe', runs=3)
    pw2 = power('detect', ratio=2.0)
    pw3x = power('detect', ratio=3.0)
    n_ev = int(ev_all['n_runs'])
    hp_pts = float(ev_all['base_hp_max'])
    aerial_pts = float(ev_all['aerial_dmg']) * hp_pts
    P.para(
        f'The mission-level columns of Table {{t4}} have to be re-read before '
        f'the breakdown by task, because the arrival column is an event '
        f'counter and the CSR is a weighted mean of three facets whose terminal '
        f'one is met once in the campaign.  Table {{t5}} '
        f'reports those events as rates with $95\\%$ Wilson intervals over the '
        f'rollouts of each task, the two arms pooled.  The aerial half of the '
        f'mission is close to saturated: in {rate_cell(ev_all, "air")} of the '
        f'{n_ev} rollouts both UAVs complete the penetration and bomb the base, '
        f'which removes a fixed '
        f'{aerial_pts:.0f} of the '
        f'{hp_pts:.0f} health points and is why the '
        f'median base health is the same in every cell of Table {{t6}}.  The '
        f'ground half of the mission is not saturated: the infantry reach the '
        f'base in {rate_cell(ev_all, "gnd")} of the same rollouts, and that '
        f'arrival decides the rest of the damage, because an arrived squad '
        f'keeps firing while the aerial damage is delivered once.  The evidence '
        f'is exact: of the {n_ev} rollouts, the '
        f'{int(ev_all["extra_k"])} whose base ends below the aerial-only level '
        f'are precisely the {int(ev_all["extra_gnd_k"])} in which a squad also '
        f'reached the base.  The base is destroyed in '
        f'{rate_cell(ev_all, "dest")} of the rollouts, '
        f'{int(ev_all["dest_k"])} of them in the whole experiment.  The binary '
        f'success indicator is therefore a threshold placed outside the range '
        f'the search reaches, and its median is zero by construction: at the '
        f'bare arm\'s arrival rate of {float(ev_bare["gnd_pct"]):.1f}% and '
        f'$R=3$ runs per cell, the median of the indicator is zero in '
        f'{100 * float(pw3["median_zero"]):.0f}% of the cells even if every '
        f'variant behaved identically, so a pool median taken over such cells '
        f'is zero whatever the variants do, which is why the outcome is carried '
        f'by the graded CSR of Table {{t6}} from here on.  Read as a rate, the '
        f'same evidence '
        f'says the opposite of "every algorithm fails": the decisive sub-event '
        f'is accomplished in {rate_cell(ev_all, "gnd")} of the rollouts, '
        f'roughly one rollout in six.')
    t_ev = _nt(P)

    P.table_caption('Mission-level event rates on the interception scenario '
                    'with $95\\%$ Wilson intervals.  Each rate is the share of '
                    'the rollouts of that task (both arms pooled, $R=3$ runs '
                    'and $29$ variants) in which the event occurred, and the '
                    'base damage is the mean fractional loss of base health '
                    'over the same rollouts.')
    P.table(event_rate_headers(), event_rate_table(),
            widths=[0.7, 0.75, 1.5, 1.5, 1.15, 1.05],
            align='lrrrrr', font_size=7.2)

    P.para(
        f'Two questions follow from those rates.  The first is whether the '
        f'budget is large enough.  For the objective the search is given, it is '
        f'not the binding constraint: reading each rollout\'s best-so-far curve '
        f'against the budget it has consumed, the bare arm reaches $50\\%$ of '
        f'its total improvement after {100 * float(plat["t50"]):.1f}% of the '
        f'budget, $90\\%$ after {100 * float(plat["t90"]):.1f}% and $99\\%$ '
        f'after {100 * float(plat["t99"]):.1f}%, while the last $5\\%$ of the '
        f'budget adds a median {100 * float(plat["tail5"]):.1f}% of the total '
        f'improvement, so the search has effectively stopped improving well '
        f'before the evaluations run out and the within-noise ordering reported '
        f'here is not an artefact of a truncated run.  That measurement bounds '
        f'the budget effect on the objective only; it cannot see the rare ground '
        f'arrival, which is not a term of the aggregate curve, and a larger '
        f'budget might still change the arrival rate, which is why the arrival '
        f'rate is reported as the raw quantity and not as a claim about '
        f'convergence.  The second question is whether the outcome can resolve '
        f'the algorithms at all, and there the limiting factor is sample size '
        f'rather than budget: at the observed arrival rate a cell shows at least '
        f'one arrival with probability {100 * float(pw3["value"]):.0f}%, so most '
        f'cells read zero for reasons that have nothing to do with the variant, '
        f'and separating a variant that arrives twice as often as another would '
        f'take about {int(pw2["runs"])} runs per cell at $80\\%$ power, or '
        f'{int(pw3x["runs"])} for a threefold difference.  With $R=3$ the '
        f'scenario cannot rank the variants by the terminal event even in '
        f'principle: only ${int(ev_all["dest_k"])}$ of '
        f'${int(ev_all["n_runs"])}$ rollouts collected in Table {{t5}} end in a '
        f'success, which is why the ordering is built on the '
        f'continuous quantities - the graded CSR and the geometric metrics - '
        f'whose run-to-run spread is small enough to be resolved at $R=3$.')

    # --- graded completion: CSR and its three components ------------------
    ev0 = _event_row('all')
    mb, mf = _mission_mean('bare'), _mission_mean('full')
    mis = {(r['fid'], r['arm']): r for r in _rows('uav_mission_summary.csv')}
    csr_b = _mission_cell('bare', 'composite')
    csr_f = _mission_cell('full', 'composite')
    dmg_b = _mission_cell('bare', 'damage')
    dmg_f = _mission_cell('full', 'damage')
    brc_b = {f: float(mis[(f, 'bare')]['breach_pct']) for f in ('1', '2', '3', '4')}
    brc_f = {f: float(mis[(f, 'full')]['breach_pct']) for f in ('1', '2', '3', '4')}
    wb, wf = weight_rows('bare'), weight_rows('full')
    rhob = [float(r['spearman_rho']) for r in wb]
    rhof = [float(r['spearman_rho']) for r in wf]
    alt = [r for r in wb + wf if r['weights'] != '0.50/0.25/0.25']
    lead0 = {r['arm']: r['top3'].split(';')[0]
             for r in wb + wf if r['weights'] == '0.50/0.25/0.25'}
    moved = [(r['arm'], r['weights'], r['top3'].split(';')[0])
             for r in alt if r['top3'].split(';')[0] != lead0[r['arm']]]
    t_mis = _nt(P)
    f_mis = P.fig_no + 1
    P.para(
        f'The terminal event is met {int(ev0["dest_k"])} times in the '
        f'{int(ev0["n_runs"])} rollouts of Table {{t5}}, and it is easy to '
        f'read that as "every variant fails".  '
        f'That reading belongs to the threshold rather than to the search, and '
        f'Table {t_mis} takes the threshold out: its first column is the CSR '
        f'of Section 5.3 and the next three are the components it averages - '
        f'the share of the base health removed, the share of the ground team '
        f'that reached the base, and the '
        f'share of the patrol force killed.  Each entry is the mean over the '
        f'$29$ variants of the per-cell median over $R=3$ runs, and the '
        f'half-width is the $95\\%$ confidence interval across variants.  '
        f'Pooled over the four tasks the CSR is {mb["composite"]:.1f}% at the '
        f'bare arm and {mf["composite"]:.1f}% with the layer: the base loses '
        f'{mb["damage"]:.1f}% of its '
        f'health at the bare arm and {mf["damage"]:.1f}% with the layer, the '
        f'ground team puts {mb["breach"]:.1f}% of its strength inside the base '
        f'against {mf["breach"]:.1f}%, and {mb["kill"]:.1f}% against '
        f'{mf["kill"]:.1f}% of the patrol force is killed.  Across cells the '
        f'CSR runs from {min(csr_b):.1f}% to {max(csr_b):.1f}% at the bare arm '
        f'and from {min(csr_f):.1f}% to {max(csr_f):.1f}% with the layer, and '
        f'the removed share from {min(dmg_b):.1f}% to {max(dmg_b):.1f}% bare '
        f'against {min(dmg_f):.1f}%-{max(dmg_f):.1f}% with the layer, so the '
        f'outcome does discriminate once it is read as a '
        f'quantity.')
    P.para(
        f'Two features of Table {t_mis} matter.  First, the removed share is '
        f'bounded below by the aerial payload: the two UAVs deliver a fixed '
        f'{100 * aerial_pts / hp_pts:.0f}% of the base health in every rollout '
        f'that completes the penetration, so a cell at that level has finished '
        f'the aerial half and not the ground half, and everything above it is '
        f'the ground contribution.  The inside-base share is what separates the '
        f'tasks: it is {brc_b["1"]:.1f}% and {brc_b["2"]:.1f}% at the bare arm '
        f'on F1 and F2, {brc_b["3"]:.1f}% on F3 and F4, and the layer lifts it '
        f'to {brc_f["2"]:.1f}% on F2 and {brc_f["4"]:.1f}% on F4 while leaving '
        f'F1 at {brc_f["1"]:.1f}%.  Second, the killed share is flat across '
        f'tasks and slightly lower with the layer, the same clearance trade-off '
        f'that Table {{t4}} reports as a rate.  The terminal flag is '
        f'therefore the endpoint of a graded curve and not a cliff: arriving at '
        f'the target already removes a fixed slice of it, and the graded '
        f'columns keep the part of the mission that the flag '
        f'discards.  Fig. {f_mis} draws the CSR and the three components side '
        f'by side.')
    P.para(
        f'The weights of the CSR are a stated choice, so the ordering they '
        f'produce was re-computed under three alternatives - equal weights, '
        f'0.60/0.20/0.20 and 0.70/0.15/0.15 - by scoring each variant on the '
        f'four tasks and ranking the pool again.  The Spearman correlation '
        f'with the published ordering is '
        f'{min(rhob[1:]):.3f}-{max(rhob[1:]):.3f} on the bare arm and '
        f'{min(rhof[1:]):.3f}-{max(rhof[1:]):.3f} with the layer '
        f'($p<0.001$ in every case), so the '
        f'ordering is not an artefact of the weights; the leader is unchanged '
        f'in {len(alt) - len(moved)} of the {len(alt)} alternative orderings'
        + ('' if not moved else
           f', and the one exception is a swap of the two front-runners '
           f'({moved[0][2]} ahead of {lead0[moved[0][0]]} on the '
           f'{moved[0][0]} arm under {moved[0][1]} weights)')
        + f'.  What the weights do decide is the level, not the order: with the '
        f'CSR bounded by {csr_peak()[0]:.1f}% in the archive, no reading of '
        f'this scenario supports the sentence "the variant completes the '
        f'mission", only "it completes this much of it".')
    P.para(
        f'Two limits of such an index are worth stating. The first is that a '
        f'weighted sum can hide a trade: two variants with the same CSR may '
        f'differ in whether they removed base health or put soldiers inside '
        f'the base, which is why Table {t_mis} reports the three components '
        f'beside the index instead of folding them into it, and why the '
        f'reading of the tasks below goes back to the components. The second '
        f'is that the index is a cell-level mean and says nothing about '
        f'dispersion: a cell at a given CSR may have reached it in every '
        f'rollout or in one run out of three, and a mean over the variants '
        f'cannot tell those two cases apart. The run-wise consistency '
        f'statistics of Section 5.4 exist for that reason, and they are read '
        f'as a bound on how much weight any small difference in the index can '
        f'carry. Within those limits the composite is used for one purpose '
        f'only: to place the {len(vr)} variants on a single scale on which the '
        f'two arms and the four tasks can be compared, so that a statement '
        f'about the layer keeps the same sign across the metrics it was built '
        f'from. The conclusions drawn from it are comparisons between arms, '
        f'not statements about absolute mission capability.')
    P.table_caption('Composite success rate and its components on the '
                    'interception scenario, the two arms side by side.  CSR $= '
                    '0.50$ weakened $+ 0.25$ inside base $+ 0.25$ killed.  '
                    'Weakened: share of the base '
                    'health removed; inside base: share of the ground team that '
                    'reached the base; killed: share of the patrol force '
                    'killed.  Mean over the $29$ variants of the per-cell '
                    'median over $R=3$ runs, $\\pm$ the $95\\%$ confidence '
                    'half-width across variants.')
    P.table(['Task', 'Arm', 'CSR (%)', 'Weakened (%)', 'Inside base (%)',
             'Killed (%)'],
            mission_table(),
            widths=[0.7, 0.75, 1.1, 1.2, 1.3, 1.05],
            align='llrrrr', font_size=7.4)
    P.figure(PFG.fig('uav_mission'),
             'Composite success rate and its components on the four tasks: '
             'panel (a) (shaded) is the CSR, and panels (b)-(d) are the share '
             'of the base health removed, the share of the ground team that '
             'reached the base and the share of the patrol force killed.  '
             'Bars are means over the '
             '$29$ variants, error bars the $95\\%$ confidence intervals, and '
             'the two arms are drawn side by side.')

    md = _median_by_task('min_dist')
    sp_md = _spread_by_task('min_dist')
    pl = _median_by_task('path_length')
    fc = _median_by_task('first_capture')
    P.para(
        f'The four tasks themselves are not interchangeable.  '
        f'Table {{t7}} breaks the outcome down by task for both arms, each '
        f'cell being the median over the {len(vr)} variants.  The '
        f'minimum interceptor distance is the metric that follows task '
        f'difficulty most closely: its pool median falls from '
        f'{md["1"]:.0f} m on F1 to {md["4"]:.0f} m on F4, where two faster '
        f'interceptors patrol, and within a single task the pool already spans '
        f'a comparable range (F1: {min(sp_md["1"]):.0f}-'
        f'{max(sp_md["1"]):.0f} m).  The path lengthens from {pl["1"]:,.0f} m '
        f'on F1 to {pl["3"]:,.0f} m on F3, as the search pays detour for the '
        f'restricted airspace and the second interceptor, and then shortens '
        f'again to {pl["4"]:,.0f} m on F4, where the faster interceptors make '
        f'first capture earlier ({fc["4"]:.0f} steps into the rollout against '
        f'{fc["3"]:.0f} on F3).  The mission-level counters behave differently, '
        f'because they are event counters whose medians are zero when the event '
        f'is rare rather than when the variants are alike.  Read as rates in '
        f'Table {{t5}}, the ground team reaches the base in '
        f'{rate_cell(_event_row("1"), "gnd")} of the F1 rollouts, '
        f'{rate_cell(_event_row("2"), "gnd")} on F2, '
        f'{rate_cell(_event_row("3"), "gnd")} on F3 and '
        f'{rate_cell(_event_row("4"), "gnd")} on F4, and the base is destroyed '
        f'in only {int(ev_all["dest_k"])} of the {n_ev} rollouts.  That spread of '
        f'a factor of forty does not follow the difficulty column of Table '
        f'{{t1}}: the baseline task F1 is by far the hardest on which to move '
        f'the base health, and the two-interceptor tasks F3 and F4 are the '
        f'easiest.  The four tasks share one map, one patrol deployment, one '
        f'infantry start and the same reward weights on the ground half, so the '
        f'spread cannot come from the ground route being harder on F1; it is a '
        f'property of the joint search over the two halves of the reward, and '
        f'the difficulty column of Table {{t1}} describes the strength of the '
        f'air defence rather than the resolvability of the mission outcome.  '
        f'The family that is constant instead is the constraint family: no-fly '
        f'steps, out-of-bounds steps and crashes are zero for every variant on '
        f'every task, so those penalties never separate the pool.  The effective '
        f'objective of the scenario therefore reduces to how each variant trades '
        f'detour against threat distance.')
    t5 = _nt(P)

    P.table_caption('Median key metrics over the $29$ variants on each task, '
                    'for the bare and the UPCL-augmented configuration.')
    P.table(['Metric'] + [f'F{f} {a}' for f in ('1', '2', '3', '4')
                          for a in ('bare', 'full')],
            task_metrics_table(),
            widths=[1.5] + [0.66] * 8,
            align='l' + 'r' * 8, font_size=6.5)

    rbf = {r['fid']: r for r in _rows('uav_rank_by_fid.csv')}
    trk = {}
    for r in _rows('uav_task_rank.csv'):
        trk.setdefault(r['fid'], []).append(r)
    tops = {f: min(rows, key=lambda r: int(r['task_rank']))
            for f, rows in trk.items()}
    f0 = P.fig_no + 1
    P.para(
        'Read task by task, the two orderings agree to a different degree on '
        f'each of them, so the pooled correlation of Table {t4} is the average '
        'of four different answers rather than one common answer.  Between the '
        'CEC 2017 $D=30$ rank and the scenario rank the Spearman correlation '
        'is '
        + ', '.join(
            f'$\\rho={float(rbf[f]["spearman_rho"]):.2f}$ '
            f'($p={float(rbf[f]["p"]):.2f}$) on F{f}'
            for f in ('1', '2', '3', '4') if f in rbf)
        + ', so only on F1 does the benchmark order carry over at the $0.05$ '
          'level.  The variant heading a task is '
        + ', '.join(
            f'{tops[f]["host"]} on F{f} (CEC rank {int(tops[f]["cec_rank"])})'
            for f in ('1', '2', '3', '4') if f in tops)
        + f'.  Fig. {f0} draws the four scatter plots side by side in one '
          '$2\\times2$ grid, each panel with the diagonal of perfect transfer: '
          'the migration is not one global re-ordering that a single panel '
          'could summarise, and a variant near the top of one task need not be '
          'near the top of another.')
    P.figure(PFG.fig('uav_rank_scatter'),
             'Transfer of the CEC 2017 $D=30$ rank (horizontal axis) to the '
             'interception-scenario rank (vertical axis); panels (a)-(d) are '
             'F1-F4, the dashed line is perfect transfer and each panel title '
             'reports its Spearman correlation.', width_in=5.5)

    P.para(
        'Each task is then read on its own, because the four rankings are '
        'different rankings of the same pool and a single merged table would '
        'hide exactly that.  Sections 5.4.1 to 5.4.4 give, for one task at a '
        'time, its own ranking table and what the two arms do on it; Section '
        '5.5 then follows one cell of those tables through the flight '
        'geometry.')

    P.para(
        'Every ordering reported in the four subsections that follow is '
        'descriptive. With $R=3$ runs per cell the pairwise differences are '
        'not resolved at the $0.05$ level, the power analysis above states how '
        'many runs a twofold difference in the terminal event would need, and '
        'no claim is made about which variant is best on a task.')

    for fid in TASK_FIDS:
        _task_block(P, fid)

    # t7 (the run-wise sign consistency table) is emitted immediately after
    # this one by _consistency(), with no table in between.
    t6 = _nt(P)
    P.para(
        f'The two arms exist to characterise the layer rather than to score '
        f'it.  Because UPCL only corrects the candidate solutions proposed by '
        f'the host, the questions are what its correction reaches inside this '
        f'scenario and whether that effect reproduces.  Table {t6} therefore '
        f'reports the same-seed change of each semantic group between the two '
        f'arms, averaged over the four tasks and the $R=3$ runs, together with '
        f'its $95\\%$ confidence interval over the $29$ variants; the '
        f'run-level sign consistency of each group is reported in Table '
        f'{t6 + 1}.')

    hg = _rows('uav_mech_host_gain.csv')
    gain_num = []
    for g in GROUP_ORDER:
        v = np.array([float(r[g]) for r in hg])
        n = len(v)
        m = float(v.mean())
        se = float(v.std(ddof=1) / np.sqrt(n))
        ci = se * float(stats.t.ppf(0.975, n - 1))
        gain_num.append((g, m, m - ci, m + ci))
    spanning = [g for g, _m, lo, hi in gain_num if lo <= 0 <= hi]
    P.table_caption('Same-seed change of each metric group between the two '
                    'arms (mean over the $29$ variants with $95\\%$ '
                    'confidence interval).')
    P.table(['Group', 'Mean change', 'CI low', 'CI high'],
            [[GROUP_MEANING[g], _f(m, 3, True), _f(lo, 3, True),
              _f(hi, 3, True)] for g, m, lo, hi in gain_num],
            widths=[2.4, 1.3, 1.3, 1.3], align='lrrr')

    st = _delta_stats(('path_length', 'min_dist', 'curvature', 'flight_time',
                       'n_arrived', 'n_lost'))
    P.para(
        f'The per-metric detail shows where the correction lands.  The '
        f'continuous geometric quantities move by a substantial amount: over '
        f'all {st["path_length"]["n"]} cells the median relative change is '
        f'{st["path_length"]["rel_pct"]:.1f}% for the path length, '
        f'{st["min_dist"]["rel_pct"]:.1f}% for the minimum interceptor '
        f'distance, {st["curvature"]["rel_pct"]:.1f}% for the curvature and '
        f'{st["flight_time"]["rel_pct"]:.1f}% for the flight time.  The '
        f'event-driven outcomes, by contrast, are not merely small but '
        f'untouched: {st["n_arrived"]["zero"]} of the {st["n_arrived"]["n"]} '
        f'cells have exactly the same arrival count in the two arms and '
        f'{st["n_lost"]["zero"]} have exactly the same loss count.  The layer '
        f'therefore re-shapes how the fleet flies (its detour, its curvature '
        f'and its clearance) while the discrete mission outcome, which is '
        f'decided by event-driven interception, stays where it was.')

    P.para(
        f'The re-shaping is also not a systematic shift.  Averaged over the '
        f'variants, {len(spanning)}/{len(gain_num)} of the pooled intervals in '
        f'Table {t6} contain zero, and the direction of the per-metric change '
        f'splits almost evenly across the pool: the path is longer in '
        f'{st["path_length"]["up"]} cells and shorter in '
        f'{st["path_length"]["down"]}, while the minimum interceptor distance '
        f'is larger in {st["min_dist"]["up"]} cells and smaller in '
        f'{st["min_dist"]["down"]}.  The constraint family is identically zero '
        f'because both arms keep those counters at zero on every task (see the '
        f'per-task medians of Table {t5}), so no correction can act there at all.  '
        f'Whether the residual differences are reproducible is the question '
        f'addressed next.')

    _consistency(P)


# ===========================================================================
# 5.4.4  Stability of the residual differences
# ===========================================================================
def _consistency(P):
    t7 = _nt(P)
    P.para(
        'One question still has to be settled before the residual differences '
        'are given any weight.  Because the change is small and the intervals '
        'are wide, is it a property of the variant and the task, or only of the '
        f'run?  Table {t7} reports, for each group, the fraction of the '
        'variants whose three runs all keep the sign of the pooled '
        'mean.')

    cons = _rows('uav_gain_run_consistency.csv')
    P.table_caption('Run-wise consistency of the two-arm change: fraction of '
                    'the variants whose per-group change keeps the pooled '
                    'sign in all three runs.')
    P.table(['Group', 'Same-sign', 'Total', 'Ratio'],
            [[GROUP_MEANING[r['metric_group']], r['same_sign'], r['total'],
              _f(float(r['ratio']) * 100, 1)] for r in cons],
            widths=[2.4, 1.2, 1.0, 1.2], align='llrr')

    top = max(cons, key=lambda r: float(r['ratio']))
    zero_groups = [GROUP_MEANING[r['metric_group']] for r in cons
                   if float(r['ratio']) <= 0]
    P.para(
        'Consistency is low everywhere: at best '
        f'{_f(float(top["ratio"]) * 100, 1)}% of the variants keep the pooled '
        f'sign in all three runs, for '
        f'{GROUP_MEANING[top["metric_group"]]}, and the sign is never kept at '
        f'all in {len(zero_groups)} of the {len(cons)} groups.  A change whose '
        'direction flips from run to run, for the same variant and the same '
        'task, is indistinguishable from the scenario\'s own run-to-run '
        'variation, so the per-variant changes of Section 5.4 should not be '
        'read as reliable per-variant effects.')


# ===========================================================================
# 5.5  Case study
# ===========================================================================
def _case(P):
    P.h2('5.5  Case study: what a single run does')

    vr = _rows('uav_value_rank.csv')
    ref = next(r for r in vr if r['host'] == 'NL-SHADE-RSP')
    dl = {r['metric']: r for r in _rows('uav_upcl_delta.csv')
          if r['host'] == 'NL-SHADE-RSP' and r['fid'] == '1'}

    def _pair(stem):
        r = dl[stem]
        return float(r['bare_median']), float(r['full_median'])

    p0, p1 = _pair('path_length')
    c0, c1 = _pair('curvature')
    e0, e1 = _pair('path_efficiency')
    d0, d1 = _pair('min_dist')
    n_arr, n_lost = _pair('n_arrived')[0], _pair('n_lost')[0]

    f0 = P.fig_no + 1
    P.para(
        f'Representative runs are examined in detail.  For each task, the '
        f'best, the median and the worst variant of the scenario ranking are '
        f'overlaid in Figs. {f0}-{f0 + 3}: every panel puts the bare arm and '
        f'the UPCL-augmented arm on the same sandtable under the same random '
        f'seed, so any difference between the two routes is attributable to '
        f'the layer.  Each figure is a $3\\times2$ grid whose columns are the '
        f'three variants of the task ranking and whose rows show the same runs '
        f'first with the terrain background removed and then with the terrain, '
        f'so that the flight geometry can be read on its own before it is put '
        f'back on the terrain.')
    P.para(
        'The first task is the one to read the convention on. Its columns are '
        'the best, the median and the worst variant of the F1 ranking, so the '
        'three panels bracket the pool rather than sampling it: an effect that '
        'appears in all three columns is not an effect of which variant was '
        'chosen, and an effect that appears only in the extreme columns is. In '
        'the upper row the terrain is removed and the two arms are drawn on '
        'the same grid, which is where the geometry of a difference becomes '
        'visible at all - a detour around a ridge is legible there and '
        'illegible against the shading of the lower row. The lower row returns '
        'the same two routes to the terrain, and it is the row to use when '
        'asking whether a difference survives at the altitude the rollout '
        'actually flew: a route that looks shorter from above can be the '
        'longer one once the climb is charged. Both arms start at the same '
        'point under the same seed, so the two routes coincide until the first '
        'accepted correction and separate only at the proposals the layer '
        'changed. Where they coincide for a whole run nothing was corrected, '
        'which on this scenario is a frequent outcome and is read as such '
        'rather than as a defect of the drawing: a layer that finds nothing '
        'worth correcting leaves a provably identical trace, and the visual '
        'counterpart of a low intervention rate is exactly this overlap.')
    _traj_notes = {
        '2': (
            'The second task adds a forbidden airspace and nothing else, so the '
            'figure isolates one cause. Every route in every panel must now '
            'enter the corridor between the zone and the ridge, and the '
            'question the panels answer is not whether a route got round the '
            'zone - all of them do, since a route through it is infeasible - '
            'but what the detour costs and where the cost is paid. Two '
            'patterns are therefore worth separating. A pair that is identical '
            'in the upper row and identical in the lower row says the layer '
            'found nothing to change on a route that was already forced, which '
            'is the expected outcome when the feasible set is narrow: the '
            'constraint, not the search, decides the path. A pair that differs '
            'in the upper row but converges in the lower says the geometric '
            'change was real and did not survive the altitude charge, and that '
            'is the case to read against the path metrics rather than against '
            'the drawing. Because the zone is a hard constraint enforced inside '
            'the rollout, no panel can show its violation; the panels can only '
            'show the margin with which it is respected, and it is the margin '
            'that a correction can move.'),
        '3': (
            'The third task changes the opposition rather than the map: a '
            'second interceptor is added and the pair is allowed to coordinate, '
            'so the same two routes are flown against a capture geometry that '
            'reaches further along the corridor. This is the task on which a purely '
            'geometric difference is least informative, because a route that '
            'looks like a small deviation from above may be the one that keeps '
            'the aircraft outside a moving capture cone at the moment the '
            'interceptor launches. The lower row is consequently read for '
            'spacing rather than for length: the two routes are compared by '
            'where they pass the ridge line relative to the interceptor '
            'positions, and the metric that corresponds to that reading is the '
            'minimum interceptor distance reported in the tables rather than '
            'the path length. A pair of routes that separate in this figure and '
            'not in the previous one is the clearest evidence available at the '
            'level of a single run that the layer is responding to the threat '
            'geometry and not to the shape of the terrain. One further '
            'consequence follows from the way the routes are encoded: the '
            'resolution of the polyline is fixed by the scenario, so the layer '
            'moves the same waypoints rather than adding new ones, and a '
            'difference that shows up as a single shifted vertex is '
            'nevertheless a real change in the path actually flown.'),
        '4': (
            'The compound task combines what the previous two add separately: '
            'the forbidden airspace, the faster interceptors and the '
            'coordination between them are all present, so no single cause can '
            'be attached to a difference and the figure is read as an outcome '
            'rather than as a diagnostic. Two things remain legible. The first '
            'is whether the two arms still coincide, which after three tasks '
            'with low intervention rates is the question most likely to be '
            'answered in the affirmative and, if so, closes the sequence with '
            'the same statement it opened with. The second is the spread across '
            'the three columns: a panel that shows the two arms apart in the '
            'best column and together in the worst says that what the layer can '
            'add depends on which variant it is attached to, which is the same '
            'conclusion the pooled statistics reach from the other direction. '
            'The sequence also closes in a second sense. Because the four '
            'figures use the same three column positions, the four best '
            'variants can be compared with one another by reading down the '
            'first column alone, and the same holds for the median and for the '
            'worst; read that way the four figures answer a question none of '
            'the pooled statistics can, namely whether one variant is strong on '
            'all four tasks or strong on one of them. Where the first column is '
            'filled by different variants on different tasks, the task ordering '
            'is driven by the setting rather than by the variant, which is the '
            'reading suggested by the per-task medians reported earlier in this '
            'section.'),
    }
    for fid in ('1', '2', '3', '4'):
        if fid in _traj_notes:
            P.para(_traj_notes[fid])
        P.figure(PFG.fig('uav_traj_F%s' % fid),
                 f'Task F{fid}: the best, the median and the worst variant of '
                 'the task ranking (columns), with the terrain background '
                 'removed (upper row) and with the terrain (lower row); each '
                 'panel overlays the bare arm (blue) and the UPCL arm (red) '
                 'under the same seed.')

    P.para(
        f'One cell is then read out numerically: NL-SHADE-RSP on task F1, '
        f'whose composite score places it at rank {ref["uav_rank"]} of the '
        f'$29$ variants on this scenario.  The two arms fly the same corridor '
        f'and both '
        f'reach the base, and the difference between them is a re-shaping of '
        f'the approach rather than a different outcome.  The augmented arm '
        f'returns a path '
        f'{abs(p1 - p0):,.0f} m shorter ({p1:,.0f} m against {p0:,.0f} m) with '
        f'lower curvature ({c1:.2f} against {c0:.2f}) and a higher path '
        f'efficiency ({e1:.3f} against {e0:.3f}), yet it passes closer to the '
        f'interceptor, whose minimum distance drops from {d0:.0f} m to '
        f'{d1:.0f} m.  The mission itself is unchanged: {n_arr:.0f} UAVs '
        f'arrive and {n_lost:.0f} is lost in both arms.  This is the pattern '
        f'identified in Section 5.4: in a single cell, the layer moves the geometry of the '
        f'flight, in a direction that varies between cells, while the '
        f'event-driven outcome stays fixed.')


# ===========================================================================
# 5.6  Discussion
# ===========================================================================
def _discussion(P):
    P.h2('5.6  Interpretation and discussion')

    ev_all = _event_row('all')
    ev_b_arm = _event_row('all', 'bare')
    ev_f_arm = _event_row('all', 'full')
    P.para(
        'Three observations summarise what the algorithms do on this '
        'scenario.  First, the pool is a narrow band rather than a ranking: '
        'on all four tasks the variants reach closely comparable outcomes, so '
        'the composite ordering should be read as a within-noise ordering, not '
        'as a capability hierarchy, and it does not reproduce the benchmark '
        'order either, as Table {t4} shows.  Second, the informative '
        'differences are concentrated in evasion safety and path quality: the '
        'minimum interceptor distance and the path length are the two metrics '
        'that separate the variants, whereas the mission-level events are '
        'measurable but not attributable: the ground team reaches the base in '
        f'{rate_cell(ev_all, "gnd")} of the '
        f'{int(ev_all["n_runs"])} rollouts and the base is destroyed twice, and '
        f'against those rates $R=3$ runs per cell cannot resolve a variant '
        f'effect, as Table {{t5}} shows.  The constraint counters, finally, '
        'are zero '
        'for every variant on every task.  Third, the UPCL layer re-shapes the '
        'flight geometry without changing the outcome: it moves the detour, '
        'the curvature and the clearance, leaves the arrival and loss '
        'counters identical, and does so in a direction that varies across the '
        'pool and across runs.  At the level of the graded outcome '
        'the two arms differ by a few points at most - the ground-arrival rate '
        f'is {float(ev_b_arm["gnd_pct"]):.1f}% in the bare arm against '
        f'{float(ev_f_arm["gnd_pct"]):.1f}% with the layer, on '
        f'{int(ev_b_arm["n_runs"])} rollouts each, and the pooled CSR is '
        f'{_mission_mean("bare")["composite"]:.1f}% against '
        f'{_mission_mean("full")["composite"]:.1f}% - which is inside the '
        'intervals of the observation above and is the mission-outcome reading '
        'of the same null result.')

    P.para(
        'The scenario itself explains this pattern.  Task accomplishment is '
        'under-resolved rather than impossible: the aerial damage is delivered '
        f'almost deterministically ({rate_cell(ev_all, "air")} of the rollouts '
        f'land both UAVs and bomb the base) but it removes only a fixed '
        f'{float(ev_all["aerial_dmg"]) * float(ev_all["base_hp_max"]):.0f} of the '
        f'{float(ev_all["base_hp_max"]):.0f} health points, while the remaining '
        'health is removed by a ground arrival that the scenario makes rare '
        f'({rate_cell(ev_all, "gnd")} of the rollouts, and every rollout whose '
        f'base ends below the aerial-only level is one of them).  The budget is '
        'not what blocks it: the best-so-far curve of the bare arm has captured '
        f'$99\\%$ of its total improvement once '
        f'{100 * float(plateau("all", "bare")["t99"]):.1f}% of the budget is '
        'spent and the last $5\\%$ of the budget adds nothing measurable, so '
        'the search has stopped improving on the objective it is given well '
        'before the evaluations run out.  What blocks a mission-outcome ranking '
        'is the sample size: the decisive event is rare enough that three runs '
        'per cell cannot resolve it, which is why the ordering reported here '
        'rests on the graded CSR and on the geometry of the approach - exactly '
        'the path and safety '
        'trade-off.  The constraint counters stay at zero in both arms because '
        'the trajectories produced by the search never enter the no-fly zone '
        'and never leave the permitted box, so these penalties cannot separate '
        'or be moved by any variant.  The ground fight is real but does not '
        f'reach the base: in '
        f'{float(ev_all["inf_lost_pct"]):.0f}% of the rollouts at least '
        'one infantry soldier is lost and one to two patrol soldiers are '
        'killed, yet a squad reaches the base in only '
        f'{float(ev_all["gnd_pct"]):.0f}%, which pins the coordination '
        'and patrol families at their floor.  Finally, the run-to-run variation '
        'of the detour term is of the same order as the difference between the '
        'two arms, which is why the change seen in a single run is not a '
        'reproducible effect of the layer.')

    P.para(
        'The scenario is a synthetic but physically parameterised surrogate: '
        'the terrain is procedural, the defenders follow scripted, '
        'deterministic doctrine, and the four tasks share one map.  That '
        'places it in the tradition of simheuristic evaluation, in which a '
        'metaheuristic is run against a simulation model of a system rather '
        'than against an analytic objective [@JUAN15], and it shares with '
        'expensive black-box studies the property that the evaluation budget '
        'is the binding constraint rather than the algorithm [@REGIS14].')

    P.para(
        'Three alternatives were considered and not taken, and the reasons '
        'bear on what the failed transfer of this section does and does not '
        'show.  The first is to replace the scripted defenders by learned '
        'ones: deep reinforcement learning reaches superhuman play in '
        'two-player games [@MNIH15][@SILVER18], multi-agent actor-critic '
        'methods are the standard tool for mixed cooperative-competitive '
        'teams [@LOWE17][@ZHANG_MARL21], and air-combat manoeuvre generation '
        'with such controllers has been demonstrated [@KONG20].  That would '
        'make the red side adaptive, but it would also make the objective '
        'stochastic in a way that three runs per cell cannot resolve, and it '
        'would replace a reproducible testbed by a policy whose own training '
        'variance would dominate the comparison.  The second is to hand the '
        'search itself to a learned proposer, which is what program search and '
        'chain-of-thought prompting with large language models now do for '
        'algorithm discovery and for reasoning steps [@FUNSEARCH][@WEI22], and '
        'what recent work does for evolutionary operators [@LIU_LLM_EA], a '
        'line now mapped out by survey work on the interface between the two '
        '[@ECLLM25]; the objection is not capability but attribution, since a '
        'gain could then '
        'no longer be assigned to the operator rather than to the model that '
        'wrote it.  The third is a richer mission model - communication '
        'constraints, several bases, partial observability - which would raise '
        'the dimension beyond the thirty variables used here and, on the '
        'evidence of Section 4, would mostly add variance to the same '
        'comparison.')

    P.para(
        'The practical reading for a user of these solvers is therefore '
        'concrete and scenario-bound: on an expensive, event-driven '
        'interception task of this kind, any of the $29$ variants is a '
        'reasonable choice, the choice matters mainly through the '
        'clearance-versus-detour trade-off.  Establishing a stable ordering '
        'would require an instance whose mission outcome is resolvable within '
        'the budget - a base whose health the aerial damage can move across '
        'the success threshold, or a ground route that is reached far more '
        'often - together with enough repetitions for the event rate to be '
        'estimated, rather than a larger pool of variants or a stronger air '
        'defence.')

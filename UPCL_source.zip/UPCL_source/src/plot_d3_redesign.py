"""D3.3 interaction redesign — round 2 candidates (temporary)."""
import sys
sys.path.insert(0, 'src')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from analyze_mech_attribution import load_cell_df, PAIRS, _short, _savefig

df = load_cell_df()
pairs = PAIRS[:4]
DIM_EN = {'archive': 'archive', 'param_class': 'param rule',
          'strategy': 'strategy', 'pop': 'population'}

groups = []
for a, b in pairs:
    for (ka, kb), sub in df.groupby([a, b]):
        vals = sub['dec_median'].dropna().values
        if len(vals) == 0:
            continue
        groups.append(dict(a=a, b=b, ka=ka, kb=kb, mean=float(np.mean(vals)),
                           vals=vals, nhost=int(sub['host'].nunique())))

allvals = np.concatenate([g['vals'] for g in groups])
vmax = max(abs(allvals.min()), abs(allvals.max())) * 1.15
cmap_obj = plt.get_cmap('RdBu_r')
norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)


def lab(g):
    return f"{_short(str(g['ka']))} \u00d7 {_short(str(g['kb']))}"


def sub_groups(a, b):
    return sorted([g for g in groups if g['a'] == a and g['b'] == b],
                  key=lambda g: -g['mean'])


def style(ax, y, gs, a, b):
    ax.axvline(0, color='0.3', lw=1.1, zorder=2)
    ax.set_yticks(y)
    ax.set_yticklabels([lab(g) for g in gs], fontsize=9.5)
    ax.set_xlim(-vmax, vmax)
    ax.grid(axis='x', color='0.85', alpha=0.4, zorder=0)
    ax.set_title(f'{DIM_EN[a]} \u00d7 {DIM_EN[b]}', loc='left',
                 fontsize=11.5, fontweight='bold')
    ax.tick_params(length=0)
    for s in ('top', 'right', 'left'):
        ax.spines[s].set_visible(False)


def add_cbar(fig, axes):
    sm = plt.cm.ScalarMappable(cmap=cmap_obj, norm=norm)
    sm.set_array([])
    fig.colorbar(sm, ax=axes.ravel().tolist(), orientation='horizontal',
                 fraction=0.025, pad=0.05,
                 label='dec mean  (log10 error removed, >0 = UPCL better)')


def finalize(fig, axes, title, fname):
    fig.subplots_adjust(left=0.17, right=0.97, top=0.96, bottom=0.10, hspace=0.55)
    add_cbar(fig, axes)
    fig.suptitle(title, fontsize=13, fontweight='bold')
    _savefig(fig, fname)
    plt.close(fig)


# ---- C2: diverging bars (fixed colorbar, vertical stack) ----
fig, axes = plt.subplots(4, 1, figsize=(11, 11))
for k, (a, b) in enumerate(pairs):
    ax = axes[k]
    gs = sub_groups(a, b)
    y = np.arange(len(gs))[::-1]
    ax.barh(y, [g['mean'] for g in gs],
            color=[cmap_obj(norm(g['mean'])) for g in gs],
            edgecolor='k', linewidth=0.4, height=0.68, zorder=3)
    style(ax, y, gs, a, b)
    for yi, g in zip(y, gs):
        m = g['mean']
        ax.text(m + (0.008 if m >= 0 else -0.008), yi,
                f'{m:+.3f}  (n={g["nhost"]})', va='center', fontsize=8,
                ha='left' if m >= 0 else 'right')
finalize(fig, axes, 'D3.3 (C2) dec-mean diverging bars  (sorted; color = dec, n = #hosts)',
         'attr_d3_c2_bar.png')

# ---- D: forest plot (mean point + IQR range, point size = #hosts) ----
fig, axes = plt.subplots(4, 1, figsize=(11, 11))
for k, (a, b) in enumerate(pairs):
    ax = axes[k]
    gs = sub_groups(a, b)
    y = np.arange(len(gs))
    means = np.array([g['mean'] for g in gs])
    lo = np.array([np.percentile(g['vals'], 5) for g in gs])
    hi = np.array([np.percentile(g['vals'], 95) for g in gs])
    ax.errorbar(means, y, xerr=[np.clip(means - lo, 0, None),
                                np.clip(hi - means, 0, None)], fmt='none',
                ecolor='0.55', elinewidth=1.3, capsize=0, zorder=1)
    ax.scatter(means, y, c=[cmap_obj(norm(m)) for m in means],
               s=[60 + g['nhost'] * 55 for g in gs],
               edgecolor='k', linewidth=0.6, zorder=3)
    style(ax, y, gs, a, b)
    for yi, g in zip(y, gs):
        ax.text(g['mean'] + 0.01, yi, f'{g["mean"]:+.3f}', va='center',
                fontsize=8)
finalize(fig, axes, 'D3.3 (D) forest plot  (dot = mean, bar = 5-95% range, size = #hosts)',
         'attr_d3_d_forest.png')

# ---- E: violin distribution ----
fig, axes = plt.subplots(4, 1, figsize=(11, 11))
for k, (a, b) in enumerate(pairs):
    ax = axes[k]
    gs = sub_groups(a, b)
    y = np.arange(len(gs))
    vp = ax.violinplot([g['vals'] for g in gs], positions=y, vert=False,
                       showmedians=False, showextrema=False, widths=0.85)
    for body, g in zip(vp['bodies'], gs):
        body.set_facecolor(cmap_obj(norm(g['mean'])))
        body.set_alpha(0.8)
        body.set_edgecolor('k')
        body.set_linewidth(0.5)
    ax.scatter([g['mean'] for g in gs], y, c='white', edgecolor='k',
               s=40, linewidth=0.8, zorder=4)
    style(ax, y, gs, a, b)
finalize(fig, axes, 'D3.3 (E) violin distribution  (white dot = mean, color = dec)',
         'attr_d3_e_violin.png')

print('done')

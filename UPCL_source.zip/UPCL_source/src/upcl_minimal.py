# -*- coding: utf-8 -*-
"""
Minimal UPCL -- a parameter-free reformulation of the Universal Proposal
Correction Layer.

Motivation
==========
The original ``upcl_framework.UPCLController`` exposes ~20 hand-tuned
hyper-parameters (epsilon schedule, exploration weights, UCB kappa, identity
margin, kernel bandwidth, shrinkage prior, ARD prior/warmup, geometric
contract/expand coefficients, ...).  Tuning that many knobs on a fixed
benchmark suite re-introduces the very over-fitting problem UPCL is meant to
solve: we would be optimising one black box by wrapping it in a *harder* black
box.

This module collapses the whole decision rule into three parameter-free
mechanisms, each replacing a cluster of the old knobs:

  1.  Action selection  ->  Thompson sampling on a kernel-regression posterior
      (replaces the epsilon schedule ``eps0/eps_min/eps_gens``, the fixed
      ``explore_weights``, the UCB ``ucb_kappa`` term and the adaptive
      ``margin``).  Exploration-vs-exploitation falls out of the posterior
      variance: an arm with thin evidence has a wide posterior and is sampled
      more often; an arm with confident evidence is exploited.  No schedule,
      no kappa, no margin.

  2.  Response model   ->  k-NN median bandwidth + unit-information prior
      (replaces ``bandwidth``, ``prior_strength``, ``n_min``, ``ard_prior``
      and ``ard_warmup``).  The kernel length-scale is the median distance of
      the stored descriptors to the query, and the ARD per-component
      relevance is the raw sample correlation (a 1e-3 numerical floor, not a
      hand-picked prior).  A thin-evidence prediction is shrunk towards zero
      with a unit-variance prior, so the posterior naturally widens when there
      is little data.

  3.  Geometry         ->  success-feedback multiplicative gains
      (replaces the fixed ``contract`` / ``expand``).  After observing the
      response of a contract/expand move the coefficient is multiplied by
      exp(+-r / (n+1)): a successful move is amplified, a harmful one is
      damped, with a Robbins-Monro step 1/(n+1).  The coefficients therefore
      converge to whatever magnitude actually helps on *this* (host, function)
      instance instead of being frozen at 0.5 / 1.6.

What remains in the config are *structural / numerical* constants only, not
decision hyper-parameters: the memory capacity (a physical buffer size), the
reference-sample count (a cost knob), the prototype count (a descriptor
definition), the feasibility-shrink floor and the degeneracy epsilon.

The public interface (``begin_generation`` / ``propose`` / ``observe`` /
``stats``) is identical to ``UPCLController`` so it drops into the existing
paired-experiment driver unchanged.
"""

import math

import numpy as np

from upcl_framework import (
    ACTION_NAMES, N_ACTIONS,
    A_IDENTITY, A_CONTRACT, A_EXPAND, A_REFLECT, A_PROJECT,
    _clamp,
)

# --- numerical-stability constants (NOT decision hyper-parameters) ----------
_DEGENERATE_EPS = 1e-24      # below this step length the proposal is a no-op
_ARD_FLOOR = 1e-3            # ARD relevance denominator floor (numerical)
_SIG_FLOOR = 1e-6            # descriptor std floor
_VAR_FLOOR = 1e-12           # posterior variance floor

# --- geometric physical bounds (NOT tuned points) ---------------------------
# A contract coefficient must stay strictly below 1 (a contract move shrinks)
# and an expand coefficient strictly above 1; the bounds only keep the
# feedback update inside a sane physical range.
_ALPHA_MIN, _ALPHA_MAX = 0.2, 0.9
_BETA_MIN, _BETA_MAX = 1.1, 2.5


# ===========================================================================
# Response memory: kernel regression with a posterior variance
# ===========================================================================
class MinimalResponseMemory:
    """Per-action kernel regression returning ``(r_hat, var)``.

    The bandwidth is the *median distance* of the stored descriptors to the
    query (a robust, fully data-driven length-scale); the per-component
    relevance is the raw sample correlation (ARD without a prior or a warmup
    threshold).  Predictions are shrunk towards zero with a unit-variance
    prior, so the posterior variance is

        var(z) = 1 / (1 + n_eff / sigma^2_local)

    which is 1 for no evidence (pure exploration) and shrinks as evidence
    accumulates (pure exploitation).  This single quantity drives Thompson
    sampling, so no separate exploration/exploitation machinery is needed.
    """

    def __init__(self, capacity=256, dim_z=5):
        self.dim_z = int(dim_z)
        self.cap = max(1, int(capacity) // N_ACTIONS)
        self.Z = np.zeros((N_ACTIONS, self.cap, self.dim_z), dtype=float)
        self.R = np.zeros((N_ACTIONS, self.cap), dtype=float)
        self.ptr = np.zeros(N_ACTIONS, dtype=np.intp)
        self.size = np.zeros(N_ACTIONS, dtype=np.intp)
        # Welford statistics for the ARD per-component length-scales.
        self._mu = np.zeros((N_ACTIONS, self.dim_z), dtype=float)
        self._m2 = np.zeros((N_ACTIONS, self.dim_z), dtype=float)
        self._rbar = np.zeros(N_ACTIONS, dtype=float)
        self._rm2 = np.zeros(N_ACTIONS, dtype=float)
        self._xr = np.zeros((N_ACTIONS, self.dim_z), dtype=float)
        self._ard_n = np.zeros(N_ACTIONS, dtype=float)
        # scratch reused by predict_all
        self._pred = np.zeros(N_ACTIONS, dtype=float)
        self._var = np.zeros(N_ACTIONS, dtype=float)

    # ------------------------------------------------------------------
    def add(self, z, a, r):
        p = int(self.ptr[a])
        self.Z[a, p] = z
        self.R[a, p] = r
        self.ptr[a] = (p + 1) % self.cap
        if self.size[a] < self.cap:
            self.size[a] += 1
        # Welford update (mean / M2 / component-response cross product).
        n = self._ard_n[a]
        mu = self._mu[a]
        d = z - mu
        mu += d / (n + 1.0)
        d2 = z - mu
        self._m2[a] += d * d2
        dr = r - self._rbar[a]
        self._rbar[a] += dr / (n + 1.0)
        self._rm2[a] += dr * (r - self._rbar[a])
        # Welford cross-term: (z - mu_old) * (r - rbar_new), where ``d``
        # still holds z - mu_old (mu was updated in place above).
        self._xr[a] += d * (r - self._rbar[a])
        self._ard_n[a] = n + 1.0

    # ------------------------------------------------------------------
    def _action_pred(self, a, z):
        """Return ``(r_hat, var)`` for action ``a`` at descriptor ``z``."""
        n = int(self.size[a])
        if n == 0:
            # No evidence: zero mean, unit variance (unit-information prior).
            return 0.0, 1.0
        Zm = self.Z[a, :n]
        Rm = self.R[a, :n]
        diff = Zm - z
        # ARD per-component length-scales from the sample std and the raw
        # component-response correlation (no prior, no warmup threshold).
        if n >= 2:
            na = self._ard_n[a]
            sig = np.maximum(np.sqrt(self._m2[a] / na), _SIG_FLOOR)
            sr = math.sqrt(max(self._rm2[a] / na, _VAR_FLOOR))
            rho = (self._xr[a] / na) / (sig * sr + _VAR_FLOOR)
            rho = np.clip(rho, -1.0, 1.0)
            scale = np.maximum(sig / (np.abs(rho) + _ARD_FLOOR), _SIG_FLOOR)
            ds = diff / scale
        else:
            ds = diff
        dist = np.sqrt(np.einsum('ij,ij->i', ds, ds))
        # k-NN median bandwidth: fully data-driven local length-scale.
        bw = float(np.median(dist)) + 1e-9
        w = np.exp(-0.5 * (dist / bw) ** 2)
        sw = float(w.sum())
        if sw <= 1e-12:
            # Query is isolated: fall back to the action's global response with
            # a wide posterior (global variance + unit prior).
            g = float(Rm.mean())
            vg = float(np.var(Rm)) if n > 1 else 1.0
            return g, vg + 1.0
        neff = sw * sw / float(np.dot(w, w))
        local = float(np.dot(w, Rm) / sw)
        res = Rm - local
        local_var = float(np.dot(w, res * res) / sw)
        local_var = max(local_var, _VAR_FLOOR)
        # Unit-information prior N(0, 1): posterior precision = 1 + n_eff/var.
        post_var = 1.0 / (1.0 + neff / local_var)
        return local, post_var

    # ------------------------------------------------------------------
    def predict_all(self, z):
        pred, var = self._pred, self._var
        for a in range(N_ACTIONS):
            pred[a], var[a] = self._action_pred(a, z)
        return pred, var

    def counts(self):
        return [int(self.size[a]) for a in range(N_ACTIONS)]


# ===========================================================================
# Minimal UPCL controller
# ===========================================================================
class MinimalUPCLController:
    """Parameter-free proposal-correction layer (Thompson + ARD + adaptive geo)."""

    def __init__(self, dim, lb, ub, seed=None, config=None):
        cfg = dict(config) if config else {}
        self.dim = int(dim)
        self.lb = np.full(int(dim), float(np.ravel(lb)[0])) if np.ndim(lb) == 0 \
            else np.asarray(lb, dtype=float).ravel()
        self.ub = np.full(int(dim), float(np.ravel(ub)[0])) if np.ndim(ub) == 0 \
            else np.asarray(ub, dtype=float).ravel()
        self.rng = np.random.default_rng(seed)

        # Structural constants only (buffer size / sampling cost / descriptor
        # definition), never decision hyper-parameters.
        self.mem_capacity = int(cfg.get('mem_capacity', 256))
        self.n_ref = int(cfg.get('n_ref', 32))
        self.n_proto = int(cfg.get('n_proto', 8))
        self.min_shrink = float(cfg.get('min_shrink', 0.5))

        self.memory = MinimalResponseMemory(self.mem_capacity, dim_z=5)

        # Population context
        self.s_ref = 1.0
        self.sigma_f = 1.0
        self.best_x = None
        self.ref_pts = None
        self._ref2 = None
        self._tmp_ref = None
        self._z = np.zeros(5)

        # Adaptive geometry (initial values are just starting points; the
        # feedback update below drives them to what actually helps).
        self.alpha = 0.5
        self.beta = 1.6
        self._n_geo = np.zeros(N_ACTIONS, dtype=float)

        # Success direction (cumulative average, no EMA rate).
        self.s_hat = None
        self._n_succ = 0
        self.protos = np.zeros((self.n_proto, self.dim))
        self.n_proto_filled = 0
        self._proto_ptr = 0

        self._pending = None

        # Diagnostics
        self.n_proposals = 0
        self.n_interventions = 0
        self.n_policy_act = 0
        self.gen_proposals = 0
        self.gen_interventions = 0
        self.gen_policy_act = 0
        self.action_counts = np.zeros(N_ACTIONS, dtype=np.int64)
        self.rho_curve = []
        self.rho_policy_curve = []
        self.mean_abs_shift = 0.0

    # ------------------------------------------------------------------
    def begin_generation(self, pop, fitness):
        self.population = pop
        self.fitness = fitness
        N = pop.shape[0]
        self.sigma_f = float(np.std(fitness)) + 1e-30
        self.best_x = pop[int(np.argmin(fitness))].copy()

        n_ref = int(min(N, self.n_ref))
        if n_ref >= 2:
            idx = self.rng.choice(N, size=n_ref, replace=False)
            P = pop[idx]
            diff = P[:, None, :] - P[None, :, :]
            dist = np.sqrt(np.einsum('ijk,ijk->ij', diff, diff))
            iu = np.triu_indices(n_ref, k=1)
            s = float(np.median(dist[iu])) if len(iu[0]) else 1.0
            self.s_ref = max(s, 1e-30)
            self.ref_pts = P
        else:
            self.s_ref = 1.0
            self.ref_pts = np.asarray(pop)
        self._ref2 = np.einsum('ij,ij->i', self.ref_pts, self.ref_pts)
        m = self.ref_pts.shape[0]
        if self._tmp_ref is None or self._tmp_ref.shape[0] < m:
            self._tmp_ref = np.zeros(m)

        if self.gen_proposals > 0:
            self.rho_curve.append(self.gen_interventions / float(self.gen_proposals))
            self.rho_policy_curve.append(self.gen_policy_act / float(self.gen_proposals))
        self.gen_proposals = 0
        self.gen_interventions = 0
        self.gen_policy_act = 0

    # ------------------------------------------------------------------
    def _describe(self, x, d, nd):
        q = d / nd
        z = self._z
        z[0] = _clamp(0.5 * math.log2(nd / self.s_ref + 1e-30))
        z[1] = (0.0 if self.s_hat is None
                else _clamp(float(np.dot(q, self.s_hat))))
        ze = self.best_x - x
        ne = math.sqrt(float(np.dot(ze, ze)))
        z[2] = 0.0 if ne < 1e-30 else _clamp(float(np.dot(q, ze / ne)))
        u = x + d
        uu = float(np.dot(u, u))
        if self._ref2 is not None:
            m = self.ref_pts.shape[0]
            tmp = self._tmp_ref[:m]
            np.dot(self.ref_pts, u, out=tmp)
            tmp *= -2.0
            tmp += self._ref2
            tmp += uu
            dmin = math.sqrt(max(float(tmp.min()), 0.0))
        else:
            dmin = float(np.linalg.norm(self.ref_pts - u, axis=1).min())
        z[3] = _clamp(0.5 * math.log2(dmin / self.s_ref + 1e-30))
        if self.n_proto_filled > 0:
            cos = self.protos[:self.n_proto_filled] @ q
            np.abs(cos, out=cos)
            z[4] = _clamp(1.0 - float(np.max(cos)))
        else:
            z[4] = 1.0
        return z, q

    # ------------------------------------------------------------------
    def _apply(self, a, d, nd, q):
        if a == A_IDENTITY:
            return d, q
        if a == A_CONTRACT:
            return self.alpha * d, q
        if a == A_EXPAND:
            return self.beta * d, q
        if a == A_REFLECT:
            return -d, -q
        if a == A_PROJECT:
            if self.s_hat is None:
                return d, q
            q2 = 0.5 * q + 0.5 * self.s_hat
            n2 = math.sqrt(float(np.dot(q2, q2)))
            if n2 < 1e-12:
                return d, q
            q2 = q2 / n2
            return nd * q2, q2
        raise ValueError(f'unknown action {a}')

    def _cost_vector(self, q):
        c_proj = 0.0
        if self.s_hat is not None:
            q2 = 0.5 * q + 0.5 * self.s_hat
            n2 = math.sqrt(float(np.dot(q2, q2)))
            if n2 >= 1e-12:
                q2 = q2 / n2
                dq = q2 - q
                c_proj = math.sqrt(float(np.dot(dq, dq)))
        # Costs are pure geometric distortions: |1-alpha|, |beta-1|, the
        # reversal distance 2, and the projection's direction change.
        return np.array([0.0, 1.0 - self.alpha, self.beta - 1.0,
                         2.0, c_proj], dtype=float)

    # ------------------------------------------------------------------
    def _select(self, z, q):
        """Thompson sampling: sample each arm from its posterior and pick the
        best.  Returns ``(action, greedy_action)``."""
        pred, var = self.memory.predict_all(z)
        cost = self._cost_vector(q)
        # Posterior mean is pred - cost; posterior std is sqrt(var).
        noise = self.rng.standard_normal(N_ACTIONS)
        theta = (pred - cost) + np.sqrt(np.maximum(var, _VAR_FLOOR)) * noise
        greedy = int(np.argmax(pred - cost))
        projectable = self.s_hat is not None
        # Thompson pick among feasible arms.
        best_a = A_IDENTITY
        best_v = theta[A_IDENTITY]
        for a in range(1, N_ACTIONS):
            if a == A_PROJECT and not projectable:
                continue
            if theta[a] > best_v:
                best_v = theta[a]
                best_a = a
        return best_a, greedy

    # ------------------------------------------------------------------
    def _box_shrink(self, x, d):
        u = x + d
        t = 1.0
        over = u > self.ub
        if np.any(over):
            dd = d[over]
            dd = np.where(np.abs(dd) < 1e-30, 1e-30, dd)
            t = min(t, float(np.min((self.ub[over] - x[over]) / dd)))
        under = u < self.lb
        if np.any(under):
            dd = d[under]
            dd = np.where(np.abs(dd) < 1e-30, 1e-30, dd)
            t = min(t, float(np.min((self.lb[under] - x[under]) / dd)))
        return x + max(0.0, min(1.0, t)) * d, max(0.0, min(1.0, t))

    # ------------------------------------------------------------------
    def propose(self, x, u, f_x):
        self.n_proposals += 1
        self.gen_proposals += 1
        d = u - x
        nd = float(np.sqrt(float(np.dot(d, d))))
        if nd < _DEGENERATE_EPS:
            self._pending = (None, A_IDENTITY, f_x, None)
            return u

        z, q = self._describe(x, d, nd)
        a, greedy = self._select(z, q)
        if greedy != A_IDENTITY:
            self.n_policy_act += 1
            self.gen_policy_act += 1

        d_a, q_a = self._apply(a, d, nd, q)
        if a == A_IDENTITY:
            u_new, t = u, 1.0
        else:
            u_new, t = self._box_shrink(x, d_a)
            if t < self.min_shrink:
                a, greedy = A_IDENTITY, A_IDENTITY
                u_new = u
                q_a = q

        if a != A_IDENTITY:
            self.n_interventions += 1
            self.gen_interventions += 1
            du = u_new - u
            self.mean_abs_shift += math.sqrt(float(np.dot(du, du))) / nd
        self.action_counts[a] += 1

        if self.n_proto_filled < self.protos.shape[0]:
            self.protos[self.n_proto_filled] = q
            self.n_proto_filled += 1
        elif self.rng.random() < 0.05:
            self.protos[self._proto_ptr] = q
            self._proto_ptr = (self._proto_ptr + 1) % self.protos.shape[0]

        self._pending = (z, a, f_x, q_a)
        return u_new

    # ------------------------------------------------------------------
    def observe(self, f_new):
        if self._pending is None:
            return
        z, a, f_old, q_exec = self._pending
        self._pending = None
        if z is None:
            return
        raw = (f_old - f_new) / (self.sigma_f + 1e-30)
        r = float(np.tanh(raw))
        self.memory.add(z, a, r)

        # Adaptive geometry: amplify a move that improved the response, damp a
        # move that hurt it, with a Robbins-Monro step 1/(n+1).
        n_geo = self._n_geo[a] + 1.0
        self._n_geo[a] = n_geo
        if a == A_CONTRACT:
            # success (r>0) -> stronger contract (alpha down); harm -> weaker.
            self.alpha *= math.exp(-r / n_geo)
            self.alpha = min(max(self.alpha, _ALPHA_MIN), _ALPHA_MAX)
        elif a == A_EXPAND:
            # success -> stronger expand (beta up); harm -> weaker.
            self.beta *= math.exp(r / n_geo)
            self.beta = min(max(self.beta, _BETA_MIN), _BETA_MAX)

        # Success direction: cumulative average (no EMA rate).
        if r > 0.0 and q_exec is not None:
            n = self._n_succ
            self._n_succ += 1
            if self.s_hat is None:
                self.s_hat = q_exec.copy()
            else:
                s = (n * self.s_hat) + q_exec
                ns = math.sqrt(float(np.dot(s, s)))
                if ns > 1e-12:
                    self.s_hat = s / ns

    # ------------------------------------------------------------------
    def intervention_rate(self):
        if self.n_proposals == 0:
            return 0.0
        return self.n_interventions / float(self.n_proposals)

    def policy_rate(self):
        if self.n_proposals == 0:
            return 0.0
        return self.n_policy_act / float(self.n_proposals)

    def mean_shift(self):
        if self.n_interventions == 0:
            return 0.0
        return self.mean_abs_shift / float(self.n_interventions)

    def stats(self):
        return {
            'n_proposals': int(self.n_proposals),
            'n_interventions': int(self.n_interventions),
            'intervention_rate': float(self.intervention_rate()),
            'policy_rate': float(self.policy_rate()),
            'mean_relative_shift': float(self.mean_shift()),
            'action_counts': {ACTION_NAMES[i]: int(self.action_counts[i])
                              for i in range(N_ACTIONS)},
            'memory_counts': {ACTION_NAMES[i]: int(self.memory.counts()[i])
                              for i in range(N_ACTIONS)},
            'rho_curve': [float(v) for v in self.rho_curve],
            'rho_policy_curve': [float(v) for v in self.rho_policy_curve],
            'alpha': float(self.alpha),
            'beta': float(self.beta),
        }

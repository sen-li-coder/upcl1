# -*- coding: utf-8 -*-
"""LaTeX -> Word native equation (OMML).

Display and inline mathematics are inserted as real Office Math objects
(`m:oMath`) instead of pictures, so every formula stays editable in Word and
follows the surrounding font metrics.

Pipeline:  LaTeX -> MathML (latex2mathml) -> OMML (Office MML2OMML.XSL).
If either stage is unavailable the caller falls back to unicode text.
"""
import re
from pathlib import Path

from lxml import etree
import latex2mathml.converter

_NSRE = re.compile(r'\s+')

_XSL_CANDIDATES = [
    Path(r'C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL'),
    Path(r'C:\Program Files (x86)\Microsoft Office\root\Office16\MML2OMML.XSL'),
    Path(r'C:\Program Files\Microsoft Office\Office16\MML2OMML.XSL'),
]

_transform = None
_warned = set()

_NS_M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
_NS_W = ('http://schemas.openxmlformats.org/wordprocessingml/2006/main')


def _ensure_ns(xml):
    """Re-declare the math/word namespaces on the root element.

    The extracted `m:oMath` fragment loses the declarations that the Office
    stylesheet puts on the discarded `m:oMathPara` wrapper, and python-docx
    parses fragments without a namespace map of its own.
    """
    if xml is None or 'xmlns:m=' in xml:
        return xml
    def fix(m):
        return ('<m:%s xmlns:m="%s" xmlns:w="%s"' % (m.group(1), _NS_M, _NS_W))
    return re.sub(r'^<m:(\w+)', fix, xml, count=1)


def _xsl_transform():
    global _transform
    if _transform is not None:
        return _transform
    for p in _XSL_CANDIDATES:
        if not p.exists():
            continue
        try:
            _transform = etree.XSLT(etree.parse(str(p)))
            return _transform
        except Exception:
            continue
    return None


def _clean_mathml(mathml):
    """Strip attributes that make the Office stylesheet emit junk."""
    try:
        root = etree.fromstring(mathml.encode('utf-8'))
    except Exception:
        return None
    for el in root.iter():
        for k in list(el.attrib.keys()):
            if k.endswith('}href') or k in ('href', 'id', 'class', 'style'):
                el.attrib.pop(k, None)
    return root


_LATEX_FIXES = [
    # latex2mathml does not know \arg and leaves it as the literal text
    # "\arg" (a backslash followed by "arg"); render it as an upright operator.
    (re.compile(r'\\arg\b'), lambda m: r'\operatorname{arg}'),
]


def _preprocess(tex):
    """Fix LaTeX commands that latex2mathml leaves as literal text."""
    for pat, rep in _LATEX_FIXES:
        tex = pat.sub(rep, tex)
    return tex


def _normalize_omml(xml):
    """Clean artefacts of the Office MML2OMML transform.

    ``\\text{...}`` spaces reach OMML as non-breaking spaces (U+00A0), which
    Word draws as small circles inside a math zone.  Replace them with
    ordinary spaces and mark the runs ``xml:space="preserve"`` so the spaces
    survive parsing (MML2OMML otherwise collapses ordinary spaces).
    """
    if '\xa0' not in xml:
        return xml
    xml = xml.replace('\xa0', ' ')
    xml = re.sub(r'<m:t(?![^>]*xml:space=)(?=[ >])',
                 '<m:t xml:space="preserve"', xml)
    return xml


def latex_to_omml(tex, display=True):
    """Return the OMML markup for `tex` as a string, or None on failure."""
    tex = (tex or '').strip()
    if not tex:
        return None
    tr = _xsl_transform()
    if tr is None:
        if 'xsl' not in _warned:
            _warned.add('xsl')
            print('[omml] MML2OMML.XSL not found - equations fall back to text')
        return None
    try:
        mathml = latex2mathml.converter.convert(
            _preprocess(tex), display=('block' if display else 'inline'))
        root = _clean_mathml(mathml)
        if root is None:
            raise ValueError('MathML parse failed')
        out = tr(root)
        xml = etree.tostring(out, encoding='unicode')
    except Exception as exc:
        key = ('conv', tex[:40])
        if key not in _warned:
            _warned.add(key)
            print('[omml] conversion failed:', tex[:70], '->', exc)
        return None
    xml = re.sub(r'<\?xml[^>]*\?>', '', xml).strip()
    if 'oMath' not in xml:
        return None
    return _normalize_omml(_ensure_ns(xml))


def omml_inline(tex):
    """OMML for an inline fragment: an `m:oMath` element without oMathPara."""
    xml = latex_to_omml(tex, display=False)
    if xml is None:
        return None
    if '<m:oMathPara' in xml:
        inner = re.search(r'(<m:oMath\b.*</m:oMath>)', xml, re.S)
        if inner:
            return _ensure_ns(inner.group(1))
    return xml


def omml_display(tex):
    """OMML for a display equation.

    The block-level `m:oMathPara` wrapper is dropped so that the equation can
    share its paragraph with the centred tab stop and the right-aligned
    number; the MathML is still converted in display mode, so n-ary operators
    keep their over/under limits and fractions keep their full height.
    """
    xml = latex_to_omml(tex, display=True)
    if xml is None:
        return None
    if '<m:oMathPara' in xml:
        inner = re.search(r'(<m:oMath\b.*</m:oMath>)', xml, re.S)
        if inner:
            return _ensure_ns(inner.group(1))
    return xml


# --------------------------------------------------------------------------
#  unicode fallback (Cambria Math renders these acceptably)
# --------------------------------------------------------------------------
_GREEK = {
    'alpha': '\u03b1', 'beta': '\u03b2', 'gamma': '\u03b3', 'delta': '\u03b4',
    'epsilon': '\u03b5', 'varepsilon': '\u03b5', 'zeta': '\u03b6', 'eta': '\u03b7',
    'theta': '\u03b8', 'vartheta': '\u03d1', 'iota': '\u03b9', 'kappa': '\u03ba',
    'lambda': '\u03bb', 'mu': '\u03bc', 'nu': '\u03bd', 'xi': '\u03be',
    'pi': '\u03c0', 'rho': '\u03c1', 'sigma': '\u03c3', 'tau': '\u03c4',
    'upsilon': '\u03c5', 'phi': '\u03c6', 'varphi': '\u03c6', 'chi': '\u03c7',
    'psi': '\u03c8', 'omega': '\u03c9',
    'Gamma': '\u0393', 'Delta': '\u0394', 'Theta': '\u0398', 'Lambda': '\u039b',
    'Xi': '\u039e', 'Pi': '\u03a0', 'Sigma': '\u03a3', 'Phi': '\u03a6',
    'Psi': '\u03a8', 'Omega': '\u03a9',
}
_SUP = {'0': '\u2070', '1': '\u00b9', '2': '\u00b2', '3': '\u00b3',
        '4': '\u2074', '5': '\u2075', '6': '\u2076', '7': '\u2077',
        '8': '\u2078', '9': '\u2079', '+': '\u207a', '-': '\u207b',
        'n': '\u207f', 'i': '\u2071', 't': '\u1d57', 'T': '\u1d40'}
_SUB = {'0': '\u2080', '1': '\u2081', '2': '\u2082', '3': '\u2083',
        '4': '\u2084', '5': '\u2085', '6': '\u2086', '7': '\u2087',
        '8': '\u2088', '9': '\u2089', 'i': '\u1d62', 'j': '\u2c7c',
        'k': '\u2096', 'n': '\u2099', 'm': '\u2098', 's': '\u209b',
        't': '\u209c', 'a': '\u2090', 'e': '\u2091', 'o': '\u2092',
        'r': '\u1d63'}
_SYM = {
    r'\leq': '\u2264', r'\le': '\u2264', r'\geq': '\u2265', r'\ge': '\u2265',
    r'\neq': '\u2260', r'\approx': '\u2248', r'\sim': '\u223c',
    r'\cdot': '\u00b7', r'\times': '\u00d7', r'\pm': '\u00b1',
    r'\infty': '\u221e', r'\partial': '\u2202', r'\nabla': '\u2207',
    r'\in': '\u2208', r'\notin': '\u2209', r'\forall': '\u2200',
    r'\exists': '\u2203', r'\rightarrow': '\u2192', r'\to': '\u2192',
    r'\Rightarrow': '\u21d2', r'\leftarrow': '\u2190',
    r'\leftarrow': '\u2190', r'\min': 'min', r'\max': 'max',
    r'\arg': 'arg', r'\log': 'log', r'\exp': 'exp', r'\sum': '\u2211', r'\prod': '\u220f',
    r'\sqrt': '\u221a', r'\emptyset': '\u2205', r'\varnothing': '\u2205',
    r'\ldots': '\u2026', r'\dots': '\u2026', r'\quad': ' ',
    r'\,': ' ', r'\;': ' ', r'\!': '',
}
_ACC = {r'\tilde': '\u0303', r'\hat': '\u0302', r'\bar': '\u0304',
        r'\vec': '\u20d7', r'\dot': '\u0307'}


def latex_to_unicode(tex):
    """Best-effort linear rendering used only when OMML is unavailable."""
    s = (tex or '').strip()
    s = re.sub(r'\\(?:mathrm|mathbf|mathbb|mathcal|mathit|text|operatorname)'
               r'\s*\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'\\tilde\s*\{([^{}]*)\}', lambda m: m.group(1) + '\u0303', s)
    s = re.sub(r'\\hat\s*\{([^{}]*)\}', lambda m: m.group(1) + '\u0302', s)
    s = re.sub(r'\\bar\s*\{([^{}]*)\}', lambda m: m.group(1) + '\u0304', s)
    s = re.sub(r'\\frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}', r'(\1)/(\2)', s)
    s = re.sub(r'\\sqrt\s*\{([^{}]*)\}',
               lambda m: '\u221a(' + m.group(1) + ')', s)
    s = re.sub(r'_\{([^{}]*)\}', lambda m: ''.join(_SUB.get(c, c)
                                                   for c in m.group(1)), s)
    s = re.sub(r'\^\{([^{}]*)\}', lambda m: ''.join(_SUP.get(c, c)
                                                    for c in m.group(1)), s)
    s = re.sub(r'_(\w)', lambda m: _SUB.get(m.group(1), m.group(1)), s)
    s = re.sub(r'\^(\w)', lambda m: _SUP.get(m.group(1), m.group(1)), s)
    for k, v in _GREEK.items():
        s = re.sub(r'\\' + k + r'\b', v, s)
    for k, v in _SYM.items():
        s = s.replace(k, v)
    s = re.sub(r'\\[A-Za-z]+', '', s)
    s = s.replace('{', '').replace('}', '')
    return re.sub(r'\s+', ' ', s).strip()

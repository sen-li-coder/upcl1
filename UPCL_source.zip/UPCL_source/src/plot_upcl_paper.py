# -*- coding: utf-8 -*-
"""Manuscript-quality figures for the UPCL mechanism analysis.

Reads the ``mech30_*`` tables written by ``analyze_upcl_cec.py`` and renders
four figures that visualise the mechanism fingerprint reported in Section 4.4:

  * mech_fingerprint.png             three-panel host gradient
  * mech_scatter_ir_gain.png         intervention rate vs intervention gain
  * mech_category_level_heatmap.png  gain by problem class and level
  * mech_descriptor.png              descriptor contrasts by level

Run from the repo root::

    python src/plot_upcl_paper.py

All figures are drawn at 6.3 in wide (the manuscript text column) and 300 dpi.
"""
import csv
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

FIG_W = 6.3

# Composition levels of the host pool (see Section 3).
LEVELS = [0, 1, 2, 3]
# Nature-style level palette (NPG + Okabe-Ito, colour-blind safe), ordered
# blue -> green -> amber -> red with increasing composition level.
LEVEL_COLORS = {0: '#3C5488', 1: '#00A087', 2: '#E69F00', 3: '#E64B35'}
LEVEL_LABELS = {
    0: 'L0  fixed parameter',
    1: 'L1  adaptive F/CR',
    2: 'L2  archived history',
    3: 'L3  LPSR / modern',
}

DESCRIPTORS = [
    ('rho_step_effect', 'step'),
    ('theta_align_effect', 'align'),
    ('eta_elite_effect', 'elite'),
    ('kappa_crowd_effect', 'crowd'),
    ('nu_novel_effect', 'novel'),
]


def _read(name):
    path = TABLES / name
    if not path.exists():
        raise SystemExit(f'missing table: {path}')
    with open(path, encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh))


def _style():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans',
        'font.size': 8,
        'axes.titlesize': 8.5,
        'axes.labelsize': 8,
        'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444',
        'xtick.color': '#333333',
        'ytick.color': '#333333',
        'xtick.labelsize': 6.5,
        'ytick.labelsize': 7,
        'legend.fontsize': 6.5,
        'legend.frameon': False,
        'figure.dpi': 300,
    })


def _despine(ax, grid=True):
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    if grid:
        ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
        ax.set_axisbelow(True)


def _level_patches():
    return [Patch(facecolor=LEVEL_COLORS[lv], label=LEVEL_LABELS[lv])
            for lv in LEVELS]


def fingerprint(hosts):
    """Three-panel host gradient, hosts ordered by bare rank."""
    order = sorted(hosts, key=lambda r: int(r.get('bare_rank') or 10**9))
    names = [r['host'] for r in order]
    x = np.arange(len(names))
    bare = np.array([float(r['bare_median_log10err']) for r in order])
    irate = np.array([float(r['intervention_rate']) for r in order])
    dec = np.array([float(r['dec_mean']) for r in order])
    cols = [LEVEL_COLORS[int(r['level'])] for r in order]

    fig, axes = plt.subplots(3, 1, figsize=(FIG_W, 6.4), sharex=True)
    fig.subplots_adjust(hspace=0.16, left=0.10, right=0.98, top=0.93, bottom=0.20)

    ax = axes[0]
    ax.bar(x, bare, color=cols, width=0.72, linewidth=0)
    ax.set_ylabel('bare log10 error')
    ax.set_title('a  bare final error', loc='left', fontsize=8)
    _despine(ax)

    ax = axes[1]
    ax.bar(x, irate * 100.0, color=cols, width=0.72, linewidth=0)
    ax.set_ylabel('intervention rate (%)')
    ax.set_title('b  intervention rate', loc='left', fontsize=8)
    _despine(ax)

    ax = axes[2]
    ax.bar(x, dec, color=cols, width=0.72, linewidth=0)
    ax.axhline(0, color='#666666', linewidth=0.6)
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title('c  intervention gain', loc='left', fontsize=8)
    _despine(ax)

    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=90, ha='right', va='top', fontsize=5.2)
    ax.set_xlabel('host, ordered by bare rank (1 = best)')

    fig.legend(handles=_level_patches(), loc='upper center', ncol=4,
               bbox_to_anchor=(0.5, 0.985), frameon=False,
               handlelength=1.0, handleheight=0.8, columnspacing=1.2)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / 'mech_fingerprint.png', bbox_inches='tight')
    plt.close(fig)


def scatter_ir_gain(hosts):
    """Intervention rate against intervention gain, coloured by level."""
    irate = np.array([float(r['intervention_rate']) for r in hosts])
    dec = np.array([float(r['dec_mean']) for r in hosts])
    cols = [LEVEL_COLORS[int(r['level'])] for r in hosts]
    names = [r['host'] for r in hosts]

    fig, ax = plt.subplots(figsize=(FIG_W, 3.1))
    fig.subplots_adjust(left=0.11, right=0.98, top=0.90, bottom=0.16)
    ax.scatter(irate, dec, c=cols, s=34, edgecolors='white',
               linewidths=0.5, zorder=3)
    ax.axhline(0, color='#666666', linewidth=0.6, zorder=1)

    # label a few landmarks, nudged so they do not overlap
    landmarks = {
        'NL-SHADE-RSP': (0.004, -0.006),
        'DE/rand/1': (0.006, 0.010),
        'DE/current-to-best/1': (0.005, -0.006),
        'jDE100': (0.006, -0.006),
    }
    for r, name in zip(hosts, names):
        if name in landmarks:
            dx, dy = landmarks[name]
            ax.annotate(name, (float(r['intervention_rate']), float(r['dec_mean'])),
                        xytext=(float(r['intervention_rate']) + dx,
                                float(r['dec_mean']) + dy),
                        fontsize=6, color='#333333')

    ax.set_xlabel('intervention rate')
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title('intervention rate vs intervention gain, 30 hosts',
                 loc='left', fontsize=8.5)
    _despine(ax)
    fig.legend(handles=_level_patches(), loc='upper right', ncol=1,
               bbox_to_anchor=(0.995, 0.985), frameon=False,
               handlelength=1.0, handleheight=0.8)
    fig.savefig(FIG / 'mech_scatter_ir_gain.png', bbox_inches='tight')
    plt.close(fig)


def category_level_heatmap(cat_level):
    """Intervention gain by problem class and composition level."""
    cats = ['unimodal', 'multimodal', 'hybrid', 'composite']
    matrix = np.full((len(cats), len(LEVELS)), np.nan)
    for r in cat_level:
        if r['category'] in cats and int(r['level']) in LEVELS:
            matrix[cats.index(r['category']), int(r['level'])] = float(r['dec_mean'])

    vmax = np.nanmax(np.abs(matrix))
    fig, ax = plt.subplots(figsize=(FIG_W, 2.7))
    fig.subplots_adjust(left=0.16, right=0.94, top=0.88, bottom=0.14)
    im = ax.imshow(matrix, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
    ax.set_xticks(range(len(LEVELS)))
    ax.set_xticklabels([LEVEL_LABELS[lv] for lv in LEVELS], fontsize=7)
    ax.set_yticks(range(len(cats)))
    ax.set_yticklabels(cats, fontsize=7.5)
    for i in range(len(cats)):
        for j in range(len(LEVELS)):
            v = matrix[i, j]
            if np.isfinite(v):
                ax.text(j, i, f'{v:+.2f}', ha='center', va='center',
                        fontsize=7, color='#111111')
    cb = fig.colorbar(im, ax=ax, shrink=0.85, pad=0.02)
    cb.ax.tick_params(labelsize=6.5)
    cb.set_label('intervention gain (dec)', fontsize=7)
    ax.set_title('gain by problem class and composition level', loc='left',
                 fontsize=8.5)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
    fig.savefig(FIG / 'mech_category_level_heatmap.png', bbox_inches='tight')
    plt.close(fig)


def descriptors(by_level):
    """Descriptor contrasts by composition level (heatmap)."""
    rows = {int(r['level']): r for r in by_level if r.get('level') not in (None, '')}
    mat = np.array([[float(rows[lv][col]) for lv in LEVELS]
                    for col, _ in DESCRIPTORS])
    labels = [short for _, short in DESCRIPTORS]

    vmax = np.nanmax(np.abs(mat))
    fig, ax = plt.subplots(figsize=(FIG_W, 2.5))
    fig.subplots_adjust(left=0.16, right=0.94, top=0.88, bottom=0.14)
    im = ax.imshow(mat, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
    ax.set_xticks(range(len(LEVELS)))
    ax.set_xticklabels([LEVEL_LABELS[lv] for lv in LEVELS], fontsize=7)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=7.5)
    for i in range(len(labels)):
        for j in range(len(LEVELS)):
            ax.text(j, i, f'{mat[i, j]:+.2f}', ha='center', va='center',
                    fontsize=7, color='#111111')
    cb = fig.colorbar(im, ax=ax, shrink=0.85, pad=0.02)
    cb.ax.tick_params(labelsize=6.5)
    cb.set_label('descriptor contrast', fontsize=7)
    ax.set_title('descriptor contrasts by composition level', loc='left',
                 fontsize=8.5)
    fig.savefig(FIG / 'mech_descriptor.png', bbox_inches='tight')
    plt.close(fig)


def main():
    _style()
    hosts = _read('mech30_host_summary.csv')
    by_level = _read('mech30_by_level.csv')
    cat_level = _read('mech30_category_level.csv')

    fingerprint(hosts)
    scatter_ir_gain(hosts)
    category_level_heatmap(cat_level)
    descriptors(by_level)
    print('[plot] wrote 4 mechanism figures to', FIG)


if __name__ == '__main__':
    main()

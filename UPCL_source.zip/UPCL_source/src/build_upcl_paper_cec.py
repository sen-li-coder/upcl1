# -*- coding: utf-8 -*-
"""Build the UPCL manuscript for the CEC paired experiments.

Assembles the tables written by ``analyze_upcl_cec.py`` into
``results/cec/tables`` and renders them, together with the unchanged method
part, into a single docx::

    python src/build_upcl_paper_cec.py

The figures referenced here are the ones produced by the same analysis pass,
so the document is regenerated rather than edited by hand.
"""
import csv
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np                                            # noqa: E402
from scipy.stats import spearmanr, binomtest                  # noqa: E402

from ec_style import Paper                                    # noqa: E402
import paper_figures as PFG                                   # noqa: E402
import upcl_part_front as PF                                  # noqa: E402
import upcl_part_bg as PBG                                    # noqa: E402
import upcl_part_method as PM                                 # noqa: E402
import upcl_part_exp_cec as PE                                # noqa: E402
import upcl_part_app as PA                                    # noqa: E402
from upcl_refs import get_refs                                # noqa: E402

# Renderable parts, in manuscript order.  ``build`` accepts a subset, so the
# first three sections can be drafted and circulated on their own.
PARTS = ('front', 'bg', 'method', 'exp', 'app', 'back')

# Size of each suite, used only to state how much of it has been run.
# CEC 2013 is deliberately absent: a CEC 2013 pilot exists in the raw
# directory but is not part of the manuscript.
SUITE_SIZE = {('cec2017', 30): 29, ('cec2017', 50): 29,
              ('cec2022', 10): 12, ('cec2022', 20): 12}

# Full-grid cost obtained from the calibrated extrapolation of
# ``python src/run_upcl_cec.py --estimate`` (two suites, four dimensions,
# twenty-nine hosts, thirty runs per cell).
CPU_HOURS_FULL_GRID = 4271.6

# The full DE host pool reported in this manuscript: the twenty established
# hosts plus the nine wave-4 variants.
N_HOSTS = 29

# The paired family of Section 4.3: every one of the twenty-nine registered hosts
# on every problem of the three primary blocks (CEC 2017 D=30, CEC 2022 D=10
# and D=20), two arms, thirty runs per cell.  CEC 2017 at $D=50$ is a fourth
# block covering the twenty established hosts (the wave-4 variants were not
# run at this dimension) on all twenty-nine problems.
GRID = ROOT / 'results' / 'cec' / 'tables'
# The blocks that get their own convergence panel; the list lives with the
# figure registry, which also decides where those panels are read from.
GRID_SUITES = PFG.CONV_SUITES
GRID_CPU_HOURS = CPU_HOURS_FULL_GRID


# ---------------------------------------------------------------------------
def _read(name):
    path = TABLES / name
    if not path.exists():
        print('[UPCL] missing table:', name)
        return []
    with open(path, encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh))


def _drop_cec2013(rows):
    """Drop the CEC 2013 pilot rows, which are not part of the manuscript."""
    return [r for r in rows if r.get('suite') != 'cec2013']


def _read_grid(name):
    """Read a CSV written under ``results/cec/tables`` (bare ranking, mechanism
    fingerprint); the probe-level measurements of the manuscript come from
    here rather than from the paired CEC tables."""
    path = GRID / name
    if not path.exists():
        print('[UPCL] missing grid table:', name)
        return []
    with open(path, encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh))


def _mean(rows, key):
    vals = [float(r[key]) for r in rows if r.get(key) not in (None, '', 'nan')]
    return sum(vals) / len(vals) if vals else float('nan')


def _holm(pvals, alpha=0.05):
    """Holm-Bonferroni rejection set (indices)."""
    m = len(pvals)
    rej, order = [False] * m, np.argsort(pvals)
    for k, idx in enumerate(order):
        if pvals[idx] <= alpha / (m - k):
            rej[idx] = True
        else:
            break
    return rej


# ---------------------------------------------------------------------------
def block_ranks(cells):
    """Variant-alone accuracy and rank inside every (suite, dimension) block.

    The accuracy of a variant in a block is the median over the functions of the
    per-function median final error of the bare arm, taken in log-10 space
    (lower is better); the rank is its 1-based ascending order in the block, so
    rank 1 is the best variant.  An error of exactly zero is floored at 1e-8
    before the logarithm, so a function on which a variant reaches the machine
    zero is counted rather than dropped.

    This is the only place the quantity is computed: the accuracy and rank
    columns of Tables 8-11, the summary table of Section 4.3, the final row of
    every function-level matrix and the reported rank of a variant are all this
    function, so they cannot disagree.  Variants whose accuracies coincide are
    ordered by name, so the order is reproducible rather than dependent on the
    row order of the input file.
    """
    pool = {}
    for c in cells:
        try:
            key = (c['suite'], int(c['dim']), c['host'])
            pool.setdefault(key, []).append(float(c['bare_median']))
        except (TypeError, ValueError, KeyError):
            pass
    acc = {k: float(np.median([float(np.log10(max(float(v), 1e-8)))
                               for v in vals]))
           for k, vals in pool.items()}
    blocks = {}
    for k in acc:
        blocks.setdefault((k[0], k[1]), []).append(k)
    rank = {}
    for bk, keys in blocks.items():
        keys.sort(key=lambda k: (acc[k], k[2]))
        for r, k in enumerate(keys, 1):
            rank[k] = r
    return acc, rank, blocks


def tie_groups(acc, blocks, tol=1e-6):
    """Groups of variants whose block accuracy agrees to within ``tol`` decades.

    Four variants can share a median error to every printed digit when the
    median function is one on which they all stall at the same plateau; their
    ranks are then decided by digits the tables do not show.  Collecting those
    groups lets the text say so instead of implying an ordering that the data
    cannot support.
    """
    out = {}
    for bk, keys in blocks.items():
        keys = sorted(keys, key=lambda k: acc[k])
        run = []
        for k in keys:
            if run and abs(acc[k] - acc[run[-1]]) > tol:
                if len(run) > 1:
                    out.setdefault(bk, []).append(run)
                run = []
            run.append(k)
        if len(run) > 1:
            out.setdefault(bk, []).append(run)
    return out


def load_stats(lang='en'):
    """Assemble every number and phrase the manuscript needs.

    ``lang='zh'`` only switches the human-readable phrases (protocol entries,
    scope sentences, figure labels); every numeric field is identical, so the
    translated manuscript stays faithful to the same data.
    """
    zh = (lang == 'zh')
    cells = _drop_cec2013(_read('exp1_cells.csv'))
    if not cells:
        raise SystemExit('[UPCL] no Exp1 cells found; run the analysis first')
    hosts = _drop_cec2013(_read('exp1_host_summary.csv'))

    # ---- host-alone rank and accuracy, attached to each host summary ----
    # One estimator for all four blocks, defined in `block_ranks`: per variant
    # and block, the median over the functions of the per-function median final
    # error of the bare arm, taken in log-10 space.  (An earlier draft carried
    # a side-car table recovered from an older build for three of the blocks;
    # it pooled the runs differently, so it was dropped in favour of the
    # definition above, which every reader can recompute from
    # `exp1_cells.csv`.  The side-car file is kept in the table directory but
    # is no longer read.)
    _acc_med, _acc_rank, _acc_blocks = block_ranks(cells)
    for r in hosts:
        _key = (r['suite'], int(r['dim']), r['host'])
        r['rank'] = _acc_rank.get(_key, '-')
        r['accuracy'] = _acc_med.get(_key, '-')
    # variants whose block accuracy is identical to every printed digit
    _ties = tie_groups(_acc_med, _acc_blocks)

    category = _drop_cec2013(_read('exp5_by_category.csv'))
    diminfo = _drop_cec2013(_read('exp5_by_dimension.csv'))
    descriptor = _drop_cec2013(_read('exp5_descriptor_influence.csv'))
    cost_dim = _drop_cec2013(_read('exp6_overhead_by_dim.csv'))
    cost_host = _read('exp6_overhead_by_host.csv')
    abl_cells = _read('exp4_ablation_cells.csv')
    abl_friedman = _read('exp4_friedman.csv')
    abl_contrasts = _read('exp4_contrasts.csv')
    # ---- D=30 against D=50 on the variants present in both blocks -------
    # Written by analyze_upcl_cec.exp5_dim_transfer; every number the
    # dimension paragraph of Section 4.2 quotes comes from here.
    dim_transfer = {r['metric']: r for r in _read('exp5_dim_transfer.csv')}

    # ---- blocks actually completed -------------------------------------
    blocks = sorted({(c['suite'], int(c['dim'])) for c in cells},
                    key=lambda k: (k[0], k[1]))
    problems = {}
    for c in cells:
        problems.setdefault((c['suite'], int(c['dim'])), set()).add(c['fid'])
    n_hosts = len({c['host'] for c in cells})
    n_funcs = len(problems and {(k[0], k[1], f)
                                for k, fs in problems.items() for f in fs})

    # ---- mechanism decomposition over the full 29-host pool -------------
    # The unified mechanism tables of ``analyze_mech30.py`` carry the three
    # observables (intervention rate, intervention gain, descriptor
    # contrasts) for every one of the twenty-nine hosts, and the aggregated
    # readings by composition level and by problem category.  They are the
    # quantities Section 4's three-layer analysis turns on.
    mech30 = {
        'host_summary': _read('mech30_host_summary.csv'),
        'by_level': _read('mech30_by_level.csv'),
        'category': _read('mech30_category.csv'),
        'category_level': _read('mech30_category_level.csv'),
        'cells': _read('mech30_cells.csv'),
    }

    # ---- six-dimension attribution (D1-D8) ------------------------------
    # The attribution tables of ``analyze_mech_attribution.py`` attribute dec
    # (and its companion observables) to the six mechanism dimensions.
    # Section 4.4's second step reads them: the collinearity of the
    # dimensions, the univariate effect sizes, the multivariate regression
    # with its random-forest check, and the near-pair ablation.
    attr_raw = {
        'regression': _read('attr_d6_regression.csv'),
        'rf_importance': _read('attr_d6_rf_importance.csv'),
        'vif': _read('attr_d6_vif.csv'),
        'near_pairs': _read('attr_d8_near_pairs.csv'),
        'effect_sizes': _read('attr_d2_effect_sizes.csv'),
        'univariate': _read('attr_d1_univariate.csv'),
        'cramer': _read('attr_d1_cramer.csv'),
        'interaction': _read('attr_d3_srh.csv'),
        'action': _read('attr_d5_action_gain.csv'),
        'pca_variance': _read('attr_d4_pca_variance.csv'),
    }

    def _row1(rows, key, value):
        """First row of ``rows`` whose ``key`` equals ``value``, else {}."""
        for r in rows:
            if r.get(key) == value:
                return r
        return {}

    def _fv(rows, key, where, value, default=float('nan')):
        r = _row1(rows, where, value)
        try:
            return float(r[key])
        except (TypeError, ValueError, KeyError):
            return default

    # Cramer's V: mutation <-> strategy and param <-> archive.
    attr = {}
    attr['v_mut_strategy'] = _fv(attr_raw['cramer'], 'strategy',
                                 '', 'mutation_class')
    attr['v_param_archive'] = _fv(attr_raw['cramer'], 'archive',
                                  '', 'param_class')

    # Univariate Kruskal-Wallis on dec: the parameter rule is the strongest
    # and significant; the mutation operator is not significant.
    def _kwv(dim, key):
        r = _row1([x for x in attr_raw['univariate']
                   if x.get('observable') == 'dec_median'], 'dimension', dim)
        try:
            return float(r[key])
        except (TypeError, ValueError, KeyError):
            return float('nan')
    attr['kw_param_H'] = _kwv('param_class', 'H')
    attr['kw_param_p'] = _kwv('param_class', 'p')
    attr['kw_param_eta2'] = _kwv('param_class', 'eta2')
    attr['kw_mut_p'] = _kwv('mutation_class', 'p')

    # eta2 on the step-size ratio: param and mutation carry the largest
    # univariate structure on the geometric descriptors.
    def _eta2(observable, dim):
        r = _row1([x for x in attr_raw['effect_sizes']
                   if x.get('observable') == observable], 'dimension', dim)
        try:
            return float(r['eta2'])
        except (TypeError, ValueError, KeyError):
            return float('nan')
    attr['eta2_rho_param'] = _eta2('rho_step_effect', 'param_class')
    attr['eta2_rho_mut'] = _eta2('rho_step_effect', 'mutation_class')
    _dec_eta2 = [_eta2('dec_median', d) for d in
                 ['mutation_class', 'param_class', 'strategy',
                  'archive', 'pop', 'other_flag']]
    attr['eta2_dec_max'] = max(_dec_eta2) if _dec_eta2 else float('nan')

    # Multivariate regression and random-forest importance.
    attr['beta_mut'] = _fv(attr_raw['regression'], 'beta', 'term',
                           'mutation_class')
    attr['beta_mut_lo'] = _fv(attr_raw['regression'], 'lo', 'term',
                              'mutation_class')
    attr['beta_mut_hi'] = _fv(attr_raw['regression'], 'hi', 'term',
                              'mutation_class')
    # The analysis builds the interval as beta +/- 1.96 se, so the same normal
    # reference distribution gives the p value quoted beside the interval.
    _se_mut = max(1e-12, _fv(attr_raw['regression'], 'se', 'term',
                             'mutation_class'))
    attr['beta_mut_p'] = float(math.erfc(
        abs(float(attr['beta_mut']) / float(_se_mut)) / math.sqrt(2.0)))
    attr['beta_param'] = _fv(attr_raw['regression'], 'beta', 'term',
                             'param_class')
    attr['rf_mut'] = _fv(attr_raw['rf_importance'], 'importance', 'term',
                         'mutation_class')
    attr['rf_param'] = _fv(attr_raw['rf_importance'], 'importance', 'term',
                           'param_class')
    # Third-highest importance: the sentence quotes it as the ceiling for
    # "every other dimension", so it must be read from the table rather than
    # fixed at the value of an earlier run of the analysis.
    _rf_rest = sorted(
        float(x['importance']) for x in attr_raw['rf_importance']
        if x.get('term') not in ('mutation_class', 'param_class'))
    attr['rf_third'] = _rf_rest[-1] if _rf_rest else float('nan')
    # Largest variance-inflation factor of the six dimension codes.
    _vifs = [float(x['VIF']) for x in attr_raw['vif']
             if str(x.get('VIF', '')).strip() not in ('', 'nan')]
    attr['vif_max'] = max(_vifs) if _vifs else float('nan')

    # Near-pair ablation: per-dimension mean |d_dec|.
    _np = {}
    for r in attr_raw['near_pairs']:
        d = r.get('diff_dim')
        if not d:
            continue
        _np.setdefault(d, []).append(abs(float(r['d_dec'])))
    attr['np_by_dim'] = {d: {'n': len(v), 'mean': sum(v) / len(v)}
                         for d, v in _np.items()}

    # The single significant two-factor interaction: strategy x param.
    def _srh(a, b, key):
        for r in attr_raw['interaction']:
            if {r.get('a'), r.get('b')} == {a, b}:
                try:
                    return float(r[key])
                except (TypeError, ValueError, KeyError):
                    return float('nan')
        return float('nan')
    attr['inter_H'] = _srh('strategy', 'param_class', 'H_ab')
    attr['inter_p'] = _srh('strategy', 'param_class', 'p_ab')

    # Action decomposition: the reflect action and the identity share.
    attr['action_R_r'] = _fv(attr_raw['action'], 'spearman_r', 'action', 'R')
    attr['action_R_p'] = _fv(attr_raw['action'], 'p', 'action', 'R')
    attr['action_I_share'] = _fv(attr_raw['action'], 'mean_share', 'action',
                                 'I')

    # Observable-space structure: the first two principal components.
    attr['pc1'] = _fv(attr_raw['pca_variance'], 'explained_variance',
                      'component', 'PC1')
    attr['pc2'] = _fv(attr_raw['pca_variance'], 'explained_variance',
                      'component', 'PC2')

    attr['raw'] = attr_raw

    # intervention-rate extremes: the fixed-parameter hosts (level 0) leave
    # the largest proposal-level slack; the modern hosts (level 3) leave the
    # least, so these two read off the mechanism-composition gradient.
    by_level = {int(r['level']): r for r in mech30['by_level']
                if r.get('level') not in (None, '')}
    rho_hi = float(by_level[0]['intervention_rate']) if 0 in by_level else 0.0
    rho_lo = float(by_level[3]['intervention_rate']) if 3 in by_level else 0.0

    # bare ranking of the full pool: rank 1 is the best host by median
    # final error across every completed cell of the 30-host study.
    bare_top1 = 'NL-SHADE-RSP'
    try:
        hs = sorted(mech30['host_summary'],
                    key=lambda r: float(r['bare_median_log10err']))
        if hs:
            bare_top1 = hs[0]['host']
    except Exception as exc:                                  # pragma: cover
        print('[UPCL] bare ranking unavailable:', exc)

    probe = {
        'n_hosts': N_HOSTS,
        'rho_hi': rho_hi,
        'rho_lo': rho_lo,
        'bare_top1': bare_top1,
    }

    # ---- population sizes of the hosts actually used -------------------
    try:
        import de_hosts_cec as DHC
        pops = {}
        for (suite, dim) in blocks:
            sizes = sorted({DHC.pop_size_for(h, dim)
                            for h in {c['host'] for c in cells
                                      if (c['suite'], int(c['dim'])) ==
                                      (suite, dim)}})
            pops[(suite, dim)] = sizes
        pop_txt = '; '.join(
            f'${dim}$: $N={"$, $".join(str(s) for s in sizes)}$'
            for (suite, dim), sizes in pops.items())
    except Exception as exc:                                  # pragma: cover
        print('[UPCL] population sizes unavailable:', exc)
        pop_txt = '不可用' if zh else 'not available'

    # ---- budget per block ----------------------------------------------
    budgets = {f'{r["suite"]} ${r["dim"]}$':
               (int(r['fe_bare']), int(r['dim'])) for r in cost_dim}
    mults = sorted({v[0] // v[1] for v in budgets.values()})
    mult = mults[0] if len(mults) == 1 else None
    if mult:
        # One example per dimension actually run, so the D=50 block states
        # its own 500,000 evaluations instead of being implied.
        _ex = [(int(r['dim']), mult * int(r['dim'])) for r in cost_dim]
        if zh:
            _pairs = '，'.join(f'$D={k}$ 时 ${v:,}$ 次' for k, v in _ex)
            budget = f'$10^{{{len(str(mult)) - 1:.0f}}}D$ 次评估（{_pairs}）'
        else:
            _pairs = '$, $'.join(f'{v:,}$ at $D={k}' for k, v in _ex)
            budget = (f'$10^{{{len(str(mult)) - 1:.0f}}}D$ evaluations'
                      f' (${_pairs}$)')
    else:
        budget = ', '.join(f'{k}: ${v[0]:,}$' for k, v in budgets.items())

    # ---- baseline-error confound ---------------------------------------
    try:
        sub = [c for c in cells if (c['suite'], int(c['dim'])) ==
               ('cec2017', 30)]
        base = np.log10([max(float(c['bare_median']), 1e-8) for c in sub])
        corr, pv = spearmanr(base, [float(c['dec']) for c in sub])
    except Exception:                                         # pragma: cover
        corr, pv = float('nan'), float('nan')

    # ---- ablation progress ---------------------------------------------
    abl_keys = {(r['host'], r['fid']) for r in abl_cells}
    abl_done = len(abl_keys)
    abl_hosts = len({k[0] for k in abl_keys})
    abl_total = abl_hosts * 12        # stage definition: 12 functions/host

    # ---- runs per configuration: thirty for every completed cell. ----
    _runs_zh = '每组 30 次'
    _runs_en = '30 per configuration'

    # ---- suite names and grouped dimensions for the protocol table ------
    # Blocks are reported suite by suite with their dimensions grouped, so
    # the fourth block reads as part of CEC 2017 rather than as a repetition.
    _sn = {'cec2017': 'CEC 2017', 'cec2022': 'CEC 2022'}
    _order, _gd = [], {}
    for _s, _d in blocks:
        _n = _sn.get(str(_s).lower(), str(_s))
        if _n not in _gd:
            _order.append(_n)
            _gd[_n] = []
        _gd[_n].append((str(_s).lower(), int(_d)))
    _grp = [(_n, _gd[_n]) for _n in _order]
    _cnt = {k: len(v) for k, v in problems.items()}

    if zh:
        _dims_txt = '；'.join(
            f'{n} 在 ' + ' 与 '.join(f'$D={d}$' for _, d in ds)
            for n, ds in _grp)
        _prob_txt = '；'.join(
            f'{n}：' + '，'.join(
                f'$D={d}$ 时 {SUITE_SIZE.get((r, d), "?")} 个问题'
                for r, d in ds) for n, ds in _grp)
        _cells_txt = ('; '.join(
            f'{n}：' + '，'.join(f'$D={d}$ 时 {_cnt.get((r, d), 0)} 个'
                                for r, d in ds) for n, ds in _grp))
    else:
        _dims_txt = '; '.join(
            f'{n} at ' + ' and '.join(f'$D={d}$' for _, d in ds)
            for n, ds in _grp)
        _prob_txt = '; '.join(
            f'{n}: ' + ', '.join(
                f'{SUITE_SIZE.get((r, d), "?")} problems at $D={d}$'
                for r, d in ds) for n, ds in _grp)
        _cells_txt = ('; '.join(
            f'{n}: ' + ', '.join(f'{_cnt.get((r, d), 0)} at $D={d}$'
                                 for r, d in ds) for n, ds in _grp))

    protocol = {
        'suites': ('CEC 2017 与 CEC 2022，有界约束单目标' if zh
                   else 'CEC 2017 and CEC 2022, bound-constrained single '
                        'objective'),
        'dims': _dims_txt,
        'problems': _prob_txt,
        'budget': budget,
        'hosts': (f'{N_HOSTS} 个 DE 变体，涵盖固定参数与自适应变体'
                  if zh
                  else f'{N_HOSTS} DE variants spanning fixed-parameter '
                       f'and adaptive variants'),
        'pops': pop_txt,
        'runs': (_runs_zh if zh else _runs_en),
        'pairing': ('两组使用相同种子、种群与预算；层从独立生成器采样'
                    if zh else
                    'same seed, population and budget for both '
                    'configurations; the layer draws from its own generator'),
        'cells_line': (f'{len(cells)} 个成对比较（' + _cells_txt + '）'
                       if zh else
                       f'{len(cells)} paired comparisons (' + _cells_txt + ')'),
        'metrics': ('移除的误差数量级与有界相对改进，'
                    '每项比较配以成对 Wilcoxon 检验' if zh else
                    'decades of error removed and bounded relative '
                    'improvement, with a paired Wilcoxon test per comparison'),
        'config': ('所有比较使用同一固定工作点，'
                   '未按套件、维度、变体或函数调参' if zh else
                   'one fixed operating point for every comparison, nothing '
                   'tuned per suite, dimension, variant or function'),
        'err_corr': float(corr),
        'err_corr_p': float(pv),
        'cpu_hours': CPU_HOURS_FULL_GRID,
        'cpu_hours_grid': GRID_CPU_HOURS,
        'abl_done': abl_done,
        'abl_total': abl_total,
    }

    n = len(cells)
    n_pool = len(mech30['cells'])
    # The per-comparison Wilcoxon p value is not part of the paired tables the
    # layer publishes: when the analysis writes the ``p`` column the Holm
    # rejection count is reported, otherwise the summary entry is left empty
    # rather than invented.  Nothing else in the manuscript reads it.
    decs = [float(c['dec']) for c in cells]
    try:
        rej = _holm([float(c['p']) for c in cells])
    except (TypeError, ValueError):
        rej = []
    _holm_ok = len(rej) == len(cells)

    # ---- D=50 coverage of the wave-4 variants ---------------------------
    # The nine wave-4 variants were stopped part-way through their D=50
    # segment, so that block reports only the twenty variants with a complete
    # design.  The fragment is counted here rather than hard-coded in the
    # manuscript, so the sentence follows the raw directory.
    _d50 = {'have': 0, 'total': 0, 'short': 0}
    try:
        _d50_hosts = {r['host'] for r in hosts
                      if (r.get('suite'), str(r.get('dim'))) == ('cec2017', '50')}
        _all_hosts = {r['host'] for r in hosts}
        _w4 = sorted(_all_hosts - _d50_hosts, key=lambda s: s.lower())
        _FUNCS = [1] + list(range(3, 31))          # CEC 2017: F2 excluded
        _d50['total'] = len(_w4) * len(_FUNCS)
        _raw = (ROOT / 'results' / 'cec' / 'raw' / 'cec2017' / 'D50')
        for _f in _raw.glob('*.json'):
            try:
                _d = json.loads(_f.read_text(encoding='utf-8'))
            except Exception:
                continue
            if _d.get('host') not in _w4:
                continue
            _d50['have'] += 1
            if int(_d.get('runs_complete', 0) or 0) < 30:
                _d50['short'] += 1
    except Exception as exc:                                  # pragma: cover
        print('[UPCL] D=50 fragment count unavailable:', exc)

    stats = {
        'n': n,
        'd50_frag': _d50,
        'n_pool': n_pool,
        'improved': sum(1 for d in decs if d > 0),
        'pct_improved': 100.0 * sum(1 for d in decs if d > 0) / max(n, 1),
        'pct_win_holm': (100.0 * sum(1 for a, d in zip(rej, decs)
                                     if a and d > 0) / max(n, 1)
                         if _holm_ok else float('nan')),
        'rho_mean': _mean(cells, 'rho'),
        'mean_dec': sum(decs) / max(n, 1),
        'dec_mean': sum(decs) / max(n, 1),
        'identity_share': _mean(diminfo, 'identity_share'),
        'decision_us': _mean(cost_dim, 'decision_us'),
    }

    return {
        'cells': cells, 'hosts': hosts, 'category': category,
        'diminfo': diminfo, 'descriptor': descriptor,
        'cost_dim': cost_dim, 'cost_host': cost_host,
        'abl_cells': abl_cells, 'abl_friedman': abl_friedman,
        'abl_contrasts': abl_contrasts,
        'block_rank': {(k[0], k[1]): v for k, v in _acc_rank.items()},
        'block_ties': _ties,
        'grid': load_grid(cells, lang, block_rank=_acc_rank),
        'protocol': protocol, 'stats': stats, 'probe': probe,
        'dim_transfer': dim_transfer,
        'mech30': mech30, 'attr': attr, 'n_hosts': n_hosts,
        'n_funcs': n_funcs,
        'scope': {
            'where': ('在 CEC 2017 与 CEC 2022 单目标有界约束套件上'
                      '开展的成对实验' if zh else
                      'paired experiments on the CEC 2017 and CEC 2022 '
                      'single-objective bound-constrained suites'),
            'hosts': (f'{N_HOSTS} 个注册 DE 变体，'
                      f'涵盖固定参数与自适应变体' if zh else
                      f'{N_HOSTS} registered DE variants spanning '
                      'fixed-parameter and adaptive variants'),
            'rho': ('干预率随变体把层本会做出的候选级调整内化而下降，'
                    '这正是机制指纹排序整个家族所沿的轴'
                    if zh else
                    'the intervention rate falls as the variant internalises '
                    'the candidate-generation adjustments the layer would '
                    'otherwise make, which is the axis along which the '
                    'mechanism fingerprint orders the family'),
            'contrib': ('成对研究回答 RQ1–RQ4，'
                        '把贡献定位于少数替换式机制，表明它随问题实例'
                        '强烈波动、而沿函数类别几乎不变，并从这一依赖'
                        '解释为什么现代 DE 难以从变体外部改进。'
                        if zh else
                        'An evidence-based account of mechanism contribution, '
                        'problem dependence and substitutability. The paired '
                        'study answers RQ1-RQ4, locating the contribution in a '
                        'few substitutive mechanisms, showing that it varies '
                        'strongly from problem instance to problem instance and '
                        'hardly at all across function classes, and explaining '
                        'from that dependence why modern DE is hard to improve '
                        'from outside the variant.'),
            'caution': ('校正算子是经典的；UPCL 的贡献在于它所启用的测量，'
                        '即一个可跨变体比较的机制指纹，以及关于哪些机制在'
                        '哪些问题上驱动搜索、以及为何的证据。'
                        if zh else
                        'The correction operators are classical; the '
                        'contribution of UPCL is the measurement it enables, a '
                        'variant-comparable mechanism fingerprint and an '
                        'evidence-based account of which mechanisms drive the '
                        'search, on which problems, and why.'),
            'organisation': ('本文其余部分把这一构造落实为引言承诺的测量：'
                             '回顾经典 DE 与文献表所汇集的变体，将其归入九个机制'
                             '族与四个组成层次，为归因把这些族重编到六个机制'
                             '维度上，构造带三个可观测量的探针，报告'
                             '成对研究在机制贡献、问题依赖与可替换性上测得的'
                             '内容。' if zh else
                             'The rest of the paper turns this '
                             'construction into the measurement promised '
                             'in Section 1: it recalls the canonical DE and the '
                             'variants that the literature tables collect, orders '
                             'them into nine mechanism '
                             'families and four composition levels, recodes the '
                             'families on six dimensions for the attribution, '
                             'constructs the probe with its three observables, '
                             'and reports what the paired study measures '
                             'about mechanism contribution, problem dependence '
                             'and substitutability.'),
        },
    }


# ---------------------------------------------------------------------------
def load_grid(cells, lang='en', block_rank=None):
    """The full 29-host paired family of Section 4.3, built from the Exp 1 cells.

    Every matrix and every block summary is assembled from ``exp1_cells.csv``
    (the same paired data that Section 4.2 reads), so the four blocks
    (CEC 2017 at $D=30$ and $D=50$, CEC 2022 at $D=10$ and $D=20$) cover all
    twenty-nine variants on every function.  ``lang='zh'`` only switches
    human-readable figure labels.  ``block_rank`` is the ranking computed by
    :func:`block_ranks` and reused here, so the summary table of this section
    and the rank column of Section 4.2 are the same numbers.
    """
    zh = (lang == 'zh')
    if block_rank is None:
        _, block_rank, _ = block_ranks(cells)

    # order hosts by their variant-alone rank: median log10 final error over
    # the whole family, ascending (rank 1 = best)
    def _bare_log10(h):
        vals = [float(c['bare_median']) for c in cells if c['host'] == h]
        if not vals:
            return 1e9
        return float(np.log10(max(float(np.median(vals)), 1e-8)))
    hosts = sorted({c['host'] for c in cells}, key=_bare_log10)

    def block(rs):
        if not rs:
            return dict(cells=0, mean_dec=float('nan'), better=0, tie=0,
                        worse=0, runs='-', sig_better=0, sig_worse=0,
                        win_rate=float('nan'), sign_p=float('nan'))
        decs = [float(r['dec']) for r in rs]
        better = sum(1 for r in rs if r['verdict'] == 'win')
        tie = sum(1 for r in rs if r['verdict'] == 'tie')
        worse = sum(1 for r in rs if r['verdict'] == 'loss')
        nt = better + worse
        win_rate = better / nt if nt else float('nan')
        sign_p = (float(binomtest(better, nt, 0.5,
                                  alternative='two-sided').pvalue)
                  if nt else float('nan'))
        return dict(cells=len(rs), mean_dec=sum(decs) / len(decs),
                    better=better, tie=tie, worse=worse, runs='30',
                    sig_better=better, sig_worse=worse,
                    win_rate=win_rate, sign_p=sign_p)

    per_host = []
    for h in hosts:
        blks = [block([r for r in cells
                       if r['host'] == h and r['suite'] == s
                       and int(r['dim']) == d])
                for s, d in GRID_SUITES]
        per_host.append({'host': h, 'blocks': blks,
                         'cells': sum(b['cells'] for b in blks)})

    suites = []
    for suite, dim in GRID_SUITES:
        rs = [r for r in cells
              if r['suite'] == suite and int(r['dim']) == dim]
        info = block(rs)
        n_func = SUITE_SIZE.get((suite, dim), 0)
        info.update(suite=suite, dim=dim, planned=n_func * len(hosts),
                    funcs=len({r['fid'] for r in rs}), funcs_total=n_func,
                    hosts=len({r['host'] for r in rs}))
        suites.append(info)

    # ---- function x algorithm matrices, built from the Exp 1 cells ----
    matrices = {}
    for suite, dim in GRID_SUITES:
        rs = [r for r in cells
              if r['suite'] == suite and int(r['dim']) == dim]
        if not rs:
            continue
        fids = sorted({int(r['fid']) for r in rs})
        hset = [h for h in hosts if any(r['host'] == h for r in rs)]
        by_key = {(int(r['fid']), r['host']): r for r in rs}
        bare_rows, acc_rows = [], []
        for fid in fids:
            brow, arow = [], []
            for h in hset:
                c = by_key.get((fid, h))
                if c:
                    brow.append(f'{float(np.log10(max(float(c["bare_median"]), 1e-8))):.6f}')
                    arow.append(f'{float(np.log10(max(float(c["upcl_median"]), 1e-8))):.6f}')
                else:
                    brow.append('-')
                    arow.append('-')
            bare_rows.append(brow)
            acc_rows.append(arow)
        matrices[(suite, dim)] = {
            'tag': f'{suite}_D{dim}',
            'hosts': hset,
            'fids': [f'F{fid}' for fid in fids],
            'acc': acc_rows,
            'bare': bare_rows,
            'delta': None,
        }

    # ---- function x composition-level terminal value -------------------
    # The level-median of the variant-alone final error (log10), i.e. the
    # exact terminal reading every convergence curve reaches.  One row per
    # function, one column per composition level, so the curves map onto
    # concrete numbers.
    _level_of = {r['host']: r.get('level', 'x')
                 for r in _read('mech30_host_summary.csv')}
    level_matrix = {}
    for suite, dim in GRID_SUITES:
        rs = [r for r in cells
              if r['suite'] == suite and int(r['dim']) == dim]
        if not rs:
            continue
        fids = sorted({int(r['fid']) for r in rs})
        levels = sorted({_level_of.get(r['host'], 'x') for r in rs}
                        & set('0123'))
        rows = []
        for fid in fids:
            cat = next((r['category'] for r in rs
                        if int(r['fid']) == fid), '')
            vals = []
            for lv in levels:
                logv = [float(np.log10(max(float(r['bare_median']), 1e-8)))
                        for r in rs
                        if int(r['fid']) == fid
                        and _level_of.get(r['host'], 'x') == lv]
                vals.append(float(np.median(logv)) if logv else float('nan'))
            rows.append({'fid': f'F{fid}', 'cat': cat, 'vals': vals})
        level_matrix[(suite, dim)] = {
            'suite': suite, 'dim': dim,
            'levels': levels, 'rows': rows,
        }

    # one combined convergence panel per block, split into per-part figures so
    # that each part fits the text column, plus the representative close-up
    # (four typical functions x four representative variants)
    conv_figs = PFG.conv_series()
    rep_path = PFG.fig('conv_representative')
    rep_fig = {'path': rep_path} if Path(rep_path).exists() else None

    return {
        'hosts': hosts, 'per_host': per_host, 'suites': suites,
        'cells': sum(s['cells'] for s in suites),
        'planned': sum(s['planned'] for s in suites),
        'hosts_done': sum(1 for e in per_host if e['cells']),
        'total': block([r for r in cells
                        if (r['suite'], int(r['dim'])) in GRID_SUITES]),
        'cpu_hours': GRID_CPU_HOURS, 'matrices': matrices,
        'level_matrix': level_matrix,
        'conv_figs': conv_figs, 'rep_fig': rep_fig,
        'block_rank': {(k[0], k[1]): {k2[2]: v for k2, v in block_rank.items()
                                       if (k2[0], k2[1]) == k}
                       for k in {(k2[0], k2[1]) for k2 in block_rank}},
    }


# ---------------------------------------------------------------------------
def _availability(P, S):
    """Reproducibility statement, including the coefficients actually used."""
    P.h1('Data, code and coefficients')
    P.para(
        'The layer is attached to a variant through three callbacks, one at '
        'the start of each generation, one that receives $(x_i,u_i)$ and '
        'returns the candidate to evaluate, and one that receives the '
        'resulting fitness along with the fate of the candidate. The variants '
        'used here are unmodified. Each comparison is reproducible from the '
        'seed schedule alone: for run $r$ of problem $f$ at dimension $D$ the '
        'seed is $s(r,f,D)$ and is shared by the variant alone and the same '
        'variant with UPCL, while the layer draws from an independent generator '
        'so that the '
        "variant's random sequence is untouched. Per-comparison results, including "
        'the convergence and intervention traces used in Section 4, are '
        'written by the driver in JSON form, and the tables and figures of '
        'that section are generated from those files rather than edited.')

    P.para(
        f'The coefficients of Table {P.tab_no + 1} are the ones used for every comparison '
        'reported here. They are hyper-parameters of the layer rather than '
        'properties '
        'of it: they were fixed once from the role each plays in the scoring '
        'rule, the exploration schedule and the adaptive identity margin '
        'were revised once after an earlier version of the layer was found '
        'to damage the variant, and nothing was fitted per suite, dimension, '
        'variant or function.')

    cfg = {}
    try:
        from upcl_experiment import get_config
        cfg.update(get_config('default'))
    except Exception as exc:                                  # pragma: cover
        print('[UPCL] default configuration unavailable:', exc)
    rows = [['$\\lambda$', 'weight of the correction cost',
             str(cfg.get('lam', '-'))],
            ['$\\mu_0$', 'static identity margin', str(cfg.get('margin', '-'))],
            ['$\\mu_1$', 'adaptive identity margin coefficient',
             str(cfg.get('margin_adapt', '-'))],
            ['$\\kappa_u$', 'uncertainty penalty',
             str(cfg.get('ucb_kappa', '-'))],
            ['$\\varepsilon_0\\!\\to\\!\\varepsilon_{\\min}$',
             'exploration rate', f"{cfg.get('eps0', '-')} to "
                                 f"{cfg.get('eps_min', '-')}"],
            ['$T_{\\varepsilon}$', 'generations over which exploration decays',
             str(cfg.get('eps_gens', '-'))],
            ['$B$', 'budget', '$10^{4}D$ evaluations'],
            ['$M$', 'response memory capacity', 'as implemented (256)']]
    P.table_caption('Coefficients fixed for every comparison of Section 4. '
                    'The first six are the operating point; anything not '
                    'listed '
                    'keeps the value stated in Section 3.')
    P.table(['Symbol', 'Meaning', 'Value'], rows,
            widths=[1.1, 3.6, 1.6], align='llr')


# ---------------------------------------------------------------------------
def build(out_path=None, stats=None, parts=PARTS):
    """Render the manuscript; ``parts`` selects which sections to emit.

    ``parts='front,bg,method'`` produces the first three sections on their
    own, which is how they were drafted and circulated.
    """
    if isinstance(parts, str):
        parts = tuple(p.strip() for p in parts.split(',') if p.strip())
    unknown = [p for p in parts if p not in PARTS]
    if unknown:
        raise SystemExit(f'[UPCL] unknown part(s): {unknown}; '
                         f'choose from {PARTS}')
    S = stats if stats is not None else load_stats()
    # Sections 1 and 3 embed the artwork drawn for this edition.
    PFG.set_lang('en')
    P = Paper()
    if 'front' in parts:
        PF.build(P, S)
    if 'bg' in parts:
        PBG.build(P, S)
    if 'method' in parts:
        PM.build(P, S)
    if 'exp' in parts:
        PE.build(P, S)
    if 'app' in parts:
        PA.build(P, S)
    if 'back' in parts:
        PE._conclusion(P, S)
        _availability(P, S)
        PE._appendix(P, S)
    P.references(get_refs(), drop_uncited=True)
    if P.uncited_refs:
        print('[UPCL] dropped %d uncited reference(s) from the list'
              % len(P.uncited_refs))
    if P.unknown_refs:
        print('[UPCL] WARNING unknown reference keys:', P.unknown_refs)

    if out_path:
        out = Path(out_path)
    elif parts == PARTS:
        out = ROOT / 'docs' / 'UPCL_paper.docx'
    else:
        out = ROOT / 'docs' / ('UPCL_paper_' + '-'.join(parts) + '.docx')
    P.save(out)
    print('[UPCL] written ->', out)
    print('[UPCL] figures:', P.fig_no, 'tables:', P.tab_no)
    # Keep the manuscript and the paper-figure folder in step: anything added
    # or deleted on either side is reported here.
    PFG.audit(P.figure_files)
    return out


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out', nargs='?', default=None,
                    help='output .docx path')
    ap.add_argument('--parts', default=','.join(PARTS),
                    help=f'comma-separated subset of {PARTS}')
    a = ap.parse_args()
    build(a.out, parts=a.parts)

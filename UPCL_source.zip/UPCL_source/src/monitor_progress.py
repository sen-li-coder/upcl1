"""Wave4 full-run progress monitor.

Scans results/cec/raw and writes one timestamped progress line to a log every
``--interval`` seconds.  A cell counts as "done" when its JSON has
``runs_complete >= --runs`` (default 30).  Progress is computed over the three
blocks the full run covers: cec2022 D10 + D20 (12 funcs each) and cec2017 D30
(30 funcs), 9 wave4 hosts each.

Usage:
    python -u src/monitor_progress.py --interval 600              # loop forever
    python -u src/monitor_progress.py --once                      # one snapshot
"""
import argparse
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / 'results' / 'cec' / 'raw'

HOSTS = ['jDE100', 'j2020', 'DISH', 'DISK', 'LSHADE-cnEpSin',
         'SinDE', 'IMODE', 'PaDE', 'SHADE-ILS']

# (suite, dim, n_funcs)  -> target cells = len(HOSTS) * n_funcs
BLOCKS = [
    ('cec2022', 10, 12),
    ('cec2022', 20, 12),
    ('cec2017', 30, 30),
]


def snapshot(runs: int):
    done = total = 0
    detail = []
    for suite, dim, n_funcs in BLOCKS:
        d = RAW / suite / f'D{dim}'
        target = len(HOSTS) * n_funcs
        total += target
        n = 0
        if d.exists():
            for f in d.glob('*.json'):
                if f.name.split('__')[0] not in HOSTS:
                    continue
                try:
                    j = json.loads(f.read_text(encoding='utf-8'))
                    if j.get('runs_complete', 0) >= runs:
                        n += 1
                except Exception:
                    pass
        done += n
        detail.append((suite, dim, n, target))
    return done, total, detail


def fmt_line(runs: int):
    done, total, detail = snapshot(runs)
    pct = done / total * 100.0 if total else 0.0
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    parts = [f'{s} D{dim}:{n}/{t}' for s, dim, n, t in detail]
    return (f'[{ts}] {done}/{total} cells ({pct:.1f}%)  '
            + '  '.join(parts))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--interval', type=int, default=600, help='seconds (default 600)')
    ap.add_argument('--once', action='store_true')
    ap.add_argument('--runs', type=int, default=30)
    ap.add_argument('--log', type=Path,
                    default=ROOT / 'results' / 'progress_wave4.log')
    args = ap.parse_args()

    args.log.parent.mkdir(parents=True, exist_ok=True)

    if args.once:
        line = fmt_line(args.runs)
        with open(args.log, 'a', encoding='utf-8') as fh:
            fh.write(line + '\n')
        print(line, flush=True)
        return

    while True:
        line = fmt_line(args.runs)
        with open(args.log, 'a', encoding='utf-8') as fh:
            fh.write(line + '\n')
        print(line, flush=True)
        time.sleep(args.interval)


if __name__ == '__main__':
    main()

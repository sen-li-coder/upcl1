# -*- coding: utf-8 -*-
"""Build the UPCL manuscript.

Assembles the paired-experiment statistics produced by
`upcl_experiment.py` and renders the four manuscript parts into a docx.
"""
import json
from pathlib import Path
from collections import defaultdict

import numpy as np

from ec_style import Paper
import upcl_part_front as PF
import upcl_part_method as PM
import upcl_part_exp as PE
import upcl_part_back as PB
from upcl_refs import get_refs

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RESULTS = ROOT / 'results' / 'upcl_D10_default'


# ---------------------------------------------------------------------------
def holm_reject(pvals, alpha=0.05):
    """Holm-Bonferroni step-down rejection set."""
    m = len(pvals)
    if m == 0:
        return []
    rej = [False] * m
    for k, idx in enumerate(np.argsort(pvals)):
        if pvals[idx] <= alpha / (m - k):
            rej[idx] = True
        else:
            break
    return rej


# ---------------------------------------------------------------------------
def cell_dec(r):
    """Orders of magnitude gained on one cell, with a fallback for old files.

    Primary metric.  ``improvement_pct`` divides by a quantity that converges
    to zero, so a cell whose baseline is 1e-12 can swing the mean by hundreds
    of percent; decades of the median cannot.  Old summaries that predate the
    change only stored the medians, which is enough to recover the metric.
    """
    if r.get('gain_dec') is not None:
        return float(r['gain_dec'])
    fl = 1e-8
    o, u = max(float(r['orig_median']), fl), max(float(r['upcl_median']), fl)
    return float(np.log10(o) - np.log10(u))


def build_stats(results_dir=DEFAULT_RESULTS, ablation=None):
    results_dir = Path(results_dir)
    S = {'rows': [], 'stats': {}, 'per_host': [], 'per_func': [],
         'meta': {}, 'figs': {}, 'ablation': []}

    sfile = results_dir / 'summary_D10.json'
    if not sfile.exists():
        print('[UPCL] summary not found:', sfile)
        return S

    rows = json.loads(sfile.read_text(encoding='utf-8'))
    S['rows'] = rows

    # ---- experiment metadata from the first pair file -------------------
    for pf in sorted(results_dir.glob('pair_*.json')):
        d = json.loads(pf.read_text(encoding='utf-8'))
        S['meta'] = {
            'dim': d.get('dim', 10),
            'max_evals': d.get('max_evals', 0),
            'n_runs': len(d.get('original', [])),
        }
        break

    # ---- per-host aggregation -------------------------------------------
    by_host = defaultdict(list)
    for r in rows:
        by_host[r['host']].append(r)
    order = {'DE/rand/1': 0, 'CoBiDE': 1, 'JADE': 2,
             'SHADE': 3, 'L-SHADE': 4, 'jSO': 5}
    for h, rs in sorted(by_host.items(), key=lambda kv: order.get(kv[0], 9)):
        om = float(np.mean([r['orig_mean'] for r in rs]))
        um = float(np.mean([r['upcl_mean'] for r in rs]))
        S['per_host'].append({
            'host': h,
            'orig_mean': om,
            'upcl_mean': um,
            'imp_pct': (om - um) / (abs(om) + 1e-30) * 100.0,
            'gain_dec': float(np.mean([cell_dec(r) for r in rs])),
            'n_imp': sum(1 for r in rs if cell_dec(r) > 0),
            'n_funcs': len(rs),
            'n_sig': sum(1 for r in rs if r.get('wilcoxon_p_two_sided', 1) < 0.05),
            'rho': float(np.mean([r.get('policy_rate', 0.0) for r in rs])),
            'rho_all': float(np.mean([r.get('intervention_rate', 0.0) for r in rs])),
            'shift': float(np.mean([r.get('mean_relative_shift', 0.0) for r in rs])),
        })

    # ---- per-function aggregation ---------------------------------------
    by_func = defaultdict(list)
    for r in rows:
        by_func[r['func']].append(r)
    for fn, rs in by_func.items():
        om = float(np.mean([r['orig_mean'] for r in rs]))
        um = float(np.mean([r['upcl_mean'] for r in rs]))
        S['per_func'].append({
            'func': fn,
            'imp_pct': (om - um) / (abs(om) + 1e-30) * 100.0,
            'gain_dec': float(np.mean([cell_dec(r) for r in rs])),
            'n_imp': sum(1 for r in rs if cell_dec(r) > 0),
            'n_hosts': len(rs),
            'rho': float(np.mean([r.get('policy_rate', 0.0) for r in rs])),
        })

    # ---- overall statistics ---------------------------------------------
    n = len(rows)
    pvals = [r.get('wilcoxon_p_two_sided', 1.0) for r in rows]
    rej = holm_reject(pvals)
    n_sig_holm = sum(1 for a, b in zip(rej, rows) if a and cell_dec(b) > 0)
    n_loss_holm = sum(1 for a, b in zip(rej, rows) if a and cell_dec(b) < 0)

    S['stats'] = {
        'n': n,
        'improved': sum(1 for r in rows if cell_dec(r) > 0),
        'degraded': sum(1 for r in rows if cell_dec(r) < 0),
        'win': sum(1 for r in rows if r.get('result_direction') == 'win'),
        'loss': sum(1 for r in rows if r.get('result_direction') == 'loss'),
        'neutral': sum(1 for r in rows if r.get('result_direction') == 'neutral'),
        'pct_improved': 100.0 * sum(1 for r in rows
                                    if cell_dec(r) > 0) / max(n, 1),
        'win_holm': n_sig_holm,
        'pct_win_holm': 100.0 * n_sig_holm / max(n, 1),
        'loss_holm': n_loss_holm,
        'rho_mean': float(np.mean([r.get('policy_rate', 0.0) for r in rows])),
        'mean_improvement_pct': float(np.mean([r.get('improvement_pct', 0.0)
                                               for r in rows])),
        'mean_gain_dec': float(np.mean([cell_dec(r) for r in rows])),
    }
    S['n_hosts'] = len(by_host)
    S['n_funcs'] = len(by_func)
    S['meta']['n_hosts'] = len(by_host)
    S['meta']['n_funcs'] = len(by_func)
    S['figs'] = {
        'converge': 'upcl_fig1_converge.png',
        'rho': 'upcl_fig2_rho.png',
    }
    if ablation is None:
        af = ROOT / 'results' / 'upcl_ablation.json'
        if af.exists():
            try:
                raw = json.loads(af.read_text(encoding='utf-8'))
                ablation = [[a['variant'],
                             f"{a.get('dec', a['imp']):+.3f}",
                             a['cells'], f"{a['rho']:.3f}"] for a in raw]
            except Exception as exc:
                print('[UPCL] could not read ablation file:', exc)
                ablation = []
    S['ablation'] = ablation or []
    return S


# ---------------------------------------------------------------------------
def build(out_path=None, results_dir=DEFAULT_RESULTS, ablation=None,
          stats=None):
    S = stats if stats is not None else build_stats(results_dir, ablation)
    P = Paper()
    PF.build(P, S)
    PM.build(P, S)
    PE.build(P, S)
    PB.build(P, S)
    P.references(get_refs())
    if P.unknown_refs:
        print('[UPCL] WARNING unknown reference keys:', P.unknown_refs)

    out = Path(out_path) if out_path else ROOT / 'docs' / 'UPCL_EC_journal.docx'
    P.save(out)
    print('[UPCL] written ->', out)
    print('[UPCL] figures:', P.fig_no, 'tables:', P.tab_no)
    return out


if __name__ == '__main__':
    build()

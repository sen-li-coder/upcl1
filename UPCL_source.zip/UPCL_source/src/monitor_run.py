#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Monitor the progress of run_upcl_grid.py background experiments.

Usage:
    python src/monitor_run.py                 # one-shot snapshot (print + append)
    python src/monitor_run.py --loop 600      # snapshot every 600 s, keep running
    python src/monitor_run.py --log <path>    # custom monitor log path
    python src/monitor_run.py --log-file <f>  # explicit run log to monitor
    python src/monitor_run.py --tail 8        # show last 8 completion records
    python src/monitor_run.py --no-file       # print only, do not write log

Notes:
    * Auto-locates the newest still-running ``*_run.log`` under
      ``results/grid`` (contains ``starting N cells`` with no ``finished``
      after it), unless ``--log-file`` is given.
    * Parses ``[grid] K/N done <suite> D<dim> <host> F<fid> <x.x> min``
      lines for progress K/N and worker count, and estimates ETA from the
      average cost of the most recent cells.
    * Scans ``results/grid/raw/<suite>/D<dim>/*.json`` for active cells
      (recently written and not yet at full runs) as a liveness check.
    * All output is plain ASCII so it reads cleanly in any terminal/log
      viewer regardless of code page.
"""
import argparse
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
GRID = ROOT / "results" / "grid"
RAW = GRID / "raw"
DEFAULT_MON = GRID / "monitor_run.log"

RUNS = 30  # independent runs per cell in the grid experiment

START_RE = re.compile(r"starting\s+(\d+)\s+cells\s+on\s+(\d+)\s+workers")
DONE_RE = re.compile(
    r"\[grid\]\s+(\d+)/(\d+)\s+done\s+(\S+)\s+D(\d+)\s+(\S+)\s+F(\d+)"
    r"\s+([\d.]+)\s+min")
FINISH_RE = re.compile(r"\[grid\]\s+finished\s+(\d+)\s+cells")


def _dt(ts):
    return datetime.fromtimestamp(ts).strftime("%m-%d %H:%M:%S")


def _dur(seconds):
    seconds = int(seconds)
    d, h = divmod(seconds, 86400)
    h, m = divmod(h, 3600)
    m, _ = divmod(m, 60)
    if d:
        return f"{d}d{h:02d}h"
    if h:
        return f"{h}h{m:02d}m"
    return f"{m}m"


def find_active_log():
    """Return the most recently modified ``*_run.log`` under results/grid.

    Following the newest log (finished or not) keeps the monitor attached to
    the current experiment.  The previous "newest still-running log" rule had
    a failure mode: once the current run finished, it fell back to an older
    abandoned ``*_run.log`` from a previous day, making progress appear to
    jump backwards (e.g. 99.6% -> 67%).
    """
    if not GRID.exists():
        return None
    candidates = sorted(GRID.glob("*_run.log"),
                        key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0] if candidates else None


def parse_log(path):
    """Parse the run log; return an info dict."""
    info = dict(total=None, workers=None, done=0, wall_h=None,
                tail=[], costs=[], created=None, last_done=None,
                hosts={})
    if path is None or not Path(path).exists():
        return info
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    # Only count cells after the LAST "starting N cells" marker.
    start_idx = -1
    for i, ln in enumerate(lines):
        m = START_RE.search(ln)
        if m:
            start_idx = i
            info["total"], info["workers"] = int(m.group(1)), int(m.group(2))
    for m in re.finditer(r"wall clock\s*:\s*~?([\d.]+)\s*h", text):
        info["wall_h"] = float(m.group(1))

    seg = lines[start_idx + 1:] if start_idx >= 0 else lines
    for ln in seg:
        dm = DONE_RE.search(ln)
        if dm:
            info["done"] = int(dm.group(1))
            info["costs"].append(float(dm.group(7)) * 60.0)  # seconds
            h = dm.group(5)
            info["hosts"][h] = info["hosts"].get(h, 0) + 1
    info["tail"] = [ln for ln in seg if DONE_RE.search(ln)][-8:]
    info["created"] = os.path.getctime(path)
    info["last_done"] = os.path.getmtime(path)
    return info


def python_count():
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-Process python -ErrorAction SilentlyContinue).Count"],
            capture_output=True, timeout=25).stdout
        return int(out.decode("utf-8", "ignore").strip() or 0)
    except Exception:
        return -1


def scan_active(active_sec):
    """Return (active_cells, total_json); active sorted by mtime desc."""
    rows = []
    if RAW.exists():
        for p in RAW.rglob("*.json"):
            try:
                rel = p.relative_to(RAW)
                suite, dimdir = rel.parts[0], rel.parts[1]
                dim = int(dimdir[1:])
                host_file, fid = p.stem.split("__F")
                host = host_file.replace("-", "/")
            except Exception:
                continue
            runs = -1
            try:
                head = p.open("rb").read(512).decode("utf-8", "ignore")
                m = re.search(r'"runs_complete"\s*:\s*(\d+)', head)
                runs = int(m.group(1)) if m else -1
            except Exception:
                pass
            rows.append(dict(suite=suite, dim=dim, host=host, fid=int(fid),
                             runs=runs, mtime=p.stat().st_mtime))
    now = time.time()
    active = [r for r in rows if 0 <= r["runs"] < RUNS
              and now - r["mtime"] < active_sec]
    active.sort(key=lambda r: r["mtime"], reverse=True)
    return active, len(rows)


def snapshot(path, active_sec, tail_n):
    now = time.time()
    info = parse_log(path)
    active, n_json = scan_active(active_sec)
    L = []
    sep = "=" * 70
    L.append(sep)
    L.append(f"[monitor] {_dt(now)}   run log: "
             f"{Path(path).name if path else '(not found)'}")
    if info.get("created"):
        L.append(f"  elapsed {_dur(now - info['created'])}  "
                 f"json files: {n_json}")
    L.append("-" * 70)

    total, done = info.get("total"), info.get("done")
    if total:
        pct = 100.0 * done / total
        bar_len = 30
        fill = int(bar_len * done / total)
        bar = "#" * fill + "-" * (bar_len - fill)
        L.append(f"progress: {done}/{total} cells  [{bar}]  {pct:.1f}%")
    else:
        L.append("progress: (no 'starting N cells' found in log)")

    w = info.get("workers")
    py = python_count()
    L.append(f"workers: {w if w else '?'}   python procs: {py}")

    if info.get("tail"):
        L.append(f"last done: {info['tail'][-1].strip()}")
        L.append("-" * 70)
        L.append("recent done:")
        L.extend("  " + x.strip() for x in info["tail"][-tail_n:])
    elif info.get("last_done"):
        L.append(f"log activity: {_dt(info['last_done'])} "
                 f"({_dur(now - info['last_done'])} ago, no completion yet)")

    L.append("-" * 70)
    if active:
        L.append(f"active cells (last {active_sec // 60}min, {len(active)} total):")
        for r in active[:tail_n]:
            L.append(f"  {r['suite']} D{r['dim']} {r['host']:<20s} "
                     f"F{r['fid']:<3d} run {r['runs']}/{RUNS} "
                     f"({_dur(now - r['mtime'])} ago)")
    else:
        L.append(f"active cells: none (no write in last {active_sec // 60}min)")

    L.append("-" * 70)
    eta_txt = "n/a"
    if total and done and done < total and info.get("costs"):
        recent = info["costs"][-8:]
        avg = sum(recent) / len(recent)
        remain = total - done
        workers = w or 1
        eta_s = avg * remain / workers
        eta_txt = (f"~{_dt(now + eta_s)}  "
                   f"({remain} cells left x ~{avg / 60:.0f}min/{workers} workers)")
    elif total and done >= total:
        eta_txt = "finished"
    L.append("ETA: " + eta_txt)

    if total and done >= total:
        L.append("status: all done")
    elif active:
        L.append("status: OK (workers active)")
    elif py > 0:
        L.append("status: idle (no writes, possibly slow cells)")
    else:
        L.append("status: WARNING (no python procs, experiment may be stopped)")

    if info.get("hosts"):
        hh = sorted(info["hosts"].items(), key=lambda x: -x[1])
        L.append("-" * 70)
        L.append("done per host: " + " | ".join(f"{h} {c}" for h, c in hh))

    L.append(sep)
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--loop", type=int, default=0,
                    help="poll interval in seconds; 0 = single snapshot")
    ap.add_argument("--log", type=str, default=str(DEFAULT_MON),
                    help="monitor log output path")
    ap.add_argument("--log-file", type=str, default=None,
                    help="run log to monitor (default: auto-detect)")
    ap.add_argument("--active-window", type=int, default=30,
                    help="active-cell window in minutes")
    ap.add_argument("--tail", type=int, default=6,
                    help="number of recent completion records to show")
    ap.add_argument("--no-file", action="store_true",
                    help="print to screen only, do not write the log file")
    a = ap.parse_args()

    log_path = Path(a.log)
    active_sec = a.active_window * 60

    def emit(text):
        sys.stdout.write(text + "\n")
        sys.stdout.flush()
        if not a.no_file:
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write(text + "\n")

    try:
        while True:
            path = Path(a.log_file) if a.log_file else find_active_log()
            emit(snapshot(path, active_sec, a.tail))
            if a.loop <= 0:
                break
            time.sleep(a.loop)
    except KeyboardInterrupt:
        emit("[monitor] stopped.")


if __name__ == "__main__":
    main()

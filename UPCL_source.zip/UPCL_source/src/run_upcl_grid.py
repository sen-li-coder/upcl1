# -*- coding: utf-8 -*-
"""Full algorithm x function grid for UPCL, warm-started from what exists.

The CEC paired runs in ``results/cec`` cover six host algorithms on twelve
CEC 2017 functions and four hosts on three CEC 2022 functions.  This driver
completes the grid the paper actually needs: every registered host (twenty of
them) on every function of both suites, two arms only -

    bare      the host unmodified
    upcl      the same host with the layer attached

- and nothing else.  Records already produced by ``run_upcl_cec.py`` are
reused rather than recomputed: those files use the same seeds, the same
budget and both of these arms, so a cell only costs anything when it is
genuinely missing.

    python src/run_upcl_grid.py --plan            # coverage + CPU estimate
    python src/run_upcl_grid.py --workers 18      # run everything missing
    python src/run_upcl_grid.py --suites cec2022  # the cheap suite first

Results land in ``results/grid/raw/<suite>/D<dim>/<host>__F<fid>.json``.  The
``results/cec`` tree is never written, so the ablation stage keeps its data.
Each cell is written to its own file as soon as it is complete, so the run can
be stopped and resumed.
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

# Pin BLAS/OpenMP to a single thread per worker.  The machine has ~20 cores
# and the grid spawns ~18 Python processes; if every process lets OpenBLAS
# spin up its default 24 threads they oversubscribe the cores and inflate the
# wall time by 8-12x.  The CEC objectives here are not matmul-bound, so
# single-threading loses no per-core throughput (verified empirically).
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
           'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(_v, '1')

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                        # noqa: E402
import de_hosts_cec as DHC                                     # noqa: E402
import run_upcl_cec as R                                       # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'grid'
CEC_OUT = ROOT / 'results' / 'cec'

ARMS = [('bare', None), ('upcl', 'default')]
RUNS = 30
FES_MULT = R.FES_MULT
SEED_BASE = R.SEED_BASE
SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10), ('cec2022', 20))


# --------------------------------------------------------------------------
def _seed_for(fid, dim, r):
    return SEED_BASE + dim * 1_000_003 + r * 7919 + fid * 31


def _path(suite, dim, host, fid):
    return (OUT / 'raw' / suite / f'D{dim}'
            / f'{host.replace("/", "-")}__F{fid}.json')


def _load_runs(existing, n_runs):
    """Pull the two arms out of an existing record file, if it has them.

    ``results/cec`` stores the full layer under the arm name ``full``; this
    driver stores it under ``upcl``.  Both spellings mean the same arm here,
    so a file written by an earlier run of this driver is reused exactly like
    one imported from ``results/cec`` - without this alias the driver would
    silently re-run every cell it had already produced.
    """
    have = existing.get('arms', [])
    second = 'full' if 'full' in have else ('upcl' if 'upcl' in have else None)
    if 'bare' not in have or second is None:
        return None
    out = []
    for r in existing.get('runs', []):
        b, f = r.get('bare'), r.get(second)
        if not isinstance(b, dict) or not isinstance(f, dict):
            return None
        if 'err_curve' not in b or 'err_curve' not in f:
            return None
        out.append({'run': r['run'], 'seed': r['seed'],
                    'bare': b, 'upcl': f})
    if len(out) < n_runs:
        return None
    return out if n_runs == 0 else out[:n_runs]


def existing_runs(suite, dim, host, fid, runs=RUNS):
    """Completed runs already available for a cell, and where they came from."""
    name = f'{host.replace("/", "-")}__F{fid}.json'
    for tag, base in (('grid', OUT / 'raw'), ('cec', CEC_OUT / 'raw')):
        p = base / suite / f'D{dim}' / name
        if not p.exists():
            continue
        try:
            with open(p, encoding='utf-8') as fh:
                got = _load_runs(json.load(fh), runs)
        except Exception:
            continue
        if got:
            return got, tag
    return None, None


def plan(suites=SUITES, hosts=None, runs=RUNS):
    """Every cell of the grid, split into reusable and still-to-run."""
    host_list = hosts or list(DHC.CEC_HOST_ORDER)
    todo, warm, ready = [], [], []
    for suite, dim in suites:
        fids = [f.fid for f in CS.get_suite(suite, dim)]
        for h in host_list:
            for fid in fids:
                task = dict(suite=suite, dim=dim, host=h, fid=fid,
                            runs=runs, arms=list(ARMS), fes_mult=FES_MULT)
                _, src = existing_runs(suite, dim, h, fid, runs)
                if src is None:
                    todo.append(task)
                elif src == 'cec':
                    warm.append(task)       # reuse rather than recompute
                else:
                    ready.append(task)
    return host_list, todo, warm, ready


def estimate_cost(todo):
    """CPU hours for the missing cells, from the costs actually measured."""
    meas = R.measured_run_cost()
    if not meas:
        return None
    total, unknown = 0.0, 0
    pool_cache = {}
    for t in todo:
        kb = (t['suite'], t['dim'], t['fid'], 'bare')
        kf = (t['suite'], t['dim'], t['fid'], 'full')
        if kb in meas and kf in meas:
            per = meas[kb][0] + meas[kf][0]
        else:
            key = (t['suite'], t['dim'])
            if key not in pool_cache:
                vals = [v[0] for k, v in meas.items()
                        if k[0] == key[0] and k[1] == key[1]
                        and k[3] in ('bare', 'full')]
                if vals:
                    pool_cache[key] = sum(vals) / len(vals)
                else:
                    # No measurements for this (suite, dim) yet: scale the
                    # nearest measured dimension of the same suite by the
                    # ratio of the dimensions (cost grows roughly linearly
                    # with D for the benchmark objectives).
                    dims = sorted({k[1] for k in meas if k[0] == key[0]})
                    pool_cache[key] = 0.0
                    if dims:
                        base = dims[0]
                        base_vals = [v[0] for k, v in meas.items()
                                     if k[0] == key[0] and k[1] == base
                                     and k[3] in ('bare', 'full')]
                        if base_vals:
                            avg = sum(base_vals) / len(base_vals)
                            pool_cache[key] = avg * (key[1] / base)
            per = pool_cache[key] * 2
            unknown += 1
        total += per * t['runs']
    return total / 3600.0, unknown


# --------------------------------------------------------------------------
def _payload(suite, dim, host_name, fid, func, max_evals, per_run):
    return {
        'suite': suite, 'dim': dim, 'host': host_name, 'fid': fid,
        'func': func.name, 'category': func.category,
        'max_evals': int(max_evals), 'runs_complete': len(per_run),
        'arms': [a for a, _ in ARMS],
        'runs': sorted(per_run, key=lambda r: r['run']),
    }


def _replace_retry(src, dst, attempts=10, delay=1.0):
    """Atomically replace dst with src, retrying the transient PermissionError
    ([WinError 5]) that Windows Defender / the search indexer can raise against
    a file written a moment ago."""
    last = None
    for i in range(attempts):
        try:
            src.replace(dst)
            return
        except PermissionError as exc:
            last = exc
            time.sleep(delay * (i + 1))
    raise last


def run_cell(task):
    """Run whatever is missing for one cell; write the file when complete."""
    suite, dim = task['suite'], task['dim']
    host_name, fid = task['host'], task['fid']
    runs = task['runs']
    max_evals = task['fes_mult'] * dim
    out_file = _path(suite, dim, host_name, fid)
    out_file.parent.mkdir(parents=True, exist_ok=True)

    per_run, _ = existing_runs(suite, dim, host_name, fid, 0) or ([], None)
    per_run = list(per_run or [])
    have = {r['run'] for r in per_run}
    if len(per_run) >= runs:
        return ('skip', f'{suite} D{dim} {host_name} F{fid}', 0.0)

    func = CS.get_function(suite, dim, fid)
    pop = DHC.pop_size_for(host_name, dim)
    t0 = time.perf_counter()
    for r in range(runs):
        if r in have:
            continue
        seed = _seed_for(fid, dim, r)
        entry = {'run': r, 'seed': seed}
        for label, cfg in task['arms']:
            entry[label] = R.run_arm(host_name, func, dim, seed, max_evals,
                                     cfg, pop_size=pop)
        per_run.append(entry)
        payload = _payload(suite, dim, host_name, fid, func, max_evals,
                           per_run)
        tmp = out_file.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh)
        _replace_retry(tmp, out_file)
    return ('done', f'{suite} D{dim} {host_name} F{fid}',
            time.perf_counter() - t0)


# --------------------------------------------------------------------------
def report(suites, hosts=None, runs=RUNS, workers=None):
    host_list, todo, warm, ready = plan(suites, hosts, runs)
    total = sum(len([f.fid for f in CS.get_suite(s, d)]) * len(host_list)
                for s, d in suites)
    print(f'hosts        : {len(host_list)}')
    print(f'cells total  : {total}')
    print(f'already done : {len(ready)}  (this driver)')
    print(f'reusable     : {len(warm)}  (imported from results/cec)')
    print(f'to run       : {len(todo)}')
    est = estimate_cost(todo)
    if est:
        hours, unknown = est
        extra = f'  ({unknown} cells extrapolated)' if unknown else ''
        print(f'CPU cost     : {hours:.1f} h{extra}')
        w = workers or max(1, (os.cpu_count() or 4) - 2)
        print(f'wall clock   : ~{hours / w:.1f} h at {w} workers')
    return todo


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--plan', action='store_true',
                    help='print coverage and cost, run nothing')
    ap.add_argument('--suites', nargs='*', default=None,
                    help='subset of cec2017, cec2022')
    ap.add_argument('--dims', nargs='*', type=int, default=None,
                    help='subset of dimensions, e.g. 30 50')
    ap.add_argument('--hosts', nargs='*', default=None)
    ap.add_argument('--funcs', nargs='*', type=int, default=None)
    ap.add_argument('--runs', type=int, default=RUNS)
    ap.add_argument('--workers', type=int,
                    default=max(1, (os.cpu_count() or 4) - 1))
    ap.add_argument('--limit', type=int, default=None,
                    help='run at most this many cells')
    a = ap.parse_args(argv)

    suites = SUITES
    if a.suites:
        suites = tuple(s for s in SUITES if s[0] in a.suites)
    if a.dims:
        suites = tuple(s for s in suites if s[1] in a.dims)

    if a.plan:
        report(suites, a.hosts, a.runs, a.workers)
        return

    _, todo, _, _ = plan(suites, a.hosts, a.runs)
    if a.funcs:
        todo = [t for t in todo if t['fid'] in a.funcs]
    if a.limit:
        todo = todo[:a.limit]
    if not todo:
        print('[grid] nothing to run')
        return
    report(suites, a.hosts, a.runs, a.workers)
    print(f'[grid] starting {len(todo)} cells on {a.workers} workers')

    ctx = mp.get_context('spawn')
    t0 = time.perf_counter()
    done = 0
    total = len(todo)
    with ctx.Pool(a.workers) as pool:
        for status, what, dt in pool.imap_unordered(run_cell, todo):
            done += 1
            elapsed = time.perf_counter() - t0
            avg = elapsed / done
            remain = avg * (total - done)
            eta = time.strftime('%m-%d %H:%M:%S',
                                time.localtime(time.time() + remain))
            print(f'[grid] {done:4d}/{total} {status:5s} {what} '
                  f'{dt / 60.0:6.1f} min  elapsed {elapsed / 3600:.1f}h  '
                  f'left ~{remain / 3600:.1f}h  ETA {eta}', flush=True)
    print(f'[grid] finished {done} cells in '
          f'{(time.perf_counter() - t0) / 3600:.2f} h')


if __name__ == '__main__':
    main()

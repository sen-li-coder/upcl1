"""Rebuild the coverage-grid tables of Section 4.3 from the raw per-cell JSON.

Reads ``results/cec/raw/{suite}/D{dim}/*.json``, keeps only *finished* cells
(30 runs) of the twenty established hosts (whose UPCL arm is named ``upcl``),
and emits the same CSVs that ``run_upcl_grid.py`` used to write:

* ``cells.csv``                 one row per finished cell;
* ``accuracy_{tag}.csv``        function x host, log10 median UPCL error;
* ``bare_accuracy_{tag}.csv``   function x host, log10 median bare error;
* ``delta_{tag}.csv``           function x host, dec (bare - UPCL, orders);
* ``mechanism_by_host.csv``     per-host mechanism fingerprint.

Unfinished cells are omitted so the manuscript prints a dash for them.
"""

import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw'
TAB = ROOT / 'results' / 'cec' / 'tables'
TAB.mkdir(parents=True, exist_ok=True)

FLOOR = 1e-8
RUNS = 30

GRID_SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10))

# The twenty established hosts (CEC_HOST_ORDER[:20]) and their adaptivity wave.
OLD_HOSTS = [
    'DE/rand/1', 'DE/best/1', 'DE/rand/2', 'DE/current-to-best/1',
    'DE/current-to-rand/1', 'DE/rand/1/either-or', 'jDE', 'SaNSDE',
    'JADE', 'SHADE', 'CoBiDE', 'SaDE', 'EPSDE', 'CoDE', 'MPEDE',
    'L-SHADE', 'jSO', 'L-SHADE-RSP', 'NL-SHADE-RSP', 'MadDE',
]
ADAPTIVITY = {
    'DE/rand/1': 0, 'DE/best/1': 0, 'DE/rand/2': 0,
    'DE/current-to-best/1': 0, 'DE/current-to-rand/1': 0,
    'DE/rand/1/either-or': 0,
    'jDE': 1, 'SaNSDE': 1,
    'JADE': 2, 'SHADE': 2, 'CoBiDE': 2, 'SaDE': 2, 'EPSDE': 2,
    'CoDE': 2, 'MPEDE': 2,
    'L-SHADE': 3, 'jSO': 3, 'L-SHADE-RSP': 3, 'NL-SHADE-RSP': 3,
    'MadDE': 3,
}
DESC_NAMES = ['rho_step', 'theta_align', 'eta_elite', 'kappa_crowd', 'nu_novel']


def _wilcoxon(a, b):
    from scipy.stats import wilcoxon
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    d = d[d != 0]
    if len(d) == 0:
        return 1.0
    try:
        return float(wilcoxon(d).pvalue)
    except Exception:
        return 1.0


def _load_finished():
    """Return {(suite, dim, host, fid): {'category': .., 'runs': [...]}}."""
    cells = {}
    for f in RAW.rglob('*.json'):
        try:
            with open(f, encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        if d.get('host') not in OLD_HOSTS:
            continue
        dim = int(d.get('dim', 0))
        if (d.get('suite'), dim) not in GRID_SUITES:
            continue
        if 'upcl' not in d.get('arms', []):
            continue
        key = (d['suite'], dim, d['host'], int(d['fid']))
        if key in cells:
            cells[key]['runs'].extend(d['runs'])
        else:
            cells[key] = {'category': d.get('category', ''), 'runs': list(d['runs'])}
    # Finished only: a cell with fewer than RUNS merged runs is left out.
    return {k: c for k, c in cells.items() if len(c['runs']) >= RUNS}


def _reference(cells):
    """Per-(suite, dim, fid) minimum over every bare/upcl final error."""
    ref = defaultdict(lambda: float('inf'))
    for (suite, dim, _h, fid), c in cells.items():
        for r in c['runs']:
            for arm in ('bare', 'upcl'):
                if arm in r:
                    v = float(r[arm]['err_final'])
                    ref[(suite, dim, fid)] = min(ref[(suite, dim, fid)], v)
    return ref


def _shifted(r, arm, shift):
    return max(float(r[arm]['err_final']) - shift, 0.0)


def _write_cells(cells, ref):
    rows = []
    for (suite, dim, host, fid), c in sorted(cells.items()):
        shift = ref[(suite, dim, fid)]
        bare = np.array([_shifted(r, 'bare', shift) for r in c['runs']], float)
        upcl = np.array([_shifted(r, 'upcl', shift) for r in c['runs']], float)
        n = min(len(bare), len(upcl))
        if n == 0:
            continue
        bm = float(np.median(bare[:n]))
        um = float(np.median(upcl[:n]))
        dec = (np.log10(max(bm, FLOOR)) - np.log10(max(um, FLOOR)))
        p = _wilcoxon(bare[:n], upcl[:n])
        verdict = 'better' if dec > 0.05 else ('worse' if dec < -0.05 else 'tie')
        rows.append(dict(
            suite=suite, dim=dim, host=host, fid=fid, category=c['category'],
            runs=RUNS, reference_value=f'{shift:.8g}',
            bare_median=f'{bm:.8g}', upcl_median=f'{um:.8g}',
            decades_removed=f'{dec:.3f}', p_wilcoxon=f'{p:.4g}',
            verdict=verdict))
    fields = ['suite', 'dim', 'host', 'fid', 'category', 'runs',
              'reference_value', 'bare_median', 'upcl_median',
              'decades_removed', 'p_wilcoxon', 'verdict']
    with open(TAB / 'cells.csv', 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print('[grid] cells.csv:', len(rows), 'rows')


def _write_matrices(cells, ref):
    by_block = defaultdict(dict)
    for (suite, dim, host, fid), c in cells.items():
        by_block[(suite, dim)][(host, fid)] = c
    for suite, dim in GRID_SUITES:
        block = by_block.get((suite, dim))
        if not block:
            continue
        tag = f'{suite}_D{dim}'
        fids = sorted({fid for (_h, fid) in block}, key=int)
        acc_rows, bare_rows, delta_rows = [], [], []
        for fid in fids:
            shift = ref[(suite, dim, fid)]
            acc_row, bare_row, delta_row = [f'F{fid}'], [f'F{fid}'], [f'F{fid}']
            for h in OLD_HOSTS:
                c = block.get((h, fid))
                if not c:
                    acc_row.append('-')
                    bare_row.append('-')
                    delta_row.append('-')
                    continue
                bare = np.array([_shifted(r, 'bare', shift) for r in c['runs']], float)
                upcl = np.array([_shifted(r, 'upcl', shift) for r in c['runs']], float)
                n = min(len(bare), len(upcl))
                lb = np.log10(max(float(np.median(bare[:n])), FLOOR))
                lu = np.log10(max(float(np.median(upcl[:n])), FLOOR))
                acc_row.append(f'{lu:.3f}')
                bare_row.append(f'{lb:.3f}')
                delta_row.append(f'{lb - lu:.3f}')
            acc_rows.append(acc_row)
            bare_rows.append(bare_row)
            delta_rows.append(delta_row)
        _write_matrix(f'accuracy_{tag}.csv', acc_rows)
        _write_matrix(f'bare_accuracy_{tag}.csv', bare_rows)
        _write_matrix(f'delta_{tag}.csv', delta_rows)


def _write_matrix(name, rows):
    with open(TAB / name, 'w', encoding='utf-8', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['fid'] + OLD_HOSTS)
        w.writerows(rows)
    print('[grid]', name)


def _write_mechanism(cells):
    rows = []
    for (suite, dim, host) in sorted({(k[0], k[1], k[2]) for k in cells}):
        cs = [c for k, c in cells.items() if (k[0], k[1], k[2]) == (suite, dim, host)]
        inter, ident, shift = [], [], []
        desc = [[] for _ in range(5)]
        for c in cs:
            for r in c['runs']:
                u = (r.get('upcl') or {}).get('upcl') or {}
                if u.get('intervention_rate') is not None:
                    inter.append(float(u['intervention_rate']))
                if u.get('mean_relative_shift') is not None:
                    shift.append(float(u['mean_relative_shift']))
                ac = u.get('action_counts')
                if ac:
                    tot = sum(ac.values())
                    if tot:
                        ident.append(float(ac.get('I', 0)) / tot)
                di = u.get('descriptor_influence')
                if di:
                    for k in range(5):
                        if di.get(f'z{k}_effect') is not None:
                            desc[k].append(float(di[f'z{k}_effect']))

        def _mean(v):
            return float(np.mean(v)) if v else 0.0

        rows.append(dict(
            suite=suite, dim=dim, host=host, wave=ADAPTIVITY.get(host, 0),
            n_cells=len(cs),
            rho_step=_mean(desc[0]), theta_align=_mean(desc[1]),
            eta_elite=_mean(desc[2]), kappa_crowd=_mean(desc[3]),
            nu_novel=_mean(desc[4]),
            intervention_rate=_mean(inter), identity_share=_mean(ident),
            mean_relative_shift=_mean(shift)))
    fields = ['suite', 'dim', 'host', 'wave', 'n_cells', 'rho_step',
              'theta_align', 'eta_elite', 'kappa_crowd', 'nu_novel',
              'intervention_rate', 'identity_share', 'mean_relative_shift']
    with open(TAB / 'mechanism_by_host.csv', 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print('[grid] mechanism_by_host.csv:', len(rows), 'rows')


def main():
    cells = _load_finished()
    if not cells:
        print('[grid] no finished cells')
        return
    ref = _reference(cells)
    _write_cells(cells, ref)
    _write_matrices(cells, ref)
    _write_mechanism(cells)


if __name__ == '__main__':
    main()

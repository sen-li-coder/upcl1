"""绘制 intercept 场景的三维地形图 + 目标函数二维切片响应面。

用法（自项目根目录运行）：
    python src/plot_scenario.py                 # 默认出图 5-2 四联图
    python src/plot_scenario.py --layout single # 旧的每任务单张曲面

输出：
    src/figures/fig_intercept_terrain_3d.png       图 5-1 场景三维地形（仿真建模背景）
    results/apps/figures/fig_landscape_3d.png      图 5-2 F1–F4 函数景观四联图（英文版）
    results/apps/figures/fig_landscape_3d_zh.png   同上，面板标签为中文（中文版论文用）
                                                   （扫 x1/x2 ∈ [-1,1]^2，其余 28 维固定
                                                   为该任务 NL-SHADE-RSP 优化所得较优解；
                                                   每面板自带 z 轴，故只比形态不比高度）
    src/figures/fig_landscape_3d_F{fid}_e{elev}.png  --layout single 时各任务单张曲面
"""
import math
import os
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import de_hosts                            # noqa: E402
import de_hosts_cec as DHC                 # noqa: E402
from uav_adversarial import get_uav_problem, _intercept_terrain  # noqa: E402

DHC.register()                             # 把 EXTRA_HOSTS/WAVE4_HOSTS 并入 de_hosts.HOST_REGISTRY

OUT = Path(__file__).resolve().parent / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
# 图 5-2 直接写进 paper_figures.SOURCE_DIR 认的那个目录（uav_* 系列都在 APP_FIG），
# `python src/paper_figures.py sync` 再把它拷进 docs/figures。
APP_FIG = ROOT / 'results' / 'apps' / 'figures'

SEED = 20240_000
MAP_W = MAP_H = 1000.0
HOST_NAME = 'NL-SHADE-RSP'     # 固定其余维所用的宿主（项目内 bare 排名第一）
OPT_EVALS = 12_000


def build_terrain():
    return _intercept_terrain(MAP_W, MAP_H, 220.0, seed=SEED)


# 与 webapp 三维沙盒一致的「真实仿真环境」高程分层设色（绿→黄绿→黄棕→棕→灰→白）
_HYPSO_STOPS = [
    (0.00, (0.22, 0.48, 0.22)), (0.12, (0.35, 0.58, 0.24)),
    (0.30, (0.52, 0.66, 0.28)), (0.48, (0.72, 0.72, 0.36)),
    (0.62, (0.78, 0.60, 0.35)), (0.75, (0.66, 0.46, 0.30)),
    (0.86, (0.52, 0.36, 0.28)), (0.93, (0.66, 0.62, 0.58)),
    (0.98, (0.88, 0.88, 0.90)), (1.00, (1.00, 1.00, 1.00)),
]


def _hypsometric_rgb(h01):
    """DEM 高程分层设色：绿(谷底)→黄绿→黄棕→棕→灰→白(雪顶)。"""
    xs = np.array([s[0] for s in _HYPSO_STOPS])
    ch = np.array([s[1] for s in _HYPSO_STOPS])
    h = np.clip(np.asarray(h01, dtype=float), 0.0, 1.0)
    return np.stack([np.interp(h, xs, ch[:, k]) for k in range(3)], axis=-1)


def _hillshade(Z, cell_x, cell_y):
    """太阳方向日照阴影（与 webapp 沙盒 sun=(60,90,40) 一致），返回 [0.2, 1.0] 亮度。"""
    gy, gx = np.gradient(Z, cell_y, cell_x)
    nx_ = -gx
    ny_ = np.ones_like(Z)
    nz_ = -gy
    inv = 1.0 / np.sqrt(nx_ * nx_ + ny_ * ny_ + nz_ * nz_)
    sl = math.sqrt(60.0 ** 2 + 90.0 ** 2 + 40.0 ** 2)
    sx, sy, sz = 60.0 / sl, 90.0 / sl, 40.0 / sl
    hs = nx_ * sx + ny_ * sy + nz_ * sz
    hs = np.clip(hs, -1.0, 1.0)
    return 0.60 + 0.40 * hs


def fig_terrain():
    """图 5-1：真实三维仿真环境——合成山地（分层设色 + 日照阴影）+ 关键实体。"""
    T = build_terrain()
    X, Y = np.meshgrid(T.xs, T.ys)
    Z = T.Z
    cell_x = float(T.xs[1] - T.xs[0])
    cell_y = float(T.ys[1] - T.ys[0])
    zmin, zmax = float(Z.min()), float(Z.max())

    rgb = _hypsometric_rgb((Z - zmin) / (zmax - zmin))
    rgb = np.clip(rgb * _hillshade(Z, cell_x, cell_y)[..., None], 0.0, 1.0)
    rgba = np.dstack([rgb, np.ones(rgb.shape[:2])])

    SKY = '#cfe6f7'
    fig = plt.figure(figsize=(10.0, 7.5))
    fig.patch.set_facecolor(SKY)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor(SKY)
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.set_facecolor(SKY)
        pane.set_edgecolor('none')
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis._axinfo['grid'].update(color='white', linewidth=0.5, alpha=0.45)

    ax.plot_surface(X, Y, Z, facecolors=rgba, rstride=1, cstride=1,
                    linewidth=0, antialiased=True, shade=False)

    def h(x, y):
        return T.height(x, y) + 6.0

    # 突防任务示意路径（起点 → 军事基地，贴地起伏）
    t = np.linspace(0.0, 1.0, 80)
    px = 60.0 + (820.0 - 60.0) * t
    py = 60.0 + (820.0 - 60.0) * t
    pz = np.array([T.height(float(px[i]), float(py[i])) + 40.0
                   for i in range(len(t))])
    ax.plot(px, py, pz, color='#1f77b4', lw=1.4, ls=(0, (4, 3)),
            alpha=0.55, zorder=10)

    ax.scatter([60], [60], [h(60, 60)], c='#1f77b4', s=120, depthshade=True,
               edgecolors='white', linewidths=0.6,
               label='UAV start (60, 60)')
    ax.scatter([820], [820], [h(820, 820)], c='#d62728', s=140, depthshade=True,
               marker='^', edgecolors='white', linewidths=0.6,
               label='Military base (820, 820)')
    ax.scatter([500], [500], [h(500, 500)], c='#ff7f0e', s=100, depthshade=True,
               marker='*', edgecolors='white', linewidths=0.6,
               label='Radar (500, 500)')
    ax.scatter([950], [50], [h(950, 50)], c='#2ca02c', s=90, depthshade=True,
               marker='s', edgecolors='white', linewidths=0.6,
               label='Interceptor apron (950, 50)')
    ax.scatter([820, 780], [820, 720], [h(820, 820), h(780, 720)],
               c='#9467bd', s=70, marker='D', depthshade=True,
               edgecolors='white', linewidths=0.6,
               label='Air-defense vehicles')

    ax.set_xlabel('x (m)', fontsize=9)
    ax.set_ylabel('y (m)', fontsize=9)
    ax.set_zlabel('Elevation z (m)', fontsize=9)
    ax.tick_params(labelsize=8)
    ax.view_init(elev=34, azim=-58)
    ax.set_box_aspect((1.0, 1.0, 0.62))
    leg = ax.legend(loc='upper left', fontsize=8, framealpha=0.85,
                    facecolor='white', edgecolor='#cccccc')
    leg.set_zorder(20)

    cmap = matplotlib.colors.LinearSegmentedColormap.from_list(
        'hypsometric', _HYPSO_STOPS)
    sm = plt.cm.ScalarMappable(norm=plt.Normalize(zmin, zmax), cmap=cmap)
    sm.set_array([])
    cb = fig.colorbar(sm, ax=ax, shrink=0.5, aspect=12, pad=0.02,
                      label='Terrain elevation (m)')
    cb.ax.tick_params(labelsize=8)
    cb.outline.set_linewidth(0.6)

    fig.tight_layout()
    fig.savefig(OUT / 'fig_intercept_terrain_3d.png', dpi=200,
                bbox_inches='tight', facecolor=SKY)
    plt.close(fig)
    print(f'[plot] terrain -> {OUT / "fig_intercept_terrain_3d.png"}')


_GOOD_SOLUTION = {}


def find_good_solution(prob):
    """用项目内最优宿主（NL-SHADE-RSP）优化一次，返回 (best_x, best_f)。

    供图 5-2 把其余 28 维固定到「已找到的较优解」，使曲面更贴近最优附近。
    按 (scenario, fid) 分别缓存，避免不同任务复用同一个解。
    """
    global _GOOD_SOLUTION
    key = (getattr(prob, 'scenario', ''), getattr(prob, 'fid', 0))
    if key in _GOOD_SOLUTION:
        return _GOOD_SOLUTION[key]
    host_name = 'NL-SHADE-RSP'
    pop = DHC.pop_size_for(host_name, prob.dim)
    host = de_hosts.get_host(host_name, prob.dim, prob.lb, prob.ub,
                             seed=SEED, pop_size=pop)
    t0 = time.time()
    best_f, best_x, conv, evals = host.run(prob, max_evals=12_000)
    best_x = np.asarray(best_x, dtype=float)
    _GOOD_SOLUTION[key] = (best_x, best_f)
    print(f'[plot] {host_name} D={prob.dim}: best f={best_f:.2f} '
          f'in {time.time() - t0:.1f}s ({int(evals[-1])} evals)')
    return _GOOD_SOLUTION[key]


def _render_landscape(Xg, Yg, C, elev, fid):
    """渲染一张 f(x) 三维曲面图（透明背景 + 指定仰角）。"""
    fig = plt.figure(figsize=(9.5, 7.5))
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor('none')
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.set_fill(False)          # 关闭 pane 填充 -> 透明背景
        pane.set_edgecolor('none')
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis._axinfo['grid'].update(color='#bbbbbb', linewidth=0.4, alpha=0.6)

    surf = ax.plot_surface(Xg, Yg, C, cmap='viridis', linewidth=0,
                           antialiased=True, rstride=1, cstride=1, alpha=1.0)
    ax.set_xlabel('x1', fontsize=9)
    ax.set_ylabel('x2', fontsize=9)
    ax.set_zlabel('f(x)', fontsize=9)
    ax.tick_params(labelsize=8)
    ax.set_title(f'3-D function landscape of f(x), F{fid} (D=30)\n'
                 '(x1, x2 swept over [-1,1]^2; other 28 dims fixed to a '
                 'near-optimal solution)', fontsize=10)
    ax.view_init(elev=elev, azim=-65)
    fig.colorbar(surf, shrink=0.55, aspect=12, pad=0.02, label='f(x)')
    fig.tight_layout()
    out = OUT / f'fig_landscape_3d_F{fid}_e{elev}.png'
    fig.savefig(out, dpi=200, bbox_inches='tight', transparent=True)
    plt.close(fig)
    print(f'[plot] landscape-3d F{fid} elev={elev} -> {out.name}')


def fig_landscape_3d(fid=1, elevs=(30,)):
    """目标函数 f(x) 的三维函数图（某一任务 fid，若干仰角）。

    扫编码空间前两维 (x1, x2) ∈ [-1,1]^2，其余 28 维固定为「已找到的较优解」。
    """
    prob = get_uav_problem('intercept', fid=fid, seed=SEED)
    env = prob.env
    base, base_f = find_good_solution(prob)

    t0 = time.time()
    env.cost(base)
    dt = max(time.time() - t0, 1e-3)
    grid = 96  # 固定细粒度，四任务曲面一致可比
    print(f'[plot] single cost {dt * 1e3:.1f} ms -> grid {grid}x{grid}')

    xs = np.linspace(-1.0, 1.0, grid)
    C = np.zeros((grid, grid))
    for i in range(grid):       # 行 -> x2
        for j in range(grid):   # 列 -> x1
            x = base.copy()
            x[0] = xs[j]
            x[1] = xs[i]
            C[i, j] = env.cost(x)

    Xg, Yg = np.meshgrid(xs, xs)

    for elev in elevs:
        _render_landscape(Xg, Yg, C, elev, fid)
    print(f'[plot] landscape-3d F{fid} sampled (base f={base_f:.1f}, '
          f'min {C.min():.1f}, max {C.max():.1f})')


_LAND_CTX = {}


def _landscape_prob(fid):
    """worker 内自建问题实例（spawn 子进程不继承父进程的缓存）。"""
    return get_uav_problem('intercept', fid=fid, seed=SEED)


def _landscape_opt(fid):
    """worker：优化一个任务，返回 (fid, 近优解)。"""
    prob = _landscape_prob(fid)
    pop = DHC.pop_size_for(HOST_NAME, prob.dim)
    host = de_hosts.get_host(HOST_NAME, prob.dim, prob.lb, prob.ub,
                             seed=SEED, pop_size=pop)
    t0 = time.time()
    best_f, best_x, _conv, evals = host.run(prob, max_evals=OPT_EVALS)
    print(f'[plot] panel F{fid}: {HOST_NAME} best f={best_f:.2f} '
          f'in {time.time() - t0:.1f}s ({int(evals[-1])} evals)', flush=True)
    return fid, np.asarray(best_x, dtype=float)


def _landscape_row(job):
    """worker：采样网格的一行（行 -> x2，列 -> x1）。"""
    fid, base, i, grid = job
    if _LAND_CTX.get('fid') != fid:          # 每个 worker 懒建实例并缓存
        prob = _landscape_prob(fid)
        b = np.asarray(base, dtype=float)
        prob.env.cost(b)                     # 预热，摊掉首次调用的开销
        _LAND_CTX.clear()
        _LAND_CTX.update(fid=fid, prob=prob, base=b)
    prob, b = _LAND_CTX['prob'], _LAND_CTX['base']
    xs = np.linspace(-1.0, 1.0, grid)
    x = b.copy()
    x[1] = xs[i]
    row = np.empty(grid)
    for j in range(grid):
        x[0] = xs[j]
        row[j] = prob.env.cost(x)
    return fid, i, row


# 四个 3D 轴框（左, 下, 宽, 高）。面板标题画在轴内左上角，上排的 x 轴刻度就不会
# 撞到下排标题；四周留白靠渲染后按 alpha 通道裁掉（bbox_inches='tight' 对 3D 轴
# 不可靠，会把标题一起裁掉）。
_PANEL_RECTS = [(0.005, 0.545, 0.485, 0.430), (0.485, 0.545, 0.485, 0.430),
                (0.005, 0.055, 0.485, 0.420), (0.485, 0.055, 0.485, 0.420)]
# 面板标签按语种给：中文沿用正文/表 46 的叫法（基线 / 受限空域 / 协同拦截 / 复合难度），
# 英文沿用正文的 baseline / restricted airspace / coordinated interception /
# compound difficulty。两版只有这几个词不同，几何、配色、视角完全一致。
_PANEL_LABEL = {
    'en': {1: 'baseline', 2: 'restricted airspace',
           3: 'coordinated interception', 4: 'compound difficulty'},
    'zh': {1: '基线', 2: '受限空域', 3: '协同拦截', 4: '复合难度'},
}
_LANDSCAPE_NAME = {'en': 'fig_landscape_3d.png', 'zh': 'fig_landscape_3d_zh.png'}

# 中文版需要的 CJK 字体（按可用性依次尝试）；找不到时只警告，不中断出图。
_CJK_FONTS = ('Microsoft YaHei', 'SimHei', 'SimSun', 'Noto Sans CJK SC',
              'Source Han Sans SC', 'WenQuanYi Zen Hei')


def _cjk_font():
    """本机可用的第一个中文字体，没有则返回 None。"""
    from matplotlib import font_manager
    have = {f.name for f in font_manager.fontManager.ttflist}
    for name in _CJK_FONTS:
        if name in have:
            return name
    return None


def _render_landscape_panel(xs, C, out, elev=20, azim=-62, zoom=1.25,
                            figsize=(6.9, 5.9), dpi=300, lang='en'):
    """渲染 2x2 四联图：每个面板独立 z 轴与配色，透明背景，裁掉外圈留白。"""
    cjk = None
    if lang == 'zh':
        cjk = _cjk_font()
        if cjk is None:
            print('[plot] WARNING 找不到中文字体，中文面板标签可能显示为空框',
                  flush=True)
        else:
            print(f'[plot] zh 面板标签使用字体 {cjk}', flush=True)
    saved = {k: plt.rcParams[k] for k in
             ('font.family', 'font.sans-serif', 'axes.unicode_minus')}
    if cjk:
        plt.rcParams['font.family'] = 'sans-serif'
        plt.rcParams['font.sans-serif'] = [cjk, 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
    try:
        Xg, Yg = np.meshgrid(xs, xs)
        fig = plt.figure(figsize=figsize)
        for k, fid in enumerate(sorted(C)):
            ax = fig.add_axes(_PANEL_RECTS[k], projection='3d')
            ax.set_facecolor('none')
            for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
                pane.set_fill(False)         # 关闭 pane 填充 -> 透明背景
                pane.set_edgecolor('none')
            for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
                axis._axinfo['grid'].update(color='#cccccc', linewidth=0.35,
                                            alpha=0.55)
            c = C[fid]
            lo, hi = float(np.nanmin(c)), float(np.nanmax(c))
            ax.plot_surface(Xg, Yg, c, cmap='viridis', linewidth=0,
                            antialiased=True, rstride=1, cstride=1,
                            norm=plt.Normalize(lo, hi))
            ax.set_zlim(lo, hi)
            ax.set_xlabel('$x_1$', fontsize=7.0, labelpad=-7)
            ax.set_ylabel('$x_2$', fontsize=7.0, labelpad=-7)
            ax.set_zlabel('$f(x)$', fontsize=7.0, labelpad=-8)
            ax.tick_params(labelsize=6.0, pad=-2.5)
            label = _PANEL_LABEL.get(lang, _PANEL_LABEL['en'])
            ax.text2D(0.02, 0.96, '(%s) F%d $\\cdot$ %s'
                      % ('abcd'[k], fid, label.get(fid, '')),
                      transform=ax.transAxes, fontsize=7.5, ha='left', va='top')
            ax.view_init(elev=elev, azim=azim)
            ax.set_box_aspect((1.0, 1.0, 0.78), zoom=zoom)

        raw = out.with_name(out.stem + '_raw.png')
        fig.savefig(raw, dpi=dpi, transparent=True)
        plt.close(fig)
    finally:
        plt.rcParams.update(saved)

    im = Image.open(raw).convert('RGBA')
    box = im.split()[3].getbbox()            # 非透明区域 = 实际画面
    w, h = im.size
    pad = 6
    im = im.crop((max(0, box[0] - pad), max(0, box[1] - pad),
                  min(w, box[2] + pad), min(h, box[3] + pad)))
    im.save(out)
    raw.unlink()
    print(f'[plot] panel ({lang}) -> {out.name} {im.size[0]}x{im.size[1]}',
          flush=True)


def fig_landscape_panel(fids=(1, 2, 3, 4), grid=96, procs=None,
                        elev=20, azim=-62, dpi=300, langs=('en', 'zh')):
    """图 5-2（定稿）：F1–F4 四个任务的 f(x) 函数景观拼成一张 2x2 四联图。

    口径与 :func:`fig_landscape_3d` 相同（扫 x1,x2 ∈ [-1,1]^2，其余 28 维固定在
    该任务 NL-SHADE-RSP 12k evals 的较优解上），差别有三点：

    * 四个任务并行（优化 4 个进程、采样 ``procs`` 个进程），96x96 全量约 1 分钟；
    * 交付一张四联图（论文按 6.30 in 宽入文），每面板自带 z 轴刻度——四任务的
      极值差一个量级，共用一条色标会把低者压成平板，故这里只比形态不比高度；
    * 面板标题写在轴内左上角，上排的 x 轴刻度不会与下排标题相撞。

    采样只做一次，按 ``langs`` 各渲染一张（``en`` -> ``fig_landscape_3d.png``，
    ``zh`` -> ``fig_landscape_3d_zh.png``）：中文版论文嵌中文面板标签的那张，
    英文版嵌英文那张，两版数据与几何逐点相同。
    """
    fids = list(fids)
    procs = procs or min(18, os.cpu_count() or 8)
    t_all = time.time()

    print(f'[plot] panel: {HOST_NAME} {OPT_EVALS} evals x {len(fids)} tasks',
          flush=True)
    with Pool(min(len(fids), procs)) as pool:
        bases = dict(pool.map(_landscape_opt, fids))

    jobs = [(fid, bases[fid], i, grid) for fid in fids for i in range(grid)]
    Z = {fid: np.zeros((grid, grid)) for fid in fids}
    done = 0
    with Pool(procs) as pool:
        for fid, i, row in pool.imap_unordered(_landscape_row, jobs,
                                               chunksize=1):
            Z[fid][i] = row
            done += 1
            if done % 96 == 0:
                print(f'[plot] panel sample {done}/{len(jobs)} rows '
                      f'({time.time() - t_all:.0f}s)', flush=True)

    xs = np.linspace(-1.0, 1.0, grid)
    C = {fid: np.where(np.isfinite(Z[fid]), Z[fid], np.nan) for fid in fids}
    for fid in fids:
        c = C[fid]
        print(f'[plot] panel F{fid}: min={np.nanmin(c):.1f} '
              f'max={np.nanmax(c):.1f} mean={np.nanmean(c):.1f}', flush=True)

    APP_FIG.mkdir(parents=True, exist_ok=True)
    for lang in langs:
        out = APP_FIG / _LANDSCAPE_NAME.get(lang, _LANDSCAPE_NAME['en'])
        _render_landscape_panel(xs, C, out, elev=elev, azim=azim, dpi=dpi,
                                lang=lang)
    print(f'[plot] panel -> {APP_FIG}  ({time.time() - t_all:.0f}s total)',
          flush=True)


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--layout', choices=['panel', 'single'], default='panel',
                    help='panel=F1-F4 四联图（定稿）；single=旧的每任务单张')
    ap.add_argument('--fids', nargs='+', type=int, default=[1, 2, 3, 4],
                    help='intercept 任务编号（默认 1-4）')
    ap.add_argument('--grid', type=int, default=96, help='扫描网格边长（默认 96）')
    ap.add_argument('--procs', type=int, default=min(18, os.cpu_count() or 8),
                    help='并行进程数')
    ap.add_argument('--elevs', nargs='+', type=int, default=[30],
                    help='--layout single 的仰角（默认 30）')
    ap.add_argument('--skip-terrain', action='store_true', help='跳过地形图')
    ap.add_argument('--lang', choices=['both', 'en', 'zh'], default='both',
                    help='panel 版式出哪一版（默认中英各一张）')
    args = ap.parse_args()
    if not args.skip_terrain:
        fig_terrain()
    if args.layout == 'panel':
        langs = ('en', 'zh') if args.lang == 'both' else (args.lang,)
        fig_landscape_panel(fids=args.fids, grid=args.grid, procs=args.procs,
                            langs=langs)
    else:
        for fid in args.fids:
            fig_landscape_3d(fid=fid, elevs=args.elevs)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Grid 进度循环监控：进度变化即写一行，并定时补一条心跳，同时输出 CSV。

复用 ``monitor_run.py`` 的 run-log 定位与解析逻辑。

- 事件驱动：done 增加时立即写一行，便于看到每个 cell 完成。
- 心跳兜底：即使进度不变，每 ``--interval`` 秒也补一条心跳行。
- CSV：同步输出 ``timestamp,done,total,pct``，便于后续画进度图。

Usage:
    python src/watch_progress.py                 # 默认：轮询 20s，心跳 600s
    python src/watch_progress.py --interval 300  # 心跳间隔(秒)
    python src/watch_progress.py --poll 10       # 轮询间隔(秒)
    python src/watch_progress.py --log-file <f>  # 指定要监控的 run log
    python src/watch_progress.py --out <p>       # 进度 log 输出路径
    python src/watch_progress.py --csv <p>       # CSV 输出路径

进度 log 默认 ``results/grid/progress.log``，CSV 默认
``results/grid/progress.csv``。每行形如::

    [09-21 15:04:05]  123/240  [##########----------]  51.2%
"""
import argparse
import csv
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import monitor_run as MON  # noqa: E402

DEFAULT_OUT = MON.ROOT / "results" / "grid" / "progress.log"
DEFAULT_CSV = MON.ROOT / "results" / "grid" / "progress.csv"


def format_line(total, done, width=22):
    now = datetime.now().strftime("%m-%d %H:%M:%S")
    if not total:
        return f"[{now}] (no run log / no progress yet)"
    pct = 100.0 * done / total
    fill = int(width * done / total)
    bar = "#" * fill + "-" * (width - fill)
    return f"[{now}] {done:4d}/{total:<4d} [{bar}] {pct:5.1f}%"


def snapshot(log_path):
    info = MON.parse_log(log_path)
    return info.get("total"), info.get("done")


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--interval", type=int, default=600,
                    help="心跳间隔(秒)，进度不变时也写一行 (默认 600)")
    ap.add_argument("--poll", type=int, default=20,
                    help="轮询间隔(秒)，检测进度变化 (默认 20)")
    ap.add_argument("--log-file", type=str, default=None,
                    help="要监控的 run log (默认自动定位最新)")
    ap.add_argument("--out", type=str, default=str(DEFAULT_OUT),
                    help="进度 log 输出路径")
    ap.add_argument("--csv", type=str, default=str(DEFAULT_CSV),
                    help="CSV 输出路径")
    a = ap.parse_args()

    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    csv_path = Path(a.csv)
    csv_path.parent.mkdir(parents=True, exist_ok=True)

    if not csv_path.exists() or csv_path.stat().st_size == 0:
        with open(csv_path, "a", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerow(["timestamp", "done", "total", "pct"])

    last_done = None
    last_heartbeat = time.time()

    def emit(log_path, total, done):
        nonlocal last_done, last_heartbeat
        now = datetime.now()
        last_heartbeat = time.time()
        line = format_line(total, done)
        print(line, flush=True)
        with open(out, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
        if total:
            with open(csv_path, "a", newline="", encoding="utf-8") as fh:
                csv.writer(fh).writerow([
                    now.strftime("%Y-%m-%d %H:%M:%S"),
                    done, total, round(100.0 * done / total, 2)])
        last_done = done

    try:
        # 启动即写一条初始进度，便于确认脚本已运行
        log_path = Path(a.log_file) if a.log_file else MON.find_active_log()
        total, done = snapshot(log_path)
        emit(log_path, total, done)

        while True:
            log_path = Path(a.log_file) if a.log_file else MON.find_active_log()
            total, done = snapshot(log_path)
            if done != last_done or (time.time() - last_heartbeat) >= a.interval:
                emit(log_path, total, done)
            time.sleep(a.poll)
    except KeyboardInterrupt:
        print("stopped.", flush=True)


if __name__ == "__main__":
    main()

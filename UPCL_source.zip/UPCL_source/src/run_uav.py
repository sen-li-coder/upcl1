"""UAV 应用场景批量 runner —— 复用 ``run_upcl_cec.run_arm``。

与 CEC 基准不同，UAV 场景无官方 ``f_opt``、无 estimate/calibrate，任务生成
更简单：``hosts × 任务 id × runs × arms``。落盘到 ``results/apps/raw/``，
JSON schema 与 CEC 完全一致（方便分析层复用）。

用法示例
--------
    # smoke：4 个宿主、任务 1~2、各 2 runs、裸 DE（串行，最快验证）
    python src/run_uav.py --hosts DE/rand/1 SHADE --fids 1 2 --runs 2 --no-upcl

    # 全量 30 宿主 × 4 任务 × 5 runs，bare+upcl 配对
    python src/run_uav.py --runs 5
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import de_hosts_cec as DHC                                  # noqa: E402
import run_upcl_cec as RUC                                  # noqa: E402
from uav_adversarial import (SCENARIO_DIMS, SCENARIO_NFUNCS,  # noqa: E402
                             get_uav_problem, list_scenarios)
from opponents import (DIFFICULTIES, DRL_ALGOS, is_drl_difficulty,  # noqa: E402
                       make_opponent, train_opponent)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'apps'
FES_MULT = 10_000          # 预算 = FES_MULT * D（UAV 毫秒级，可下调加速演示）
SEED_BASE = 20240_000
_PROGRESS_QUEUE = None
_PROGRESS_INTERVAL = 2.0


def result_path(task):
    out = Path(task.get('out_dir', OUT))
    return (out / 'raw' / f"uav_{task['scenario']}" / f"D{task['dim']}"
            / f"{task['host'].replace('/', '-')}__F{task['fid']}.json")


def seed_for(task, run):
    return (task.get('seed_base', SEED_BASE) + task['dim'] * 1_000_003
            + run * 7919 + task['fid'] * 31)


def protocol_for(task):
    return dict(code_stack=task.get('code_stack', 'current'),
                seed_base=task.get('seed_base', SEED_BASE),
                difficulty=task.get('difficulty', 'L1'),
                drl_algo=task.get('drl_algo', 'es'))


def load_existing(task):
    """Validate before resuming; never silently replace incompatible results."""
    path = result_path(task)
    if task.get('force') or not path.exists():
        return {}
    data = json.loads(path.read_text(encoding='utf-8'))
    expected = dict(suite=f"uav_{task['scenario']}", dim=task['dim'],
                    host=task['host'], fid=task['fid'],
                    max_evals=task['fes_mult'] * task['dim'],
                    arms=[a for a, _ in task['arms']])
    for key, value in expected.items():
        if data.get(key) != value:
            raise ValueError(f'{path}: {key}={data.get(key)!r}, expected {value!r}')
    if 'protocol' in data and data['protocol'] != protocol_for(task):
        raise ValueError(f'{path}: experiment protocol differs')
    records = {}
    for entry in data.get('runs', []):
        rid = entry.get('run') if isinstance(entry, dict) else None
        if (type(rid) is not int or rid < 0 or rid in records
                or entry.get('seed') != seed_for(task, rid)
                or not all(isinstance(entry.get(a), dict) for a in expected['arms'])):
            raise ValueError(f'{path}: invalid/duplicate/incomplete run {rid!r}')
        for arm in expected['arms']:
            rec = entry[arm]
            if (rec.get('seed') != seed_for(task, rid)
                    or rec.get('max_evals') != expected['max_evals']):
                raise ValueError(f'{path}: incompatible seed/budget in run {rid} {arm}')
        records[rid] = entry
    if data.get('runs_complete') != len(records):
        raise ValueError(f'{path}: runs_complete does not match saved runs')
    return records


def _init_progress(queue, interval):
    global _PROGRESS_QUEUE, _PROGRESS_INTERVAL
    _PROGRESS_QUEUE, _PROGRESS_INTERVAL = queue, interval


def _emit(task, kind, **fields):
    if _PROGRESS_QUEUE is not None:
        _PROGRESS_QUEUE.put(dict(key=(task['host'], task['fid']), kind=kind,
                                 **fields))


def _make_problem(task):
    if task.get('code_stack') == 'legacy-20261011':
        # Package-qualified import keeps all three frozen modules together.
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        legacy = importlib.import_module('legacy.uav_20261011.uav_adversarial')
        return legacy.get_uav_problem(task['scenario'], dim=task['dim'],
                                      fid=task['fid'], seed=task.get('seed_base', SEED_BASE))
    difficulty = task.get('difficulty', 'L1')
    seed = task.get('seed_base', SEED_BASE)
    algo = task.get('drl_algo', 'es')
    opp = make_opponent(difficulty, drl_algo=algo, seed=seed)
    func = get_uav_problem(task['scenario'], dim=task['dim'], fid=task['fid'],
                           seed=seed, opponent=opp)
    if is_drl_difficulty(difficulty):
        train_opponent(func.env, difficulty, algo, seed=seed)
    return func


def build_tasks(scenario, dim, hosts, fids, runs, arms, fes_mult,
                difficulty='L1', drl_algo='es'):
    tasks = []
    for h in hosts:
        for fid in fids:
            tasks.append(dict(scenario=scenario, dim=dim, host=h, fid=fid,
                              runs=runs, arms=arms, fes_mult=fes_mult,
                              difficulty=difficulty, drl_algo=drl_algo))
    return tasks


def run_task(task):
    """与 ``run_upcl_cec.run_task`` 同构：cell 级 resume + run 级 flush。

    问题来自 UAV 工厂，落盘目录为 ``results/apps/``。
    """
    scenario = task['scenario']
    dim, host_name, fid = task['dim'], task['host'], task['fid']
    runs, arms, fes_mult = task['runs'], task['arms'], task['fes_mult']
    max_evals = fes_mult * dim
    suite = f'uav_{scenario}'
    out_file = result_path(task)
    arm_names = [a for a, _ in arms]

    def _flush(per_run):
        ordered = sorted(per_run, key=lambda e: e.get('run', 0))
        payload = {
            'schema': 1,
            'suite': suite, 'dim': dim, 'host': host_name, 'fid': fid,
            'func': func.name, 'category': func.category,
            'max_evals': int(max_evals), 'runs_complete': len(ordered),
            'arms': arm_names, 'runs': ordered,
            'protocol': protocol_for(task),
        }
        tmp = out_file.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh)
        # Windows antivirus/indexers can briefly hold the destination open.
        for attempt in range(10):
            try:
                tmp.replace(out_file)
                break
            except PermissionError:
                if attempt == 9:
                    raise
                time.sleep(0.2 * (attempt + 1))

    try:
        existing_runs = load_existing(task)
        if all(r in existing_runs for r in range(runs)):
            _emit(task, 'skip')
            return ('skip', str(out_file))
        _emit(task, 'start')
        func = _make_problem(task)
        pop_size = DHC.pop_size_for(host_name, dim)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        per_run = list(existing_runs.values())
        for r in range(runs):
            if r in existing_runs:
                continue
            seed = seed_for(task, r)
            entry = {'run': r, 'seed': seed}
            for arm_idx, (arm_label, cfg) in enumerate(arms):
                last_report = 0.0

                def progress(nevals, generation):
                    nonlocal last_report
                    now = time.monotonic()
                    if now - last_report >= _PROGRESS_INTERVAL:
                        _emit(task, 'progress', run=r, arm=arm_label,
                              arm_idx=arm_idx, nevals=nevals, generation=generation)
                        last_report = now

                _emit(task, 'progress', run=r, arm=arm_label, arm_idx=arm_idx,
                      nevals=0, generation=0)
                rec = RUC.run_arm(host_name, func, dim, seed, max_evals, cfg,
                                  pop_size=pop_size, evaluate_metrics=True,
                                  progress_cb=progress if _PROGRESS_QUEUE is not None else None)
                entry[arm_label] = rec
                _emit(task, 'progress', run=r, arm=arm_label, arm_idx=arm_idx,
                      nevals=max_evals, generation=None)
            per_run.append(entry)
            _flush(per_run)
            _emit(task, 'saved', run=r)
        _emit(task, 'done')
        return ('done', str(out_file))
    except Exception as exc:
        _emit(task, 'error', message=repr(exc))
        return ('error', f'{out_file}: {exc!r}')


def _run_serial(tasks):
    for t in tasks:
        status, path = run_task(t)
        if _PROGRESS_QUEUE is None:
            print(f'[uav] {status} {path}', flush=True)
        yield status, path


def _run_pool(tasks, workers, progress_queue=None, interval=2.0):
    import multiprocessing as mp
    ctx = mp.get_context('spawn')
    n_done = 0
    with ctx.Pool(processes=workers, initializer=_init_progress,
                  initargs=(progress_queue, interval)) as pool:
        for status, path in pool.imap_unordered(run_task, tasks, chunksize=1):
            n_done += 1
            if progress_queue is None:
                print(f'[uav] ({n_done}/{len(tasks)}) {status} {path}', flush=True)
            yield status, path
        # Let worker queue feeders flush their final saved/done events.
        pool.close()
        pool.join()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept', choices=list_scenarios())
    ap.add_argument('--dims', nargs='*', type=int, default=None)
    ap.add_argument('--hosts', nargs='*', default=None,
                    help='默认 = 全部 30 个注册宿主')
    ap.add_argument('--fids', nargs='*', type=int, default=None,
                    help='任务 id，默认 = 场景全部任务')
    ap.add_argument('--runs', type=int, default=5)
    ap.add_argument('--evals-mult', type=int, default=FES_MULT)
    ap.add_argument('--workers', type=int, default=1,
                    help='并行 worker 数（Windows spawn，验证阶段建议 1）')
    ap.add_argument('--seed', type=int, default=SEED_BASE)
    ap.add_argument('--force', action='store_true')
    ap.add_argument('--out-dir', type=Path, default=OUT,
                    help='结果根目录（默认 results/apps）')
    ap.add_argument('--code-stack', choices=['current', 'legacy-20261011'],
                    default='current', help='冻结版用于扩展现有 UAV 存档')
    ap.add_argument('--plan', action='store_true', help='仅校验并显示待补 run 数')
    ap.add_argument('--progress', action='store_true', help='显示实时进度面板')
    ap.add_argument('--progress-interval', type=float, default=2.0)
    ap.add_argument('--progress-log', type=Path, default=None)
    ap.add_argument('--plain', action='store_true', help='逐行输出，适合重定向日志')
    ap.add_argument('--no-upcl', action='store_true',
                    help='只跑 bare 宿主臂（跳过 UPCL 臂）')
    ap.add_argument('--opponent', '--difficulty', dest='difficulty',
                    default='L1', choices=DIFFICULTIES,
                    help='红方对手难度档位 L0/L1/L4/L5/L6')
    ap.add_argument('--drl-algo', default='es', choices=DRL_ALGOS,
                    help='DRL 难度（L4/L5/L6）使用的训练算法')
    args = ap.parse_args(argv)
    if min(args.runs, args.evals_mult, args.workers) <= 0 or args.progress_interval <= 0:
        ap.error('runs, evals-mult, workers and progress-interval must be positive')
    if args.dims and len(args.dims) != 1:
        ap.error('choose exactly one dimension per invocation')
    if args.code_stack == 'legacy-20261011' and args.difficulty != 'L1':
        ap.error('the frozen stack uses its built-in L1 opponent')

    arms = [('bare', None)]
    if not args.no_upcl:
        arms.append(('full', 'default'))

    scenario = args.scenario
    dim = (args.dims or [SCENARIO_DIMS[scenario]])[0]
    if dim <= 0:
        ap.error('dimension must be positive')
    hosts = args.hosts or DHC.CEC_HOST_ORDER
    fids = args.fids or list(range(1, SCENARIO_NFUNCS[scenario] + 1))
    hosts, fids = list(dict.fromkeys(hosts)), list(dict.fromkeys(fids))
    if any(h not in DHC.CEC_HOST_ORDER for h in hosts):
        ap.error('unknown host name')
    if any(f < 1 or f > SCENARIO_NFUNCS[scenario] for f in fids):
        ap.error('fid is outside this scenario')

    tasks = build_tasks(scenario, dim, hosts, fids, args.runs, arms,
                        args.evals_mult, difficulty=args.difficulty,
                        drl_algo=args.drl_algo)
    for t in tasks:
        t['seed_base'] = args.seed
        t['force'] = args.force
        t['out_dir'] = str(args.out_dir.resolve())
        t['code_stack'] = args.code_stack

    print(f'[uav] scenario={scenario} dim={dim} hosts={len(hosts)} '
          f'fids={fids} runs={args.runs} arms={[a for a, _ in arms]} '
          f'workers={args.workers} -> {len(tasks)} cells', flush=True)
    try:
        initial = {(t['host'], t['fid']): set(load_existing(t)) & set(range(args.runs))
                   for t in tasks}
    except (ValueError, OSError, TypeError, AttributeError) as exc:
        print(f'[uav] resume check failed: {exc}', file=sys.stderr, flush=True)
        return 2
    total = len(tasks) * args.runs
    saved = sum(map(len, initial.values()))
    print(f'[uav] stack={args.code_stack} budget={args.evals_mult * dim} '
          f'saved={saved}/{total} remaining={total - saved} paired runs', flush=True)
    if args.plan:
        return 0
    t0 = time.time()
    monitor = queue = None
    if args.progress:
        import multiprocessing as mp
        from uav_progress import LiveProgress
        queue = mp.get_context('spawn').Queue()
        log = args.progress_log or args.out_dir / 'logs' / 'uav_live_progress.log'
        monitor = LiveProgress(queue, tasks, initial, args.progress_interval,
                               log, plain=args.plain)
        monitor.start()
    _init_progress(queue, args.progress_interval)
    try:
        if args.workers <= 1:
            results = list(_run_serial(tasks))
        else:
            results = list(_run_pool(tasks, args.workers, queue, args.progress_interval))
    except KeyboardInterrupt:
        print('[uav] interrupted; saved paired runs will be reused on restart.', flush=True)
        return 130
    finally:
        if monitor:
            monitor.finish()
        _init_progress(None, args.progress_interval)
        if queue is not None:
            queue.close()
            queue.join_thread()

    n_done = sum(1 for s, _ in results if s == 'done')
    n_skip = sum(1 for s, _ in results if s == 'skip')
    n_err = sum(1 for s, _ in results if s == 'error')
    print(f'[uav] finished in {time.time() - t0:.1f}s: '
          f'done={n_done} skip={n_skip} error={n_err}', flush=True)
    for status, path in results:
        if status == 'error':
            print(f'[uav] ERROR {path}', file=sys.stderr, flush=True)
    return 1 if n_err else 0


if __name__ == '__main__':
    raise SystemExit(main())

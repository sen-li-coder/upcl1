# -*- coding: utf-8 -*-
"""UAV 拦截场景的「稀有事件 / 结局分辨率」分析。

背景：第五章原来的呈现只用中位数，而二值型结局（基地是否被摧毁）在
$R=3$ 下几乎恒为 0，于是「表里一片零」既不能说明算法失败，也不能说明任务
太难。本脚本把这类结局换算成可比较的量：

  1. uav_event_rates.csv   —— 每（任务, 臂）的事件发生率，附 95% Wilson
     区间：两架无人机到达 / 地面分队抵达基地 / 基地被摧毁，以及基地损伤
     进度（连续量）的中位数与均值；
  2. uav_budget_plateau.csv —— best-so-far 曲线达到自身总增益 50/90/99% 时
     已消耗的预算占比，以及最后 5% / 20% 预算带来的增量（回答"次数够不够"）；
  3. uav_power.csv          —— 在观测到的发生率下，$R$ 次运行至少观测到一次
     事件的概率，以及检出 $2\\times$ / $3\\times$ 速率差所需的每 cell 运行数。

只读 ``results/apps/raw/uav_intercept``，幂等，可反复运行。
"""
import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import uav_adversarial as UA  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'results' / 'apps'
RAW = BASE / 'raw'
TAB = BASE / 'tables'

Z95 = 1.959963985
# 基地初始血量：直接取自场景配置，避免把量纲硬编码进分析层
BASE_HP_MAX = float(UA._intercept_cfg(1).base_hp)


def wilson(k, n, z=Z95):
    """二项比例的 Wilson 置信区间（小样本下优于正态近似）。"""
    if n <= 0:
        return float('nan'), float('nan')
    p = k / n
    d = 1.0 + z * z / n
    c = p + z * z / (2 * n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (c - h) / d), min(1.0, (c + h) / d)


def load_runs(scenario='intercept'):
    """展开为一条 run 一行的记录。"""
    raw = RAW / f'uav_{scenario}'
    out = []
    for f in sorted(raw.rglob('*.json')):
        try:
            with open(f, encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        for run in d.get('runs', []):
            for arm in d.get('arms', []):
                rec = run.get(arm)
                if not isinstance(rec, dict):
                    continue
                m = rec.get('metrics') or {}
                if 'base_hp' not in m:
                    continue
                out.append({'host': d['host'], 'fid': str(d['fid']),
                            'dim': d['dim'], 'arm': arm,
                            'nevals': rec.get('nevals'),
                            'curve': rec.get('err_curve'),
                            'm': m})
    return out


def _rates(rows):
    """一组 run 的事件发生率与连续损伤量。"""
    n = len(rows)
    hp = np.array([float(r['m']['base_hp']) for r in rows], dtype=float)
    dmg = 1.0 - hp / BASE_HP_MAX
    nr = np.array([float(r['m'].get('n_arrived', 0)) for r in rows])

    def rate(pred):
        k = int(sum(1 for r in rows if pred(r)))
        lo, hi = wilson(k, n)
        return k, 100.0 * k / n, 100.0 * lo, 100.0 * hi

    air = rate(lambda r: float(r['m'].get('n_arrived', 0)) >= 2)
    gnd = rate(lambda r: float(r['m'].get('n_inf_arrived', 0)) >= 1)
    des = rate(lambda r: bool(r['m'].get('base_destroyed')))
    lost = rate(lambda r: float(r['m'].get('n_inf_lost', 0)) >= 1)

    # 模态损伤 = 仅空中打击造成的固定损伤；超出该水平的损伤是否都由
    # 地面分队抵达带来（用于说明基地血量由哪个通道决定）。
    vals, cnts = np.unique(np.round(dmg, 6), return_counts=True)
    aerial = float(vals[int(np.argmax(cnts))])
    ia = np.array([float(r['m'].get('n_inf_arrived', 0)) for r in rows])
    ex = dmg > aerial + 1e-9
    return dict(n_runs=n, air_k=air[0], air_pct=air[1], air_lo=air[2],
                air_hi=air[3], gnd_k=gnd[0], gnd_pct=gnd[1], gnd_lo=gnd[2],
                gnd_hi=gnd[3], dest_k=des[0], dest_pct=des[1], dest_lo=des[2],
                dest_hi=des[3], inf_lost_k=lost[0], inf_lost_pct=lost[1],
                dmg_med=float(np.median(dmg)), dmg_mean=float(dmg.mean()),
                aerial_dmg=aerial, extra_k=int(ex.sum()),
                extra_gnd_k=int((ex & (ia >= 1)).sum()),
                hp_med=float(np.median(hp)), air_mean_n=float(nr.mean()))


def event_rates(rows):
    """按（范围, 任务, 臂）汇总事件发生率；``both`` 为两臂合并池。"""
    out = []
    for arm in ('bare', 'full', 'both'):
        for scope, fid in ([('task', f) for f in ('1', '2', '3', '4')]
                           + [('all', 'all')]):
            sel = [r for r in rows if (arm == 'both' or r['arm'] == arm)
                   and (fid == 'all' or r['fid'] == fid)]
            if not sel:
                continue
            rec = _rates(sel)
            rec.update(scenario='intercept', dim=sel[0]['dim'], scope=scope,
                       fid=fid, arm=arm, base_hp_max=BASE_HP_MAX)
            out.append(rec)
    return out


def _first_reach(curve, frac):
    """best-so-far 第一次达到总增益 frac 比例时所处的预算占比。"""
    c = np.minimum.accumulate(np.asarray(curve, dtype=float))
    rng = c[0] - c[-1]
    if rng <= 1e-9:
        return 0.0
    idx = np.nonzero((c[0] - c) >= frac * rng)[0]
    return float(idx[0]) / (len(c) - 1) if len(idx) else 1.0


def _tail_gain(curve, frac):
    """最后 frac 比例预算带来的增益，占总增益的比例。"""
    c = np.minimum.accumulate(np.asarray(curve, dtype=float))
    rng = c[0] - c[-1]
    if rng <= 1e-9:
        return 0.0
    k = max(1, int(frac * len(c)))
    return float((c[-k - 1] - c[-1]) / rng)


def plateau(rows):
    """预算饱和证据：逐（任务, 臂）与合并范围。"""
    out = []
    for arm in ('bare', 'full'):
        for scope, fid in ([('task', f) for f in ('1', '2', '3', '4')]
                           + [('all', 'all')]):
            sel = [r for r in rows if r['arm'] == arm and r['curve']
                   and len(r['curve']) >= 10
                   and (fid == 'all' or r['fid'] == fid)]
            if not sel:
                continue
            t = {k: [float(_first_reach(r['curve'], v))
                     for r in sel] for k, v in (('t50', 0.50), ('t90', 0.90),
                                                ('t99', 0.99))}
            tail = {k: [float(_tail_gain(r['curve'], v)) for r in sel]
                    for k, v in (('tail20', 0.20), ('tail5', 0.05))}
            rec = {'scenario': 'intercept', 'scope': scope, 'fid': fid,
                   'arm': arm, 'n_runs': len(sel), 'base_hp_max': BASE_HP_MAX}
            rec.update({k: round(float(np.median(v)), 4) for k, v in
                        list(t.items()) + list(tail.items())})
            out.append(rec)
    return out


def power(rates):
    """检出所需样本量：用合并的（bare）地面抵达率做 p0。"""
    row = next(r for r in rates if r['scope'] == 'all' and r['arm'] == 'bare')
    p0 = row['gnd_pct'] / 100.0
    z_a, z_b = 1.959963985, 0.8416212336          # 双侧 0.05，功效 0.80
    out = []
    for n in (3, 6, 12, 25, 50):
        out.append({'scenario': 'intercept', 'kind': 'observe', 'p0': round(p0, 4),
                    'runs': n, 'ratio': '',
                    'value': round(1.0 - (1.0 - p0) ** n, 4),
                    'median_zero': round((1.0 - p0) ** n, 4)})
    for ratio in (2.0, 3.0):
        p1 = min(0.95, p0 * ratio)
        need = None
        for n in range(3, 601):
            pbar = (p0 + p1) / 2.0
            val = ((z_a * math.sqrt(2 * pbar * (1 - pbar))
                    + z_b * math.sqrt(p0 * (1 - p0) + p1 * (1 - p1)))
                   / (p1 - p0)) ** 2
            if n >= val:
                need = n
                break
        out.append({'scenario': 'intercept', 'kind': 'detect', 'p0': round(p0, 4),
                    'runs': need, 'ratio': ratio, 'value': round(p1, 4),
                    'median_zero': ''})
    return out


def ratio_binom(k, n):
    """用于正文的 Wald 区间（正态近似），仅作参考输出。"""
    if n <= 0:
        return float('nan')
    p = k / n
    return Z95 * math.sqrt(p * (1 - p) / n)


def _write(name, rows, fields):
    if not rows:
        print(f'[analyze_uav_events] no rows for {name}')
        return
    TAB.mkdir(parents=True, exist_ok=True)
    with open(TAB / name, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow({k: ('' if r.get(k) is None else r.get(k))
                        for k in fields})


def _console(rates, plat):
    print('\n=== 事件发生率（95% Wilson 区间）===')
    print('%-6s %-5s %5s %18s %18s %16s %10s' %
          ('task', 'arm', 'n', '两机到达', '地面抵达', '基地摧毁', '损伤中位'))
    for r in rates:
        print('%-6s %-5s %5d %8.1f%% [%4.1f,%4.1f] %8.1f%% [%4.1f,%4.1f] '
              '%7.1f%% %10.3f'
              % (r['fid'], r['arm'], r['n_runs'], r['air_pct'], r['air_lo'],
                 r['air_hi'], r['gnd_pct'], r['gnd_lo'], r['gnd_hi'],
                 r['dest_pct'], r['dmg_med']))
    print('\n=== 预算饱和（best-so-far 曲线）===')
    print('%-6s %-5s %5s %8s %8s %8s %9s %9s' %
          ('task', 'arm', 'n', 't50', 't90', 't99', 'tail20', 'tail5'))
    for r in plat:
        print('%-6s %-5s %5d %8.3f %8.3f %8.3f %9.4f %9.4f'
              % (r['fid'], r['arm'], r['n_runs'], r['t50'], r['t90'], r['t99'],
                 r['tail20'], r['tail5']))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept')
    ap.add_argument('--dims', nargs='*', type=int, default=None)
    args = ap.parse_args(argv)

    rows = load_runs(args.scenario)
    if not rows:
        print('[analyze_uav_events] no results under',
              RAW / f'uav_{args.scenario}')
        return
    if args.dims:
        rows = [r for r in rows if r['dim'] in args.dims]
    hp = max(float(r['m']['base_hp']) for r in rows)
    if hp > BASE_HP_MAX + 1e-6:
        raise SystemExit(f'[analyze_uav_events] base_hp {hp} > cfg {BASE_HP_MAX}')

    rates = event_rates(rows)
    plat = plateau(rows)
    pw = power(rates)

    rfields = ['scenario', 'dim', 'base_hp_max', 'scope', 'fid', 'arm', 'n_runs',
               'air_k', 'air_pct', 'air_lo', 'air_hi',
               'gnd_k', 'gnd_pct', 'gnd_lo', 'gnd_hi',
               'dest_k', 'dest_pct', 'dest_lo', 'dest_hi',
               'inf_lost_k', 'inf_lost_pct', 'air_mean_n',
               'hp_med', 'dmg_med', 'dmg_mean', 'aerial_dmg',
               'extra_k', 'extra_gnd_k']
    _write('uav_event_rates.csv', rates, rfields)
    _write('uav_budget_plateau.csv', plat,
           ['scenario', 'scope', 'fid', 'arm', 'n_runs', 'base_hp_max',
            't50', 't90', 't99', 'tail20', 'tail5'])
    _write('uav_power.csv', pw,
           ['scenario', 'kind', 'p0', 'runs', 'ratio', 'value', 'median_zero'])
    _console(rates, plat)
    print(f'\n[analyze_uav_events] {len(rows)} runs, base_hp_max={BASE_HP_MAX:.0f}'
          f' -> {TAB}')


if __name__ == '__main__':
    main()

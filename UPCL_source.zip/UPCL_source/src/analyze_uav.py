# -*- coding: utf-8 -*-
"""UAV 真实应用场景分析：把 metrics 汇总成"指标面板"。

读取 ``results/apps/raw/uav_*/D*/`` 下的 cell json，将每臂最优解的任务级
指标（``run_arm(evaluate_metrics=True)`` 落盘的 ``metrics``）汇总成 CSV：

  1. uav_metric_cells.csv —— 细粒度：每 (scenario,dim,host,fid,arm) 一行，逐指标 median/mean
  2. uav_upcl_delta.csv   —— bare→full 配对中位差，按指标方向归一化为 gain（>0 表示 full 更好）

指标方向：higher_better / lower_better / bool / neutral。幂等，可对部分完成的实验反复运行。
"""
import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import de_hosts_cec as DHC  # noqa: E402
import uav_scores  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'results' / 'apps'
RAW = BASE / 'raw'
TAB = BASE / 'tables'

# 指标方向（蓝方收益视角）：higher_better=越大越好；lower_better=越小越好；bool=达成率(0/1)
# composite_pct 排在最前：综合成功率是本场景的主口径，逐任务表、价值榜与机制分解都先看它
METRIC_DIRECTION = {
    'composite_pct': 'higher_better', 'damage_pct': 'higher_better',
    'breach_pct': 'higher_better', 'kill_pct': 'higher_better',
    'n_arrived': 'higher_better', 'min_dist': 'higher_better',
    'first_capture': 'higher_better', 'path_efficiency': 'higher_better',
    'n_inf_arrived': 'higher_better', 'n_patrol_killed': 'higher_better',
    'infantry_alive': 'higher_better', 'infantry_survival': 'higher_better',
    'infantry_avg_hp': 'higher_better', 'infantry_hp_total': 'higher_better',
    'base_destroyed': 'bool', 'mission_success': 'bool',
    'path_length': 'lower_better', 'flight_time': 'lower_better',
    'bounds_steps': 'lower_better', 'nofly_steps': 'lower_better',
    'n_lost': 'lower_better', 'n_crashed': 'lower_better',
    'climb': 'lower_better', 'risk_time': 'lower_better',
    'curvature': 'lower_better', 'base_hp': 'lower_better',
    'n_inf_lost': 'lower_better', 'patrol_alive': 'lower_better',
    'patrol_survival': 'lower_better', 'patrol_avg_hp': 'lower_better',
    'patrol_hp_total': 'lower_better',
}
KEY_METRICS = ['composite_pct', 'n_arrived', 'n_lost', 'path_length']


def load_cells(scenario=None, min_runs=1):
    """返回 { (suite, dim, host, fid): {'meta': {...}, 'runs': [...]} }。"""
    cells = {}
    if not RAW.exists():
        return cells
    for f in RAW.rglob('*.json'):
        try:
            with open(f, 'r', encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        if scenario and d.get('suite') != f'uav_{scenario}':
            continue
        key = (d['suite'], d['dim'], d['host'], d['fid'])
        if key in cells:
            cells[key]['runs'].extend(d['runs'])
        else:
            cells[key] = {'meta': {k: d[k] for k in
                                   ('suite', 'dim', 'host', 'fid', 'func',
                                    'category', 'max_evals', 'arms')},
                          'runs': d['runs']}
    cells = {k: c for k, c in cells.items() if len(c['runs']) >= min_runs}
    # 每个 rollout 补上三个分级完成度与综合成功率（uav_scores 只读不写原始档案）
    return uav_scores.inject(cells)


def arms_of(cell):
    return sorted({k for r in cell['runs'] for k in r
                   if k not in ('run', 'seed')})


def metric_names(cells):
    names = set()
    for c in cells.values():
        for r in c['runs']:
            for a in arms_of(c):
                m = (r.get(a) or {}).get('metrics')
                if isinstance(m, dict):
                    names |= set(m)
    ordered = [n for n in METRIC_DIRECTION if n in names]
    return ordered + sorted(names - set(ordered))


def _metric_vals(cell, arm, name):
    out = []
    for r in cell['runs']:
        rec = r.get(arm)
        if not isinstance(rec, dict):
            continue
        m = rec.get('metrics')
        if not isinstance(m, dict) or name not in m:
            continue
        v = m[name]
        if isinstance(v, bool):
            out.append(1.0 if v else 0.0)
        elif isinstance(v, (int, float)):
            out.append(float(v))
    return out


def metric_cells(cells, names):
    rows = []
    for (suite, dim, host, fid), c in sorted(cells.items()):
        for arm in arms_of(c):
            n = sum(1 for r in c['runs'] if isinstance(r.get(arm), dict))
            row = dict(scenario=suite.replace('uav_', ''), dim=dim, host=host,
                       fid=fid, arm=arm, n=n)
            for name in names:
                vals = _metric_vals(c, arm, name)
                if not vals:
                    row[f'{name}_median'] = ''
                    row[f'{name}_mean'] = ''
                    continue
                row[f'{name}_median'] = round(float(np.median(vals)), 4)
                row[f'{name}_mean'] = round(float(np.mean(vals)), 4)
            rows.append(row)
    return rows


def upcl_delta(cells, names):
    rows = []
    for (suite, dim, host, fid), c in sorted(cells.items()):
        if 'bare' not in arms_of(c) or 'full' not in arms_of(c):
            continue
        for name in names:
            b, f = _metric_vals(c, 'bare', name), _metric_vals(c, 'full', name)
            if not b or not f:
                continue
            bm, fm = float(np.median(b)), float(np.median(f))
            d = METRIC_DIRECTION.get(name, 'neutral')
            gain = fm - bm if d in ('higher_better', 'bool') else \
                (bm - fm if d == 'lower_better' else fm - bm)
            rows.append(dict(scenario=suite.replace('uav_', ''), dim=dim, host=host,
                             fid=fid, metric=name, direction=d,
                             bare_median=round(bm, 4), full_median=round(fm, 4),
                             delta=round(fm - bm, 4), gain=round(gain, 4)))
    return rows


def _write(name, rows, fields):
    if not rows:
        return
    TAB.mkdir(parents=True, exist_ok=True)
    with open(TAB / name, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _host_key(host):
    try:
        return DHC.CEC_HOST_ORDER.index(host)
    except ValueError:
        return len(DHC.CEC_HOST_ORDER)


def _console(cells, names):
    agg = defaultdict(lambda: defaultdict(list))
    for (_, _, host, _), c in cells.items():
        for name in KEY_METRICS:
            if name not in names:
                continue
            b = _metric_vals(c, 'bare', name)
            if b:
                agg[host][f'{name}_bare'].append(float(np.median(b)))
            if 'full' in arms_of(c):
                f = _metric_vals(c, 'full', name)
                if b and f:
                    d = METRIC_DIRECTION.get(name)
                    g = float(np.median(f) - np.median(b)) if d in ('higher_better', 'bool') \
                        else float(np.median(b) - np.median(f))
                    agg[host][f'{name}_gain'].append(g)
    print('\n=== UAV 指标面板（按 host 聚合，跨 cell 取均值；gain>0 = full 更好）===')
    hdr = 'host'.ljust(24)
    for n in KEY_METRICS:
        if n in names:
            hdr += f' {n:>10s}bare {n:>8s}gain'
    print(hdr)
    for host in sorted(agg, key=_host_key):
        line = host.ljust(24)
        for n in KEY_METRICS:
            b, g = agg[host].get(f'{n}_bare'), agg[host].get(f'{n}_gain')
            if b is not None:
                line += f' {np.mean(b):>10.3f}'
                line += f' {np.mean(g):>+8.3f}' if g else ' ' * 8
        print(line)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default=None, help='只分析某场景（如 intercept）')
    ap.add_argument('--dims', nargs='*', type=int, default=None)
    ap.add_argument('--hosts', nargs='*', default=None)
    ap.add_argument('--fids', nargs='*', type=int, default=None)
    ap.add_argument('--min-runs', type=int, default=1)
    args = ap.parse_args(argv)

    cells = load_cells(scenario=args.scenario, min_runs=args.min_runs)
    if not cells:
        print('[analyze_uav] no results under', RAW)
        return
    if args.dims:
        cells = {k: c for k, c in cells.items() if k[1] in args.dims}
    if args.hosts:
        cells = {k: c for k, c in cells.items() if k[2] in args.hosts}
    if args.fids:
        cells = {k: c for k, c in cells.items() if k[3] in args.fids}

    names = metric_names(cells)
    TAB.mkdir(parents=True, exist_ok=True)
    fields = ['scenario', 'dim', 'host', 'fid', 'arm', 'n']
    for n in names:
        fields += [f'{n}_median', f'{n}_mean']
    _write('uav_metric_cells.csv', metric_cells(cells, names), fields)
    _write('uav_upcl_delta.csv', upcl_delta(cells, names),
           ['scenario', 'dim', 'host', 'fid', 'metric', 'direction',
            'bare_median', 'full_median', 'delta', 'gain'])
    _console(cells, names)
    print(f'[analyze_uav] wrote {len(cells)} cells -> {TAB}')


if __name__ == '__main__':
    main()

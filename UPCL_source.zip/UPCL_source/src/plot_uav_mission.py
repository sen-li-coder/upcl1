# -*- coding: utf-8 -*-
"""§5.5 任务完成度图：综合成功率与三条分量在两臂、四个任务上的对比。

输入：``results/apps/tables/uav_mission_summary.csv``
输出：``results/apps/figures/fig_uav_mission.png``

四个面板依次为综合成功率 CSR、目标削弱率、步兵突入率、战果率，纵轴均为百分比；
柱高为跨 29 宿主的均值，误差棒为 95% CI。不做任何阈值判定。
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'
FIG = ROOT / 'results' / 'apps' / 'figures'

PANELS = [
    ('composite', '', 'composite success rate'),
    ('damage', '%', 'base weakened'),
    ('breach', '% of runs', 'ground team inside base'),
    ('kill', '% of runs', 'patrol troops killed'),
]
COLORS = {'bare': '#8fa4bd', 'full': '#c0504d'}
ARM_LABEL = {'bare': 'bare', 'full': 'UPCL'}


def _style():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 9, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 7,
        'ytick.labelsize': 7, 'legend.fontsize': 7,
        'legend.frameon': False, 'figure.dpi': 300})


def _despine(ax):
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)


def main():
    p = TAB / 'uav_mission_summary.csv'
    if not p.exists():
        raise SystemExit(f'missing table: {p}; run analyze_uav_mission.py first')
    rows = list(csv.DictReader(open(p, encoding='utf-8', newline='')))
    by = {(r['fid'], r['arm']): r for r in rows}
    fids = sorted({r['fid'] for r in rows}, key=int)

    _style()
    fig, axes = plt.subplots(1, len(PANELS), figsize=(9.3, 2.3), sharex=True)
    w = 0.36
    xs = np.arange(len(fids), dtype=float)
    for k, (ax, (key, ylab, title)) in enumerate(zip(axes, PANELS)):
        for j, arm in enumerate(('bare', 'full')):
            vals, errs = [], []
            for fid in fids:
                r = by.get((fid, arm), {})
                try:
                    vals.append(float(r.get(f'{key}_pct', 0.0)))
                    errs.append(float(r.get(f'{key}_ci', 0.0)))
                except (TypeError, ValueError):
                    vals.append(0.0)
                    errs.append(0.0)
            ax.bar(xs + (j - 0.5) * w, vals, w * 0.92, yerr=errs,
                   capsize=1.6, error_kw={'lw': 0.6, 'elinewidth': 0.6},
                   color=COLORS[arm], edgecolor='#333333', linewidth=0.4,
                   label=ARM_LABEL[arm])
        ax.set_xticks(xs)
        ax.set_xticklabels([f'F{f}' for f in fids])
        ax.set_xlim(-0.6, len(fids) - 0.4)
        ax.set_ylabel(ylab)
        top = ax.get_ylim()[1]
        ax.set_ylim(0, max(1.2, top * 1.18))
        ax.set_title('(%s) %s' % (chr(97 + k), title), loc='left',
                     fontsize=9.5, color='0.25', pad=5)
        _despine(ax)
    # the CSR panel is the weighted mean of the three panels to its right
    axes[0].set_facecolor('#f4f6f9')
    axes[0].set_ylabel('%')
    axes[0].legend(loc='upper left', ncol=1, handlelength=1.0,
                   handletextpad=0.4, borderpad=0.1)
    fig.tight_layout(w_pad=1.6)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / 'fig_uav_mission.png', bbox_inches='tight')
    plt.close(fig)
    print('[plot_uav_mission] fig_uav_mission.png %d tasks x %d panels'
          % (len(fids), len(PANELS)))


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""补齐 cec2022 D20 缺失的 UPCL(upcl) 臂到 30 runs，复用已有 bare 臂。

背景
----
results/cec/raw/cec2022/D20/ 下 30 个宿主 x 12 函数 = 360 个 cell：
  * 10 个 wave4 变体已是 bare+full（完整）；
  * 20 个旧宿主里，87 个 cell 完全没有 upcl 臂、19 个 cell 的 upcl 臂跑了一部分
    （1~29 runs，中途中断），合计 106 个 cell 需要补 upcl 臂。

本脚本**复用**每个 cell 里已落盘的 bare 臂（同 seed 配对），只补跑缺失的
upcl 臂（cfg='default'，与现有 upcl/full 臂实现完全一致），逐 run 落盘，
可随时中断后重跑续补。进度每 sync_min 分钟同步一次到 stdout（外部重定向
到 log）。

用法
----
    python -u src/fill_upcl_arm.py --dry-run          # 只列出待补清单
    python -u src/fill_upcl_arm.py --workers 19 \
        > results/cec/fill_upcl_2022d20.log 2>&1
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                     # noqa: E402
import de_hosts                                             # noqa: E402
import de_hosts_cec as DHC                                  # noqa: E402
from run_upcl_cec import run_arm                            # noqa: E402

DHC.register()

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw' / 'cec2022' / 'D20'
SUITE, DIM, RUNS = 'cec2022', 20, 30
UPCL_CFG = 'default'


def scan_cells(only=None):
    """返回需要补 UPCL 臂的 cell 任务列表。

    每个 cell 的 UPCL 臂标签按现状确定：wave4 变体是 'full'，旧宿主是
    'upcl'（或 bare-only 待补 'upcl'）。只统计缺该标签 rec 的 run。
    """
    tasks = []
    for p in sorted(RAW.glob('*.json')):
        try:
            with open(p, 'r', encoding='utf-8') as fh:
                d = json.load(fh)
        except Exception:
            continue
        host, fid = d.get('host'), d.get('fid')
        if not host or fid is None:
            continue
        if only and only not in f'{host}__F{fid}':
            continue
        arms = d.get('arms', [])
        arm_label = 'full' if 'full' in arms else 'upcl'
        by_run = {e.get('run'): e for e in d.get('runs', [])}
        missing = [r for r in range(RUNS)
                   if not isinstance(by_run.get(r, {}).get(arm_label), dict)]
        if missing:
            tasks.append({'file': str(p), 'host': host, 'fid': fid,
                          'arm_label': arm_label, 'missing': missing})
    return tasks


def fill_cell(task, active=None):
    """补一个 cell 缺的 UPCL runs，逐 run 落盘。返回 ('done', name, n)。"""
    p = Path(task['file'])
    name = f'{task["host"]}__F{task["fid"]}'
    if active is not None:
        active[name] = time.time()        # 上报：开始处理该 cell
    try:
        with open(p, 'r', encoding='utf-8') as fh:
            d = json.load(fh)
        host, fid = task['host'], task['fid']
        arm_label = task['arm_label']
        max_evals = d.get('max_evals', 200000)
        func = CS.get_function(SUITE, DIM, fid)
        by_run = {e.get('run'): e for e in d['runs']}
        arms = list(d.get('arms', []))
        if arm_label not in arms:
            arms.append(arm_label)
            d['arms'] = arms

        done = 0
        for r in task['missing']:
            e = by_run.get(r)
            if e is None or isinstance(e.get(arm_label), dict):
                continue
            rec = run_arm(host, func, DIM, e['seed'], max_evals, UPCL_CFG,
                          pop_size=None)
            e[arm_label] = rec
            done += 1
            tmp = p.with_suffix('.tmp')
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(d, fh)
            tmp.replace(p)                # 原子替换，中断只丢当前 run

        d['runs_complete'] = RUNS
        return ('done', f'{name}[{arm_label}]', done)
    finally:
        if active is not None:
            try:
                if name in active:
                    del active[name]      # 上报：结束处理该 cell
            except Exception:
                pass


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--workers', type=int,
                    default=max(1, (os.cpu_count() or 4) - 1))
    ap.add_argument('--sync-min', type=int, default=10,
                    help='进度同步间隔（分钟），默认 10')
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--only', default=None,
                    help='只处理 host__Ffid 含该子串的 cell（测试用）')
    args = ap.parse_args()

    tasks = scan_cells(args.only)
    total_runs = sum(len(t['missing']) for t in tasks)
    print(f'[fill] {len(tasks)} cells to fill, {total_runs} upcl runs total',
          flush=True)

    if args.dry_run or not tasks:
        for t in tasks:
            print(f'[fill]   {t["host"]:24s} F{t["fid"]:<3d} '
                  f'need {len(t["missing"])} runs', flush=True)
        if not tasks:
            print('[fill] nothing to do', flush=True)
        return

    state = {'done_runs': 0, 'done_cells': 0}
    lock = threading.Lock()
    stop = threading.Event()
    t0 = time.time()

    active = None
    mgr = None
    if args.workers > 1:
        mgr = mp.Manager()
        active = mgr.dict()                # 活跃 cell 名 -> 开始时间戳（跨进程）

    def progress():
        with lock:
            dr, dc = state['done_runs'], state['done_cells']
        act = list(active.keys()) if active is not None else []
        pct = dr / total_runs * 100.0 if total_runs else 0.0
        el = time.time() - t0
        if dr > 0:
            eta = el / dr * (total_runs - dr)
            eta_s = f'{eta/60:.1f} min'
        else:
            eta_s = '--'
        line = (f'[fill] {dc}/{len(tasks)} cells  {dr}/{total_runs} runs '
                f'({pct:.2f}%)  elapsed {el/60:.1f} min  eta {eta_s}')
        if act:
            shown = ', '.join(act[:6])
            line += f'  | active({len(act)}): {shown}'
            if len(act) > 6:
                line += f' ...+{len(act)-6}'
        return line

    def progress_loop():
        print(progress(), flush=True)                    # 启动即打印 0% 基线
        while not stop.wait(args.sync_min * 60):
            print(progress(), flush=True)

    threading.Thread(target=progress_loop, daemon=True).start()

    def record(res):
        if res[0] != 'done':
            return
        _, name, n = res
        with lock:
            state['done_runs'] += n
            state['done_cells'] += 1
        print(f'[fill-done] {name} +{n}  ({progress()})', flush=True)

    if args.workers <= 1:
        for t in tasks:
            record(fill_cell(t, None))
    else:
        pool = mp.Pool(processes=args.workers)
        try:
            pending = [pool.apply_async(fill_cell, (t, active)) for t in tasks]
            for r in pending:
                record(r.get())
        finally:
            pool.close()
            pool.join()

    stop.set()
    print('[fill] finished: ' + progress(), flush=True)
    if mgr is not None:
        mgr.shutdown()


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""R=3 -> R=6 子集验证：同一批 cell 在 n=3 与 n=6 下的结局可观测性对比。

做法：把已完成的 run 按 ``run id`` 截断成前 3 个 / 前 6 个，分别用与
``analyze_uav_events`` 完全相同的口径（Wilson 区间、``_rates``）统计。
n=3 那一列就是「原来论文看到的东西」，n=6 那一列是「补跑之后的样子」，
两者同 seed 配对，差异只来自多出来的 3 个 run。

另做两项健全性检查：
  1. 前 3 个 run 的指标在补跑前后必须逐项一致（run 级 resume 未污染旧数据）；
  2. 逐 cell 列出「n=3 零事件、n=6 出现事件」的翻转格子。

只读 ``results/apps/raw/uav_intercept``，输出
``results/apps/tables/uav_r6_subset.csv``，不覆盖论文用的任何表。

用法::

    python src/analyze_uav_r6_subset.py
    python src/analyze_uav_r6_subset.py --hosts DISK DE/rand/1
"""
import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analyze_uav_events as AUE  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'apps' / 'raw' / 'uav_intercept' / 'D30'
BACKUP = ROOT / 'results' / 'apps' / 'raw_uav_r3_backup' / 'D30'
TAB = ROOT / 'results' / 'apps' / 'tables'

DEFAULT_HOSTS = ['DISK', 'NL-SHADE-RSP', 'DE/rand/1', 'DE/best/1']
N_SHORT, N_LONG = 3, 6
FIDS = ('1', '2', '3', '4')
ARMS = ('bare', 'full')


def load_cells(hosts):
    """按文件名前缀选 cell。

    ``json['host']`` 里带斜杠（``DE/rand/1``），文件名把 ``/`` 换成 ``-``，
    而宿主名自身也含 ``-``（``NL-SHADE-RSP``），所以统一用文件名前缀做键，
    并把 JSON 里的 host 名规范成命令行形式。
    """
    want = {h.replace('/', '-'): h for h in hosts}
    out = []
    for p in sorted(RAW.glob('*.json')):
        stem = p.stem.split('__')[0]
        if want and stem not in want:
            continue
        d = json.loads(p.read_text(encoding='utf-8'))
        out.append({'host': want.get(stem, d['host']), 'path': p, 'data': d})
    return out


def host_key(h):
    return h.replace('/', '-')


def rows_from(cells, n_runs):
    """截断到前 ``n_runs`` 个 run，产出与 AUE.load_runs 同构的记录。"""
    rows = []
    for c in cells:
        d = c['data']
        for run in d.get('runs', []):
            if int(run.get('run', 0)) >= n_runs:
                continue
            for arm in d.get('arms', []):
                rec = run.get(arm)
                if not isinstance(rec, dict):
                    continue
                m = rec.get('metrics') or {}
                if 'base_hp' not in m:
                    continue
                rows.append({'host': c['host'], 'fid': str(d['fid']),
                             'dim': d['dim'], 'arm': arm,
                             'nevals': rec.get('nevals'),
                             'curve': rec.get('err_curve'), 'm': m})
    return rows


def sel(rows, host=None, fid=None, arm=None):
    return [r for r in rows
            if (host is None or r['host'] == host)
            and (fid is None or r['fid'] == fid)
            and (arm is None or r['arm'] == arm)]


def safe_rates(rows):
    """``_rates`` 在空集上会除零，这里挡掉。"""
    return AUE._rates(rows) if rows else None


def integrity_check(cells):
    """补跑后前 3 个 run 的指标/seed 必须与备份逐项相等。"""
    bad = []
    for c in cells:
        b = BACKUP / c['path'].name
        if not b.exists():
            bad.append((c['path'].name, 'no backup'))
            continue
        old = {int(e['run']): e for e in
               json.loads(b.read_text(encoding='utf-8')).get('runs', [])}
        for e in c['data'].get('runs', []):
            rid = int(e.get('run', -1))
            if rid >= N_SHORT or rid not in old:
                continue
            for arm in c['data'].get('arms', []):
                a, n = old[rid].get(arm), e.get(arm)
                if not (isinstance(a, dict) and isinstance(n, dict)):
                    bad.append((c['path'].name, f'run{rid} {arm} missing'))
                    continue
                if a.get('metrics') != n.get('metrics'):
                    bad.append((c['path'].name, f'run{rid} {arm} metrics differ'))
                if a.get('seed') != n.get('seed'):
                    bad.append((c['path'].name, f'run{rid} {arm} seed differ'))
    return bad


def fmt(r):
    return f'{r["gnd_pct"]:5.1f}%[{r["gnd_lo"]:4.1f},{r["gnd_hi"]:4.1f}]'


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--hosts', nargs='*', default=DEFAULT_HOSTS)
    args = ap.parse_args(argv)

    cells = load_cells(args.hosts)
    if not cells:
        print('[r6] no cells found')
        return
    hosts = list(dict.fromkeys(c['host'] for c in cells))
    waiting = [(c['host'], c['data']['fid'], c['data'].get('runs_complete'))
               for c in cells if c['data'].get('runs_complete', 0) < N_LONG]
    print(f'[r6] cells={len(cells)} hosts={hosts} '
          f'pending(<{N_LONG} runs)={len(waiting)}')
    for h, f, rc in waiting:
        print(f'      waiting: {h} F{f} runs_complete={rc}')

    r3 = rows_from(cells, N_SHORT)
    r6 = rows_from(cells, N_LONG)

    # ---------- 1. 健全性 ----------
    bad = integrity_check(cells)
    print('\n=== 1. run 级 resume 完整性（前 3 个 run 与备份比对）===')
    print('  PASS' if not bad else f'  FAIL: {len(bad)} 处不一致')
    for b in bad[:10]:
        print('   ', b)

    # ---------- 2. 逐 cell 事件计数 ----------
    print('\n=== 2. 逐 cell 事件计数（地面抵达 / 两机到达），同 seed 配对 ===')
    print('%-14s %-2s %-5s %16s %16s %16s %16s' %
          ('host', 'F', 'arm', 'gnd n=3', 'gnd n=6', 'air n=3', 'air n=6'))
    flips = []
    for h in hosts:
        for fid in FIDS:
            for arm in ARMS:
                a = safe_rates(sel(r3, h, fid, arm))
                b = safe_rates(sel(r6, h, fid, arm))
                if a is None or b is None:
                    print('%-14s %-2s %-5s %16s' % (h, fid, arm, 'missing'))
                    continue
                print('%-14s %-2s %-5s %16s %16s %16s %16s' %
                      (h, fid, arm,
                       f"{a['gnd_k']}/{a['n_runs']}", f"{b['gnd_k']}/{b['n_runs']}",
                       f"{a['air_k']}/{a['n_runs']}", f"{b['air_k']}/{b['n_runs']}"))
                if a['gnd_k'] == 0 and b['gnd_k'] > 0:
                    flips.append(f'{h} F{fid} {arm}: 地面抵达 0/{a["n_runs"]}'
                                 f' -> {b["gnd_k"]}/{b["n_runs"]}')
                if a['dest_k'] == 0 and b['dest_k'] > 0:
                    flips.append(f'{h} F{fid} {arm}: 基地被摧毁 0/{a["n_runs"]}'
                                 f' -> {b["dest_k"]}/{b["n_runs"]}')

    # ---------- 3. 合并口径 ----------
    print('\n=== 3. 合并口径：地面抵达率与 Wilson 95% 区间 ===')
    print('%-10s %-5s %22s %22s %10s' %
          ('scope', 'arm', 'n=3', 'n=6', 'CI 收缩'))
    csv_rows = []
    for arm in ('bare', 'full', 'both'):
        key = None if arm == 'both' else arm
        for scope, fid in [('all', None)] + [('task', f) for f in FIDS]:
            a = safe_rates(sel(r3, None, fid, key))
            b = safe_rates(sel(r6, None, fid, key))
            if a is None or b is None:
                continue
            wa, wb = a['gnd_hi'] - a['gnd_lo'], b['gnd_hi'] - b['gnd_lo']
            shrink = (1 - wb / wa) * 100 if wa > 0 else float('nan')
            print('%-10s %-5s %22s %22s %9.1f%%' %
                  (f'{scope}:{fid or "all"}', arm, fmt(a), fmt(b), shrink))
            csv_rows.append(dict(
                hosts=';'.join(hosts), scope=scope, fid=fid or 'all', arm=arm,
                n3=a['n_runs'], gnd3_k=a['gnd_k'],
                gnd3_pct=round(a['gnd_pct'], 3), gnd3_lo=round(a['gnd_lo'], 3),
                gnd3_hi=round(a['gnd_hi'], 3), n6=b['n_runs'], gnd6_k=b['gnd_k'],
                gnd6_pct=round(b['gnd_pct'], 3), gnd6_lo=round(b['gnd_lo'], 3),
                gnd6_hi=round(b['gnd_hi'], 3),
                ci_width_shrink_pct=round(shrink, 2),
                dest3_k=a['dest_k'], dest6_k=b['dest_k'],
                dmg_med3=round(a['dmg_med'], 4), dmg_med6=round(b['dmg_med'], 4),
                dmg_mean3=round(a['dmg_mean'], 4),
                dmg_mean6=round(b['dmg_mean'], 4),
                extra_k3=a['extra_k'], extra_k6=b['extra_k'],
                extra_gnd3=a['extra_gnd_k'], extra_gnd6=b['extra_gnd_k']))

    # ---------- 4. 翻转清单 ----------
    print('\n=== 4. 由「零事件」翻转为「有事件」的 cell ===')
    print('  （无）' if not flips else '')
    for f in flips:
        print('   ', f)

    # ---------- 5. 零事件格子占比 ----------
    print('\n=== 5. "整个 cell 看不到地面抵达"的比例（逐 cell 逐臂）===')
    for tag, rows in (('n=3', r3), ('n=6', r6)):
        tot = zero = 0
        for h in hosts:
            for fid in FIDS:
                for arm in ARMS:
                    rec = safe_rates(sel(rows, h, fid, arm))
                    if rec is None:
                        continue
                    tot += 1
                    zero += 1 if rec['gnd_k'] == 0 else 0
        if tot:
            print(f'  {tag}: {zero}/{tot} = {100 * zero / tot:.1f}%')

    if not csv_rows:
        print('\n[r6] nothing to write yet')
        return
    TAB.mkdir(parents=True, exist_ok=True)
    out = TAB / 'uav_r6_subset.csv'
    with open(out, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(csv_rows[0].keys()))
        w.writeheader()
        w.writerows(csv_rows)
    print(f'\n[r6] wrote {out}  ({len(csv_rows)} rows)')


if __name__ == '__main__':
    main()

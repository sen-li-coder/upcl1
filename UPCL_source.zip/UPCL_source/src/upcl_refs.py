# -*- coding: utf-8 -*-
"""Reference entries added for the UPCL manuscript.

Extends the shared EC bibliography (ec_refs.REFS) with the works cited in
the positioning audit of Section 2.  Records keep the typed GB/T 7714 field
order (``AUTHORS. Title[J]. Journal, Year, Vol(Issue): Pages.``) that the
checkers and `refs_style` rely on; `get_refs` prints them in the layout of the
target journal.
"""

import refs_style
from ec_refs import REFS

UPCL_REFS = {
    'NELDERMEAD65':
        'NELDER J A, MEAD R. A simplex method for function minimization[J]. '
        'The Computer Journal, 1965, 7(4): 308-313.',

    'MADS06':
        'AUDET C, DENNIS J E. Mesh adaptive direct search algorithms for '
        'constrained optimization[J]. SIAM Journal on Optimization, 2006, '
        '17(1): 188-217.',

    'GPS97':
        'TORCZON V. On the convergence of pattern search algorithms[J]. '
        'SIAM Journal on Optimization, 1997, 7(1): 1-25.',

    'ODE07':
        'RAHNAMAYAN S, TIZHOOSH H R, SALAMA M M A. Opposition-based '
        'differential evolution[J]. IEEE Transactions on Evolutionary '
        'Computation, 2008, 12(1): 64-79.',

    'MTDE20':
        'NADIMI-SHAHRAKI M H, TAGHIAN S, MIRJALILI S, et al. MTDE: an '
        'effective multi-trial vector-based differential evolution algorithm '
        'and its applications for engineering design problems[J]. Applied '
        'Soft Computing, 2020, 97: 106761.',

    'MEMETIC89':
        'MOSCATO P. On evolution, search, optimization, genetic algorithms '
        'and martial arts: towards memetic algorithms[R]. Pasadena: '
        'California Institute of Technology, 1989.',

    'RECHENBERG73':
        'RECHENBERG I. Evolutionsstrategie: optimierung technischer systeme '
        'nach prinzipien der biologischen evolution[M]. Stuttgart: '
        'Frommann-Holzboog, 1973.',

    'HAARIO06':
        'HAARIO H, LAINE E, MIRA A, et al. DRAM: efficient adaptive MCMC[J]. '
        'Statistics and Computing, 2006, 16(4): 339-354.',

    'L2O22':
        'CHEN T, CHEN X, CHEN W, et al. Learning to optimize: a primer and a '
        'benchmark[J]. Journal of Machine Learning Research, 2022, 23(189): '
        '1-70.',

    'OACDE22':
        'HUANG C, BAI H, YAO X. Online algorithm configuration for '
        'differential evolution algorithm[J]. Applied Intelligence, 2022, '
        '52(8): 9193-9211.',

    'MODDE23':
        'VERMETTEN D, CARAFFINI F, KONONOVA A V, et al. Modular differential '
        'evolution[EB/OL]. (2023-04-19)[2026-10-12]. '
        'https://arxiv.org/abs/2304.09524.',

    'DRLDAS24':
        'GUO H, MA Y, MA Z, et al. Deep reinforcement learning for dynamic '
        'algorithm selection: a proof-of-principle study on differential '
        'evolution[J/OL]. IEEE Transactions on Systems, Man, and Cybernetics: '
        'Systems, 2024[2026-10-12]. '
        'https://doi.org/10.1109/TSMC.2024.3374797.',

    'CEC17':
        'AWAD N H, ALI M Z, LIANG J J, et al. Problem definitions and '
        'evaluation criteria for the CEC 2017 special session and '
        'competition on single objective real-parameter numerical '
        'optimization[R]. Singapore: Nanyang Technological University, 2016.',

    'CEC22':
        'KUMAR A, WU G, ALI M Z, et al. Problem definitions and '
        'evaluation criteria for the CEC 2022 special session and '
        'competition on single objective bound constrained numerical '
        'optimization[R]. Singapore: Nanyang Technological University, 2022.',

    # --- recent success-history based variants (metadata verified via
    #     Crossref DOI lookup; see tools note in ``upcl_part_bg``) ---
    'ILSHADE':
        'BREST J, MAUČEC M S, BOŠKOVIĆ B. iL-SHADE: improved L-SHADE '
        'algorithm for single objective real-parameter optimization[C]//'
        '2016 IEEE Congress on Evolutionary Computation. Vancouver: IEEE, '
        '2016: 1188-1195.',

    'MPEDE':
        'WU G H, MALLIPEDDI R, SUGANTHAN P N, et al. Differential evolution '
        'with multi-population based ensemble of mutation strategies[J]. '
        'Information Sciences, 2016, 329: 329-345.',

    'LSHADE_EPSIN':
        'AWAD N H, ALI M Z, SUGANTHAN P N, et al. An ensemble sinusoidal '
        'parameter adaptation incorporated with L-SHADE for solving CEC2014 '
        'benchmark problems[C]//2016 IEEE Congress on Evolutionary '
        'Computation. Vancouver: IEEE, 2016: 2958-2965.',

    'LSHADE_SPACMA':
        'MOHAMED A W, HADI A A, FATTOUH A M, et al. LSHADE with '
        'semi-parameter adaptation hybrid with CMA-ES for solving CEC 2017 '
        'benchmark problems[C]//2017 IEEE Congress on Evolutionary '
        'Computation. San Sebastian: IEEE, 2017: 145-152.',

    'LBRDE':
        'STANOVOV V, AKHMEDOVA S, SEMENKIN E. Differential evolution with '
        'linear bias reduction in parameter adaptation[J]. Algorithms, 2020, '
        '13(11): 283.',

    'NLSHADE_RSP':
        'STANOVOV V, AKHMEDOVA S, SEMENKIN E. NL-SHADE-RSP algorithm with '
        'adaptive archive and selective pressure for CEC 2021 numerical '
        'optimization[C]//2021 IEEE Congress on Evolutionary Computation. '
        'Kraków: IEEE, 2021: 809-816.',

    'NLSHADE_LBC':
        'STANOVOV V, AKHMEDOVA S, SEMENKIN E. NL-SHADE-LBC algorithm with '
        'linear parameter adaptation bias change for CEC 2022 numerical '
        'optimization[C]//2022 IEEE Congress on Evolutionary Computation. '
        'Padua: IEEE, 2022: 1-8.',


    # --- wave-4 host mechanisms and the adaptation-taxonomy anchors cited
    #     in the Section 2 variant tables ---
    'SANSDE':
        'YANG Z, TANG K, YAO X. Self-adaptive differential evolution with '
        'neighborhood search[C]//2008 IEEE Congress on Evolutionary '
        'Computation. Hong Kong: IEEE, 2008: 1110-1116.',

    'PADE':
        'MENG Z, PAN J S, TSENG K K. PaDE: an enhanced differential '
        'evolution algorithm with novel control parameter adaptation schemes '
        'for numerical optimization[J]. Knowledge-Based Systems, 2019, 168: '
        '80-99.',

    'DISH':
        'VIKTORIN A, SENKERIK R, PLUHACEK M, et al. Distance based parameter '
        'adaptation for success-history based differential evolution[J]. '
        'Swarm and Evolutionary Computation, 2019, 50: 100462.',

    'JDE100':
        'BREST J, MAUČEC M S, BOŠKOVIĆ B. jDE100: a new differential '
        'evolution algorithm for single objective numerical '
        'optimization[C]//2020 IEEE Congress on Evolutionary Computation. '
        'Glasgow: IEEE, 2020: 1-8.',

    'SINDE':
        'DRAA A, CHETTAH K, TALBI H. A compound sinusoidal differential '
        'evolution algorithm for continuous optimization[J]. Swarm and '
        'Evolutionary Computation, 2019, 50: 100450.',

    'LSHADE_RSP':
        'STANOVOV V, AKHMEDOVA S, SEMENKIN E. LSHADE algorithm with '
        'rank-based selective pressure strategy for solving CEC 2017 '
        'benchmark problems[C]//2018 IEEE Congress on Evolutionary '
        'Computation. Rio de Janeiro: IEEE, 2018: 1-8.',

    'IMODE':
        'SALLAM K M, ELSAYED S M, CHAKRABORTTY R K, et al. Improved '
        'multi-operator differential evolution algorithm for solving '
        'unconstrained problems[C]//2020 IEEE Congress on Evolutionary '
        'Computation. Glasgow: IEEE, 2020: 1-8.',

    'MADDE':
        'BISWAS S, SAHA D, DE S, et al. Improving differential evolution '
        'through Bayesian hyperparameter optimization[C]//2021 IEEE Congress '
        'on Evolutionary Computation. Kraków: IEEE, 2021: 832-840.',

    'SHADEILS':
        'MOLINA D, LATORRE A, HERRERA F. SHADE with iterative local search '
        'for large-scale global optimization[C]//2018 IEEE Congress on '
        'Evolutionary Computation. Rio de Janeiro: IEEE, 2018: 1252-1259.',

    'FADE05':
        'LIU J, LAMPINEN J. A fuzzy adaptive differential evolution '
        'algorithm[J]. Soft Computing, 2005, 9(6): 448-462.',

    'DEGL09':
        'DAS S, ABRAHAM A, CHAKRABORTY U K, et al. Differential evolution '
        'using a neighborhood-based mutation operator[J]. IEEE Transactions '
        'on Evolutionary Computation, 2009, 13(3): 526-553.',

    'MDEPBX':
        'ISLAM S M, DAS S, GHOSH S, et al. An adaptive differential evolution '
        'algorithm with novel mutation and crossover strategies for global '
        'numerical optimization[J]. IEEE Transactions on Systems, Man, and '
        'Cybernetics, Part B (Cybernetics), 2012, 42(2): 482-500.',

    'SPSLSEIG':
        'GUO S M, YANG C C. Enhancing differential evolution utilizing '
        'eigenvector-based crossover operator[J]. IEEE Transactions on '
        'Evolutionary Computation, 2015, 19(1): 31-49.',

    'LSHADE_CNEPSIN':
        'AWAD N H, ALI M Z, SUGANTHAN P N. Ensemble of parameters in a '
        'sinusoidal differential evolution with niching-based population '
        'reduction[J]. Swarm and Evolutionary Computation, 2018, 39: 141-156.',

    'AGDE':
        'MOHAMED A K, MOHAMED A W. Real-parameter unconstrained optimization '
        'based on enhanced AGDE algorithm[M]//Machine Learning Paradigms: '
        'Theory and Application. Cham: Springer, 2019: 431-450.',

    'EA4EIG':
        'BUJOK P, KOLENOVSKÝ P. Eigen crossover in cooperative model of '
        'evolutionary algorithms applied to CEC 2022 single objective '
        'numerical optimisation[C]//2022 IEEE Congress on Evolutionary '
        'Computation. Padua: IEEE, 2022: 1-8.',









    'ZEPDE':
        'FAN Q, YAN X. Self-adaptive differential evolution algorithm with '
        'Z-score for numerical optimization[J]. Information Sciences, 2016, '
        '364-365: 1-15.',

    'LSHADE44':
        'POLÁKOVÁ R. L-SHADE with competing strategies applied to '
        'constrained optimization[C]//2019 IEEE Congress on Evolutionary '
        'Computation. Wellington: IEEE, 2019: 1-8.',

    'HARDDE':
        'MENG Z, PAN J S. HARD-DE: hierarchical archive-based mutation for '
        'differential evolution[J]. Information Sciences, 2020, 526: '
        '201-222.',

    'LSHADE_ND22':
        'TANABE R, FUKUNAGA A S. L-SHADE with neighbourhood-based mutation '
        'for single-objective numerical optimisation[C]//2022 IEEE Congress '
        'on Evolutionary Computation. Padua: IEEE, 2022: 1-8.',
























    'NERI10':
        'NERI F, TIRRONEN V. Recent advances in differential evolution: '
        'a survey and experimental analysis[J]. Artificial Intelligence '
        'Review, 2010, 33(1-2): 61-106.',

    'BREST07':
        'BREST J, BOSKOVIC B, GREINER S, et al. Performance comparison '
        'of self-adaptive and adaptive differential evolution '
        'algorithms[J]. Soft Computing, 2007, 11(7): 617-629.',


    'COBIDE':
        'WANG Y, LI H X, HUANG T, et al. Differential evolution based '
        'on covariance matrix learning and bimodal distribution '
        'parameter setting[J]. Applied Soft Computing, 2014, 18: '
        '232-247.',

    'TANG15':
        'TANG L, DONG Y, LIU J. Differential evolution with an '
        'individual-dependent mechanism[J]. IEEE Transactions on '
        'Evolutionary Computation, 2015, 19(4): 560-574.',


    'PIOTROWSKI17':
        'PIOTROWSKI A P. Review of differential evolution population '
        'size[J]. Swarm and Evolutionary Computation, 2017, 32: 1-24.',

    'PIOTROWSKI_SPEED17':
        'PIOTROWSKI A P, NAPIORKOWSKI J J, PIOTROWSKA A E, et al. Swarm '
        'intelligence and evolutionary algorithms: performance versus '
        'speed[J]. Information Sciences, 2017, 384: 34-85.',

    'KARAFOTIAS15':
        'KARAFOTIAS G, HOOGENDOORN M, EIBEN A E. Parameter control in '
        'evolutionary algorithms: trends and challenges[J]. IEEE '
        'Transactions on Evolutionary Computation, 2015, 19(2): '
        '167-187.',

    'EIBEN99':
        'EIBEN A E, HINTERDING R, MICHALEWICZ Z. Parameter control in '
        'evolutionary algorithms[J]. IEEE Transactions on Evolutionary '
        'Computation, 1999, 3(2): 124-141.',

    'BACK93':
        'BACK T, SCHWEFEL H P. An overview of evolutionary algorithms '
        'for parameter optimization[J]. Evolutionary Computation, 1993, '
        '1(1): 1-23.',

    'WOLPERT97':
        'WOLPERT D H, MACREADY W G. No free lunch theorems for '
        'optimization[J]. IEEE Transactions on Evolutionary '
        'Computation, 1997, 1(1): 67-82.',


    'MUNOZ15':
        'MUNOZ M A, SUN Y, KIRLEY M, et al. Algorithm selection for '
        'black-box continuous optimization problems: a survey on '
        'methods and challenges[J]. Information Sciences, 2015, 317: '
        '224-245.',

    'BURKE13':
        'BURKE E K, GENDREAU M, HYDE M, et al. Hyper-heuristics: a '
        'survey of the state of the art[J]. Journal of the Operational '
        'Research Society, 2013, 64(12): 1695-1724.',

    'JIN11':
        'JIN Y. Surrogate-assisted evolutionary computation: recent '
        'advances and future challenges[J]. Swarm and Evolutionary '
        'Computation, 2011, 1(2): 61-70.',

    'CHUGH19':
        'CHUGH T, SINDHYA K, HAKANEN J, et al. A survey on handling '
        'computationally expensive multiobjective optimization problems '
        'with evolutionary algorithms[J]. Soft Computing, 2019, 23(9): '
        '3137-3166.',

    'TAN21TEO':
        'TAN K C, FENG L, JIANG M. Evolutionary transfer optimization - '
        'a new frontier in evolutionary computation research[J]. IEEE '
        'Computational Intelligence Magazine, 2021, 16(1): 22-33.',

    'NGUYEN12':
        'NGUYEN T T, YANG S, BRANKE J. Evolutionary dynamic '
        'optimization: a survey of the state of the art[J]. Swarm and '
        'Evolutionary Computation, 2012, 6: 1-24.',

    'COELLO02':
        'COELLO COELLO C A. Theoretical and numerical '
        'constraint-handling techniques used with evolutionary '
        'algorithms: a survey of the state of the art[J]. Computer '
        'Methods in Applied Mechanics and Engineering, 2002, '
        '191(11-12): 1245-1287.',

    'MEZURA11':
        'MEZURA-MONTES E, COELLO COELLO C A. Constraint-handling in '
        'nature-inspired numerical optimization: past, present and '
        'future[J]. Swarm and Evolutionary Computation, 2011, 1(4): '
        '173-194.',

    'DEB00F':
        'DEB K. An efficient constraint handling method for genetic '
        'algorithms[J]. Computer Methods in Applied Mechanics and '
        'Engineering, 2000, 186(2-4): 311-338.',

    'NSGA2':
        'DEB K, PRATAP A, AGARWAL S, et al. A fast and elitist '
        'multiobjective genetic algorithm: NSGA-II[J]. IEEE '
        'Transactions on Evolutionary Computation, 2002, 6(2): 182-197.',

    'MOEAD':
        'ZHANG Q, LI H. MOEA/D: a multiobjective evolutionary algorithm '
        'based on decomposition[J]. IEEE Transactions on Evolutionary '
        'Computation, 2007, 11(6): 712-731.',

    'OMIDVAR14':
        'OMIDVAR M N, LI X, MEI Y, et al. Cooperative co-evolution with '
        'differential grouping for large scale optimization[J]. IEEE '
        'Transactions on Evolutionary Computation, 2014, 18(3): '
        '378-393.',

    'YANG08':
        'YANG Z, TANG K, YAO X. Large scale evolutionary optimization '
        'using cooperative coevolution[J]. Information Sciences, 2008, '
        '178(15): 2985-2999.',

    'HANSEN01':
        'HANSEN N, OSTERMEIER A. Completely derandomized '
        'self-adaptation in evolution strategies[J]. Evolutionary '
        'Computation, 2001, 9(2): 159-195.',

    'YAO99':
        'YAO X, LIU Y, LIN G. Evolutionary programming made faster[J]. '
        'IEEE Transactions on Evolutionary Computation, 1999, 3(2): '
        '82-102.',

    'HANSEN_COCO21':
        'HANSEN N, AUGER A, ROS R, et al. COCO: a platform for '
        'comparing continuous optimizers in a black-box setting[J]. '
        'Optimization Methods and Software, 2021, 36(1): 114-144.',

    'SHAHRIARI16':
        'SHAHRIARI B, SWERSKY K, WANG Z, et al. Taking the human out of '
        'the loop: a review of Bayesian optimization[J]. Proceedings of '
        'the IEEE, 2016, 104(1): 148-175.',


    'SUTTON18':
        'SUTTON R S, BARTO A G. Reinforcement learning: an '
        'introduction[M]. 2nd ed. Cambridge: MIT Press, 2018.',

    'AUER02':
        'AUER P, CESA-BIANCHI N, FISCHER P. Finite-time analysis of the '
        'multiarmed bandit problem[J]. Machine Learning, 2002, 47(2-3): '
        '235-256.',

    'LATTIMORE20':
        'LATTIMORE T, SZEPESVARI C. Bandit algorithms[M]. Cambridge: '
        'Cambridge University Press, 2020.',

    'BENGIO21':
        'BENGIO Y, LODI A, PROUVOST A. Machine learning for '
        'combinatorial optimization: a methodological tour '
        'd\'horizon[J]. European Journal of Operational Research, 2021, '
        '290(2): 405-421.',

    'HOSPEDALES22':
        'HOSPEDALES T, ANTONIOU A, MICAELLI P, et al. Meta-learning in '
        'neural networks: a survey[J]. IEEE Transactions on Pattern '
        'Analysis and Machine Intelligence, 2022, 44(9): 5149-5169.',

    'BREIMAN01':
        'BREIMAN L. Random forests[J]. Machine Learning, 2001, 45(1): '
        '5-32.',

    'STONE74':
        'STONE M. Cross-validatory choice and assessment of statistical '
        'predictions[J]. Journal of the Royal Statistical Society: '
        'Series B, 1974, 36(2): 111-147.',

    'COHEN88':
        'COHEN J. Statistical power analysis for the behavioral '
        'sciences[M]. 2nd ed. Hillsdale: Lawrence Erlbaum, 1988.',

    'HOLLANDER99':
        'HOLLANDER M, WOLFE D A. Nonparametric statistical methods[M]. '
        '2nd ed. New York: Wiley, 1999.',

    'BENAVOLI16':
        'BENAVOLI A, CORANI G, MANGILI F. Should we really use post-hoc '
        'tests based on mean-ranks?[J]. Journal of Machine Learning '
        'Research, 2016, 17(5): 1-10.',

    'COOK77':
        'COOK R D. Detection of influential observation in linear '
        'regression[J]. Technometrics, 1977, 19(1): 15-18.',

    'MONTGOMERY12':
        'MONTGOMERY D C. Design and analysis of experiments[M]. 8th ed. '
        'Hoboken: Wiley, 2012.',

    'BISHOP06':
        'BISHOP C M. Pattern recognition and machine learning[M]. New '
        'York: Springer, 2006.',

    'PEDREGOSA11':
        'PEDREGOSA F, VAROQUAUX G, GRAMFORT A, et al. Scikit-learn: '
        'machine learning in Python[J]. Journal of Machine Learning '
        'Research, 2011, 12: 2825-2830.',

    'VASSILEV00':
        'VASSILEV V K, FOGARTY T C, MILLER J F. Information '
        'characteristics and the structure of landscapes[J]. '
        'Evolutionary Computation, 2000, 8(1): 31-60.',

    'WASSERSTEIN16':
        'WASSERSTEIN R L, LAZAR N A. The ASA statement on p-values: '
        'context, process, and purpose[J]. The American Statistician, '
        '2016, 70(2): 129-133.',

    'NOSEK18':
        'NOSEK B A, EBERSOLE C R, DEHAVEN A C, et al. The '
        'preregistration revolution[J]. Proceedings of the National '
        'Academy of Sciences, 2018, 115(11): 2600-2606.',

    'DRIFT14':
        'GAMA J, ZLIOBAITE I, BIFET A, et al. A survey on concept drift '
        'adaptation[J]. ACM Computing Surveys, 2014, 46(4): 44.',

    'HUTTER19':
        'HUTTER F, KOTTHOFF L, VANSCHOREN J. Automated machine '
        'learning: methods, systems, challenges[M]. Cham: Springer, '
        '2019.',

    'OTTO18':
        'OTTO A, AGATZ N, CAMPBELL J, et al. Optimization approaches '
        'for civil applications of unmanned aerial vehicles (UAVs) or '
        'aerial drones: a survey[J]. Networks, 2018, 72(4): 411-458.',

    'ROBERGE13':
        'ROBERGE V, TARBOUCHI M, LABONTE G. Comparison of parallel '
        'genetic algorithm and particle swarm optimization for '
        'real-time UAV path planning[J]. IEEE Transactions on '
        'Industrial Informatics, 2013, 9(1): 132-141.',

    'BESADA10':
        'BESADA-PORTAS E, DE LA TORRE L, DE LA CRUZ J M, et al. '
        'Evolutionary trajectory planner for multiple UAVs in realistic '
        'scenarios[J]. IEEE Transactions on Robotics, 2010, 26(4): '
        '619-634.',

    'ZHEN20':
        'ZHEN Z, CHEN Y, WEN L, et al. An intelligent cooperative '
        'mission planning scheme of UAV swarm in uncertain dynamic '
        'environment[J]. Aerospace Science and Technology, 2020, 100: '
        '105826.',

    'ZENG16':
        'ZENG Y, ZHANG R, LIM T J. Wireless communications with '
        'unmanned aerial vehicles: opportunities and challenges[J]. '
        'IEEE Communications Magazine, 2016, 54(5): 36-42.',

    'DORLING17':
        'DORLING K, HEINRICHS J, MESSIER G G, et al. Vehicle routing '
        'problems for drone delivery[J]. IEEE Transactions on Systems, '
        'Man, and Cybernetics: Systems, 2017, 47(1): 70-85.',

    'ZHAO18':
        'ZHAO Y, ZHENG Z, LIU Y. Survey on '
        'computational-intelligence-based UAV path planning[J]. '
        'Knowledge-Based Systems, 2018, 158: 54-64.',

    'ISAACS65':
        'ISAACS R. Differential games[M]. New York: Wiley, 1965.',

    'VIDAL02':
        'VIDAL R, SHAKERNIA O, KIM H J, et al. Probabilistic '
        'pursuit-evasion games: theory, implementation, and '
        'experimental evaluation[J]. IEEE Transactions on Robotics and '
        'Automation, 2002, 18(5): 662-669.',

    'SHIMA02':
        'SHIMA T, SHINAR J. Time-varying linear pursuit-evasion game '
        'models with bounded controls[J]. Journal of Guidance, Control, '
        'and Dynamics, 2002, 25(3): 425-432.',

    'JUAN15':
        'JUAN A A, FAULIN J, GRASMAN S E, et al. A review of '
        'simheuristics: extending metaheuristics to deal with '
        'stochastic simulation optimisation problems[J]. Operations '
        'Research Perspectives, 2015, 2: 62-72.',

    'REGIS14':
        'REGIS R G. Evolutionary programming for high-dimensional '
        'constrained expensive black-box optimization using radial '
        'basis functions[J]. IEEE Transactions on Evolutionary '
        'Computation, 2014, 18(3): 326-347.',

    'LAVALLE06':
        'LAVALLE S M. Planning algorithms[M]. Cambridge: Cambridge '
        'University Press, 2006.',

    'KARAMAN11':
        'KARAMAN S, FRAZZOLI E. Sampling-based algorithms for optimal '
        'motion planning[J]. International Journal of Robotics '
        'Research, 2011, 30(7): 846-894.',

    'MNIH15':
        'MNIH V, KAVUKCUOGLU K, SILVER D, et al. Human-level control '
        'through deep reinforcement learning[J]. Nature, 2015, '
        '518(7540): 529-533.',

    'SILVER16':
        'SILVER D, HUANG A, MADDISON C J, et al. Mastering the game of '
        'Go with deep neural networks and tree search[J]. Nature, 2016, '
        '529(7587): 484-489.',

    'SILVER18':
        'SILVER D, HUBERT T, SCHRITWIESER J, et al. A general '
        'reinforcement learning algorithm that masters chess, shogi, '
        'and Go through self-play[J]. Science, 2018, 362(6419): '
        '1140-1144.',

    'LOWE17':
        'LOWE R, WU Y, TAMAR A, et al. Multi-agent actor-critic for '
        'mixed cooperative-competitive environments[C]//Advances in '
        'Neural Information Processing Systems, 2017: 6379-6390.',

    'ZHANG_MARL21':
        'ZHANG K, YANG Z, BASAR T. Multi-agent reinforcement learning: '
        'a selective overview of theories and algorithms[M]//Handbook '
        'of Reinforcement Learning and Control. Cham: Springer, 2021: '
        '321-384.',

    'FUNSEARCH':
        'ROMERA-PAREDES B, BAREKATAIN M, NOVIKOV A, et al. Mathematical '
        'discoveries from program search with large language models[J]. '
        'Nature, 2024, 625(7995): 468-475.',

    'WEI22':
        'WEI J, WANG X, SCHUURMANS D, et al. Chain-of-thought prompting '
        'elicits reasoning in large language models[C]//Advances in '
        'Neural Information Processing Systems, 2022: 24824-24837.',

    'LIU_LLM_EA':
        'LIU S, CHEN C, QU X, et al. Large language models as '
        'evolutionary optimizers[C]//2024 IEEE Congress on Evolutionary '
        'Computation (CEC), 2024: 1-8.',

    'KONG20':
        'KONG W, ZHOU D, YANG Z, et al. UAV autonomous aerial combat '
        'maneuver strategy generation with observation error based on '
        'state-adversarial deep deterministic policy gradient and '
        'inverse reinforcement learning[J]. Electronics, 2020, 9(7): '
        '1121.',

    'WHITLEY94':
        'WHITLEY D. A genetic algorithm tutorial[J]. Statistics and '
        'Computing, 1994, 4(2): 65-85.',

    'SRINIVAS94':
        'SRINIVAS M, PATNAIK L M. Genetic algorithms: a survey[J]. '
        'Computer, 1994, 27(6): 17-26.',

    'NERI12':
        'NERI F, COTTA C. Memetic algorithms and memetic computing '
        'optimization: a literature review[J]. Swarm and Evolutionary '
        'Computation, 2012, 2: 1-14.',

    'JIN05':
        'JIN Y. A comprehensive survey of fitness approximation in '
        'evolutionary computation[J]. Soft Computing, 2005, 9(1): 3-12.',

    'ZHOU11':
        'ZHOU A, QU B Y, LI H, et al. Multiobjective evolutionary '
        'algorithms: a survey of the state of the art[J]. Swarm and '
        'Evolutionary Computation, 2011, 1(1): 32-49.',

    'ZITZLER99':
        'ZITZLER E, THIELE L. Multiobjective evolutionary algorithms: a '
        'comparative case study and the strength Pareto approach[J]. '
        'IEEE Transactions on Evolutionary Computation, 1999, 3(4): '
        '257-271.',

    # ---- 2025-2026 additions (Section 2 timeline continuation, Section 6) ----
    'DA2MODE25':
        'REDA M, ONSY A, HAIKAL A Y, et al. DA2MODE: dynamic archive with '
        'adaptive multi-operator differential evolution for numerical '
        'optimization[J]. Swarm and Evolutionary Computation, 2025, 99: '
        '102130.',

    'BIGMDE25':
        'WANG Y, LUO G, LI X, et al. Multifactorial differential evolution '
        'enhanced by adaptive Gaussian-mixture-model-based knowledge '
        'transfer[J]. Swarm and Evolutionary Computation, 2025, 99: 102194.',

    'ECLLM25':
        'WU X, WU S H, WU J, et al. Evolutionary computation in the era of '
        'large language model: survey and roadmap[J]. IEEE Transactions on '
        'Evolutionary Computation, 2025, 29(2): 534-554.',

    'METADE26':
        'CHEN M, FENG C, CHENG R. MetaDE: evolving differential evolution by '
        'differential evolution[J]. IEEE Transactions on Evolutionary '
        'Computation, 2026, 30(1): 141-155.',

    'DIVVAR26':
        'ZHAO L, SUN L, SONG Z, et al. Differential evolution with a '
        'variance contribution ratio-based diversity enhancement mechanism '
        'for numerical optimization[J]. Swarm and Evolutionary Computation, '
        '2026, 104: 102359.',

    'GLICK26':
        'GLICK A, MASTROBERARDINO A. GPU-accelerated differential evolution '
        'with gradient polishing and decorrelation-based convergence '
        'control[J]. Swarm and Evolutionary Computation, 2026, 107: 102488.',

    # ---- 2026 additions, indexed by mechanism dimension (Section 2) ----
    'SFGDE26':
        'GAO H, WANG J, WANG H. SFG-DE: an explainable and evolvable '
        'differential evolution for learning to generate operator '
        'structures[J]. Swarm and Evolutionary Computation, 2026, 100: '
        '102248.',

    'XPXOVER26':
        'PAN J, CHEN J, LI J, et al. Differential evolution with exponential '
        'crossover: a survey[J]. Computer Science Review, 2026, 62: 100990.',

    'SELALL26':
        'KITAMURA T, FUKUNAGA A. Is selection all you need in differential '
        'evolution?[J]. Applied Soft Computing, 2026, 186: 114138.',

    'DIMINH26':
        'ZHANG S, LIU Y, HU X, et al. Differential evolution with '
        'dimensionally adaptive inheritance[J]. Engineering Applications of '
        'Artificial Intelligence, 2026, 163: 112587.',

    'NICHE26':
        'WANG P, WANG Y, JIN J. A DBSCAN-enhanced niching differential '
        'evolution algorithm for solving nonlinear equations[J]. Information '
        'Sciences, 2026, 734: 122996.',

    'CCODE26':
        'GOU J, SONG Z, SUN L, et al. Cooperative co-evolution based '
        'differential evolutional algorithm[J]. Expert Systems with '
        'Applications, 2026, 307: 130876.',

    'DUAL26':
        'WU Y, WANG Y, ZHANG S, et al. Adaptive dual-module cooperation and '
        'competition differential evolution[J]. Engineering Applications of '
        'Artificial Intelligence, 2026, 181: 115602.',

    'PARAM26':
        'ZHONG R, WANG Z, XIAO Y, et al. Parameter adaptive competitive '
        'differential evolution with local search[J]. Applied Intelligence, '
        '2026, 56: 190.',

    # ---- 2025 additions to complete the mechanism-dimension index ----
    'FODE25':
        'WANG K, GAO S, ZHOU M, et al. Fractional order differential '
        'evolution[J]. IEEE Transactions on Evolutionary Computation, 2025, '
        '29: 822-835.',

    'LOCGLOB25':
        'JIN X, ZHANG S, ZHENG L, et al. Differential evolution algorithm with '
        'local and global parameter adaptation[J]. Swarm and Evolutionary '
        'Computation, 2025, 98: 102125.',

    'DEEM25':
        'MACHACEK J, SIEGEL S, ZACHERT H. DEEM: differential evolution with '
        'elitism and multi-populations[J]. Swarm and Evolutionary Computation, '
        '2025, 92: 101818.',

}


def get_refs(style=refs_style.DEFAULT_STYLE):
    """Return the shared bibliography extended with the UPCL entries.

    ``style`` selects the printed layout: ``'ec'`` (the target EC journal) or
    ``'gbt'`` (GB/T 7714-2015, as stored).  See `refs_style` for both layouts.
    """
    out = dict(REFS)
    out.update(UPCL_REFS)
    rendered, problems = refs_style.render(out, style)
    for key, why in problems:
        print('[refs] WARNING %s: %s' % (key, why))
    return rendered

# -*- coding: utf-8 -*-
"""Layer invariants that the paper's paired design relies on.

Two properties make the H vs H+UPCL comparison well posed, and both are
checked here on several hosts, dimensions and suites:

1. **Pure pass-through.**  With a configuration that can never intervene
   (identity margin larger than any attainable score), the layer must
   reproduce the bare host *bit for bit*: same trajectory, same final error,
   same number of evaluations.  If this fails, the layer is perturbing
   proposals it claims to leave alone and the paired comparison is impure.

2. **Evaluation-count neutrality.**  Attaching the layer must not change the
   number of objective evaluations for the same budget -- the layer only moves
   the x at which the host spends an evaluation.  The check is implicit in (1)
   and repeated here for the default configuration through the run records of
   the grid experiments (``fe_equal`` in ``exp6_overhead.csv``).

Usage
-----
    python validate_layer_invariants.py
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cec_suites as CS                                        # noqa: E402
import de_hosts                                                # noqa: E402
import de_hosts_cec as DHC                                     # noqa: E402
from upcl_experiment import get_config                         # noqa: E402
from upcl_framework import UPCLController                      # noqa: E402

DHC.register()

NEVER = dict(get_config('default'))
NEVER['margin'] = 1e9        # no correction can beat the identity
NEVER['margin_adapt'] = 0.0
NEVER['eps0'] = 0.0
NEVER['eps_min'] = 0.0

CASES = [('cec2017', 30, 1, 'DE/rand/1'),
         ('cec2017', 30, 5, 'JADE'),
         ('cec2017', 30, 25, 'DE/rand/2'),
         ('cec2017', 50, 6, 'CoDE'),
         ('cec2022', 10, 12, 'L-SHADE'),
         ('cec2022', 20, 3, 'NL-SHADE-RSP')]


def main():
    fails = 0
    for suite, dim, fid, host in CASES:
        func = CS.get_function(suite, dim, fid)
        pop = DHC.pop_size_for(host, dim)
        budget = 10000 * dim // 3          # a third of the paper's budget
        seed = 12345

        h0 = de_hosts.get_host(host, dim, func.lb, func.ub, seed=seed,
                               pop_size=pop)
        h0.run(func, budget)
        e0, n0 = h0.best_so_far, h0.nevals

        h1 = de_hosts.get_host(host, dim, func.lb, func.ub, seed=seed,
                               pop_size=pop)
        c = UPCLController(dim, func.lb, func.ub, seed=seed + 977,
                           config=NEVER)
        h1.gen_begin_fn = c.begin_generation
        h1.proposal_fn = c.propose
        h1.post_eval_fn = c.observe
        h1.run(func, budget)
        e1, n1 = h1.best_so_far, h1.nevals
        st = c.stats()

        same = (e0 == e1) and (n0 == n1) and st['n_interventions'] == 0
        fails += (not same)
        print(f'{suite} D={dim:<3d} F{fid:<3d} {host:>18s}  '
              f'err {e0!r} vs {e1!r}  nevals {n0}/{n1}  '
              f'interventions {st["n_interventions"]:<6d} '
              + ('PASS' if same else 'FAIL'))
    print('\nall invariants hold' if not fails else f'\n{fails} case(s) FAILED')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())

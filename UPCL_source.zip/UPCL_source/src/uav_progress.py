"""Parent-process UAV progress display; worker callbacks only send small events."""
from __future__ import annotations

import os
import queue
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

LOCAL_TZ = timezone(timedelta(hours=8))


def duration(seconds):
    seconds = max(0, int(seconds))
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return (f'{days}d ' if days else '') + f'{hours:02d}:{minutes:02d}:{seconds:02d}'


class ProgressState:
    def __init__(self, tasks, initial):
        self.tasks = {(t['host'], t['fid']): t for t in tasks}
        self.saved = {key: set(initial[key]) for key in self.tasks}
        self.baseline = sum(map(len, self.saved.values()))
        self.total = sum(t['runs'] for t in tasks)
        self.active = {}
        self.errors = {}

    def apply(self, event):
        key, kind = tuple(event['key']), event['kind']
        if kind == 'start':
            self.active[key] = dict(phase='initializing', updated=time.monotonic())
        elif kind == 'progress':
            self.active[key] = dict(event, phase='running', updated=time.monotonic())
        elif kind == 'saved':
            self.saved[key].add(event['run'])
            self.active[key] = dict(phase='saving / next run', updated=time.monotonic())
        elif kind in ('done', 'skip', 'error'):
            self.active.pop(key, None)
            if kind == 'error':
                self.errors[key] = event['message']

    @property
    def completed(self):
        return sum(map(len, self.saved.values()))

    def render(self, elapsed):
        completed = self.completed
        cells = sum(len(self.saved[k]) >= t['runs'] for k, t in self.tasks.items())
        new = max(0, completed - self.baseline)
        remaining = self.total - completed
        rate = new * 3600 / elapsed if elapsed > 0 else 0
        eta = (duration(remaining * 3600 / rate) if rate else 'waiting for first new run')
        if not remaining:
            eta = '00:00:00'
        pct = completed / self.total if self.total else 1.0
        fill = int(pct * 30)
        now = datetime.now(LOCAL_TZ).strftime('%Y-%m-%d %H:%M:%S')
        lines = [f'UAV live progress | {now} UTC+8',
                 f'[{"#" * fill}{"-" * (30 - fill)}] {pct:6.2%} '
                 f'saved paired runs {completed}/{self.total}',
                 f'This session: +{new}/{self.total - self.baseline} runs | '
                 f'cells {cells}/{len(self.tasks)} | active {len(self.active)} | '
                 f'errors {len(self.errors)}',
                 f'Elapsed {duration(elapsed)} | speed {rate:.2f} runs/h | ETA {eta}',
                 'HOST                     TASK  RUN       ARM    EVALUATIONS       GEN  UPDATE AGE']
        for key, state in sorted(self.active.items()):
            task = self.tasks[key]
            age = duration(time.monotonic() - state['updated'])
            prefix = f'{key[0]:24s} F{key[1]:<4d}'
            if state['phase'] != 'running':
                lines.append(f'{prefix} {state["phase"]} (last update {age} ago)')
                continue
            budget = task['fes_mult'] * task['dim']
            nevals = state['nevals']
            fraction = min(1.0, nevals / budget)
            gen = state['generation']
            lines.append(f'{prefix} {state["run"] + 1:2d}/{task["runs"]:<5d} '
                         f'{state["arm"]:6s} {nevals:6d}/{budget:<6d} '
                         f'{fraction:5.1%} {str(gen) if gen is not None else "-":>5s}  {age}')
        if not self.active and remaining and not self.errors:
            lines.append('Waiting for workers to start...')
        for key, message in sorted(self.errors.items()):
            lines.append(f'ERROR {key[0]} F{key[1]}: {message}')
        lines.append('A run is counted after all selected arms are saved to JSON. Ctrl+C to stop.')
        return '\n'.join(lines)


def _enable_ansi():
    if not sys.stdout.isatty():
        return False
    if os.name != 'nt':
        return True
    try:
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetStdHandle.argtypes = [wintypes.DWORD]
        kernel.GetStdHandle.restype = wintypes.HANDLE
        kernel.GetConsoleMode.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetConsoleMode.restype = wintypes.BOOL
        kernel.SetConsoleMode.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.SetConsoleMode.restype = wintypes.BOOL
        handle = kernel.GetStdHandle(-11)
        mode = wintypes.DWORD()
        return bool(kernel.GetConsoleMode(handle, ctypes.byref(mode))
                    and kernel.SetConsoleMode(handle, mode.value | 0x0004))
    except (OSError, AttributeError):
        return False


class LiveProgress:
    def __init__(self, events, tasks, initial, interval, log, plain=False):
        self.events = events
        self.state = ProgressState(tasks, initial)
        self.interval = interval
        self.log = Path(log)
        self.ansi = not plain and _enable_ansi()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._loop, name='uav-progress', daemon=True)
        self.t0 = time.monotonic()

    def start(self):
        self.log.parent.mkdir(parents=True, exist_ok=True)
        # Fail synchronously if the log cannot be opened, before starting workers.
        with self.log.open('a', encoding='utf-8') as fh:
            fh.write(f'\n# monitor start; baseline={self.state.baseline}; total={self.state.total}\n')
        print(f'[uav] progress log: {self.log.resolve()}', flush=True)
        self.thread.start()

    def _display(self, fh, write_log):
        panel = self.state.render(time.monotonic() - self.t0)
        print(('\x1b[H\x1b[2J' if self.ansi else '') + panel, flush=True)
        if write_log:
            fh.write(panel + '\n\n')
            fh.flush()

    def _loop(self):
        with self.log.open('a', encoding='utf-8') as fh:
            next_display = next_log = 0.0
            while True:
                try:
                    event = self.events.get(timeout=min(0.2, self.interval))
                    self.state.apply(event)
                    if event['kind'] in ('saved', 'done', 'skip', 'error'):
                        stamp = datetime.now(LOCAL_TZ).isoformat(timespec='seconds')
                        fh.write(f'[{stamp}] {event}\n')
                        fh.flush()
                except queue.Empty:
                    if self.stop.is_set():
                        self._display(fh, True)
                        return
                now = time.monotonic()
                if now >= next_display:
                    self._display(fh, now >= next_log)
                    next_display = now + self.interval
                    if now >= next_log:
                        next_log = now + max(30.0, self.interval)

    def finish(self):
        self.stop.set()
        self.thread.join()

"""Single registry of the images embedded in the manuscript.

Every figure that the paper shows lives in one folder, ``docs/figures``
(:data:`DIR`).  The manuscript scripts must obtain a path from here --
:func:`fig` for a single image, :func:`conv_series` for the convergence family
-- instead of joining a results directory themselves.  That keeps the adding and
deleting of a figure a one-place change:

* **add**    -- drop the file into ``DIR`` and add one line to :data:`REGISTRY`
  (plus :data:`SOURCE_DIR` if it can be refreshed from a plot script);
* **delete** -- remove the line; :func:`audit` then reports the leftover file,
  and any manuscript call site that still asks for the key fails at build time;
* **refresh** -- ``python src/paper_figures.py sync`` copies the current render
  of every entry from the script that produces it into ``DIR``.

An entry is normally a single file name, shared by both editions of the
manuscript.  The concept artwork of Sections 1 and 3 is drawn once per language,
so those entries map a language to a file name instead; :func:`set_lang` selects
the edition a build is rendering, and the other edition's renders are left in
``DIR`` without being reported as unused or as orphans.

The audit runs at the end of every paper build and reports four kinds of drift:
a registered image missing from ``DIR``, an image the manuscript embedded
without being registered, a registered image the manuscript never embedded, and
a file sitting in ``DIR`` that nothing refers to.  A clean build prints a single
``[figures] 28 embedded ... ok`` line.

Usage::

    python src/paper_figures.py check     # audit the folder on its own
    python src/paper_figures.py sync      # refresh docs/figures from the plots
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# The one folder that holds the manuscript images.
DIR = ROOT / 'docs' / 'figures'

# Renderers, kept separate from the paper folder: analysis output stays where
# the plotting scripts write it, and `sync` copies it across.
CEC_FIG = ROOT / 'results' / 'cec' / 'figures'
APP_FIG = ROOT / 'results' / 'apps' / 'figures'

# --------------------------------------------------------------------------
# key -> file name inside DIR.  Keys are what call sites ask for.  A value is
# either one file name shared by both editions, or a {language: file name}
# mapping for artwork that is drawn once per edition.
# --------------------------------------------------------------------------
# The manuscript editions this registry knows about.
LANGS = ('en', 'zh')
# The edition currently being rendered; build scripts select it with `set_lang`.
LANG = 'en'

REGISTRY = {
    # Sections 1 and 3 -- concept artwork (source files live in CEC_FIG).  These
    # four are drawn once per language, hence the per-edition mapping.
    'schematic_logic': {'en': 'fig_schematic_logic_en.png',
                        'zh': 'fig_schematic_logic.png'},
    'schematic_timeline': {'en': 'fig_schematic_timeline_en.png',
                           'zh': 'fig_schematic_timeline.png'},
    'schematic_hierarchy': {'en': 'fig_schematic_hierarchy_en.png',
                            'zh': 'fig_schematic_hierarchy.png'},
    'schematic_workflow': {'en': 'fig_schematic_workflow_en.png',
                           'zh': 'fig_schematic_workflow.png'},
    'schematic_descriptor': {'en': 'fig_schematic_descriptor_en.png',
                             'zh': 'fig_schematic_descriptor.png'},
    'schematic_actions': {'en': 'fig_schematic_actions_en.png',
                          'zh': 'fig_schematic_actions.png'},
    # Section 2 -- survey figures read off the variant table of Table 3.  These
    # are drawn outside this project and dropped into DIR by hand, so they are
    # excluded from SOURCE_DIR below and `sync` never touches them.
    'tax_timeline': 'fig4_mechanism_timeline.png',
    'tax_positioning': 'fig6_positioning_matrix.png',
    # The family-by-level panel of Table 3.  Drawn by
    # `src/plot_tax_families.py`, once per edition because the family labels
    # differ; it writes into DIR, so `sync` is not involved either.
    'tax_families': {'en': 'fig_tax_families_en.png',
                     'zh': 'fig_tax_families.png'},
    # Chapter 4 -- CEC study
    'attr_d1_assoc': 'attr_d1_assoc.png',
    'attr_d2_eta2_dot': 'attr_d2_eta2_dot.png',
    'attr_d6_attribution': 'attr_d6_attribution.png',
    'attr_d8_near_matrix': 'attr_d8_near_matrix.png',
    'conv_representative': 'conv_representative.png',
    # The same twenty variants at D=30 and D=50, one row per variant: the
    # gain ordering and the intervention-rate ordering both carry over.
    'dim_effect': 'fig_dim_effect.png',
    # Chapter 5 -- UAV interception scenario
    'uav_sandbox': 'fig_uav_sandbox_view.png',
    'uav_tasks': 'fig_uav_tasks.png',
    # The 2x2 function-landscape plate is rendered once per edition: only the
    # four panel labels differ (baseline/... vs 基线/...), the data and geometry
    # are identical -- see plot_scenario.fig_landscape_panel.
    'uav_landscape_3d': {'en': 'fig_landscape_3d.png',
                         'zh': 'fig_landscape_3d_zh.png'},
}
# The four rank-transfer scatters are pooled into one 2x2 grid; the per-task
# renders still exist in APP_FIG for the webapp panel but are not manuscript
# figures, so they are deliberately absent from the registry.
REGISTRY['uav_rank_scatter'] = 'fig_uav_rank_scatter_2x2.png'
REGISTRY['uav_mission'] = 'fig_uav_mission.png'
for _fid in (1, 2, 3, 4):
    REGISTRY['uav_traj_F%d' % _fid] = 'fig_uav_traj_F%d.png' % _fid

# key -> the directory the plot script writes it to.  A key absent from here is
# produced directly in DIR and must not be overwritten by `sync`.
SOURCE_DIR = {key: CEC_FIG for key in REGISTRY if not key.startswith('uav_')}
SOURCE_DIR.update({key: APP_FIG for key in REGISTRY if key.startswith('uav_')})
# The sandbox panels are screenshots assembled straight into DIR by
# `make_uav_sandbox_montage.py`, so there is no intermediate render to copy.
SOURCE_DIR.pop('uav_sandbox')
# The Section 2 survey figures are drawn elsewhere and placed in DIR by hand,
# so there is no render for `sync` to copy.
for _key in ('tax_timeline', 'tax_positioning', 'tax_families'):
    SOURCE_DIR.pop(_key, None)

# Chapter 4 embeds one convergence figure per (suite, dimension, page), split
# into parts so that every function stays legible at the text-column width.
CONV_SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10), ('cec2022', 20))
CONV_GLOB = 'conv_%s_D%d_p*_all.png'


def set_lang(lang):
    """Select the edition being built; call it before asking for a figure."""
    global LANG
    if lang not in LANGS:
        raise ValueError('unknown manuscript language %r; expected one of %s'
                         % (lang, ', '.join(LANGS)))
    LANG = lang


def _variants(key):
    """Every ``(language, file name)`` pair the entry ``key`` can resolve to.

    A shared entry yields one pair whose language is ``None``.
    """
    if key not in REGISTRY:
        raise KeyError('unknown paper figure %r; add it to '
                       'paper_figures.REGISTRY' % key)
    value = REGISTRY[key]
    if isinstance(value, str):
        return [(None, value)]
    return [(lang, value[lang]) for lang in LANGS if lang in value]


def _label(key):
    """File name ``key`` resolves to in the edition being built."""
    value = REGISTRY.get(key)
    if not isinstance(value, dict):
        return REGISTRY.get(key, key)
    return value.get(LANG, value['en'])


def fig(key):
    """Absolute path of the registered figure ``key``, for `Paper.figure`."""
    return str(DIR / _label(key))


def out_path(key):
    """Where the registry expects a generated figure to be written."""
    return DIR / _label(key)


def conv_series():
    """The convergence figures, as the list of dicts the manuscript expects.

    Each item is ``{'path', 'suite', 'dim', 'part', 'n_parts'}``; the glob runs
    over ``DIR`` so the series follows the folder, and a suite that has not been
    plotted yet simply contributes no item.
    """
    out = []
    for suite, dim in CONV_SUITES:
        parts = sorted(DIR.glob(CONV_GLOB % (suite, dim)))
        for k, p in enumerate(parts, start=1):
            out.append({'path': str(p), 'suite': suite, 'dim': dim,
                        'part': k, 'n_parts': len(parts)})
    return out


def sync(verbose=True):
    """Copy every registered render into ``DIR``, newest render wins."""
    if not DIR.exists():
        DIR.mkdir(parents=True, exist_ok=True)
    copied = 0
    for key in sorted(REGISTRY):
        src_dir = SOURCE_DIR.get(key)
        if src_dir is None:
            continue
        # Every edition of a per-language render is copied, so a build never
        # depends on `sync` having been run for that language last.
        for _lang, name in _variants(key):
            src = src_dir / name
            if not src.exists():
                if verbose:
                    print('[figures] %-30s no render at %s' % (key, src))
                continue
            dst = DIR / name
            fresh = dst.exists() and dst.stat().st_size == src.stat().st_size
            shutil.copyfile(src, dst)
            copied += 1
            if verbose:
                print('[figures] %-30s %s%s' % (key, name,
                                                ' (unchanged)' if fresh else ''))
    # The convergence pages are globbed rather than named, one at a time.
    for suite, dim in CONV_SUITES:
        for src in sorted(CEC_FIG.glob(CONV_GLOB % (suite, dim))):
            shutil.copyfile(src, DIR / src.name)
            copied += 1
            if verbose:
                print('[figures] %-30s %s' % ('conv ' + suite, src.name))
    if verbose:
        print('[figures] synced %d file(s) -> %s' % (copied, DIR))
    return copied


def audit(files, verbose=True, strict=False):
    """Compare the manuscript's embedded images with the folder and registry.

    ``files`` is the sequence of basenames a build actually embedded (see
    ``Paper.figure_files``).  Returns the list of ``(kind, name)`` problems and,
    unless ``verbose`` is off, prints them with a one-line summary.  With
    ``strict`` a non-empty problem list raises instead of only warning.
    """
    used = [Path(f).name for f in files]
    used_set = set(used)
    # This edition must embed every name it resolves to.  The other edition's
    # per-language renders are known files, so they are not orphans, but they
    # are not this build's business either.
    active = {_label(k) for k in REGISTRY}
    other = {n for k in REGISTRY if not isinstance(REGISTRY[k], str)
             for _l, n in _variants(k)} - active
    conv_globbed = {p.name for s, d in CONV_SUITES
                    for p in DIR.glob(CONV_GLOB % (s, d))}
    known = active | other | conv_globbed

    problems = []
    for name in sorted(active | conv_globbed):
        if not (DIR / name).exists():
            problems.append(('missing', name))
    for name in sorted(used_set - known):
        problems.append(('unregistered', name))
    for name in sorted(active - used_set):
        problems.append(('unused', name))
    on_disk = {p.name for p in DIR.glob('*') if p.is_file()}
    for name in sorted(on_disk - known - used_set):
        problems.append(('orphan', name))

    if verbose:
        for kind, name in problems:
            print('[figures] WARNING %-13s %s' % (kind, name))
        print('[figures] %d embedded, %d registered (%d by pattern), %d in %s '
              '-> %s'
              % (len(used_set), len(active), len(conv_globbed),
                 len(on_disk), DIR.name,
                 'ok' if not problems else '%d problem(s)' % len(problems)))
    if strict and problems:
        raise SystemExit('[figures] %d problem(s) between the manuscript and %s'
                         % (len(problems), DIR))
    return problems


def main():
    argv = sys.argv[1:] or ['check']
    cmd = argv[0]
    if cmd == 'sync':
        sync()
    elif cmd == 'check':
        audit([], strict=False)
        print('[figures] note: "check" without a build cannot tell which '
              'figures are unused; the paper build does the full audit')
    else:
        raise SystemExit(__doc__.strip().splitlines()[-4].strip())


if __name__ == '__main__':
    main()

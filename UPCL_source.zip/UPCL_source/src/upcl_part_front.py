# -*- coding: utf-8 -*-
"""Manuscript Part I - front matter: title, abstract, and the introduction.

Manuscript Part II (Section 2, background and related work) lives in
``upcl_part_bg.py``; keeping the two in separate files follows the rest of
the build, where each section is rendered by its own module.

The empirical claims made here are injected through ``S['scope']`` by the
builder, so this part stays valid when the experimental grid changes.
"""
import paper_figures as PFG

TITLE = ('The Candidate Generation Stage as a Probe: What a Variant-Agnostic Correction '
         'Layer Reveals About the Mechanisms of Differential Evolution')

AUTHORS = ['JIA HAOWEN']
AFFIL = ["Xi'an Technological University, China"]
EMAIL = ''


# ===========================================================================
def build(P, S):
    """Render Part I.

    ``S['scope']`` (optional) re-states the empirical scope for a study other
    than the one this part was first written for.  Every key defaults to the
    original wording, so existing builds are unaffected.
    """
    st = S.get('stats', {})
    pr = S.get('probe', {})
    n_pair = st.get('n_pool', st.get('n', 0))
    n_hosts = pr.get('n_hosts', 0)

    scope = S.get('scope', {})
    where = scope.get('where', 'a paired study on two benchmark suites')

    # ---------------------------------------------------------------------
    P.title_block(TITLE, AUTHORS, AFFIL, EMAIL)

    P.abstract(
        'Progress in differential evolution (DE) has largely come from '
        'adding or replacing a mechanism inside a specific variant and '
        'checking whether the result optimises better. What the field has '
        'not had is a systematic measurement of which of these mechanisms '
        'actually steer the search, and by how much. '
        'We build that measurement by turning the candidate generation stage of DE into '
        'an observation point. The instrument is the Universal Candidate '
        'Correction Layer (UPCL), a wrapper attached to any DE variant that '
        'reads the move from parent to candidate, describes it with five '
        'dimensionless features, and applies the least-distorted correction '
        'whose estimated gain exceeds its cost. Because UPCL intervenes '
        'identically on every variant and costs no extra evaluation, its '
        'intervention rate and descriptor contrasts form a '
        f'mechanism fingerprint directly comparable across {n_hosts} '
        'variants. '
        f'Across {where}, the layer is inert where it matters: the median '
        'variant moves by at most $0.01$ decades of $\\log_{10}$ error in every '
        'block, the block means lie between $-0.08$ and $-0.01$ decades, and '
        'the gain is negative on the fixed-parameter variants, positive only on '
        'the lightly adapted ones, and indistinguishable from zero on the '
        'success-history variants, whose intervention rate is 2.6% or lower. The '
        'mechanisms that make modern DE win are therefore substitutive rather '
        'than additive, they already act at the candidate generation stage '
        'where a correction layer would act. This is why modern DE is hard to '
        'improve from outside the variant, and why the candidate generation stage is better '
        'read as an observation point than as an intervention point. The same '
        'instrument is then carried into a four-task UAV interception scenario '
        'to test its readings outside the benchmark suites.')

    P.keywords(
        'differential evolution; mechanism contribution; candidate-generation '
        'probe; variant-agnostic intervention; mechanism fingerprint; problem '
        'dependence; substitutable mechanisms; paired comparison')

    # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    P.h1('1  Introduction')
    P.para(
        'Differential evolution (DE) is a population-based, '
        'derivative-free optimiser for continuous search spaces, introduced '
        'by Storn and Price [@DE97] and developed in the monograph of Price '
        'et al. [@PRICE_BOOK]. Its canonical form exposes three control '
        'parameters and one mutation family, and it '
        'remains competitive over a wide range of numerical problems, which '
        'explains why it has attracted so much work. Two surveys, '
        'separated by five years, record that development '
        '[@DAS_SURVEY11][@DAS_SURVEY16], and the recent surveys of mechanism-level '
        'taxonomy list the variants by the mechanism each adds '
        '[@NERI10][@KARAFOTIAS15]. Since the canonical form holds its control '
        'parameters fixed, most of that work has been directed at choosing '
        'them during the search.')
    P.para(
        'A variant of DE is usually described by four ingredients: the '
        'mutation strategy that builds a donor vector, the crossover that '
        'mixes it with the target, the selection that decides what survives, '
        'and the rules that set the control parameters, the scale factor, '
        'the crossover rate and the population size. '
        'Almost every DE paper of the last two decades changes one of these '
        'four, most often the parameter rules: a perturbation '
        'of the control parameters that adapts them during the run '
        '[@SELFADAPT_DE06], a memory of successful parameter values combined '
        'with an archive and elite-directed mutation [@JADE][@SHADE], a '
        'linear reduction of the population size over the budget '
        '[@LSHADE], a tuned combination of these for a fixed competition '
        'budget [@JSO], pools of strategies and parameters with online '
        'credit assignment [@SADE][@EPSDE][@CODE], and controllers '
        'trained by deep reinforcement learning [@SHARMA19][@DRLDAS24]. The '
        'resulting literature is large enough to be surveyed and '
        'benchmarked as a subject in itself [@TANABE_BENCH]'
        '[@KARAFOTIAS15].')

    P.para(
        'These mechanisms differ considerably, from a random '
        'walk on a parameter through a Lehmer-weighted memory of successful '
        'values to an ensemble with credit assignment and a learned policy, '
        'but they can be ordered a second way, by the object each one modifies, '
        'and along that axis the field is less diverse than the count of '
        'variants suggests.')
    P.para(
        'Reading three decades of work by the object it modifies reduces '
        'the field to nine mechanism families: the donor structure, which '
        'builds the difference term and the base vector; the crossover '
        'structure, which decides how donor coordinates enter the trial; the '
        'scale-and-rate rule, which sets the scale factor $F$ and the crossover '
        'rate $CR$ during the run [@SELFADAPT_DE06][@SHADE][@JSO]; the '
        'population size, which is reshaped over the budget [@LSHADE]; the '
        'selection rule, which decides which trial survives; the operator '
        'ensemble, which chooses among donors or parameter sets and assigns '
        'them credit [@SADE][@EPSDE][@CODE][@IMODE]; the restart and '
        'stagnation trigger; the candidate correction, which acts on a trial '
        'that has already been built; and the meta-level composition of '
        'several of these, up to the selection of the algorithm itself '
        '[@MPEDE][@SHADEILS][@STANOVOV22]. The nine partition the entries of '
        'Section 2 without remainder, and every one of the twenty-nine '
        'variants studied here is located in them; for the statistical '
        'attribution of Section 4 those families are recoded on the six '
        'mechanism dimensions that vary across this pool, a reduction '
        'described in Section 2.')
    P.para(
        'Along a second axis - how much of this machinery a variant has '
        'accumulated - the same variants fall into four composition levels. '
        'Level 0 variants keep every quantity fixed and differ only in their '
        'mutation strategy; Level 1 variants add self-adaptation of $F$ and '
        '$CR$; Level 2 variants add a success-history memory with an external '
        'archive, or an ensemble credit rule; Level 3 variants add '
        'population-size reduction with selective pressure, the combination '
        'that has won most CEC competitions since 2014 '
        '[@LSHADE][@JSO][@NLSHADE_RSP]. The levels are a statement about '
        'mechanism composition, not about adaptivity, and they are not a '
        'performance ladder: a variant can reach a high level without '
        'performing well, as the measurements of Section 4 show. Their '
        'purpose is to let us ask the question about mechanisms '
        'rather than about names.')
    P.figure(
        PFG.fig('schematic_timeline'),
        'Evolution of DE mechanism families, drawn at the six-dimension '
        'resolution used for the attribution, which recodes the nine families '
        'of Section 2 onto six dimensions: one row per dimension, '
        'one marker per variant that introduces or elaborates it, coloured by '
        'its composition level.',
        note='Positioning diagram compiled from the cited literature; it '
             'carries no measured value.')
    P.para(
        'Ordered in either way, all of these '
        'mechanisms share one structural property: every one of them '
        'intervenes before the candidate exists, by deciding which '
        'mechanism, with which parameters, should produce the next '
        'candidate.')
    P.para(
        'That common placement has a consequence for generality. Because '
        'the intervention is located inside the variant, the reach of any one '
        'scheme is bounded by the interface it requires: a mechanism '
        'modulating the scale factor has no effect on a variant that has none, '
        'an archive manager conflicts with a variant maintaining its own '
        'archive, and a strategy selector can be installed only on variants '
        'exposing a strategy pool. Even the most variant-independent schemes at '
        'these levels, such as a configuration policy over a module space or '
        'a dynamic selection among variants, must be able to name the '
        'component they configure. Variant independence is therefore obtained '
        'one family at a time, in special cases, rather than by '
        'construction. This limitation follows from where those methods act, '
        'and it raises the question pursued in Section 3, whether anything can be '
        'said about the family as a whole from outside the variant.')

    P.para(
        'What we work with sits later than any of them, at the instant at '
        'which the variant has committed to a candidate but has not yet '
        'spent an evaluation on it, and forms no part of the variant. The '
        'choice rests on one reproduction '
        'pattern shared by the whole family: every DE variant, however its '
        'components differ, emits exactly one candidate for each member of '
        'the current population, and the move from parent to candidate is '
        'available to any component given the two.')
    P.para(
        'That move is the output by which variants are distinguished, and '
        'no member '
        'of the family can search without producing it, so a mechanism '
        'operating on the pair applies to the family as a whole, including '
        'variants whose internals it has not been told about. A DE-like search '
        'can instead be written without a scale factor, as in a '
        'covariance-driven sampler, without an archive, or with a mutation '
        'operator that is not drawn from a discrete pool; in each of these '
        'cases a parameter-level or component-level controller has to be '
        're-derived for the new design, and one acting on the pair does '
        'not.')
    P.para(
        'Such a mechanism admits two possible uses. The first reads it as a '
        'third point of intervention: after the variant has committed to '
        'a candidate, adapt the candidate itself and thereby improve the '
        'search. The evidence does not support that '
        'reading: over a large paired grid the correction '
        'layer, however configured, yields no systematic gain on the variants '
        'that matter, its gain being negative on the fixed-parameter variants, '
        'positive only on the lightly adapted ones, and indistinguishable from '
        'zero on the success-history variants. What survives is the '
        'instrument. A layer that intervenes '
        'identically on every variant turns each variant\'s reaction to the '
        'intervention (whether its candidates can be improved, and by how '
        'much) into a measurement, and a set of such measurements reads '
        'the family along an axis that no variant-side quantity exposes. The '
        'contribution is that reading, organised around four '
        'questions.')
    P.bullet(
        'RQ1 (mechanism contribution). Which of the mechanisms in that '
        'decomposition actually steer the search, and how much does each '
        'contribute? The bare-performance gradient across the composition '
        'levels gives the size of each contribution, and the fingerprint each '
        'mechanism induces in the candidate stream shows how it acts.',
        style='Numbered')
    P.bullet(
        'RQ2 (problem dependence). Where does a mechanism\'s contribution '
        'sit: does it move with the function class (unimodal, multimodal, '
        'hybrid or composite), with dimensionality, or from one problem '
        'instance to the next? Conditioning the fingerprint on the class, on '
        'the dimension and on the instance reads that distribution off '
        'directly.',
        style='Numbered')
    P.bullet(
        'RQ3 (substitutability and redundancy). To what extent are the '
        'contributing mechanisms substitutable for one another, or for a '
        'generic candidate-generation correction? The intervention gain '
        'measures it directly: a mechanism whose contribution a generic '
        'correction cannot replace has internalised that contribution, '
        'whereas one that leaves externally recoverable slack has not.',
        style='Numbered')
    P.bullet(
        'RQ4 (why modern DE is hard to improve). Why does the room for '
        'external improvement shrink as variants become more capable? '
        'RQ1-RQ3 give one explanation: the winning mechanisms are substitutive, '
        'so they already occupy the very level at which a correction layer '
        'acts, leaving it nothing to recover.',
        style='Numbered')
    P.para(
        'In this reading the word universal in the name of the layer takes '
        'on a second, more precise sense. It refers not to the reach of a '
        'correction, which the measurements of Section 4 show to be bounded, '
        'but to the reach of the observation: because the same intervention '
        'is applied to every variant, the differences between variants cannot be '
        'attributed to the instrument, and what remains is a difference in '
        'the variant itself. This section states the construction.')

    P.para(
        'The Universal Candidate Correction Layer (UPCL) instantiates the '
        'idea as a wrapper attached to an arbitrary DE variant. Once per '
        'generation and per member of the population it receives the parent '
        'and the candidate the variant has generated for it, in place of any '
        'variant internal state. From that pair it computes a '
        'five-dimensional descriptor of the generated step, encoding its '
        'scale relative to the spread of the population, its agreement with '
        'directions that have recently succeeded, its agreement with the '
        'direction of the current elite, the crowding at its landing point '
        'and its directional novelty. It then queries an online '
        'non-parametric model that returns, for each available correction, '
        'an estimate of the response that correction has produced in similar '
        'states, and applies the correction that maximises estimated response '
        'minus an explicit intervention cost, with the identity treated as a '
        'privileged action carrying a bonus.')
    P.para(
        'The variant then evaluates the corrected vector with the single '
        'evaluation it would have spent in any case, and performs its own '
        'selection, its own archive update and its own memory update without '
        'knowing that anything happened. The construction is given '
        'in Section 3 and summarised as Algorithm 2.')
    P.para(
        'Three properties of this construction follow directly from its '
        'definition and are stated with proofs in Section 3. Opacity: the information '
        'available to the layer consists of the population, the fitness '
        'values, the candidate and the scalar response, while the variant scale '
        'factor, the crossover rate, the archive, the strategy index and '
        'every variant-side success memory are neither read nor written. Zero '
        'evaluation overhead: the candidate is replaced rather than '
        'augmented, so the evaluation accounting of the wrapped variant '
        'coincides with that of the bare variant and a paired comparison of '
        'the two at equal budget needs no convention. Identity safety, in a '
        'conditional sense: when '
        'the response model holds no evidence that a correction pays, the '
        'layer returns the candidate unchanged, so the layer can only degrade '
        'a variant through estimation error, and the size of that error is '
        'measured rather than assumed absent.')
    P.para(
        'The first two properties keep the instrument out of the '
        'comparison it is used for: the layer neither reads nor writes '
        'variant state, and replacing the candidate rather than augmenting '
        'it leaves the wrapped variant with the same evaluation accounting '
        'as the bare variant, so a difference between the two cannot come '
        'from extra function evaluations. Identity safety is conditional: it '
        'holds while the estimated sign is right, and where the estimate is '
        'wrong the realised gain is negative. The wrap is not therefore '
        'invisible, since whenever the layer intervenes it changes the '
        'candidate stream the variant selects from, and that effect is '
        'measured rather than assumed away. A fourth quantity is then treated differently '
        'from the others: the rate at which the layer intervenes is set by '
        'the evidence rather than configured, and it is this rate, rather '
        'than any single correction, that carries the measurement. As '
        'derived in Section 3 and confirmed by the measurements, the rate falls as '
        'the variant internalises the candidate-generation adjustments the layer '
        'would otherwise make.')
    P.para(
        'On that basis the contributions are as follows.')
    P.bullet(
        'The candidate generation stage as a probe. Every DE variant '
        'publishes its behaviour as a move from a parent to a candidate; '
        'that observable is treated here not as a third point of '
        'intervention but as a point of observation, and is instantiated as '
        'UPCL: a dimensionless descriptor of the candidate, an online '
        'non-parametric response model, and a decision rule whose default '
        'action is the identity.',
        style='Numbered')
    P.bullet(
        'A mechanism decomposition and fingerprint for differential '
        'evolution. The literature is partitioned into nine mechanism families, '
        'the twenty-nine variants are located in them and in four composition '
        'levels, and the three observables '
        'UPCL records (the intervention rate, the intervention gain and '
        'the descriptor contrasts) are assembled into a per-variant mechanism '
        'fingerprint that is directly comparable across variants and across '
        'problem classes.',
        style='Numbered')
    P.bullet(
        'An evidence-based account of mechanism contribution, problem '
        'dependence and substitutability. The paired study answers '
        'RQ1-RQ4, locating the contribution in a few substitutive '
        'mechanisms, showing that it varies strongly from problem instance to '
        'problem instance and hardly at all across function classes, and '
        'explaining from that dependence why modern DE is hard to improve '
        'from outside the variant.',
        style='Numbered')
    P.para(
        'The correction operators are classical; the contribution of UPCL is '
        'the measurement it enables, a variant-comparable mechanism fingerprint '
        'and an evidence-based account of which mechanisms drive the search, '
        'on which problems, and why.')

    P.para(
        'The rest of the paper turns this construction into the '
        'measurement promised in Section 1: it recalls the canonical DE and the '
        'variants that the literature tables collect, orders them into nine '
        'mechanism families and four composition levels, recodes the families '
        'on six dimensions for the attribution, constructs the '
        'probe with its three '
        'observables, and reports what the paired study measures about '
        'mechanism contribution, problem dependence and substitutability.')
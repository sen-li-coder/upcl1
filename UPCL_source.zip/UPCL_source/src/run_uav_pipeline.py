# -*- coding: utf-8 -*-
"""UAV 实验编排：等待 ``run_uav.py`` 跑完 -> 分析 -> 绘图。

后台运行本脚本，它会轮询 ``results/apps/raw/uav_intercept/D30``，当全部
``N_CELLS`` 个 cell 的 ``runs_complete >= MIN_RUNS`` 后，依次执行分析层与
绘图层，最终打印 ``ALL DONE``。

用法：``python -u src/run_uav_pipeline.py``（后台 + 日志重定向）
"""
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'apps' / 'raw' / 'uav_intercept' / 'D30'

N_CELLS = 116          # 29 宿主 × 4 任务
MIN_RUNS = 3
POLL_SEC = 120


def cells_done():
    n = total = 0
    for p in RAW.glob('*.json'):
        total += 1
        try:
            d = json.load(open(p, encoding='utf-8'))
        except Exception:
            continue
        if d.get('runs_complete', 0) >= MIN_RUNS:
            n += 1
    return n, total


def run(cmd):
    print(f'[pipeline] $ {cmd}', flush=True)
    r = subprocess.run(cmd, shell=True, cwd=str(ROOT))
    print(f'[pipeline] exit={r.returncode}', flush=True)
    if r.returncode != 0:
        raise SystemExit(f'pipeline abort on: {cmd}')


def main():
    print(f'[pipeline] waiting for {N_CELLS} cells (min {MIN_RUNS} runs) under '
          f'{RAW}', flush=True)
    while True:
        n, total = cells_done()
        print(f'[pipeline] cells done {n}/{total} (target {N_CELLS})', flush=True)
        if n >= N_CELLS and total >= N_CELLS:
            break
        time.sleep(POLL_SEC)

    run('python src/analyze_uav.py --scenario intercept --min-runs 3')
    run('python src/analyze_uav_events.py --scenario intercept')
    run('python src/analyze_uav_rank.py --min-runs 3')
    run('python src/analyze_uav_mech.py --min-runs 3')
    run('python src/analyze_uav_robust.py --min-runs 3')
    run('python src/plot_uav_paper.py')
    run('python src/plot_uav_trajectory.py --grid')
    run('python src/paper_figures.py sync')
    print('[pipeline] ALL DONE', flush=True)


if __name__ == '__main__':
    main()

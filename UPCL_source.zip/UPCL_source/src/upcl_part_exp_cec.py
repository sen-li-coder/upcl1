# -*- coding: utf-8 -*-
"""Manuscript Part III (CEC edition) - empirical study of UPCL on the CEC
single-objective suites.

Every number printed here is read from the tables written by
``analyze_upcl_cec.py`` into ``results/cec/tables``, so the section can be
regenerated as the grid grows; nothing is hard-coded.
"""

import statistics

import paper_figures as PFG


# ---------------------------------------------------------------------------
def _f(v, n=3, sign=False):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    if x != x:  # NaN -> leave blank
        return '-'
    if not sign:
        return f'{x:.{n}f}'
    s = f'{x:+.{n}f}'
    # A value that rounds to zero must not print as a signed zero ('-0.00').
    return f'{0.0:.{n}f}' if float(s) == 0.0 else s


def _mean(rows, key):
    vals = [float(r[key]) for r in rows if r.get(key) not in (None, '', 'nan')]
    return sum(vals) / len(vals) if vals else float('nan')


def _nullband():
    """Per-block zero-reference band, from ``null_band_summary.csv``.

    Written by ``analyze_null_band.py``.  Returns ``{}`` when the table has
    not been produced, in which case the paragraph that quotes it is skipped
    rather than printed with placeholders.
    """
    import csv
    from pathlib import Path
    path = (Path(__file__).resolve().parents[1] / 'results' / 'cec' / 'tables'
            / 'null_band_summary.csv')
    out = {}
    try:
        with open(path, encoding='utf-8') as fh:
            for r in csv.DictReader(fh):
                key = '%s/%d' % (r['suite'], int(float(r['dim'])))
                out[key] = {k: float(v) for k, v in r.items() if k != 'suite'}
    except (FileNotFoundError, KeyError, ValueError):
        return {}
    return out


def _blk_read(sub):
    """Extremes and counts of one paired block, as quoted in Section 4.2.

    ``sub`` holds the host rows of a single (suite, dimension) block, so every
    number below is read off the table that block contributes.
    """
    def fv(r, k):
        return float(r[k])
    rho = sorted(sub, key=lambda r: fv(r, 'rho'))
    dec = sorted(sub, key=lambda r: fv(r, 'dec_mean'))
    byrank = sorted(sub, key=lambda r: int(r.get('rank', 999)))
    top5 = [fv(r, 'dec_mean') for r in byrank[:5]]
    return {
        'n': len(sub),
        'rho_lo': (rho[0]['host'], fv(rho[0], 'rho')),
        'rho_hi': (rho[-1]['host'], fv(rho[-1], 'rho')),
        'rho_med': statistics.median([fv(r, 'rho') for r in sub]),
        'rho_top3': [r['host'] for r in rho[-3:]],
        'dec_lo': (dec[0]['host'], fv(dec[0], 'dec_mean')),
        'dec_hi': (dec[-1]['host'], fv(dec[-1], 'dec_mean')),
        'dec_med': statistics.median([fv(r, 'dec_mean') for r in sub]),
        'dec_mean': sum(fv(r, 'dec_mean') for r in sub) / len(sub),
        'n_pos': sum(1 for r in sub if fv(r, 'dec_mean') > 0),
        'n_small': sum(1 for r in sub if abs(fv(r, 'dec_mean')) <= _CELL_TOL),
        'n_mismatch': sum(1 for r in sub
                          if fv(r, 'dec_mean') * fv(r, 'ri_mean') < 0),
        'dec': {r['host']: fv(r, 'dec_mean') for r in sub},
        'rank': {r['host']: int(r.get('rank', 0)) for r in sub},
        # Holm-corrected cell counts of the block, by variant: a win is a
        # function on which the layer is significantly better after the
        # correction, a loss the reverse; the rest are ties.
        'wins': {r['host']: int(float(r.get('wins') or 0)) for r in sub},
        'losses': {r['host']: int(float(r.get('losses') or 0)) for r in sub},
        'n_cells': {r['host']: int(float(r.get('cells') or 0)) for r in sub},
        'cells': int(sum(int(float(r.get('cells') or 0)) for r in sub)),
        'rho': {r['host']: fv(r, 'rho') for r in sub},
        'top5_abs': max((abs(v) for v in top5), default=0.0),
        'dec_top5_ranks': [int(r.get('rank', 0)) for r in
                           sorted(sub, key=lambda r: -fv(r, 'dec_mean'))[:5]],
    }


def _next_table(P):
    """Number the next table will carry, for forward cross-references."""
    return P.tab_no + 1


def build(P, S):
    _protocol(P, S)
    _paired(P, S)
    _grid(P, S)
    _mechanism(P, S)


# ===========================================================================
# 4.1  Protocol
# ===========================================================================
def _protocol(P, S):
    pr = S['protocol']
    P.h1('4  Experimental study')

    P.h2('4.1  Protocol')
    P.para(
        'Each observation pairs one benchmark function, one dimensionality '
        'and one variant search algorithm, and every such pair is run in two '
        'configurations that differ in exactly one respect (the variant '
        '$H$ alone, and the same variant with UPCL attached) and each '
        'configuration is repeated for the same number of independent runs. '
        'A run therefore has one seed, and that seed is shared by the two '
        'configurations: they start from the same population, receive the '
        'same budget $B=10^{4}D$ evaluations, and differ only in whether the '
        'candidate vector $u_i$ leaving the variation and crossover stage is '
        'passed straight to evaluation or routed through the layer first. '
        'Nothing else (population size, initial sampling, evaluation order, '
        'termination) is allowed to vary.')
    P.para(
        'The problems are the '
        'bound-constrained single-objective suites CEC 2017 [@CEC17] and '
        'CEC 2022 [@CEC22], which group their functions into four declared '
        'categories: unimodal, multimodal, hybrid and composite. The variants '
        f'are the twenty-nine algorithms of Table {_next_table(P) + 1}: '
        'DE/rand/1, '
        'DE/best/1, DE/rand/2, DE/current-to-best/1, DE/current-to-rand/1, '
        'DE/rand/1/either-or, jDE, SaDE, SaNSDE, CoDE, EPSDE, CoBiDE, JADE, '
        'SHADE, MPEDE, L-SHADE, L-SHADE-RSP, jSO, NL-SHADE-RSP, MadDE, jDE100, '
        'j2020, DISH, DISK, LSHADE-cnEpSin, SinDE, IMODE, PaDE and SHADE-ILS. '
        f'Table {_next_table(P) + 1} groups them by the adaptivity level they '
        'apply, so '
        'that the layer\'s effect can be read as a function of which mechanism '
        'each variant already provides. Twenty-six of the twenty-nine are '
        'among the seventy-nine named variants of Tables 1 and 2, the other '
        'three are the classical donors of Section 1, and every composition '
        'level of Table 3 has at least one representative in the pool.')
    P.para(
        'Two features of the protocol are stated here rather than left to the '
        'tables. CEC 2017 is evaluated on twenty-nine of its thirty functions: '
        'the originally published $F_2$ was withdrawn by the benchmark authors '
        'as numerically unstable and is absent from the reference '
        'implementation, so every count in this section refers to '
        'twenty-nine functions and does not match a figure quoted for the '
        'full set in the literature. The budget is $10^4 D$ function '
        'evaluations per run, the protocol of the two suites, and it is the '
        'budget of the bare arm and of the wrapped arm alike, so the layer '
        'spends no evaluation of its own.')
    P.para(
        'Performance is read through two effect sizes. The primary one is '
        'the decades of error removed:')
    P.equation(
        r'\mathrm{dec}=\log_{10}\tilde{e}_{H}-\log_{10}\tilde{e}_{\mathrm{UPCL}},')
    P.para(
        r'where $\tilde{e}$ is the median final error over the runs of one '
        r'configuration and $e=f(x)-f^{\star}$ is floored at $10^{-8}$ before '
        r'the logarithm; one unit is one order of magnitude. Its bounded '
        r'counterpart is the relative improvement')
    P.equation(
        r'\mathrm{ri}=\frac{\bar{e}_{H}-\bar{e}_{\mathrm{UPCL}}}'
        r'{\max(\bar{e}_{H},\bar{e}_{\mathrm{UPCL}},10^{-8})},')
    P.para(
        r'which lies in $[-1,1]$ and is positive whenever attaching UPCL '
        r'lowers the mean error; it stays meaningful once a variant has reached '
        r'machine precision, where the usual $(e_{H}-e_{\mathrm{UPCL}})/'
        r'|e_{H}|$ diverges. Every such pair is also compared with a two-sided '
        r'paired Wilcoxon signed-rank test over its runs, following the '
        r'non-parametric comparison methodology of [@DERRAC11][@GARCIA10]. The '
        r'protocol is fixed '
        f'for every comparison and is collected in Table {_next_table(P)}.')
    P.para(
        r'The protocol follows what the benchmarking literature recommends, '
        r'because the quantities at stake are small. Anytime performance '
        r'under a fixed evaluation budget is the primary currency of black-box '
        r'benchmarking platforms [@HANSEN_COCO21], so every comparison here is '
        r'made at exactly $10^{4}D$ evaluations and never against a wall-clock '
        r'budget. Because hundreds of pairs are tested at once, the family-wise '
        r'error is controlled by the Holm step-down procedure applied to the '
        r'paired signed-rank test, which is the combination recommended for '
        r'multiple comparisons across algorithms and functions '
        r'[@HOLLANDER99][@BENAVOLI16]; the uncorrected $p$-values are reported '
        r'next to the corrected verdicts rather than instead of them, in line '
        r'with the caution that a threshold alone does not measure evidence '
        r'[@WASSERSTEIN16]. Effect sizes accompany the tests for the same '
        r'reason: with thirty runs per cell a paired test can resolve '
        r'differences far below any practical relevance, so power and '
        r'magnitude are stated together [@COHEN88]. The design, with seeds, '
        r'budget and implementation held fixed and one factor varied, is the '
        r'one an analysis-of-experiments treatment of the same question would '
        r'prescribe [@MONTGOMERY12], and it is reported in full so that the '
        r'tables can be regenerated from the archived runs, which is the '
        r'practice the reproducibility literature asks of empirical studies '
        r'[@NOSEK18].')

    P.table_caption('Protocol of the paired CEC experiments. Every entry is '
                    'generated from the result tables, so it follows the '
                    'grid.')
    rows = [
        ['Benchmark suites', pr['suites']],
        ['Dimensions reported', pr['dims']],
        ['Problems', pr['problems']],
        ['Evaluation budget', pr['budget']],
        ['Variants', pr['hosts']],
        ['Population size', pr['pops']],
        ['Runs per configuration', pr['runs']],
        ['Pairing', pr['pairing']],
        ['Comparisons reported', pr['cells_line']],
        ['Effect sizes', pr['metrics']],
        ['Layer configuration', pr['config']],
    ]
    P.table(['Item', 'Setting'], rows, widths=[1.5, 5.0], align='ll',
            font_size=8.5)

    P.para(
        'The variant table groups the twenty-nine algorithms by their mechanism '
        'composition, so that every level of the accumulation is represented, '
        'from fixed-parameter donors whose candidates the layer can directly '
        'adjust to state-of-the-art winners whose internal mechanisms already '
        'govern the search. The six fixed-parameter '
        'donors of Section 2 isolate the layer\'s own contribution: with '
        'no internal adaptation to interfere with, any change in their '
        'trajectory is attributable to the layer. The adaptive variants grow in '
        'strength from per-individual parameter encoding, through operator '
        'pools and success-history memory, to population-size reduction and '
        'multi-operator ensembles; each such mechanism is a candidate answer '
        'to the question of what steers the search, and Section 4 reads the '
        'layer\'s effect as a function of which mechanism the variant already '
        'provides.')

    P.table_caption('Variants used in Section 4, grouped by mechanism '
                    'composition level. Level 0 keeps fixed parameters; '
                    'level 1 encodes parameters per individual; level 2 adds '
                    'strategy adaptation; level 3 adds population-size '
                    'control or a second mechanism.')
    P.table(
        header=['Level', 'Variants (abbreviation)', 'Why this group is used'],
        rows=[
            ['0', 'DE/rand/1, DE/best/1, DE/rand/2, DE/current-to-best/1, '
             'DE/current-to-rand/1, DE/rand/1/either-or',
             'a fixed-parameter donor the layer can correct without touching '
             'internal adaptation'],
            ['1', 'jDE, SaNSDE, jDE100, j2020, SinDE',
             'per-individual parameter encoding and periodic schedules, the '
             'earliest adaptation'],
            ['2', 'JADE, SHADE, CoBiDE, SaDE, EPSDE, CoDE, MPEDE, DISH, '
             'DISK, PaDE',
             'operator pools, ensembles and success-history memory, the '
             'dominant mid-generation designs'],
            ['3', 'L-SHADE, jSO, L-SHADE-RSP, NL-SHADE-RSP, MadDE, '
             'LSHADE-cnEpSin, IMODE, SHADE-ILS',
             'the LPSR family and recent competition winners: the layer must '
             'stay neutral against them'],
        ],
        widths=[0.5, 3.2, 2.6], font_size=7.0, align='c l l')

    P.para(
        'Attaching the layer changes one thing only: the candidate $u_i$ '
        'that leaves variation and crossover is either evaluated directly or '
        'passed through the layer first. A layer that decides not to '
        'intervene returns $u_i$ unchanged, so the two configurations spend '
        'exactly the same evaluations and a non-intervening layer is '
        'indistinguishable from no layer at all; the comparison therefore '
        'isolates the added mechanism.')

    P.para(
        'Four indices turn the paired results into a reading of the DE '
        'family, each reducing one property of a variant to a number.')
    P.bullet(
        '\\textbf{Variant-alone rank.} The rank of a variant\'s median final '
        'error across the functions, the medians being taken in log-10 space; '
        'it measures what the variant already achieves before the layer is '
        'attached.',
        style='Numbered')
    P.bullet(
        '\\textbf{Intervention rate} $\\bar\\rho=\\tfrac{1}{T}\\sum_{t=1}^{T}'
        '\\rho_t$: the fraction of candidates the layer modifies, averaged '
        'over generations, i.e. the share of the variant\'s own candidate '
        'generation that the layer has to correct.',
        style='Numbered')
    P.bullet(
        '\\textbf{Intervention gain} $\\mathrm{dec}$ and $\\mathrm{ri}$ '
        'defined in Section 4.1: the error removed once those corrections '
        'take effect.',
        style='Numbered')
    P.bullet(
        '\\textbf{Descriptor contrast} $\\Delta\\phi_k=(\\bar\\phi_k^{+}-'
        '\\bar\\phi_k^{-})/\\sigma_k$: the standardised shift of candidate '
        'feature $k$ between accepted and rejected interventions; it '
        'localises the geometric conditions under which a candidate is '
        'improvable.',
        style='Numbered')
    P.para(
        'Read together by mechanism family, these four indices answer the '
        'question Section 2 left open: which way of improving DE actually '
        'pays.')


# ===========================================================================
# 4.2  Paired results
# ===========================================================================
def _paired(P, S):
    cells = S['cells']
    hsum = S['hosts']
    pr = S.get('probe', {})
    bare_top1 = pr.get('bare_top1', 'NL-SHADE-RSP')
    P.h2('4.2  The intervention rate and the gain')

    _paired_blocks = (('cec2017', '30'), ('cec2022', '10'),
                      ('cec2022', '20'), ('cec2017', '50'))
    _blk = {}
    for _bs, _bd in _paired_blocks:
        _sub0 = [r for r in hsum
                 if (r.get('suite'), str(r.get('dim'))) == (_bs, _bd)]
        if _sub0:
            _blk[(_bs, _bd)] = _blk_read(_sub0)
    A = _blk[('cec2017', '30')]
    B = _blk[('cec2022', '10')]
    C = _blk[('cec2022', '20')]
    # The D=50 block became a full block on 2026-10-22 (all twenty-nine
    # variants, thirty runs): the wave-4 cells were imported from
    # E:\cec2017\D50.  The sentence that quotes it is still skipped when the
    # block is absent rather than printed with stale numbers.
    D = _blk.get(('cec2017', '50'))
    _dt = S.get('dim_transfer') or {}

    def _dv(metric, default=float('nan')):
        try:
            return float(_dt[metric]['value'])
        except (KeyError, TypeError, ValueError):
            return default

    def _dp(metric, default=float('nan')):
        try:
            return float(_dt[metric]['p'])
        except (KeyError, TypeError, ValueError):
            return default

    t_a = _next_table(P)

    P.para(
        f'Tables {t_a} to {t_a + 3} carry the paired result in full, one table '
        'per block of thirty runs per configuration: the twenty-nine '
        'registered variants on CEC 2017 at $D=30$, the same family on '
        'CEC 2022 at $D=10$ and at $D=20$, and the same twenty-nine variants '
        'again on CEC 2017 at $D=50$. The left half '
        'of each '
        'table is the variant on its own, its rank within the block and its '
        'median final error; the right half is the same seeds with the layer '
        'attached, read through the three paired indices of Section 4.1, so '
        'the four tables answer, variant by variant, how often the layer '
        'intervenes and what those interventions are worth.')
    P.para(
        'Before the tables are read it matters how rarely the layer acts. The '
        'identity action accounts for about $95\\%$ of all proposals at the '
        'configuration used here, so the block-level gain reported below is '
        'the gain of a layer that is close to the identity map, and a value '
        'near zero has two readings that this experiment cannot separate: '
        'that no slack exists in the host, or that the layer declined to act '
        'where slack existed. Both are kept open in Section 4.4, and the '
        'intervention designed to separate them is listed in the data '
        'release rather than assumed away here.')
    for _bi, (_bs, _bd) in enumerate(_paired_blocks):
        _sub = [r for r in hsum
                if (r.get('suite'), str(r.get('dim'))) == (_bs, _bd)]
        if not _sub:
            continue
        _tag = ('a', 'b', 'c', 'd')[_bi]
        P.table_caption(
            f'Exp. 1{_tag}, variant-alone rank and accuracy on {_bs} at '
            f'$D={int(_bd)}$: per variant, rank, median final error '
            '(lower is better; the medians are taken in log-10 space and '
            'back-transformed), dec, ri and mean intervention rate $\\rho$, '
            'all in this block.')
        _rows = [[r['host'], str(r.get('rank', '-')),
                  _sci(r.get('accuracy')),
                  _f(r['dec_mean'], 3, True), _f(r['ri_mean'], 3, True),
                  _f(r['rho'], 3)] for r in _sub]
        P.table(['Variant', 'rank', 'accuracy', 'dec', 'ri', '$\\rho$'],
                _rows, widths=[2.6, 0.6, 0.9, 0.75, 0.7, 0.7],
                align='lcrrrr')

        if _bi == 0:
            # The reading of each table is printed directly after it, so that
            # the four tables are never left as one uninterrupted run.
            P.para(
                f'Table {t_a} shows the intervention rate spanning a factor of '
                f'{A["rho_hi"][1] / max(A["rho_lo"][1], 1e-9):.0f} across the '
                f'family, from {A["rho_lo"][1]:.3f} for {A["rho_lo"][0]} to '
                f'{A["rho_hi"][1]:.3f} for {A["rho_hi"][0]}, with the median '
                f'variant at {A["rho_med"]:.3f}. The three highest entries, '
                f'{A["rho_top3"][2]}, {A["rho_top3"][1]} and {A["rho_top3"][0]}, '
                'are the variants that draw their base vector uniformly at '
                'random, while the greedy DE/best/1 and DE/current-to-best/1 '
                'and the success-history variants sit at the bottom of the '
                'column. That ordering is what the minimal-intervention rule '
                'predicts and no other part of the layer is arranged to produce '
                'it: a near-random candidate is easy for the response model to '
                'beat, a candidate already aimed at the incumbent best is not. '
                'The column therefore measures the host rather than tuning it, '
                'and it is the axis on which the fingerprint of Section 4.4 is '
                'built.')
            # A rank is only meaningful down to the precision the accuracy
            # column prints.  Where several variants agree to every printed
            # digit their order is a formality, and saying so is better than
            # letting the reader infer a difference the data does not carry.
            _rk_of = {r['host']: int(r['rank']) for r in _sub
                      if str(r.get('rank', '')).isdigit()}
            for _grp in (S.get('block_ties') or {}).get((_bs, int(_bd)), []):
                _nm = [h[2] for h in _grp if h[2] in _rk_of]
                if len(_nm) < 3:
                    continue
                _nm.sort(key=lambda h: _rk_of[h])
                _rks = [_rk_of[h] for h in _nm]
                P.para(
                    'One caveat on the rank column. '
                    + (', '.join(_nm[:-1]) + ' and ' + _nm[-1])
                    + f' agree in median final error to every digit the table '
                    'prints, their raw errors differing by a few parts in a '
                    f'million; the ranks {_rks[0]} to {_rks[-1]} that separate '
                    'them therefore rest on digits this table does not show, '
                    'and the four should be read as one joint position at the '
                    'foot of the column rather than as an ordering.')
        elif _bi < 3:
            K = B if _bi == 1 else C
            P.para(
                f'Table {t_a + _bi} carries the same comparison on CEC 2022 at '
                f'$D={_bd}$ and confirms the ordering on a second suite: the '
                f'intervention rate spans a factor of '
                f'{K["rho_hi"][1] / max(K["rho_lo"][1], 1e-9):.0f}, from '
                f'{K["rho_lo"][1]:.3f} for {K["rho_lo"][0]} to '
                f'{K["rho_hi"][1]:.3f} for {K["rho_hi"][0]}, with the middle '
                f'variant at {K["rho_med"]:.3f} and the same three '
                f'uniform-draw variants at the top of the column. Its gain '
                f'column is bounded in the same way: the largest improvement '
                f'is {K["dec_hi"][1]:+.3f} decades ({K["dec_hi"][0]}, rank '
                f'{K["rank"][K["dec_hi"][0]]}) against a largest loss of '
                f'{K["dec_lo"][1]:+.3f} ({K["dec_lo"][0]}, rank '
                f'{K["rank"][K["dec_lo"][0]]}), and $|\\mathrm{{dec}}|$ stays '
                f'within ${_CELL_TOL:.2f}$ decades for {K["n_small"]} of its '
                f'{K["n"]} variants.')
        elif D is not None:
            P.para(
                f'Table {t_a + 3} repeats the comparison on CEC 2017 at '
                '$D=50$, the same twenty-nine variants at twice the number of '
                'coordinates. The ordering '
                'of the intervention rate is the one of the '
                f'thirty-dimensional block: the column spans a factor of '
                f'{D["rho_hi"][1] / max(D["rho_lo"][1], 1e-9):.0f}, from '
                f'{D["rho_lo"][1]:.3f} for {D["rho_lo"][0]} to '
                f'{D["rho_hi"][1]:.3f} for {D["rho_hi"][0]}, with the median '
                f'variant at {D["rho_med"]:.3f}; the two uniform-draw donors '
                'that lead the thirty-dimensional column are its two highest '
                'entries here as well, and the greedy best-anchored donor, '
                'which sits near the bottom at thirty, is the lowest of the '
                'twenty-nine. The gain column is bounded as before: the '
                f'largest improvement is {D["dec_hi"][1]:+.3f} decades '
                f'({D["dec_hi"][0]}, rank {D["rank"][D["dec_hi"][0]]}), the '
                f'largest loss {D["dec_lo"][1]:+.3f} ({D["dec_lo"][0]}, rank '
                f'{D["rank"][D["dec_lo"][0]]}), and $|\\mathrm{{dec}}|$ within '
                f'tolerance for {D["n_small"]} of the twenty-nine, but its '
                'sign is not simply inherited from the smaller dimension: '
                f'{D["n_pos"]} of the twenty-nine are positive and '
                f'{D["n_mismatch"]} rows carry dec and ri of opposite sign. '
                'The extra coordinates redistribute the effect over the family '
                'rather than scaling it up or down.')

    P.para(
        f'Crossing the left and right halves of Tables {t_a + 1} and '
        f'{t_a + 2} sharpens '
        'the reading, because on both CEC 2022 blocks the three highest '
        'intervention rates are also the three most negative $\\mathrm{dec}$ '
        'entries: '
        f'DE/rand/1/either-or loses '
        f'{abs(B["dec"]["DE/rand/1/either-or"]):.3f} and '
        f'{abs(C["dec"]["DE/rand/1/either-or"]):.3f} decades, DE/rand/1 '
        f'{abs(B["dec"]["DE/rand/1"]):.3f} and '
        f'{abs(C["dec"]["DE/rand/1"]):.3f}, and DE/rand/2 '
        f'{abs(B["dec"]["DE/rand/2"]):.3f} and '
        f'{abs(C["dec"]["DE/rand/2"]):.3f}. The layer therefore spends its '
        'interventions where the host candidate generator is weakest, and that '
        'is also where it does the most damage.')
    if D is not None:
        P.para(
            'At fifty coordinates that identification holds only in part, and '
            'the exception is informative. '
            f'DE/rand/1 and DE/rand/2 carry almost the same intervention rate '
            f'there ({D["rho"]["DE/rand/1"]:.3f} and '
            f'{D["rho"]["DE/rand/2"]:.3f}), yet the first loses '
            f'{abs(D["dec"]["DE/rand/1"]):.3f} decades and the second gains '
            f'{D["dec"]["DE/rand/2"]:+.3f}, being significantly better on '
            f'{D["wins"]["DE/rand/2"]} of its {D["n_cells"]["DE/rand/2"]} '
            f'functions, while DE/rand/1/either-or, at '
            f'{D["rho"]["DE/rand/1/either-or"]:.3f}, loses '
            f'{abs(D["dec"]["DE/rand/1/either-or"]):.3f}. '
            'A high intervention rate is thus a property of the host, whereas '
            'its price depends on whether the host still has slack at that '
            'dimension: the uniform-draw donor that draws two differences has '
            'more of it at $D=50$ than at $D=30$, the one that draws a single '
            'difference less.')

    # The extremes quoted as "anywhere in the tables" must span all four
    # blocks, not just the thirty-dimensional one: with the D=50 block now
    # complete its tails are wider than the others and set both bounds.
    _tbl_blks = [A, B, C] + ([D] if D is not None else [])
    _tbl_hi = max(_tbl_blks, key=lambda b: b['dec_hi'][1])
    _tbl_lo = min(_tbl_blks, key=lambda b: b['dec_lo'][1])
    P.para(
        'The gain columns nevertheless favour more variants than they '
        f'penalise: $\\mathrm{{dec}}>0$ for {A["n_pos"]}, {B["n_pos"]}, '
        f'{C["n_pos"]} and {D["n_pos"] if D is not None else "-"} of the '
        f'{A["n"]}, {B["n"]}, {C["n"]} and '
        f'{D["n"] if D is not None else "-"} variants of the four tables, and '
        f'the median variant moves by {A["dec_med"]:+.3f}, '
        f'{B["dec_med"]:+.3f}, {C["dec_med"]:+.3f} and '
        f'{(D["dec_med"] if D is not None else float("nan")):+.3f} decades. '
        f'What keeps the block mean negative ({A["dec_mean"]:+.3f}, '
        f'{B["dec_mean"]:+.3f}, {C["dec_mean"]:+.3f} and '
        f'{(D["dec_mean"] if D is not None else float("nan")):+.3f}) is the '
        f'asymmetry of the two tails: the largest gain anywhere in the tables '
        f'is {_tbl_hi["dec_hi"][1]:+.3f} decades '
        f'({_tbl_hi["dec_hi"][0]}, rank '
        f'{_tbl_hi["rank"][_tbl_hi["dec_hi"][0]]}) while the '
        f'largest loss is {_tbl_lo["dec_lo"][1]:+.3f} '
        f'({_tbl_lo["dec_lo"][0]}, rank '
        f'{_tbl_lo["rank"][_tbl_lo["dec_lo"][0]]}), and $|\\mathrm{{dec}}|$ stays within '
        f'${_CELL_TOL:.2f}$ decades for {A["n_small"]}, {B["n_small"]}, '
        f'{C["n_small"]} and '
        f'{D["n_small"] if D is not None else "-"} of them. A further '
        f'{A["n_mismatch"]}, {B["n_mismatch"]}, {C["n_mismatch"]} and '
        f'{D["n_mismatch"] if D is not None else "-"} rows carry '
        '$\\mathrm{dec}$ and $\\mathrm{ri}$ of opposite sign, the case in '
        'which the layer improved the median while thickening the tail of bad '
        'runs; that is why the two indices are reported side by side.')

    # The five best variants of the D=50 block, by the rank column of its own
    # table; used by the sentence that reads that table against its ranks.
    _lead5 = (sorted(D['dec'], key=lambda h: D['rank'][h])[:5]
              if D is not None else [])
    _lead4 = sorted(abs(D['dec'][h]) for h in _lead5)[3] if _lead5 else 0.0

    P.para(
        'Read against the rank column, the same tables localise the effect. '
        f'In Table {t_a} the five best variants by variant-alone rank move by '
        f'no more than {A["top5_abs"]:.3f} decades once the layer is attached, '
        'so the layer is inert on exactly the variants that lead the family, '
        'whereas the largest gains belong to variants ranked '
        f'{min(A["dec_top5_ranks"])} to {max(A["dec_top5_ranks"])} of '
        f'twenty-nine. The other two full blocks tell the same story from the '
        f'opposite end, since their largest gains fall on {B["dec_hi"][0]} '
        f'({B["dec_hi"][1]:+.3f} decades, rank {B["rank"][B["dec_hi"][0]]}) '
        f'and {C["dec_hi"][0]} ({C["dec_hi"][1]:+.3f} decades, rank '
        f'{C["rank"][C["dec_hi"][0]]}), and the fourth block at $D=50$ '
        'reproduces the pattern within its own ranking: its four best variants '
        f'by rank move by no more than {_lead4:.3f} decades once the layer is '
        f'attached, and only its fifth, {_lead5[-1]}, moves further '
        f'({D["dec"][_lead5[-1]]:+.3f}), while its largest gain sits at rank '
        f'{D["rank"][D["dec_hi"][0]]} of twenty-nine. '
        'The layer is thus not uniformly '
        'useful: it moves the variants the family has already superseded and '
        'leaves the leaders where they are.')

    # ---- the same family at two dimensions -------------------------------
    # Figure and paragraph are built only when the D=50 block is present in
    # the tables, so an edition built from a partial grid stays consistent.
    if D is not None and _dv('hosts_in_both_blocks', 0) >= 3:
        _n_both = int(_dv('hosts_in_both_blocks'))
        _fig_dim = P.fig_no + 1
        P.para(
            f'Figure {_fig_dim} reads the two CEC 2017 blocks against each '
            'other variant by variant, and it is the reason the dimension is '
            'not treated as a further experimental factor. Panel (a) pairs the '
            f'per-variant mean dec of Tables {t_a} and {t_a + 3} on one row '
            'per variant: the ordering of the gain is preserved '
            f'(Spearman $\\rho = {_dv("host_dec_spearman"):.2f}$ over the '
            f'{_n_both} variants present in both blocks, '
            f'$p = {_dp("host_dec_spearman"):.1e}$), '
            f'{int(_dv("host_sign_agree"))} of them keep the sign of the gain '
            f'and {int(_dv("host_both_positive"))} are positive in both '
            'blocks, so for most of them a variant repaired at one dimension '
            'is repaired at the other. Panel (b) does the same for the '
            'intervention rate: its ordering is transferred almost intact '
            f'(Spearman $\\rho = {_dv("host_rho_spearman"):.2f}$) while its '
            'level barely moves, so the rate is a property of the variant and '
            'not of the problem dimension. At the level of individual '
            'optimisations the two blocks are statistically '
            'indistinguishable: over the '
            f'{int(_dv("cells_in_both_blocks"))} configurations the two blocks '
            f'share, the mean dec is {_dv("cell_dec_mean30"):+.3f} decades at '
            f'$D=30$ and {_dv("cell_dec_mean50"):+.3f} at $D=50$ '
            f'(Wilcoxon $p = {_dp("cell_dec_wilcoxon_p"):.2f}$), and the same '
            f'fraction of configurations improves '
            f'({_dv("cell_frac_positive30"):.2f} and '
            f'{_dv("cell_frac_positive50"):.2f}). What the dimension changes '
            'is therefore where inside the family the effect sits, not how '
            'large it is.')
        P.figure(PFG.fig('dim_effect'),
                 'Exp. 1, dimension transfer of the paired effect on '
                 'CEC 2017: (a) per-variant mean dec at $D=30$ (open) and '
                 '$D=50$ (filled), one row per variant and ordered by the '
                 '$D=50$ value, the connector drawn in red where the sign of '
                 'the gain changes; (b) the same rows for the policy '
                 'intervention rate. Both panels cover all twenty-nine '
                 'variants, each with a design at both dimensions.')

    P.para(
        'The decisive observation is the one the paired design cannot make '
        'by itself: on '
        f'the full family of Section 4.3 the variant-alone ranking is led by '
        f'{bare_top1}, a variant that substitutes success-history parameters '
        'and a shrinking population for the fixed rules, while the '
        'classical fixed-parameter variants and the strategy ensembles trail '
        'it. The layer\'s effect, large exactly where the variant is weakest, '
        'is therefore not a general improvement of the family; it is a '
        'repair of the variants that the family has already superseded.')

    # ---- zero-reference band ---------------------------------------------
    # A non-significant paired test is not evidence of equivalence.  The band
    # is the sampling noise of our own estimator, rebuilt from the bare arm of
    # each cell (see analyze_null_band.py); equivalence is claimed only where
    # the two one-sided tests support it.
    _nb = _nullband()
    _nb30 = _nb.get('cec2017/30')
    if _nb30:
        _nb50 = _nb.get('cec2017/50', _nb30)
        _nb10 = _nb.get('cec2022/10', _nb30)
        _nb20 = _nb.get('cec2022/20', _nb30)
        _in_half = [_nb30, _nb50, _nb10, _nb20]
        _lo_pct = min(100 * r['frac_in_band'] for r in _in_half)
        _hi_pct = max(100 * r['frac_in_band'] for r in _in_half)
        P.para(
            'A non-significant paired test is not evidence of equivalence, so '
            'the block-level tests above are read against a zero-reference '
            'band built from the same runs. For every cell two independent '
            'thirty-run medians are drawn with replacement from that cell\'s '
            'bare arm alone, which is the distribution of dec under the '
            f'hypothesis that both arms are one distribution; '
            f'{int(_nb30["n_cells_used"])} of the '
            f'{int(_nb30["n_cells_used"] + _nb30["n_cells_skipped"])} '
            f'CEC 2017 $D=30$ cells have a bare arm that has not already '
            'collapsed to machine precision and enter the analysis. The band '
            f'is {_f(_nb30["band_sd"], 2)} decades wide in standard deviation '
            f'with 95% limits [{_f(_nb30["band_p025"], 2, True)}, '
            f'{_f(_nb30["band_p975"], 2, True)}], and '
            f'{_lo_pct:.0f}% to {_hi_pct:.0f}% of the observed cell values '
            'fall inside it in the four blocks, the median cell value being '
            f'{_f(_nb30["dec_median"], 3, True)} decades in each of them. '
            'Equivalence is a stronger statement and the data support it only '
            f'in part: inside a $\\pm 0.05$-decade margin '
            f'{100 * _nb30["frac_abs_le_margin"]:.0f}% of the $D=30$ cells '
            'qualify, and the excess splits '
            f'{100 * _nb30["frac_neg"]:.0f}% below the margin and '
            f'{100 * _nb30["frac_pos"]:.0f}% above it, so the residual '
            'distribution is amplitude-asymmetric rather than sign-'
            'asymmetric: cells that leave the margin in the two directions '
            'are equally numerous, while those that leave it downwards do so '
            'by up to an order of magnitude, which is what makes the block '
            'means negative. A two-one-sided-test at that margin on the '
            f'per-variant means gives $p = {_nb30["tost_host_p"]:.2f}$ at '
            f'$D=30$, $p = {_nb50["tost_host_p"]:.2f}$ at $D=50$ and '
            f'$p = {_nb20["tost_host_p"]:.2f}$ at CEC 2022 $D=20$, and '
            f'$p = {_nb10["tost_host_p"]:.2g}$ at CEC 2022 $D=10$. Equivalence '
            'is therefore claimed only for that block; elsewhere the layer is '
            'reported as having a zero median effect that lies inside the '
            'noise of its own estimator, with a negative tail on the '
            'fixed-parameter variants. The four blocks are reproduced in the '
            'table null_band_summary.csv of the data release.')

# ===========================================================================
# 4.3  The family across variants and problems
# ===========================================================================
# The twenty-nine registered variants, split by composition level (the same axis the
# mechanism fingerprint of Section 4.4 is read against).  The two largest levels
# are split once more so that no single table has to carry more than twelve
# numeric columns (six variants x two arms).
_GRID_SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10), ('cec2022', 20))
_HOST_GROUPS = (
    ('L0 fixed-parameter',
     ['DE/rand/1', 'DE/best/1', 'DE/rand/2',
      'DE/current-to-best/1', 'DE/current-to-rand/1', 'DE/rand/1/either-or']),
    ('L1 self-adaptive $F$/$CR$',
     ['jDE', 'jDE100', 'j2020', 'SaNSDE', 'SinDE']),
    ('L2 success-history',
     ['SHADE', 'JADE', 'DISK', 'DISH', 'CoBiDE']),
    ('L2 archive and strategy ensembles',
     ['SaDE', 'EPSDE', 'CoDE', 'MPEDE', 'PaDE']),
    ('L3 LPSR',
     ['NL-SHADE-RSP', 'MadDE', 'L-SHADE', 'L-SHADE-RSP']),
    ('L3 rank-based and restart',
     ['jSO', 'SHADE-ILS', 'LSHADE-cnEpSin', 'IMODE']),
)

# Small counts are spelled out in the running text ("the six appendix tables"),
# which is the style the rest of the paper follows.
_COUNT_WORDS = {1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six',
                7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 11: 'eleven',
                12: 'twelve'}


# Green ramp for the rank shading: rank 1 (smallest error) gets the lightest
# fill and the worst rank the darkest, so a pale-green cell marks a good result
# and a deep-green cell marks a poor one.
_RANK_LO = (0xF1, 0xF8, 0xF1)
_RANK_HI = (0x1B, 0x5E, 0x20)


def _rank_fill(rank, n):
    """Green fill for a 1-based rank over ``n`` competitors (1 = best)."""
    if n <= 1:
        return 'F1F8F1'
    t = (rank - 1) / float(n - 1)
    c = tuple(round(lo + (hi - lo) * t) for lo, hi in zip(_RANK_LO, _RANK_HI))
    return '%02X%02X%02X' % c


def _sci(cell):
    """A ``log10`` final-error cell printed back as the error, scientific."""
    if cell in ('-', '', None):
        return '-'
    try:
        v = float(cell)
    except (TypeError, ValueError):
        return cell
    try:
        return f'{10.0 ** v:.2E}'
    except OverflowError:
        # a variant that diverged records a log10 error too large to raise back
        # to a float; print the magnitude directly rather than crashing.
        return f'1E{v:.0f}'


_CELL_TOL = 0.05          # resolution the paired matrices are read at, in decades


def _cell_stats(M):
    """Up, down and tie counts of one paired matrix, in decades of error."""
    up = down = same = 0
    bare = M.get('bare') or []
    acc = M.get('acc') or []
    for i, brow in enumerate(bare):
        arow = acc[i] if i < len(acc) else []
        for j, bv in enumerate(brow):
            if j >= len(arow):
                continue
            try:
                b, a = float(bv), float(arow[j])
            except (TypeError, ValueError):
                continue
            if b != b or a != a:              # cell left empty
                continue
            d = b - a
            if abs(d) <= _CELL_TOL:
                same += 1
            elif d > 0:
                up += 1
            else:
                down += 1
    return up + down + same, up, down, same


def _group_cell_stats(M, host_list):
    """Up, down and tie counts of one paired matrix, restricted to some variants.

    ``host_list`` selects the columns that belong to one composition-level
    group, so the cell counts of a single group of tables are read off the same
    matrix the tables themselves are built from.
    """
    hosts = M.get('hosts') or []
    fids = M.get('fids') or []
    idx = [hosts.index(h) for h in host_list if h in hosts]
    bare = M.get('bare') or []
    acc = M.get('acc') or []
    up = down = same = 0
    for i in range(len(fids)):
        for j in idx:
            if i >= len(bare) or j >= len(bare[i]):
                continue
            if i >= len(acc) or j >= len(acc[i]):
                continue
            try:
                b, a = float(bare[i][j]), float(acc[i][j])
            except (TypeError, ValueError):
                continue
            if b != b or a != a:              # cell left empty
                continue
            d = b - a
            if abs(d) <= _CELL_TOL:
                same += 1
            elif d > 0:
                up += 1
            else:
                down += 1
    return up + down + same, up, down, same


def _paired_cell_stats(G):
    """How often the layer moves a cell of the paired matrices.

    Every cell of a paired matrix is one variant on one function, so counting
    the cells whose UPCL column sits below the variant-alone column measures how
    concentrated the layer's action is.  Cells whose two columns agree to within
    ``_CELL_TOL`` decades are counted as untouched: that is the resolution the
    tables are read at.
    """
    tot = up = down = same = 0
    for M in (G.get('matrices') or {}).values():
        t, u, d, s = _cell_stats(M)
        tot += t
        up += u
        down += d
        same += s
    return tot, up, down, same


def _level_order_stats(G):
    """Rows of the lead-in tables that carry all four composition levels, and
    how often the strongest and the weakest level own the best and the worst
    terminal value on their row."""
    rows = low3 = high0 = 0
    for lm in (G.get('level_matrix') or {}).values():
        for r in lm.get('rows') or []:
            vals = []
            for v in r.get('vals') or []:
                try:
                    vals.append(float(v))
                except (TypeError, ValueError):
                    break
            if len(vals) < 4 or any(v != v for v in vals):
                continue
            rows += 1
            if vals[3] == min(vals):
                low3 += 1
            if vals[0] == max(vals):
                high0 += 1
    return rows, low3, high0


def _matrix_will_emit(M, host_list):
    """True when at least one variant of ``host_list`` has data in this block.

    The same test `_emit_paired_matrix` applies before drawing anything, kept
    separate so that the appendix numbering can be predicted in the main text
    before the appendix is rendered.
    """
    return any(h in M['hosts'] for h in host_list)


def _emit_paired_matrix(P, caption, M, host_list, rank_map, appendix=False):
    """One paired (variant alone vs UPCL) table for one variant generation.

    Each variant contributes two adjacent columns (the variant-alone value and the
    same variant with UPCL attached, both the median final error in scientific
    notation) so the before and after are read side by side.  Every value cell
    is shaded green by its rank within its row (lightest = best, darkest =
    worst).  The final row gives each variant its overall rank within the suite,
    by its variant-alone median error across the functions (1 = best).
    """
    hosts = M['hosts']
    fids = M['fids']
    bare = M.get('bare') or []
    acc = M.get('acc') or []
    idx = [hosts.index(h) if h in hosts else None for h in host_list]
    if all(j is None for j in idx):
        return False                  # no variant of this generation has run yet

    header = ['Function'] + [c for h in host_list for c in (h, f'UPCL-{h}')]

    body, shades = [], []
    for i in range(len(fids)):
        row = [fids[i]]
        vals = []                     # (column index, numeric error)
        for j in idx:
            if j is None:
                row += ['-', '-']
                continue
            bv = bare[i][j] if i < len(bare) and j < len(bare[i]) else '-'
            av = acc[i][j] if i < len(acc) and j < len(acc[i]) else '-'
            cb = len(row)
            row.append(_sci(bv))
            ca = len(row)
            row.append(_sci(av))
            if bv not in ('-', '', None):
                vals.append((cb, 10.0 ** float(bv)))
            if av not in ('-', '', None):
                vals.append((ca, 10.0 ** float(av)))
        shade_row = [None] * len(row)
        order = sorted(range(len(vals)), key=lambda k: vals[k][1])
        for rank, k in enumerate(order, start=1):
            shade_row[vals[k][0]] = _rank_fill(rank, len(order))
        body.append(row)
        shades.append(shade_row)

    # overall rank row: each variant's 1-based rank within the suite, by its
    # variant-alone median error across the functions (1 = best)
    rank_row = ['Overall rank']
    for j in idx:
        if j is None:
            rank_row += ['-', '-']
        else:
            rank_row += [str(rank_map.get(hosts[j], '-')), '-']
    body.append(rank_row)
    shades.append([None] * len(rank_row))

    P.table_caption(caption, appendix=appendix)
    P.table(header, body, shades=shades,
            widths=[0.80] + [0.55] * (2 * len(host_list)),
            align='l' + 'r' * (2 * len(host_list)),
            font_size=6.5)
    return True


def _grid(P, S):
    G = S.get('grid') or {}
    hosts = G.get('hosts', [])
    matrices = G.get('matrices', {})

    # ---- variant-alone rank of every variant in every block --------------
    # Taken from the shared estimator (`build_upcl_paper_cec.block_ranks`),
    # the same one behind the accuracy and rank columns of Tables 8-11, so the
    # summary table here cannot contradict the per-block tables there.  The
    # fallback recomputes it from the matrix, which carries the same numbers
    # rounded for display, and is only used if the caller is run standalone.
    _rank_block = G.get('block_rank')
    if not _rank_block:
        def _block_rank(M):
            """1-based rank of each variant inside one (suite, dimension) block.

            The rank is the order of the variant-alone median final error over
            all functions of the suite, ascending (1 = best), ties broken by
            name exactly as in `block_ranks`.
            """
            _m_hosts = M.get('hosts', [])
            _m_bare = M.get('bare') or []
            _m_fids = M.get('fids', [])
            _m_acc = {}
            for _j, _h in enumerate(_m_hosts):
                _vals = []
                for _i in range(len(_m_fids)):
                    if _i < len(_m_bare) and _j < len(_m_bare[_i]):
                        _v = _m_bare[_i][_j]
                        if _v not in ('-', '', None):
                            try:
                                _vals.append(float(_v))
                            except ValueError:
                                pass
                if _vals:
                    _vals.sort()
                    _n = len(_vals)
                    _m_acc[_h] = (_vals[_n // 2] if _n % 2
                                  else (_vals[_n // 2 - 1] + _vals[_n // 2]) / 2.0)
                else:
                    _m_acc[_h] = None
            _rk = {}
            for _r, (_h, _v) in enumerate(
                    sorted(((h, v) for h, v in _m_acc.items() if v is not None),
                           key=lambda h_v: (h_v[1], h_v[0])), start=1):
                _rk[_h] = _r
            return _rk

        _rank_block = {_k: _block_rank(_m) for _k, _m in matrices.items() if _m}
    _rank_block = dict(_rank_block)

    def _blk_label(_k):
        _s, _d = _k
        return f'{_s[:3].upper()} {_s[3:]} $D={_d}$'

    # the summary table: one row per variant, one column per block, so the
    # ranking of the whole family, and how far it moves with the suite and the
    # dimension, are readable before the function-level detail
    _all_hosts = []
    for _k in _GRID_SUITES:
        for _h in _rank_block.get(_k, {}):
            if _h not in _all_hosts:
                _all_hosts.append(_h)
    _mean_rk = {}
    for _h in _all_hosts:
        _rs = [_rank_block[_k][_h] for _k in _GRID_SUITES
               if _h in _rank_block.get(_k, {})]
        _mean_rk[_h] = sum(_rs) / float(len(_rs)) if _rs else None
    _by_mean = sorted(_all_hosts, key=lambda _h: (_mean_rk[_h] or 1e9, _h))
    # the two leaders are quoted together only when they really share the mean
    # rank, which was the case before the D=50 block was completed and is no
    # longer; the wording is therefore derived from the numbers, not fixed
    _rk0 = _mean_rk[_by_mean[0]] if _by_mean else None
    _rk1 = _mean_rk[_by_mean[1]] if len(_by_mean) > 1 else None
    if _rk1 is not None and abs(_rk0 - _rk1) < 0.05:
        _lead_txt = (f'{_by_mean[0]} and {_by_mean[1]} '
                     f'(both {_f(_rk0, 1)})')
    elif _rk1 is not None:
        _lead_txt = (f'{_by_mean[0]} ({_f(_rk0, 1)}), ahead of '
                     f'{_by_mean[1]} ({_f(_rk1, 1)})')
    else:
        _lead_txt = (f'{_by_mean[0]} ({_f(_rk0, 1)})' if _by_mean
                     else 'the top variant')

    P.h2('4.3  The variant ranking and the landscapes')

    # The per-function paired matrices are collected in Appendix A, numbered
    # A1, A2, ... in the order of the four blocks described here, one table per
    # variant generation. Only the block summary stays in the main text; the
    # appendix figures are therefore referenced by that series rather than by
    # the main table counter.
    _n_mtx = sum(sum(1 for _gl, _hl in _HOST_GROUPS
                     if _matrix_will_emit(matrices[_k], _hl))
                 for _k in _GRID_SUITES if matrices.get(_k))

    P.para(
        'Section 4.2 already pairs the family with the layer variant by '
        'variant; this subsection unpacks the same comparisons into the '
        'variant-alone ranking that frames the rest of the paper. Table '
        f'{_next_table(P)} and the Appendix tables A1-A{_n_mtx} '
        'cover every block: ' + _suite_desc(G)
        + ', each with all twenty-nine variants on all twenty-nine problems, and '
        'every configuration was run thirty times, so nothing in the tables is '
        'a progress snapshot: the entries are final.')

    P.para(
        'Because the variant-alone configuration of every comparison is the '
        'variant run untouched, ranking the variants by their variant-alone '
        'median error across the functions yields a property of the family '
        'itself, not of the layer. Taken over the four blocks, the best mean '
        f'rank belongs to {_lead_txt}; in the two CEC 2017 blocks the whole '
        'top six is made of success-history, linear-population-size and '
        'rank-based variants, while the classical fixed-parameter variants and '
        'the strategy ensembles hold the bottom. The middle of the order does '
        'move with the suite and the dimension, but the two ends are stable, '
        'and those ends are the substitution structure argued for here, which '
        'the correction experiments of Sections 4.2 and 4.3 read against. A '
        'layer that could improve these variants would be adding something the '
        'winners lack; the fact that it cannot, and that its effect is '
        'confined to the variants the family has already superseded, is the '
        'central finding about substitutability. Table '
        f'{_next_table(P)} collects that ranking block by block, so the '
        'overview precedes the function-by-function expansion; the underlying '
        f'per-variant matrices are in Appendix A, Tables A1-A{_n_mtx}.')

    # ---- ranking summary: all variants x all blocks ----------------------
    # One table gives the whole family: a row per variant, a column per block,
    # the cell being the rank that variant holds inside that block over the
    # functions of the suite. Movement along a row is how far the ranking
    # depends on suite and dimension; the last column averages the ranks a
    # variant actually holds.
    _sum_rows = []
    for _h in sorted(_all_hosts, key=lambda _h: (_mean_rk[_h] or 1e9, _h)):
        _row = [_h]
        for _k in _GRID_SUITES:
            _row.append(str(_rank_block.get(_k, {}).get(_h, '-')))
        _row.append(_f(_mean_rk[_h], 1) if _mean_rk[_h] is not None else '-')
        _sum_rows.append(_row)
    P.table_caption(
        'Exp. 2 (summary), the variant-alone rank of every variant in every '
        f'block (1 = best), which reproduces the final row of '
        f'Appendix tables A1-A{_n_mtx}; the last column '
        'averages the ranks a variant actually holds.')
    P.table(['Variant'] + [_blk_label(_k) for _k in _GRID_SUITES]
            + ['Mean rank'],
            _sum_rows, widths=[1.5, 1.0, 1.0, 1.0, 1.0, 1.0],
            align='l' + 'r' * 5, font_size=7.5)

    # ---- function x algorithm paired matrices, one per suite/dim ----
    # The matrices themselves are rendered by `_appendix` at the end of the
    # paper. Here they are only queued with the block they belong to, so the
    # prose can quote exact appendix numbers before anything is drawn.
    _first_mtx = True
    _app_cursor = 0                   # appendix tables queued so far
    _app_jobs = []                    # (suite, dim, label, hosts, rank, M)
    for suite, dim in _GRID_SUITES:
        M = matrices.get((suite, dim))
        if not M:
            continue
        # the overall rank of this block, reused from the summary table
        _m_rank = _rank_block.get((suite, dim), {})
        _blk_groups = [(gl, hl) for gl, hl in _HOST_GROUPS
                       if _matrix_will_emit(M, hl)]
        _n_blk = len(_blk_groups)
        _a0 = _app_cursor + 1
        _bt, _bup, _bdn, _bsame = _cell_stats(M)
        P.para(
            ('The paired matrices begin with ' if _first_mtx
             else 'The same reading continues on ')
            + f'{_blk_label((suite, dim))}: of its {_bt} function-variant '
            f'cells, {_bup} have the UPCL column lower, {_bdn} have it higher '
            f'and {_bsame} agree with it to within the ${_CELL_TOL:.2f}$ '
            'decades these tables resolve. The '
            f'{_COUNT_WORDS.get(_n_blk, str(_n_blk))} appendix tables '
            f'A{_a0}-A{_a0 + _n_blk - 1} of the block split '
            'the family by composition level, so a column read downwards '
            'follows one level across the whole suite while a row compares the '
            'two configurations on a single function.')
        _first_mtx = False
        _g_done = []                  # (label, cells, up, down, same)
        for group_label, host_list in _blk_groups:
            _gt, _gup, _gdn, _gsame = _group_cell_stats(M, host_list)
            _g_done.append((group_label, _gt, _gup, _gdn, _gsame))
            _app_jobs.append((suite, dim, group_label, host_list, _m_rank, M))
            # After every second table a short reading of the pair is printed,
            # so that the appendix is not left as one uninterrupted run of
            # tables with the prose collected after them.
            if len(_g_done) == 2:
                _c1 = sum(g[1] for g in _g_done)
                _u1 = sum(g[2] for g in _g_done)
                _d1 = sum(g[3] for g in _g_done)
                _s1 = sum(g[4] for g in _g_done)
                P.para(
                    f'Appendix tables A{_a0} and A{_a0 + 1} hold the '
                    f'{_g_done[0][0]} and the {_g_done[1][0]} variants, '
                    f'{_c1} of the {_bt} cells of the block between them. '
                    f'Within that half the layer lowers the UPCL column in '
                    f'{_u1} cells, raises it in {_d1} and leaves {_s1} '
                    f'agreeing with the variant-alone column to within '
                    f'${_CELL_TOL:.2f}$ decades, so {100.0 * _u1 / max(_c1, 1):.0f}% '
                    'of these cells improve under the layer, and the adaptive '
                    'tables that follow carry the rest of the block against '
                    'the same baseline.')
            elif len(_g_done) == 4:
                _c2 = sum(g[1] for g in _g_done[2:])
                _u2 = sum(g[2] for g in _g_done[2:])
                _d2 = sum(g[3] for g in _g_done[2:])
                _s2 = sum(g[4] for g in _g_done[2:])
                P.para(
                    f'Appendix tables A{_a0 + 2} and A{_a0 + 3} carry the '
                    f'{_g_done[2][0]} and the {_g_done[3][0]} variants, '
                    f'{_c2} further cells of the same block. Here the layer '
                    f'lowers the UPCL column in {_u2} of them, raises it in '
                    f'{_d2} and leaves {_s2} within ${_CELL_TOL:.2f}$ decades, '
                    f'a share of {100.0 * _u2 / max(_c2, 1):.0f}% against '
                    f'{100.0 * _u1 / max(_c1, 1):.0f}% in the fixed-parameter '
                    'and self-adaptive half of the block. The two level-3 '
                    'tables that close the block complete the row; read down '
                    'the block, the share of improving cells is what shrinks as '
                    'the host takes over the mechanism.')
        _app_cursor += _n_blk
    S['exp2_appendix'] = _app_jobs

    _n_cell, _n_up, _n_dn, _n_same = _paired_cell_stats(G)
    P.para(
        'Read cell by cell, the matrices show where that mixture comes from. '
        f'Across the {_n_cell} variant-function cells of the four blocks the '
        f'two columns of a pair agree to within ${_CELL_TOL:.2f}$ decades in '
        f'{_n_same} cells, while the layer is lower in {_n_up} and higher in '
        f'{_n_dn}. Attaching the layer therefore leaves the median final error '
        'of most of the family below the resolution of these tables and moves '
        'only a minority of cells, and the aggregates of Section 4.2 are the '
        'average of that mixture.')

    # The convergence figures switch from per-variant paired values to a
    # per-composition-level summary.  Before the switch, a function x
    # composition-level terminal-value table maps each curve onto concrete
    # numbers; the figures then give the full trajectory.
    level_matrix = G.get('level_matrix', {})
    _n_lead = sum(1 for _k in _GRID_SUITES if matrices.get(_k))
    _lead_first = P.tab_no + 1
    P.para(
        'Before moving from the per-variant paired values to the convergence '
        'figures, the composition levels are mapped onto concrete numbers.  '
        'This partition is the one defined in Section 4.1: level 0 keeps fixed '
        'parameters, level 1 encodes parameters per individual, level 2 adds '
        'success-history memory, an external archive and strategy ensembles, '
        'and level 3 adds population-size reduction and rank-based restart.  '
        f'Tables {_lead_first}-{_lead_first + _n_lead - 1} put functions in '
        'rows and composition levels in '
        'columns; every cell is the median $\\log_{10}$ final error over the '
        'variants of that level and their 30 runs (lower is better), exactly '
        'the reading each convergence curve reaches at the end of the budget. '
        'The tables give the terminal values and the figures give the '
        'trajectory, on the same partition and the same 30 runs.')
    _lv_label = {'0': 'L0', '1': 'L1', '2': 'L2', '3': 'L3'}
    for suite, dim in _GRID_SUITES:
        lm = level_matrix.get((suite, dim))
        if not lm:
            continue
        levels = lm['levels']
        header = ['Function', 'Category'] + [_lv_label[lv] for lv in levels]
        body = []
        for r in lm['rows']:
            row = [r['fid'], r['cat']]
            for v in r['vals']:
                row.append(_f(v, 2))
            body.append(row)
        P.table_caption(
            f'Exp. 3 (lead-in): the level-median terminal value on '
            f'{suite} at $D={dim}$ ($\\log_{10}$ error, lower is better).  '
            'One row per function; the L0-L3 columns are the concrete values '
            'each convergence curve reaches.')
        P.table(header, body,
                widths=[0.6, 1.2] + [0.7] * len(levels),
                align='l l' + 'r' * len(levels), font_size=7.0)

    _n_lv, _n_lv3, _n_lv0 = _level_order_stats(G)
    P.para(
        'These tables also fix the level ordering on individual functions. '
        f'The {_n_lv} rows that carry all four levels are the ones to read: on '
        f'{_n_lv3} of them the L3 column holds the lowest terminal error of the '
        f'row, and on {_n_lv0} the L0 column holds the highest, so the ordering '
        'the convergence curves show at the end of the budget is already fixed '
        'by the numbers behind them.')

    # One convergence figure per (suite, dimension, part): each part holds six
    # functions so that it fits the text column.
    conv_figs = G.get('conv_figs', [])
    first_fig = P.fig_no + 1
    P.para(
        f'The convergence figures {first_fig}-'
        f'{first_fig + len(conv_figs) - 1} reuse this partition.  Because one '
        'curve per variant would make the subplots unreadable, and because the '
        'exact per-variant paired values are already carried by the tables of '
        'this section, the figures summarise by composition level: in each '
        'subplot every line is the median $\\log_{10}$ error over the variants '
        'of one level and over their 30 runs (band: 25th-75th percentile '
        'across those variants), the variant alone solid and the same variant '
        'with UPCL dashed.')
    _conv_notes = {
        ('cec2017', 30, 1):
        'The series follows the numbering the suite declares: functions are '
        'taken in suite order and cut into blocks of at most twelve, drawn as '
        'three columns of up to four rows, so a function is found by its '
        'number without a legend. Each subplot keeps its own vertical range, '
        'taken from the curves it holds, which means that the height of a '
        'curve is comparable only inside its panel; what is comparable across '
        'panels is the distance between the solid and the dashed curve of the '
        'same colour. The columns run in suite order, so the leftmost panel of '
        'a part holds the lowest function numbers of that part, and the same '
        'position holds the same function in the figures that follow at the '
        'other dimension: a reader who has located a function once can find '
        'it again by position in the paired figure, which is what makes the '
        'dimension pair readable without a second legend.',
        ('cec2017', 30, 2):
        'Two shaded ranges sit behind every pair of curves, the darker for the '
        'level alone and the lighter for the same level with the layer. They '
        'are the 25th to 75th percentiles across the variants of that level, '
        'not intervals for the median, and their width is a reading of its '
        'own: where the two ranges overlap for most of the budget, the gap '
        'between the medians is smaller than the disagreement inside the '
        'level and the panel is no evidence either way; where they separate, '
        'the level itself is moving. The two ranges are drawn with '
        'transparency so that their overlap appears as a third, darker shade: '
        'where that shade covers most of a panel, the medians should not be '
        'read apart however far they drift, and where it thins out early the '
        'separation has happened before the budget was half spent.',
        ('cec2017', 30, 3):
        r'Every curve is a $\log_{10}$ error clipped at $10^{-8}$, so a curve '
        'that runs flat along the bottom has reached the floor rather than '
        'stopped improving, and over that stretch the two arms agree to the '
        'resolution of the plot. The readable event in a panel is the point '
        'at which the dashed curve parts from the solid one, not the height '
        'at which both end; the informative segment is the one before the '
        'floor, which is why these panels are read left to right. The floor '
        'is a floor of the measurement and not of the search: a level that '
        'reaches it has passed the resolution at which the suite can '
        'distinguish two runs, and any further difference between the arms is '
        'below what a logarithm can show.',
        ('cec2017', 50, 1):
        r'The same suite is drawn again at $D=50$ so that dimension is '
        'separated from suite. The variants, the runs, the pairing and the '
        r'summarisation are unchanged, and the budget keeps the same rule of '
        r'$10^{4}$ evaluations per coordinate, so the two families of figures '
        'differ in the number of coordinates and in nothing else. The '
        'descriptor normalises step length by the population spread, which is '
        'why the layer sees the same five numbers for the same relative move '
        'at either dimension; a change in the gap between the arms is '
        'therefore a change of landscape, not of units. The budget rule also '
        'lengthens the axis, five hundred thousand evaluations against three '
        'hundred thousand, so equal fractions of the horizontal axis mean '
        'equal evaluations per coordinate and the two families of figures can '
        'be compared at the same fraction rather than at the same count. Two '
        'consequences follow for the reading. Because the axis is longer, the '
        'early phase of every curve is compressed into the left-hand fifth of '
        'the panel, and a difference that at thirty coordinates would be '
        'spread over the first few thousand evaluations is squeezed into a few '
        'pixels here; the panels at this dimension are therefore read for the '
        'late phase, where a decade of separation is drawn across a readable '
        'length. The second consequence is a licence rather than a caveat: '
        'both blocks carry the same twenty-nine variants on the same '
        'twenty-nine problems, so every level of the taxonomy is drawn from '
        'the same members at either dimension and the two families of panels '
        'can be read level by level. What they do not license is a '
        'comparison, across the two families, of the absolute height of a '
        'curve. The '
        'floor, the summary and the runs are the same, but the number of '
        'coordinates is not, so a level that reaches a given error at fifty '
        'coordinates has done more work per unit of error than one that '
        'reaches it at thirty; the two families are compared for the order of '
        'the levels and for the separation between the arms, never for the '
        'height of an individual curve. Read that way the family is a check on '
        'the earlier tables rather than a second result: the question is '
        'whether the levels appear in the same order and whether the two arms '
        'part at the same point of the budget, and both are answered from the '
        'panels without leaving the figure.',
        ('cec2017', 50, 2):
        'At fifty coordinates the levels separate later, and in several '
        'panels they are still within a decade of one another when the budget '
        'ends. The mechanisms that separate L0 from L3 mostly govern how the '
        'population is maintained across generations, and that governance '
        'needs a longer transient before it registers in the error, so the '
        'ordering is expected to appear late rather than to appear weakly. '
        'The reading is unaffected: within a panel the comparison of interest '
        'is between the solid and the dashed curve of the same colour, taken '
        'at the right-hand end of the axis. The wider bands at this dimension '
        'matter for that reading: where the two ranges overlap for most of '
        'the budget, a separation of a few tenths of a decade between the '
        'medians is smaller than the disagreement among the variants of the '
        'level and is not read as a gain.',
        ('cec2017', 50, 3):
        'All four levels are present in every panel and draw on the same '
        'membership as their counterparts at thirty coordinates, because this '
        'block carries the same twenty-nine variants on the same twenty-nine '
        'problems, so the band of a level is a statement about the same '
        'number of variants as in the other family and the two can be read '
        'against each other directly. The remaining difference from the '
        'thirty-coordinate family is '
        'that the curves do not reach the floor as often: at this dimension '
        'the resolution of the suite is not exhausted inside the budget, so '
        'more panels are read across their whole width instead of only before '
        'a flat stretch. A level is attributed to a variant once, from the '
        'mechanism table of Section 2, and the same attribution is used in '
        'every panel: the colours do not change with the function, which is '
        'what allows a level to be followed from one panel to the next and '
        'from one dimension to the other.',
        ('cec2022', 10, 1):
        'The second suite has ten functions per dimension, so one figure '
        'covers all of it and a whole suite is read at once. The same '
        'colours, line styles and per-level summarisation are kept, so the '
        'two suites can be read with the same eye, and the panels of this '
        'figure are the ones to compare with the $D=20$ figure that follows: '
        'the same position holds the same function in both, which makes the '
        'pair a direct reading of the dimension effect inside one suite. Ten '
        'functions fill three columns of four rows with the last row partly '
        'empty, and the empty cells are switched off rather than filled with '
        'a placeholder, so no panel is read where no function exists. The '
        'horizontal axis here runs to one hundred thousand evaluations, the '
        'budget of ten thousand per coordinate at ten coordinates; the '
        'summary is again per level and per arm, thirty runs each, with the '
        'same band definition and the same floor as the larger suite. Every '
        'one of the four blocks is complete, so no panel here carries a '
        'missing level and the pair is read without gaps: a colour that '
        'appears in a panel of this figure appears in the same panel of the '
        'next, and the comparison between '
        'them is between the same set of variants. What the ten panels cannot '
        'show is the behaviour of a single variant, since every curve is '
        'already a median over the variants of a level; the figure that '
        'follows takes up that question at one dimension and one function per '
        'class. Where the ten panels do carry more than the thirty-coordinate '
        'ones is in the width of the level bands: with two or three variants '
        'per level the band spans an order of magnitude on the multimodal '
        'functions, and a separation of a few tenths of a decade in the median '
        'is then read as no separation at all. That asymmetry is the reason the '
        'pooled tables rather than these curves carry the quantitative claims: '
        'the curves are used to check that the effect has the sign the tables '
        'report and that it appears at the same point of the budget, and the '
        'magnitudes are left to the paired statistics. The partial last row is '
        'closed rather than padded, so that no panel stands for a function the '
        'suite does not contain, and the position of every function is fixed by '
        'its index, so a panel can be found in the same place in both figures '
        'of the pair without consulting the caption. The decisive reading is '
        'the one stated once for the whole family: the distance between the '
        'solid and the dashed curve of the same colour inside one subplot, and '
        'the point at which that distance begins. Any difference that requires '
        'two subplots to be laid side by side falls outside what the shared '
        'axis ranges allow.',
        ('cec2022', 20, 1):
        'The second dimension of the same suite is drawn on the same ten '
        'panels, so the pair can be read as one figure seen twice: the same '
        'box holds the same function, and the only differences between the '
        'two are the number of coordinates and the budget that comes with '
        'it. Read together they give the dimension effect free of any change '
        'of function set, which is the smallest controlled pair in the '
        'design and the one against which the larger suite is checked. The '
        'axis of the second figure is twice as long, two hundred thousand '
        'evaluations against one hundred thousand, so the pair is compared at '
        'equal fractions of the budget and not at equal counts; a curve that '
        'reaches a given height at the same fraction in both panels is a '
        'behaviour that does not depend on the number of coordinates, and a '
        'curve that reaches it later has paid for the extra coordinates. '
        'Nothing else in the figure changes between the two, which is what '
        'makes that comparison admissible.',
    }
    for f in conv_figs:
        _nt = _conv_notes.get((f['suite'], int(f['dim']),
                               int(f.get('part') or 1)))
        if _nt:
            P.para(_nt)
        part_txt = (f', part {f.get("part")} of {f.get("n_parts")}'
                    if f.get('n_parts', 1) > 1 else '')
        P.figure(f['path'],
                 f'Exp. 3, convergence on {f["suite"]} at $D={f["dim"]}$'
                 f'{part_txt}: one subplot per function; lines are the per-level '
                 'medians of $\\log_{10}$ error (bands: 25th-75th percentile), '
                 'the variant alone solid, with UPCL dashed.')

    P.para(
        'A level median can be flat while its members move in opposite '
        'directions: the aggregation that makes eight panels legible is the '
        'same aggregation that hides an individual variant\'s response, and '
        'the tables report the paired effect variant by variant precisely '
        'because the figure cannot. The close-up that follows therefore '
        'changes one factor at a time. It keeps the suite and the dimension '
        'at the setting where the analysis is densest, takes one function per '
        'category so that the four kinds of landscape are represented, and '
        'takes one variant per composition level so that the four generations '
        'of mechanism are represented. It displays not a summary but the '
        'paired runs themselves, the variant alone and the same variant with '
        'the layer, so the reader can see where the two curves part and '
        'whether they part in the same way on a unimodal, a multimodal, a '
        'hybrid and a composite function. The figure is therefore read column '
        'by column rather than across: each column is one landscape, and the '
        'four rows ask the same question of it four times.')

    rep = G.get('rep_fig')
    if rep:
        P.figure(rep['path'],
                 'Exp. 4, a representative close-up: four typical functions '
                 '(one per CEC category) x four representative variants (one '
                 'per composition level) on CEC 2017 at $D=30$, the variant '
                 'alone solid and the same variant with UPCL dashed (median of '
                 '30 runs).')

    tot = G.get('total', {})

    def _avg(e):
        """Mean effect of a variant, pooled over the completed blocks."""
        done_blocks = [b for b in e['blocks'] if b['cells']]
        n = sum(b['cells'] for b in done_blocks)
        return sum(b['mean_dec'] * b['cells'] for b in done_blocks) / max(n, 1)

    have = [e for e in G.get('per_host', []) if e['cells']]
    ranked = sorted(have, key=_avg)
    worst, best = ranked[0], ranked[-1]

    P.para(
        f'Over the completed family the mean of $\\mathrm{{dec}}$ is '
        f'{_f(tot.get("mean_dec"), 3, True)} decades, the same picture as '
        'Section 4.2, now including every variant that adapts its own '
        'parameters. The spread across variants is again larger than the '
        f'average effect: over its {best["cells"]} comparisons, '
        f'{best["host"]} gains {_avg(best):+.2f} decades, while '
        f'{worst["host"]} loses {abs(_avg(worst)):.2f} over its {worst["cells"]}. '
        + (f' Figures {first_fig}-{P.fig_no} draw the same comparisons.' if
           conv_figs else ''))

    # ---- block-level summary, condensed to one sentence -----------------
    _block_means = ', '.join(
        f'{s["suite"]} $D={s["dim"]}$ {_f(s["mean_dec"], 3, True)}'
        for s in G.get('suites', []))
    P.para(
        f'The block means are consistent with the family picture: the mean '
        f'decades removed is {_f(tot.get("mean_dec"), 3, True)} overall and, '
        f'block by block, {_block_means}, negative but small everywhere, and '
        'not moving systematically with suite or dimensionality. What changes '
        'with the problem is the spread around the mean, which variants the '
        'layer helps and which it hurts; the category reading next locates '
        'the landscapes where that spread actually opens.')

    # ---- which landscapes leave room (the category reading) ------------
    cat = S['category']
    P.para(
        'Table '
        f'{_next_table(P)} regroups the comparisons by the category the '
        'suite declares and so locates the landscapes on which a variant '
        'leaves improvable room. The layer is not '
        'uniformly useful, and the failure is not random: it is concentrated '
        'in the composite functions, where it is also largest in magnitude. '
        'Composite functions are built by summing several independently '
        'shifted and rotated basis functions with different weights, so the '
        'local landscape carries little information about the useful '
        'direction, and a correction chosen from the local geometry of a '
        'single candidate (contract towards the target, reflect it, align it '
        'with the elite) is fitting a proxy that does not describe that '
        'landscape. The unimodal block, where local geometry is exactly what '
        'matters, is the one where the layer pays best. The reading is not '
        'that the layer prefers easy functions but that it edits candidates '
        'according to local evidence, and that edit is worth less when the '
        'local geometry is deliberately made uninformative.')

    P.table_caption('Exp. 5, effect by declared problem category. The mean '
                    'and median of $\\mathrm{dec}$ (decades removed) are '
                    'reported per category.')
    _cat_rows = [[f'{r["suite"]} ${r["dim"]}$', r['category'],
                  _f(r['dec_mean'], 3, True), _f(r['dec_median'], 3, True)]
                 for r in cat]
    P.table(['Suite', 'Category', 'dec mean', 'dec median'],
            _cat_rows, widths=[1.25, 1.15, 0.95, 1.0],
            align='llrr')

    _ec = S["protocol"].get("err_corr")
    if _ec != _ec:  # NaN: CEC 2017 paired comparisons not yet available
        P.para(
            'One confound can be ruled out directly: a large gain '
            'might simply mean that the variant alone was far from the '
            'optimum and had further to fall. The correlation between the '
            'variant-alone error and the decades removed is reported once the '
            'CEC 2017 paired block is available.')
    else:
        P.para(
            'One confound can be ruled out directly: a large gain '
            'might simply mean that the variant alone was far from the '
            'optimum and had further to fall. The correlation between the '
            'variant-alone error and the decades removed answers this: it is '
            f'positive but weak (Spearman {_f(S["protocol"]["err_corr"], 2, True)}, $p<'
            f'10^{{-7}}$ over the CEC 2017 block at $D=30$), so the gain is '
            'only weakly '
            'related to how far each variant had left to fall.')


def _suite_desc(G):
    """A human sentence naming the completed blocks, suite by suite.

    Dimensions are grouped under their suite, so four blocks read as
    "CEC 2017 at $D=30$ and $D=50$, CEC 2022 at $D=10$ and $D=20$" rather
    than as four repeated suite names.
    """
    names = {'cec2017': 'CEC 2017', 'cec2022': 'CEC 2022'}
    order, dims = [], {}
    for s in G.get('suites', []):
        raw = str(s['suite'])
        name = names.get(raw.lower(), raw)
        if name not in dims:
            order.append(name)
            dims[name] = []
        dims[name].append(int(s['dim']))
    if not order:
        return 'the four blocks'
    parts = [f'{n} at ' + ' and '.join(f'$D={d}$' for d in dims[n])
             for n in order]
    if len(parts) == 1:
        return parts[0]
    return '; '.join(parts)


# ===========================================================================
# 4.4  Mechanism attribution
# ===========================================================================
def _mechanism(P, S):
    m30 = S.get('mech30', {})
    attr = S.get('attr', {})
    host_summary = m30.get('host_summary', [])
    by_level = m30.get('by_level', [])
    by_cat = m30.get('category', [])
    cat_level = m30.get('category_level', [])

    P.h2('4.4  Mechanism attribution')

    P.para(
        'Sections 4.2 and 4.3 established which variants win the family and '
        'which landscapes leave room for a correction; this section turns to '
        'why. It attributes the intervention gain, together with its '
        'companion observables, back to the mechanism families of Section 2, '
        'collapsed as that section states onto the six mechanism indicators '
        'the twenty-nine hosts carry: donor, $F/CR$ rule, operator pool, '
        'archive, population size and a residual. The reading proceeds from '
        'the mechanism fingerprint, to '
        'the composition-level gradient, to a six-dimensional statistical '
        'attribution over those six indicators that controls the collinearity '
        'between them, '
        'and finally conditions the contribution on the problem and on '
        'substitutability, answering RQ1-RQ4. The per-variant fingerprints '
        f'behind all of this are collected in Table {_next_table(P)}.')

    # --- master fingerprint table -----------------------------------------
    fp_rows = []
    for r in host_summary:
        fp_rows.append([
            r['host'], str(r['level']),
            _f(r['bare_median_log10err']),
            _f(r['intervention_rate'], 3),
            _f(r['dec_mean'], 3, True),
            _f(r['theta_align_effect'], 2, True),
            _f(r['eta_elite_effect'], 2, True),
        ])
    P.table_caption(
        'Mechanism fingerprint of the twenty-nine variants, ordered by bare '
        'rank: bare = mean median $\\log_{10}$ final error (lower is better), '
        'IR = intervention rate, dec = gain in $\\log_{10}$ error (positive is '
        'better), $\\theta$/$\\eta$ = the two descriptor contrasts that carry '
        'signal.')
    P.table(
        header=['Variant', 'Level', 'bare', 'IR', 'dec', '$\\theta$',
                '$\\eta$'],
        rows=fp_rows,
        widths=[1.45, 0.50, 0.92, 0.70, 0.92, 0.92, 0.92],
        font_size=7.0, align='l c r r r r r')

    P.para(
        'The collapse is not an artefact of a few outliers. Taken variant by '
        'variant, the entries behind the fingerprint fall into two groups: the '
        'modern variants cluster tightly at the bottom-left, intervening on a '
        'tiny fraction of candidates and recovering next to nothing, while '
        'the fixed-parameter variants spread upward with both higher '
        'intervention rates and larger, noisier gains. The two descriptor '
        'contrasts that carry signal locate where '
        'that gap lives geometrically: the alignment between the proposed '
        'correction and the variant displacement, and the proximity of the '
        'correction to the elite, both fall with the composition level, so '
        'the level that intervenes least is also the level whose own '
        'candidates are already aimed and already elite-shaped, there is no '
        'geometric slack left for the layer to correct.')

    # --- composition-level gradient ----------------------------------------
    lv = {int(r['level']): r for r in by_level if r.get('level') not in (None, '')}
    ir0 = float(lv[0]['intervention_rate']) if 0 in lv else 0.0
    ir3 = float(lv[3]['intervention_rate']) if 3 in lv else 0.0
    bare0 = float(lv[0]['bare_median_log10err']) if 0 in lv else 0.0
    bare3 = float(lv[3]['bare_median_log10err']) if 3 in lv else 0.0

    P.para(
        'Table '
        f'{_next_table(P)} aggregates the fingerprint by composition level '
        'and shows where the search pressure comes from. Moving from the '
        'fixed-parameter variants of level 0 to the modern variants of level 3, '
        'three numbers move in opposite directions. The bare error falls by '
        f'about {max(0.0, bare0 - bare3):.1f} decades of $\\log_{10}$ error, '
        f'the intervention rate falls from {100.0 * ir0:.0f}% to '
        f'{100.0 * ir3:.1f}%, and the intervention gain collapses from a '
        'negative value at level 0 to a value indistinguishable '
        'from zero at level 3. The contribution is therefore not uniform '
        'across the six dimensions: it is concentrated in the mechanisms '
        'that levels 2 and 3 add (the success-history memory with its '
        'archive, and population-size reduction with selective pressure) '
        'and these are exactly the mechanisms that also erase the '
        'candidate-generation slack a correction layer could recover. The two '
        'descriptor contrasts that carry signal, the alignment with the '
        'variant displacement and the proximity to the elite, are likewise the '
        'quantities a success-history variant stores explicitly, so the '
        'fingerprint reads back, from outside, the mechanism the winning '
        'variants install inside.')

    lv_rows = [[str(r['level']), str(r['n_hosts']),
                _f(r['bare_median_log10err']),
                _f(r['intervention_rate'], 3),
                _f(r['dec_mean'], 3, True),
                _f(r['mean_relative_shift'], 2)]
               for r in by_level]
    P.table_caption(
        'Mechanism contribution by composition level, averaged over the '
        'variants of each level. bare is the mean median '
        '$\\log_{10}$ error; IR is the intervention rate; dec is the '
        'intervention gain; shift is the mean relative displacement of the '
        'corrections over the candidates they modify.')
    P.table(
        header=['Level', 'Variants', 'bare', 'IR', 'dec', 'shift'],
        rows=lv_rows, widths=[0.7, 0.7, 1.1, 0.9, 1.0, 0.9],
        align='ccrrrr')

    # --- Step 2: six-dimensional statistical attribution ------------------
    _DIM_LABEL = {
        'mutation_class': 'Mutation',
        'param_class': 'Parameter rule',
        'strategy': 'Operator selection',
        'archive': 'External archive',
        'pop': 'Population size',
        'other_flag': 'Extra mechanisms',
    }
    P.para(
        'The composition-level gradient names which generations of mechanism '
        'carry the field\'s progress, but not which of the six dimensions does; '
        'locating the contribution at the dimension level requires a '
        'statistical attribution that respects one structural fact: the six '
        'dimensions are not orthogonal, '
        'a situation for which screening designs [@MORRIS] and variance-based '
        'sensitivity analysis [@SALTELLI10] are the established tools; the '
        'four readings of this section take the discrete route instead. '
        f'After coarsening, the mutation operator fully determines the '
        f'strategy (Cramer\'s $V = {attr.get("v_mut_strategy", 1.0):.2f}$) '
        f'and the parameter rule is strongly associated with the archive '
        f'($V = {attr.get("v_param_archive", 0.90):.2f}$). This collinearity '
        'is the central confound of the attribution, and it pre-figures a '
        'reversal between the univariate and the multivariate readings. The '
        'four readings that follow (association, univariate effect size, '
        'multivariate attribution, near-pair ablation) are drawn in '
        f'Figs. {P.fig_no + 1}-{P.fig_no + 4}.')

    P.figure(PFG.fig('attr_d1_assoc'),
             'Association among the six mechanism indicators (Cramer\'s V tile) '
             'with the marginal host distribution per indicator; the mutation '
             'operator fully determines the '
             'operator-selection strategy ($V = 1.00$) and the parameter rule '
             'is strongly associated with the archive ($V = 0.90$).')
    P.para(
        'The tile is read as a map of which labels the design can and cannot '
        'separate. Its diagonal is one by construction and carries no '
        'information; the informative entries are the off-diagonal ones, each '
        'of which counts the variants on which two labels co-occur and '
        'normalises that count against what independence would give. Two '
        'entries are close to unity - the mutation operator determines the '
        'operator-selection strategy completely, and the parameter rule is '
        'strongly associated with the archive - and both are features of how '
        'modern DE is built rather than accidents of the sample: a strategy '
        'is named after the mutation that drives it, and the archive is the '
        'device through which a parameter rule adapts. The practical '
        'consequence is a bound on what an observational comparison can '
        'attribute: on this corpus the effect of the mutation cannot be '
        'separated from that of the strategy by any method that treats the '
        'two labels as regressors, and the same holds for the parameter rule '
        'and the archive. The marginal bars along the edges of the tile show '
        'why the remaining entries are easier to read: the indicators that '
        'co-occur weakly are also those whose variants are spread across the '
        'four levels, so a difference between them is not confounded with the '
        'level structure. Everything that follows in this subsection attacks '
        'the same two entries by a different route.')
    P.para(
        'The four readings are ordered by how much they assume. The tile '
        'assumes nothing beyond a categorical encoding and reports '
        'co-occurrence. The univariate effect size assumes that an indicator '
        'can be screened one at a time and reports how much of the variation '
        'in an observable it explains. The multivariate attribution assumes a '
        'linear model on standardised indicators and reports which of them '
        'survives when the others are held fixed. The near-pair ablation '
        'assumes only that two variants differing in one mechanism can be '
        'compared, and reports what that difference is worth in error. Each '
        'answers a question the previous one cannot: co-occurrence says which '
        'pairs are entangled, the univariate screen says whether an entangled '
        'indicator still carries signal, the linear model says which of a set '
        'of entangled indicators carries the marginal signal, and the ablation '
        'is the only one of the four that is not observational, since it '
        'varies a mechanism by construction. Where the four agree the reading '
        'is safe; where they disagree - as they do on the operator-selection '
        'strategy, which the linear model ranks second and the forest sixth - '
        'the disagreement localises the confound rather than the effect.')
    P.figure(PFG.fig('attr_d2_eta2_dot'),
             'Univariate effect size ($\\eta^2$, Kruskal-Wallis) of each '
             'mechanism indicator on each observable; the ten observables are '
             'sorted within each panel and the dashed line marks '
             '$\\eta^2 = 0.10$.')
    P.figure(PFG.fig('attr_d6_attribution'),
             'Multivariate attribution of the intervention gain. (a) '
             'Standardized regression coefficients with 95% confidence '
             'intervals, one hue per mechanism indicator (the hue that '
             'indicator carries throughout this section); the coefficient is '
             'printed at the right of its row and a dagger marks $\\beta$ '
             'significant at $p<0.10$. (b) Random-forest permutation '
             'importance, with the permutation standard deviation as whisker. '
             'Both panels share one row order ($|\\beta|$ descending) and the '
             'narrow middle band maps the $\\beta$ ordering (left nodes, '
             'filled) onto the importance ordering (right nodes, open, '
             'labelled by importance rank), so the two readings can be '
             'compared row by row and agree on the leading dimension only.')
    P.figure(PFG.fig('attr_d8_near_matrix'),
             'Near-pair ablation: the 40 controlled comparisons whose '
             'six-dimension mechanism profiles differ in exactly one '
             'dimension, grouped by that dimension and sorted by '
             '$\\Delta$dec within each group.')

    P.para(
        'Univariately the picture is quiet. No dimension produces a strong '
        f'effect on dec: the largest $\\eta^2$ over the six dimensions is '
        f'{attr.get("eta2_dec_max", 0.02):.3f}, and the strongest single '
        f'signal is the parameter rule '
        f'($\\eta^2 = {attr.get("kw_param_eta2", 0.013):.3f}$, '
        f'$H = {attr.get("kw_param_H", 25.4):.1f}$, $p < 0.001$), while the '
        f'mutation operator is not significant ($p = '
        f'{attr.get("kw_mut_p", 0.18):.2f}$). Where the dimensions do show '
        'structure is on the geometric descriptors rather than on the final '
        'gain: the parameter rule and the mutation operator carry the '
        'largest effects on the step-size ratio '
        f'($\\eta^2 = {attr.get("eta2_rho_param", 0.21):.2f}$ and '
        f'${attr.get("eta2_rho_mut", 0.19):.2f}$). Univariately, then, these '
        'two dimensions shape how candidates move, not whether the search '
        'ends better.')

    P.para(
        f'The standardized regression of dec on the six dimension codes '
        f'reported in Table {_next_table(P)} reverses the reading. With every '
        f'other '
        f'dimension controlled, the mutation operator carries the largest '
        f'coefficient ($\\beta = {attr.get("beta_mut", 0.76):+.2f}$, '
        f'95% CI [{_f(attr.get("beta_mut_lo", -0.003), 3, True)}, '
        f'{_f(attr.get("beta_mut_hi", 1.513), 3, True)}], '
        f'$p = {attr.get("beta_mut_p", 0.051):.3f}$), but its interval still '
        'contains zero and, with six terms tested, the coefficient does not '
        'survive a Holm correction: no single mechanism dimension is '
        'identified at this sample size. The parameter '
        f'rule\'s univariate advantage collapses to a non-significant '
        f'$\\beta = {attr.get("beta_param", 0.22):+.2f}$. A random-forest '
        f'permutation importance ranks the two leading dimensions the same '
        f'way (mutation {attr.get("rf_mut", 0.58):.2f}, param '
        f'{attr.get("rf_param", 0.18):.2f}, every other dimension at or below '
        f'{attr.get("rf_third", 0.04):.2f}), and '
        f'the collinearity is mild (the largest variance-inflation factor '
        f'is {attr.get("vif_max", 3.9):.2f}, below the usual threshold '
        f'of 5) so the reversal is '
        f'interpretable. That agreement is confined to the leading '
        f'dimensions: the middle band of Fig. {P.fig_no - 1} maps the two '
        f'orderings onto each other and shows that the strategy dimension, '
        f'second under $\\beta$, comes last under the random forest, its '
        f'coefficient resting on the widest interval of panel (a). '
        f'Univariately the mutation operator\'s effect is '
        f'split away by the strategy and archive dimensions with which it '
        f'is entangled, and it becomes the largest coefficient only once '
        f'those dimensions are held fixed. Neither reading is an '
        f'identification: with twenty-nine variants and six correlated '
        f'codes the attribution supports an ordering of the leading two '
        f'dimensions, not a claim that one of them carries the effect.')

    reg_rows = []
    for r in attr.get('raw', {}).get('regression', []):
        term = r.get('term')
        if term == 'intercept':
            continue
        b = float(r['beta'])
        rf = next((float(rr['importance'])
                   for rr in attr['raw']['rf_importance']
                   if rr.get('term') == term), float('nan'))
        reg_rows.append((b, [_DIM_LABEL.get(term, term), _f(b, 2, True),
                             _f(r['se'], 2),
                             f'[{_f(r["lo"], 3, True)}, '
                             f'{_f(r["hi"], 3, True)}]', _f(rf, 2)]))
    reg_rows.sort(key=lambda t: -t[0])
    reg_rows = [t[1] for t in reg_rows]
    P.table_caption(
        'Six-dimensional attribution of the intervention gain: $\\beta$ = '
        'standardized regression coefficient of dec on each dimension with the '
        'others controlled, RF = random-forest permutation importance. No '
        'interval excludes zero at $n=29$, so the coefficient column is an '
        'ordering of magnitudes; the RF column is a ranking of magnitudes and '
        'not an inferential statistic.')
    P.table(
        header=['Dimension', '$\\beta$', 'se', '95% CI', 'RF'],
        rows=reg_rows, widths=[1.7, 0.8, 0.7, 1.5, 0.7],
        align='lrrrr')

    np_by_dim = attr.get('np_by_dim', {})
    np_tot = sum(v['n'] for v in np_by_dim.values())
    P.para(
        f'A near-pair ablation gives the closest-to-causal check. '
        f'Enumerating every host pair that differs in exactly one dimension '
        f'({np_tot} pairs: param {np_by_dim.get("param", {}).get("n", 0)}, '
        f'mutation {np_by_dim.get("mutation", {}).get("n", 0)}, '
        f'pop {np_by_dim.get("pop", {}).get("n", 0)}, '
        f'other {np_by_dim.get("other", {}).get("n", 0)}; strategy '
        f'and archive yield none because they always co-vary) and asking how '
        f'far dec moves when only that dimension changes again singles out '
        f'the mutation operator as the only strong dimension: its pairs '
        f'move dec by $|\\Delta\\mathrm{{dec}}| = '
        f'{np_by_dim.get("mutation", {}).get("mean", 0.25):.2f}$ on average, '
        f'against {np_by_dim.get("param", {}).get("mean", 0.05):.2f} for '
        f'the parameter rule and below 0.01 for the rest; Table '
        f'{_next_table(P)} gives the per-dimension means. Figure {P.fig_no} '
        f'opens the same forty comparisons one row at a time: rows are '
        f'grouped by the dimension that differs and sorted by $\\Delta$dec, '
        f'and the colour gives the sign of that move, so the mutation block '
        f'is the only one whose rows are not balanced around zero. Each group '
        f'header carries the group\'s own $|\\Delta\\mathrm{{dec}}|$ '
        f'distribution (one dot per pair, a diamond for the mean and a bar '
        f'for its 95% $t$-interval), which places the main-effect view inside '
        f'the rows it summarises rather than in a separate panel, while the '
        f'signature block beside the rows repeats the three least redundant '
        f'UPCL descriptor deltas, so a group whose comparison moves dec can '
        f'also be read against the geometry that produced the move. The sign '
        f'is mixed and the spread large, driven by outliers such as '
        f'DE/rand/1/either-or, so the effect is a per-pair property rather '
        f'than a uniform dimension-wide shift; and because the 29 variants '
        f'are a designed sample, the group intervals are descriptive and not '
        f'a population claim.')

    np_summary = [[_DIM_LABEL.get(d, d), str(np_by_dim[d]['n']),
                   _f(np_by_dim[d]['mean'], 3)]
                  for d in ['mutation', 'param', 'pop', 'other']
                  if d in np_by_dim]
    P.table_caption(
        'Near-pair ablation: hosts that differ in exactly one mechanism '
        'dimension. $|\\Delta$dec$|$ is the mean absolute move of the '
        'intervention gain when only that dimension changes. The mutation '
        'operator is the dimension with the largest mean move of the four.')
    P.table(header=['Dimension', 'pairs', '$|\\Delta$dec$|$'],
            rows=np_summary, widths=[1.9, 0.7, 1.2], align='lrr')

    P.para(
        'Read together, the two steps give the same answer at two '
        'resolutions. The composition-level gradient says the field\'s '
        'progress is concentrated in the mechanisms that levels 2 and 3 '
        'add; the six-dimensional attribution orders the mutation operator '
        'ahead of the parameter rule that looks decisive univariately, with '
        'its entangled strategy and archive architecture, and the ordering '
        'is as far as twenty-nine variants resolve the question. The '
        'reversal is itself the finding: the winning mechanisms do not act '
        'independently, so only an attribution that controls the '
        'collinearity can order them.')

    # --- problem dependence -------------------------------------------------
    _cd = {r['category']: r for r in by_cat if r.get('category')}
    _cblk = {}
    for _r in S['category']:
        try:
            _cblk.setdefault(_r.get('category'), []).append(
                float(_r['dec_mean']))
        except (KeyError, TypeError, ValueError):
            continue
    _uni = _cblk.get('unimodal') or [0.0]
    _u_lo, _u_hi = min(_uni), max(_uni)

    def _cm(k, d=0.0):
        try:
            return float(_cd[k]['dec_mean'])
        except (KeyError, TypeError, ValueError):
            return d

    P.para(
        'The same observables, '
        'conditioned on the CEC function class, show that the gain is not '
        f'problem-agnostic, as Table {_next_table(P)} '
        'records, but the class signal is weak and is not ordered by '
        'difficulty. Pooled over the four blocks the mean gain is '
        f'${_f(_cm("unimodal"), 3, True)}$ on unimodal problems, '
        f'${_f(_cm("hybrid"), 3, True)}$ on hybrid, '
        f'${_f(_cm("composite"), 3, True)}$ on composite and '
        f'${_f(_cm("multimodal"), 3, True)}$ on multimodal ones, all four '
        'within a few hundredths of a decade of zero. The spread between '
        'blocks inside a single class is larger than any of those means: '
        'within the unimodal class alone the four block means range from '
        f'${_f(_u_lo, 3, True)}$ to ${_f(_u_hi, 3, True)}$. The class '
        'reading therefore locates no benefit; what it shows is that the '
        'sign of the effect is set at least as much by the benchmark block '
        'as by the landscape, and that a candidate-generation correction '
        'does not recover the shortfall on any class.')
    P.para(
        'Two further readings agree on the direction. The single '
        f'significant two-factor interaction is strategy $\\times$ param '
        f'($H = {attr.get("inter_H", 19.2):.1f}$, '
        f'$p = {attr.get("inter_p", 0.002):.3f}$): the parameter rule\'s '
        'effect depends on the single/pool operator-selection architecture, '
        'again a signature of coupling rather than independence. And the '
        'gain is itself concentrated in the early slack (the cumulative '
        'gain peaks around progress $\\approx$ 0.1-0.2 and then turns '
        'negative) consistent with the layer\'s conservative design and '
        'the reading that it profits only from slack left early.')
    cat_rows = [[r['category'],
                 _f(r['bare_median_log10err']),
                 _f(r['intervention_rate'], 3),
                 _f(r['dec_mean'], 3, True)]
                for r in by_cat]
    P.table_caption(
        'The same observables conditioned on the CEC function class: '
        'unimodal, multimodal, hybrid and composite. dec is the intervention '
        'gain; a negative value means the correction layer hurts on '
        'average.')
    P.table(header=['Category', 'bare', 'IR', 'dec'],
            rows=cat_rows, widths=[1.6, 1.1, 0.9, 1.0], align='lrrr')

    # --- substitutability ---------------------------------------------------
    cats = sorted({r['category'] for r in cat_level if r.get('category')})
    cmap = {(r['category'], int(r['level'])): r for r in cat_level
            if r.get('level') not in (None, '')}

    P.para(
        'The interaction of the two '
        'axes answers RQ3 and RQ4 directly. Table '
        f'{_next_table(P)} lays out the intervention gain by problem class '
        'and composition level. The pattern is a gradient along the level axis '
        'and nearly flat along the class axis. Vertically, the gain rises from '
        'level 0 to level 1, stays positive at level 2 and falls back to zero '
        'at level 3: only the lightly adapted variants '
        'leave slack that a generic correction can turn to profit, and the '
        'most capable variants leave none. Horizontally, the sign is set by '
        'the level rather than by the class: level 0 is negative in all four '
        'classes, most strongly on multimodal and unimodal problems, where '
        'a correction of a variant whose search already works does the most '
        'harm, while levels 1 and 2 are positive in all four. At level 3 the '
        'gain is indistinguishable from zero in three classes and nominally '
        'positive only on unimodal problems, where it rests on a handful of '
        'cells.')
    P.para(
        'Read as a whole, the matrix says why modern DE '
        'is hard to improve from outside: the mechanisms that carry its '
        'contribution are substitutive, they replace the rules that produce '
        'the candidate, and a layer confined to the candidate can add nothing '
        'to a rule that has already been replaced. The action decomposition '
        'of Section 4.2 makes the same point from the layer\'s own side: '
        'the reflect action, which re-aims a candidate only when its '
        'geometry is off, correlates at '
        f'$r = {attr.get("action_R_r", -0.50):+.2f}$ '
        f'($p = {attr.get("action_R_p", 0.006):.3f}$) with dec, hosts that '
        'need frequent geometric re-aiming gain systematically less, because '
        'the mechanism that already keeps their geometry right is exactly the '
        'one a candidate-level correction cannot restore.')

    P.para(
        'The gradient is monotone rather than abrupt, and that monotonicity '
        'is itself informative. Were the effect a threshold (variants below '
        'some capability leave slack, variants above it do not) one would '
        'expect a step at the boundary; instead the gain decays smoothly '
        'through levels 1 and 2 as each successive mechanism removes a '
        'different part of the slack the layer could have recovered. Level 1 '
        'adds the self-adaptive parameter rule, which still leaves the '
        'candidate geometry recoverable, hence the positive entries at that '
        'level in every class; level 2 adds the success-history memory and '
        'archive, which already re-aim candidates toward the elite; level 3 '
        'adds rank-based population-size reduction, which removes the last '
        'residual slack. Each step therefore subtracts a mechanism the layer '
        'depends on, which is exactly the substitutability reading: UPCL '
        'does not fail on modern DE because it is weak, but because the '
        'rules it would have to improve have been replaced before it ever '
        'sees the candidate.')

    cl_rows = [[cat,
                _f(cmap[(cat, 0)]['dec_mean'], 3, True) if (cat, 0) in cmap else '-',
                _f(cmap[(cat, 1)]['dec_mean'], 3, True) if (cat, 1) in cmap else '-',
                _f(cmap[(cat, 2)]['dec_mean'], 3, True) if (cat, 2) in cmap else '-',
                _f(cmap[(cat, 3)]['dec_mean'], 3, True) if (cat, 3) in cmap else '-']
               for cat in cats]
    P.table_caption(
        'Intervention gain (dec, positive is better) by problem class and '
        'composition level. The gradient answers RQ3-RQ4: level 0 is '
        'negative in every class and levels 1 and 2 positive in every class, '
        'while the gain collapses to zero at level 3.')
    P.table(header=['Category', 'L0', 'L1', 'L2', 'L3'],
            rows=cl_rows, widths=[1.6, 1.0, 1.0, 1.0, 1.0], align='lrrrr')


# ===========================================================================
# 5  Conclusion
# ===========================================================================
def _conclusion(P, S):
    st = S.get('stats', {})
    pr = S.get('probe', {})
    attr = S.get('attr', {})
    bare_top1 = pr.get('bare_top1', 'NL-SHADE-RSP')
    rho_hi = pr.get('rho_hi', 0.0)
    rho_lo = pr.get('rho_lo', 0.0)
    n_pool = st.get('n_pool', st.get('n', 0))
    P.h1('6  Conclusion')
    P.para(
        'The candidate turns out to be a usable point at which to observe a '
        'population-based search. Because every member of the DE family must '
        'emit a candidate $u_i$ for a target $x_i$, and hence a displacement '
        '$d_i$, the displacement is an observable that all variants expose in '
        'the same units, and a layer that reads only $(x_i,u_i)$ and the '
        'scalar response can be attached to any of them without knowledge '
        'of, or write access to, anything inside. Three properties (well '
        'defined for an opaque variant, identical evaluation accounting, and '
        'identity degeneracy in the absence of response evidence) hold by '
        'construction, so a paired comparison of a wrapped variant against '
        'its bare version cannot be confounded by extra function evaluations '
        'or by state the layer was not given.')

    P.para(
        'Across the twenty-nine-variant pool the probe reads a clear answer to RQ1. '
        'Mechanism contribution is dominated by a few substitutive '
        'mechanisms: the bare-performance gradient across the four '
        'composition levels shows the field\'s gains concentrated in the '
        'success-history memory with its external archive and in '
        'population-size reduction with selective pressure, while the two '
        'descriptor contrasts that carry signal (alignment with the variant '
        'displacement and proximity to the elite) are precisely the '
        'quantities those mechanisms store internally. The fingerprint thus '
        'reads back, from outside the variant, the mechanism the winning '
        'variants install inside.')

    P.para(
        'The six-dimensional attribution orders the answer to RQ1 without '
        'identifying a single dimension. Because the six codes are collinear '
        '(the mutation operator largely determines the strategy, and the '
        'parameter rule is strongly associated with the archive) a univariate '
        'reading credits the parameter rule, while a regression that controls '
        'the other dimensions puts the mutation operator first; its '
        f'coefficient ({attr.get("beta_mut", 0.76):+.2f}) nevertheless has an '
        'interval that contains zero and, with six terms tested, does not '
        'survive a Holm correction. The near-pair ablation agrees with that '
        'ordering -- the mutation dimension is the one whose change moves the '
        'gain most -- but with twenty-nine variants it is an ordering as '
        'well. What the section establishes is therefore the composition-'
        'level gradient of Section 4.3 and a rank order above it, not an '
        'attribution of the effect to one mechanism.')

    P.para(
        'The answer to RQ2 is that the contribution is weak everywhere, and '
        'its dependence runs along the instance axis rather than the class '
        'axis. Conditioned on the CEC function class, the '
        'intervention gain stays within a few hundredths of a decade of zero '
        'on all four classes, while the spread between the blocks inside a '
        'single class exceeds half a decade: a mechanism does not reliably '
        'help even where the problem already matches it, and a '
        'candidate-generation correction does not recover the shortfall '
        'where it does not. The ordering reappears across dimensions, so what '
        'does transfer is an instance-level effect rather than a class-level '
        'one.')

    P.para(
        'The intervention gain itself settles RQ3. On '
        f'fixed-parameter variants the layer intervenes on up to '
        f'{100.0 * rho_hi:.0f}% of candidates and, where the search already '
        'works, hurts; on the lightly adapted variants of level 1 it leaves '
        'externally recoverable slack that a correction can turn to profit; '
        'on the success-history variants of levels 2 and 3 the rate falls to '
        f'{100.0 * rho_lo:.1f}% or below and the gain collapses to zero. The '
        'contributing mechanisms are substitutable: they replace the rules '
        'that produce the candidate, and a layer confined to the candidate '
        'level has nothing left to recover.')

    P.para(
        'That is also the answer to RQ4. Modern DE is hard to improve from '
        'outside the variant not because the variant is opaque, but because its '
        'winning mechanisms already act at the very level at which an '
        'external correction would have to operate; the candidate generation stage is '
        'the wrong place to look for slack that has been internalised. The '
        'candidate generation stage thus emerges not as a third point of intervention, '
        'but as a probe: a single observable through which the mechanisms '
        'of differential '
        'evolution, otherwise hidden inside each variant, can be compared '
        f'and ordered, consistently with the bare ranking over all four '
        f'blocks, which places {bare_top1} first. The immediate '
        'steps that follow are the extension of the same probe to search '
        'families other than DE and to the higher dimensions that the budget '
        'rule makes affordable.')


# ---------------------------------------------------------------------------
def _appendix(P, S):
    """Appendix A: the per-function paired matrices of Section 4.3.

    The block-level reading stays in the main text; the matrices themselves are
    moved here so that the section is not forty pages of tables. Nothing is
    dropped: every cell of every matrix is still printed, and the appendix
    tables are numbered A1, A2, ... in the order the four blocks are described
    in Section 4.3, which is the numbering that section quotes.
    """
    jobs = S.get('exp2_appendix') or []
    if not jobs:
        return
    P.h1('Appendix A  Per-function paired matrices')
    P.para(
        'These are the matrices behind the block summaries of Section 4.3, '
        'printed in full so that the function-level entries are one page away '
        'from the ranking that reads them. Each table pairs the variant alone '
        'with the same variant under UPCL, two adjacent columns per variant, '
        'the median final error over the thirty runs of the cell; the green '
        'shading ranks the cells of a row (lightest = lowest error) and the '
        'final row gives each variant its rank within the suite (1 = best). '
        f'Tables A1 to A{len(jobs)} follow the order of the four blocks in '
        'Section 4.3: CEC 2017 at $D=30$, CEC 2017 at $D=50$, CEC 2022 at '
        '$D=10$ and CEC 2022 at $D=20$, and within a block the six variant '
        'generations from the fixed-parameter group to the rank-based and '
        'restart group.')
    for suite, dim, group_label, host_list, _m_rank, M in jobs:
        _emit_paired_matrix(
            P,
            f'Exp. 2, bare vs UPCL median final error (lower is '
            f'better), {suite} at $D={dim}$, {group_label} variants; '
            'green ranks each row (lightest = best error) and the final '
            'row gives the rank within the suite (1 = best).',
            M, host_list, _m_rank, appendix=True)

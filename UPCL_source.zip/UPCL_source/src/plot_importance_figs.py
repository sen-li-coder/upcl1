# -*- coding: utf-8 -*-
"""Importance-driven 'full-fill' figures around the dominant indicators
   (kappa > capacity > interv). Four figures:
   importance_ranking     : 4-method importance + composite rank
   kappa_dose             : kappa decile -> gain dose-response filled band
   capacity_kappa_contour : 2D filled terrain of the two leading mechanisms
   mechanism_stack        : 8 algorithms x 5 mechanism |effect| 100% stack
Run: python src/plot_importance_figs.py
"""
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr, binned_statistic_2d
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
import shap

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

SELECTED = ['NL-SHADE-RSP', 'MadDE', 'L-SHADE',
            'SHADE', 'JADE', 'jDE100', 'DE/best/1']
ALGO_COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',
               '#9467bd', '#8c564b', '#e377c2', '#7f7f7f']
MECH = ['rho', 'theta', 'eta', 'kappa', 'nu']
MECH_COL = {'rho': '#1f77b4', 'theta': '#2ca02c', 'eta': '#ff7f0e',
            'kappa': '#d62728', 'nu': '#9467bd'}
FEAT = {
    'capacity': 'bare_median_log10err',
    'rho': 'rho_step_effect', 'theta': 'theta_align_effect', 'eta': 'eta_elite_effect',
    'kappa': 'kappa_crowd_effect', 'nu': 'nu_novel_effect',
    'ri': 'ri_mean', 'interv': 'intervention_rate',
}


def _read():
    return list(csv.DictReader(open(TABLES / 'mech30_cells.csv', encoding='utf-8', newline='')))


def _f(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return np.nan
    return v if np.isfinite(v) else np.nan


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6, 'ytick.labelsize': 6,
        'legend.fontsize': 6, 'legend.frameon': False, 'figure.dpi': 300})


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[imp] {name}')


def _importance(rows):
    names = list(FEAT.keys()); cols = list(FEAT.values())
    X = np.array([[float(r[c]) for c in cols] for r in rows], dtype=float)
    y = np.array([_f(r['dec_median']) for r in rows], dtype=float)
    m = np.isfinite(X).all(axis=1) & np.isfinite(y)
    X, y = X[m], y[m]
    sr = [abs(spearmanr(X[:, j], y)[0]) for j in range(len(names))]
    beta = np.abs(Ridge(alpha=1.0).fit(StandardScaler().fit_transform(X), y).coef_)
    rf = RandomForestRegressor(n_estimators=300, random_state=0, n_jobs=-1).fit(X, y)
    pi = permutation_importance(rf, X, y, n_repeats=10, random_state=0, n_jobs=-1).importances_mean
    g = GradientBoostingRegressor(n_estimators=200, max_depth=3, random_state=0).fit(X, y)
    sv = shap.TreeExplainer(g).shap_values(X)
    sv = np.asarray(sv[0]) if isinstance(sv, list) else np.asarray(sv)
    sh = np.abs(sv).mean(axis=0)
    methods = {'Spearman |r|': sr, 'Ridge beta': beta, 'Permutation': pi, 'SHAP': sh}
    # composite rank
    rank = {}
    for k, v in methods.items():
        rank[k] = np.argsort(np.argsort(-np.asarray(v))) + 1
    mean_rank = np.mean([rank[k] for k in methods], axis=0)
    order = np.argsort(mean_rank)
    return names, methods, rank, mean_rank, order, X, y


def importance_ranking(names, methods, rank, mean_rank, order):
    n = len(names)
    fig, ax = plt.subplots(figsize=(6.2, 4.6))
    fig.subplots_adjust(left=0.18, right=0.96, top=0.92, bottom=0.09)
    ypos = np.arange(n)[::-1]
    mnames = list(methods.keys())
    for mi, mk in enumerate(mnames):
        v = np.array(methods[mk], dtype=float)
        v = v / (v.max() + 1e-9)
        ax.barh(ypos - 0.21 + mi * 0.14, v[order], height=0.13,
                color=plt.cm.tab10(mi), label=mk, alpha=0.85)
    ax.set_yticks(ypos)
    ax.set_yticklabels([names[i] for i in order], fontsize=6.5)
    ax.set_xlabel('normalized importance (0-1)')
    ax.set_xlim(0, 1.12)
    # composite rank badge
    for yi, oi in zip(ypos, order):
        ax.text(1.02, yi, f'#{int(mean_rank[oi])}', fontsize=6.5,
                va='center', color='#d62728', fontweight='bold')
    ax.set_title('indicator importance (4 methods, composite rank badge)', loc='left')
    ax.legend(loc='lower right', ncol=2, fontsize=5.5)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.4, alpha=0.5); ax.set_axisbelow(True)
    _save(fig, 'importance_ranking.png')


def kappa_dose(rows):
    kap = np.array([_f(r['kappa_crowd_effect']) for r in rows])
    gain = np.array([_f(r['dec_median']) for r in rows])
    m = np.isfinite(kap) & np.isfinite(gain)
    kap, gain = kap[m], gain[m]
    # deciles
    edges = np.percentile(kap, np.linspace(0, 100, 11))
    centers, means, ses, ns = [], [], [], []
    for i in range(10):
        sel = (kap >= edges[i]) & (kap <= edges[i + 1])
        sel = sel & (kap > edges[i]) | (sel & (i == 0))
        g = gain[(kap >= edges[i]) & (kap < edges[i + 1])]
        if i == 9:
            g = gain[(kap >= edges[i]) & (kap <= edges[i + 1])]
        if len(g) < 1:
            continue
        centers.append((edges[i] + edges[i + 1]) / 2)
        means.append(np.mean(g)); ses.append(np.std(g) / np.sqrt(len(g))); ns.append(len(g))
    centers = np.array(centers); means = np.array(means); ses = np.array(ses)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    fig.subplots_adjust(left=0.10, right=0.96, top=0.92, bottom=0.11)
    ax.fill_between(centers, means - 1.96 * ses, means + 1.96 * ses,
                    color='#d62728', alpha=0.18, linewidth=0)
    ax.plot(centers, means, color='#d62728', linewidth=1.6, marker='o', markersize=4)
    ax.axhline(0, color='#333333', linewidth=0.8, linestyle='--')
    # sample size annotation
    for x, y, nn in zip(centers, means, ns):
        ax.text(x, y + 0.02, str(nn), fontsize=5, ha='center', color='#888888')
    ax.set_xlabel('kappa (crowding effect) decile')
    ax.set_ylabel('mean gain (dec)')
    ax.set_title('dose-response: kappa (leading mechanism) -> gain', loc='left')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(color='#dddddd', linewidth=0.4, alpha=0.5); ax.set_axisbelow(True)
    _save(fig, 'kappa_dose.png')


def capacity_kappa_contour(rows):
    cap = np.array([_f(r['bare_median_log10err']) for r in rows])
    kap = np.array([_f(r['kappa_crowd_effect']) for r in rows])
    gain = np.array([_f(r['dec_median']) for r in rows])
    m = np.isfinite(cap) & np.isfinite(kap) & np.isfinite(gain)
    cap, kap, gain = cap[m], kap[m], gain[m]
    clo, chi = np.percentile(cap, [0.5, 99.5])
    klo, khi = np.percentile(kap, [0.5, 99.5])
    keep = (cap >= clo) & (cap <= chi) & (kap >= klo) & (kap <= khi)
    cap, kap, gain = cap[keep], kap[keep], gain[keep]

    stat, xe, ye, _ = binned_statistic_2d(cap, kap, gain, statistic='mean', bins=32)
    vmax = np.nanmax(np.abs(stat[np.isfinite(stat)]))
    from matplotlib.colors import TwoSlopeNorm
    fig, ax = plt.subplots(figsize=(6.4, 4.8))
    fig.subplots_adjust(left=0.10, right=0.82, top=0.92, bottom=0.11)
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax)
    cf = ax.contourf((xe[:-1] + xe[1:]) / 2, (ye[:-1] + ye[1:]) / 2, stat.T,
                     levels=16, cmap='RdBu_r', norm=norm)
    cs = ax.contour((xe[:-1] + xe[1:]) / 2, (ye[:-1] + ye[1:]) / 2, stat.T,
                    levels=7, colors='#333333', linewidths=0.4, alpha=0.5)
    ax.clabel(cs, inline=True, fontsize=4.5, fmt='%.2f')
    ax.set_xlabel('capacity (log10 error, lower = stronger)')
    ax.set_ylabel('kappa (crowding effect)')
    ax.set_title('gain terrain: capacity x kappa (two leading drivers)', loc='left')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    cbar = fig.colorbar(cf, ax=ax, fraction=0.05, pad=0.03)
    cbar.ax.tick_params(labelsize=5); cbar.set_label('mean gain', fontsize=6)
    _save(fig, 'capacity_kappa_contour.png')


def mechanism_stack(rows):
    by = {h: {k: [] for k in MECH} for h in SELECTED}
    for r in rows:
        if r['host'] not in by:
            continue
        by[r['host']]['rho'].append(abs(_f(r['rho_step_effect'])))
        by[r['host']]['theta'].append(abs(_f(r['theta_align_effect'])))
        by[r['host']]['eta'].append(abs(_f(r['eta_elite_effect'])))
        by[r['host']]['kappa'].append(abs(_f(r['kappa_crowd_effect'])))
        by[r['host']]['nu'].append(abs(_f(r['nu_novel_effect'])))
    M = np.array([[np.nanmedian(np.array(by[h][k])[np.isfinite(by[h][k])]) for k in MECH]
                  for h in SELECTED])
    M = M / (M.sum(axis=1, keepdims=True) + 1e-9)  # 100% normalize

    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    fig.subplots_adjust(left=0.16, right=0.96, top=0.92, bottom=0.10)
    left = np.zeros(len(SELECTED))
    for j, k in enumerate(MECH):
        ax.barh(np.arange(len(SELECTED)), M[:, j], left=left, height=0.66,
                color=MECH_COL[k], label=k, alpha=0.88)
        left += M[:, j]
    ax.set_yticks(np.arange(len(SELECTED)))
    ax.set_yticklabels(SELECTED, fontsize=6.5)
    ax.set_xlabel('share of mechanism-response |effect| (100%)')
    ax.set_title('mechanism composition of 8 algorithms', loc='left')
    ax.legend(loc='lower right', ncol=5, fontsize=5.5)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.4, alpha=0.5); ax.set_axisbelow(True)
    _save(fig, 'mechanism_stack.png')


if __name__ == '__main__':
    _style()
    rows = _read()
    names, methods, rank, mean_rank, order, X, y = _importance(rows)
    importance_ranking(names, methods, rank, mean_rank, order)
    kappa_dose(rows)
    capacity_kappa_contour(rows)
    mechanism_stack(rows)
    print('[imp] done ->', FIG)

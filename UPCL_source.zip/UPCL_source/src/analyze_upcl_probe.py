# -*- coding: utf-8 -*-
"""UPCL as a *mechanism probe* for advanced DE variants (read-only, zero reruns).

This reads the mechanism statistics that the UPCL layer already wrote into
every ``results/grid/raw/<suite>/D<dim>/<HOST>__F<fid>.json`` cell while the
bare-vs-UPCL grid was running, and turns them into a per-host "mechanism
fingerprint".  No experiment is re-run; the diagnostics are the ones the layer
computes on its own, namely the five proposal descriptors

    rho_step      z0  -- proposal step magnitude
    theta_align   z1  -- alignment with the successful search direction
    eta_elite     z2  -- alignment with the elite (best) direction
    kappa_crowd   z3  -- crowding around the proposal
    nu_novel      z4  -- novelty relative to the population

whose standardised working-vs-failing contrast (``descriptor_influence``,
``z{k}_effect = (mean_pos - mean_neg) / sd``) says *which signal the layer
actually exploits*, together with ``intervention_rate`` (how often the layer
had to step in) and the ``action_counts`` mix (identity / contract / expand /
reflect / perturb).

The key observable is the contrast between the six fixed-parameter hosts
(wave 0) and the self-adaptive / adaptive / LPSR families (waves 1-3): a
descriptor whose effect collapses in the advanced hosts is one whose mechanism
those hosts have already internalised, which is exactly what turns "UPCL does
not help them" into a *mechanism finding*.

    python src/analyze_upcl_probe.py
"""
import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

OUT = ROOT / 'results' / 'grid'
FIGDIR = OUT / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
FIGDIR.mkdir(parents=True, exist_ok=True)

# descriptor order is the z0..z4 order inside descriptor_influence
DESCRIPTORS = ['rho_step', 'theta_align', 'eta_elite', 'kappa_crowd', 'nu_novel']
DESC_LABEL = {
    'rho_step': 'rho_step\n(step)',
    'theta_align': 'theta_align\n(success dir.)',
    'eta_elite': 'eta_elite\n(elite dir.)',
    'kappa_crowd': 'kappa_crowd\n(crowding)',
    'nu_novel': 'nu_novel\n(novelty)',
}

try:
    import de_hosts_cec as DHC
    HOST_ORDER = list(DHC.CEC_HOST_ORDER)
    ADAPTIVITY = dict(DHC.ADAPTIVITY)
except Exception:                                  # pragma: no cover
    HOST_ORDER = []
    ADAPTIVITY = {}

WAVE_NAME = {0: 'fixed params', 1: 'self-adaptive', 2: 'adaptive/ensemble',
             3: 'LPSR / rank-based'}
WAVE_COLOR = {0: '#9e9e9e', 1: '#2e75b6', 2: '#548235', 3: '#c0504d'}

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 8,
    'axes.labelsize': 8.5,
    'axes.titlesize': 8.5,
    'legend.fontsize': 7,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'figure.dpi': 200,
    'savefig.dpi': 200,
    'savefig.bbox': 'tight',
})


def _wave(host):
    return ADAPTIVITY.get(host, -1)


def host_sort_key(host):
    """Order hosts by their adaptivity wave, then by their canonical order."""
    idx = HOST_ORDER.index(host) if host in HOST_ORDER else 999
    return (_wave(host), idx)


# --------------------------------------------------------------------------
def load_mechanism(path):
    """One cell -> dict of per-host mechanism stats, averaged over runs.

    Returns None when the cell has no UPCL arm or no mechanism block.
    """
    try:
        with open(path, encoding='utf-8') as fh:
            d = json.load(fh)
    except Exception:
        return None
    runs = d.get('runs', [])
    if not runs:
        return None

    effects = {k: [] for k in DESCRIPTORS}
    rates, shifts = [], []
    acts = defaultdict(float)
    n = 0
    for r in runs:
        arm = r.get('upcl') or r.get('full')
        if not isinstance(arm, dict):
            continue
        m = arm.get('upcl')
        if not isinstance(m, dict):
            continue
        di = m.get('descriptor_influence')
        if not isinstance(di, dict):
            continue
        n += 1
        for k, name in enumerate(DESCRIPTORS):
            v = di.get(f'z{k}_effect')
            if isinstance(v, (int, float)):
                effects[name].append(float(v))
        ir = m.get('intervention_rate')
        if isinstance(ir, (int, float)):
            rates.append(float(ir))
        mrs = m.get('mean_relative_shift')
        if isinstance(mrs, (int, float)):
            shifts.append(float(mrs))
        ac = m.get('action_counts')
        if isinstance(ac, dict):
            for a, v in ac.items():
                if isinstance(v, (int, float)):
                    acts[a] += float(v)

    if n == 0:
        return None
    total_act = sum(acts.values())
    return {
        'suite': d.get('suite', ''), 'dim': int(d.get('dim', 0)),
        'host': d.get('host', ''), 'fid': int(d.get('fid', 0)),
        'category': d.get('category', ''),
        'n_runs': n,
        'effects': {k: float(np.mean(v)) if v else float('nan')
                    for k, v in effects.items()},
        'effect_sd': {k: float(np.std(v)) if v else float('nan')
                      for k, v in effects.items()},
        'intervention_rate': float(np.mean(rates)) if rates else float('nan'),
        'mean_relative_shift': float(np.mean(shifts)) if shifts else float('nan'),
        'action_share': {a: (v / total_act if total_act else 0.0)
                         for a, v in acts.items()},
    }


def load_all():
    cells = {}
    base = OUT / 'raw'
    if not base.exists():
        return cells
    for p in sorted(base.glob('*/*/*.json')):
        c = load_mechanism(p)
        if c is None:
            continue
        key = (c['suite'], c['dim'], c['host'], c['fid'])
        cells[key] = c
    return cells


# --------------------------------------------------------------------------
def write_cells_csv(cells):
    fields = (['suite', 'dim', 'host', 'fid', 'category', 'n_runs']
              + DESCRIPTORS
              + ['intervention_rate', 'identity_share', 'mean_relative_shift',
                 'act_I', 'act_C', 'act_E', 'act_R', 'act_P'])
    rows = []
    for key, c in sorted(cells.items()):
        row = {'suite': c['suite'], 'dim': c['dim'], 'host': c['host'],
               'fid': c['fid'], 'category': c['category'], 'n_runs': c['n_runs']}
        for k in DESCRIPTORS:
            row[k] = f"{c['effects'][k]:.4f}"
        row['intervention_rate'] = f"{c['intervention_rate']:.6f}"
        row['identity_share'] = f"{1.0 - c['intervention_rate']:.6f}"
        row['mean_relative_shift'] = f"{c['mean_relative_shift']:.4f}"
        for a, col in zip('ICERP', ['act_I', 'act_C', 'act_E', 'act_R', 'act_P']):
            row[col] = f"{c['action_share'].get(a, 0.0):.4f}"
        rows.append(row)
    path = OUT / 'mechanism_cells.csv'
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print('[probe] cells ->', path.name, len(rows))
    return rows


def write_by_host_csv(cells):
    by = defaultdict(list)
    for c in cells.values():
        by[(c['suite'], c['dim'], c['host'])].append(c)

    fields = (['suite', 'dim', 'host', 'wave', 'n_cells']
              + DESCRIPTORS
              + ['intervention_rate', 'identity_share', 'mean_relative_shift'])
    rows = []
    for key in sorted(by, key=lambda k: (k[0], k[1], host_sort_key(k[2]))):
        suite, dim, host = key
        cs = by[key]
        row = {'suite': suite, 'dim': dim, 'host': host,
               'wave': _wave(host), 'n_cells': len(cs)}
        for k in DESCRIPTORS:
            vals = [c['effects'][k] for c in cs if not np.isnan(c['effects'][k])]
            row[k] = f"{np.mean(vals):.4f}" if vals else '-'
        irs = [c['intervention_rate'] for c in cs
               if not np.isnan(c['intervention_rate'])]
        row['intervention_rate'] = f"{np.mean(irs):.6f}" if irs else '-'
        row['identity_share'] = f"{1.0 - np.mean(irs):.6f}" if irs else '-'
        mrs = [c['mean_relative_shift'] for c in cs
               if not np.isnan(c['mean_relative_shift'])]
        row['mean_relative_shift'] = f"{np.mean(mrs):.4f}" if mrs else '-'
        rows.append(row)
    path = OUT / 'mechanism_by_host.csv'
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print('[probe] by-host ->', path.name, len(rows))
    return rows


# --------------------------------------------------------------------------
def fingerprint_figure(cells, suite, dim):
    """Rows = hosts (wave-sorted), columns = 5 descriptors, value = mean effect."""
    hosts = sorted({c['host'] for c in cells.values()
                    if c['suite'] == suite and c['dim'] == dim},
                   key=host_sort_key)
    if not hosts:
        return None
    M = np.full((len(hosts), len(DESCRIPTORS)), np.nan)
    for i, h in enumerate(hosts):
        vals = [cells[(suite, dim, h, f)]['effects']
                for f in sorted({c['fid'] for c in cells.values()
                                 if (c['suite'], c['dim'], c['host']) == (suite, dim, h)})]
        for j, k in enumerate(DESCRIPTORS):
            M[i, j] = np.mean([v[k] for v in vals if not np.isnan(v[k])]) \
                if vals else np.nan

    fig_w = max(5.0, 1.0 * len(DESCRIPTORS) + 3.0)
    fig_h = max(3.0, 0.34 * len(hosts) + 1.4)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    data = np.ma.array(M, mask=np.isnan(M))
    lim = float(np.nanmax(np.abs(M))) or 1.0
    cmap = plt.get_cmap('RdBu_r').copy()
    cmap.set_bad(color='#e8e8e8')
    im = ax.imshow(data, aspect='auto', cmap=cmap, vmin=-lim, vmax=lim)
    ax.set_xticks(range(len(DESCRIPTORS)))
    ax.set_xticklabels([DESC_LABEL[k] for k in DESCRIPTORS], fontsize=7)
    ax.set_yticks(range(len(hosts)))
    labels = []
    for h in hosts:
        w = _wave(h)
        labels.append(f'{h}  [{w}]')
    ax.set_yticklabels(labels, fontsize=7)
    for i, h in enumerate(hosts):
        ax.get_yticklabels()[i].set_color(WAVE_COLOR.get(_wave(h), '#000000'))
    for i in range(len(hosts)):
        for j in range(len(DESCRIPTORS)):
            if not np.isnan(M[i, j]):
                ax.text(j, i, f'{M[i, j]:+.2f}', ha='center', va='center',
                        fontsize=6.5,
                        color='white' if abs(M[i, j]) > 0.6 * lim else 'black')
    ax.set_title(f'{suite} $D={dim}$: UPCL mechanism fingerprint '
                 '(descriptor effect, mean over functions)')
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    cb.set_label('working-vs-failing descriptor contrast (effect)')
    cb.ax.tick_params(labelsize=7)
    legend = [Patch(color=WAVE_COLOR[w], label=f'wave {w}: {WAVE_NAME[w]}')
              for w in (0, 1, 2, 3)]
    ax.legend(handles=legend, loc='lower center', bbox_to_anchor=(0.5, -0.32),
              ncol=2, frameon=False, fontsize=6.5)
    fig.tight_layout()
    name = f'probe_fingerprint_{suite}_D{dim}.png'
    fig.savefig(FIGDIR / name)
    plt.close(fig)
    print('[probe] figure ->', name)
    return name


def selfsufficiency_figure(cells, suite, dim):
    """Intervention rate per host, wave-coloured; low rate = self-sufficient."""
    hosts = sorted({c['host'] for c in cells.values()
                    if c['suite'] == suite and c['dim'] == dim},
                   key=host_sort_key)
    if not hosts:
        return None
    rates, mins, maxs = [], [], []
    for h in hosts:
        vals = [c['intervention_rate'] * 100.0 for c in cells.values()
                if (c['suite'], c['dim'], c['host']) == (suite, dim, h)
                and not np.isnan(c['intervention_rate'])]
        rates.append(np.mean(vals) if vals else np.nan)
        mins.append(np.min(vals) if vals else np.nan)
        maxs.append(np.max(vals) if vals else np.nan)

    fig, ax = plt.subplots(figsize=(max(6.4, 0.5 * len(hosts)), 3.0))
    x = np.arange(len(hosts))
    colors = [WAVE_COLOR.get(_wave(h), '#000000') for h in hosts]
    ax.bar(x, rates, width=0.6, color=colors, edgecolor='0.3', lw=0.5)
    for i, h in enumerate(hosts):
        if not np.isnan(mins[i]):
            ax.plot([x[i], x[i]], [mins[i], maxs[i]], color='0.3', lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(hosts, rotation=60, ha='right', fontsize=6.5)
    ax.set_ylabel('UPCL intervention rate (%)')
    ax.set_title(f'{suite} $D={dim}$: how often UPCL had to intervene '
                 '(lower = host more self-sufficient)')
    ax.grid(axis='y', alpha=0.25, lw=0.4)
    legend = [Patch(color=WAVE_COLOR[w], label=f'wave {w}: {WAVE_NAME[w]}')
              for w in (0, 1, 2, 3)]
    ax.legend(handles=legend, loc='upper right', frameon=False, fontsize=6.5)
    fig.tight_layout()
    name = f'probe_selfsufficiency_{suite}_D{dim}.png'
    fig.savefig(FIGDIR / name)
    plt.close(fig)
    print('[probe] figure ->', name)
    return name


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--suites', nargs='+', default=None,
                    help='restrict to suite dim pairs, e.g. cec2017 30')
    a = ap.parse_args(argv)

    cells = load_all()
    if not cells:
        print('[probe] no grid mechanism data found')
        return

    dims = defaultdict(set)
    for c in cells.values():
        dims[c['suite']].add(c['dim'])
    print('[probe] loaded cells:', len(cells))
    for suite in sorted(dims):
        print(f'   {suite}: ' + ', '.join(f'D{d}' for d in sorted(dims[suite])))

    write_cells_csv(cells)
    write_by_host_csv(cells)

    targets = []
    for suite in sorted(dims):
        for dim in sorted(dims[suite]):
            if a.suites and (suite not in a.suites or str(dim) not in a.suites):
                continue
            targets.append((suite, dim))
    for suite, dim in targets:
        fingerprint_figure(cells, suite, dim)
        selfsufficiency_figure(cells, suite, dim)


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Terrain / ridge / volcano styled gallery for algorithm-level analysis.
   (1) volcano: 30 algos, x = mean gain (effect), y = -log10 p (t-test vs 0)
   (2) terrain: 2D density (capacity x gain) shaded-relief + contours + 30 hosts
   (3) ridge: 30-algo ridgeline of per-cell gain distribution
"""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde, ttest_1samp
from scipy.ndimage import gaussian_filter
from matplotlib.colors import LightSource
from matplotlib import patheffects as pe

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}
LEVEL_LABEL = {'0': 'L0 fixed', '1': 'L1 adaptive', '2': 'L2 archive', '3': 'L3 LPSR'}


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 9, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
        'legend.fontsize': 6.5, 'legend.frameon': False, 'figure.dpi': 300})


def _load():
    cells = list(csv.DictReader(open(TABLES / 'mech30_cells.csv',
                                     encoding='utf-8', newline='')))
    hosts = list(csv.DictReader(open(TABLES / 'mech30_host_summary.csv',
                                     encoding='utf-8', newline='')))
    order = sorted(hosts, key=lambda r: int(r['bare_rank']))
    return hosts, cells, order


def _legend():
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=6,
                       color=LEVEL_COL[l], label=LEVEL_LABEL[l]) for l in LEVEL_COL]


def _tag(ax, x, y, s, c, fs=5.0):
    ax.text(x, y, s, fontsize=fs, color=c, zorder=6, ha='left', va='center',
            path_effects=[pe.withStroke(linewidth=1.5, foreground='white')])


# ---- (1) volcano plot ----
def volcano(hosts, cells):
    by_host = {}
    for r in cells:
        by_host.setdefault(r['host'], []).append(_f(r['dec_median']))
    xs, ys, cols, sig_up, sig_dn = [], [], [], [], []
    labels = []
    for r in hosts:
        h = r['host']
        v = [x for x in by_host.get(h, []) if np.isfinite(x)]
        if len(v) < 5:
            continue
        x = _f(r['dec_mean'])
        t, p = ttest_1samp(v, 0.0)
        p = max(p, 1e-30)
        y = -np.log10(p)
        xs.append(x); ys.append(y); labels.append(h)
        if p < 0.05 and x > 0:
            cols.append('#d62728'); sig_up.append(h)
        elif p < 0.05 and x < 0:
            cols.append('#1f77b4'); sig_dn.append(h)
        else:
            cols.append('#9e9e9e')
    xs = np.array(xs); ys = np.array(ys)
    fig, ax = plt.subplots(figsize=(7.2, 5.6))
    fig.subplots_adjust(left=0.12, right=0.82, top=0.90, bottom=0.12)
    ax.scatter(xs, ys, s=58, c=cols, edgecolors='white', linewidths=0.6, zorder=3)
    for i, h in enumerate(labels):
        _tag(ax, xs[i], ys[i], h, cols[i])
    ax.axhline(-np.log10(0.05), color='#666666', lw=0.8, ls='--')
    ax.text(xs.min(), -np.log10(0.05) + 0.25, 'p = 0.05', fontsize=6.5,
            color='#666666', va='bottom')
    ax.axvline(0, color='#666666', lw=0.8, ls='--')
    ax.set_xlabel('effect size  dec (mean gain, + = improved)')
    ax.set_ylabel('-log10 p  (t-test, gain ≠ 0)')
    ax.set_title('Volcano: 30 algorithms (red = sig. improved, blue = sig. degraded)',
                 loc='left', fontsize=9)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(color='#e8e8e8', linewidth=0.4, alpha=0.6)
    ax.set_axisbelow(True)
    n_up, n_dn = len(sig_up), len(sig_dn)
    ax.text(0.02, 0.96, f'{n_up} improved / {n_dn} degraded / {len(labels)-n_up-n_dn} n.s.',
            transform=ax.transAxes, fontsize=6.5, va='top', color='#555555')
    fig.savefig(FIG / 'terrain_volcano.png', bbox_inches='tight')
    plt.close(fig)
    print('[terrain] terrain_volcano.png')


# ---- (2) terrain map (shaded relief) ----
def terrain_map(cells, hosts):
    bx = [_f(r['bare_median_log10err']) for r in cells]
    by = [_f(r['dec_median']) for r in cells]
    keep = [(np.isfinite(x) and np.isfinite(y)) for x, y in zip(bx, by)]
    bx = np.array(bx)[keep]; by = np.array(by)[keep]
    xl, xh = np.percentile(bx, [1, 99]); yl, yh = np.percentile(by, [1, 99])
    H, xe, ye = np.histogram2d(bx, by, bins=110, range=[[xl, xh], [yl, yh]])
    H = gaussian_filter(H, sigma=1.4)
    H = H / H.max()
    xc = (xe[:-1] + xe[1:]) / 2; yc = (ye[:-1] + ye[1:]) / 2
    X, Y = np.meshgrid(xc, yc)
    ls = LightSource(azdeg=315, altdeg=50)
    rgb = ls.shade(H.T, cmap=plt.cm.terrain, blend_mode='soft', vert_exag=6)
    fig, ax = plt.subplots(figsize=(7.2, 5.6))
    fig.subplots_adjust(left=0.12, right=0.90, top=0.90, bottom=0.13)
    ax.imshow(rgb, extent=[xl, xh, yl, yh], aspect='auto', origin='lower')
    cs = ax.contour(X, Y, H.T, levels=[0.25, 0.45, 0.65, 0.85],
                    colors='white', linewidths=0.4, alpha=0.55)
    for r in hosts:
        hx = _f(r['bare_median_log10err']); hy = _f(r['dec_mean'])
        c = LEVEL_COL[r['level']]
        ax.scatter(hx, hy, s=52, c=c, edgecolors='white', linewidths=0.9, zorder=5)
        _tag(ax, hx, hy, r['host'], '#111111', fs=4.6)
    ax.set_xlim(xl, xh); ax.set_ylim(yl, yh)
    ax.set_xlabel('capacity  log10 error (lower = stronger)')
    ax.set_ylabel('gain  dec (log10)')
    ax.set_title('Terrain: capacity × gain density (shaded relief + contours, 1590 cells)',
                 loc='left', fontsize=9)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    fig.legend(handles=_legend(), loc='right', bbox_to_anchor=(1.12, 0.5),
               ncol=1, handlelength=1.0)
    fig.savefig(FIG / 'terrain_map.png', bbox_inches='tight')
    plt.close(fig)
    print('[terrain] terrain_map.png')


# ---- (3) ridge / joyplot: 30-algo gain distribution ----
def ridge(cells, order):
    by_host = {}
    for r in cells:
        by_host.setdefault(r['host'], []).append(_f(r['dec_median']))
    allv = [x for r in order for x in by_host[r['host']] if np.isfinite(x)]
    xl, xh = np.percentile(allv, [0.5, 99.5])
    grid = np.linspace(xl, xh, 400)
    n = len(order)
    fig, ax = plt.subplots(figsize=(7.4, 0.42 * n + 1.6))
    fig.subplots_adjust(left=0.30, right=0.96, top=0.95, bottom=0.06)
    for i, r in enumerate(order):
        v = [x for x in by_host[r['host']] if np.isfinite(x)]
        if len(v) < 3:
            continue
        kde = gaussian_kde(v)
        d = kde(grid)
        d = d / d.max() * 0.86
        c = LEVEL_COL[r['level']]
        ybase = n - 1 - i
        ax.fill_between(grid, ybase, ybase + d, color=c, alpha=0.42, lw=0)
        ax.plot(grid, ybase + d, color=c, lw=0.8)
        ax.hlines(ybase, xl, xh, color='#dddddd', lw=0.35, alpha=0.6)
    ax.axvline(0, color='#333333', lw=1.0)
    ax.set_yticks(range(n))
    ax.set_yticklabels([r['host'] for r in order][::-1], fontsize=5.6)
    for i, r in enumerate(order):
        ax.get_yticklabels()[i].set_color(LEVEL_COL[r['level']])
    ax.set_ylim(-0.5, n - 0.5 + 0.9)
    ax.set_xlim(xl, xh)
    ax.set_xlabel('per-cell gain  dec (log10, + = improved)')
    ax.set_title('Ridge: 30-algorithm gain distribution (level-coloured, strong→weak top→bottom)',
                 loc='left', fontsize=9)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(False)
    fig.savefig(FIG / 'terrain_ridge.png', bbox_inches='tight')
    plt.close(fig)
    print('[terrain] terrain_ridge.png')


if __name__ == '__main__':
    _style()
    hosts, cells, order = _load()
    print(f'[terrain] {len(hosts)} hosts, {len(cells)} cells')
    volcano(hosts, cells)
    terrain_map(cells, hosts)
    ridge(cells, order)
    print('[terrain] done ->', FIG)

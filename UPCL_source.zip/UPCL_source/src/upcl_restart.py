# -*- coding: utf-8 -*-
"""UPCL-Restart: stagnation-triggered population restart (a DE-level mechanism).

This is UPCL re-purposed away from *proposal correction* and toward a mechanism
that plain DE is missing: **stagnation-triggered partial restart**.  None of the
20 hosts in the CEC order implements any restart -- when the difference vectors
collapse inside a basin, the search stalls and cannot escape.

The mechanism lives in the host (``de_hosts.DifferentialEvolution``), because a
restart must (a) re-evaluate new individuals and (b) replace individuals
bypassing the greedy selection -- neither of which a proposal hook can do.  It
is opt-in via ``restart_enable`` and off by default, so every host stays
bit-for-bit identical to the bare arm unless this runner turns it on.

Mechanism
---------
* detect: the host already counts ``stagnation`` = consecutive generations with
  no best improvement (zero extra evaluation);
* trigger: ``stagnation >= window``;
* act: reset the ``frac`` worst individuals (best kept) to uniform random points
  and re-evaluate them, spending the evaluation budget exactly like the normal
  loop -- so ``bare`` and ``restart`` compare under an identical ``max_evals``.

The runner mirrors ``run_route1_arm`` / ``run_mc_arm`` so the paired smoke
driver and downstream analysis are unchanged.
"""
from __future__ import annotations

import time

import numpy as np

from run_upcl_cec import N_GRID, _grid_interp


# ===========================================================================
# paired-arm runner
# ===========================================================================
def run_restart_arm(host_name, func, dim, seed, max_evals, pop_size,
                    window=30, frac=0.2, keep_best=True):
    """Run the host with the stagnation-triggered restart mechanism enabled."""
    import de_hosts

    host = de_hosts.get_host(host_name, dim, func.lb, func.ub, seed=seed,
                             pop_size=pop_size,
                             restart_enable=True,
                             restart_window=int(window),
                             restart_frac=float(frac),
                             restart_keep_best=bool(keep_best))

    t0 = time.perf_counter()
    best_f, _best_x, conv, evals = host.run(func, max_evals)
    wall = time.perf_counter() - t0

    grid = np.linspace(0.0, max_evals, N_GRID + 1)[1:]
    err_curve = _grid_interp(evals, conv, grid) - func.f_opt
    arm = f'rs_w{int(window)}_f{frac:g}'
    restart_stats = {
        'window': int(window),
        'frac': float(frac),
        'keep_best': bool(keep_best),
        'count': int(host.restart_count),
        'gens': [int(g) for g in host.restart_gens],
        'evals': int(host.restart_evals),
        'n_reset_total': int(host.restart_n_reset_total),
    }
    return {
        'host': host_name,
        'func': func.label,
        'fid': func.fid,
        'category': func.category,
        'suite': func.suite,
        'dim': dim,
        'seed': int(seed),
        'arm': arm,
        'max_evals': int(max_evals),
        'nevals': int(host.nevals),
        'err_final': float(best_f - func.f_opt),
        'err_curve': [float(v) for v in err_curve],
        'wall_time_s': float(wall),
        'grid': [float(v) for v in grid],
        'restart': restart_stats,
    }

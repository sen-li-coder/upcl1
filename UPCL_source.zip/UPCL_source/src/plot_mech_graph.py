# -*- coding: utf-8 -*-
"""Section-4 relationship map: the near-pair contrasts drawn as a graph.

Preview script -- deliberately standalone, it is *not* wired into
``analyze_mech_attribution.py`` or the paper build.  It reads the two tables
that already exist and renders ``results/cec/figures/attr_d8_near_graph.png``:

* ``results/cec/tables/mech30_host_summary.csv``  -> host, level, bare rank
* ``results/cec/tables/attr_d8_near_pairs.csv``   -> the 40 near pairs

Layout: the 29 variants are listed once, ordered by bare accuracy, down a single
column, and each near pair is an arc that leaves that column and comes back.

Two things make that readable, and both are about *geometry*, not styling.
First, the arcs do not live in four separate lanes: one column keeps the 40
pairs as a single network and leaves no half-empty panels behind.  Second --
and this was the actual bug in earlier drafts -- an arc's reach is proportional
to the number of rows it spans, computed in inches (one x unit == one inch,
one y unit == one row).  Pairs in this graph are *short* (median span 3 rows,
mean 4.8, longest 13), so a fixed reach of the kind an x/y-normalised axis
gives you turns every short pair into a big semicircular hook and the mutation
block into a ball of yarn.  A spectral row order was tested as an alternative
and helps much less (mean span 4.8 -> 3.3) than fixing the aspect ratio does.

Convention inherited from the table: a pair is ``(a, b)`` in taxonomy order
(mechanism level ascending), so ``d_dec = dec_b - dec_a``; positive means the
later variant in that order keeps *more* externally recoverable headroom.

Note: ``mech30_host_summary.csv`` still carries the pre-LSHADE-HS-deletion rank
column (values 1, 2, 4, ..., 30 -- rank 3 is a hole), so the rank is only used
here for *ordering* and is renumbered contiguously 1..29.

Usage:
    python src/plot_mech_graph.py [--out PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import PathPatch
from matplotlib.path import Path as MPath

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# Same hex order as analyze_mech_attribution.d8, keyed by edge count descending,
# so this figure stays colour-consistent with attr_d8_near_pairs.png.
DIM_COLS = ['#3C5488', '#00A087', '#E69F00', '#E64B35', '#4DBBD5', '#7E6148']
DESC = ['rho_step', 'theta_align', 'eta_elite', 'kappa_crowd', 'nu_novel']
DESC_LBL = ['step\nscale', 'success\nalignment', 'elite\nalignment',
            'crowding', 'direction\nnovelty']
LEVEL_COLS = ['#D9D9D9', '#9ECAE1', '#4292C6', '#08519C']
# readable mid-tones of the same ramp, for text (level-coded row labels)
LEVEL_TEXT = ['#8E8E8E', '#5B9BD5', '#1F6FB2', '#08306B']

# Figure geometry declared once.  Panel (A) derives its arc sizes from these
# numbers in inches, so the arcs keep the same shape if the canvas is resized.
FIG_W, FIG_H = 11.4, 9.8
GS_L, GS_R, GS_T, GS_B = 0.135, 0.975, 0.950, 0.125
GS_WSP, GS_HSP = 0.26, 0.50
GS_WR = (1.15, 1.0)


def ci95(vals):
    """Mean and 95% t-interval; degenerate for n < 2."""
    vals = np.asarray(vals, float)
    m, n = vals.mean(), len(vals)
    if n < 2:
        return m, m, m, n
    try:
        from scipy.stats import t as tdist
        se = vals.std(ddof=1) / np.sqrt(n)
        lo, hi = tdist.interval(0.95, n - 1, loc=m, scale=se)
    except Exception:
        se = vals.std(ddof=1) / np.sqrt(n)
        lo, hi = m - 1.96 * se, m + 1.96 * se
    return m, lo, hi, n


def main(out: Path) -> int:
    hosts = pd.read_csv(TAB / 'mech30_host_summary.csv')
    hosts['other'] = hosts['other'].fillna('')
    pairs = pd.read_csv(TAB / 'attr_d8_near_pairs.csv')

    # rank column of the summary has a hole (deleted host); renumber 1..29
    order = hosts.sort_values('bare_rank')['host'].tolist()
    rank = {h: i + 1 for i, h in enumerate(order)}
    level = dict(zip(hosts['host'], hosts['level'].astype(int)))
    n_host = len(order)

    dims = list(pairs['diff_dim'].value_counts().index)
    cmap = {d: DIM_COLS[i % len(DIM_COLS)] for i, d in enumerate(dims)}

    fig = plt.figure(figsize=(FIG_W, FIG_H))
    gs = fig.add_gridspec(2, 2, width_ratios=GS_WR, height_ratios=[1.0, 1.0],
                          wspace=GS_WSP, hspace=GS_HSP, left=GS_L, right=GS_R,
                          top=GS_T, bottom=GS_B)

    # ---------------------------------------------------------------- (A) graph
    # Panel (A) uses one x unit == one inch and one y unit == one row, so an
    # arc spanning N rows sticks out rho*N rows' worth of paper.  Getting that
    # ratio right is what stops the short pairs from ballooning into
    # semicircles and piling up into a ball of yarn.
    unit = (GS_R - GS_L) * FIG_W / (sum(GS_WR) * (1 + GS_WSP / 2))
    w_a = unit * GS_WR[0]
    row_in = (GS_T - GS_B) * FIG_H / (n_host + 2.0)
    rho, tie_d, strip_x = 0.44, 0.035, 2.42

    ax = fig.add_subplot(gs[:, 0])
    ax.set_xlim(-0.12, w_a - 0.12)
    ax.set_ylim(n_host + 1.0, -1.0)                  # rank 1 on top

    # one column of variants, arcs fanning right: no empty lanes anywhere
    ax.plot([0, 0], [0.9, n_host + 0.1], color='0.87', lw=1.3, zorder=1,
            solid_capstyle='round')
    ax.set_yticks(range(1, n_host + 1))
    ax.set_yticklabels([f'{i:>2}   {h}' for i, h in enumerate(order, 1)],
                       fontsize=9)
    for lab, h in zip(ax.get_yticklabels(), order):
        lab.set_color(LEVEL_TEXT[level.get(h, 0)])

    dmax = float(np.abs(pairs['d_dec']).max())
    edge = []
    for _, r in pairs.iterrows():
        ya, yb = rank[r['a']], rank[r['b']]
        edge.append({'d': r['diff_dim'], 'y0': min(ya, yb), 'y1': max(ya, yb),
                     'v': float(r['d_dec']), 'a': r['a'], 'b': r['b']})
    seen = {}
    for e in sorted(edge, key=lambda e: (e['y1'] - e['y0'], e['y0'])):
        e['span'] = e['y1'] - e['y0']
        k = seen.get(e['span'], 0)
        seen[e['span']] = k + 1
        e['bulge'] = rho * row_in * (e['span'] + 1.5) + tie_d * k

    for e in sorted(edge, key=lambda e: -e['bulge']):    # outer arcs behind
        lw = 1.5 + 4.0 * np.sqrt(abs(e['v']) / dmax)
        path = MPath([(0.0, e['y0']),
                      (2.0 * e['bulge'], 0.5 * (e['y0'] + e['y1'])),
                      (0.0, e['y1'])],
                     [MPath.MOVETO, MPath.CURVE3, MPath.CURVE3])
        style = '-' if e['v'] > 0 else (0, (2.8, 1.8))
        ax.add_patch(PathPatch(path, facecolor='none', edgecolor='white',
                               lw=lw + 2.0, alpha=0.95, zorder=2,
                               capstyle='round', joinstyle='round'))
        ax.add_patch(PathPatch(path, facecolor='none', edgecolor=cmap[e['d']],
                               lw=lw, alpha=0.9, zorder=3, linestyle=style,
                               capstyle='round', joinstyle='round'))

    # variant spine: node size = how many pairs that variant takes part in
    deg = pd.concat([pairs['a'], pairs['b']]).value_counts()
    for h, k in deg.items():
        ax.scatter(0.0, rank[h], s=26 + 16 * (k - 1), color='#37474F',
                   edgecolor='white', linewidth=1.1, zorder=4)

    ax.set_title('(A)  Near-pair relationship map: 40 pairs over the 29 '
                 'variants', fontsize=11, loc='left', pad=10)

    # ---- key: laid out down the strip the arcs leave free on the right
    sx = strip_x
    ax.text(sx, -0.50, 'dimension   (arc colour)', fontsize=8.4, color='0.3',
            va='center', fontweight='bold')
    for i, d in enumerate(dims):
        y = 0.60 + i * 0.95
        n_e = int((pairs['diff_dim'] == d).sum())
        ax.plot([sx, sx + 0.16], [y, y], color=cmap[d], lw=4.6, zorder=5,
                solid_capstyle='round')
        ax.text(sx + 0.22, y, f'{d}   {n_e} pair' + ('s' if n_e > 1 else ''),
                fontsize=8.4, color=cmap[d], va='center', fontweight='bold')

    ax.text(sx, 5.20, 'mechanism level\n(row-label colour)', fontsize=8.4,
            color='0.3', va='top', linespacing=1.5, fontweight='bold')
    for k in range(4):
        y = 7.80 + k * 0.95
        ax.plot([sx, sx + 0.16], [y, y], color=LEVEL_TEXT[k], lw=4.6,
                solid_capstyle='round', zorder=5)
        ax.text(sx + 0.22, y, f'L{k}', fontsize=8.4, va='center',
                color=LEVEL_TEXT[k], fontweight='bold')

    ax.text(sx, 12.60, 'how to read an arc', fontsize=8.4, color='0.3',
            va='bottom', fontweight='bold')
    bl = rho * row_in * 4.0                       # same reach for both samples
    for k, (lw, ls, lab) in enumerate([
            (5.6, '-', '|$\\Delta$dec| = 0.60'),
            (1.7, (0, (2.8, 1.8)), '|$\\Delta$dec| = 0.03')]):
        yc = 14.70 + k * 2.40
        p = MPath([(sx, yc - 1.25), (sx + 2 * bl, yc), (sx, yc + 1.25)],
                  [MPath.MOVETO, MPath.CURVE3, MPath.CURVE3])
        ax.add_patch(PathPatch(p, facecolor='none', edgecolor=cmap[dims[k]],
                               lw=lw, alpha=0.9, zorder=5, linestyle=ls,
                               capstyle='round'))
        ax.text(sx + 2 * bl + 0.06, yc, lab, fontsize=7.8, va='center',
                color=cmap[dims[k]])

    ax.text(sx, 19.60, 'widest arcs', fontsize=8.4, color='0.3', va='bottom',
            fontweight='bold')
    for k, e in enumerate(sorted(edge, key=lambda e: -abs(e['v']))[:3]):
        y = 20.95 + k * 2.80
        ax.text(sx, y, f'{abs(e["v"]):.2f}', fontsize=8.0, color=cmap[e['d']],
                va='top', fontweight='bold')
        ax.text(sx + 0.44, y, f'{e["a"]}\n{e["b"]}', fontsize=7.2,
                color='0.4', va='top', linespacing=1.45)

    ax.text(sx, 29.60, 'strategy, archive: 0 near pairs', fontsize=7.8,
            color='0.5', va='bottom', style='italic')

    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(axis='x', length=0, labelbottom=False)
    ax.tick_params(axis='y', length=0)

    # ------------------------------------------------------------ (B) |d_dec|
    axb = fig.add_subplot(gs[0, 1])
    rows = {}
    for i, d in enumerate(dims):
        vals = np.abs(pairs.loc[pairs['diff_dim'] == d, 'd_dec'].to_numpy())
        m, lo, hi, n = ci95(vals)
        rows[d] = (m, lo, hi, n)
    xmax = max(r[2] for r in rows.values()) * 1.55
    for i, d in enumerate(dims):
        m, lo, hi, n = rows[d]
        c = cmap[d]
        axb.plot([0, xmax], [i, i], color='0.94', lw=7, zorder=0,
                 solid_capstyle='round')
        axb.plot([max(lo, 0.0), hi], [i, i], color=c, lw=1.2, alpha=0.55,
                 zorder=1, solid_capstyle='round')
        axb.plot([0, m], [i, i], color=c, lw=2.6, alpha=0.5, zorder=2,
                 solid_capstyle='round')
        axb.plot([m], [i], marker='o', ms=9,
                 mfc=c if lo > 0 else 'white', mec=c, mew=1.8, zorder=3)
        axb.text(hi + xmax * 0.035, i, f'{m:.3f}   n={n}', va='center',
                 fontsize=8.4, color='0.3')
    axb.set_yticks(range(len(dims)))
    axb.set_yticklabels(dims, fontsize=9.5)
    for lab, d in zip(axb.get_yticklabels(), dims):
        lab.set_color(cmap[d])
        lab.set_fontweight('bold')
    axb.set_ylim(len(dims) - 0.55, -0.55)
    axb.set_xlim(-xmax * 0.02, xmax * 1.30)
    axb.axvline(0, color='0.55', lw=0.9, ls='--', zorder=1)
    axb.set_xlabel('mean |$\\Delta$dec| (log10 orders), 95% CI\n'
                   'hollow marker = CI spans zero', fontsize=8.4,
                   color='0.35')
    axb.set_title('(B)  Per-dimension effect strength', fontsize=10, loc='left')
    axb.spines[['top', 'right']].set_visible(False)

    # -------------------------------------------------- (C) descriptor profile
    axc = fig.add_subplot(gs[1, 1])
    mat = np.zeros((len(dims), len(DESC)))
    for i, d in enumerate(dims):
        sub = pairs[pairs['diff_dim'] == d]
        for j, k in enumerate(DESC):
            mat[i, j] = sub[f'd_{k}_effect'].mean()
    lim = float(np.abs(mat).max())
    im = axc.imshow(mat, cmap='RdBu_r', norm=TwoSlopeNorm(0.0, -lim, lim),
                    aspect='auto')
    axc.set_xticks(range(len(DESC)))
    axc.set_xticklabels(DESC_LBL, fontsize=8.2)
    axc.set_yticks(range(len(dims)))
    axc.set_yticklabels(dims, fontsize=9.5)
    for lab, d in zip(axc.get_yticklabels(), dims):
        lab.set_color(cmap[d])
        lab.set_fontweight('bold')
    for i in range(len(dims)):
        for j in range(len(DESC)):
            axc.text(j, i, f'{mat[i, j]:+.2f}', ha='center', va='center',
                     fontsize=8.8,
                     color='white' if abs(mat[i, j]) > 0.55 * lim else '0.15')
    axc.set_xticks(np.arange(-0.5, len(DESC), 1), minor=True)
    axc.set_yticks(np.arange(-0.5, len(dims), 1), minor=True)
    axc.grid(which='minor', color='white', lw=2.0)
    axc.set_title('(C)  What each dimension actually moves\n'
                  '(mean signed $\\Delta$ of the UPCL descriptor effects, '
                  'b - a)', fontsize=10, loc='left')
    cb = fig.colorbar(im, ax=axc, fraction=0.046, pad=0.04)
    cb.ax.tick_params(labelsize=7.6)

    fig.text(0.135, 0.010,
             'Mechanism relationship map from the 40 single-dimension near '
             'pairs (29 variants, descriptive);  rows ordered by bare accuracy, '
             'best on top.\n'
             'An arc joins one near pair:  width = |$\\Delta$dec|,  colour = '
             'the single dimension the pair differs in,  solid = '
             '$\\Delta$dec > 0,  dashed = $\\Delta$dec < 0.\n'
             '$\\Delta$dec = dec$_b$ - dec$_a$ with (a, b) in taxonomy order '
             '(mechanism level ascending), so $\\Delta$dec > 0 means the later '
             'variant keeps more externally recoverable headroom.',
             fontsize=8.4, color='0.35', va='bottom', linespacing=1.6)
    fig.savefig(out, dpi=150, bbox_inches='tight')
    plt.close(fig)

    # ------------------------------------------------------------- console
    print(f'[mech-graph] written -> {out}')
    print(f'[mech-graph] {"dim":<9} {"n":>3} {"mean|d_dec|":>12} '
          f'{"95% CI":>19} {"mean d_dec":>11}')
    for d in dims:
        sub = pairs[pairs['diff_dim'] == d]
        v = np.abs(sub['d_dec'].to_numpy())
        m, lo, hi, n = ci95(v)
        ci = f'[{lo:.4f}, {hi:.4f}]'
        print(f'[mech-graph] {d:<9} {n:>3} {m:>12.4f} {ci:>19} '
              f'{sub["d_dec"].mean():>11.4f}')
    return 0


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=str(FIG / 'attr_d8_near_graph.png'))
    sys.exit(main(Path(ap.parse_args().out)))

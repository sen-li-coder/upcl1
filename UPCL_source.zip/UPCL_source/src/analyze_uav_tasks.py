# -*- coding: utf-8 -*-
"""§5.4 逐任务拆分：把 UAV 拦截场景的结果按 F1-F4 任务拆开汇总。

与 ``analyze_uav_mech.py`` / ``analyze_uav_robust.py`` 口径一致，只是把聚合
维度从「跨任务」换成「按任务」（``fid``），使正文可以为每个任务单独给出

* 该任务上两臂的**分组增益**（组内指标 gain 均值 → 跨 29 宿主均值 + 95% CI），
* 该任务上增益的**宿主级同号率**（该 fid 上保持均值符号的宿主占比），
* 该任务上 27 项指标的**池中位数**（29 宿主 median 的中位数，bare/full 并列）。

产出（``results/apps/tables/``）：
    uav_task_summary.csv   fid × 指标组：mean_gain / CI / 同号率
    uav_task_metrics.csv   fid × 指标 × 臂：池中位数

用法：``python src/analyze_uav_tasks.py``
"""
import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from analyze_uav_mech import METRIC_GROUPS, GROUP_ORDER   # noqa: E402
from scipy import stats                                   # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'


def _rows(name):
    p = TAB / name
    if not p.exists():
        raise SystemExit(f'[analyze_uav_tasks] missing table: {p}')
    with open(p, encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh))


def group_gain_by_fid(delta_rows, scenario='intercept'):
    """每任务上每个指标组的宿主级 gain。

    返回 ``{fid: {group: [gain per host]}}``；组内指标先取均值，跨 3 次运行
    由 ``uav_upcl_delta.csv`` 自身的中位数口径承担。
    """
    metric_to_group = {m: g for g, ms in METRIC_GROUPS.items() for m in ms}
    acc = defaultdict(list)                      # (fid, host, group) -> [gain]
    for r in delta_rows:
        if r.get('scenario') != scenario:
            continue
        g = metric_to_group.get(r['metric'])
        if g is None:
            continue
        try:
            acc[(r['fid'], r['host'], g)].append(float(r['gain']))
        except (TypeError, ValueError):
            continue
    out = defaultdict(lambda: defaultdict(list))
    for (fid, _host, g), vals in acc.items():
        out[fid][g].append(float(np.mean(vals)))
    # 保证每个 fid / 组都有键（组内指标缺失时留空）
    for fid in out:
        for g in GROUP_ORDER:
            out[fid].setdefault(g, [])
    return out


def summarise(gains):
    """一组宿主级 gain → (mean, ci_lo, ci_hi, same_sign_ratio, n)。"""
    v = np.asarray([x for x in gains if np.isfinite(x)], float)
    if v.size == 0:
        return None
    n = v.size
    m = float(v.mean())
    if n > 1:
        se = float(v.std(ddof=1) / np.sqrt(n))
        ci = se * float(stats.t.ppf(0.975, n - 1))
    else:
        ci = 0.0
    same = int(np.sum(np.sign(v) == np.sign(m))) if abs(m) > 1e-12 else 0
    return m, m - ci, m + ci, same / n, n


def pool_medians(cell_rows, scenario='intercept'):
    """每任务 / 指标 / 臂的池中位数（29 宿主 median 的中位数）。"""
    names = sorted({m for ms in METRIC_GROUPS.values() for m in ms})
    acc = defaultdict(list)
    for r in cell_rows:
        if r.get('scenario') != scenario:
            continue
        for name in names:
            key = f'{name}_median'
            if key not in r:
                continue
            try:
                acc[(r['fid'], name, r['arm'])].append(float(r[key]))
            except (TypeError, ValueError):
                continue
    return {k: float(np.median(v)) for k, v in acc.items()}, names


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--scenario', default='intercept')
    args = ap.parse_args(argv)

    delta_rows = _rows('uav_upcl_delta.csv')
    cell_rows = _rows('uav_metric_cells.csv')

    # --- 逐任务分组增益 ---------------------------------------------------
    gains = group_gain_by_fid(delta_rows, args.scenario)
    fids = sorted(gains, key=int)
    summary_rows = []
    for fid in fids:
        for g in GROUP_ORDER:
            st = summarise(gains[fid][g])
            if st is None:
                continue
            m, lo, hi, same, n = st
            summary_rows.append(dict(fid=fid, metric_group=g,
                                     mean_gain=round(m, 5),
                                     ci_lo=round(lo, 5), ci_hi=round(hi, 5),
                                     same_sign_pct=round(100 * same, 2),
                                     n_host=n))
    with open(TAB / 'uav_task_summary.csv', 'w', newline='',
              encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['fid', 'metric_group', 'mean_gain',
                                           'ci_lo', 'ci_hi', 'same_sign_pct',
                                           'n_host'])
        w.writeheader()
        w.writerows(summary_rows)

    # --- 逐任务指标池中位数 -----------------------------------------------
    med, names = pool_medians(cell_rows, args.scenario)
    metric_rows = []
    for fid in fids:
        for name in names:
            for arm in ('bare', 'full'):
                v = med.get((fid, name, arm))
                if v is None:
                    continue
                metric_rows.append(dict(fid=fid, metric=name, arm=arm,
                                        pool_median=round(v, 6)))
    with open(TAB / 'uav_task_metrics.csv', 'w', newline='',
              encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['fid', 'metric', 'arm',
                                           'pool_median'])
        w.writeheader()
        w.writerows(metric_rows)

    # --- 控制台摘要 -------------------------------------------------------
    print('=== §5.4 逐任务分组增益（29 宿主均值 [95% CI]，同号率）===')
    head = 'group'.ljust(12) + ''.join(f'F{f}'.rjust(26) for f in fids)
    print(head)
    for g in GROUP_ORDER:
        line = g.ljust(12)
        for fid in fids:
            r = next((x for x in summary_rows
                      if x['fid'] == fid and x['metric_group'] == g), None)
            if r is None:
                line += '-'.rjust(26)
            else:
                line += (f'{r["mean_gain"]:+7.3f} '
                         f'[{r["ci_lo"]:+6.2f},{r["ci_hi"]:+6.2f}] '
                         f'{r["same_sign_pct"]:4.0f}%').rjust(26)
        print(line)
    print(f'[analyze_uav_tasks] wrote uav_task_summary.csv '
          f'({len(summary_rows)} rows) + uav_task_metrics.csv '
          f'({len(metric_rows)} rows)')


if __name__ == '__main__':
    main()

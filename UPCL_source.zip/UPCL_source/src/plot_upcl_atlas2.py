# -*- coding: utf-8 -*-
"""UPCL mechanism atlas v2 - richer composite narrative figures."""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from scipy.stats import gaussian_kde, spearmanr

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FIG_W = 6.3

LEVELS = [0, 1, 2, 3]
LEVEL_COLORS = {0: '#d62728', 1: '#ff7f0e', 2: '#2ca02c', 3: '#1f77b4'}
LEVEL_LABELS = {0: 'L0 fixed', 1: 'L1 adaptive', 2: 'L2 archive', 3: 'L3 LPSR'}
ARMS = ['bare', 'full', 'mem1', 'no_minimal', 'random']
ARM_COLORS = {'bare': '#999999', 'full': '#1f77b4', 'mem1': '#2ca02c',
              'no_minimal': '#d62728', 'random': '#ff7f0e'}
ARM_LABELS = {'bare': 'bare', 'full': 'full', 'mem1': 'memory 1',
              'no_minimal': 'no gate', 'random': 'random'}
DESCRIPTORS = [('rho_step_effect', 'step'), ('theta_align_effect', 'align'),
               ('eta_elite_effect', 'elite'), ('kappa_crowd_effect', 'crowd'),
               ('nu_novel_effect', 'novel')]
CAT_ORDER = ['unimodal', 'multimodal', 'hybrid', 'composite']
CAT_LABELS = {'unimodal': 'uni-modal', 'multimodal': 'multi-modal',
              'hybrid': 'hybrid', 'composite': 'composite'}


def _read(name):
    p = TABLES / name
    if not p.exists():
        raise SystemExit(f'missing: {p}')
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6.5, 'ytick.labelsize': 7,
        'legend.fontsize': 6.5, 'legend.frameon': False, 'figure.dpi': 300})


def _despine(ax, grid=True):
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    if grid:
        ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
        ax.set_axisbelow(True)


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[atlas2] {name}')


def _level_legend():
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=5,
                       color=LEVEL_COLORS[lv], label=LEVEL_LABELS[lv])
            for lv in LEVELS]


def _half_cloud(ax, vals, xc, color, spread=0.36, n=200):
    v = np.asarray([x for x in vals if np.isfinite(x)], dtype=float)
    if len(v) < 3:
        return
    lo, hi = np.percentile(v, [2, 98]); pad = (hi - lo) * 0.15
    xs = np.linspace(lo - pad, hi + pad, n)
    try:
        d = gaussian_kde(v)(xs)
    except Exception:
        return
    d = d / d.max() * spread
    ax.fill_betweenx(xs, xc, xc + d, color=color, alpha=0.30, lw=0)
    ax.plot(xc + d, xs, color=color, lw=0.7)


def _raincloud(ax, groups, colors, labels, ylabel=None):
    for i, (vals, c) in enumerate(zip(groups, colors)):
        v = np.asarray([x for x in vals if np.isfinite(x)], dtype=float)
        if len(v) == 0:
            continue
        _half_cloud(ax, v, i, c)
        rng = np.random.default_rng(100 + i)
        ax.scatter(i + rng.uniform(-0.13, 0.13, len(v)), v, s=6, color=c,
                   alpha=0.38, edgecolors='none', linewidths=0)
        ax.plot([i - 0.16, i + 0.16], [np.median(v)] * 2, color='#111111', lw=1.2)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels, fontsize=6.5)
    if ylabel:
        ax.set_ylabel(ylabel)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='y', color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)


# ---- P0 ablation: forest plot + rank + intervention ----
def ablation(cells, friedman):
    fig = plt.figure(figsize=(FIG_W, 3.0))
    gs = gridspec.GridSpec(1, 3, width_ratios=[1.45, 1.0, 1.0],
                           left=0.08, right=0.98, top=0.86, bottom=0.20, wspace=0.45)
    ax = fig.add_subplot(gs[0])
    meds, los, his = [], [], []
    for a in ARMS:
        d = np.array([_f(r['dec_vs_bare']) for r in cells if r['arm'] == a])
        d = d[np.isfinite(d)]
        meds.append(np.median(d)); los.append(np.median(d) - np.percentile(d, 25))
        his.append(np.percentile(d, 75) - np.median(d))
    ys = list(range(len(ARMS)))
    for i, a in enumerate(ARMS):
        ax.errorbar([meds[i]], [ys[i]], xerr=[[los[i]], [his[i]]], fmt='o',
                    markersize=5, elinewidth=1.4, capsize=3, capthick=1.2,
                    color=ARM_COLORS[a], ecolor='#666666', zorder=3)
    ax.axvline(0, color='#333333', linewidth=0.9)
    ax.set_yticks(list(ys)); ax.set_yticklabels([ARM_LABELS[a] for a in ARMS])
    ax.invert_yaxis()
    ax.set_xlabel('dec vs bare (decades, + better)')
    ax.set_title('a  effect size vs bare', loc='left')
    _despine(ax, grid=False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.5, alpha=0.7); ax.set_axisbelow(True)

    ax = fig.add_subplot(gs[1])
    keys = [f'rank_{a}' for a in ARMS]
    means = [np.nanmean([_f(r[k]) for r in friedman]) for k in keys]
    order = np.argsort(means)[::-1]
    lab = [ARM_LABELS[ARMS[i]] for i in order]
    ax.barh(range(5), [means[i] for i in order], color=[ARM_COLORS[ARMS[i]] for i in order],
            height=0.6, alpha=0.85)
    ax.set_yticks(range(5)); ax.set_yticklabels(lab)
    ax.invert_yaxis()
    ax.set_xlabel('Friedman mean rank (lower better)')
    ax.set_title('b  ranking', loc='left')
    _despine(ax)
    for i, o in enumerate(order):
        ax.text(means[o] + 0.08, i, f'{means[o]:.2f}', va='center', fontsize=6)

    ax = fig.add_subplot(gs[2])
    ir = [100.0 * np.nanmean([_f(r['intervention_rate']) for r in cells
                              if r['arm'] == a]) for a in ARMS]
    ax.barh(range(5), ir, color=[ARM_COLORS[a] for a in ARMS], height=0.6, alpha=0.85)
    ax.set_yticks(range(5)); ax.set_yticklabels([ARM_LABELS[a] for a in ARMS])
    ax.invert_yaxis()
    ax.set_xlabel('intervention rate (%)')
    ax.set_title('c  how much each intervenes', loc='left')
    _despine(ax)
    for i, v in enumerate(ir):
        ax.text(v + 0.5, i, f'{v:.0f}%', va='center', fontsize=6)
    _save(fig, 'atlas2_ablation.png')


# ---- P1 capacity vs gain: joint plot + per-cell hexbin ----
def capacity_gain(hosts, cells):
    lvmap = {r['host']: int(r['level']) for r in hosts}
    fig = plt.figure(figsize=(FIG_W, 3.3))
    gs = gridspec.GridSpec(2, 2, width_ratios=[3.2, 1], height_ratios=[1, 3.2],
                           left=0.10, right=0.97, top=0.90, bottom=0.15,
                           wspace=0.05, hspace=0.05)
    ax = fig.add_subplot(gs[1, 0])
    axT = fig.add_subplot(gs[0, 0], sharex=ax)
    axR = fig.add_subplot(gs[1, 1], sharey=ax)
    xs = [_f(r['bare_median_log10err']) for r in hosts]
    ys = [_f(r['dec_mean']) for r in hosts]
    cols = [LEVEL_COLORS[int(r['level'])] for r in hosts]
    ax.scatter(xs, ys, s=46, c=cols, edgecolors='white', linewidths=0.6, zorder=3)
    ax.axhline(0, color='#666666', lw=0.6, zorder=1)
    ax.set_xlabel('bare median log10 error (lower = stronger)')
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title('a  30 hosts: gain vs capacity', loc='left')
    _despine(ax)
    for lv in LEVELS:
        v = [_f(r['bare_median_log10err']) for r in hosts if int(r['level']) == lv]
        v = [x for x in v if np.isfinite(x)]
        if len(v) >= 3:
            xx = np.linspace(min(v), max(v), 200)
            dd = gaussian_kde(v)(xx)
            axT.plot(xx, dd, color=LEVEL_COLORS[lv], lw=1.0)
            axT.fill_between(xx, dd, color=LEVEL_COLORS[lv], alpha=0.14)
    axT.set_ylabel('density', fontsize=6.5); axT.tick_params(labelsize=6)
    for sp in ('top', 'right', 'bottom'):
        axT.spines[sp].set_visible(False)
    axT.set_xticks([])
    for lv in LEVELS:
        v = [_f(r['dec_mean']) for r in hosts if int(r['level']) == lv]
        v = [x for x in v if np.isfinite(x)]
        if len(v) >= 3:
            yy = np.linspace(min(v), max(v), 200)
            dd = gaussian_kde(v)(yy)
            axR.plot(dd, yy, color=LEVEL_COLORS[lv], lw=1.0)
            axR.fill_betweenx(yy, dd, color=LEVEL_COLORS[lv], alpha=0.14)
    axR.set_xlabel('density', fontsize=6.5); axR.tick_params(labelsize=6)
    for sp in ('top', 'right', 'left'):
        axR.spines[sp].set_visible(False)
    axR.set_yticks([])
    axin = fig.add_axes([0.60, 0.46, 0.34, 0.40])
    cx = [_f(r['bare_median_log10err']) for r in cells]
    cy = [_f(r['dec_median']) for r in cells]
    keep = [np.isfinite(x) and np.isfinite(y) for x, y in zip(cx, cy)]
    cx = np.array(cx)[keep]; cy = np.array(cy)[keep]
    hb = axin.hexbin(cx, cy, gridsize=20, cmap='Blues', mincnt=1, linewidths=0.15)
    axin.axhline(0, color='#1f77b4', lw=0.7)
    axin.set_title('b  1590 cells (hexbin density)', fontsize=6.5, loc='left')
    axin.set_xlabel('bare err', fontsize=6); axin.set_ylabel('gain', fontsize=6)
    axin.tick_params(labelsize=5.5)
    for sp in ('top', 'right'):
        axin.spines[sp].set_visible(False)
    fig.legend(handles=_level_legend(), loc='upper center', ncol=4, frameon=False,
               bbox_to_anchor=(0.5, 0.985), handlelength=1.0, columnspacing=1.2)
    _save(fig, 'atlas2_capacity_gain.png')


# ---- P1 gain distribution: raincloud ----
def gain_dist(cells, hosts):
    lvmap = {r['host']: int(r['level']) for r in hosts}
    fig, ax = plt.subplots(figsize=(FIG_W, 2.6))
    fig.subplots_adjust(left=0.12, right=0.96, top=0.88, bottom=0.16)
    groups = [[_f(r['dec_median']) for r in cells if lvmap[r['host']] == lv]
              for lv in LEVELS]
    _raincloud(ax, groups, [LEVEL_COLORS[lv] for lv in LEVELS],
               [LEVEL_LABELS[lv] for lv in LEVELS],
               ylabel='intervention gain (dec)')
    ax.axhline(0, color='#666666', lw=0.6)
    ax.set_title('gain distribution by composition level (raincloud)',
                 loc='left', fontsize=8)
    for lv in LEVELS:
        v = [x for x in groups[lv] if np.isfinite(x)]
        neg = sum(1 for x in v if x < 0)
        ax.text(lv, ax.get_ylim()[0], f'{neg}/{len(v)} neg', ha='center',
                va='bottom', fontsize=5.8, color='#666666')
    _save(fig, 'atlas2_gain_dist.png')


# ---- P2 descriptor signal: radar + correlation ----
def descriptor_signal(hosts):
    ranks = [_f(r['bare_rank']) for r in hosts]
    decs = [_f(r['dec_mean']) for r in hosts]
    labels = [s for _, s in DESCRIPTORS]
    fig = plt.figure(figsize=(FIG_W, 2.7))
    fig.subplots_adjust(left=0.06, right=0.98, top=0.86, bottom=0.14, wspace=0.32)
    ax = fig.add_subplot(1, 2, 1, polar=True)
    N = len(DESCRIPTORS)
    ang = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    ang += ang[:1]
    allv = []
    for lv in LEVELS:
        vals = [np.nanmean([_f(r[col]) for r in hosts if int(r['level']) == lv])
                for col, _ in DESCRIPTORS]
        allv += vals
        v = vals + vals[:1]
        ax.plot(ang, v, color=LEVEL_COLORS[lv], lw=1.5, label=LEVEL_LABELS[lv])
        ax.fill(ang, v, color=LEVEL_COLORS[lv], alpha=0.06)
    ax.set_xticks(ang[:-1]); ax.set_xticklabels(labels, fontsize=7)
    lo, hi = min(allv), max(allv)
    ax.set_ylim(lo - 0.05, hi + 0.05)
    ax.tick_params(labelsize=6)
    ax.set_title('a  descriptor profile by level', loc='left', fontsize=8)
    ax.grid(True, color='#dddddd', lw=0.5)
    ax2 = fig.add_subplot(1, 2, 2)
    x = np.arange(N); w = 0.38
    rho_rank = [spearmanr([_f(r[col]) for r in hosts], ranks)[0]
                for col, _ in DESCRIPTORS]
    rho_dec = [spearmanr([_f(r[col]) for r in hosts], decs)[0]
               for col, _ in DESCRIPTORS]
    ax2.bar(x - w / 2, rho_rank, w, color='#1f77b4', label='with bare rank')
    ax2.bar(x + w / 2, rho_dec, w, color='#d62728', label='with gain')
    ax2.axhline(0, color='#666666', lw=0.6)
    ax2.set_xticks(x); ax2.set_xticklabels(labels)
    ax2.set_ylabel('Spearman rho')
    ax2.set_title('b  descriptor correlation', loc='left')
    ax2.legend(loc='best')
    _despine(ax2)
    _save(fig, 'atlas2_descriptor_signal.png')


# ---- P2 gate: hexbin scatter + rejection raincloud ----
def gate(hosts):
    pol = [_f(r['policy_rate']) for r in hosts]
    itv = [_f(r['intervention_rate']) for r in hosts]
    cols = [LEVEL_COLORS[int(r['level'])] for r in hosts]
    fig = plt.figure(figsize=(FIG_W, 2.9))
    fig.subplots_adjust(left=0.10, right=0.97, top=0.84, bottom=0.16, wspace=0.32)
    ax = fig.add_subplot(1, 2, 1)
    ax.hexbin(pol, itv, gridsize=24, cmap='Blues', mincnt=1, linewidths=0.15)
    ax.scatter(pol, itv, s=26, c=cols, edgecolors='white', linewidths=0.5, zorder=3)
    m = max(max(pol), max(itv)) * 1.05
    ax.plot([0, m], [0, m], color='#888888', lw=0.7, ls='--')
    ax.set_xlabel('policy rate (proposed)')
    ax.set_ylabel('intervention rate (accepted)')
    ax.set_title('a  proposal vs acceptance', loc='left')
    _despine(ax)
    ax2 = fig.add_subplot(1, 2, 2)
    gap = [i - p for p, i in zip(pol, itv)]
    groups = [[g for g, r in zip(gap, hosts) if int(r['level']) == lv] for lv in LEVELS]
    _raincloud(ax2, groups, [LEVEL_COLORS[lv] for lv in LEVELS],
               [LEVEL_LABELS[lv] for lv in LEVELS],
               ylabel='intervention - policy')
    ax2.axhline(0, color='#666666', lw=0.6)
    ax2.set_title('b  gate rejection by level', loc='left')
    fig.legend(handles=_level_legend(), loc='upper center', ncol=4, frameon=False,
               bbox_to_anchor=(0.5, 0.98), handlelength=1.0, columnspacing=1.2)
    _save(fig, 'atlas2_gate.png')


# ---- P2 level gradient: host x category heatmap ----
def level_gradient(hosts, cells):
    hs = sorted(hosts, key=lambda r: (int(r['level']), _f(r['bare_rank'])))
    hnames = [r['host'] for r in hs]
    hlvs = [int(r['level']) for r in hs]
    idx = {h: i for i, h in enumerate(hnames)}
    M = np.full((len(hnames), len(CAT_ORDER)), np.nan)
    for r in cells:
        if r['host'] in idx and r['category'] in CAT_ORDER:
            M[idx[r['host']], CAT_ORDER.index(r['category'])] = _f(r['dec_median'])
    vmax = min(np.nanmax(np.abs(M)), 0.5)
    fig, ax = plt.subplots(figsize=(FIG_W, 4.6))
    fig.subplots_adjust(left=0.28, right=0.92, top=0.94, bottom=0.08)
    im = ax.imshow(M, aspect='auto', cmap='RdBu_r', vmin=-vmax, vmax=vmax)
    ax.set_xticks(range(len(CAT_ORDER)))
    ax.set_xticklabels([CAT_LABELS[c] for c in CAT_ORDER], fontsize=7)
    ax.set_yticks(range(len(hnames)))
    ax.set_yticklabels(hnames, fontsize=5.2)
    ax.tick_params(top=True, bottom=False, labeltop=True, labelbottom=False)
    ax.grid(False)
    for i in range(1, len(hnames)):
        if hlvs[i] != hlvs[i - 1]:
            ax.axhline(i - 0.5, color='#111111', lw=0.8)
    for i, lv in enumerate(hlvs):
        ax.add_patch(plt.Rectangle((len(CAT_ORDER) + 0.25, i - 0.5), 0.28, 1.0,
                                   color=LEVEL_COLORS[lv], clip_on=False))
    ax.set_xlim(-0.5, len(CAT_ORDER) + 0.8)
    cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.03)
    cb.set_label('median gain (dec)', fontsize=7)
    cb.ax.tick_params(labelsize=6)
    ax.set_title('intervention gain: 30 hosts x function category', loc='left', fontsize=8)
    fig.legend(handles=_level_legend(), loc='upper left', ncol=1, frameon=False,
               bbox_to_anchor=(0.005, 0.80), handlelength=1.0, fontsize=6)
    _save(fig, 'atlas2_level_gradient.png')


if __name__ == '__main__':
    _style()
    hosts = _read('mech30_host_summary.csv')
    cells = _read('mech30_cells.csv')
    abl = _read('exp4_ablation_cells.csv')
    fried = _read('exp4_friedman.csv')
    ablation(abl, fried)
    capacity_gain(hosts, cells)
    gain_dist(cells, hosts)
    descriptor_signal(hosts)
    gate(hosts)
    level_gradient(hosts, cells)
    print('[atlas2] done ->', FIG)

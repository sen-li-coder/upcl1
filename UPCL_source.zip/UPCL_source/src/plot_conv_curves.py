# -*- coding: utf-8 -*-
"""Classic convergence curves: log10(error) vs FES, bare (solid) vs upcl (dashed).
   conv_curves.png : 4 representative functions x 4 representative algorithms
   conv_matrix.png : 8 algorithms x 4 functions small-multiples
"""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'results' / 'cec' / 'raw' / 'cec2017' / 'D30'
FIG = ROOT / 'results' / 'cec' / 'figures'

LEVEL_COL = {'0': '#d62728', '1': '#ff7f0e', '2': '#2ca02c', '3': '#1f77b4'}
LEVEL_LABEL = {'0': 'L0 fixed', '1': 'L1 adaptive', '2': 'L2 archive', '3': 'L3 LPSR'}

FIDS = [1, 10, 15, 25]
FNAME = {1: ('F1', 'Bent Cigar', 'unimodal'),
         10: ('F10', 'Schwefel', 'multimodal'),
         15: ('F15', 'Hybrid', 'hybrid'),
         25: ('F25', 'Composite', 'composite')}

REPRESENT = [('L-SHADE', '3'), ('SHADE', '2'), ('jDE', '1'), ('DE/rand/1', '0')]
MATRIX_ALGOS = [('NL-SHADE-RSP', '3'), ('L-SHADE', '3'),
                ('SHADE', '2'), ('CoBiDE', '2'),
                ('jDE', '1'), ('jDE100', '1'),
                ('DE/rand/1', '0'), ('DE/best/1', '0')]


def _fpath(host, fid):
    return RAW / f'{host.replace("/", "-")}__F{fid}.json'


def _load(host, fid):
    d = json.load(open(_fpath(host, fid), encoding='utf-8'))
    grid = np.asarray(d['runs'][0]['bare']['grid'], dtype=float)
    arm = 'upcl' if 'upcl' in d['runs'][0] else 'full'
    bare = np.array([r['bare']['err_curve'] for r in d['runs']], dtype=float)
    upcl = np.array([r[arm]['err_curve'] for r in d['runs']], dtype=float)
    return grid, bare, upcl


def _log(err):
    return np.log10(np.maximum(err, 1e-12))


def _mid(arr):
    return np.percentile(arr, [25, 50, 75], axis=0)


def _draw(ax, grid, bare, upcl, c):
    blo, bmed, bhi = _mid(_log(bare))
    ulo, umed, uhi = _mid(_log(upcl))
    ax.fill_between(grid, blo, bhi, color=c, alpha=0.10, lw=0)
    ax.plot(grid, bmed, color=c, lw=1.5, ls='-')
    ax.plot(grid, umed, color=c, lw=1.5, ls='--')
    ax.fill_between(grid, ulo, uhi, color=c, alpha=0.05, lw=0)


def _fmt(ax):
    ax.set_xlim(0, 300000)
    ax.set_xticks([0, 100000, 200000, 300000])
    ax.set_xticklabels(['0', '100k', '200k', '300k'])
    ax.tick_params(labelsize=7)
    ax.grid(color='#e8e8e8', lw=0.4, alpha=0.7)
    ax.set_axisbelow(True)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 9, 'axes.labelsize': 8.5, 'legend.fontsize': 7.5,
        'legend.frameon': False, 'figure.dpi': 300})


def _legend_handles():
    hs = []
    for name, lvl in REPRESENT:
        c = LEVEL_COL[lvl]
        hs.append(plt.Line2D([], [], color=c, lw=1.6, ls='-',
                             label=f'{name}  bare  ({LEVEL_LABEL[lvl]})'))
        hs.append(plt.Line2D([], [], color=c, lw=1.6, ls='--',
                             label=f'{name}  +UPCL'))
    return hs


def conv_compare():
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 7.0))
    fig.subplots_adjust(left=0.08, right=0.98, top=0.93, bottom=0.20,
                        hspace=0.30, wspace=0.16)
    for ax, fid in zip(axes.flat, FIDS):
        for host, lvl in REPRESENT:
            grid, bare, upcl = _load(host, fid)
            _draw(ax, grid, bare, upcl, LEVEL_COL[lvl])
        code, name, cat = FNAME[fid]
        ax.set_title(f'{code}  {name}   ({cat})', loc='left', fontsize=9)
        _fmt(ax)
    axes[1, 0].set_xlabel('function evaluations (FES)')
    axes[1, 1].set_xlabel('function evaluations (FES)')
    axes[0, 0].set_ylabel('log10 error')
    axes[1, 0].set_ylabel('log10 error')
    fig.legend(handles=_legend_handles(), loc='lower center', ncol=4,
               bbox_to_anchor=(0.5, 0.02), handlelength=2.2, columnspacing=1.2)
    fig.savefig(FIG / 'conv_curves.png', bbox_inches='tight')
    plt.close(fig)
    print('[conv] conv_curves.png')


def conv_matrix():
    na = len(MATRIX_ALGOS)
    nf = len(FIDS)
    fig, axes = plt.subplots(na, nf, figsize=(9.4, 2.1 * na + 1.0),
                             sharex=True)
    fig.subplots_adjust(left=0.13, right=0.97, top=0.96, bottom=0.06,
                        hspace=0.22, wspace=0.12)
    for i, (host, lvl) in enumerate(MATRIX_ALGOS):
        c = LEVEL_COL[lvl]
        for j, fid in enumerate(FIDS):
            ax = axes[i, j]
            grid, bare, upcl = _load(host, fid)
            _draw(ax, grid, bare, upcl, c)
            if i == 0:
                code, name, cat = FNAME[fid]
                ax.set_title(f'{code}  {name}\n({cat})', fontsize=7.5)
            if j == 0:
                ax.set_ylabel(f'{host}\n{LEVEL_LABEL[lvl]}', fontsize=6.5,
                              rotation=0, ha='right', va='center',
                              labelpad=58)
            _fmt(ax)
            ax.tick_params(labelsize=5.5)
            ax.set_xticklabels([])
            if i == na - 1:
                ax.set_xticklabels(['0', '100k', '200k', '300k'])
    for j in range(nf):
        axes[na - 1, j].set_xlabel('FES')
    fig.savefig(FIG / 'conv_matrix.png', bbox_inches='tight')
    plt.close(fig)
    print('[conv] conv_matrix.png')


if __name__ == '__main__':
    _style()
    conv_compare()
    conv_matrix()
    print('[conv] done ->', FIG)

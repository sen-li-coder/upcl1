# -*- coding: utf-8 -*-
"""军事沙盘出图：把 intercept（三维山地突防 vs 拦截）渲染成俯视沙盘 + 路线叠加。

用法：
    python src/render_sandtable.py --fid 1 --out results/apps/figures/sandtable_naive_f1.png
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import transforms
from matplotlib.colors import LinearSegmentedColormap, LightSource
from matplotlib.legend_handler import HandlerBase
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Ellipse, Patch, Polygon, Rectangle, Wedge

from uav_adversarial import get_uav_problem
from opponents import make_opponent

ROOT = Path(__file__).resolve().parents[1]
FIG_DIR = ROOT / 'results' / 'apps' / 'figures'

ALGO_COLORS = ['#d62728', '#1f77b4', '#2ca02c', '#9467bd', '#ff7f0e',
               '#17becf', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']

# 两臂对照的固定配色：bare 蓝、携带 UPCL 红（图集内跨子图一致）
ARM_COLORS = ['#1f77b4', '#d62728']

TERRAIN_CMAP = LinearSegmentedColormap.from_list('sandtable', [
    (0.00, '#2f5d3a'), (0.35, '#7ba05b'), (0.55, '#c2a878'),
    (0.75, '#9c7a4a'), (1.00, '#e8e2d5'),
])

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 9, 'axes.linewidth': 0.6, 'axes.edgecolor': '#333333',
})


def load_problem(fid=1, seed=0, difficulty='L1'):
    # seed 必须与 webapp 后端一致（恒为 0，见 app/webapp/web/uav_api.py 的
    # map_geometry / run_uav 均不传 seed），否则 _intercept_terrain(seed) 的
    # 山峰位置/幅度会不同，二维沙盘与 webapp 三维截图就对不上同一环境。
    opp = make_opponent(difficulty, drl_algo='es', seed=seed)
    return get_uav_problem('intercept', fid=fid, seed=seed, opponent=opp)


def naive_straight(problem) -> np.ndarray:
    """直线贴地解：无人机/步兵走起点->目标直线，高度贴地，作最短路基线。"""
    cfg, env = problem.cfg, problem.env
    n_drone_dims = cfg.n_drones * cfg.n_waypoints * 3
    x = np.zeros(problem.dim)
    drone = np.zeros((cfg.n_drones, cfg.n_waypoints, 3))
    for i in range(cfg.n_drones):
        sx, sy = env.starts[i]
        tx, ty = env.targets[i]
        for k in range(cfg.n_waypoints):
            t = (k + 1) / (cfg.n_waypoints + 1)
            drone[i, k, 0] = 2.0 * (sx + (tx - sx) * t) / cfg.map_w - 1.0
            drone[i, k, 1] = 2.0 * (sy + (ty - sy) * t) / cfg.map_h - 1.0
            drone[i, k, 2] = -1.0
    x[:n_drone_dims] = drone.ravel()
    inf = np.zeros((cfg.n_infantry, cfg.n_waypoints, 2))
    for i in range(cfg.n_infantry):
        sx, sy = env.infantry0[i]
        tx, ty = cfg.base_pos
        for k in range(cfg.n_waypoints):
            t = (k + 1) / (cfg.n_waypoints + 1)
            inf[i, k, 0] = 2.0 * (sx + (tx - sx) * t) / cfg.map_w - 1.0
            inf[i, k, 1] = 2.0 * (sy + (ty - sy) * t) / cfg.map_h - 1.0
    x[n_drone_dims:] = inf.ravel()
    return x


def _dedup(pts):
    out = []
    for p in pts:
        if not out or p != out[-1]:
            out.append(p)
    if not out:
        return np.array([]), np.array([])
    a = np.asarray(out, dtype=float)
    return a[:, 0], a[:, 1]


def extract_drone_tracks(frames, n):
    """(tracks, final_states)：每架无人机轨迹与终态。state 0飞行 1/4到达 2击落 3坠毁。"""
    tracks, states = [], []
    for i in range(n):
        pts, st = [], 0
        for fr in frames:
            drones = fr.get('drones') or []
            if i < len(drones):
                d = drones[i]
                pts.append((d[0], d[1]))
                st = d[3]
        tracks.append(_dedup(pts))
        states.append(st)
    return tracks, states


def extract_infantry_tracks(frames, n):
    tracks = []
    for i in range(n):
        pts = []
        for fr in frames:
            inf = fr.get('infantry') or []
            if i < len(inf):
                p = inf[i]
                pts.append((p[0], p[1]))
        tracks.append(_dedup(pts))
    return tracks


def _render_terrain(ax, env, vert_exag=1.5):
    xs, ys, Z = env.terrain.grid()
    dx, dy = float(xs[1] - xs[0]), float(ys[1] - ys[0])
    ls = LightSource(azdeg=315, altdeg=45)
    rgba = ls.shade(Z, cmap=TERRAIN_CMAP, blend_mode='soft', vert_exag=vert_exag,
                    dx=dx, dy=dy, vmin=env.terrain.z_min, vmax=env.terrain.z_max)
    im = ax.imshow(rgba, extent=[xs[0], xs[-1], ys[0], ys[-1]], origin='lower',
                   aspect='equal', interpolation='bilinear', zorder=1)
    ax.contour(xs, ys, Z, levels=12, colors='#5b4632', linewidths=0.4,
               alpha=0.35, zorder=2)
    return im


# ---------------------------------------------------------------------------
# 军事态势图标（MIL-STD-2525 风格几何符号，纯 patches/line 绘制，不依赖字体）
# 约定：所有 _icon_* 返回「以 (0,0) 为中心、尺寸随 s 缩放」的 artist 列表，
# 由 _draw_icon 平移到目标位置，这样既能画到地图上，也能复用为图例图标。
# ---------------------------------------------------------------------------
def _icon_radar(c='#1f77b4', s=1.0):
    """预警雷达：探测圆 + 中心天线点 + 扫描波束扇区。"""
    return [
        Circle((0, 0), 0.55 * s, facecolor='none', edgecolor=c, linewidth=1.1, zorder=6),
        Wedge((0, 0), 0.55 * s, 30, 100, facecolor=c, alpha=0.22, edgecolor='none', zorder=5),
        Circle((0, 0), 0.13 * s, facecolor=c, edgecolor='white', linewidth=0.5, zorder=7),
    ]


def _icon_drone(c='#2ca02c', s=1.0):
    """无人机（固定翼俯视）：机身纵轴 + 横机翼 + 机头三角，交点白点为无人标识。"""
    return [
        Line2D([-0.45 * s, 0.42 * s], [0, 0], color=c, linewidth=1.3,
               solid_capstyle='round', zorder=8),
        Line2D([-0.04 * s, 0.04 * s], [-0.42 * s, 0.42 * s], color=c,
               linewidth=1.3, solid_capstyle='round', zorder=8),
        Polygon([(0.42 * s, 0), (0.62 * s, -0.12 * s), (0.62 * s, 0.12 * s)],
                closed=True, facecolor=c, edgecolor='none', zorder=8),
        Circle((0, 0), 0.11 * s, facecolor='white', edgecolor=c, linewidth=0.7, zorder=9),
    ]


def _icon_base(c='#d62728', s=1.0):
    """军事基地：旗杆 + 三角旗 + 底座横杠。"""
    return [
        Line2D([-0.28 * s, -0.28 * s], [-0.5 * s, 0.5 * s], color=c,
               linewidth=1.4, solid_capstyle='round', zorder=7),
        Polygon([(-0.28 * s, 0.5 * s), (0.42 * s, 0.24 * s), (-0.28 * s, -0.04 * s)],
                closed=True, facecolor=c, edgecolor='none', zorder=7),
        Line2D([-0.42 * s, -0.14 * s], [-0.5 * s, -0.5 * s], color=c,
               linewidth=1.4, solid_capstyle='round', zorder=7),
    ]


def _icon_aa(c='#ff7f0e', s=1.0):
    """地面防空车：车体方块 + 斜向上炮管。"""
    return [
        Rectangle((-0.36 * s, -0.24 * s), 0.72 * s, 0.48 * s, facecolor=c,
                  edgecolor='#7f3f00', linewidth=0.7, zorder=7),
        Line2D([0.08 * s, 0.42 * s], [0.24 * s, 0.52 * s], color='#7f3f00',
               linewidth=1.8, solid_capstyle='round', zorder=7),
    ]


def _icon_helipad(c='#7f3f00', s=1.0):
    """拦截直升机停机坪：旋翼圆 + 机身椭圆 + 尾桨。"""
    return [
        Circle((0, 0), 0.42 * s, facecolor='none', edgecolor=c, linewidth=0.9, zorder=6),
        Ellipse((0, -0.16 * s), 0.52 * s, 0.28 * s, facecolor=c,
                edgecolor='#5b2a00', linewidth=0.6, zorder=7),
        Line2D([0.2 * s, 0.42 * s], [-0.08 * s, -0.08 * s], color=c,
               linewidth=1.1, solid_capstyle='round', zorder=7),
    ]


def _icon_nofly(c='#d62728', s=1.0):
    """禁飞区中心禁止符号：圆 + 斜杠。"""
    return [
        Circle((0, 0), 0.4 * s, facecolor='none', edgecolor=c, linewidth=1.1, zorder=6),
        Line2D([-0.28 * s, 0.28 * s], [0.28 * s, -0.28 * s], color=c,
               linewidth=1.3, solid_capstyle='round', zorder=6),
    ]


def _draw_icon(ax, icon_fn, x, y, s, c):
    """把 icon_fn(c, s) 生成的（以 (0,0) 为中心）图标平移到 (x,y) 画到 ax。"""
    arts = icon_fn(c, s)
    tr = transforms.Affine2D().translate(x, y) + ax.transData
    for a in arts:
        a.set_transform(tr)
        ax.add_artist(a)
    return arts


class _IconHandle:
    """图例句柄：携带图标绘制函数与颜色，供 _IconHandler 渲染成真实图形。"""
    def __init__(self, icon_fn, color):
        self.icon_fn = icon_fn
        self.color = color


class _IconHandler(HandlerBase):
    """把 _IconHandle 渲染为图例里的真实军事图标（而非色块）。"""
    def create_artists(self, legend, orig_handle, xdescent, ydescent,
                       width, height, fontsize, trans):
        cx = xdescent + width / 2.0
        cy = ydescent + height / 2.0
        s = 0.5 * min(width, height)
        arts = orig_handle.icon_fn(orig_handle.color, s)
        tr = transforms.Affine2D().translate(cx, cy) + trans
        for a in arts:
            a.set_transform(tr)
        return arts


def _render_features(ax, env, cfg, show_aa_range=False):
    handles, labels = [], []

    for (bx, by, bw, bd) in env.buildings:
        ax.add_patch(Rectangle((bx - bw / 2, by - bd / 2), bw, bd,
                               facecolor='#6b6b6b', edgecolor='#3d3d3d',
                               linewidth=0.5, zorder=3))
    handles.append(Patch(facecolor='#6b6b6b', edgecolor='#3d3d3d'))
    labels.append('Building (cover)')

    if env.nofly.size:
        for (cx, cy, _cz, r) in env.nofly:
            ax.add_patch(Circle((cx, cy), r, facecolor='#d62728', alpha=0.12,
                                edgecolor='#d62728', linewidth=1.0,
                                linestyle='--', zorder=3))
            _draw_icon(ax, _icon_nofly, cx, cy, 0.22 * r, '#d62728')
        handles.append(_IconHandle(_icon_nofly, '#d62728'))
        labels.append('No-fly zone')

    rx, ry = cfg.radar_pos
    ax.add_patch(Circle((rx, ry), cfg.radar_range, fill=False,
                        edgecolor='#1f77b4', linewidth=0.8, linestyle=':', zorder=3))
    _draw_icon(ax, _icon_radar, rx, ry, 20.0, '#1f77b4')
    handles.append(_IconHandle(_icon_radar, '#1f77b4'))
    labels.append('Radar station')

    for (hx, hy) in env.interceptors0:
        _draw_icon(ax, _icon_helipad, hx, hy, 20.0, '#7f3f00')
    handles.append(_IconHandle(_icon_helipad, '#7f3f00'))
    labels.append('Interceptor helipad')

    for (axx, ayy, _z) in env.aa0:
        _draw_icon(ax, _icon_aa, axx, ayy, 20.0, '#ff7f0e')
        if show_aa_range:
            ax.add_patch(Circle((axx, ayy), cfg.aa_range, fill=False,
                                edgecolor='#ff7f0e', linewidth=0.6,
                                linestyle=':', zorder=3))
    handles.append(_IconHandle(_icon_aa, '#ff7f0e'))
    labels.append('AA vehicle')

    bx, by = env.base
    ax.add_patch(Circle((bx, by), cfg.base_radius, fill=False,
                        edgecolor='#d62728', linewidth=1.2, zorder=4))
    _draw_icon(ax, _icon_base, bx, by, 24.0, '#d62728')
    handles.append(_IconHandle(_icon_base, '#d62728'))
    labels.append('Military base')

    for (sx, sy) in env.starts:
        _draw_icon(ax, _icon_drone, sx, sy, 20.0, '#2ca02c')
    handles.append(_IconHandle(_icon_drone, '#2ca02c'))
    labels.append('Drone start')

    return handles, labels


def _draw_solutions(ax, problem, solutions, colors=None, show_infantry=True,
                    show_waypoints=True):
    """把一个 cell 的若干候选解画到 ax，返回图例句柄与标签。"""
    cfg = problem.cfg
    colors = ALGO_COLORS if colors is None else colors
    algo_handles, algo_labels = [], []
    for idx, (label, x) in enumerate(solutions):
        color = colors[idx % len(colors)]
        cost, _state, frames = problem.trajectory(np.asarray(x, float))
        tracks, states = extract_drone_tracks(frames, cfg.n_drones)

        for i, (xs_, ys_) in enumerate(tracks):
            if len(xs_) < 2:
                continue
            ax.plot(xs_, ys_, color=color, linewidth=1.6, alpha=0.9,
                    zorder=7, solid_capstyle='round')
            # 终点标记（按终态）
            ex, ey = xs_[-1], ys_[-1]
            st = states[i]
            if st in (1, 4):
                ax.plot([ex], [ey], marker='o', color=color, markersize=7,
                        markerfacecolor=color, markeredgecolor='white',
                        markeredgewidth=0.6, zorder=8)
            elif st == 2:
                ax.plot([ex], [ey], marker='x', color=color, markersize=8,
                        markeredgewidth=1.8, zorder=8)
            elif st == 3:
                ax.plot([ex], [ey], marker='x', color='#ff7f0e', markersize=8,
                        markeredgewidth=1.8, zorder=8)
            # 起点小三角
            ax.plot([xs_[0]], [ys_[0]], marker='.', color=color, markersize=9,
                    zorder=8)

        # 航点
        if show_waypoints:
            wp = problem.decode(np.asarray(x, float))
            for i in range(cfg.n_drones):
                ax.plot(wp[i, :, 0], wp[i, :, 1], marker='o', color=color,
                        markersize=4, markerfacecolor='white',
                        markeredgecolor=color, markeredgewidth=1.0,
                        linestyle='none', zorder=8)

        # 步兵轨迹
        if show_infantry:
            itracks = extract_infantry_tracks(frames, cfg.n_infantry)
            for xs_, ys_ in itracks:
                if len(xs_) >= 2:
                    ax.plot(xs_, ys_, color=color, linewidth=1.2, alpha=0.6,
                            linestyle='--', zorder=6)

        algo_handles.append(Line2D([], [], color=color, linewidth=1.8,
                                   label=f'{label} (cost={cost:.1f})'))
        algo_labels.append(f'{label} (cost={cost:.1f})')
    return algo_handles, algo_labels


def render_sandtable(problem, solutions, out_png=None, title=None,
                     show_infantry=True, show_waypoints=True,
                     show_aa_range=False, figsize=(8.5, 8.0), dpi=200,
                     vert_exag=1.5):
    cfg, env = problem.cfg, problem.env
    fig, ax = plt.subplots(figsize=figsize)
    _render_terrain(ax, env, vert_exag=vert_exag)
    f_handles, f_labels = _render_features(ax, env, cfg, show_aa_range=show_aa_range)

    algo_handles, algo_labels = _draw_solutions(
        ax, problem, solutions, show_infantry=show_infantry,
        show_waypoints=show_waypoints)

    ax.set_xlim(0, cfg.map_w)
    ax.set_ylim(0, cfg.map_h)
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.set_aspect('equal', adjustable='box')
    ax.set_title(title or f'intercept F{problem.fid} — sandtable', fontsize=11,
                 fontweight='bold', pad=8)

    # 图例分两列：算法在上、地物在下
    all_handles = algo_handles + f_handles
    all_labels = algo_labels + f_labels
    ncol = 2 if len(all_handles) > 6 else 1
    leg = ax.legend(all_handles, all_labels, loc='upper left', framealpha=0.92,
                    fontsize=8, ncol=ncol, borderaxespad=0.6, handlelength=1.6,
                    handler_map={_IconHandle: _IconHandler()})
    leg.set_zorder(10)

    fig.tight_layout()
    if out_png:
        Path(out_png).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_png, dpi=dpi, bbox_inches='tight')
        print(f'[sandtable] saved {out_png}', flush=True)
    return fig


def render_sandtable_grid(problem, panels, out_png=None, suptitle=None,
                          show_infantry=True, show_waypoints=True,
                          show_aa_range=False, figsize=None, dpi=170,
                          vert_exag=1.5, legend_cols=7):
    """1xN 轨迹图集：同一场景下的 N 个代表 cell 并置在一行。

    ``panels`` 为 ``[(子图标题, solutions), ...]``，``solutions`` 是该 cell 的
    ``[(臂名, x), ...]``（通常 bare / full 两臂）。两臂配色固定为
    ``ARM_COLORS``（bare 蓝、携带 UPCL 红），因此各子图之间可直接比较；
    地物图例只在图底部给出一次，算法图例放在各子图右下角。
    """
    n = len(panels)
    if n == 0:
        raise ValueError('empty panels')
    cfg, env = problem.cfg, problem.env
    if figsize is None:
        figsize = (1.1 + 4.5 * n, 5.9)
    fig, axes = plt.subplots(1, n, figsize=figsize, squeeze=False)
    axes = axes[0]
    feat = None
    for k, (title, sols) in enumerate(panels):
        ax = axes[k]
        _render_terrain(ax, env, vert_exag=vert_exag)
        fh, fl = _render_features(ax, env, cfg, show_aa_range=show_aa_range)
        if feat is None:
            feat = (fh, fl)
        ah, al = _draw_solutions(ax, problem, sols, colors=ARM_COLORS,
                                 show_infantry=show_infantry,
                                 show_waypoints=show_waypoints)
        ax.set_xlim(0, cfg.map_w)
        ax.set_ylim(0, cfg.map_h)
        ax.set_xlabel('X (m)', fontsize=8)
        if k == 0:
            ax.set_ylabel('Y (m)', fontsize=8)
        ax.set_aspect('equal', adjustable='box')
        ax.set_title(title or f'F{problem.fid}  cell {k + 1}', fontsize=9.5,
                     fontweight='bold', pad=5)
        leg = ax.legend(ah, al, loc='lower right', fontsize=7.2, framealpha=0.9,
                        borderaxespad=0.4, handlelength=1.4)
        leg.set_zorder(10)

    if suptitle:
        fig.suptitle(suptitle, fontsize=11.5, fontweight='bold')
    if feat:
        fig.legend(feat[0], feat[1], loc='lower center', ncol=legend_cols,
                   fontsize=7.6, frameon=False, bbox_to_anchor=(0.5, 0.0),
                   handlelength=1.4,
                   handler_map={_IconHandle: _IconHandler()})
    fig.tight_layout(rect=(0.0, 0.06, 1.0, 0.95 if suptitle else 1.0))
    if out_png:
        Path(out_png).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_png, dpi=dpi, bbox_inches='tight')
        print(f'[sandtable] saved {out_png}', flush=True)
    return fig


def _plain_background(ax, cfg, step=200.0):
    """「无地形背景」底图：只留浅色底 + 200 m 参考网格 + 地图边界。"""
    ax.set_facecolor('#fcfdfe')
    v = step
    while v < cfg.map_w:
        ax.axvline(v, color='#e3e8eb', linewidth=0.5, zorder=0)
        v += step
    v = step
    while v < cfg.map_h:
        ax.axhline(v, color='#e3e8eb', linewidth=0.5, zorder=0)
        v += step
    ax.add_patch(Rectangle((0, 0), cfg.map_w, cfg.map_h, fill=False,
                           edgecolor='#b9c4c9', linewidth=0.9, zorder=1))


def render_sandtable_matrix(problem, rows, out_png=None, suptitle=None,
                            col_titles=None, row_titles=None,
                            show_infantry=True, show_waypoints=True,
                            show_aa_range=False, figsize=None, dpi=170,
                            vert_exag=1.5, legend_cols=7):
    """MxN 轨迹图集：同一场景下多档代表解的「有 / 无地形背景」对照。

    ``rows`` 为 ``[[(solutions, with_terrain), ...], ...]``，每个 cell 给出该
    cell 的 ``[(臂名, x), ...]`` 以及是否绘制地形底图；行、列的含义由调用方
    决定（第 5 章的 3x2 轨迹图集为列=名次、行=无/有地形背景）。无地形底图的
    cell 只保留 200 m 参考网格与地物符号，让航线几何本身不被地形纹理干扰，
    有地形底图的 cell 再把同一组航线叠在地形阴影与等高线上。
    两臂配色固定为 ``ARM_COLORS``（bare 蓝、携带 UPCL 红），地物图例只在图
    底部给出一次。
    """
    if not rows:
        raise ValueError('empty rows')
    nrow = len(rows)
    ncol = max(len(r) for r in rows)
    cfg, env = problem.cfg, problem.env
    if figsize is None:
        panel = 4.5
        figsize = (1.15 + panel * ncol, 0.55 + (panel + 0.30) * nrow)
    fig, axes = plt.subplots(nrow, ncol, figsize=figsize, squeeze=False)
    feat = None
    for i, row in enumerate(rows):
        for j in range(ncol):
            ax = axes[i][j]
            if j >= len(row):
                ax.axis('off')
                continue
            sols, with_terrain = row[j]
            if with_terrain:
                _render_terrain(ax, env, vert_exag=vert_exag)
            else:
                _plain_background(ax, cfg)
            fh, fl = _render_features(ax, env, cfg,
                                      show_aa_range=show_aa_range)
            if feat is None:
                feat = (fh, fl)
            ah, al = _draw_solutions(ax, problem, sols, colors=ARM_COLORS,
                                     show_infantry=show_infantry,
                                     show_waypoints=show_waypoints)
            ax.set_xlim(0, cfg.map_w)
            ax.set_ylim(0, cfg.map_h)
            ax.set_aspect('equal', adjustable='box')
            if i == nrow - 1:
                ax.set_xlabel('X (m)', fontsize=8)
            if j == 0 and row_titles and i < len(row_titles):
                ax.text(-0.155, 0.5, row_titles[i], transform=ax.transAxes,
                        rotation=90, ha='center', va='center', fontsize=9.5,
                        fontweight='bold')
            if i == 0 and col_titles and j < len(col_titles):
                ax.set_title(col_titles[j], fontsize=10.5, fontweight='bold',
                             pad=7)
            leg = ax.legend(ah, al, loc='lower right', fontsize=7.0,
                            framealpha=0.9, borderaxespad=0.4, handlelength=1.4)
            leg.set_zorder(10)

    if suptitle:
        fig.suptitle(suptitle, fontsize=11.5, fontweight='bold')
    if feat:
        fig.legend(feat[0], feat[1], loc='lower center', ncol=legend_cols,
                   fontsize=7.6, frameon=False, bbox_to_anchor=(0.5, 0.0),
                   handlelength=1.4,
                   handler_map={_IconHandle: _IconHandler()})
    fig.tight_layout(rect=(0.03, 0.045, 1.0, 0.965 if suptitle else 1.0))
    if out_png:
        Path(out_png).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_png, dpi=dpi, bbox_inches='tight')
        print(f'[sandtable] saved {out_png}', flush=True)
    return fig


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--fid', type=int, default=1)
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--difficulty', default='L1')
    ap.add_argument('--out', default=None)
    ap.add_argument('--mode', choices=['naive'], default='naive',
                    help='样例模式：naive=直线贴地解')
    ap.add_argument('--dpi', type=int, default=200)
    args = ap.parse_args(argv)

    problem = load_problem(fid=args.fid, seed=args.seed, difficulty=args.difficulty)
    if args.mode == 'naive':
        solutions = [('naive-straight', naive_straight(problem))]
    else:
        solutions = [('naive-straight', naive_straight(problem))]

    out = args.out or str(FIG_DIR / f'sandtable_{args.mode}_f{args.fid}.png')
    render_sandtable(problem, solutions, out_png=out)


if __name__ == '__main__':
    main()


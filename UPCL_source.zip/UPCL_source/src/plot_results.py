# -*- coding: utf-8 -*-
"""Generate paired convergence curves for paper figures.

For each (func, host) pair, plot median convergence across all paired runs
of original vs H+LAES. Produces PNGs. Uses matplotlib; falls back gracefully.
"""
import json, os, sys, glob
import numpy as np

def ensure_matplotlib():
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        return plt
    except Exception as e:
        print(f"matplotlib unavailable ({e}). Skipping plots.")
        return None

def load_pair_json(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def aggregate_median_curve(runs_curve):
    """runs_curve: list of (eval_points, conv_curve). Return common-grid median curve."""
    # Use first run's eval grid (deterministic from code: log-spacing × pop_size)
    evals = np.array(runs_curve[0][0])
    curves = np.array([np.array(c) for _, c in runs_curve])
    # Clip all curves to minimum length (safety)
    L = min(len(c) for c in curves)
    evals = evals[:L]
    curves = np.array([c[:L] for c in curves])
    med = np.median(curves, axis=0)
    q1  = np.percentile(curves, 25, axis=0)
    q3  = np.percentile(curves, 75, axis=0)
    return evals, med, q1, q3


def plot_one_pair(plt, ax, json_path, title=None):
    data = load_pair_json(json_path)
    o_runs = data['original']
    l_runs = data['enhanced']
    o_curves = [(r['evals'], r['convergence']) for r in o_runs]
    l_curves = [(r['evals'], r['convergence']) for r in l_runs]
    ox, om, o1, o3 = aggregate_median_curve(o_curves)
    lx, lm, l1, l3 = aggregate_median_curve(l_curves)
    ax.semilogy(ox, om, color='#666666', lw=1.5, label='Original Host (median)', alpha=0.9)
    ax.fill_between(ox, o1, o3, color='#666666', alpha=0.15)
    ax.semilogy(lx, lm, color='#d95f02', lw=1.9, label='H+LAES (median)')
    ax.fill_between(lx, l1, l3, color='#d95f02', alpha=0.22)
    ax.set_title(title or os.path.basename(json_path), fontsize=9)
    ax.set_xlabel('Function evaluations')
    ax.set_ylabel('Best-so-far f(x)')
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)


def generate_all(result_dir, out_dir, dim):
    plt = ensure_matplotlib()
    if plt is None:
        return
    os.makedirs(out_dir, exist_ok=True)
    files = sorted(glob.glob(os.path.join(result_dir, f'pair_*_D{dim}.json')))
    # Aggregate by host
    from collections import OrderedDict
    by_host = OrderedDict()
    for p in files:
        b = os.path.basename(p)
        # pair_DE_rand_1_Ackley_D10.json
        stem = b[len('pair_'):-len(f'_D{dim}.json')]
        # split: last '_' separates host from func
        parts = stem.rsplit('_', 1)
        if len(parts) != 2:
            continue
        host, func = parts
        host = host.replace('_', '/').replace('DE/rand/1', 'DE/rand/1').replace('L/SHADE', 'L-SHADE')
        by_host.setdefault(host, []).append((func, p))

    # 7 functions × 6 hosts -> 42 individual plots + 7 (func overview, 6 hosts on one axes)
    # A4: 6×3 grid per-func overview or 3×2 per-host overview.
    # Generate one plot per function with 2x3 hosts subplot grid.
    funcs_order = ['Sphere', 'Rastrigin', 'Ackley', 'Rosenbrock', 'Schwefel', 'Griewank', 'Levy']
    host_order = ['DE/rand/1', 'JADE', 'SHADE', 'L-SHADE', 'CoBiDE', 'jSO']

    # --- Per-host, multi-func (2-row 4-col)  ---
    host_to_paths = {}
    for host, lst in by_host.items():
        # host uses '/' but JSON name used '_'  ; reconstruct path map
        for func, p in lst:
            host_to_paths.setdefault(host, {})[func] = p

    for func_name in funcs_order:
        fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(13, 7), dpi=110)
        axes = axes.flatten()
        for i, host_name in enumerate(host_order):
            ax = axes[i]
            # recover filename path
            safe_host = host_name.replace('/', '_')
            pattern = os.path.join(result_dir, f'pair_{safe_host}_{func_name}_D{dim}.json')
            match = glob.glob(pattern)
            if not match:
                ax.text(0.5, 0.5, f'no data\n{host_name}', ha='center', va='center',
                        transform=ax.transAxes, fontsize=9)
                ax.set_title(f'{host_name} — missing')
                continue
            plot_one_pair(plt, ax, match[0], title=f'{host_name} on {func_name}, D={dim}')
        # Hide last empty subplot if any
        for j in range(len(host_order), len(axes)):
            axes[j].axis('off')
        fig.suptitle(f'Paired convergence: {func_name} D={dim}. Grey=original host, Orange=H+LAES.',
                     fontsize=11, y=1.005)
        fig.tight_layout()
        out_path = os.path.join(out_dir, f'convergence_{func_name}_D{dim}.png')
        fig.savefig(out_path, bbox_inches='tight')
        plt.close(fig)
        print(f'Saved {out_path}')

    # Summary bar: improvement % per (host, func) as heatmap
    summary_path = os.path.join(result_dir, f'summary_D{dim}.json')
    if os.path.exists(summary_path):
        with open(summary_path, encoding='utf-8') as f:
            summary = json.load(f)
        grid = np.full((len(host_order), len(funcs_order)), np.nan)
        pvals = np.full((len(host_order), len(funcs_order)), 1.0)
        for r in summary:
            try:
                hi = host_order.index(r['host'])
                fi = funcs_order.index(r['func'])
            except ValueError:
                continue
            grid[hi, fi] = r['improvement_pct']
            pvals[hi, fi] = r['wilcoxon_p'] if r['wilcoxon_p'] is not None else 1.0
        fig, ax = plt.subplots(figsize=(9, 4.2), dpi=110)
        vmax = max(np.nanmax(np.abs(grid)), 1.0)
        cmap = 'RdYlGn'
        im = ax.imshow(grid, cmap=cmap, vmin=-vmax, vmax=vmax, aspect='auto')
        ax.set_xticks(range(len(funcs_order)))
        ax.set_xticklabels(funcs_order, rotation=15, ha='right')
        ax.set_yticks(range(len(host_order)))
        ax.set_yticklabels(host_order)
        ax.set_title(f'Improvement % of +LAES over original (D={dim}). Green = LAES better.')
        cbar = fig.colorbar(im, ax=ax, shrink=0.85)
        cbar.set_label('% improvement (positive = H+LAES wins)')
        for i in range(len(host_order)):
            for j in range(len(funcs_order)):
                if np.isnan(grid[i, j]): continue
                pct = grid[i, j]
                marker = ' *' if pvals[i, j] < 0.05 else ''
                ax.text(j, i, f'{pct:+.1f}%{marker}',
                        ha='center', va='center', fontsize=8,
                        color='black' if abs(pct) < 0.7 * vmax else 'white')
        fig.tight_layout()
        out_path = os.path.join(out_dir, f'heatmap_improvement_D{dim}.png')
        fig.savefig(out_path, bbox_inches='tight')
        plt.close(fig)
        print(f'Saved {out_path}')


if __name__ == '__main__':
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    res_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        ROOT, 'results', 'pilot_D10_tuned_v2')
    D = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(res_dir, 'figures')
    generate_all(res_dir, out, D)

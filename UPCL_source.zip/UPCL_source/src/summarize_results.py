# -*- coding: utf-8 -*-
import json, os, sys
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
base = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    ROOT, 'results', 'pilot_D10_tuned_v2')
dim = int(sys.argv[2]) if len(sys.argv) > 2 else 10
with open(os.path.join(base, f'summary_D{dim}.json'), encoding='utf-8') as f:
    s = json.load(f)

per_host = defaultdict(list)
for r in s:
    per_host[r['host']].append(r)

fmt = '{:>10s} {:>14s} {:>14s} {:>10s} {:>8s} {:>10s}'
print(fmt.format('Host', 'OrigMean', '+LAESMean', 'Imp%', '#Imp/7', '#Sig(p<0.05)'))
print('-' * 72)
total_imp = 0
for hn, rows in per_host.items():
    om = sum(r['orig_mean'] for r in rows)/len(rows)
    lm = sum(r['laes_mean'] for r in rows)/len(rows)
    imp = (om-lm)/(abs(om)+1e-30)*100
    n_imp = sum(1 for r in rows if r['improvement_pct']>0)
    n_sig = sum(1 for r in rows if r['wilcoxon_p']<0.05)
    total_imp += n_imp
    print(f'{hn:>10s} {om:>14.4e} {lm:>14.4e} {imp:>+9.2f}% {n_imp:>5d}/7 {n_sig:>8d}/7')
print(f'\nTOTAL improved pairs: {total_imp}/42 = {total_imp/42*100:.1f}%')
print(f'\nPer-function breakdown:')
funcs = sorted({r['func'] for r in s})
for fn in funcs:
    rows = [r for r in s if r['func'] == fn]
    n_host_imp = sum(1 for r in rows if r['improvement_pct']>0)
    print(f'  {fn:12s}: improved on {n_host_imp}/6 hosts')

# -*- coding: utf-8 -*-
"""第 5 章论文图（§5.2–§5.4）。

依赖：``analyze_uav.py`` / ``analyze_uav_rank.py`` / ``analyze_uav_mech.py``
已产出 ``results/apps/tables/`` 下的 CSV。

产出（``results/apps/figures/``）：
    fig_uav_rank_scatter.png   benchmark 名次 vs 真实任务名次散点（跨任务）
    fig_uav_gain_heatmap.png   指标组 × 宿主 的 median gain 热图（跨任务）
    fig_uav_gain_forest.png    6 指标组 pooled mean gain ± 95% CI 森林图
    fig_uav_mech_eta2.png      机制维度 × 指标组 效应量 η² 热图

按任务拆分版（文件名带 ``_F{fid}``，F1–F4 各一张，webapp「任务实验数据」面板
随任务切换展示的就是这一组；跨任务的同名图是 4 个任务合并口径）：
    fig_uav_rank_scatter_F{fid}.png  各任务单独名次榜 vs CEC 名次
    fig_uav_gain_heatmap_F{fid}.png  该任务的指标组 × 宿主 median gain 热图
    fig_uav_gain_forest_F{fid}.png   该任务的 6 指标组 mean gain ± 95% CI 森林图

论文正文插入的合并版：
    fig_uav_rank_scatter_2x2.png     四个任务的名次迁移散点合并为 2x2 图组

注意：按任务拆分的散点、热图与森林图只供 webapp 面板与诊断使用，论文正文
（中英文）只插入 2x2 合并散点；第 5 章的逐任务代表轨迹由
``plot_uav_trajectory.py --grid`` 输出的 3x2 图集 ``fig_uav_traj_F{fid}.png``
呈现（列=名次 1 / 中位 / 末位，行=无地形背景 / 有地形背景）。
"""
import csv
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent))

import de_hosts_cec as DHC                     # noqa: E402 (host 排序)
from analyze_uav_mech import METRIC_GROUPS, GROUP_ORDER  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'results' / 'apps' / 'tables'
FIG = ROOT / 'results' / 'apps' / 'figures'

GROUP_LABEL = {
    'task': 'task completion',
    'safety': 'safety avoidance',
    'path': 'path quality',
    'constraint': 'constraint satisf.',
    'infantry': 'air-ground coop.',
    'patrol': 'enemy patrol',
}
DIM_LABEL = {
    'mutation_class': 'mutation', 'param_class': 'param rule',
    'strategy': 'strategy', 'archive': 'archive',
    'pop': 'population', 'other_flag': 'other mech',
}


def _style():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 9, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 7,
        'ytick.labelsize': 7, 'legend.fontsize': 7,
        'legend.frameon': False, 'figure.dpi': 300})


def _despine(ax):
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[plot_uav] {name}')


def _read(name):
    p = TAB / name
    if not p.exists():
        raise SystemExit(f'missing table: {p}')
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _repel_labels(fig, ax, texts, xs, ys, max_iter=500, step=1.6, gap=0.0,
                  obstacles=None, obs_r=5.5):
    """简单斥力去重叠，返回每个标签最终的数据坐标位置 (n, 2)。

    ``gap`` 为额外的相对间隙：重叠判定用放大 ``1+gap`` 倍的外接框，因而标签
    之间会留出与自身尺寸成比例的空白（0 表示只消除真正的重叠）。
    ``obstacles`` 是显示坐标下的数据点 ``(px, py)`` 列表，半径为 ``obs_r`` 的
    小方框同样参与排斥（标签对应的那个点自动跳过），避免文字压住标记。
    """
    from matplotlib.transforms import Bbox
    n = len(texts)
    obs_boxes, obs_cents = [], []
    if obstacles is not None:
        for (px, py) in obstacles:
            obs_boxes.append(Bbox.from_bounds(px - obs_r, py - obs_r,
                                              2 * obs_r, 2 * obs_r))
            obs_cents.append((px, py))
    pos = np.zeros((n, 2))
    pos[:, 0] = xs + 0.45
    pos[:, 1] = ys + 0.45
    for t, (px, py) in zip(texts, pos):
        t.set_position((px, py))
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    inv = ax.transData.inverted()
    origin = inv.transform((0.0, 0.0))

    def _center(b):
        p0, p1 = b.get_points()
        return ((p0[0] + p1[0]) / 2.0, (p0[1] + p1[1]) / 2.0)

    for _ in range(max_iter):
        boxes = [t.get_window_extent(renderer=renderer) for t in texts]
        cents = [_center(b) for b in boxes]
        test = ([b.expanded(1.0 + gap, 1.0 + gap) for b in boxes] if gap > 0.0
                else boxes)
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                if not test[i].overlaps(test[j]):
                    continue
                dx = cents[i][0] - cents[j][0]
                dy = cents[i][1] - cents[j][1]
                dist = math.hypot(dx, dy) or 1e-3
                ux, uy = dx / dist, dy / dist
                for idx, sgn in ((i, 1.0), (j, -1.0)):
                    d = inv.transform((ux * step * sgn, uy * step * sgn))
                    pos[idx, 0] += d[0] - origin[0]
                    pos[idx, 1] += d[1] - origin[1]
                moved = True
            for k in range(len(obs_boxes)):
                if k == i or not test[i].overlaps(obs_boxes[k]):
                    continue
                dx = cents[i][0] - obs_cents[k][0]
                dy = cents[i][1] - obs_cents[k][1]
                dist = math.hypot(dx, dy) or 1e-3
                d = inv.transform((dx / dist * step, dy / dist * step))
                pos[i, 0] += d[0] - origin[0]
                pos[i, 1] += d[1] - origin[1]
                moved = True
        if not moved:
            break
        for t, (px, py) in zip(texts, pos):
            t.set_position((px, py))
        fig.canvas.draw()

    for t, (px, py) in zip(texts, pos):
        t.set_position((px, py))
    return pos


# ---------------------------------------------------------------------------
# 图 5-3  排名迁移散点
# ---------------------------------------------------------------------------
def fig_rank_scatter(fid=None):
    """benchmark 名次 vs 真实任务名次散点。

    ``fid=None`` 用 ``uav_value_rank.csv``（跨 4 任务综合名次）；``fid=1..4``
    用 ``uav_task_rank.csv``（该任务单独名次，方法相同、总体只限本任务），
    得到「按任务拆分」版：F1–F4 各一张，名次分布互不相同。
    """
    if fid is None:
        rows = _read('uav_value_rank.csv')
        uav_col, ylab, scope = 'uav_rank', 'UAV intercept rank (4 tasks pooled)', 'F1–F4 pooled'
        fname = 'fig_uav_rank_scatter.png'
    else:
        rows = [r for r in _read('uav_task_rank.csv')
                if int(_f(r['fid'], -1)) == int(fid)]
        if not rows:
            print(f'[plot_uav] skip rank scatter F{fid}: no uav_task_rank.csv rows')
            return
        uav_col = 'task_rank'
        ylab = f'UAV intercept F{int(fid)} rank (1 = best)'
        scope = f'F{int(fid)}'
        fname = f'fig_uav_rank_scatter_F{int(fid)}.png'

    hosts = [r['host'] for r in rows]
    cec = np.array([_f(r['cec_rank']) for r in rows])
    uav = np.array([_f(r[uav_col]) for r in rows])
    ok = np.isfinite(cec) & np.isfinite(uav)
    rho, p = stats.spearmanr(uav[ok], cec[ok])

    _style()
    fig, ax = plt.subplots(figsize=(8.4, 7.4))
    ax.scatter(cec, uav, s=24, c='#1f77b4', alpha=0.75, zorder=3,
               edgecolors='white', linewidths=0.4)
    lo, hi = 0.5, max(cec.max(), uav.max()) + 0.5
    ax.plot([lo, hi], [lo, hi], '--', color='#888888', linewidth=1,
            label='perfect transfer')

    # 标注全部宿主算法名，并用斥力去重叠
    texts = []
    for i in range(len(hosts)):
        t = ax.text(cec[i], uav[i], hosts[i], fontsize=5.5, color='#333333',
                    ha='left', va='bottom', zorder=6)
        texts.append(t)
    offsets = _repel_labels(fig, ax, texts, cec, uav)
    for i in range(len(hosts)):
        if math.hypot(offsets[i, 0] - cec[i], offsets[i, 1] - uav[i]) > 1.6:
            ax.plot([cec[i], offsets[i, 0]], [uav[i], offsets[i, 1]],
                    color='#aaaaaa', lw=0.4, alpha=0.55, zorder=2)

    ax.set_xlabel('CEC2017 D=30 bare rank (1 = best)')
    ax.set_ylabel(ylab)
    ax.set_title(f'RQ5.1 benchmark → real-task rank transfer  [{scope}]\n'
                 f'Spearman $\\rho$ = {rho:+.3f}  (p = {p:.3f}, n = {ok.sum()})',
                 fontsize=9)
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.legend(loc='upper left')
    _despine(ax)
    _save(fig, fname)


# ---------------------------------------------------------------------------
# 图 5-3b  四个任务的名次迁移散点合并图组（论文正文插入的就是这一张）
# ---------------------------------------------------------------------------
def _scatter_data(fid):
    """单个任务的名次散点数据：``(hosts, cec, task, rho, p, n)``。"""
    rows = [r for r in _read('uav_task_rank.csv')
            if int(_f(r['fid'], -1)) == int(fid)]
    if not rows:
        return None
    hosts = [r['host'] for r in rows]
    cec = np.array([_f(r['cec_rank']) for r in rows])
    task = np.array([_f(r['task_rank']) for r in rows])
    ok = np.isfinite(cec) & np.isfinite(task)
    rho, p = stats.spearmanr(task[ok], cec[ok])
    return hosts, cec, task, float(rho), float(p), int(ok.sum())


def fig_rank_scatter_grid(fname='fig_uav_rank_scatter_2x2.png'):
    """四个任务的名次散点合并为一张 2x2 图组。

    数据与 ``fig_rank_scatter`` 的按任务版完全相同，只是把四幅面板放进同一
    张图，并把字号、点尺寸调大一档。为避免文字互相遮挡：坐标轴上方与右侧各
    留一圈标签环带，标签用斥力去重叠后凡移动过的都用细引线连回数据点，标签
    本身再加白色描边（halo），因此即便在密集处也不会与点或其它文字糊在一起。
    """
    data = {}
    for fid in (1, 2, 3, 4):
        d = _scatter_data(fid)
        if d is not None:
            data[fid] = d
    if not data:
        print('[plot_uav] skip rank scatter grid: no uav_task_rank.csv rows')
        return

    pad = {'font.size': 10.5, 'axes.titlesize': 11.5, 'axes.labelsize': 10.5,
           'xtick.labelsize': 9.5, 'ytick.labelsize': 9.5, 'legend.fontsize': 10}
    with plt.rc_context():
        _style()
        plt.rcParams.update(pad)
        fig, axes = plt.subplots(2, 2, figsize=(11.6, 11.4),
                                 sharex=True, sharey=True)
        axes = np.atleast_2d(axes)
        for k, fid in enumerate(sorted(data)):
            ax = axes.ravel()[k]
            hosts, cec, task, rho, p, n = data[fid]
            lo = 0.0
            hi = float(max(cec.max(), task.max())) + 3.0   # 右上留标签环带
            # 先定死坐标范围与等比例，斥力与引线都在最终变换下计算
            ax.set_xlim(lo, hi)
            ax.set_ylim(lo, hi)
            ax.set_aspect('equal')
            ax.scatter(cec, task, s=44, c='#1f77b4', alpha=0.8, zorder=3,
                       edgecolors='white', linewidths=0.5)
            ax.plot([lo, hi - 2.5], [lo, hi - 2.5], '--', color='#8c8c8c',
                    linewidth=1.1, zorder=2,
                    label='perfect transfer' if k == 0 else None)
            texts = [ax.text(cec[i], task[i], hosts[i], fontsize=7.0,
                             color='#1a1a1a', ha='left', va='bottom', zorder=6,
                             path_effects=[pe.withStroke(linewidth=2.4,
                                                         foreground='white')])
                     for i in range(len(hosts))]
            off = _repel_labels(fig, ax, texts, cec, task, max_iter=900,
                                step=2.2, gap=0.22,
                                obstacles=ax.transData.transform(
                                    np.column_stack([cec, task])))
            # 引线在显示坐标里画：从数据点指向标签锚点，端点回退 7 px 不压字
            inv = ax.transData.inverted()
            for i in range(len(hosts)):
                p0 = ax.transData.transform((cec[i], task[i]))
                p1 = ax.transData.transform((off[i, 0], off[i, 1]))
                dvec = p1 - p0
                dist = float(np.hypot(dvec[0], dvec[1]))
                if dist <= 18.0:      # 只挪了几像素的不画引线，免得留下小短线
                    continue
                p2 = p0 + dvec * (1.0 - 7.0 / dist)
                (x0, y0), (x1, y1) = inv.transform([p0, p2])
                ax.plot([x0, x1], [y0, y1], color='#b8b8b8', lw=0.5,
                        alpha=0.75, zorder=2, solid_capstyle='round')
            ax.set_title(f'({chr(97 + k)})  Task F{fid}    '
                         f'$\\rho={rho:+.2f}$  ($p={p:.2f}$, $n={n}$)')
            if k == 0:
                ax.legend(loc='upper left', frameon=False)
        for ax in axes[-1]:
            ax.set_xlabel('CEC 2017 $D=30$ rank  (1 = best)')
        for ax in axes[:, 0]:
            ax.set_ylabel('interception-scenario rank  (1 = best)')
        for ax in axes.ravel():
            _despine(ax)
        _save(fig, fname)


# ---------------------------------------------------------------------------
# 图 5-4  指标组 × 宿主 median gain 热图
# ---------------------------------------------------------------------------
def fig_gain_heatmap(fid=None):
    """指标组 × 宿主 median gain 热图。

    ``fid=None`` 用 4 个任务全部 cell（跨任务口径）；``fid=1..4`` 只保留该任务
    的 cell，得到按任务拆分版。
    """
    # 从 upcl_delta 聚合：per-(host, metric) median gain -> per-(host, group) mean
    rows = _read('uav_upcl_delta.csv')
    if fid is not None:
        rows = [r for r in rows if int(_f(r['fid'], -1)) == int(fid)]
        if not rows:
            print(f'[plot_uav] skip gain heatmap F{fid}: no upcl_delta rows')
            return
    scope = 'F1–F4 pooled' if fid is None else f'F{int(fid)}'
    fname = ('fig_uav_gain_heatmap.png' if fid is None
             else f'fig_uav_gain_heatmap_F{int(fid)}.png')
    host_idx = DHC.CEC_HOST_ORDER
    hosts = [h for h in host_idx if any(r['host'] == h for r in rows)]
    mat = np.full((len(GROUP_ORDER), len(hosts)), np.nan)
    for g_i, g in enumerate(GROUP_ORDER):
        members = METRIC_GROUPS[g]
        for h_i, h in enumerate(hosts):
            vals = [_f(r['gain']) for r in rows if r['host'] == h
                    and r['metric'] in members and np.isfinite(_f(r['gain']))]
            if vals:
                mat[g_i, h_i] = float(np.median(vals))

    _style()
    fig, ax = plt.subplots(figsize=(12.0, 4.6))
    vmax = np.nanmax(np.abs(mat))
    if not np.isfinite(vmax) or vmax == 0.0:
        vmax = 1.0
    im = ax.imshow(mat, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto',
                   interpolation='nearest')

    ax.set_xticks(range(len(hosts)))
    ax.set_xticklabels(hosts, rotation=50, ha='right', fontsize=6.5)
    ax.set_yticks(range(len(GROUP_ORDER)))
    ax.set_yticklabels([GROUP_LABEL[g] for g in GROUP_ORDER], fontsize=8)

    # 单元格数值 + 分组网格线
    ax.set_xticks(np.arange(-0.5, len(hosts), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(GROUP_ORDER), 1), minor=True)
    ax.grid(which='minor', color='white', linewidth=0.8)
    ax.tick_params(which='minor', length=0)
    for i in range(len(GROUP_ORDER)):
        for j in range(len(hosts)):
            v = mat[i, j]
            if np.isfinite(v):
                ax.text(j, i, f'{v:+.2f}', ha='center', va='center',
                        fontsize=5.5,
                        color='white' if abs(v) > 0.55 * vmax else '#1a1a1a')

    ax.set_title('median bare→full gain by metric group × host  '
                 f'[{scope}]  (red = full arm better)', fontsize=9)
    cbar = fig.colorbar(im, ax=ax, fraction=0.018, pad=0.02,
                        label='median gain')
    cbar.ax.tick_params(labelsize=7)
    fig.tight_layout()
    _save(fig, fname)


# ---------------------------------------------------------------------------
# 图 5-5  6 指标组 pooled mean gain ± 95% CI 森林图
# ---------------------------------------------------------------------------
def fig_gain_forest(fid=None):
    """6 指标组 pooled mean gain ± 95% CI 森林图。

    ``fid=None`` 用 ``uav_mech_host_gain.csv``（每宿主按跨 4 任务 median 聚合，
    与论文正文一致）；``fid=1..4`` 改成只统计该任务下的 gain（每宿主组内各指标
    gain 取均值），得到按任务拆分版。
    """
    if fid is None:
        rows = _read('uav_mech_host_gain.csv')
        scope, fname = 'F1–F4 pooled', 'fig_uav_gain_forest.png'
    else:
        delta = [r for r in _read('uav_upcl_delta.csv')
                 if int(_f(r['fid'], -1)) == int(fid)]
        if not delta:
            print(f'[plot_uav] skip gain forest F{fid}: no upcl_delta rows')
            return
        acc = defaultdict(list)
        for r in delta:
            for g, members in METRIC_GROUPS.items():
                if r['metric'] in members:
                    acc[(r['host'], g)].append(_f(r['gain']))
        per_host = defaultdict(dict)
        for (h, g), vals in acc.items():
            vv = [v for v in vals if np.isfinite(v)]
            if vv:
                per_host[h][g] = float(np.mean(vv))
        rows = [d for d in per_host.values() if len(d) == len(GROUP_ORDER)]
        if not rows:
            print(f'[plot_uav] skip gain forest F{fid}: no complete host rows')
            return
        scope, fname = f'F{int(fid)}', f'fig_uav_gain_forest_F{int(fid)}.png'

    _style()
    fig, ax = plt.subplots(figsize=(5.6, 3.8))
    means, los, his = [], [], []
    for g in GROUP_ORDER:
        vals = np.array([_f(r[g]) for r in rows])
        vals = vals[np.isfinite(vals)]
        m = vals.mean()
        sem = vals.std(ddof=1) / np.sqrt(len(vals))
        ci = sem * stats.t.ppf(0.975, len(vals) - 1)
        means.append(m); los.append(m - ci); his.append(m + ci)
    y = np.arange(len(GROUP_ORDER))[::-1]
    ax.errorbar(means, y, xerr=[np.array(means) - np.array(los),
                                np.array(his) - np.array(means)],
                fmt='o', color='#1f77b4', capsize=4, linewidth=1.2)
    ax.axvline(0, color='#888888', linewidth=0.8, linestyle='--')
    for yi, m in zip(y, means):
        ax.text(0, yi, ' 0', va='center', fontsize=6, color='#888888')
    ax.set_yticks(y)
    ax.set_yticklabels([GROUP_LABEL[g] for g in GROUP_ORDER], fontsize=7)
    ax.set_xlabel('pooled mean gain  (positive = full arm better)')
    ax.set_title(f'UPCL intervention effect by metric group  [{scope}]\n'
                 f'(mean ± 95% CI across {len(rows)} hosts)', fontsize=9)
    ax.axvline(0, color='#cccccc', linewidth=0.5)
    _despine(ax)
    _save(fig, fname)


# ---------------------------------------------------------------------------
# 图 5-6  机制维度 × 指标组 η² 热图
# ---------------------------------------------------------------------------
def fig_mech_eta2():
    rows = _read('uav_mech_eta2.csv')
    dims = list(DIM_LABEL)
    mat = np.full((len(dims), len(GROUP_ORDER)), np.nan)
    for r in rows:
        if r['dimension'] in dims and r['metric_group'] in GROUP_ORDER:
            mat[dims.index(r['dimension']),
                GROUP_ORDER.index(r['metric_group'])] = _f(r['eta2'])

    _style()
    fig, ax = plt.subplots(figsize=(5.8, 4.0))
    im = ax.imshow(mat, cmap='viridis', vmin=0, vmax=1, aspect='auto')
    ax.set_xticks(range(len(GROUP_ORDER)))
    ax.set_xticklabels([GROUP_LABEL[g] for g in GROUP_ORDER], fontsize=7)
    ax.set_yticks(range(len(dims)))
    ax.set_yticklabels([DIM_LABEL[d] for d in dims], fontsize=7)
    ax.set_title('mechanism dimension × metric group  '
                 '$\\eta^2$ (Kruskal-Wallis)', fontsize=9)
    for i in range(len(dims)):
        for j in range(len(GROUP_ORDER)):
            v = mat[i, j]
            if np.isfinite(v):
                ax.text(j, i, f'{v:.2f}', ha='center', va='center', fontsize=7,
                        color='white' if v < 0.6 else '#222222')
                if v >= 0.1:
                    from matplotlib.patches import Rectangle
                    ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False,
                                           edgecolor='red', linewidth=1.5))
    fig.colorbar(im, ax=ax, shrink=0.9, pad=0.01, label='$\\eta^2$')
    fig.tight_layout()
    _save(fig, 'fig_uav_mech_eta2.png')


def main():
    figs = [('rank_scatter', fig_rank_scatter),
            ('gain_heatmap', fig_gain_heatmap),
            ('gain_forest', fig_gain_forest)]
    # 跨任务合并口径（论文正文引用） + 按任务拆分口径（webapp 面板随任务切换）
    for name, fn in figs:
        fn()
    for fid in (1, 2, 3, 4):
        for name, fn in figs:
            fn(fid)
    # 论文正文插入的 2x2 合并散点（替换原来的 4 张单任务散点）
    fig_rank_scatter_grid()
    fig_mech_eta2()
    print(f'[plot_uav] all figures -> {FIG}')


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Figures for the UPCL manuscript.

Generates two figures from the paired run files written by
`upcl_experiment.py`:

    upcl_fig1_converge.png   convergence of bare vs. wrapped hosts
    upcl_fig2_rho.png        intervention rate and improvement per host
"""
import json
import sys
from pathlib import Path
from collections import defaultdict

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIGDIR = ROOT / 'paper_figures_highres'
FIGDIR.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 8.5,
    'axes.labelsize': 9,
    'axes.titlesize': 9,
    'legend.fontsize': 7.5,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
})


# ===========================================================================
def load_pairs(results_dir):
    pairs = {}
    for f in sorted(Path(results_dir).glob('pair_*.json')):
        d = json.loads(Path(f).read_text(encoding='utf-8'))
        pairs[(d['host'], d['func'])] = d
    return pairs


def _stack(runs, key):
    """Align convergence traces across runs and return (evals, mean, median)."""
    seqs = [np.asarray(r[key], dtype=float) for r in runs]
    evs = [np.asarray(r['evals'], dtype=float) for r in runs]
    n = min(len(s) for s in seqs)
    M = np.vstack([s[:n] for s in seqs])
    E = evs[0][:n]
    return E, np.median(M, axis=0), M


# ===========================================================================
def fig_convergence(pairs, out):
    combos = [('DE/rand/1', 'Sphere'), ('SHADE', 'Rastrigin'),
              ('DE/rand/1', 'Rosenbrock'), ('jSO', 'Ackley')]
    combos = [c for c in combos if c in pairs]
    if not combos:
        combos = list(pairs)[:4]
    ncol = min(2, len(combos))
    nrow = int(np.ceil(len(combos) / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(3.3 * ncol, 2.5 * nrow))
    axes = np.atleast_1d(axes).ravel()

    for ax, (h, fn) in zip(axes, combos):
        d = pairs[(h, fn)]
        Eo, mo, _ = _stack(d['original'], 'convergence')
        Eu, mu, _ = _stack(d['corrected'], 'convergence')
        ax.plot(Eo, np.maximum(mo, 1e-30), '-', color='#1f4e79',
                lw=1.4, label='bare $H$')
        ax.plot(Eu, np.maximum(mu, 1e-30), '--', color='#c0504d',
                lw=1.4, label='$H$+UPCL')
        ax.set_yscale('log')
        ax.set_title(f'{h} on {fn}')
        ax.set_xlabel('evaluations')
        ax.set_ylabel('best-so-far')
        ax.grid(alpha=0.25, lw=0.4)
        ax.legend(frameon=False)

    for ax in axes[len(combos):]:
        ax.axis('off')
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    print('[fig] wrote', out.name)


def fig_rho(per_host, out):
    if not per_host:
        return
    hosts = [h['host'] for h in per_host]
    rho = [h['rho'] for h in per_host]
    imp = [h['imp_pct'] for h in per_host]
    x = np.arange(len(hosts))

    fig, ax1 = plt.subplots(figsize=(6.6, 2.9))
    ax1.bar(x, rho, width=0.55, color='#8faadc',
            edgecolor='#1f4e79', lw=0.6, label=r'$\rho$ (policy)')
    ax1.set_ylabel(r'intervention rate $\rho$')
    ax1.set_xticks(x)
    ax1.set_xticklabels(hosts, rotation=18, ha='right')
    ax1.set_ylim(0, max(0.05, max(rho) * 1.35))
    ax1.grid(axis='y', alpha=0.25, lw=0.4)

    ax2 = ax1.twinx()
    ax2.plot(x, imp, 'o-', color='#c0504d', lw=1.2, ms=5,
             label='mean improvement %')
    ax2.set_ylabel('mean improvement (%)')
    ax2.axhline(0.0, color='0.5', lw=0.6)
    ax2.set_ylim(min(0, min(imp) * 1.4) - 5, max(imp) * 1.4 + 5)

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, frameon=False, loc='upper left')

    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    print('[fig] wrote', out.name)


# ===========================================================================
def main(results_dir=None, summary=None):
    results_dir = Path(results_dir) if results_dir else ROOT / 'results' / 'upcl_D10_default'
    summary = Path(summary) if summary else results_dir / 'summary_D10.json'
    pairs = load_pairs(results_dir)
    if not pairs:
        print('[fig] no pair files found in', results_dir)
        return
    print(f'[fig] {len(pairs)} pair files')

    fig_convergence(pairs, FIGDIR / 'upcl_fig1_converge.png')

    per_host = []
    if summary.exists():
        rows = json.loads(Path(summary).read_text(encoding='utf-8'))
        by = defaultdict(list)
        for r in rows:
            by[r['host']].append(r)
        for h, rs in by.items():
            om = float(np.mean([r['orig_mean'] for r in rs]))
            um = float(np.mean([r['upcl_mean'] for r in rs]))
            per_host.append({
                'host': h,
                'imp_pct': (om - um) / (abs(om) + 1e-30) * 100.0,
                'rho': float(np.mean([r.get('policy_rate', 0.0) for r in rs])),
            })
        order = {'DE/rand/1': 0, 'CoBiDE': 1, 'JADE': 2,
                 'SHADE': 3, 'L-SHADE': 4, 'jSO': 5}
        per_host.sort(key=lambda d: (order.get(d['host'], 9), d['host']))
    fig_rho(per_host, FIGDIR / 'upcl_fig2_rho.png')


if __name__ == '__main__':
    main(*(sys.argv[1:3] if len(sys.argv) > 1 else []))

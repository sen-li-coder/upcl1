# -*- coding: utf-8 -*-
"""Turn the bare-vs-UPCL grid into the two views asked for:

* an **accuracy matrix**, rows = benchmark functions (F1..F30 / F1..F12),
  columns = host algorithms, cells = median final error, plus the paired
  decade-difference version of the same matrix;
* **convergence figures**, one per host algorithm, one subplot per function,
  showing the bare host and the same host with UPCL attached.

Every cell that exists is drawn; a (host, function) pair that has not been run
yet is left blank rather than interpolated, so the picture always shows how
much of the grid is real.

Errors are reported against the best value observed for the same function
(``reference_values()``), exactly as in ``analyze_upcl_cec.py``: it is one
constant per function, applied to both arms, and it is what keeps ``log10``
defined for the composite functions whose landscape dips below the declared
optimum.

    python src/analyze_upcl_grid.py
"""
import argparse
import csv
import json
import sys
import warnings
from collections import defaultdict
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

OUT = ROOT / 'results' / 'grid'
FIGDIR = OUT / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
FIGDIR.mkdir(parents=True, exist_ok=True)

FLOOR = 1e-8
SUITES = (('cec2017', 30), ('cec2017', 50), ('cec2022', 10))

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 8,
    'axes.labelsize': 8.5,
    'axes.titlesize': 8.5,
    'legend.fontsize': 7.5,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'figure.dpi': 200,
    'savefig.dpi': 200,
    'savefig.bbox': 'tight',
})

C_BARE, C_UPCL = '#1f4e79', '#c0504d'


# --------------------------------------------------------------------------
def _log10(v):
    return np.log10(np.maximum(np.asarray(v, dtype=float), FLOOR))


def load_cell(path):
    """One (host, function) cell from either result tree, or None if empty."""
    try:
        with open(path, encoding='utf-8') as fh:
            d = json.load(fh)
    except Exception:
        return None
    runs = d.get('runs', [])
    if not runs:
        return None
    bare, upcl = [], []
    for r in runs:
        b = r.get('bare')
        u = r.get('upcl') or r.get('full')
        if isinstance(b, dict) and isinstance(u, dict):
            bare.append(b)
            upcl.append(u)
    if not bare:
        return None
    grid = np.asarray(bare[0].get('grid', []), dtype=float)

    def curve(recs):
        out = []
        for r in recs:
            c = np.asarray(r.get('err_curve', []), dtype=float)
            out.append(c[:len(grid)] if len(grid) else c)
        n = min(len(c) for c in out)
        return np.vstack([c[:n] for c in out]) if n else np.zeros((0, 0))

    return {
        'suite': d['suite'], 'dim': int(d['dim']),
        'host': bare[0]['host'], 'fid': int(d['fid']),
        'func': bare[0].get('func', ''), 'category': bare[0].get('category', ''),
        'n': len(bare), 'grid': grid,
        'bare_final': np.array([float(r['err_final']) for r in bare]),
        'upcl_final': np.array([float(r['err_final']) for r in upcl]),
        'bare_curve': curve(bare), 'upcl_curve': curve(upcl),
    }


def load_all():
    """Every cell available, newest tree winning, keyed by (suite,dim,host,fid)."""
    cells = {}
    trees = [(OUT / 'raw', 'grid'), (ROOT / 'results' / 'cec' / 'raw', 'cec')]
    for base, tag in trees:
        if not base.exists():
            continue
        for p in sorted(base.glob('*/*/*.json')):
            c = load_cell(p)
            if c is None:
                continue
            key = (c['suite'], c['dim'], c['host'], c['fid'])
            if key not in cells or tag == 'grid':
                cells[key] = c
    return cells


def reference_values(cells):
    """Best error observed per function, used as the zero of the error scale.

    Same reason as ``analyze_upcl_cec.reference``: every function is normalised
    so that ``f(x_opt) = bias``, but under the deterministic fallback data the
    true minimum of a composite blend can lie well below that value (CEC 2017
    F7 does), and optimisers then return *negative* "errors".  Taking ``log10``
    of a negative number is undefined, and flooring it silently would hand the
    best possible cell to whichever arm happened to overshoot the declared
    optimum.  Subtracting a per-function constant is what restores a
    non-negative scale; because it is constant inside a cell it leaves every
    paired difference on the raw scale untouched.
    """
    ref = {}
    for c in cells.values():
        key = (c['suite'], c['dim'], c['fid'])
        vals = [float(v) for v in c['bare_final']] + \
               [float(v) for v in c['upcl_final']]
        if not vals:
            continue
        ref[key] = min(ref.get(key, float('inf')), min(vals))
    return ref


def apply_reference(cells, ref):
    """Shift every arm of every cell by its function's reference, in place."""
    for c in cells.values():
        v = ref.get((c['suite'], c['dim'], c['fid']), 0.0)
        c['bare_final'] = np.asarray(c['bare_final'], float) - v
        c['upcl_final'] = np.asarray(c['upcl_final'], float) - v
        c['bare_curve'] = np.asarray(c['bare_curve'], float) - v
        c['upcl_curve'] = np.asarray(c['upcl_curve'], float) - v


def write_reference_csv(ref, cells):
    path = OUT / 'reference_values.csv'
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['suite', 'dim', 'fid', 'reference_value', 'n_runs'])
        for key, v in sorted(ref.items()):
            suite, dim, fid = key
            n = sum(c['n'] for c in cells.values()
                    if (c['suite'], c['dim'], c['fid']) == key)
            w.writerow([suite, dim, f'F{fid}', f'{v:.6g}', n])
    print('[grid] reference ->', path.name, len(ref), 'functions')


def summarise(c):
    bm = float(np.median(c['bare_final']))
    um = float(np.median(c['upcl_final']))
    dec = float(_log10(bm) - _log10(um))
    try:
        with warnings.catch_warnings():
            # all-tied pairs give a zero standard error; that is not an error
            warnings.simplefilter('ignore')
            p = float(wilcoxon(c['upcl_final'], c['bare_final'],
                               alternative='two-sided',
                               zero_method='wilcox').pvalue)
    except Exception:
        p = float('nan')
    return {'dec': dec, 'p': p, 'bare_med': bm, 'upcl_med': um}


# --------------------------------------------------------------------------
def write_cells_csv(cells, ref):
    rows = []
    for key, c in sorted(cells.items()):
        s = summarise(c)
        rows.append({
            'suite': c['suite'], 'dim': c['dim'], 'host': c['host'],
            'fid': c['fid'], 'category': c['category'], 'runs': c['n'],
            'reference_value':
                f'{ref.get((c["suite"], c["dim"], c["fid"]), 0.0):.6g}',
            'bare_median': f'{s["bare_med"]:.6g}',
            'upcl_median': f'{s["upcl_med"]:.6g}',
            'decades_removed': f'{s["dec"]:.3f}',
            'p_wilcoxon': f'{s["p"]:.4g}',
            'verdict': ('better' if s['dec'] > 0.05 else
                        'worse' if s['dec'] < -0.05 else 'tie'),
        })
    path = OUT / 'cells.csv'
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print('[grid] cells ->', path.name, len(rows))
    return rows


def _matrices(cells, suite, dim, hosts, fids):
    bare = np.full((len(fids), len(hosts)), np.nan)  # baseline, no layer
    acc = np.full((len(fids), len(hosts)), np.nan)   # with UPCL (ours)
    dec = np.full((len(fids), len(hosts)), np.nan)   # decades removed
    for i, fid in enumerate(fids):
        for j, h in enumerate(hosts):
            c = cells.get((suite, dim, h, fid))
            if c is None:
                continue
            s = summarise(c)
            bare[i, j] = _log10(s['bare_med'])
            acc[i, j] = _log10(s['upcl_med'])
            dec[i, j] = s['dec']
    return bare, acc, dec


def _write_matrix_csv(name, fids, hosts, M, fmt='{:.3f}'):
    path = OUT / name
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['fid'] + list(hosts))
        for i, fid in enumerate(fids):
            w.writerow([f'F{fid}'] + ['-' if np.isnan(v) else fmt.format(v)
                                      for v in M[i]])
    print('[grid] matrix ->', path.name)


def heatmap(M, fids, hosts, title, cbar, cmap, out, vmax=None, center=None):
    fig_w = max(6.0, 0.42 * len(hosts) + 2.0)
    fig_h = max(3.2, 0.26 * len(fids) + 1.6)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    data = np.ma.array(M, mask=np.isnan(M))
    cmap = plt.get_cmap(cmap).copy()
    cmap.set_bad(color='#e8e8e8')
    if center is None:
        im = ax.imshow(data, aspect='auto', cmap=cmap,
                       vmin=np.nanmin(M), vmax=vmax if vmax else np.nanmax(M))
    else:
        lim = float(np.nanmax(np.abs(M - center))) or 1.0
        im = ax.imshow(data, aspect='auto', cmap=cmap,
                       vmin=center - lim, vmax=center + lim)
    ax.set_xticks(range(len(hosts)))
    ax.set_xticklabels(hosts, rotation=45, ha='right')
    ax.set_yticks(range(len(fids)))
    ax.set_yticklabels([f'F{f}' for f in fids])
    ax.set_title(title)
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    cb.set_label(cbar)
    cb.ax.tick_params(labelsize=7)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    print('[grid] figure ->', out.name)


def convergence_grid_figure(cells, suite, dim, hosts, fids):
    """One figure per (suite, dim): every host overlaid on the same grid of
    subplots, one subplot per function, one colour per host.  The bare host is
    a dashed trace and the same host with UPCL is a solid trace, so each
    function panel compares all hosts at once."""
    ncols = 5 if len(fids) > 15 else 4
    nrows = int(np.ceil(len(fids) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(2.3 * ncols, 1.9 * nrows),
                             sharey=False)
    axes = np.atleast_1d(axes).ravel()
    cmap = plt.get_cmap('tab20')
    colors = [cmap(i % cmap.N) for i in range(len(hosts))]

    for ax, fid in zip(axes, fids):
        ax.set_title(f'F{fid}', fontsize=8)
        if not any((suite, dim, h, fid) in cells for h in hosts):
            ax.text(0.5, 0.5, 'not run', ha='center', va='center',
                    fontsize=7, color='0.6', transform=ax.transAxes)
            ax.set_xticks([])
            ax.set_yticks([])
            continue
        xlim = None
        for h, col in zip(hosts, colors):
            c = cells.get((suite, dim, h, fid))
            if c is None:
                continue
            g = c['grid']
            b = np.median(_log10(c['bare_curve']), axis=0)
            u = np.median(_log10(c['upcl_curve']), axis=0)
            ax.plot(g, b, '--', color=col, lw=0.8)
            ax.plot(g, u, '-', color=col, lw=1.0)
            xlim = (g[0], g[-1])
        if xlim is not None:
            ax.set_xlim(*xlim)
        ax.grid(alpha=0.25, lw=0.3)
        ax.tick_params(labelsize=6)
    for ax in axes[len(fids):]:
        ax.axis('off')
    for ax in axes[:len(fids)]:
        ax.set_xlabel('evaluations', fontsize=7)
        ax.set_ylabel(r'$\log_{10}$ error', fontsize=7)

    # One colour per host, plus two shared style keys for the two arms.
    handles = [mlines.Line2D([], [], color=col, lw=1.3, label=h)
               for h, col in zip(hosts, colors)]
    handles += [
        mlines.Line2D([], [], color='0.35', lw=1.2, ls='--', label='bare'),
        mlines.Line2D([], [], color='0.35', lw=1.2, ls='-', label='+UPCL'),
    ]
    fig.suptitle(f'{suite} $D={dim}$: every host, bare (dashed) vs '
                 '+UPCL (solid), median of 5 runs', fontsize=9)
    fig.tight_layout(rect=[0, 0.13, 1, 0.97])
    fig.legend(handles=handles, loc='upper center',
               bbox_to_anchor=(0.5, 0.06), ncol=8, frameon=False,
               fontsize=6.5, columnspacing=1.0, handlelength=1.5)
    name = f'conv_{suite}_D{dim}_all.png'
    fig.savefig(FIGDIR / name)
    plt.close(fig)
    return name


def host_summary_figure(rows, suite, dim, hosts, out):
    """Where the layer helps on average, per host."""
    dec_by = defaultdict(list)
    for r in rows:
        if r['suite'] == suite and r['dim'] == dim:
            dec_by[r['host']].append(float(r['decades_removed']))
    hosts = [h for h in hosts if h in dec_by]
    if not hosts:
        return None
    means = [float(np.mean(dec_by[h])) for h in hosts]
    mins = [float(np.min(dec_by[h])) for h in hosts]
    maxs = [float(np.max(dec_by[h])) for h in hosts]
    n = [len(dec_by[h]) for h in hosts]
    x = np.arange(len(hosts))
    fig, ax = plt.subplots(figsize=(max(6.4, 0.42 * len(hosts)), 2.8))
    ax.bar(x, means, width=0.6, color='#8faadc', edgecolor='#1f4e79', lw=0.6)
    ax.errorbar(x, means, [np.array(means) - np.array(mins),
                           np.array(maxs) - np.array(means)],
                fmt='none', ecolor='0.35', lw=0.8, capsize=2)
    ax.axhline(0.0, color='0.4', lw=0.7)
    ax.set_xticks(x)
    ax.set_xticklabels([f'{h}\n(n={c})' for h, c in zip(hosts, n)],
                       rotation=45, ha='right', fontsize=6.5)
    ax.set_ylabel('decades of error removed\n(mean, min-max over functions)')
    ax.set_title(f'{suite} $D={dim}$: mean effect per host algorithm')
    ax.grid(axis='y', alpha=0.25, lw=0.4)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    print('[grid] figure ->', out.name)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--min-runs', type=int, default=5,
                    help='a cell counts only once it has this many runs; '
                         'lower it to preview a grid that is still filling')
    a = ap.parse_args(argv)

    # A cell still being written holds the runs completed so far, and its
    # median would drift as the remaining runs land. Keeping the tables on
    # finished cells only is what makes two consecutive renders comparable.
    # The reference, by contrast, is taken over everything available:
    # including a half-finished cell can only move it downwards, towards the
    # true floor of the function, which is the conservative direction.
    loaded = load_all()
    ref = reference_values(loaded)
    apply_reference(loaded, ref)
    write_reference_csv(ref, loaded)

    cells = {k: c for k, c in loaded.items() if c['n'] >= a.min_runs}
    if not cells:
        print(f'[grid] no cell has {a.min_runs} runs yet')
        return
    partial = len(loaded) - len(cells)
    print(f'[grid] complete cells: {len(cells)}   '
          f'still running (excluded): {partial}')
    rows = write_cells_csv(cells, ref)

    try:
        import de_hosts_cec as DHC
        order = list(DHC.CEC_HOST_ORDER)
    except Exception:                                    # pragma: no cover
        order = sorted({c['host'] for c in cells.values()})

    for suite, dim in SUITES:
        fids = sorted({c['fid'] for c in cells.values()
                       if c['suite'] == suite and c['dim'] == dim})
        hosts = [h for h in order
                 if any((suite, dim, h, f) in cells for f in fids)]
        if not fids or not hosts:
            continue
        print(f'[grid] {suite} D{dim}: {len(fids)} functions x '
              f'{len(hosts)} hosts ({len(fids) * len(hosts)} cells, '
              f'{sum(1 for f in fids for h in hosts if (suite, dim, h, f) in cells)} measured)')
        bare, acc, dec = _matrices(cells, suite, dim, hosts, fids)
        tag = f'{suite}_D{dim}'
        _write_matrix_csv(f'bare_accuracy_{tag}.csv', fids, hosts, bare)
        _write_matrix_csv(f'accuracy_{tag}.csv', fids, hosts, acc)
        _write_matrix_csv(f'delta_{tag}.csv', fids, hosts, dec)
        heatmap(dec, fids, hosts,
                f'{suite} $D={dim}$: decades of error removed by UPCL '
                '(positive = better)',
                'decades removed', 'RdBu', FIGDIR / f'heat_delta_{tag}.png',
                center=0.0)
        heatmap(acc, fids, hosts,
                f'{suite} $D={dim}$: final accuracy with UPCL '
                r'($\log_{10}$ error, lower is better)',
                r'$\log_{10}$ final error', 'viridis_r',
                FIGDIR / f'heat_acc_{tag}.png')
        host_summary_figure(rows, suite, dim, hosts,
                            FIGDIR / f'per_host_{tag}.png')
        convergence_grid_figure(cells, suite, dim, hosts, fids)
        print(f'[grid] combined convergence figure written to '
              f'{FIGDIR.name}/conv_{tag}_all.png')


if __name__ == '__main__':
    main()

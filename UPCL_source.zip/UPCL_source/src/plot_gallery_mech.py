# -*- coding: utf-8 -*-
"""Gallery (batch 2): 30-host x 4-category MECHANISM profile, 9 panels (3x3).
   (a) mech heatmap  (b1-b4) rose radar per category  (c) mech line
   (d) kappa-vs-gain  (e) hexbin density  (f) stacked composition
Run: python src/plot_gallery_mech.py
"""
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'

CATS = ['unimodal', 'multimodal', 'hybrid', 'composite']
CAT_LABEL = {'unimodal': 'Unimodal', 'multimodal': 'Multimodal',
             'hybrid': 'Hybrid', 'composite': 'Composite'}
CAT_COL = {'unimodal': '#1f77b4', 'multimodal': '#2ca02c',
           'hybrid': '#ff7f0e', 'composite': '#d62728'}
MECH = ['rho', 'theta', 'eta', 'kappa', 'nu']
MECH_COL = {'rho': '#1f77b4', 'theta': '#2ca02c', 'eta': '#ff7f0e',
            'kappa': '#d62728', 'nu': '#9467bd'}
MECH_COLUMN = {'rho': 'rho_step_effect', 'theta': 'theta_align_effect',
               'eta': 'eta_elite_effect', 'kappa': 'kappa_crowd_effect',
               'nu': 'nu_novel_effect'}


def _f(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return np.nan
    return v if np.isfinite(v) else np.nan


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8, 'axes.labelsize': 7, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 5.5, 'ytick.labelsize': 5.5,
        'legend.fontsize': 5.5, 'legend.frameon': False, 'figure.dpi': 300})


def load():
    cells = list(csv.DictReader(open(TABLES / 'mech30_cells.csv', encoding='utf-8', newline='')))
    hs = {r['host']: r for r in csv.DictReader(open(TABLES / 'mech30_host_summary.csv', encoding='utf-8', newline=''))}
    order = sorted(hs, key=lambda h: int(hs[h]['bare_rank']))
    agg = defaultdict(list)
    for r in cells:
        agg[(r['host'], r['category'])].append(r)
    gain, bare, mech = {}, {}, {}
    for (h, c), rs in agg.items():
        def mean(k):
            return np.nanmean([_f(x[k]) for x in rs])
        gain[(h, c)] = mean('dec_median')
        bare[(h, c)] = mean('bare_median_log10err')
        mech[(h, c)] = {m: mean(col) for m, col in MECH_COLUMN.items()}
    return cells, order, gain, bare, mech


def _label(ax, s):
    ax.text(-0.12, 1.06, s, transform=ax.transAxes, fontsize=9, fontweight='bold', va='top')


def gallery_mech():
    cells, order, gain, bare, mech = load()
    M = np.array([[np.mean([mech[(h, c)][m] for h in order]) for m in MECH] for c in CATS])

    fig = plt.figure(figsize=(13.2, 9.6))
    fig.subplots_adjust(left=0.09, right=0.97, top=0.94, bottom=0.06,
                        wspace=0.45, hspace=0.55)

    # (a) mech heatmap 4 category x 5 mechanism
    ax = fig.add_subplot(3, 3, 1)
    vmax = np.nanmax(np.abs(M))
    im = ax.imshow(M, cmap='RdBu_r', norm=TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax), aspect='auto')
    ax.set_xticks(range(5)); ax.set_xticklabels(MECH, fontsize=6)
    ax.set_yticks(range(4)); ax.set_yticklabels([CAT_LABEL[c] for c in CATS], fontsize=6)
    for i in range(4):
        for j in range(5):
            ax.text(j, i, f'{M[i, j]:.2f}', ha='center', va='center', fontsize=5.5,
                    color='#111' if abs(M[i, j]) < 0.55 * vmax else 'white')
    ax.set_title('mean mechanism effect (4 cat x 5)', loc='left', fontsize=7)
    _label(ax, 'a')
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
    cbar.ax.tick_params(labelsize=4.5)

    # (b1-b4) rose radar per category
    angles = np.linspace(0, 2 * np.pi, len(MECH), endpoint=False).tolist()
    angles += angles[:1]
    Mnorm = (M - M.min()) / (M.max() - M.min() + 1e-9)
    for ci, c in enumerate(CATS):
        ax = fig.add_subplot(3, 3, 2 + ci, polar=True)
        vals = Mnorm[ci].tolist() + [Mnorm[ci][0]]
        ax.plot(angles, vals, color=CAT_COL[c], linewidth=1.5)
        ax.fill(angles, vals, color=CAT_COL[c], alpha=0.30)
        ax.set_xticks(angles[:-1]); ax.set_xticklabels(MECH, fontsize=6)
        ax.set_ylim(0, 1); ax.set_yticks([0.5, 1.0]); ax.set_yticklabels(['', ''], fontsize=4)
        ax.set_title(CAT_LABEL[c], fontsize=7.5, color=CAT_COL[c], pad=8)
        ax.tick_params(labelsize=5)
        ax.grid(color='#cccccc', linewidth=0.4, alpha=0.6)
        if ci == 0:
            _label(ax, 'b')

    # (c) mech line across categories
    ax = fig.add_subplot(3, 3, 6)
    for m in MECH:
        ax.plot(range(4), M[:, MECH.index(m)], color=MECH_COL[m], lw=1.8,
                marker='o', markersize=4, label=m)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.set_xticks(range(4)); ax.set_xticklabels([CAT_LABEL[c][:6] for c in CATS], fontsize=6)
    ax.set_ylabel('mean effect')
    ax.set_title('mechanism effect across categories', loc='left', fontsize=7)
    ax.legend(loc='lower left', ncol=5)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'c')

    # (d) kappa vs gain (120 host-category points + fit)
    ax = fig.add_subplot(3, 3, 7)
    kx = np.array([mech[(h, c)]['kappa'] for h in order for c in CATS])
    gy = np.array([gain[(h, c)] for h in order for c in CATS])
    cc = [CAT_COL[c] for h in order for c in CATS]
    ax.scatter(kx, gy, s=14, c=cc, alpha=0.55, edgecolors='white', linewidths=0.3, zorder=3)
    z = np.polyfit(kx, gy, 1)
    xs = np.linspace(kx.min(), kx.max(), 40)
    ax.plot(xs, np.polyval(z, xs), color='#666', lw=1.2, ls='--', zorder=2)
    from scipy.stats import spearmanr
    r, p = spearmanr(kx, gy)
    ax.text(0.03, 0.04, f'rho={r:.2f} (p={p:.2g})', transform=ax.transAxes, fontsize=6)
    ax.axhline(0, color='#333', lw=0.8, ls='--')
    ax.axvline(0, color='#999', lw=0.6, ls=':')
    ax.set_xlabel('kappa (crowding effect)')
    ax.set_ylabel('gain (dec)')
    ax.set_title('kappa vs gain (120 host-category)', loc='left', fontsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'd')

    # (e) hexbin density capacity x kappa + category centroids
    ax = fig.add_subplot(3, 3, 8)
    cx = np.array([_f(r['bare_median_log10err']) for r in cells])
    kk = np.array([_f(r['kappa_crowd_effect']) for r in cells])
    m = np.isfinite(cx) & np.isfinite(kk)
    cx, kk = cx[m], kk[m]
    clo, chi = np.percentile(cx, [0.5, 99.5]); klo, khi = np.percentile(kk, [0.5, 99.5])
    keep = (cx >= clo) & (cx <= chi) & (kk >= klo) & (kk <= khi)
    hb = ax.hexbin(cx[keep], kk[keep], gridsize=30, cmap='Greys', mincnt=1,
                   bins='log', linewidths=0.1, zorder=1)
    for c in CATS:
        mx = np.mean([bare[(h, c)] for h in order])
        mk = np.mean([mech[(h, c)]['kappa'] for h in order])
        ax.scatter(mx, mk, s=90, color=CAT_COL[c], edgecolors='white',
                   linewidths=1.0, zorder=4, label=CAT_LABEL[c])
    ax.set_xlim(clo, chi); ax.set_ylim(klo, khi)
    ax.set_xlabel('capacity (log10 error)')
    ax.set_ylabel('kappa (crowding)')
    ax.set_title('capacity x kappa density + centroids', loc='left', fontsize=7)
    ax.legend(loc='lower left', ncol=2)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'e')

    # (f) stacked composition 4 category x 5 mechanism |effect|
    ax = fig.add_subplot(3, 3, 9)
    Mabs = np.abs(M)
    Mabs = Mabs / (Mabs.sum(axis=1, keepdims=True) + 1e-9)
    left = np.zeros(4)
    for j, m in enumerate(MECH):
        ax.barh(range(4), Mabs[:, j], left=left, height=0.62, color=MECH_COL[m], label=m)
        left += Mabs[:, j]
    ax.set_yticks(range(4)); ax.set_yticklabels([CAT_LABEL[c] for c in CATS], fontsize=6)
    ax.set_xlabel('share of |effect| (100%)')
    ax.set_title('mechanism composition by category', loc='left', fontsize=7)
    ax.legend(loc='lower right', ncol=5)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    _label(ax, 'f')

    fig.suptitle('Gallery 2 — UPCL mechanism profile: 30 hosts x 4 problem categories',
                 fontsize=11, y=0.98)
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / 'gallery_mech.png', bbox_inches='tight')
    plt.close(fig)
    print('[gallery2] gallery_mech.png')


if __name__ == '__main__':
    _style()
    gallery_mech()
    print('[gallery2] done ->', FIG)

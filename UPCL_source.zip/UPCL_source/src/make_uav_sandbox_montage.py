"""Assemble the four sandbox screenshots into the 2x2 panel used as the Chapter 5
sandbox figure.

The four panels are captures of the simulator's own 3-D visualiser looking at
the *same* interception scenario from four different camera azimuths, so the
figure shows the run-time environment -- terrain, forest, power grid, early
warning radar dome, no-fly spheres, patrol vision discs and the flight ceiling
-- from all sides rather than from a single viewpoint.

Inputs (``results/apps/figures``), one capture per panel, in the order the four
viewpoints were requested::

    sandbox_view_a.* ... sandbox_view_d.*          1080 x 588 each

The captures are stored under whatever extension their bytes say (the browser
view of the visualiser emits JPEG); the panel is re-encoded as PNG here.

Output: ``docs/figures/fig_uav_sandbox_view.png`` -- the manuscript folder, so
that the sandbox panel is registered and audited like every other paper figure.

The captures themselves are produced by hand from the visualiser (the browser
view of ``app/webapp``); only the assembly is automated, so re-running this
script reproduces the exact panel layout from the stored captures.

Usage::

    python src/make_uav_sandbox_montage.py
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt                                        # noqa: E402
from matplotlib.image import imread                                    # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / 'src') not in sys.path:
    sys.path.insert(0, str(ROOT / 'src'))
import paper_figures as PF                                             # noqa: E402

SRC = ROOT / 'results' / 'apps' / 'figures'
PANELS = 'abcd'
DPI = 300
# The seam between panels is a hairline of white, wide enough to read the four
# views as separate panels without shrinking them.
WSPACE = 0.008
HSPACE = 0.014


def main():
    files = []
    for p in PANELS:
        found = sorted(SRC.glob('sandbox_view_%s.*' % p))
        files.extend(found[:1])
    missing = ['sandbox_view_%s.*' % p for p, f in zip(PANELS, files)
               if not f.exists()]
    if missing:
        raise SystemExit('[montage] missing capture(s): %s' % ', '.join(missing))

    images = [imread(str(f)) for f in files]
    h, w = images[0].shape[:2]
    for f, im in zip(files, images):
        if im.shape[:2] != (h, w):
            raise SystemExit('[montage] %s is %s, expected %s'
                             % (f.name, im.shape[:2], (h, w)))

    fig_w = 2 * w / DPI
    fig_h = 2 * h / DPI
    fig, axes = plt.subplots(2, 2, figsize=(fig_w, fig_h), dpi=DPI)
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0,
                        wspace=WSPACE, hspace=HSPACE)
    for ax, im, letter in zip(axes.ravel(), images, PANELS):
        ax.imshow(im)
        ax.set_axis_off()
        ax.text(0.015, 0.975, '(%s)' % letter, transform=ax.transAxes,
                ha='left', va='top', color='white', fontsize=13,
                fontweight='bold', zorder=5,
                bbox=dict(boxstyle='round,pad=0.34,rounding_size=0.32',
                          facecolor='#3c3c3c', edgecolor='#c2c7cd',
                          linewidth=1.2))

    out = PF.out_path('uav_sandbox')
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    size = out.stat().st_size
    print('[montage] %s <- %d panels %dx%d (%d bytes)'
          % (out.relative_to(ROOT), len(files), 2 * w, 2 * h, size))


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""30 optimization algorithms as individuals (not aggregated by level/dimension).
Run: python src/plot_algo_individuals.py
"""
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'results' / 'cec' / 'tables'
FIG = ROOT / 'results' / 'cec' / 'figures'
FIG_W = 6.3

LEVEL_COLORS = {0: '#d62728', 1: '#ff7f0e', 2: '#2ca02c', 3: '#1f77b4'}
LEVEL_LABELS = {0: 'L0 fixed', 1: 'L1 adaptive', 2: 'L2 archive', 3: 'L3 LPSR'}


def _read(name):
    p = TABLES / name
    if not p.exists():
        raise SystemExit(f'missing: {p}')
    return list(csv.DictReader(open(p, encoding='utf-8', newline='')))


def _f(x, default=np.nan):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def _style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 8.5, 'axes.labelsize': 8, 'axes.linewidth': 0.6,
        'axes.edgecolor': '#444444', 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
        'legend.fontsize': 6.5, 'legend.frameon': False, 'figure.dpi': 300})


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / name, bbox_inches='tight')
    plt.close(fig)
    print(f'[algo] {name}')


def _level_legend():
    return [plt.Line2D([], [], marker='o', linestyle='', markersize=5,
                       color=LEVEL_COLORS[lv], label=LEVEL_LABELS[lv]) for lv in [0, 1, 2, 3]]


def algo_forest(hosts, cells):
    hs = sorted(hosts, key=lambda r: _f(r['dec_mean']))
    names = [r['host'] for r in hs]
    cd = defaultdict(list)
    for r in cells:
        cd[r['host']].append(_f(r['dec_median']))
    meds = [_f(r['dec_mean']) for r in hs]
    los, his = [], []
    for r in hs:
        v = np.array([x for x in cd[r['host']] if np.isfinite(x)])
        los.append(np.median(v) - np.percentile(v, 25))
        his.append(np.percentile(v, 75) - np.median(v))
    cols = [LEVEL_COLORS[int(r['level'])] for r in hs]
    fig, ax = plt.subplots(figsize=(FIG_W, 7.2))
    fig.subplots_adjust(left=0.30, right=0.97, top=0.97, bottom=0.06)
    y = np.arange(len(names))
    ax.axvspan(-0.7, 0, color='#d62728', alpha=0.045, zorder=0)
    ax.axvspan(0, 0.2, color='#2ca02c', alpha=0.045, zorder=0)
    ax.axvline(0, color='#333333', lw=0.9, zorder=1)
    for i in y:
        ax.errorbar([meds[i]], [y[i]], xerr=[[los[i]], [his[i]]], fmt='o', markersize=4,
                    elinewidth=1.0, capsize=2, capthick=0.8, color=cols[i],
                    ecolor='#999999', zorder=3)
    ax.set_yticks(y); ax.set_yticklabels(names, fontsize=5.4)
    ax.invert_yaxis()
    ax.set_xlim(-0.72, 0.22)
    ax.set_xlabel('intervention gain (dec, + better)')
    ax.set_title('30 optimization algorithms as individuals, ranked by median gain', loc='left')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(axis='x', color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)
    ax.legend(handles=_level_legend(), loc='lower right', ncol=4, fontsize=6)
    _save(fig, 'algo_forest.png')


def algo_rank_gain(hosts):
    hs = sorted(hosts, key=lambda r: _f(r['bare_rank']))
    x = [_f(r['bare_rank']) for r in hs]
    y = [_f(r['dec_mean']) for r in hs]
    names = [r['host'] for r in hs]
    cols = [LEVEL_COLORS[int(r['level'])] for r in hs]
    rho, p = spearmanr(x, y)
    fig, ax = plt.subplots(figsize=(FIG_W, 4.8))
    fig.subplots_adjust(left=0.08, right=0.70, top=0.94, bottom=0.10)
    ax.scatter(x, y, s=32, c=cols, edgecolors='white', linewidths=0.5, zorder=3)
    ax.axhline(0, color='#333333', lw=0.8, zorder=1)
    for xi, yi, nm in zip(x, y, names):
        ax.text(xi + 0.35, yi, nm, fontsize=4.9, va='center', color='#444444')
    ax.set_xlabel('bare rank (1 = strongest)')
    ax.set_ylabel('intervention gain (dec)')
    ax.set_title(f'each algorithm: gain vs capacity rank  (rho={rho:.2f}, p={p:.3g})', loc='left')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.grid(color='#dddddd', linewidth=0.5, alpha=0.7)
    ax.set_axisbelow(True)
    ax.legend(handles=_level_legend(), loc='upper left', ncol=4, fontsize=6)
    _save(fig, 'algo_rank_gain.png')


if __name__ == '__main__':
    _style()
    hosts = _read('mech30_host_summary.csv')
    cells = _read('mech30_cells.csv')
    algo_forest(hosts, cells)
    algo_rank_gain(hosts)
    print('[algo] done ->', FIG)

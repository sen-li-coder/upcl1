"""无人机集群协同对抗 —— 2020 华为杯研究生数学建模 D 题 仿真场景。

这是 LASE 的第二个「应用问题套件」场景，与 ``uav_adversarial``（突防 vs 拦截）
并列。本模块对赛题进行完整的分析、建模与确定性仿真，以与 ``cec_suites.CECFunction``
相同的鸭子类型协议接入主软件，从而复用 30 个纯连续 DE + bare/UPCL 配对 + 落盘
schema，而无需改动任何 DE 核。

================================================================================
一、赛题抽象（真实参数，单位统一为米）
================================================================================
红蓝双方无人机在同一高度（平面）内机动。蓝方为进攻方，希望突破红方拦截、
在时间限制内越过目标边界（突防成功）；红方为防守方，通过多机协同在通道内
拦截蓝方。全部物理参数取自 2020 D 题原文：

  * 对抗区域：矩形 ABCD，攻击纵深 L = BC = 50 km，通道带宽 M = AB（可变）。
  * 蓝方无人机：速度 V_E = 250 m/s，最小转弯半径 R_E = 500 m。
  * 红方无人机：速度 V_P = 200 m/s，最小转弯半径 R_P = 350 m。
  * 双方速度恒定，航向可随时改变但受最小转弯半径限制（有限角速度 → 无直角
    转弯）；双方均可实时探测对方与己方位置（完全信息、确定性）。
  * 拦截判据：当蓝方突防无人机进入任意红方机头前方 ±30° 扇形、距离 < 55 m
    时，判定红方成功拦截（击落）该蓝方无人机。
  * 蓝方须在 360 s 内越过边界 CD，否则突防失败。
  * 红方编队约束：任意两架间距 > 30 m；每架与本集群至少 2 架间距 ≤ 200 m。
    对抗过程中队形可随时调整（不要求全程保持固定队形）。

红方集群初始队形为「圆周均布」：以集群中心为圆心、formation_radius = 100 m
为半径，m 架无人机均匀分布在该圆周上（相邻间距相同），机头朝向蓝方出发点。

================================================================================
二、决策变量与优化目标（适配 30 个 DE 的关键落点）
================================================================================
蓝方突防无人机为被优化方。决策变量 x ∈ [-1,1]^D 为每架蓝方无人机的 K 个
中途航点（连续坐标），维度 D = n_attack * K * 2：

      x 分量  ->  [0, M]   （通道横向，受 AD/BC 边界约束）
      y 分量  ->  [0, L]   （攻击纵深，从 AB 到 CD）

蓝方从 AB 边界中心出发，依次飞经 K 个航点，最终抵达 CD 边上的目标红点即突防成功。
红方采用确定性的「追击最近存活目标」规则机动（纯追踪 + 最小转弯半径限制 +
机间避撞），因此整个 rollout 是确定性的、可复现的，且毫秒级。

cost(x) = -reward，DE 求最小化。reward 组成：
      + w_arrive * 突防成功架次
      - w_lost   * 被拦截架次
      - w_time   * 超时未完成架次
      - w_bounds * 越过通道边界的累计步数（AD/BC 两侧）

================================================================================
三、场景变体（对应赛题四问）
================================================================================
  F1（问题一 布局）：M=30km，红方 2 集群各 5 架，中心沿纵深错开（约 15/35km），
     蓝方 1 架。核心是蓝方绕开两个拦截集群的最优突防路径。
  F2（问题二 布局）：M=12km 窄通道，红方 2 集群各 5 架贴近 CD 一侧。考验窄
     通道下蓝方能否突防（对应“通道带宽下限”问题）。
  F3（问题三 布局）：M=70km，红方 2 集群各 10 架（两波次增援）。蓝方 1 架。
  F4（问题四 布局）：M=100km，红方 5 集群各 4 架（5 架运载机协同），蓝方 1 架
     （多对一加强拦截；赛题问题四为 3 架蓝方，此处保持维度统一作单机加强版）。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

# 三维地形基础设施（Terrain / terrain_blocked）复用山区救援模块，避免重复实现
try:                                                     # pragma: no cover
    from .uav_flood import Terrain, terrain_blocked       # noqa: E402
except ImportError:                                      # pragma: no cover
    from uav_flood import Terrain, terrain_blocked        # noqa: E402


# ===========================================================================
# 环境参数
# ===========================================================================

@dataclass
class SwarmConfig:
    """一次集群协同对抗仿真的全部环境参数（真实物理量，单位：米、秒）。"""

    # 对抗区域
    depth: float = 50000.0           # 攻击纵深 L（BC 距离，蓝方突防方向）
    width: float = 30000.0           # 通道带宽 M（AB 距离）

    # 蓝方（突防方，被优化）
    n_attack: int = 1                # 蓝方突防无人机数量
    attack_speed: float = 250.0      # V_E（m/s）
    attack_turn_radius: float = 500.0  # R_E（m）

    # 红方（拦截方，规则对手）
    n_clusters: int = 2              # 红方集群数
    cluster_size: int = 5            # 每集群无人机数
    defend_speed: float = 200.0      # V_P（m/s）
    defend_turn_radius: float = 350.0  # R_P（m）
    intercept_radius: float = 55.0   # R：拦截判据距离（前方捕获扇形半径）
    intercept_min_count: int = 1     # 拦截判据：至少此数量的红方同时进入扇区内
    intercept_half_angle: float = 30.0  # 红方前方圆锥水平半角（度，总水平角 2×）
    intercept_vert_half_angle: float = 30.0  # 红方前方圆锥垂直半角（度，总垂直角 2×）
    formation_radius: float = 100.0  # 集群初始圆周半径
    min_sep: float = 30.0            # 红方机间最小间距（避撞/编队）
    cluster_link_range: float = 200.0  # 集群内至少 2 架的连通距离上限
    cluster_centers: List[Tuple[float, float]] = field(
        default_factory=lambda: [(15000.0, 15000.0), (15000.0, 35000.0)])

    # 蓝方路径与仿真
    n_waypoints: int = 4             # 每架蓝方中途航点数 K
    n_steps: int = 360               # 仿真步数（dt = 1 s）
    time_limit: float = 360.0        # 突防时限（s）
    wp_reach_radius: float = 500.0   # 中间航点到达判定半径（米）

    # —— 红方拦截者航点（协同演化：每架拦截者 K_red 个二维巡逻航点，闭环巡逻）——
    n_int_waypoints: int = 2

    # —— 蓝方三维飞行：高度自由度 + 能源 + 坠毁 ——
    max_alt: float = 5000.0          # 蓝方飞行高度上限（绝对高度，米；需覆盖断崖高地 + 离地高度）
    max_climb_rate: float = 100.0    # 每步最大爬升/下降速率（米/步），匹配缓坡断崖坡度
    max_alt_offset: float = 800.0    # 航点高度相对贴地高度的最大爬升偏移（米）
    lookahead_steps: int = 28        # 垂直前瞻步数（提前爬升，覆盖断崖落差~2.2km，避免穿山兜底弹跳）
    energy_capacity: float = 180.0   # 每架初始能源（断崖高地爬升能耗大，需留裕度）
    energy_per_step: float = 0.35    # 每步水平飞行基础能耗
    climb_energy: float = 0.004      # 每爬升 1 米额外能耗（高落差地貌下留出翻越裕度）

    # 红色球形禁飞区 (cx, cy, cz, r)
    no_fly_zones: List[Tuple[float, float, float, float]] = field(
        default_factory=list)

    # —— 地面防空车（地对空拦截；不可跨越峡谷/瀑布，可翻越普通高低地势）——
    n_aa: int = 3                     # 地面防空车数量
    aa_speed: float = 40.0            # 地面机动速度（m/s）
    aa_range: float = 6000.0          # 对空拦截水平半径（米）
    aa_vert_half_angle: float = 60.0  # 对空圆锥仰角半角（度，母线与水平面夹角）
    # 拦截导弹：进入攻击范围即发射；导弹略快于无人机（纯追踪制导 + 有限转弯
    # 率，不能直角转弯），有燃料上限（耗尽自毁），一对一追击（每车每目标一枚）
    missile_speed: float = 320.0      # 拦截导弹飞行速度（m/s，≈1.3× 无人机 250 m/s）
    missile_turn: float = 0.6         # 导弹最大航向改变率（rad/步，有限转弯，非直角）
    missile_climb: float = 250.0      # 导弹每步最大爬升/俯冲速率（m/步）
    missile_radius: float = 40.0      # 导弹命中半径（米）
    missile_fuel: int = 45            # 导弹最大飞行步数（燃料耗尽自毁，射程≈14.4km）
    aa_reload: float = 2.0            # 防空车发射冷却（秒）
    aa_max_missiles: int = 3          # 每辆防空车同时在场导弹上限

    # —— 地貌复杂度：峡谷 / 瀑布（防空车不可跨越，蓝方空中飞越不受限）——
    terrain_canyons: bool = True      # 生成峡谷（深沟）
    terrain_waterfalls: bool = True   # 生成瀑布（陡崖）

    # —— 三维山地地形（集群突防：贴地飞行 + 爬山能耗 + 视线遮挡）——
    terrain_enabled: bool = True      # 启用三维合成山地地形
    terrain_amplitude: float = 900.0  # 山地起伏幅度（米）
    h_clearance: float = 200.0        # 贴地飞行离地安全高度（米）
    los_block: bool = True            # 拦截捕获需视线（LOS）通畅，山体可遮挡雷达

    # 收益权重（cost = -reward）
    w_arrive: float = 100.0
    w_lost: float = 80.0
    w_time: float = 30.0
    w_bounds: float = 30.0
    w_path: float = 30.0             # 绕行惩罚权重（实际路径长度 / L - 1）
    w_safety: float = 20.0           # 安全裕度奖励权重（与红方最小距离 / 4R）
    w_climb: float = 40.0            # 爬山能耗惩罚：翻越一座典型山地(≈terrain_amplitude米爬升)的罚分
    w_nofly: float = 20.0            # 球形禁飞区惩罚权重（每步）
    w_crash: float = 90.0            # 能源耗尽坠毁惩罚权重（每架）

    @property
    def dim(self) -> int:
        """蓝方决策变量维度 = n_attack * n_waypoints * 3（每航点 x,y,z 含高度）。"""
        return self.n_attack * self.n_waypoints * 3

    @property
    def n_drones(self) -> int:
        """别名：被优化方（蓝方突防）无人机数，与 intercept 场景字段对齐。"""
        return self.n_attack

    @property
    def n_interceptors(self) -> int:
        """红方拦截者总数 = n_clusters * cluster_size。"""
        return self.n_clusters * self.cluster_size

    @property
    def red_dim(self) -> int:
        """红方（拦截者）决策变量维度 = n_interceptors * n_int_waypoints * 2。"""
        return self.n_interceptors * self.n_int_waypoints * 2

    @property
    def max_turn_attack(self) -> float:
        """蓝方每步最大航向改变量（rad）= v / R * dt（dt=1s）。"""
        return self.attack_speed / self.attack_turn_radius

    @property
    def max_turn_defend(self) -> float:
        return self.defend_speed / self.defend_turn_radius

    @property
    def intercept_half_angle_rad(self) -> float:
        return math.radians(self.intercept_half_angle)

    @property
    def intercept_vert_half_angle_rad(self) -> float:
        return math.radians(self.intercept_vert_half_angle)

    def describe(self) -> Dict[str, object]:
        """展平为可读 dict，供 GUI 参数面板显示。"""
        return {
            '赛题': '2020 华为杯研究生数模 D 题',
            '对抗区域': f'纵深 {self.depth / 1000:.0f} km × '
                       f'带宽 {self.width / 1000:.0f} km',
            '蓝方无人机': f'{self.n_attack} 架',
            '蓝方速度': f'{self.attack_speed:.0f} m/s',
            '蓝方最小转弯半径': f'{self.attack_turn_radius:.0f} m',
            '蓝方最大角速度': f'{self.max_turn_attack:.3f} rad/s',
            '红方集群': f'{self.n_clusters} 个 × {self.cluster_size} 架',
            '红方速度': f'{self.defend_speed:.0f} m/s',
            '红方最小转弯半径': f'{self.defend_turn_radius:.0f} m',
            '红方最大角速度': f'{self.max_turn_defend:.3f} rad/s',
            '拦截判据': f'≥{self.intercept_min_count} 架红方前方圆锥'
                       f'（水平 ±{self.intercept_half_angle:.0f}° / '
                       f'垂直 ±{self.intercept_vert_half_angle:.0f}°）'
                       f'{self.intercept_radius:.0f} m 内',
            '集群编队半径': f'{self.formation_radius:.0f} m',
            '红方最小间距': f'{self.min_sep:.0f} m',
            '突防时限': f'{self.time_limit:.0f} s',
            '每机航点数 K': self.n_waypoints,
            '红方每机航点数 K_red': self.n_int_waypoints,
            '决策变量维度 D': self.dim,
            '红方决策变量维度 D_red': self.red_dim,
            '编码域': '[-1, 1]^D',
            '飞行高度上限': f'{self.max_alt:.0f} m',
            '能源': (f'初始 {self.energy_capacity:.0f}，每步 {self.energy_per_step:.2f}，'
                     f'爬升 {self.climb_energy:.3f}/m，耗尽坠毁'),
            '球形禁飞区': (f'{len(self.no_fly_zones)} 个' if self.no_fly_zones else '无'),
            '地面防空车': (f'{self.n_aa} 辆（对空半径 {self.aa_range / 1000:.1f} km，'
                          f'导弹 {self.missile_speed:.0f} m/s 略快于无人机、限转弯率、'
                          f'燃料 {self.missile_fuel} 步耗尽自毁，不可跨越峡谷/瀑布）'
                          if self.n_aa else '无'),
            '峡谷/瀑布地貌': ('峡谷 + 瀑布' if (self.terrain_canyons and self.terrain_waterfalls)
                             else '峡谷' if self.terrain_canyons
                             else '瀑布' if self.terrain_waterfalls else '无'),
            '绕行惩罚权重': f'{self.w_path:.0f}（路径长度 / L - 1）',
            '安全裕度权重': f'{self.w_safety:.0f}（与红方最小距离 / 4R）',
        }


# ===========================================================================
# 三维合成山地地形
# ===========================================================================

def _seg_dist(px, py, ax, ay, bx, by):
    """向量化点到线段 (a,b) 的垂直距离。"""
    abx, aby = bx - ax, by - ay
    l2 = abx * abx + aby * aby
    t = np.clip(((px - ax) * abx + (py - ay) * aby) / (l2 + 1e-12), 0.0, 1.0)
    qx = ax + t * abx
    qy = ay + t * aby
    return np.sqrt((px - qx) ** 2 + (py - qy) ** 2)


# 军事管理区外围左右两侧停机坪（相对坐标：围墙 X∈[0.18,0.82] 之外、指挥部同高带）。
# 与 _swarm_terrain 的军事区外围渲染元素保持同一基准，供 SwarmEnv 停靠点复用。
_HELIPAD_PADS = ((0.10, 0.66), (0.90, 0.66))


def _swarm_terrain(width: float, depth: float, amplitude: float,
                   seed: int = 0, canyons: bool = True,
                   waterfalls: bool = True,
                   clusters: "List[Tuple[float, float]]" = None) -> "Tuple[Terrain, dict]":
    """为 swarm 集群突防场景合成三维山地（确定性，随 seed 变化）。

    突防通道 [0, width] × [0, depth]（纵深 12~100 km）内放置若干座高斯山峰 +
    低频起伏，使「翻山 vs 绕山」「贴山规避雷达视线（LOS）」成为可优化的战略
    维度。山峰高度由 ``amplitude`` 缩放，谷底相对平坦（约 0 ~ 100 m）。

    在此基础上叠加「地面不可跨越」地貌（蓝方空中飞越不受限，防空车不可跨越）：
      * 峡谷（canyon）——一条**横向断崖**（沿 X 带宽方向贯穿），位于红方纵深
        （Y 方向）中线，把战场在纵深方向一分为二：起点一侧地势低、终点一侧
        地势整体抬升 ``drop``，形成无人机飞行途中必须翻越的巨大高低落差悬崖；
      * 河流（river）——断崖脚下的横向河流（沿 X 方向，位于低地一侧崖底）；
      * 瀑布（waterfall）——断崖中间**仅一处**的瀑布（沿 X 方向一小段），从
        高地泻落到崖底河流。

    返回 ``(Terrain, features)``，其中 features 记录地貌几何参数：
      canyons    = [[x0, y0, x1, y1, half_width, drop], ...]   横向断崖线
      rivers     = [[x0, y0, x1, y1, half_width], ...]         崖底河流
      waterfalls = [[x0, y0, x1, y1, half_width, drop], ...]   中间瀑布段
    供地面防空车避障与前端 3D 渲染使用。
    """
    rng = np.random.default_rng(seed + 20261008)
    n = 96
    xs = np.linspace(0.0, width, n)
    ys = np.linspace(0.0, depth, n)
    X, Y = np.meshgrid(xs, ys)
    # 山峰中心与半径（相对通道比例）：
    #   前 6 座为主峰（坡度平缓、错落分布，地面可翻越）；后 7 座构成两条
    #   山脉（低地东西向山脊 + 高地山脊，半径更窄 → 坡陡，防空车无法翻越，
    #   蓝方空中可飞越），形成「绕山 vs 翻山」的立体战略纵深。
    #   重要约束：所有山峰必须避开 Y∈[0.42, 0.52] 的「河流 + 断崖」带，
    #   保证整条河流与断崖不被山体掩埋、完整可见。
    cx = np.array([0.22, 0.50, 0.78, 0.06, 0.94, 0.50,
                   0.08, 0.28, 0.48, 0.68, 0.88, 0.18, 0.82])
    cy = np.array([0.26, 0.28, 0.26, 0.78, 0.78, 0.88,
                   0.14, 0.14, 0.14, 0.14, 0.14, 0.86, 0.86])
    sx = np.array([0.16, 0.16, 0.16, 0.10, 0.10, 0.14,
                   0.050, 0.050, 0.050, 0.050, 0.050, 0.055, 0.055])
    sy = np.array([0.07, 0.06, 0.07, 0.08, 0.08, 0.08,
                   0.040, 0.040, 0.040, 0.040, 0.040, 0.040, 0.040])
    amp = np.array([1.00, 0.90, 0.85, 0.70, 0.70, 0.75,
                    0.95, 1.05, 1.10, 1.05, 0.95, 0.85, 0.85]) * amplitude
    Z = np.zeros_like(X)
    for i in range(len(cx)):
        Z += amp[i] * np.exp(-((X - cx[i] * width) ** 2) / (2 * (sx[i] * width) ** 2)
                             - ((Y - cy[i] * depth) ** 2) / (2 * (sy[i] * depth) ** 2))
    # 低频 + 中频地形起伏，让谷地/山坡层次更丰富、爬升下降更真实
    Z += (80.0 * np.sin(X / 2200.0) * np.cos(Y / 1800.0)
          + 45.0 * np.sin(X / 900.0 + 1.3) * np.sin(Y / 700.0 + 0.7)
          + 60.0)

    feats = {'canyons': [], 'waterfalls': [], 'rivers': []}

    # 横向断崖（峡谷）：沿 X 带宽方向贯穿，位于红方纵深（Y）中线，
    # 把战场在纵深方向一分为二——起点一侧低、终点一侧整体抬升 drop。
    # 无人机飞行方向为 Y（起点 -> 终点），途中必须翻越这道断崖。
    if clusters and len(clusters) >= 2:
        yc = float(np.mean([c[1] for c in clusters]))
        yc = min(max(yc, 0.35 * depth), 0.65 * depth)
    else:
        yc = 0.5 * depth
    hw = float(rng.uniform(0.050, 0.070) * width)       # 过渡带加宽 → 缓坡断崖，蓝方可平滑翻越
    drop = float(rng.uniform(2.0, 2.4) * amplitude)      # 落差更高（约 1.8~2.2 km）
    lifted = False

    if canyons:
        x0 = float(0.03 * width)
        x1 = float(0.97 * width)
        # 终点一侧（Y > yc）整体抬升 drop，形成「先低后高」的巨大断崖
        Z += drop * 0.5 * (1.0 + np.tanh((Y - yc) / (hw * 0.3)))
        lifted = True
        feats['canyons'].append([x0, yc, x1, yc, hw, drop])

    # —— 悬崖上层（高地）军事管理区 ——
    # 断崖南侧（终点一侧）整体抬升后，把高地改造为红方军事管理区：
    # 指挥部 + 军营（成排营房）+ 防空导弹阵地 + 雷达 + 哨塔 + 碉堡 +
    # 围墙 + 军用道路，并就地平整出营地/阵地平台。
    if canyons and lifted:
        cmd = [0.50 * width, 0.72 * depth, 0.0]
        # 军营（成排营房）：前排 2 处 + 后排 2 处（roads 仍以前排两处为锚点）
        barracks = [[0.34 * width, 0.70 * depth, 0.0],
                    [0.66 * width, 0.70 * depth, 0.0],
                    [0.30 * width, 0.665 * depth, 0.0],
                    [0.70 * width, 0.665 * depth, 0.0]]
        # 帐篷群（生活区）：营房之间空地一排 + 指挥部两侧配属帐篷
        tents = [[0.36 * width, 0.645 * depth, 0.0],
                 [0.42 * width, 0.645 * depth, 0.0],
                 [0.48 * width, 0.645 * depth, 0.0],
                 [0.52 * width, 0.645 * depth, 0.0],
                 [0.58 * width, 0.645 * depth, 0.0],
                 [0.64 * width, 0.645 * depth, 0.0],
                 [0.43 * width, 0.74 * depth, 0.0],
                 [0.57 * width, 0.74 * depth, 0.0]]
        sam_sites = [[0.20 * width, 0.58 * depth, 0.0],
                     [0.40 * width, 0.555 * depth, 0.0],
                     [0.60 * width, 0.555 * depth, 0.0],
                     [0.80 * width, 0.58 * depth, 0.0]]
        radars = [[0.50 * width, 0.84 * depth, 0.0],
                  [0.26 * width, 0.76 * depth, 0.0]]
        # 瞭望塔：前沿 3 座 + 围墙四角 4 座
        watchtowers = [[0.28 * width, 0.56 * depth],
                       [0.50 * width, 0.56 * depth],
                       [0.72 * width, 0.56 * depth],
                       [0.19 * width, 0.56 * depth],
                       [0.81 * width, 0.56 * depth],
                       [0.19 * width, 0.85 * depth],
                       [0.81 * width, 0.85 * depth]]
        bunkers = [[0.20 * width, 0.62 * depth, 0.0],
                   [0.80 * width, 0.62 * depth, 0.0]]
        # 岗亭：南门（前沿入口）门楼两侧
        guard_posts = [[0.44 * width, 0.56 * depth, 0.0],
                       [0.56 * width, 0.56 * depth, 0.0]]
        # 军车（吉普/卡车）：营房前与指挥部前广场
        vehicles = [[0.40 * width, 0.68 * depth, 0.0],
                    [0.60 * width, 0.68 * depth, 0.0],
                    [0.47 * width, 0.715 * depth, 0.0],
                    [0.53 * width, 0.715 * depth, 0.0]]
        # 沙袋工事：防空阵地与碉堡周边
        sandbags = [[0.20 * width, 0.60 * depth, 0.0],
                    [0.80 * width, 0.60 * depth, 0.0],
                    [0.40 * width, 0.575 * depth, 0.0],
                    [0.60 * width, 0.575 * depth, 0.0]]
        # 燃料罐：营区北侧角落
        fuel_tanks = [[0.22 * width, 0.82 * depth, 0.0],
                      [0.78 * width, 0.82 * depth, 0.0]]
        # —— 军事管理区外围（围墙外左右两侧空地）：停机坪 + 油桶 + 哨塔 + 树木 ——
        # 约束：所有外围单位必须远离停机坪（直升机停靠区），保证直升机周围无任何
        # 建筑/单位遮挡（停机坪中心周围约 2 km 内保持净空）。
        helipads = [[hx * width, hy * depth, 0.0] for (hx, hy) in _HELIPAD_PADS]
        # 油桶组：贴围墙侧门（Y 偏低，远离停机坪纵向带）
        fuel_drums = [[0.17 * width, 0.58 * depth, 0.0],
                      [0.17 * width, 0.60 * depth, 0.0],
                      [0.17 * width, 0.62 * depth, 0.0],
                      [0.83 * width, 0.58 * depth, 0.0],
                      [0.83 * width, 0.60 * depth, 0.0],
                      [0.83 * width, 0.62 * depth, 0.0]]
        # 外围哨塔：空地最外侧边缘（远离停机坪，警戒外围通道）
        outposts = [[0.05 * width, 0.66 * depth, 0.0]]
        # 外围树木：空地边缘绿化（远离停机坪净空带）
        trees = [[0.06 * width, 0.56 * depth, 0.0],
                 [0.04 * width, 0.72 * depth, 0.0],
                 [0.07 * width, 0.80 * depth, 0.0],
                 [0.94 * width, 0.56 * depth, 0.0],
                 [0.96 * width, 0.72 * depth, 0.0],
                 [0.93 * width, 0.80 * depth, 0.0]]
        fx0, fx1 = 0.18 * width, 0.82 * width
        fy0, fy1 = 0.55 * depth, 0.86 * depth
        fences = [[fx0, fy0, fx1, fy0], [fx0, fy1, fx1, fy1],
                  [fx0, fy0, fx0, fy1], [fx1, fy0, fx1, fy1]]
        roads = [[cmd[0], cmd[1], barracks[0][0], barracks[0][1]],
                 [cmd[0], cmd[1], barracks[1][0], barracks[1][1]],
                 [cmd[0], cmd[1], sam_sites[1][0], sam_sites[1][1]],
                 [cmd[0], cmd[1], sam_sites[2][0], sam_sites[2][1]],
                 [cmd[0], cmd[1], radars[0][0], radars[0][1]],
                 [helipads[0][0], helipads[0][1], fx0, helipads[0][1]],
                 [helipads[1][0], helipads[1][1], fx1, helipads[1][1]]]
        # 地形平整：把营地/阵地平台向各自区域平均高度拉平，形成平坦平台
        platforms = [(cmd[0], cmd[1], 0.065 * width)]
        platforms += [(b[0], b[1], 0.045 * width) for b in barracks]
        platforms += [(s[0], s[1], 0.028 * width) for s in sam_sites]
        platforms += [(r[0], r[1], 0.024 * width) for r in radars]
        platforms += [(t[0], t[1], 0.02 * width) for t in tents]
        platforms += [(v[0], v[1], 0.018 * width) for v in vehicles]
        platforms += [(g[0], g[1], 0.014 * width) for g in guard_posts]
        platforms += [(f[0], f[1], 0.018 * width) for f in fuel_tanks]
        platforms += [(h[0], h[1], 0.035 * width) for h in helipads]
        platforms += [(d[0], d[1], 0.012 * width) for d in fuel_drums]
        platforms += [(o[0], o[1], 0.012 * width) for o in outposts]
        for (px_, py_, pr) in platforms:
            mask = np.exp(-((X - px_) ** 2 + (Y - py_) ** 2) / (2 * pr ** 2))
            h0 = float(np.sum(Z * mask) / max(np.sum(mask), 1e-9))
            Z = Z * (1.0 - mask) + h0 * mask
        feats['military'] = {
            'command': cmd,
            'barracks': barracks,
            'tents': tents,
            'sam_sites': sam_sites,
            'radars': radars,
            'watchtowers': watchtowers,
            'bunkers': bunkers,
            'guard_posts': guard_posts,
            'vehicles': vehicles,
            'sandbags': sandbags,
            'fuel_tanks': fuel_tanks,
            'fuel_drums': fuel_drums,
            'outposts': outposts,
            'trees': trees,
            'fences': fences,
            'roads': roads,
        }

    # 瀑布：断崖中间**仅一处**（X 中段），从高地泻落到崖底河流
    if waterfalls:
        if not lifted:
            Z += drop * 0.5 * (1.0 + np.tanh((Y - yc) / (hw * 0.3)))
        fx0 = float(0.40 * width)
        fx1 = float(0.60 * width)
        fhw = float(0.025 * width)
        feats['waterfalls'].append([fx0, yc, fx1, yc, fhw, drop])
        # 瀑布落点正下方挖大洼地（水潭），让水流落入低处汇聚，而非被崖脚隆起顶住
        pool_x = float(0.5 * width)
        pool_y = float(yc - 0.8 * hw)
        pool_d = float(0.65 * hw)
        pool_sx = float(fhw * 4.0)
        pool_sy = float(hw * 2.8)
        Z -= pool_d * np.exp(-((X - pool_x) ** 2) / (2 * pool_sx ** 2)
                             - ((Y - pool_y) ** 2) / (2 * pool_sy ** 2))

    # —— 崖底河流 ——（低地一侧，沿 X 方向贯穿的笔直河流）
    if canyons:
        river_y = max(float(yc - 2.5 * hw), 0.02 * depth)
        feats['rivers'].append([x0, river_y, x1, river_y, hw * 1.4])

    # —— 村庄聚落 ——（起点一侧低地平坦处，避开河流/瀑布/峡谷与山峰，供前端渲染民居群）
    feats['villages'] = []
    vrng = np.random.default_rng(seed + 555)
    for _ in range(4):
        vx = float(vrng.uniform(0.15, 0.85) * width)
        vy = float(vrng.uniform(0.03, 0.11) * depth)
        vr = float(vrng.uniform(0.035, 0.060) * width)
        feats['villages'].append([vx, vy, vr])

    return Terrain(xs, ys, Z), feats


# ===========================================================================
# 仿真引擎（纯 Python，确定性，毫秒级）
# ===========================================================================

def _decode_waypoints(x: np.ndarray, cfg: SwarmConfig, terrain=None) -> np.ndarray:
    """连续编码 [-1,1]^D -> (n_attack, K, 3) 通道内航点坐标 (x∈[0,M], y∈[0,L], z)。

    x/y 解码到突防通道平面 [0, width]×[0, depth]；z 编码为相对贴地飞行高度的
    爬升偏移 [0, max_alt_offset]，解码后航点高度 = 贴地高度（地面 + 离地安全）
    + 偏移，再夹到 max_alt 上限。传入 terrain（三维地形启用）时按贴地偏移解码；
    否则回退为绝对高度 [0, max_alt]（兼容无地形调用）。
    """
    x = np.asarray(x, dtype=float).reshape(cfg.n_attack, cfg.n_waypoints, 3)
    xs = 0.5 * (x[:, :, 0] + 1.0) * cfg.width
    ys = 0.5 * (x[:, :, 1] + 1.0) * cfg.depth
    if terrain is not None:
        z_off = 0.5 * (x[:, :, 2] + 1.0) * cfg.max_alt_offset
        ground = np.asarray(
            [terrain.height(float(px), float(py))
             for px, py in zip(xs.ravel(), ys.ravel())], dtype=float
        ).reshape(xs.shape)
        zs = np.minimum(ground + cfg.h_clearance + z_off, cfg.max_alt)
    else:
        zs = 0.5 * (x[:, :, 2] + 1.0) * cfg.max_alt
    return np.stack([xs, ys, zs], axis=-1)


def _decode_red_waypoints(red_x: np.ndarray, cfg: SwarmConfig) -> np.ndarray:
    """连续编码 [-1,1]^D_red -> (n_interceptors, K_red, 2) 拦截者巡逻航点。"""
    red_x = np.asarray(red_x, dtype=float).reshape(cfg.n_interceptors,
                                                  cfg.n_int_waypoints, 2)
    return np.stack([0.5 * (red_x[:, :, 0] + 1.0) * cfg.width,
                     0.5 * (red_x[:, :, 1] + 1.0) * cfg.depth], axis=-1)


class SwarmEnv:
    """一次确定性集群对抗 rollout 的求值器。

    绑定一套 ``SwarmConfig``（红方集群布局由 ``cluster_centers`` 确定，确定性
    可复现）。``cost(x)`` 返回越小越好的成本；``trajectory(x)`` 额外返回逐步
    快照供 GUI 动画。
    """

    def __init__(self, cfg: SwarmConfig, seed: int = 0, opponent=None):
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)
        # 军事基地（红方最终目标核心，位于 CD 边防线中点 = 蓝方目标红点同一纵深处）：
        # 蓝方突破 CD 边防线抵达目标红点即对基地构成打击（基地扣血 + 爆炸特效），
        # 保证「飞行目标（CD 边目标红点）」与「攻击目标（基地建筑）」位置一致。
        self.base_pos = (0.5 * cfg.width, cfg.depth)
        self.radar_pos = (0.5 * cfg.width, 0.84 * cfg.depth)
        self.base_hp_max = 100.0
        self.base_radius = 0.05 * cfg.width
        self.radar_range = 0.25 * cfg.depth
        # 红方无人机停靠点：军事管理区外围左右两侧停机坪（围墙外空地，不再卡营区建筑）
        self.helipads = [(hx * cfg.width, hy * cfg.depth) for (hx, hy) in _HELIPAD_PADS]
        self.interceptors0 = self._build_defenders(cfg, self.helipads)
        self.nofly = np.asarray(cfg.no_fly_zones, dtype=float).reshape(-1, 4)
        self.opponent = opponent
        self.red_x = None            # 协同演化时固定红方航点（None=追击规则/DRL）
        # 三维合成山地：贴地飞行、爬山能耗与 LOS 视线遮挡的物理基础
        self.terrain = None
        self.terrain_features = {'canyons': [], 'waterfalls': [], 'rivers': []}
        if cfg.terrain_enabled:
            self.terrain, self.terrain_features = _swarm_terrain(
                cfg.width, cfg.depth, cfg.terrain_amplitude, seed,
                canyons=cfg.terrain_canyons, waterfalls=cfg.terrain_waterfalls,
                clusters=cfg.cluster_centers)
        # 蓝方起点一致（AB 边中心）、终点为 CD 边上横向散布的目标红点；
        # 轨迹随机性来自每架独立的 K 个航点决策变量（DE 初始随机 + 优化分化）。
        rng = np.random.default_rng(seed + 4242)
        self.starts: List[Tuple[float, float]] = []
        self.targets: List[Tuple[float, float]] = []
        start_x = 0.5 * cfg.width
        for _ in range(cfg.n_attack):
            self.starts.append((start_x, 0.0))
            self.targets.append((float(rng.uniform(0.05 * cfg.width,
                                                   0.95 * cfg.width)),
                                 float(cfg.depth)))
        # 地面防空车初始位置：确定性散布在可通行区域（避开峡谷/瀑布与红方集群）
        self.aa0: List[Tuple[float, float]] = self._build_aa(cfg, seed)

    # ---- 三维高度 / 视线遮挡辅助 -----------------------------------------
    def _ground_h(self, x: float, y: float) -> float:
        if self.terrain is None:
            return 0.0
        return self.terrain.height(x, y)

    def _alt(self, x: float, y: float) -> float:
        """贴地飞行高度 = 地面高程 + 离地安全高度。"""
        return self._ground_h(x, y) + self.cfg.h_clearance

    def _los_blocked(self, ax, ay, az, bx, by, bz) -> bool:
        """红方拦截者与蓝方之间是否被山体遮挡（LOS 不通视）。"""
        if not self.cfg.los_block or self.terrain is None:
            return False
        return terrain_blocked(self.terrain, (ax, ay, az), (bx, by, bz))

    def _ground_passable(self, x: float, y: float) -> bool:
        """地面车辆（防空车）可否通行：断崖（峡谷）、瀑布、河流均不可跨越；
        陡峭高山（坡度超过阈值）不可翻越，平缓高低地势可通行。
        拦截导弹在空中飞行，不受地面地形限制。"""
        feats = getattr(self, 'terrain_features', None) or \
            {'canyons': [], 'waterfalls': [], 'rivers': []}
        for (x0, y0, x1, y1, hw, _v) in feats.get('canyons', []):
            if _seg_dist(np.array([x]), np.array([y]), x0, y0, x1, y1)[0] < hw:
                return False
        for (x0, y0, x1, y1, hw, _v) in feats.get('waterfalls', []):
            if _seg_dist(np.array([x]), np.array([y]), x0, y0, x1, y1)[0] < hw:
                return False
        for (x0, y0, x1, y1, hw) in feats.get('rivers', []):
            if _seg_dist(np.array([x]), np.array([y]), x0, y0, x1, y1)[0] < hw:
                return False
        # 陡峭高山不可翻越（防空车无法翻越高山）：中心差分估算地面坡度，超过阈值判为不可通行
        t = getattr(self, 'terrain', None)
        if t is not None:
            eps = max(getattr(t, 'dx', 1.0), getattr(t, 'dy', 1.0), 1.0) * 1.5
            dzdx = (self._ground_h(x + eps, y) - self._ground_h(x - eps, y)) / (2.0 * eps)
            dzdy = (self._ground_h(x, y + eps) - self._ground_h(x, y - eps)) / (2.0 * eps)
            if math.hypot(dzdx, dzdy) > 0.20:
                return False
        return True

    def _build_aa(self, cfg: SwarmConfig, seed: int) -> List[Tuple[float, float]]:
        """地面防空车初始位置：确定性散布在可通行区域（避开峡谷/瀑布与红方集群）。"""
        rng = np.random.default_rng(seed + 7771)
        out = []
        for _ in range(cfg.n_aa):
            placed = False
            for _try in range(300):
                px = float(rng.uniform(0.12 * cfg.width, 0.88 * cfg.width))
                py = float(rng.uniform(0.30 * cfg.depth, 0.85 * cfg.depth))
                if not self._ground_passable(px, py):
                    continue
                if any(math.hypot(px - cx, py - cy) < 0.12 * cfg.depth
                       for (cx, cy) in cfg.cluster_centers):
                    continue
                out.append((px, py))
                placed = True
                break
            if not placed:
                out.append((0.5 * cfg.width, 0.4 * cfg.depth))
        return out

    @staticmethod
    def _build_defenders(cfg: SwarmConfig, helipads) -> np.ndarray:
        """生成红方全部无人机的初始停靠位置：军事管理区外围左右两侧停机坪。

        红方无人机初始停靠在基地两侧停机坪待命（贴地），基地预警雷达捕获蓝方
        突防后起飞拦截。返回 (N, 2)。
        """
        pads = [(float(helipads[0][0]), float(helipads[0][1])),
                (float(helipads[1][0]), float(helipads[1][1]))]
        n_int = cfg.n_clusters * cfg.cluster_size
        if n_int <= 2:
            # 左右各 1 架：单独停靠各自停机坪中心，四周净空（远离围墙/油桶/
            # 哨塔等外围模型），不重叠、不卡成一团。
            return np.asarray(pads[:n_int], dtype=float).reshape(-1, 2)
        per_pad = max(1, (n_int + 1) // 2)
        # 圆周均布半径：保证相邻机间距 ≥ 900 m（直升机模型约占 600 m），
        # 避免停靠时直升机彼此重叠、卡成一团。
        r = max(cfg.formation_radius, per_pad * 900.0 / (2.0 * math.pi))
        out = []
        for k in range(n_int):
            px, py = pads[k % 2]
            ang = 2.0 * math.pi * (k // 2) / per_pad
            out.append((px + r * math.cos(ang), py + r * math.sin(ang)))
        return np.asarray(out, dtype=float).reshape(-1, 2)

    @staticmethod
    def _turn_toward(heading, target, max_turn):
        """以不超过 ``max_turn`` 的角速度把航向 ``heading`` 转向 ``target``。"""
        d = (target - heading + math.pi) % (2.0 * math.pi) - math.pi
        d = max(-max_turn, min(max_turn, d))
        return heading + d

    @staticmethod
    def _seg3d_hit(ax, ay, az, bx, by, bz, px, py, pz, r):
        """三维线段 (a,b) 到点 p 的最短距离是否 ≤ r（用于导弹路径穿越命中判定）。"""
        vx, vy, vz = bx - ax, by - ay, bz - az
        l2 = vx * vx + vy * vy + vz * vz
        t = 0.0 if l2 < 1e-12 else max(
            0.0, min(1.0, ((px - ax) * vx + (py - ay) * vy + (pz - az) * vz) / l2))
        qx, qy, qz = ax + t * vx, ay + t * vy, az + t * vz
        return (px - qx) ** 2 + (py - qy) ** 2 + (pz - qz) ** 2 <= r * r

    @staticmethod
    def _angle_diff(a, b):
        """把角度差规约到 [-pi, pi]。"""
        return (a - b + math.pi) % (2.0 * math.pi) - math.pi

    @staticmethod
    def _catmull_rom_path(pts, samples_per_seg: int = 16) -> np.ndarray:
        """对控制点序列做 Catmull-Rom 样条插值，返回 C1 连续的密集路径。

        飞机沿该路径的切线方向平滑转弯，从而消除「直线段 + 突然掉头」。
        """
        pts = np.asarray(pts, dtype=float)
        n = len(pts)
        if n < 2:
            return pts.copy()
        segs: List[np.ndarray] = []
        for i in range(n - 1):
            p0 = pts[i - 1] if i > 0 else pts[0]
            p1 = pts[i]
            p2 = pts[i + 1]
            p3 = pts[i + 2] if i + 2 < n else pts[i + 1]
            ts = np.linspace(0.0, 1.0, samples_per_seg, endpoint=False)
            t2 = ts * ts
            t3 = t2 * ts
            for t, tt2, tt3 in zip(ts, t2, t3):
                q = 0.5 * ((2.0 * p1)
                           + (-p0 + p2) * t
                           + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * tt2
                           + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * tt3)
                segs.append(q)
        segs.append(pts[-1])
        return np.asarray(segs, dtype=float)

    def _rollout(self, x, record: bool = False, red_x=None):
        cfg = self.cfg
        x = np.asarray(x, dtype=float).ravel()
        n, K = cfg.n_attack, cfg.n_waypoints
        W, L = cfg.width, cfg.depth

        dspeed = cfg.attack_speed
        dturn = cfg.max_turn_attack
        ispeed = cfg.defend_speed
        iturn = cfg.max_turn_defend
        irad = cfg.intercept_radius
        icnt = cfg.intercept_min_count
        ihalf = cfg.intercept_half_angle_rad
        vhalf = cfg.intercept_vert_half_angle_rad
        minsep = cfg.min_sep
        nsteps = cfg.n_steps
        max_alt = cfg.max_alt
        max_alt_offset = cfg.max_alt_offset
        la_steps = cfg.lookahead_steps
        la_dist = dspeed * la_steps        # 前瞻距离（沿航向前方地形高度）
        climb_rate = cfg.max_climb_rate
        h_clear = cfg.h_clearance
        e_cap = cfg.energy_capacity
        e_step = cfg.energy_per_step
        e_climb = cfg.climb_energy
        wp_reach = cfg.wp_reach_radius

        # 每架蓝方独立起/终点（沿 AB/CD 边界横向随机散布），3D 航点：
        # 起点 -> K 个 (x,y,z,偏移) -> 终点（CD 边上的目标红点）
        routes = []
        for i in range(n):
            sx, sy = self.starts[i]
            tx, ty = self.targets[i]
            base = i * K * 3
            pts = [(sx, sy, self._alt(sx, sy), 0.0)]
            for k in range(K):
                px = 0.5 * (x[base + 3 * k] + 1.0) * W
                py = 0.5 * (x[base + 3 * k + 1] + 1.0) * L
                # z 编码为相对贴地高度的爬升偏移 [0, max_alt_offset]，偏移在相邻
                # 航点间线性插值，使飞机高度连续平滑过渡（不直线拉升、不卡位）。
                z_off = 0.5 * (x[base + 3 * k + 2] + 1.0) * max_alt_offset
                pz = min(self._alt(px, py) + z_off, max_alt)
                pts.append((px, py, pz, z_off))
            # 终点即目标红点（CD 边上横向散布）：贴地高度，偏移回 0，与起点一致；
            # 到达判定看水平距离，不应诱导蓝方爬到 max_alt 高空空耗能源。
            pts.append((tx, ty, self._alt(tx, ty), 0.0))
            routes.append(pts)

        # 红方无人机初始停靠在停机坪（贴地待命），雷达捕获蓝方后起飞爬升至巡航高度
        ipos = [(float(p[0]), float(p[1]), self._ground_h(float(p[0]), float(p[1])))
                for p in self.interceptors0]
        n_int = len(ipos)
        # 地面防空车：贴地机动 + 对空拦截（不可跨越峡谷/瀑布，可翻越普通高低地势）
        n_aa = cfg.n_aa
        aa_speed = cfg.aa_speed
        aa_range = cfg.aa_range
        aa_vhalf = math.radians(cfg.aa_vert_half_angle)
        aa_turn = 0.6
        aapos = [(float(p[0]), float(p[1]), self._ground_h(float(p[0]), float(p[1])))
                 for p in self.aa0]
        aah = [math.atan2(self.targets[0][1] - p[1],
                          self.targets[0][0] - p[0]) for p in aapos]
        # 拦截导弹：每车在场导弹列表 [x, y, z, target_i, heading, fuel] 与发射冷却计时
        mspd = cfg.missile_speed
        mturn = cfg.missile_turn
        mclimb = cfg.missile_climb
        mrad = cfg.missile_radius
        mfuel = cfg.missile_fuel
        aa_reload_cfg = cfg.aa_reload
        aa_max_msl = cfg.aa_max_missiles
        aa_missiles = [[] for _ in range(n_aa)]
        aa_reload = [0.0] * n_aa
        msl_seq = 0                 # 导弹稳定 ID（前端按 ID 匹配，避免列表压缩错位）
        # 球形禁飞区 (cx, cy, cz, r)
        nofly = ([(float(nf[0]), float(nf[1]), float(nf[2]), float(nf[3]))
                  for nf in self.nofly] if self.nofly.size else [])

        # 红方航点（协同演化）：拦截者沿自身航点闭环巡逻，而非追击
        red_routes = None
        rnext = None
        if red_x is not None:
            red_x = np.asarray(red_x, dtype=float).ravel()
            red_routes = []
            for k in range(n_int):
                base = k * cfg.n_int_waypoints * 2
                pts = [(ipos[k][0], ipos[k][1])]
                for j in range(cfg.n_int_waypoints):
                    rx = 0.5 * (red_x[base + 2 * j] + 1.0) * W
                    ry = 0.5 * (red_x[base + 2 * j + 1] + 1.0) * L
                    pts.append((rx, ry))
                pts.append((ipos[k][0], ipos[k][1]))  # 闭环回到起点
                red_routes.append(pts)
            rnext = [1] * n_int

        dpos = [(self.starts[i][0], self.starts[i][1],
                 self._alt(self.starts[i][0], self.starts[i][1])) for i in range(n)]
        dhead = [math.atan2(routes[i][1][1] - dpos[i][1],
                            routes[i][1][0] - dpos[i][0]) for i in range(n)]
        dnext = [1] * n                # 下一路点索引（0=起点，末尾=终点）
        state = [0] * n                # 0 飞行 1 突破成功 2 被拦截 3 坠毁
        energy = [float(e_cap)] * n    # 每架剩余能源

        # 红方初始朝向：指向首个目标方向（拦截范围朝前，覆盖蓝方前进路线）
        ihead = [math.atan2(self.targets[0][1] - p[1],
                            self.targets[0][0] - p[0]) for p in ipos]
        # 红方无人机状态：0 停靠待命（贴地停机坪）1 起飞爬升 2 巡航拦截
        iphase = [0] * n_int
        # 军事基地血量：蓝方每突破一架扣血，归零即被攻破
        base_hp = float(self.base_hp_max)
        per_hit = self.base_hp_max / max(n, 1)
        radar_x, radar_y = self.radar_pos

        nofly_steps = 0.0
        bounds_steps = 0.0
        path_len = [0.0] * n           # 每架实际飞行距离（米）
        flight_t = [0] * n             # 每架飞行步数（到终态）
        climb_total = [0.0] * n        # 每架累计爬升米数（三维爬山能耗）
        turn_total = [0.0] * n         # 每架累计航向变化（轨迹曲率，rad）
        min_dist = 1e18
        first_capture = -1.0           # 蓝方首次被拦截发生的时刻（秒），-1 表示未被拦截
        risk_time = 0.0                # 蓝方处于红方拦截半径内的累计暴露时间（秒）

        frames: List[Dict] = []
        if record:
            frames.append(self._snapshot(0, dpos, state, ipos, dhead, ihead, aapos, aah,
                                         [[m[6], m[0], m[1], m[2]] for a in range(n_aa)
                                          for m in aa_missiles[a]],
                                         events=None, iphase=iphase,
                                         base=(base_hp, self.base_hp_max)))

        for _step in range(1, nsteps + 1):
            events: List[Dict] = []      # 本步拦截/坠毁事件
            # 1) 蓝方：有限角速度转向当前路点，水平前进 + 垂直爬升/下降（有限速率）
            for i in range(n):
                if state[i] != 0:
                    continue
                tgt = routes[i][dnext[i]]
                prev_pt = routes[i][dnext[i] - 1]
                is_final = dnext[i] == len(routes[i]) - 1
                th = math.atan2(tgt[1] - dpos[i][1], tgt[0] - dpos[i][0])
                old_head = dhead[i]
                dhead[i] = self._turn_toward(dhead[i], th, dturn)
                turn_total[i] += abs(self._angle_diff(dhead[i], old_head))
                nx = dpos[i][0] + dspeed * math.cos(dhead[i])
                ny = dpos[i][1] + dspeed * math.sin(dhead[i])
                # 垂直：贴地平滑爬升——航段内爬升偏移线性插值（高度连续过渡，不直线
                # 拉升）+ 前瞻前方地形提前爬升 + 地面下限硬约束（绝不穿山）
                seg_len = math.hypot(tgt[0] - prev_pt[0], tgt[1] - prev_pt[1])
                d_to_end = math.hypot(nx - tgt[0], ny - tgt[1])
                t_seg = (max(0.0, min(1.0, 1.0 - d_to_end / seg_len))
                         if seg_len > 1e-6 else 0.0)
                off_t = prev_pt[3] + (tgt[3] - prev_pt[3]) * t_seg
                ground = self._ground_h(nx, ny)
                la_x = nx + la_dist * math.cos(dhead[i])
                la_y = ny + la_dist * math.sin(dhead[i])
                la_ground = self._ground_h(la_x, la_y)
                floor = max(ground, la_ground) + h_clear   # 前瞻贴地下限
                # 目标高度 = 贴地 + 插值偏移，且不低于贴地下限、不超上限
                desired = min(max(ground + h_clear + off_t, floor), max_alt)
                dz = max(-climb_rate, min(climb_rate, desired - dpos[i][2]))
                nz = dpos[i][2] + dz
                nz = max(nz, ground + h_clear)   # 绝不穿山
                nz = min(nz, max_alt)
                climb = max(0.0, nz - dpos[i][2])
                climb_total[i] += climb
                # 能源：水平飞行 + 爬升额外，耗尽即坠毁
                energy[i] -= e_step + e_climb * climb
                if energy[i] <= 0.0:
                    energy[i] = 0.0
                    state[i] = 3
                    events.append({'t': 'crash', 'd': i, 'x': nx, 'y': ny, 'z': nz, 's': -1})
                dpos[i] = (nx, ny, nz)
                path_len[i] += dspeed
                flight_t[i] = _step
                # 到达判定：水平抵达航点（含末尾红点）≤ wp_reach 才推进/突破；
                # 不以「越过 CD 边界（y≥L）」判突破——最终目标必须是红点而非边界。
                if state[i] == 0 and math.hypot(dpos[i][0] - tgt[0],
                                                dpos[i][1] - tgt[1]) <= wp_reach:
                    if is_final:
                        state[i] = 1
                        # 突破成功：打击军事基地（扣血 + 基地爆炸特效）
                        base_hp = max(0.0, base_hp - per_hit)
                        events.append({'t': 'bomb', 'd': i,
                                       'x': self.base_pos[0], 'y': self.base_pos[1],
                                       'z': self._alt(self.base_pos[0], self.base_pos[1])})
                    else:
                        dnext[i] += 1

            # 1.5) 停靠待命 → 起飞：基地预警雷达捕获蓝方后，停靠中的红方无人机起飞
            for k in range(n_int):
                if iphase[k] != 0:
                    continue
                if any(state[i] == 0
                       and math.hypot(dpos[i][0] - radar_x, dpos[i][1] - radar_y) <= self.radar_range
                       for i in range(n)):
                    iphase[k] = 1

            # 2) 红方运动：优先追击侦察范围内的蓝方；否则巡逻（协同）/ 追击最近（规则）/ DRL
            if self.opponent is None or red_routes is not None:
                for k in range(n_int):
                    if iphase[k] == 0:
                        continue  # 停靠待命，本步不移动
                    # 选目标：圆锥侦察范围内最近的存活蓝方（范围内每步持续追击）
                    bi, bd = -1, 1e18
                    for i in range(n):
                        if state[i] != 0:
                            continue
                        dx = dpos[i][0] - ipos[k][0]
                        dy = dpos[i][1] - ipos[k][1]
                        dz = dpos[i][2] - ipos[k][2]
                        hdist = math.hypot(dx, dy)
                        d3 = math.sqrt(dx * dx + dy * dy + dz * dz)
                        if (d3 <= irad
                                and abs(self._angle_diff(math.atan2(dy, dx), ihead[k])) <= ihalf
                                and abs(math.atan2(dz, hdist)) <= vhalf
                                and d3 < bd):
                            bi, bd = i, d3
                    if bi >= 0:
                        # 持续追击侦察范围内的目标（逃出范围则回到巡逻/追击别的目标）
                        th = math.atan2(dpos[bi][1] - ipos[k][1],
                                        dpos[bi][0] - ipos[k][0])
                    elif red_routes is not None:
                        # 巡逻：沿自身航点闭环
                        tgt = red_routes[k][rnext[k]]
                        th = math.atan2(tgt[1] - ipos[k][1], tgt[0] - ipos[k][0])
                    else:
                        # 规则：追击最近存活蓝方
                        bj, bd = -1, 1e18
                        for i in range(n):
                            if state[i] != 0:
                                continue
                            d = math.hypot(dpos[i][0] - ipos[k][0],
                                           dpos[i][1] - ipos[k][1])
                            if d < bd:
                                bj, bd = i, d
                        if bj < 0:
                            continue
                        th = math.atan2(dpos[bj][1] - ipos[k][1],
                                        dpos[bj][0] - ipos[k][0])
                    ihead[k] = self._turn_toward(ihead[k], th, iturn)
                    nix = ipos[k][0] + ispeed * math.cos(ihead[k])
                    niy = ipos[k][1] + ispeed * math.sin(ihead[k])
                    ipos[k] = (nix, niy, self._alt(nix, niy))
                    if iphase[k] == 1:
                        iphase[k] = 2  # 起飞完成，进入巡航拦截
                    # 仅在巡逻时推进航点索引
                    if bi < 0 and red_routes is not None:
                        if math.hypot(ipos[k][0] - red_routes[k][rnext[k]][0],
                                      ipos[k][1] - red_routes[k][rnext[k]][1]) <= wp_reach:
                            rnext[k] += 1
                            if rnext[k] >= len(red_routes[k]):
                                rnext[k] = 1
            else:
                targets = self.opponent.act(ipos, ihead, dpos, state, cfg)
                for k in range(n_int):
                    if iphase[k] == 0:
                        continue  # 停靠待命，本步不移动
                    if k >= len(targets) or targets[k] is None:
                        continue
                    ihead[k] = self._turn_toward(ihead[k], targets[k], iturn)
                    nix = ipos[k][0] + ispeed * math.cos(ihead[k])
                    niy = ipos[k][1] + ispeed * math.sin(ihead[k])
                    ipos[k] = (nix, niy, self._alt(nix, niy))
                    if iphase[k] == 1:
                        iphase[k] = 2

            # 3) 红方机间避撞（编队约束：间距 > min_sep）
            for a in range(n_int):
                for b in range(a + 1, n_int):
                    dx = ipos[b][0] - ipos[a][0]
                    dy = ipos[b][1] - ipos[a][1]
                    d = math.hypot(dx, dy)
                    if d < minsep and d > 1e-6:
                        push = (minsep - d) / 2.0
                        ux, uy = dx / d, dy / d
                        ipos[a] = (ipos[a][0] - push * ux,
                                   ipos[a][1] - push * uy, ipos[a][2])
                        ipos[b] = (ipos[b][0] + push * ux,
                                   ipos[b][1] + push * uy, ipos[b][2])

            # 3.5) 地面防空车：贴地追踪最近存活蓝方（不可跨越峡谷/瀑布，遇障绕行）
            for a in range(n_aa):
                ax, ay = aapos[a][0], aapos[a][1]
                bi, bd = -1, 1e18
                for i in range(n):
                    if state[i] != 0:
                        continue
                    d = math.hypot(dpos[i][0] - ax, dpos[i][1] - ay)
                    if d < bd:
                        bi, bd = i, d
                if bi >= 0:
                    aah[a] = self._turn_toward(
                        aah[a], math.atan2(dpos[bi][1] - ay, dpos[bi][0] - ax), aa_turn)
                nx = ax + aa_speed * math.cos(aah[a])
                ny = ay + aa_speed * math.sin(aah[a])
                if not self._ground_passable(nx, ny):
                    moved = False
                    for dh in (0.5, -0.5, 1.0, -1.0):
                        hh = aah[a] + dh
                        tx = ax + aa_speed * math.cos(hh)
                        ty = ay + aa_speed * math.sin(hh)
                        if self._ground_passable(tx, ty):
                            nx, ny = tx, ty
                            aah[a] = self._turn_toward(aah[a], hh, aa_turn)
                            moved = True
                            break
                    if not moved:
                        nx, ny = ax, ay
                aapos[a] = (nx, ny, self._ground_h(nx, ny))

            # 3.6) 防空车对空拦截：锁定 → 发射拦截导弹 → 一对一纯追踪追击（导弹
            # 略快于无人机、限转弯率、燃料耗尽自毁，命中即击落，可被机动甩掉）
            for a in range(n_aa):
                if aa_reload[a] > 0.0:
                    aa_reload[a] -= 1.0
                # 发射：冷却就绪且未超上限，锁定攻击范围内最近的存活蓝方（LOS 通畅）
                if aa_reload[a] <= 0.0 and len(aa_missiles[a]) < aa_max_msl:
                    bi, bd = -1, 1e18
                    for i in range(n):
                        if state[i] != 0:
                            continue
                        dx = dpos[i][0] - aapos[a][0]
                        dy = dpos[i][1] - aapos[a][1]
                        dz = dpos[i][2] - aapos[a][2]
                        hdist = math.hypot(dx, dy)
                        if (hdist <= aa_range and hdist < bd
                                and abs(math.atan2(dz, hdist)) <= aa_vhalf
                                and not any(m[3] == i for m in aa_missiles[a])
                                and not self._los_blocked(dpos[i][0], dpos[i][1], dpos[i][2],
                                                          aapos[a][0], aapos[a][1], aapos[a][2])):
                            bi, bd = i, hdist
                    if bi >= 0:
                        aa_missiles[a].append([aapos[a][0], aapos[a][1],
                                               aapos[a][2] + 2.0, bi,
                                               math.atan2(dpos[bi][1] - aapos[a][1],
                                                          dpos[bi][0] - aapos[a][0]),
                                               mfuel, msl_seq])
                        msl_seq += 1
                        aa_reload[a] = aa_reload_cfg
                # 导弹飞行：纯追踪制导，速度略快于无人机，限转弯率（不能直角
                # 转弯），燃料耗尽自毁；命中即击落（一对一追击：目标唯一）
                alive = []
                for m in aa_missiles[a]:
                    ti = m[3]
                    if ti >= n or state[ti] != 0:
                        continue  # 目标已死 → 导弹自毁
                    m[5] -= 1
                    if m[5] <= 0:
                        continue  # 燃料耗尽 → 导弹失的（自毁），无人机可甩掉
                    tx, ty, tz = dpos[ti][0], dpos[ti][1], dpos[ti][2]
                    th = math.atan2(ty - m[1], tx - m[0])
                    m[4] = self._turn_toward(m[4], th, mturn)
                    nx = m[0] + mspd * math.cos(m[4])
                    ny = m[1] + mspd * math.sin(m[4])
                    nz = m[2] + max(-mclimb, min(mclimb, tz - m[2]))
                    # 命中：本步飞行路径穿越目标（线段-点最短距离 ≤ 命中半径）
                    if self._seg3d_hit(m[0], m[1], m[2], nx, ny, nz,
                                       tx, ty, tz, mrad):
                        state[ti] = 2
                        events.append({'t': 'missile', 'd': ti,
                                       'x': tx, 'y': ty, 'z': tz, 's': a})
                        if first_capture < 0:
                            first_capture = float(_step)
                        continue  # 命中 → 导弹消失
                    m[0], m[1], m[2] = nx, ny, nz
                    alive.append(m)
                aa_missiles[a] = alive

            # 4) 拦截判据：≥icnt 架红方前方圆锥内且三维距离 <= irad（LOS 通畅）
            if getattr(self.opponent, 'active', True) or red_routes is not None:
                for i in range(n):
                    if state[i] != 0:
                        continue
                    cnt = 0
                    for k in range(n_int):
                        dx = dpos[i][0] - ipos[k][0]
                        dy = dpos[i][1] - ipos[k][1]
                        dz = dpos[i][2] - ipos[k][2]
                        hdist = math.hypot(dx, dy)
                        if (abs(self._angle_diff(math.atan2(dy, dx), ihead[k])) <= ihalf
                                and abs(math.atan2(dz, hdist)) <= vhalf
                                and math.sqrt(dx * dx + dy * dy + dz * dz) <= irad):
                            if self._los_blocked(dpos[i][0], dpos[i][1], dpos[i][2],
                                                 ipos[k][0], ipos[k][1], ipos[k][2]):
                                continue
                            cnt += 1
                            if cnt >= icnt:
                                state[i] = 2
                                events.append({'t': 'intercept', 'd': i,
                                               'x': dpos[i][0], 'y': dpos[i][1],
                                               'z': dpos[i][2], 's': k})
                                if first_capture < 0:
                                    first_capture = float(_step)
                                break

            # 5) 球形禁飞区 / 越界
            for i in range(n):
                if state[i] != 0:
                    continue
                px, py, pz = dpos[i][0], dpos[i][1], dpos[i][2]
                for (cx, cy, cz, r) in nofly:
                    if math.sqrt((px - cx) ** 2 + (py - cy) ** 2
                                 + (pz - cz) ** 2) <= r:
                        nofly_steps += 1.0
                        break
                if px < 0.0 or px > W or py < 0.0 or py > L:
                    bounds_steps += 1.0

            # 6) 安全裕度：存活蓝方与红方的最小距离
            for i in range(n):
                if state[i] != 0:
                    continue
                for k in range(n_int):
                    dx = dpos[i][0] - ipos[k][0]
                    dy = dpos[i][1] - ipos[k][1]
                    dz = dpos[i][2] - ipos[k][2]
                    d = math.sqrt(dx * dx + dy * dy + dz * dz)
                    if d < min_dist:
                        min_dist = d
                    if d < irad:
                        risk_time += 1.0
                        break

            if record:
                frames.append(self._snapshot(_step, dpos, state, ipos,
                                             dhead, ihead, aapos, aah,
                                             [[m[6], m[0], m[1], m[2]] for a in range(n_aa)
                                              for m in aa_missiles[a]],
                                             events=events, iphase=iphase,
                                             base=(base_hp, self.base_hp_max)))

        if min_dist >= 1e17:
            min_dist = L
        total_path = sum(path_len)
        total_climb = sum(climb_total)
        total_turn = sum(turn_total)
        direct = sum(math.hypot(self.targets[i][0] - self.starts[i][0],
                                self.targets[i][1] - self.starts[i][1])
                     for i in range(n))
        path_eff = direct / max(total_path, 1.0) if total_path > 0 else 0.0
        metrics = {
            'path_length': float(total_path),
            'flight_time': float(max(flight_t) if flight_t else 0.0),
            'min_dist': float(min_dist),
            'bounds_steps': int(bounds_steps),
            'nofly_steps': int(nofly_steps),
            'n_arrived': int(sum(1 for s in state if s == 1)),
            'n_lost': int(sum(1 for s in state if s == 2)),
            'n_crashed': int(sum(1 for s in state if s == 3)),
            'climb': float(total_climb),
            'first_capture': float(first_capture),
            'risk_time': float(risk_time),
            'path_efficiency': float(path_eff),
            'curvature': float(total_turn),
        }
        cost = -self._reward(state, nofly_steps, bounds_steps, total_path,
                             min_dist, total_climb)
        if record:
            return cost, state, metrics, frames
        return cost, state, metrics, None

    def _reward(self, drone_state, nofly_steps, bounds_steps, path_length,
                min_dist, total_climb):
        """收益 = 离散胜负项 + 连续梯度项（绕行 / 爬山能耗 / 安全裕度）。

        连续项让 cost 具有梯度，使 DE 收敛曲线呈现持续下降而非一条直线。
        爬升按等效距离折算进航程，使「翻山」与「绕山」成为连续可微的权衡。
        """
        cfg = self.cfg
        n_arrived = sum(1 for s in drone_state if s == 1)
        n_lost = sum(1 for s in drone_state if s == 2)
        n_crashed = sum(1 for s in drone_state if s == 3)
        n_unfinished = cfg.n_attack - n_arrived - n_lost - n_crashed
        path_norm = path_length / max(cfg.n_attack * cfg.depth, 1.0)
        safety_norm = min(1.0, min_dist / (cfg.intercept_radius * 4.0))
        return (cfg.w_arrive * n_arrived
                - cfg.w_lost * n_lost
                - cfg.w_crash * n_crashed
                - cfg.w_time * n_unfinished
                - cfg.w_nofly * nofly_steps
                - cfg.w_bounds * bounds_steps
                - cfg.w_path * (path_norm - 1.0)
                - cfg.w_climb * total_climb / max(cfg.terrain_amplitude, 1.0)
                + cfg.w_safety * safety_norm)

    @staticmethod
    def _snapshot(step, drone_pos, drone_state, inter_pos, drone_head, inter_head,
                  aa_pos=None, aa_head=None, missiles=None, events=None,
                  iphase=None, base=None):
        phases = iphase if iphase is not None else [2] * len(inter_pos)
        return {
            'step': int(step),
            'drones': [[float(p[0]), float(p[1]), float(p[2]), int(s), float(h)]
                       for p, s, h in zip(drone_pos, drone_state, drone_head)],
            'interceptors': [[float(p[0]), float(p[1]), float(p[2]), float(h), int(ph)]
                             for p, h, ph in zip(inter_pos, inter_head, phases)],
            'aa': [[float(p[0]), float(p[1]), float(p[2]), float(h)]
                   for p, h in zip(aa_pos or [], aa_head or [])],
            'missiles': [[int(m[0]), float(m[1]), float(m[2]), float(m[3])]
                         for m in (missiles or [])],
            # 军事基地血量 [当前, 上限]，供前端血条与攻破判定（无基地场景为空）
            'base': [float(base[0]), float(base[1])] if base else [],
            # 本步发生的拦截/坠毁事件，供前端播放「被拦截/被击落」反馈动画：
            # {'t': 'intercept'|'missile'|'crash'|'bomb', 'd': 无人机索引,
            #  'x','y','z': 事件位置(米), 's': 施体索引(拦截者/防空车，crash 为 -1)}
            'events': list(events or []),
        }

    def cost(self, x: np.ndarray) -> float:
        cost, _, _, _ = self._rollout(x, record=False, red_x=self.red_x)
        return float(cost)

    def evaluate(self, x: np.ndarray):
        """返回 (cost, state, metrics)，供 GUI 多维指标展示。"""
        cost, state, metrics, _ = self._rollout(x, record=False, red_x=self.red_x)
        return cost, state, metrics

    def trajectory(self, x: np.ndarray):
        """返回 (cost, state, frames)，供 GUI 动画演示。"""
        cost, state, _, frames = self._rollout(x, record=True, red_x=self.red_x)
        return cost, state, frames

    def red_cost(self, red_x: np.ndarray, blue_x: np.ndarray) -> float:
        """协同演化：红方评估函数（固定蓝方航点 blue_x，红方按 red_x 巡逻）。

        红方目标 = 最小化蓝方突破、最大化击落、并让蓝方更多暴露于拦截半径内，
        后一项（risk_time）为红方提供连续的搜索梯度。
        """
        cfg = self.cfg
        _, _, metrics, _ = self._rollout(blue_x, record=False, red_x=red_x)
        return (cfg.w_arrive * metrics['n_arrived']
                - cfg.w_lost * metrics['n_lost']
                - 0.5 * metrics['risk_time'])


# ===========================================================================
# 问题协议适配（与 CECFunction 鸭子类型一致）
# ===========================================================================

class SwarmProblem:
    """把一次集群对抗场景包装成 DE 可直接消费的问题对象。

    协议字段对齐 ``cec_suites.CECFunction`` 与 ``uav_adversarial.UAVAdversarialProblem``。
    """

    def __init__(self, scenario: str, fid: int, env: SwarmEnv, name: str = ''):
        self.suite = f'uav_{scenario}'
        self.scenario = scenario
        self.fid = fid
        self.env = env
        self.cfg = env.cfg
        self.dim = env.cfg.dim
        self.red_dim = env.cfg.red_dim
        self.lb = -1.0
        self.ub = 1.0
        self.f_opt = None
        self.x_opt = None
        self.name = name or f'{scenario} task {fid}'
        self.category = 'application'

    def decode(self, x: np.ndarray) -> np.ndarray:
        terrain = self.env.terrain if self.cfg.terrain_enabled else None
        return _decode_waypoints(x, self.cfg, terrain=terrain)

    def __call__(self, x) -> float:
        return self.env.cost(x)

    def trajectory(self, x):
        return self.env.trajectory(x)

    def evaluate(self, x):
        """返回 (cost, state, metrics)，供 GUI 多维收敛曲线展示。"""
        return self.env.evaluate(x)

    def red_cost(self, red_x, blue_x):
        """协同演化：红方评估（固定蓝方 blue_x，评估红方航点 red_x）。"""
        return self.env.red_cost(red_x, blue_x)

    @property
    def label(self):
        return f'U{self.fid}'

    def __repr__(self):
        return f'<UAV {self.scenario} U{self.fid} {self.name} D={self.dim}>'


# ===========================================================================
# 场景工厂
# ===========================================================================

def build_swarm_env(fid: int, seed: int = 0,
                    n_waypoints: Optional[int] = None,
                    n_attack: Optional[int] = None,
                    opponent=None) -> SwarmEnv:
    """按任务 id 生成确定性的集群对抗环境（对应赛题四问的简化配置）。

    ``n_waypoints`` 可覆盖每架蓝方的中途航点数 K（维度 D = n_attack * 3K），
    ``n_attack`` 可覆盖逃逸无人机数量（起点一致、各自航点轨迹随机）；两者均为
    None 时用默认值（K = 4，n_attack = 1）。
    """
    cfg = SwarmConfig()
    if n_waypoints is not None:
        cfg.n_waypoints = int(n_waypoints)
    if n_attack is not None and int(n_attack) > 0:
        cfg.n_attack = int(n_attack)

    if fid == 1:                                  # 问题一：双集群沿纵深错开（每集群 1 架，左右各停 1 架）
        cfg.width = 30000.0
        cfg.n_clusters = 2
        cfg.cluster_size = 1
        cfg.cluster_centers = [(15000.0, 15000.0), (15000.0, 35000.0)]
    elif fid == 2:                                # 问题二：窄通道 + 集群贴近 CD
        cfg.width = 12000.0
        cfg.n_clusters = 2
        cfg.cluster_size = 5
        cfg.cluster_centers = [(6000.0, 40000.0), (6000.0, 45000.0)]
        cfg.no_fly_zones = [(6000.0, 30000.0, 300.0, 2500.0)]
    elif fid == 3:                                # 问题三：两波次增援（每集群 10 架）
        cfg.width = 70000.0
        cfg.n_clusters = 2
        cfg.cluster_size = 10
        cfg.cluster_centers = [(35000.0, 20000.0), (35000.0, 40000.0)]
    elif fid == 4:                                # 问题四：5 集群协同（单机加强版）
        cfg.width = 100000.0
        cfg.n_clusters = 5
        cfg.cluster_size = 4
        cfg.cluster_centers = [
            (50000.0, 10000.0), (25000.0, 22000.0), (75000.0, 22000.0),
            (35000.0, 35000.0), (65000.0, 35000.0)]
        cfg.no_fly_zones = [
            (50000.0, 30000.0, 320.0, 5000.0),
            (40000.0, 40000.0, 350.0, 4000.0)]
    else:
        # 更多任务：随机但确定地散布集群与带宽
        rng = np.random.default_rng(seed + fid * 101)
        cfg.width = float(rng.uniform(15000, 100000))
        cfg.n_clusters = 2 + (fid % 4)
        cfg.cluster_size = 5
        cfg.cluster_centers = [
            (cfg.width / 2.0, float(rng.uniform(8000, cfg.depth - 8000)))
            for _ in range(cfg.n_clusters)]
        if fid % 2 == 0:
            cfg.no_fly_zones = [
                (cfg.width / 2.0, cfg.depth / 2.0, 300.0,
                 float(rng.uniform(2000, 5000)))]

    return SwarmEnv(cfg, seed=seed + fid * 101, opponent=opponent)


# 注册：场景名 -> (默认维度, 默认任务数)
SWARM_DIM = SwarmConfig().dim         # 1 * 4 * 3 = 12
SWARM_NFUNCS = 4


if __name__ == '__main__':
    for fid in range(1, SWARM_NFUNCS + 1):
        env = build_swarm_env(fid)
        p = SwarmProblem('swarm', fid, env)
        x = np.zeros(p.dim)
        c = p(x)
        print(f'{p!r}  cost(x=0)={c:.1f}  env.dim={p.cfg.dim}')
        rng = np.random.default_rng(1)
        costs = [p(rng.uniform(-1, 1, p.dim)) for _ in range(200)]
        print(f'  随机解 cost: min={min(costs):.1f} med={np.median(costs):.1f} '
              f'max={max(costs):.1f}')
